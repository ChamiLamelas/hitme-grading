/*
 *  CharLinkedList.cpp
 *  Rianna Liu
 *  1/31/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 * An implementation of the LinkedList interface, the LinkedList can be used
 * to store characters. This is a doubly linked list interface with th use
 * of a back pointer 
 *
 */

#include "CharLinkedList.h"
#include <sstream>
#include <iostream>
#include <string>
#include <stdexcept>


using namespace std;

//title: newNode
//argument: char newData, Node*next, Node *prev
//purpose: to make a new Node with the passed in variable 
//return: node
CharLinkedList::Node *CharLinkedList::newNode(char newData, Node *next, Node 
*prev){
    Node *new_node = new Node;
    new_node->data = newData;
    new_node->next = next; 
    new_node->prev = prev; 

    return new_node; 

}

//title: Default constructor
//argument:none
//purpose: declare an empty linked list
//return: none
CharLinkedList::CharLinkedList(){
    front = nullptr;
    back = nullptr; 
    numItems = 0;
}
//title: Constructor that declares one element linked list
//argument: one character
//purpose: to declare a linked list with one element s
//return: none
CharLinkedList::CharLinkedList(char c){
    numItems = 1; 
    front = newNode(c, nullptr, nullptr);
    back = front;
}
//title:Constructor that declares multiple elements in linked lsit
//argument: a character array and and integer size 
//purpose: to declare a linked listed filled with the given elements from
//array and given size
//return: none
CharLinkedList::CharLinkedList(char arr[], int size){
    numItems = 0; 
    front = nullptr;
    back = nullptr; 
    for(int i = 0; i < size; i++){
        pushAtBack(arr[i]); 
    }
}
//title: Copy Constructor
//argument: another instance of CharLinkedList class
//purpose: to make a deep copy of my instance into this other instance
//return: none
CharLinkedList::CharLinkedList(const CharLinkedList &other){ 
    numItems = 0; 
    front = nullptr;
    back = nullptr; 
    Node *current = other.front; 
    for(int i  = 0; i < other.numItems; i++){
        pushAtBack(other.elementAt(i)); 
    }
}
//title: Destructor
//argument: none
//purpose: delete contents in the linkedlist
//return: none
CharLinkedList::~CharLinkedList(){ 
    recHelperDelete(front); 
}


//functions
//title: Assignment operator 
//purpose: recycles the storage associated with the instance
//on the left of the assignment and makes a deep copy of the 
//instance on the right hand side
//arugments: instance of CharLinkedList class 
//return: none
CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other){
    for(int i = 0; i < other.size(); i++){
        pushAtBack(other.elementAt(i));
    }
    return *this;
}

//title: recHelper
//argument: node type curr, and integer index
//purpose: recursive method to pass through array and return element at given
//index
//return: node at given index
CharLinkedList::Node *CharLinkedList::recHelper(Node *curr, int index) const{
    if(index == 0){
        return curr; 
    } else {
        return recHelper(curr->next, index - 1); 
    }
}
//title:recHelperDelete
//argument: node type curr
//purpose: recursive method to pass through list and delete every element 
//until the end
//return: none
void CharLinkedList::recHelperDelete(Node *curr){
    if(curr == nullptr){
        return;  
    } else {
        recHelperDelete(curr->next); 
        delete curr;
    }
}
//title: isEmpty
//argument: none
//purpose: checks if list is empty 
//return: true or false 
bool CharLinkedList::isEmpty() const{
    if(front == nullptr){
        return true; 
    } else{
        return false; 
    }
}
//title: clear
//argument: none
//purpose: clear everything in the list
//return: none
void CharLinkedList::clear(){
   while(front != nullptr){
    Node *temp = front;
    front = front->next; 
    delete temp; 
   }
   back = nullptr; 

}
//title: size
//argument: none
//purpose: iterates though list and iterates int variable to check size
//return: size of list 
int CharLinkedList::size()const{
    Node *temp = front;
    int count = 0;
    
    while(temp != nullptr){
        temp = temp->next; 
        count++; 
    }
    return count; 

}
//title: first
//argument: none
//purpose: returns first element of array, but throw error if the list is
//empty
//return: character element from list
char CharLinkedList::first() const{
    char answer; 
    if(front == nullptr){
        throw std::runtime_error("cannot get first of empty LinkedList" );
    } else{
        answer = front->data; 
        return answer;
    }   
}
//title: last
//argument: none
//purpose: returns last element of list and throws error if list is empty
//return: character element from list
char CharLinkedList::last() const{
    if(front == nullptr){
        throw std::runtime_error("cannot get last of empty LinkedList");
    } else { 
        return back->data; 
    }
}
//title: pushAtBack
//argument: character c
//purpose: places element that was passed in at the end of the list
//return: none
void CharLinkedList::pushAtBack(char c){
    Node *new_node = newNode(c, nullptr, nullptr);
    if(front == nullptr){
        front = new_node;
        back = new_node;
        numItems++; 
    }
    else{
        new_node->prev = back;
        back->next = new_node; 
        back = new_node; 
        numItems++;  
    }
}
//title: pushAtFront
//argument: character c
//purpose: places element that was passed in at the front of the list
//return: none
void CharLinkedList::pushAtFront(char c){
    Node *new_node = newNode(c, nullptr, nullptr);
    if(front == nullptr){
        front = new_node;
        back = new_node; 
        numItems++; 
    } else {
        Node *tempFront = front; 
        front = new_node; 
        tempFront->prev = front; 
        front->next = tempFront; 
        numItems++; 
    }   
}
//title: toString
//argument: none
//purpose: checks the size of list and contents in the list
//return: string 
std::string CharLinkedList::toString()const{
    Node *curr = front;
    string s;
    if(front == nullptr){
        return "[CharLinkedList of size 0 <<>>]";
    } else {
        while(curr != nullptr){
            s += curr->data; 
            curr = curr->next; 
        }
    }
    
    string answer = "[CharLinkedList of size " + to_string(numItems) + " <<" 
    +s
    + ">>]";
    return answer; 
}
//title: toReverseString
//argument: none
//purpose: to check size of list and display contents in the list in reverse
//return: string
std::string CharLinkedList::toReverseString() const{
    Node *curr = back;
    string s;
    if(front == nullptr){
        return "[CharLinkedList of size 0 <<>>]";
    } else {
        while(curr != nullptr){
            s += curr->data;
            curr = curr->prev; 
        }
    }
    string answer = "[CharLinkedList of size " + to_string(numItems) + " <<" 
    +s
    + ">>]";
    return answer; 
}
//title: elementAt
//argument: integer index
//purpose: return element at the given index
//return: character element from list at the index that was passed in
char CharLinkedList::elementAt(int index) const{ 
    if(index > numItems or index < 0 or front == nullptr 
    or index == numItems){
        string error;
        error= "index ("+to_string(index)+") not in range [0.."+
        to_string(numItems)+")";
        throw std::range_error(error);  
    } else {
        Node *new_node = recHelper(front, index);
        return new_node->data; 
    }
}
//title: removeAt
//argument: integer index 
//purpose: remove element from list at the specified index, throws 
//an error if 
// index is out of range 
//return: none
void CharLinkedList::removeAt(int index){ 
    if(index > numItems or index < 0 or front == nullptr 
    or index == numItems){
        string error;
        error= "index ("+to_string(index)+") not in range [0.."+
        to_string(numItems)+")";
        throw std::range_error(error);
    } else if (index == 0){
        popFromFront();
    } else if (index == numItems-1){
        popFromBack();
    } else {
        Node *curr = front;
        int count = 0;  
        while(curr != nullptr and count <= index-1){
            curr = curr->next;
            count ++;
        }
        if(curr->next != nullptr){
            curr->prev->next = curr->next;
            curr->next->prev = curr->prev; 
            delete curr; 
            numItems--; 
        }
    }
}
//title: replaceAt
//argument: character c and integer index
//purpose: to replace given character at the given index, throw error if 
//list is
// empty or if index is out of range 
//return: none
void CharLinkedList::replaceAt(char c, int index){ 
    if(index > numItems or index < 0 or front == nullptr 
    or index == numItems){
        string error;
        error= "index ("+to_string(index)+") not in range [0.."+
        to_string(numItems)+")";
        throw std::range_error(error);
    } else {
        Node *new_node = recHelper(front, index);
        new_node->data = c; 
    }
}
//title: insertAt
//argument: character c, and integer index
//purpose: to insert passed in element at the given index
//return: none
void CharLinkedList::insertAt(char c, int index){ 
    if(index > numItems or index < 0){
        string error;
        error= "index ("+to_string(index)+") not in range [0.."+
        to_string(numItems)+"]";
        throw std::range_error(error);  
    } else if(index == 0 or front == nullptr){
        pushAtFront(c);
    } else if(index == numItems){
        pushAtBack(c); 
    } else{
        Node *curr = front; 
        Node *new_node = newNode(c, nullptr, nullptr);
        int count = 0; 
        while(curr != nullptr and count < index-1){
          curr = curr->next; 
          count++; 
        }
        new_node->next = curr->next; 
        new_node->prev = curr; 
        curr->next = new_node;
        numItems++;  
    }   
}
//title: insertInorder
//argument: character c
//purpose: insert given character in ASCII order within the linkedlist
//return: none
void CharLinkedList::insertInOrder(char c){
    bool insert = false; 
    for(int i = 0; i < numItems; i++){
        if(c < elementAt(i) and not(insert)){ 
            insertAt(c, i); 
            insert = true; 
        }
    }
    if(not(insert)){
        pushAtBack(c); 
    }
}
//title: popFromFront
//argument: none
//purpose: remove the element from the the front of the list, throw error if
// the list is empty
//return: none
void CharLinkedList::popFromFront(){
    if(front == nullptr){
        throw std::runtime_error ("cannot pop from empty LinkedList");
    } else if(front == back){
        delete front;
        front = back = nullptr; 
    } else{
        Node *temp = front; 
        front = front->next; 
        delete temp; 
        front->prev = nullptr; 
        numItems--;
    }
}
//title: popFromBack
//argument: none
//purpose: remove the element from the back of the list, throw error if the
//list is empty
//return: none
void CharLinkedList::popFromBack(){
    if(front == nullptr){
       throw std::runtime_error ("cannot pop from empty LinkedList"); 
    } else if(front == back){
        delete front; 
        front = back = nullptr; 
    } else {
        Node *temp = back;
        back = back->prev;
        delete temp;
        back->next = nullptr; 
        numItems--; 
    }
}
//title: concatenate
//argument: instance of CharLinkedlist class
//purpose: add new character linked list to the end of another linked list
//return: none
void CharLinkedList::concatenate(CharLinkedList *other){
    int original = other->size();
    for(int i = 0; i < original; i++){
        pushAtBack(other->elementAt(i));
    }

}


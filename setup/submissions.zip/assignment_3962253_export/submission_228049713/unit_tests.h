/*
 *  unit_tests.h
 *  Rianna Liu
 *  1/3
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *   A testing file for your Doubly Character linked List class that uses
 *  the unit_test framework
 *
 */

#include "CharLinkedList.h"
#include <cassert>
#include <iostream>

// void print(){
//     std::cout << "test" << std::endl; 
// }


//testing the first constructor
void constructor1_test(){
    CharLinkedList list; 
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}
//testing the second constructor
void constructor2_test(){
    CharLinkedList list('a'); 
    assert(list.toString() == "[CharLinkedList of size 1 <<a>>]");
}
//testing the third constructor
void constructor3_test(){
    char arr[3] = {'a','b','b'};
    CharLinkedList list(arr, 3);
    assert(list.toString() == "[CharLinkedList of size 3 <<abb>>]");
}
//testing the fourth constructor
void constructor4_test(){ 
    char arr[3] = {'a','b','c'};
    CharLinkedList other(arr, 3);
    CharLinkedList list(other); 
    assert(list.toString() == "[CharLinkedList of size 3 <<abc>>]");
    other.pushAtBack('c'); 
    assert(list.toString() == "[CharLinkedList of size 3 <<abc>>]");
    assert(other.toString() == "[CharLinkedList of size 4 <<abcc>>]");
 }

// test if instance of list correctly copied over to my instance 
void operater_equalsTest(){
   char test_arr[8] = {'a','b','c','d','e','f','g','h'};
   CharLinkedList first_list(test_arr,8);
   CharLinkedList test_list;
   test_list = first_list; 
   assert(test_list.size() == 8);
   assert(test_list.toString() == 
   "[CharLinkedList of size 8 <<abcdefgh>>]");
}

//adjust the new instance of list and make sure that it doesn't alter the 
//original, pushing at the back
void operater_changeFirst_back(){
   char test_arr[8] = {'a','b','c','d','e','f','g','h'};
   CharLinkedList first_list(test_arr,8);
   CharLinkedList test_list;
   test_list = first_list;
   test_list.pushAtBack('a'); 
   assert(first_list.size() == 8); 
   assert(first_list.toString() == 
   "[CharLinkedList of size 8 <<abcdefgh>>]" );
}
//adjust the new instance of list and make sure that it doesn't alter the 
//original, pushing at the front
void operater_changeFirst_front(){
   char test_arr[8] = {'a','b','c','d','e','f','g','h'};
   CharLinkedList first_list(test_arr,8);
   CharLinkedList test_list;
   test_list = first_list;
   test_list.pushAtFront('a'); 
   assert(first_list.size() == 8); 
   assert(first_list.toString() ==
    "[CharLinkedList of size 8 <<abcdefgh>>]" );
}
//test for empty list
void isEmpty_test(){
    CharLinkedList list;
    assert(list.isEmpty());
}
//testing for non empty list
void isNotEmpty_test(){
    CharLinkedList list('a');
    assert(not(list.isEmpty()));
}
//testing for non empty list after element is added
void isEmptyAdd_test(){
    CharLinkedList list;
    assert(list.isEmpty());
    list.pushAtBack('a');
    assert(not(list.isEmpty()));
}
//testing if filled list is empty after being cleared
void isEmptyClear_test(){ 
    char arr[3] = {'a','b','b'};
    CharLinkedList list(arr, 3);
    list.clear();
    assert(list.isEmpty());
}
//test if clear function clears one element list
void clear_OneElementTest(){
    CharLinkedList list('a');
    list.clear();
    assert(list.isEmpty());
}
//see if clear function clear multiple element list
void clear_multipleElementTest(){
    char arr[3] = {'a','b','b'};
    CharLinkedList list(arr, 3);
    list.clear();
    assert(list.isEmpty());
}

//testing filling an empty array correclty
void pushAtBack_test(){
    CharLinkedList list;
    list.pushAtBack('a');
    list.pushAtBack('b');
    list.pushAtBack('c');
    assert(list.toString() == "[CharLinkedList of size 3 <<abc>>]");
}
// //filling empty list with one element
void pushAtBack_OneElementTest(){
    CharLinkedList list;
    list.pushAtBack('a'); 
    assert(list.toString() == "[CharLinkedList of size 1 <<a>>]");
}
// //test if list changes after adding an element
void pushAtBack_EmptyTest(){
    CharLinkedList list;
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
    list.pushAtBack('a');
    assert(list.toString() == "[CharLinkedList of size 1 <<a>>]");
    
}
// //test pushAtBack for adding to one element filled list
void pushAtBack_AddtoOneElementTest(){ //not passing
    CharLinkedList list('a');
    list.pushAtBack('b');
    assert(list.toString() == "[CharLinkedList of size 2 <<ab>>]");
}
// //test pushAtBack for adding multiple elements to one element list
void pushAtBack_AddManytoOne(){ //not passing 
    CharLinkedList list('a');
    list.pushAtBack('b');
    list.pushAtBack('c');
    assert(list.toString() == "[CharLinkedList of size 3 <<abc>>]");
}
//test pushAtBack for adding element to filled array
void pushAtBack_AddtoFilledTest(){
    char arr[3] = {'a','b','c'};
    CharLinkedList list(arr, 3);
    list.pushAtBack('c');
    assert(list.toString() == "[CharLinkedList of size 4 <<abcc>>]");
}
//test pushAtBack for adding multiple elements to filled array
void pushAtBack_AddManytoFilledTest(){
    char arr[3] = {'a','b','c'};
    CharLinkedList list(arr, 3);
    list.pushAtBack('c');
    list.pushAtBack('d');
    assert(list.toString() == "[CharLinkedList of size 5 <<abccd>>]");
}
//test pushAtFront for adding multiple elements 
void pushAtFront_test(){ 
    CharLinkedList list;
    list.pushAtFront('a');
    list.pushAtFront('b');
    list.pushAtFront('c');
    assert(list.toString() == "[CharLinkedList of size 3 <<cba>>]");
}
//test pushAtFront for adding one element
void pushAtFront_OneElementTest(){
    CharLinkedList list; 
    list.pushAtFront('a');
    assert(list.toString() == "[CharLinkedList of size 1 <<a>>]");
}
//test pushAtFront for adding to one element filled list
void pushAtFront_AddtoOneElementTest(){
    CharLinkedList list('a');
    list.pushAtFront('b');
    assert(list.toString() == "[CharLinkedList of size 2 <<ba>>]");
}
//test pushAtFront for adding element to filled array
void pushAtFront_AddtoFilledTest(){
    char arr[3] = {'a','b','c'};
    CharLinkedList list(arr, 3);
    list.pushAtFront('c');
    assert(list.toString() == "[CharLinkedList of size 4 <<cabc>>]");
}
//test pushAtFront for adding multiple elements to filled array
void pushAtFront_AddManytoFilledTest(){
    char arr[3] = {'a','b','c'};
    CharLinkedList list(arr, 3);
    list.pushAtFront('c');
    list.pushAtFront('d');
    assert(list.toString() == "[CharLinkedList of size 5 <<dcabc>>]");
}
//test pushAtBack for adding multiple elements to one element list
void pushAtFront_AddManytoOne(){
    CharLinkedList list('a');
    list.pushAtFront('b');
    list.pushAtFront('c');
    assert(list.toString() == "[CharLinkedList of size 3 <<cba>>]");
}
//testing if size returns 0 for default constructor
void size_Emptytest(){
    CharLinkedList list;
    assert(list.size() == 0);
}
//testing if size returns 1 for one element list
void size_OneElementSizeTest(){
    CharLinkedList list('a');
    assert(list.size()==1);
}
//testing if size returns 1 for many element list
void size_ManyElementSizeTest(){
    char arr[3] = {'a','b','c'};
    CharLinkedList list(arr, 3);
    assert(list.size() == 3);
}
//testing if reverse string returns default display for empty list
void reverse_Emptytest(){
    CharLinkedList list;
    assert(list.toReverseString() == "[CharLinkedList of size 0 <<>>]");
}
//reverse string should display one element and correct character
void reverse_OneElementTest(){
    CharLinkedList list('a');
    assert(list.toReverseString() == "[CharLinkedList of size 1 <<a>>]");
}
//reverse string should display 3 element and correct characters in reverse
//order
void reverse_MultiElementTest(){ 
    char arr[3] = {'a','b','c'};
    CharLinkedList list(arr, 3); 
    assert(list.toReverseString() == "[CharLinkedList of size 3 <<cba>>]");
}
//testing reverse string with pushAtBack
void reverse_pushAtBackTest(){
    CharLinkedList list('a');
    assert(list.toReverseString() == "[CharLinkedList of size 1 <<a>>]");
    list.pushAtBack('b');
    list.pushAtBack('c');
    assert(list.toReverseString() == "[CharLinkedList of size 3 <<cba>>]");
}
//testing reverse string with pushAtFront
void reverse_pushAtFrontTest(){
    CharLinkedList list('a');
    assert(list.toReverseString() == "[CharLinkedList of size 1 <<a>>]");
    list.pushAtFront('b');
    list.pushAtFront('c');
    assert(list.toReverseString() == "[CharLinkedList of size 3 <<abc>>]");
}
//testing if first returns error for empty list
void first_EmptyTest(){
    CharLinkedList list; 
    bool runtime_error_thrown = false;
    std::string error_message = "";
    try{
        list.first();
    } catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "cannot get first of empty LinkedList");
}
//if first returns the only value in one element list
void first_OneElementTest(){
    CharLinkedList list('a');
    assert(list.first() == 'a');
}
//if first returns first value in a many element list
void first_ManyElementTest(){
    char arr[3] = {'a','b','c'};
    CharLinkedList list(arr, 3);
    assert(list.first() == 'a');
}
//if first works with pushAtback
void first_pushAtBackTest(){ 
    CharLinkedList list('a');
    assert(list.first() == 'a');
    list.pushAtBack('b');
    list.pushAtBack('c');
    assert(list.size() == 3); 
    assert(list.first() == 'a');
}
//if first works with pushAtFront
void first_pushAtFrontTest(){
    CharLinkedList list('a');
    assert(list.first() == 'a');
    list.pushAtFront('b');
    list.pushAtFront('c');
    assert(list.size() == 3); 
    assert(list.first() == 'c');
}
//testing if last returns error for empty list
void last_EmptyTest(){
    CharLinkedList list; 
    bool runtime_error_thrown = false;
    std::string error_message = "";
    try{
        list.last();
    } catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "cannot get last of empty LinkedList");
}
//if last returns the only value in one element list
void last_OneElementTest(){
    CharLinkedList list('a');
    assert(list.last() == 'a');
}
//if last returns last value in a many element list
void last_ManyElementTest(){ 
    char arr[3] = {'a','b','c'};
    CharLinkedList list(arr, 3);
    assert(list.last() == 'c');
}
//if last works with pushAtBack
void last_pushAtBackTest(){ 
    CharLinkedList list('a');
    assert(list.last() == 'a');
    list.pushAtBack('b');
    list.pushAtBack('c');
    assert(list.size() == 3); 
    assert(list.last() == 'c');
}
//if last works with pushAtFront
void last_pushAtFrontTest(){ 
    CharLinkedList list('a');
    assert(list.last() == 'a');
    list.pushAtFront('b');
    list.pushAtFront('c');
    assert(list.size() == 3); 
    assert(list.last() == 'a');
}
//check if  insertAt throw error if index is negative 
void insertAt_NegIndexTest(){ 
    CharLinkedList list; 
    bool range_error_thrown = false;
    std::string error_message = "";
    try{
        list.insertAt('c',-1);
    } catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (-1) not in range [0..0]");
}
// Tests correct insertion into an empty AL.
// Afterwards, size should be 1 and element at index 0
// should be the element we inserted.
void insertAt_empty_correct() { 
    CharLinkedList test_list;
    test_list.insertAt('a', 0);
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');
}
// Tests incorrect insertion into an empty AL.
// Attempts to call insertAt for index larger than 0.
// This should result in an std::range_error being raised.
void insertAt_empty_incorrect() {  
    bool range_error_thrown = false;
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
    range_error_thrown = true;
    error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0]");    
}
//Tests correct insertAt for front of 1-element list.
void insertAt_front_singleton_list() { //not passing

    CharLinkedList test_list('a');
    test_list.insertAt('b', 0);
    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'a');
    
}
//Tests correct insertAt for back of 1-element list.
void insertAt_back_singleton_list() {
    CharLinkedList test_list('a');
    test_list.insertAt('b', 1);
    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    
}
// // Tests calling insertAt for a large number of elements.
// // Not only does this test insertAt, it also checks that
// // array expansion works correctly.
void insertAt_many_elements() { 
    CharLinkedList test_list;
    for (int i = 0; i < 1000; i++) {
        test_list.insertAt('a', i);
    }
    assert(test_list.size() == 1000);
    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }    
}

// Tests insertion into front of a larger list
void insertAt_front_large_list() {
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);
    test_list.insertAt('y', 0);
    assert(test_list.size() == 10);
    assert(test_list.elementAt(0) == 'y');
    assert(test_list.toString() ==
    "[CharLinkedList of size 10 <<yabczdefgh>>]");

}

// // Tests insertion into the back of a larger list
void insertAt_back_large_list() { 

    char test_arr[10] = { 'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 10);  
    test_list.insertAt('x', 10);
    assert(test_list.size() == 11);
    assert(test_list.elementAt(10) == 'x');
    assert(test_list.toString() == 
    "[CharLinkedList of size 11 <<yabczdefghx>>]"); 
}

// // Tests insertion into the middle of a larger list
void insertAt_middle_large_list() {  
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);
    test_list.insertAt('z', 3);
    assert(test_list.size() == 9);
    assert(test_list.elementAt(3) == 'z');
    assert(test_list.toString()=="[CharLinkedList of size 9 <<abczdefgh>>]");

}

// // Tests out-of-range insertion for a non-empty list.
void insertAt_nonempty_incorrect() {
   
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);
    bool range_error_thrown = false;
    std::string error_message = "";
    try {
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8]");    
}
//tests if elementAt throw error if integer is negative 
void elementAt_NegIndexTest(){ 
    CharLinkedList list; 
    bool range_error_thrown = false;
    std::string error_message = "";
    try{
        list.insertAt('c',-1);
    } catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (-1) not in range [0..0]");
}
//tests if elementAt throws error at the same index number 
void elementAt_sameIndex(){
    bool range_error_thrown = false;
    std::string error_message = "";
    char arr[6] = {'a','b','c','d','e','f'};
    CharLinkedList test_list(arr, 6);
    try {
    test_list.elementAt(6);
    }
    catch (const std::range_error &e) {
    range_error_thrown = true;
    error_message = e.what();
    } 
    assert(range_error_thrown);
    assert(error_message == "index (6) not in range [0..6)"); 
}

//tests if elementAt throws error if list is empty
void elementAt_emptyTest(){
    bool range_error_thrown = false;
    std::string error_message = "";
    CharLinkedList test_list;
    try {
    test_list.elementAt(42);
    }
    catch (const std::range_error &e) {
    range_error_thrown = true;
    error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0)");  
}
//tests if elementAt throws error if integer is out of range
void elementAt_outOfRangeTest(){
    bool range_error_thrown = false;
    std::string error_message = "";
    CharLinkedList test_list('a');
    try {
    test_list.elementAt(42);
    }
    catch (const std::range_error &e) {
    range_error_thrown = true;
    error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..1)");  
}
// test elementAt return index in one element list
void elementAt_OneElementTest(){
    CharLinkedList list('c');
    assert(list.elementAt(0) == 'c');
}
//tests elementAt in a multi element test, checking if it return the first
//value
void elementAt_MultiElementTest_Front(){
    char arr[3] = {'a','b','c'};
    CharLinkedList list(arr, 3);
    assert(list.elementAt(0) == 'a');
}
//tests elementAt in a multi element test, checking if it return the middle
//value
void elementAt_MultiElementTest_Middle(){
    char arr[3] = {'a','b','c'};
    CharLinkedList list(arr, 3);
    assert(list.elementAt(1) == 'b');
}
//tests elementAt in a multi element test, checking if it return the last
//value
void elementAt_MultiElementTest_Last(){
    char arr[4] = {'a','b','c','d'};
    CharLinkedList list(arr, 4);
    assert(list.elementAt(3) == 'd');
}
//test if popFromFront throw error in empty list
void popFromFront_EmptyTest(){
    bool runtime_error_thrown = false;
    std::string error_message = "";
    CharLinkedList test_list;
    try {
    test_list.popFromFront();
    }
    catch (const std::runtime_error &e) {
    runtime_error_thrown = true;
    error_message = e.what();
    }
    assert(runtime_error_thrown); 
}
//if popFromFront returns default display with list is has one element
void popFromFront_OneElementTest(){
    CharLinkedList list('c');
    list.popFromFront();
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}
//tests popFromFront in a multiple element list
void popFromFront_ManyElementTest(){
    char arr[3] = {'a','b','c'};
    CharLinkedList list(arr, 3);
    list.popFromFront();
    assert(list.toString() == "[CharLinkedList of size 2 <<bc>>]");
}
//test popFromFront with insertAt inserting element at the beginning of list
void popFromFront_insertAtFrontTest(){
    char arr[6] = {'a','b','c','d','e','f'};
    CharLinkedList list(arr, 6);
    list.insertAt('a', 0); 
    assert(list.toString() == "[CharLinkedList of size 7 <<aabcdef>>]");
    list.popFromFront();
    assert(list.toString() == "[CharLinkedList of size 6 <<abcdef>>]");
}
//test popFromFront with insertAt inserting element at the middle of list
void popFromFront_insertAtMidTest(){
    char arr[6] = {'a','b','c','d','e','f'};
    CharLinkedList list(arr, 6);
    list.insertAt('z', 3); 
    assert(list.toString() == "[CharLinkedList of size 7 <<abczdef>>]");
    list.popFromFront();
    assert(list.toString() == "[CharLinkedList of size 6 <<bczdef>>]");
}
//test popFromFront with insertAt inserting element at the back of list
void popFromFront_insertAtBackTest(){
    char arr[6] = {'a','b','c','d','e','f'};
    CharLinkedList list(arr, 6);
    list.insertAt('g', 6); 
    assert(list.toString() == "[CharLinkedList of size 7 <<abcdefg>>]");
    list.popFromFront();
    assert(list.toString() == "[CharLinkedList of size 6 <<bcdefg>>]");
}
//test if popFromFront throw error in empty list 
void popFromBack_EmptyTest(){
    bool runtime_error_thrown = false;
    std::string error_message = "";
    CharLinkedList test_list;
    try {
    test_list.popFromBack();
    }
    catch (const std::runtime_error &e) {
    runtime_error_thrown = true;
    error_message = e.what();
    }
    assert(runtime_error_thrown); 
}
//if popFromFront returns default display with list is has one element
void popFromBack_OneElementTest(){
    CharLinkedList list('c');
    list.popFromBack();
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}
//tests popFromFront with a multiple element list
void popFromBack_ManyElementTest(){
    char arr[3] = {'a','b','c'};
    CharLinkedList list(arr, 3);
    list.popFromBack();
    //std::cout << list.toString() << std::endl; 
    assert(list.toString() == "[CharLinkedList of size 2 <<ab>>]");
}
//test popFromFront with insertAt inserting element at the front of list
void popFromBack_insertAtFrontTest(){
    char arr[6] = {'a','b','c','d','e','f'};
    CharLinkedList list(arr, 6);
    list.insertAt('a', 0); 
    assert(list.toString() == "[CharLinkedList of size 7 <<aabcdef>>]");
    list.popFromBack();
    assert(list.toString() == "[CharLinkedList of size 6 <<aabcde>>]");
}
//test popFromFront with insertAt inserting element at the middle of list
void popFromBack_insertAtMidTest(){
    char arr[6] = {'a','b','c','d','e','f'};
    CharLinkedList list(arr, 6);
    list.insertAt('z', 3); 
    assert(list.toString() == "[CharLinkedList of size 7 <<abczdef>>]");
    list.popFromBack();
    assert(list.toString() == "[CharLinkedList of size 6 <<abczde>>]");
}
//test popFromFront with insertAt inserting element at the back of list
void popFromBack_insertAtBackTest(){
    char arr[6] = {'a','b','c','d','e','f'};
    CharLinkedList list(arr, 6);
    list.insertAt('g', 6); 
    assert(list.toString() == "[CharLinkedList of size 7 <<abcdefg>>]");
    list.popFromBack();
    assert(list.toString() == "[CharLinkedList of size 6 <<abcdef>>]");
}
//testing removeAt throws error if index is negative
void removeAt_NegIndexTest(){
    bool range_error_thrown = false;
    std::string error_message = "";
    CharLinkedList test_list;
    try {
    test_list.removeAt(-3);
    }
    catch (const std::range_error &e) {
    range_error_thrown = true;
    error_message = e.what();
    } 
    assert(range_error_thrown);
    assert(error_message == "index (-3) not in range [0..0)");   
}
//testing removeAt throws error if list is empty
void removeAt_emptyTest(){
    bool range_error_thrown = false;
    std::string error_message = "";
    CharLinkedList test_list;
    try {
    test_list.removeAt(42);
    }
    catch (const std::range_error &e) {
    range_error_thrown = true;
    error_message = e.what();
    } 
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0)"); 
}
//tests if removeAt throws error at the same index number 
void removeAt_sameIndex(){
    bool range_error_thrown = false;
    std::string error_message = "";
    char arr[6] = {'a','b','c','d','e','f'};
    CharLinkedList test_list(arr, 6);
    try {
    test_list.removeAt(6);
    }
    catch (const std::range_error &e) {
    range_error_thrown = true;
    error_message = e.what();
    } 
    assert(range_error_thrown);
    assert(error_message == "index (6) not in range [0..6)"); 
}
//testing removeAt with one element list
void removeAt_OneElementTest(){
    CharLinkedList list('a');
    list.removeAt(0);
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}
//testing removeAt with many element list, but removes front value
void removeAt_ManyElementTest_First(){
    char arr[6] = {'a','b','c','d','e','f'};
    CharLinkedList list(arr, 6);
    list.removeAt(0);
    assert(list.toString() == "[CharLinkedList of size 5 <<bcdef>>]");
}
//testing removeAt with many element list, but removes middle value
void removeAt_ManyElementTest_Middle(){
    char arr[6] = {'a','b','c','d','e','f'};
    CharLinkedList list(arr, 6);
    list.removeAt(3);
    assert(list.toString() == "[CharLinkedList of size 5 <<abcef>>]");
}
//testing removeAt with many element list, but removes last value
void removeAt_ManyElementTest_Last(){
    char arr[6] = {'a','b','c','d','e','f'};
    CharLinkedList list(arr, 6);
    list.removeAt(5);
    //std::cerr << list.toString() << std::endl; 
    assert(list.toString() == "[CharLinkedList of size 5 <<abcde>>]");
    
} 
//testing replaceAt throws error if index is negative
void replaceAt_NegIndexTest(){ 
    bool range_error_thrown = false;
    std::string error_message = "";
    CharLinkedList test_list;
    try {
    test_list.replaceAt('a', -3);
    }
    catch (const std::range_error &e) {
    range_error_thrown = true;
    error_message = e.what();
    } 
    assert(range_error_thrown);
    assert(error_message == "index (-3) not in range [0..0)"); 
}
//tests if replaceAt throws error at the same index number 
void replaceAt_sameIndex(){
    bool range_error_thrown = false;
    std::string error_message = "";
    char arr[6] = {'a','b','c','d','e','f'};
    CharLinkedList test_list(arr, 6);
    try {
    test_list.replaceAt('a', 6);
    }
    catch (const std::range_error &e) {
    range_error_thrown = true;
    error_message = e.what();
    } 
    assert(range_error_thrown);
    assert(error_message == "index (6) not in range [0..6)"); 
}
//testing replaceAt throws error if index is out of range
void replaceAt_OutofRangeFill(){
    bool range_error_thrown = false;
    std::string error_message = "";
    CharLinkedList test_list('c');
    try {
    test_list.replaceAt('a', 30);
    }
    catch (const std::range_error &e) {
    range_error_thrown = true;
    error_message = e.what();
    } 
    assert(range_error_thrown);
    assert(error_message == "index (30) not in range [0..1)"); 
}
//testing replaceAt throws error if list is empty
void replaceAt_emptyTest(){
    bool range_error_thrown = false;
    std::string error_message = "";
    CharLinkedList test_list;
    try {
    test_list.replaceAt('a',42);
    }
    catch (const std::range_error &e) {
    range_error_thrown = true;
    error_message = e.what();
    }; 
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0)"); 
}
//testing replaceAt with one element
void replaceAt_OneElementTest(){ 
    CharLinkedList list('a');
    list.replaceAt('Z', 0);
    assert(list.toString() == "[CharLinkedList of size 1 <<Z>>]");
}
//testing replaceAt with many element filled list, but value should be at the
//front
void replaceAt_ManyElementTest_First(){ 
    char arr[6] = {'a','b','c','d','e','f'};
    CharLinkedList list(arr, 6);
    list.replaceAt('Z', 0);
    assert(list.toString() == "[CharLinkedList of size 6 <<Zbcdef>>]");
}
//testing replaceAt with many element filled list, but value should be at the
//middle
void replaceAt_ManyElementTest_Middle(){
    char arr[6] = {'a','b','c','d','e','f'};
    CharLinkedList list(arr, 6);
    list.replaceAt('Z',3);
    assert(list.toString() == "[CharLinkedList of size 6 <<abcZef>>]");
}
//testing replaceAt with many element filled list, but value should be at the
//end
void replaceAt_ManyElementTest_Last(){
    char arr[6] = {'a','b','c','d','e','f'};
    CharLinkedList list(arr, 6);
    list.replaceAt('Z', 5);
    assert(list.toString() == "[CharLinkedList of size 6 <<abcdeZ>>]");
} 
//testing if insertInOrder places value in empty list
void insertInOrder_EmptyTest(){ 
    CharLinkedList list;
    list.insertInOrder('a'); 
    assert(list.toString() == "[CharLinkedList of size 1 <<a>>]"); 
}
//testing if insertInOrder places value in one element list, but at the end
void insertInOrder_OneElementTest_After(){ 
    CharLinkedList list('a');
    list.insertInOrder('b'); 
    assert(list.toString() == "[CharLinkedList of size 2 <<ab>>]");
}
//testing if insertInOrder places value in one element list, but at the first
//spot
void insertInOrder_OneElementTest_Before(){
    CharLinkedList list('b');
    list.insertInOrder('a');
    assert(list.toString() == "[CharLinkedList of size 2 <<ab>>]");
}
//testing if insertInOrder places value in many element list, but at the end
void insertInOrder_ManyElementTest_After(){
    char arr[6] = {'a','b','c','d','e','f'};
    CharLinkedList list(arr, 6);
    list.insertInOrder('g');
    assert(list.toString() == "[CharLinkedList of size 7 <<abcdefg>>]");
}
//testing if insertInOrder places value in many element list, but at the 
//middle
void insertInOrder_ManyElementTest_Middle(){
    char arr[6] = {'a','b','c','x','y','z'};
    CharLinkedList list(arr, 6);
    list.insertInOrder('d');
    assert(list.toString() == "[CharLinkedList of size 7 <<abcdxyz>>]");
}
//testing if insertInOrder places value in many element list, but at the
//beginning
void insertInOrder_ManyElementTest_Before(){
    char arr[6] = {'b','c','d','e','f','g'};
    CharLinkedList list(arr, 6);
    list.insertInOrder('a'); 
    assert(list.toString() == "[CharLinkedList of size 7 <<abcdefg>>]");
}
//check if test concatenates two empty lists together
void concatenate_emptyTest1(){
    CharLinkedList list;
    CharLinkedList list1; 
    list.concatenate(&list1);
    assert(list.isEmpty()); 
}
//check if test concatenates two one element lists together
void concatenate_emptyTest(){
    CharLinkedList list('a');
    CharLinkedList list1('b'); 
    list.concatenate(&list1);
    assert(list.toString() == "[CharLinkedList of size 2 <<ab>>]"); 
}
//check if test concatenates empty list to one element list
void concatenate_emptyTestWithOne(){
    CharLinkedList list;
    CharLinkedList list1('b'); 
    list.concatenate(&list1);
    assert(list.toString() == "[CharLinkedList of size 1 <<b>>]"); 
}
//check if test concatenates one element list to empty list
void concatenate_OneWithEmptyTest(){
    CharLinkedList list('a');
    CharLinkedList list1; 
    list.concatenate(&list1);
    assert(list.toString() == "[CharLinkedList of size 1 <<a>>]"); 
}
//check if test concatenates empty test to a filled array
void concatenate_EmptyTestWithFilled(){
    char array[3] = {'b','c','d'};
    CharLinkedList list(array, 3);
    CharLinkedList list1; 
    list.concatenate(&list1);
    assert(list.toString() == "[CharLinkedList of size 3 <<bcd>>]"); 
}
//check if test concatenates filled array to empty list
void concatenate_FilledWithEmptyTest(){ 
    char array[3] = {'b','c','d'};
    CharLinkedList list(array, 3);
    CharLinkedList list1; 
    list1.concatenate(&list);
    assert(list1.toString() == "[CharLinkedList of size 3 <<bcd>>]"); 
}
//check if different linked lists are concatenating together 
void concatenate_diffArray(){
    char array[3] = {'a','b','c'};
    CharLinkedList list(array, 3);
    char array1[4] = {'d','e','f', 'g'};
    CharLinkedList list1(array1, 4);
    list.concatenate(&list1); 
    assert(list.toString() == "[CharLinkedList of size 7 <<abcdefg>>]");
}
//check if same linkedlist are concatenating together
void concatenate_sameContentArray(){
    char array[3] = {'a','b','c'};
    CharLinkedList list(array, 3);
    char array1[3] = {'a','b','c'};
    CharLinkedList list1(array1, 3);
    list.concatenate(&list1); 
    assert(list.toString() == "[CharLinkedList of size 6 <<abcabc>>]");  
}
//check if linked list can concatenate itself 
void concatenate_itself(){
    char array[3] = {'a','b','c'};
    CharLinkedList list(array, 3);
    list.concatenate(&list); 
    assert(list.toString() == "[CharLinkedList of size 6 <<abcabc>>]");  
}


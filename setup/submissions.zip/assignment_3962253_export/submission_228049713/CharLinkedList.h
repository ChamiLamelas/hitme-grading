/*
 *  CharLinkedList.h
 *  Rianna Liu
 *  1/31/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Interface for Doubly CharLinkedList homework.
 *
 */

#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H
#include <string>
#include<stdio.h>
#include<stdlib.h>


class CharLinkedList {
public:
    //constructors
    CharLinkedList(); //passed
    CharLinkedList(char c); //passed
    CharLinkedList(char arr[], int size); //passed
    CharLinkedList(const CharLinkedList &other); //passed

    //destructor
    ~CharLinkedList(); //done

    //functions
    CharLinkedList &operator=(const CharLinkedList &other); //passed
    bool isEmpty() const; //passed
    void clear(); // passed
    int size() const; //passed
    char first() const; //passed
    char last() const; //passed
    char elementAt(int index) const; //passed
    std::string toString() const; //passed
    std::string toReverseString() const; //passed
    void pushAtBack(char c); //passed
    void pushAtFront(char c); //passed
    void insertAt(char c, int index); //passed
    void insertInOrder(char c); //passed
    void popFromFront(); //passed
    void popFromBack(); //passed
    void removeAt(int index); //passed
    void replaceAt(char c, int index); // some tests failing
    void concatenate(CharLinkedList *other); //passed

private:
    struct Node{
        char data;
        struct Node* next; 
        struct Node* prev; 

    };

    Node *front;
    Node *back;
    int numItems; 

    Node *newNode(char newData, Node *next, Node *prev);
    Node *recHelper(Node *curr, int index) const; 
    void recHelperDelete (Node *curr);

#endif
};
/*
 *  CharLinkedList.h
 *  Elki Laranas
 *  2/5/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  CharLinkedList is a class that represents an ordered list of characters. 
 *  A new CharLinkedList can begin empty, or can be a copy of an array of
 *  characters or an existing CharLinkedList. Clients can add and remove
 *  characters from the list and perform other functions on it, such as
 *  list concatenation.
 *
 */


#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H
#include <string>

class CharLinkedList {
public:
    CharLinkedList();
    CharLinkedList(char c);
    CharLinkedList(char arr[], int size);
    CharLinkedList(const CharLinkedList &other);
    
    ~CharLinkedList();
    CharLinkedList &operator=(const CharLinkedList &other);

    bool isEmpty() const;
    void clear();
    int size() const;

    char first() const;
    char last() const;
    char elementAt(int index) const;

    std::string toString() const;
    std::string toReverseString() const;

    void pushAtBack(char c);
    void pushAtFront(char c);

    void insertAt(char c, int index);
    void insertInOrder(char c);

    void popFromFront();
    void popFromBack();

    void removeAt(int index);
    void replaceAt(char c, int index);

    void concatenate(CharLinkedList* other);       
        
private:
    struct Node {
        char data;
        Node *next, *previous;
    };

    // helper function for node creation
    Node *new_node(char c, Node *next) {
        Node *new_node = new Node;
        new_node->data = c;
        new_node->next = next;
        new_node->previous = nullptr;
        return new_node;
    }

    // recursive helper function for insertion and deletion
    Node *traverse_until(int index, Node *curr_node) const {
        // base case: return current node if "index" is 0, meaning distance
        // away from correct node is 0 nodes
        if (index == 0) {
            return curr_node;
        }
        // recursive case: recall the function but subtract index by 1, and
        // use the next node as the new current node
        return traverse_until(index - 1, curr_node->next);
    }

    // recursive helper function for destructor
    void destroy_list(Node* head) {
        // destroys the list from back to front
        if (head != nullptr) {
            destroy_list(head->next);
            delete head;
        }
    }

    Node* front;
    int currSize;
};

#endif

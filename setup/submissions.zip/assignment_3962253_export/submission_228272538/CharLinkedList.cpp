/*
 *  CharLinkedList.cpp
 *  Elki Laranas
 *  2/5/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Implementation of the LinkedList interface
 *
 */

#include "CharLinkedList.h"
#include <stdexcept>

/*
* name: CharLinkedList
* purpose: initializes an empty CharLinkedList whose front pointer is null
*          and size is 0
* arguments: n/a
* returns: n/a
* effects: initializes a CharLinkedList object
*/
CharLinkedList::CharLinkedList() {
    front = nullptr;
    currSize = 0;
}

/*
* name: CharLinkedList
* purpose: initializes a CharLinkedList comprising one character node
* arguments: a character c representing the data to be added to the single node
* returns: n/a
* effects: initializes a CharLinkedList, pushes one node to the heap
*/
CharLinkedList::CharLinkedList(char c) {
    front = nullptr;
    currSize = 0;
    pushAtFront(c);
}

/*
* name: CharLinkedList
* purpose: initializes a CharLinkedList and populates it with characters from
*          an array
* arguments: an array of characters arr[] and an integer size, which is the
*            size of the array arr[]
* returns: n/a
* effects: initializes a CharLinkedList object and pushes a node to the heap
*          [size] times
*/
CharLinkedList::CharLinkedList(char arr[], int size) {
    front = nullptr;
    currSize = 0;
    // add each character in the array to the front, in reverse
    for (int i = size - 1; i >= 0; i--) {
        pushAtFront(arr[i]);
    }
}

/*
* name: CharLinkedList
* purpose: creates a copy of an CharLinkedList using another CharLinkedList
* arguments: address of another CharLinkedList
* returns: n/a
* effects: uses the overloaded assign operator to 
*          initialize a new CharLinkedList
*/
CharLinkedList::CharLinkedList(const CharLinkedList &other) {
    front = nullptr;
    currSize = 0;

    // pushAtBack all data in the rhs
    Node *curr_node = other.front;
    while (curr_node != nullptr) {
        pushAtBack(curr_node->data);
        curr_node = curr_node->next;
    }
}

/*
* name: ~CharLinkedList
* purpose: destroys the CharLinkedList using a recursive helper function
* arguments: n/a
* returns: n/a
* effects: frees the CharLinkedList's memory from the heap recursively
*/
CharLinkedList::~CharLinkedList() {
    destroy_list(front);
}

/*
* name: operator=
* purpose: redefines the = operator for CharLinkedList objects
* arguments: a pointer to another CharLinkedList
* returns: n/a
* effects: allows for a "deep copy" of a CharLinkedList
*/
CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other) {
    if (this == &other) {
        return *this;
    }
    
    if (not isEmpty()) {
        clear();
    }
    // initialize default values so that pushAtBack works
    front = nullptr;
    currSize = 0;

    // pushAtBack all data in the rhs
    Node *curr_node = other.front;
    while (curr_node != nullptr) {
        pushAtBack(curr_node->data);
        curr_node = curr_node->next;
    }
    return *this;
}


/*
* name: isEmpty
* purpose: determine if the CharLinkedList is empty or not
* arguments: n/a
* returns: a boolean value of true or false
* effects: n/a
*/
bool CharLinkedList::isEmpty() const {
    return currSize == 0;
}

/*
* name: clear
* purpose: deletes all nodes in the CharLinkedList and frees memory stored on
*          the heap
* arguments: n/a
* returns: n/a
* effects: frees all memory taken up by the CharLinkedList's nodes, sets size
*          to 0
*/
void CharLinkedList::clear() {
    if (isEmpty()) {
        return;
    }

    Node *curr_node = front;
    Node *temp_node;
    
    // traverse to the back of the list
    while(curr_node->next != nullptr) {
        curr_node = curr_node->next;
    }

    // until the front is reached, traverse backwards w/ previous and delete
    // each node
    while(curr_node != front) {
        temp_node = curr_node->previous;
        delete curr_node;
        curr_node = temp_node;
    }
    delete front;
    front = nullptr;
    currSize = 0;
}

/*
* name: size
* purpose: getter function for the size of the CharLinkedList
* arguments: n/a
* returns: an integer currSize representing the number of nodes in the list
* effects: n/a
*/
int CharLinkedList::size() const {
    return currSize;
}

/*
* name: first
* purpose: gets the data of the front node of the CharLinkedList
* arguments: n/a
* returns: the character held in the data variable of the front node
* effects: raises an error if the CharLinkedList is empty
*/
char CharLinkedList::first() const {
    if (isEmpty()) {
        throw std::runtime_error("cannot get first of empty LinkedList");
    }
    // simply return the first node's data
    return front->data;
}

/*
* name: last
* purpose: gets the data of the last node of the CharLinkedList
* arguments: n/a
* returns: the character held in the data variable of the back node
* effects: raises an error if the CharLinkedList is empty
*/
char CharLinkedList::last() const {
    if (isEmpty()) {
        throw std::runtime_error("cannot get last of empty LinkedList");
    }
    Node *curr_node = front;

    // traverse the list until the next node is nullptr, meaning the back has
    // been reached
    return (elementAt(currSize - 1));
}

/*
* name: elementAt
* purpose: retrieves the data of a node at a specified index
* arguments: an integer index representing the position in the list to retrieve
*            data from
* returns: a character corresponding to the data of the node at position index
* effects: raises an error if the index is out of bounds of the list size
*/
char CharLinkedList::elementAt(int index) const {
    if (index >= currSize or index < 0) {
        throw std::range_error("index (" + std::to_string(index) +
            ") not in range [0.." + std::to_string(currSize) + ")");
    }
    return traverse_until(index, front)->data;
}

/*
* name: toString
* purpose: converts the CharLinkedList's data to a string and formats it 
* arguments: n/a
* returns: a formatted string with the CharLinkedList's size and the
*          ordered contents of each node
* effects: n/a
*/
std::string CharLinkedList::toString() const {
    std::string result = "[CharLinkedList of size ";
    result += std::to_string(currSize) + " <<";

    // only go through this if the list is populated
    if (not isEmpty()) {
        
        Node *curr_node = front;

        // add each node's data to resultuntil the back node is reached
        while (curr_node != nullptr) {
            result += curr_node->data;
            curr_node = curr_node->next;
        }
    }
    result += ">>]";
    return result;
}

/*
* name: toReverseString
* purpose: converts the reverse of the CharLinkedList's data to a string and 
*          formats it 
* arguments: n/a
* returns: a formatted string with the CharLinkedList's size and the
*          ordered contents of each node, but in reverse order
* effects: n/a
*/
std::string CharLinkedList::toReverseString() const {

    std::string result = "[CharLinkedList of size ";
    result += std::to_string(currSize) + " <<";

    // only go through this if the list is populated
    if (not isEmpty()) {

        Node *curr_node = front;
        Node *temp_node;

        // traverse to the back of the list
        while(curr_node->next != nullptr) {
            curr_node = curr_node->next;
        }

        // same process as the clear function, but add data to result instead
        while(curr_node != front) {
            temp_node = curr_node->previous;
            result += curr_node->data;
            curr_node = temp_node;
        }
        result += front->data;
    }

    result += ">>]";
    return result;
}

/*
* name: pushAtFront
* purpose: adds a new node to the front of the CharLinkedList whose data is set
*          to an argued character
* arguments: a character c representing the data contained in the added node
* returns: n/a
* effects: increments size by 1
*/
void CharLinkedList::pushAtFront(char c) {
    Node *old_front = front;
    front = new_node(c, old_front);

    // if this is not the last item in the list, set the next node's previous
    // pointer to the added node
    if (front->next != nullptr) {
        front->next->previous = front;
    }
    currSize++;
}

/*
* name: pushAtBack
* purpose: adds a new node to the back of the CharLinkedList whose data is set
*          to an argued character
* arguments: a character c representing the data contained in the added node
* returns: n/a
* effects: increments size by 1
*/
void CharLinkedList::pushAtBack(char c) {

    if (isEmpty()) {
        pushAtFront(c);
        return;
    }

    // create a new node with the given character and a nullptr next pointer
    Node *addition = new_node(c, nullptr);
    Node *curr_node = front;

    // traverse to the back of the list
    while (curr_node->next != nullptr) {
        curr_node = curr_node->next;
    }

    // set the old last node's next pointer to the newly added node
    // set the newly added node's previous pointer to the old last node
    curr_node->next = addition;
    addition->previous = curr_node;
    currSize++;
}

/*
* name: insertAt
* purpose: inserts a character node into a specified index
* arguments: a character c to be inserted into the list, integer index that
*            that specifies the position of insertion
* returns: n/a
* effects: raises an error if the index is out of bounds of the list size,
*          increments the size of the list by 1
*/
void CharLinkedList::insertAt(char c, int index) {
    // inserting at index 0 is the same as pushAtFront
    if (index == 0) {
        pushAtFront(c);
        return;
    }
    // allows insertion into currSize + 1, which is the same as pushAtBack
    if (index == currSize) {
        pushAtBack(c);
        return;
    }
    if (index > currSize or index < 0) {
        throw std::range_error("index (" + std::to_string(index) +
            ") not in range [0.." + std::to_string(currSize) + "]");
    }
    // find the location of the node before position index
    Node *previous_node = traverse_until(index - 1, front);

    // create a new node with the given character whose next node is
    // the same as the node before position index
    Node *insertion = new_node(c, previous_node->next);

    // point the new node's previous pointer to the previous node
    insertion->previous = previous_node;

    // point the previous node's next pointer to the new node
    previous_node->next = insertion;
    insertion->next->previous = insertion;
    currSize++;
}

/*
* name: insertInOrder
* purpose: inserts a character node in ASCII order
* arguments: a character c to be inserted into the list
* returns: n/a
* effects: raises an error if the index is out of bounds of the list size,
*          increments the size of the list by 1
*/
void CharLinkedList::insertInOrder(char c) {

    if (isEmpty()) {
        pushAtFront(c);
        return;
    }

    for(int i = 0; i < currSize; i++) {
        // if c comes before or is equal to element at i, insert c before it
        if (c <= elementAt(i)) {
            insertAt(c, i);
            return;
        }
    }
    // if no insertion happens, c is last in ASCII order
    pushAtBack(c);
}

/*
* name: popFromFront
* purpose: removes the first element in the CharLinkedList
* arguments: n/a
* returns: n/a
* effects: decrements size by 1, raises an error if the LinkedList is empty
*/
void CharLinkedList::popFromFront() {
    if (isEmpty()) {
        throw std::runtime_error("cannot pop from empty LinkedList");
    }

    // save a temporary pointer to the old front node
    Node *next_node = front->next;
    delete front;
    front = next_node;

    currSize--;
}


/*
* name: popFromBack
* purpose: removes the last element in the CharLinkedList
* arguments: n/a
* returns: n/a
* effects: decrements size by 1, raises an error if the LinkedList is empty
*/
void CharLinkedList::popFromBack() {
    if (isEmpty()) {
        throw std::runtime_error("cannot pop from empty LinkedList");
    }

    Node *curr_node = front;

    // traverse to last node
    while (curr_node->next != nullptr) {
        curr_node = curr_node->next;
    }

    // if this is not the last node in the list, set the previous node's
    // next node to nullptr
    if (curr_node->previous != nullptr) {
        curr_node->previous->next = nullptr;
    }

    delete curr_node;
    currSize--;
}

/*
* name: removeAt
* purpose: removes the character node at a specified index
* arguments: an integer index of which node to remove
* returns: n/a
* effects: decrements size by 1, raises an error if the index is out of bounds
*/
void CharLinkedList::removeAt(int index) {

    // removing at index 0 is the same as popFromFront
    if (index == 0) {
        popFromFront();
        return;
    }
    // removing at last index is the same as popping
    if (index == currSize - 1) {
        popFromBack();
        return;
    }
    if (index >= currSize or index < 0) {
        throw std::range_error("index (" + std::to_string(index) +
            ") not in range [0.." + std::to_string(currSize) + ")");
    }

    // traverse the list index times
    Node *curr_node = front;
    for (int i = 0; i < index; i++) {
        curr_node = curr_node->next;
    }

    // point the previous node's next to the next node
    // point the next node's previous to the previous node
    curr_node->previous->next = curr_node->next;
    curr_node->next->previous = curr_node->previous;
    delete curr_node;
    currSize--;
}

/*
* name: replaceAt
* purpose: replaces the data at a specific node with a new character
* arguments: a character c for replacement and an integer index for the
*            position of the node to be replaced
* returns: n/a
* effects: raises an error if the index is out of bounds
*/
void CharLinkedList::replaceAt(char c, int index) {
    if (index > currSize or index < 0) {
        throw std::range_error("index (" + std::to_string(index) +
            ") not in range [0.." + std::to_string(currSize) + ")");
    }

    // use recursive helper function to get the address of node at index
    // set that node's data to c
    traverse_until(index, front)->data = c;
}

/*
* name: concatenate
* purpose: adds one CharLinkedList to the end of another
* arguments: one CharLinkedList to be appended to the one that calls the 
*            function
* returns: n/a
* effects: increases the size of the CharLinkedList by the size of the
*          one in the function call
*/
void CharLinkedList::concatenate(CharLinkedList * other) {
    // nothing to add
    if (other->currSize == 0) {
        return;
    }
    // copy each node
    int temp_size = other->currSize;
    for (int i = 0; i < temp_size; i++) {
        pushAtBack(other->elementAt(i));
    }
}
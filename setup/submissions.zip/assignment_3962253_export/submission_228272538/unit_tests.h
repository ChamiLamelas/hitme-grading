/*
 *  unit_tests.h
 *  Elki Laranas
 *  2/5/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  Uses Matt Russell's unit_test framework to test the CharArrayList class.
 *
 */

#include <cassert>
#include "CharLinkedList.h"

// tests default constructor
void default_constructor() {
    CharLinkedList test_list;
    std::string testNormal = "[CharLinkedList of size 0 <<>>]";
    assert(test_list.toString() == testNormal);
}


// tests constructor with one character as a parameter
void singleton_constructor() {
    CharLinkedList test_list('p');
    assert(not test_list.isEmpty());
    assert(test_list.elementAt(0) == 'p');
    std::string testNormal = "[CharLinkedList of size 1 <<p>>]";
    assert(test_list.toString() == testNormal);
}

// tests the deep copy ability of the overloaded assign operator
// tests if items in the LinkedList instances are the same and also asserts
// that their addresses are different
void deep_copy_constructor() {
    // initialize a CharLinkedList with an array of characters
    char test_arr[9] = {'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(test_arr, 9);
    CharLinkedList test_list_copy('h');
    std::string testNormal = "[CharLinkedList of size 1 <<h>>]";
    assert(test_list_copy.toString() == testNormal);

    // test if the overloaded assign operator works
    test_list_copy = test_list;

    // test if the items in the LinkedList instances are the same
    assert(test_list.last() == test_list_copy.last());
    assert(test_list.first() == test_list_copy.first());
    assert(test_list.size() == test_list_copy.size());
    assert(test_list.toString() == test_list_copy.toString());

    // test if the addresses of the LinkedList instances are different
    test_list_copy.pushAtBack('x');
    assert(test_list.last() == 'h' and test_list_copy.last() == 'x');
    assert(&test_list != &test_list_copy);
}

// tests the clear() and isEmpty() functions in tandem
// isEmpty() is tested on a non-empty LinkedList and an empty version of it
// after clear() is called
void clear_and_empty() {
    // initialize a CharLinkedList with an array of characters
    char test_arr[9] = {'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(test_arr, 9);
    std::string testNormal = "[CharLinkedList of size 9 <<abczdefgh>>]";
    assert(test_list.toString() == testNormal);

    // test if the LinkedList is not empty
    assert(not test_list.isEmpty());

    // test if the LinkedList is empty after clear() is called
    test_list.clear();
    std::string testNormal2 = "[CharLinkedList of size 0 <<>>]";
    assert(test_list.toString() == testNormal2);

    // test if the LinkedList can be cleared while it is already empty
    test_list.clear();
    assert(test_list.isEmpty());
}

// tests the size() function called from an empty LinkedList
void size_correct() {
    // initialize a CharLinkedList with an array of characters
    char test_arr[9] = {'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(test_arr, 9);
    // test if the size() function returns the correct size
    assert(test_list.size() == 9);
}

// tests the size() function when sequentially adding elements
void size_while_sequentially_adding() {
    // initialize an empty CharLinkedList
    CharLinkedList test_list;
    assert(test_list.isEmpty());
    
    // test if the size() function returns the correct size after each 
    // pushAtFront
    test_list.pushAtFront('h');
    assert(test_list.size() == 1);
    test_list.pushAtFront('i');
    assert(test_list.size() == 2);
    test_list.pushAtFront('e');
    assert(test_list.size() == 3);
}

// tests the size() function when sequentially removing elements
void size_while_sequentially_removing() {
    // initialize an empty CharLinkedList
    CharLinkedList test_list;
    assert(test_list.isEmpty());
    
    // test if the size() function returns the correct size after each
    // popFromFront
    test_list.pushAtFront('h');
    test_list.pushAtFront('i');
    test_list.pushAtFront('e');
    assert(test_list.size() == 3);
    test_list.popFromFront();
    assert(test_list.size() == 2);
    test_list.popFromFront();
    assert(test_list.size() == 1);
    test_list.popFromFront();
    assert(test_list.isEmpty());
}

// tests the first() function called from a poppulated LinkedList
void first_correct() {
    // initialize a CharLinkedList with an array of characters
    char test_arr[9] = {'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(test_arr, 9);

    // test if the first() function returns the correct first element
    assert(test_list.first() == 'a');
}

// tests the first() function called from an empty LinkedList
void first_incorrect() {
    CharLinkedList test_list;

    // var to track whether runtime_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        // first for empty list
        char hi = test_list.first();
    }
    catch (const std::runtime_error &e) {
        // if first is correctly implemented, a runtime_error will be thrown,
        // and we will end up here
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(error_message == "cannot get first of empty LinkedList");
}

// tests the first() function while sequentially adding elements
void first_while_sequentially_adding() {
    // initialize an empty CharLinkedList
    CharLinkedList test_list;
    assert(test_list.isEmpty());
    
    // test if the first() function returns the correct first element after
    // each pushAtFront
    test_list.pushAtFront('h');
    assert(test_list.first() == 'h');
    test_list.pushAtFront('i');
    assert(test_list.first() == 'i');
    test_list.pushAtFront('e');
    assert(test_list.first() == 'e');
    std::string testNormal = "[CharLinkedList of size 3 <<eih>>]";
    assert(test_list.toString() == testNormal);
}

// tests the first() function while sequentially removing elements
void first_while_sequentially_removing() {
    // initialize an empty CharLinkedList
    CharLinkedList test_list;
    assert(test_list.isEmpty());
    
    // test if the first() function returns the correct first element after
    // each popFromFront
    test_list.pushAtFront('h');
    test_list.pushAtFront('i');
    test_list.pushAtFront('e');
    assert(test_list.first() == 'e');
    test_list.popFromFront();
    assert(test_list.first() == 'i');
    test_list.popFromFront();
    assert(test_list.first() == 'h');
    test_list.popFromFront();
    assert(test_list.isEmpty());

}

// tests the last() function called from an LinkedList with <0 elements
void last_correct() {
    // initialize a CharLinkedList with an array of characters
    char test_arr[9] = {'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(test_arr, 9);

    // test if the last() function returns the correct last element
    assert(test_list.last() == 'h');
    test_list.popFromBack();
    assert(test_list.last() == 'g');
}

// tests the last() function called from an empty LinkedList
void last_incorrect() {
    CharLinkedList test_list;

    // var to track whether runtime_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        // first for empty list
        char hi = test_list.last();
    }
    catch (const std::runtime_error &e) {
        // if last is correctly implemented, a runtime_error will be thrown,
        // and we will end up here
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(error_message == "cannot get last of empty LinkedList");
}

// tests the elementAt() function called from a populated LinkedList
void element_at_incorrect() {
    char test_arr[3] = {'a', 'b', 'c'};
    CharLinkedList test_list(test_arr, 3);
    
    // var to track whether runtime_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        // first for empty list
        char c = test_list.elementAt(6);
    }
    catch (const std::range_error &e) {
        // if first is correctly implemented, a range_error will be thrown,
        // and we will end up here
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(error_message == "index (6) not in range [0..3)");
}

// tests the elementAt() function called from a populated LinkedList
void element_at_incorrect_negative() {
    char test_arr[3] = {'a', 'b', 'c'};
    CharLinkedList test_list(test_arr, 3);
    
    // var to track whether runtime_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        // first for empty list
        char c = test_list.elementAt(-1);
    }
    catch (const std::range_error &e) {
        // if first is correctly implemented, a range_error will be thrown,
        // and we will end up here
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(error_message == "index (-1) not in range [0..3)");
}

// tests the elementAt() function called from a populated LinkedList
void element_at_correct() {
    // initialize a CharLinkedList with an array of characters
    char test_arr[9] = {'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(test_arr, 9);

    // test if the elementAt() function returns the correct element
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(3) == 'z');
}

// tests the elementAt() function while adding elements
void element_at_while_adding() {
    // initialize an empty CharLinkedList
    CharLinkedList test_list;
    assert(test_list.isEmpty());
    
    // test if the elementAt() function returns the correct element after
    // each pushAtFront
    test_list.pushAtFront('h');
    assert(test_list.elementAt(0) == 'h');
    test_list.pushAtFront('i');
    assert(test_list.elementAt(0) == 'i');
    test_list.pushAtFront('e');
    assert(test_list.elementAt(0) == 'e');
    std::string testNormal = "[CharLinkedList of size 3 <<eih>>]";
    assert(test_list.toString() == testNormal);
}

// tests the elementAt() function while removing elements
void element_at_while_removing() {
    // initialize an empty CharLinkedList
    CharLinkedList test_list;
    assert(test_list.isEmpty());
    
    // test if the elementAt() function returns the correct element after
    // each popFromFront
    test_list.pushAtFront('h');
    test_list.pushAtFront('i');
    test_list.pushAtFront('e');
    assert(test_list.elementAt(0) == 'e');
    test_list.popFromFront();
    assert(test_list.elementAt(0) == 'i');
    test_list.popFromFront();
    assert(test_list.elementAt(0) == 'h');
    test_list.popFromFront();
    assert(test_list.isEmpty());
}

// tests the toString() function called from an empty and regular LinkedList
void to_string() {
    // initialize an empty CharLinkedList
    CharLinkedList test_list;
    std::string testEmpty = "[CharLinkedList of size 0 <<>>]";
    assert(test_list.toString() == testEmpty);

    // initialize a CharLinkedList with an array of characters
    test_list.pushAtBack('h');
    test_list.pushAtBack('i');
    std::string testNormal = "[CharLinkedList of size 2 <<hi>>]";
    assert(test_list.toString() == testNormal);
}

// tests the toReverseString() function called from an empty and 
// regular LinkedList
void to_reverse_string() {
    // initialize an empty CharLinkedList
    CharLinkedList test_list;
    std::string testEmpty = "[CharLinkedList of size 0 <<>>]";
    assert(test_list.toReverseString() == testEmpty);

    // initialize a CharLinkedList with an array of characters
    test_list.pushAtBack('h');
    test_list.pushAtBack('i');
    std::string testNormal = "[CharLinkedList of size 2 <<ih>>]";
    assert(test_list.toReverseString() == testNormal);
}

// tests the pushAtFront() function on an empty LinkedList
void push_at_front_empty() {
    // initialize an empty CharLinkedList
    CharLinkedList test_list;
    assert(test_list.isEmpty());
    
    // test if the empty LinkedList changes accordingly after each pushAtFront
    test_list.pushAtFront('h');
    test_list.pushAtFront('i');
    std::string testNormal = "[CharLinkedList of size 2 <<ih>>]";
    assert(test_list.toString() == testNormal);
}

// tests the pushAtFront() function on a populated LinkedList
void push_at_front_normal() {
    // initialize a CharLinkedList with an array of characters
    char test_arr[9] = {'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(test_arr, 9);
    
    // test if the LinkedList changes accordingly after each pushAtFront
    test_list.pushAtFront('h');
    test_list.pushAtFront('i');
    std::string testNormal = "[CharLinkedList of size 11 <<ihabczdefgh>>]";
    assert(test_list.toString() == testNormal);
}

// tests the pushAtBack() function on an empty LinkedList
void push_at_back_empty() {
    // initialize an empty CharLinkedList
    CharLinkedList test_list;
    assert(test_list.isEmpty());
    
    // test if the empty LinkedList changes accordingly after each pushAtBack
    test_list.pushAtBack('h');
    test_list.pushAtBack('i');
    test_list.pushAtBack('i');
    std::string testNormal = "[CharLinkedList of size 3 <<hii>>]";
    assert(test_list.toString() == testNormal);
}

// tests the pushAtBack() function on a populated LinkedList
void push_at_back_normal() {
    // initialize a CharLinkedList with an array of characters
    char test_arr[9] = {'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(test_arr, 9);
    
    // test if the LinkedList changes accordingly after each pushAtBack
    test_list.pushAtBack('h');
    test_list.pushAtBack('i');
    std::string testNormal = "[CharLinkedList of size 11 <<abczdefghhi>>]";
    assert(test_list.toString() == testNormal);
}

// tests the insertAt() function correctly called from an empty LinkedList
void insert_at_empty() {
    // initialize an empty CharLinkedList
    CharLinkedList test_list;

    // test if the empty LinkedList changes accordingly after each insertAt
    test_list.insertAt('x', 0);
    std::string testNormal = "[CharLinkedList of size 1 <<x>>]";
    assert(test_list.toString() == testNormal);
}

// tests the insertAt() function called from a populated LinkedList
void insert_at_normal() {
    // initialize a CharLinkedList with an array of characters
    char test_arr[9] = {'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(test_arr, 9);

    // test if the LinkedList changes accordingly after each insertAt
    test_list.insertAt('x', 3);
    std::string testNormal = "[CharLinkedList of size 10 <<abcxzdefgh>>]";
    assert(test_list.toString() == testNormal);

    // test if insertion at size and 0 works
    test_list.insertAt('x', 10);
    test_list.insertAt('x', 0);
    testNormal = "[CharLinkedList of size 12 <<xabcxzdefghx>>]";
    assert(test_list.toString() == testNormal);
}

// tests the insertAt() function called with an out of bounds index
void insert_at_out_of_bounds() {
    char test_arr[9] = {'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(test_arr, 9);

    // var to track whether runtime_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        // insert out of bounds
        test_list.insertAt('x', 100);
    }
    catch (const std::range_error &e) {
        // if first is correctly implemented, a range_error will be thrown,
        // and we will end up here
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(error_message == "index (100) not in range [0..9]");

}

// tests the insertAt() function called with an out of bounds index below 0
void insert_at_out_of_bounds_negative() {
    char test_arr[9] = {'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(test_arr, 9);

    // var to track whether runtime_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        // insert out of bounds
        test_list.insertAt('x', -1);
    }
    catch (const std::range_error &e) {
        // if first is correctly implemented, a range_error will be thrown,
        // and we will end up here
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(error_message == "index (-1) not in range [0..9]");

}

// tests the insertAt() function called with the last index of the LinkedList
void insert_at_last_element() {
    // initialize a CharLinkedList with an array of characters
    char test_arr[3] = {'a', 'b', 'c'};
    CharLinkedList test_list(test_arr, 3);
    test_list.insertAt('x', 3);
    // test if the last element is correctly inserted
    assert(test_list.elementAt(3) == 'x');
    assert(test_list.last() == 'x');
}

// tests in-order insertion for an empty list
void insert_in_order_empty() {
    // initialize an empty CharLinkedList
    CharLinkedList test_list;
    test_list.insertInOrder('a');
    assert(test_list.toString() == "[CharLinkedList of size 1 <<a>>]");
}

// tests in-order insertion for a populated list
void insert_in_order_many_elements() {
    // initialize a CharLinkedList with an array of characters
    char test_arr[7] = {'a', 'b', 'c', 'd', 'f', 'g', 'h'};
    CharLinkedList test_list(test_arr, 7);

    // test if the e is inserted in the right spot
    test_list.insertInOrder('e');
    assert(test_list.toString() == "[CharLinkedList of size 8 <<abcdefgh>>]");
    
    // tests if the list is sorted after inserting capital letters and numbers
    test_list.insertInOrder('z');
    test_list.insertInOrder('A');
    test_list.insertInOrder('1');
    std::string test_string = "[CharLinkedList of size 11 <<1Aabcdefghz>>]";
    assert(test_list.toString() == test_string);
}

// tests in-order insertion for a populated list
void insert_in_order_capital_a() {
    // initialize a CharLinkedList with an array of characters
    char test_arr[4] = {'a', 'c', 'd', 'e'};
    CharLinkedList test_list(test_arr, 4);

    // test if a capital letter
    test_list.insertInOrder('A');
    assert(test_list.toString() == "[CharLinkedList of size 5 <<Aacde>>]");
}

// tests the popFromFront() function on an normal LinkedList
void pop_at_front_empty() {
    CharLinkedList test_list;
    assert(test_list.isEmpty());
    
    // var to track whether runtime_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        // first for empty list
        test_list.popFromFront();
    }
    catch (const std::runtime_error &e) {
        // if first is correctly implemented, a runtime_error will be thrown,
        // and we will end up here
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(error_message == "cannot pop from empty LinkedList");
}

// tests the popFromFront() function on an singleton LinkedList
void pop_at_front_singleton() {
    CharLinkedList test_list('i');

    std::string testNormal = "[CharLinkedList of size 1 <<i>>]";
    assert(test_list.toString() == testNormal);

    // test if the LinkedList changes accordingly after each popFromFront
    test_list.popFromFront();
    std::string testNew = "[CharLinkedList of size 0 <<>>]";
    assert(test_list.toString() == testNew);
    assert(test_list.isEmpty());
}

// tests the popFromFront() function on an normal LinkedList
void pop_at_front_normal() {
    CharLinkedList test_list;
    assert(test_list.isEmpty());
    
    test_list.pushAtBack('h');
    test_list.pushAtBack('i');
    test_list.pushAtBack('i');
    std::string testNormal = "[CharLinkedList of size 3 <<hii>>]";
    assert(test_list.toString() == testNormal);

    // test if the LinkedList changes accordingly after a popFromFront
    test_list.popFromFront();
    std::string testNew = "[CharLinkedList of size 2 <<ii>>]";
    assert(test_list.toString() == testNew);
}


// tests the popFromBack() function on an empty LinkedList
void pop_at_back_empty() {
    CharLinkedList test_list;
    assert(test_list.isEmpty());

    // var to track whether runtime_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        // first for empty list
        test_list.popFromBack();
    }
    catch (const std::runtime_error &e) {
        // if first is correctly implemented, a runtime_error will be thrown,
        // and we will end up here
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(error_message == "cannot pop from empty LinkedList");
}

// tests the popFromBack() function on an normal LinkedList
void pop_at_back_normal() {
    CharLinkedList test_list;
    assert(test_list.isEmpty());
    
    test_list.pushAtBack('h');
    test_list.pushAtBack('i');
    test_list.pushAtBack('i');
    std::string testNormal = "[CharLinkedList of size 3 <<hii>>]";
    assert(test_list.toString() == testNormal);

    // test if the LinkedList changes accordingly after a popFromBack
    test_list.popFromBack();
    std::string testNew = "[CharLinkedList of size 2 <<hi>>]";
    assert(test_list.toString() == testNew);
}

// tests the removeAt() function with an out-of-bounds function call
void removeAt_out_of_bounds() {
    char test_arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(test_arr, 8);
    
    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.removeAt(9);
    } catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    
    assert(range_error_thrown);
    assert(error_message == "index (9) not in range [0..8)");
}

// tests the removeAt() function with a negative function call
void removeAt_out_of_bounds_negative() {
    char test_arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(test_arr, 8);
    
    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.removeAt(-1);
    } catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    
    assert(range_error_thrown);
    assert(error_message == "index (-1) not in range [0..8)");
}

// tests the removeAt() function with an empty LinkedList
void removeAt_empty() {
    CharLinkedList test_list;
    
    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.removeAt(3);
    } catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    
    assert(range_error_thrown);
    assert(error_message == "index (3) not in range [0..0)");
}

// tests the removeAt() function with a single-element LinkedList
void removeAt_singleton_list() {
    CharLinkedList test_list('a');
    test_list.removeAt(0);
    
    // test if the LinkedList changes accordingly after a removeAt
    assert(test_list.size() == 0);
    assert(test_list.toString() == "[CharLinkedList of size 0 <<>>]");
}

// tests the removeAt() function with an LinkedList with many elements
void removeAt_many_elements() {
    char test_arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(test_arr, 8);

    test_list.removeAt(2);
    
    // test if the LinkedList size and element at 2 changes accordingly after 
    // a removeAt
    assert(test_list.size() == 7);
    assert(test_list.elementAt(2) == 'd');
    assert(test_list.toString() == "[CharLinkedList of size 7 <<abdefgh>>]");
}

// tests the replaceAt() function with a single-element LinkedList
void replaceAt_singleton_list() {
    CharLinkedList test_list('a');

    test_list.replaceAt('x', 0);
    
    // test if the LinkedList size and element at 0 accordingly after a 
    // replaceAt
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'x');
    assert(test_list.toString() == "[CharLinkedList of size 1 <<x>>]");
}

// tests the replaceAt() function with a populated LinkedList with many items
void replaceAt_many_elements() {
    char test_arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(test_arr, 8);

    test_list.replaceAt('x', 2);
    
    // test if the LinkedList size and element at 2 changes accordingly after
    // a replaceAt
    assert(test_list.size() == 8);
    assert(test_list.elementAt(2) == 'x');
    assert(test_list.toString() == "[CharLinkedList of size 8 <<abxdefgh>>]");
}

// tests the replaceAt() function with an out-of-bounds function call
void replaceAt_nonempty_incorrect() {
    char test_arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.replaceAt('x', 9);
    } catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    
    assert(range_error_thrown);
    assert(error_message == "index (9) not in range [0..8)");
}

// tests the replaceAt() function with a negative function call
void replaceAt_nonempty_incorrect_negative() {
    char test_arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.replaceAt('x', -1);
    } catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    
    assert(range_error_thrown);
    assert(error_message == "index (-1) not in range [0..8)");
}

// tests the replaceAt() function with an empty LinkedList and an out-of-bounds
// function call
void replaceAt_empty_incorrect() {
    CharLinkedList test_list;

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.replaceAt('x', 123);
    } catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    
    assert(range_error_thrown);
    assert(error_message == "index (123) not in range [0..0)");
}

// tests the replaceAt() function with the last element of the LinkedList
void replace_at_last_element() {
    char test_arr[3] = {'a', 'b', 'c'};
    CharLinkedList test_list(test_arr, 3);
    test_list.replaceAt('x', 2);

    // test if the last element is correctly replaced
    assert(test_list.elementAt(2) == 'x');
    assert(test_list.last() == 'x');
}

// tests the concatenate function with two populated LinkedLists
void concatenate_normal() {
    char test_arr[8] = {'C', 'h', 'e', 's', 'h', 'i', 'r', 'e'};
    CharLinkedList test_list_1(test_arr, 8);

    char test_arr_2[4] = {' ', 'C', 'a', 't'}; 
    CharLinkedList test_list_2(test_arr_2, 4);

    // test if the LinkedLists are concatenated correctly
    test_list_1.concatenate(&test_list_2);
    std::string testString = "[CharLinkedList of size 12 <<Cheshire Cat>>]";
    assert(test_list_1.toString() == testString);
}

// tests the concatenate function in the situation that an LinkedList is 
// concatenated to itself
void concatenate_self() {
    char test_arr[3] = {'C', 'a', 't'}; 
    CharLinkedList test_list(test_arr, 3);

    // test if the LinkedLists are concatenated correctly
    test_list.concatenate(&test_list);
    std::string testString = "[CharLinkedList of size 6 <<CatCat>>]";
    assert(test_list.toString() == testString);
}

// tests the concatenate function in the situation that an empty LinkedList is 
// concatenated to a populated one
void concatenate_empty_to_normal() {
    CharLinkedList empty_list;
    char test_arr[3] = {'C', 'a', 't'}; 
    CharLinkedList test_list(test_arr, 3);

    // test if the LinkedLists are concatenated correctly
    test_list.concatenate(&empty_list);
    std::string testString = "[CharLinkedList of size 3 <<Cat>>]";
    assert(test_list.toString() == testString);
}

// tests the concatenate function in the situation that a populated LinkedList
// is concatenated to an empty one
void concatenate_normal_to_empty() {
    CharLinkedList empty_list;
    char test_arr[3] = {'C', 'a', 't'}; 
    CharLinkedList test_list(test_arr, 3);

    // test if the LinkedLists are concatenated correctly
    empty_list.concatenate(&test_list);
    std::string testString = "[CharLinkedList of size 3 <<Cat>>]";
    assert(empty_list.toString() == testString);
}

// tests the concatenate function in the situation that an empty LinkedList
// is concatenated to an empty one
void concatenate_empty_to_empty() {
    CharLinkedList empty_list;
    CharLinkedList test_list;

    // test if the LinkedLists are concatenated correctly
    test_list.concatenate(&empty_list);
    std::string testString = "[CharLinkedList of size 0 <<>>]";
    assert(test_list.toString() == testString);
}


/*
 *  CharLinkedList.h
 *  Stella Roering 
 *  Feb 2nd 2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  FILE PURPOSE HERE
 * This file contains the declarations of the structure and interface  of the 
 * Linked list class. It does not provide the acutal implementation however,
 * this is included in the file CharLinkedList.cpp. It is a header file,
 * defining the class itself, it's member functions and any data members that
 * are associated.
 */

#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H
#include <stdexcept>

class CharLinkedList {
    public: 
    //Constructors
    CharLinkedList();
    CharLinkedList(char c);
    CharLinkedList(char arr[], int size);
    CharLinkedList(const CharLinkedList &other);

    //Destructor
    ~CharLinkedList();

     //Methods
    CharLinkedList &operator=(const CharLinkedList &other);
    bool isEmpty() const;
    void clear();
    int size() const;
    char first() const;
    char last() const;
    char elementAt(int index) const;
    std::string toString() const;
    std::string toReverseString() const;
    void pushAtBack(char c);
    void pushAtFront(char c);
    void insertAt(char c, int index);
    void insertInOrder(char c);
    void popFromFront();
    void popFromBack();
    void removeAt(int index);
    void replaceAt(char c, int index);
    void concatenate(CharLinkedList *other);

    private:
    struct Node {
        char info;
        Node *next;
        Node *prev;
    };

    Node *front;
    Node *back;
    int CurrSize;

    //Helper functions
    void destructrecursive(Node *curr);
    Node *newNode(char newData, Node *next, Node *previous);
    void recycleRecursive(Node *curr);
    char elementAtRecursive(Node *current, int index) const;
    void replaceAtRecursive(Node* current, char c, int index);
};

#endif

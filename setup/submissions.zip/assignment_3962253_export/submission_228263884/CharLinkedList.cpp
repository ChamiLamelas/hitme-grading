/*
 *  CharLinkedList.cpp
 *  Stella Roering
 *  Feb 2nd 2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  FILE PURPOSE HERE
 *  The file contains the implementation for the Char Linked list. It defines
 *  the functionality and behavior associated with the declared class of 
 *  Linked Lists in the file of CharLinkedList.h
 */

#include "CharLinkedList.h"
using namespace std;
#include <iostream>

/*
 * name:      LinkedList default constructor
 * purpose:   initialize an empty LinkedList
 * arguments: none
 * returns:   none
 * effects:   sets size and capacity to zero
 */
CharLinkedList::CharLinkedList() {
    front = nullptr;
    back = nullptr;
    CurrSize = 0;
}

/*
 * name:      LinkedList single character constructor
 * purpose:   initialize an LinkedList of size 1
 * arguments: a char
 * returns:   none
 * effects:   set size and capacity to one 
 */
CharLinkedList::CharLinkedList(char c) {
    front = newNode(c, nullptr, nullptr); 
    back = front;
    CurrSize = 1;
}

/*
 * name:      LinkedList constructor
 * purpose:   copies an array into an Linked list
 * arguments: char array and integer for size
 * returns:   none
 * effects:   creates an LinkedList copied from an array
 */
CharLinkedList::CharLinkedList(char arr[], int size) {
    CurrSize = size;

    if (CurrSize > 0) {
        //Setting front pointer equal to the first char of the array
        front = newNode(arr[0], nullptr, nullptr); 
        Node *current = front;

        //Iterate through the rest of the array
        for (int i = 1 ; i < CurrSize; i++) {
            current->next = newNode(arr[i], nullptr, current);
            current = current->next;
        }
        back = current;
    } else {
        front = nullptr;
        back = nullptr;
    }
}

/*
 * name:      LinkedList deepcopy constructor
 * purpose:   creates a deepcopy of an LinkedList
 * arguments: CharLinkedList and &other
 * returns:   none
 * effects:   a deep copy of the LinkedList that was passed in is created
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other) {
    if (other.front == nullptr) {
        return;
    }
    
    CurrSize = other.CurrSize;

    if (CurrSize > 0) {
        front = newNode(other.elementAt(0), nullptr, nullptr); 
        Node *current = front;
        Node *otherCurr = other.front;

        for (int i = 1; i < CurrSize; i++) {
            current->next = newNode(other.elementAt(i), nullptr, current); 
            current = current->next;
            otherCurr = otherCurr->next;
        }
        back = current;
    } else { 
        front = nullptr;
        back = nullptr;
    }
}

/*
 * name:      LinkedList destructor
 * purpose:   delete memory
 * arguments: none
 * returns:   none
 * effects:   all stored memory is deleted
 */
CharLinkedList::~CharLinkedList() {
    recycleRecursive(front); 
}

/*
 * name:      newNode
 * purpose:   create a new node in the Linked List class
 * arguments: char holds info for node, pointer to next node and previous node
 * returns:   the new node
 * effects:   a new node is created with new info
 */
CharLinkedList::Node *CharLinkedList::newNode(char newInfo, Node *next, 
                                                            Node *previous) {
    Node *new_node = new Node;
    new_node->info = newInfo;
    new_node->next = next;
    new_node->prev = previous;

    return new_node;
}

/*
 * name:      recycleRecursive
 * purpose:   helper function for the destructor to recycle the memory
 * arguments: a CharLinkedList of name other, passed by reference
 * returns:   the function itself (recursively)
 * effects:   each node is deleted by calling the function recursively
 */
void CharLinkedList::recycleRecursive(Node *curr) {
    if (curr == nullptr) {
        return;
    } else {
        Node *next = curr->next;
        delete curr;
        return recycleRecursive(next);
    }

}

/*
 * name:      CharLinkedList
 * purpose:   Defines an assignment operator to make a deep copy of the right 
 *            side instance into the left side 
 * arguments: a CharLinkedList of name other, passed by reference
 * returns:   a pointer to the deep copy
 * effects:   a deep copy of the right side instance is created over the left 
 *            side instance
 */
CharLinkedList & CharLinkedList::operator=(const CharLinkedList &other){ 
    if (this == &other) {
        return *this;
    }

    clear();

    //Creating space for other to be copied into
    CurrSize = other.CurrSize;

    //Copy the other info into the new CharLinkedList 
    if (CurrSize > 0) {
        front = newNode(other.elementAt(0), nullptr, nullptr); 
        Node *current = front;
        Node *otherCurr = other.front;

        for (int i = 1; i < CurrSize; i++) {
            current->next = newNode(other.elementAt(i), nullptr, current); 
            current = current->next;
            otherCurr = otherCurr->next;
        }
    }

    return *this;
}

/*
 * name:      isEmpty
 * purpose:   determine if an LinkedList is empty or not
 * arguments: none
 * returns:   true or false depending if it is empty 
 * effects:   tells if an LinkedList is empty
 */
bool CharLinkedList::isEmpty() const {
    if (front == nullptr) {
        return true;
    } 
    return false;
}

/*
 * name:      clear
 * purpose:   clear the data from a Linked list
 * arguments: none
 * returns:   none
 * effects:   sets the front to nullptr
 */
void CharLinkedList::clear() {
    while (front != nullptr) {
        Node *currtemp = front;
        front = front->next;
        delete currtemp;
    }
    CurrSize = 0;
}

/*
 * name:      size
 * purpose:   determine the size of the Linked List
 * arguments: none
 * returns:   the current size of the list
 * effects:   gives the size of the list
 */
int CharLinkedList::size() const {
    return CurrSize;
}

/*
 * name:      first
 * purpose:   return the first element of the Linked List
 * arguments: none
 * returns:   the first element of the Linked List
 * effects:   gives the first element of the Linked List
 */
char CharLinkedList::first() const {
    if (isEmpty()) {
        throw std::runtime_error("cannot get first of empty LinkedList");
    }
    return front->info;
}

/*
 * name:      last
 * purpose:   returns the last element of an Linked List
 * arguments: none
 * returns:   the last element of the Linked List
 * effects:   gives the last element of the Linked List
 */
char CharLinkedList::last() const {
    if (isEmpty()) {
        throw std::runtime_error("cannot get last of empty LinkedList");
    }
    return back->info;
}

/*
 * name:      elementAt
 * purpose:   returns the element at the given index by calling a recursive 
 *            helper function
 * arguments: integer holding an index
 * returns:   the element at the index in the argument
 * effects:   gives the element at the given index
 */
char CharLinkedList::elementAt(int index) const {
    return elementAtRecursive(front, index);
}

/*
 * name:      elementAtRecursive
 * purpose:   resursive helper function for elementAt
 * arguments: integer holding an index and a node pointer to the current node
 * returns:   the function itself (recursively) or the current node's info 
 *            (base case)
 * effects:   helps the elementAt function to get the node
 */
char CharLinkedList::elementAtRecursive(Node *current, int index) const {
     if (index >= CurrSize or index < 0) {
        throw std::range_error("index (" + std::to_string(index) + 
        ") not in range [0.." + std::to_string(CurrSize) + ")");
    }
    
    //Basecase
    if (index == 0) {
        return current->info;
    }

    //Recursive case 
    return elementAtRecursive(current->next, index - 1);
   
}

/*
 * name:      toString
 * purpose:   Returns the characters of the CharLinkedList as a string
 * arguments: none
 * returns:   a string holding the characters of the Linked List
 * effects:   outputs the characters of the CharLinkedList as a string
 */
std::string CharLinkedList::toString() const {
    if (CurrSize == 0) {
        return std::string("[CharLinkedList of size 0 <<>>]"); 
    }  else {

    std::string output;
    Node *current = front;

    for (int i = 0; i < CurrSize; i++) {
        output += current->info;
        current = current->next;
    }

    return std::string("[CharLinkedList of size " + std::to_string(CurrSize) 
    + " <<" + output + ">>]");
    }
}

/*
 * name:      toReverseString
 * purpose:   Returns the characters of the CharLinkedList as a string in 
 *            reverse order
 * arguments: none
 * returns:   a string holding the characters of the Linked List in reverse 
 *            order
 * effects:   outputs the characters of the CharLinkedList in reverse as a 
 *            string
 */
std::string CharLinkedList::toReverseString() const {
    if (CurrSize == 0) {
       return std::string("[CharLinkedList of size 0 <<>>]"); 
    } else{

    std::string output;
    Node *current = back;

    for(int i = CurrSize - 1; i >= 0; i--) {
        output += current->info;
        current = current->prev;
    }

    return std::string("[CharLinkedList of size " + std::to_string(CurrSize) 
    + " <<" + output + ">>]");
    }
}

/*
 * name:      pushAtBack
 * purpose:   takes the inputed character and inserts at the back of the list 
 * arguments: a char
 * returns:   nothing
 * effects:   inserts a new element at the end of Linked List
 */
void CharLinkedList::pushAtBack(char c) {
   if (front == nullptr) {
    pushAtFront(c);
   } else {
        Node *oldback = back;
        back = newNode(c, nullptr, oldback); 
        oldback->next = back;
        CurrSize++;
   }
}

/*
 * name:      pushAtFront
 * purpose:   insert the char in the argument into the front of the Linked List
 * arguments: a char
 * returns:   none
 * effects:   inserts a new element at the front of the Linked List
 */
void CharLinkedList::pushAtFront(char c) {
    if (CurrSize == 0) {
    front = newNode(c, nullptr, nullptr); 
    back = front;
    CurrSize++;
    } else {
        Node *oldfront = front;
        front = newNode(c, oldfront, nullptr); 
        oldfront->prev = front;
        CurrSize++;
    }
}

/*
 * name:      insertAt
 * purpose:   insert the given char at the given index
 * arguments: a char holding the character that is to be inserted and an integer
 *            holding the index where it is to be inserted
 * returns:   none
 * effects:   creates a new node which now points to the node in the index
 *            in front of it
 */
void CharLinkedList::insertAt(char c, int index) {
    if (index < 0 or index > CurrSize) {
        throw std::range_error("index (" + std::to_string(index) + 
        ") not in range [0.." + std::to_string(CurrSize) + "]");
    }
    if (index == 0 or isEmpty()) {
        front = newNode(c, front, nullptr);
        CurrSize++;
        return;
    } else {

    Node *current = front;

    for (int i = 0; i < index - 1; i ++) {
        current = current->next;
    }

    Node *temp = newNode(c, current->next, current);
    //Check to make sure not inserting at the back
    if (current->next != nullptr) {
        current->next->prev = current;
    }
    current->next = temp;
    CurrSize++;
    }
}




/*
 * name:      insertInOrder
 * purpose:   insert the given char into the list in order of ASCII values
 * arguments: a char holding the character that is to be inserted
 * returns:   none
 * effects:   inserts a char in the order of ASCII values, calls insertAt
 */
void CharLinkedList::insertInOrder(char c) {
    Node *current = front;
    int currentcounter = 0;
    int ogCurrSize = CurrSize;
    for (int i = 0; i < CurrSize; i++) {
        //If they are the same input in the current place
        if (c == current->info) {
            insertAt(c, currentcounter);
            return;
        }

        if (current->info > c) {
            insertAt(c, currentcounter);
            return;
        }
        current = current->next;
        currentcounter++;
    }

    //Inserting at the end
    if (ogCurrSize == CurrSize) {
        insertAt(c, CurrSize);
    }
}

/*
 * name:      popFromFront
 * purpose:   Deletes the element at the front of the list
 * arguments: none
 * returns:   none
 * effects:   calls removeAt() on the first element and deletes first element
 */
void CharLinkedList::popFromFront() {
    if (CurrSize == 0) {
        throw std::runtime_error("cannot pop from empty LinkedList");
    }

     Node *currtemp = front;
        front = front->next;
        if (front !=nullptr) {
            front->prev = nullptr;
        }

        delete currtemp;
        CurrSize--;
}

/*
 * name:      popFromBack
 * purpose:   Deletes the element at the back of the list
 * arguments: none
 * returns:   none
 * effects:   calls removeAt() on the last element and deletes last element
 */
void CharLinkedList::popFromBack() {
    if (CurrSize == 0) {
        throw std::runtime_error("cannot pop from empty LinkedList");
    }

    Node *currtemp = back;
    back = back->prev;
    back->next = nullptr;

     delete currtemp;
    CurrSize--;
}

/*
 * name:      removeAt
 * purpose:   Deletes the element at the index that is passed in
 * arguments: an integer holding the index of the element that is to be deleted
 * returns:   none
 * effects:   deletes the element in index and shifts it's pointers to the ones
 *            behind it
 */
void CharLinkedList::removeAt(int index) {
 if (index < 0 or index >= CurrSize) {
        throw std::range_error("index (" + std::to_string(index) + 
        ") not in range [0.." + std::to_string(CurrSize) + ")");
    } 

    //Delete first element
    if (index == 0) {
        Node *currtemp = front;
        front = front->next;
        if (front !=nullptr) {
            front->prev = nullptr;
        }

        delete currtemp;
    } else {
        Node *current = front;

        for (int i = 0; i < index - 1; i++) {
            current = current->next;
        }

        //Making new pointers to point to the node after index
        Node *temp = current->next;

        current->next = current->next->next; 
        if (current->next != nullptr) {
            current->next->prev = current;
        }

        delete temp;
    }
    CurrSize--;
}

/*
 * name:      replaceAt
 * purpose:   calls a recurisive helper function to replace at
 * arguments: a char holding a character to be inputted into the Linked List 
 *            and an integer holding the index 
 * returns:   none
 * effects:   calls a helper functioin
 */
void CharLinkedList::replaceAt(char c, int index) {
    replaceAtRecursive(front, c, index);
}

/*
 * name:      replaceAtRecursive
 * purpose:   a helper funciton that recursively changes the info at the node
 *            of the specified index
 * arguments: a char holding a character to be inputted into the Linked List, 
 *            an integer holding the index and  a node pointer to the current
 *            node
 * returns:   none
 * effects:   recusively changes the info to the char that was passed in 
 *            at the index that was passed in
 */
void CharLinkedList::replaceAtRecursive(Node* current, char c, int index) {
    if (index < 0 or index >= CurrSize) {
        throw std::range_error("index (" + std::to_string(index) 
        + ") not in range [0.." + std::to_string(CurrSize) + ")");
    }

    if (index == 0 ) {
        current->info = c;
        return;
    }

    return replaceAtRecursive(current->next, c, index - 1);
}

/*
 * name:      concatentate 
 * purpose:   concatenates two Linked lists together
 * arguments: a pointer to a CharLinkedList
 * returns:   none
 * effects:   combines two Linked Lists together
 */
void CharLinkedList::concatenate(CharLinkedList *other) {
    if (isEmpty()) {
        *this = *other;
        return;
    }
    
    if (other->CurrSize == 0) {
        return;
    }
    
    Node* temp = other->front;
    int counter = other->CurrSize;
    while (counter != 0) {
        pushAtBack(temp->info);
        temp = temp->next;
        counter--;
    }
}
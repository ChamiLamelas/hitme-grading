/*
 *  unit_tests.h
 *  Stella Roering 
 *  Feb 2nd 2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  FILE PURPOSE HERE
 * The purpose of this file is to verify the correctness of the linked 
 * implementation through the testing of individual functions of the code. It 
 * ensures that each function performs as it should. 
 */
 #include "CharLinkedList.h"
 #include <cassert>

//Constructor tests
void initalizeemptyarray() {
    CharLinkedList list;
    assert(list.size() == 0);
}

void inalizeconstructorwitharray() {
    char array[5] = {'d', 'o', 'g'};
    CharLinkedList list(array, 3);
    assert(list.size() == 3);
}

void emptysizetesting() {
    CharLinkedList list;
    assert(list.size() == 0);
}

void fullsizetesting() {
    char array[3] = {'d', 'o', 'g'};
    CharLinkedList list(array, 3);
    assert(list.size() == 3);
}

void cleartesting() {
    CharLinkedList list('c');
    list.clear();
    assert(list.isEmpty()); 
}

void wrongcleartesting() {
    CharLinkedList list('c');
    assert(not list.isEmpty()); 
}

void isemptytesting() {
    CharLinkedList list;
    assert(list.isEmpty());
}

void firsttesting() {
    char array[3] = {'d', 'o', 'g'};
    CharLinkedList list(array, 3);
    assert(list.first() == 'd');
}

void wrongfirsttesting() {
    char array[3] = {'d','o','g'};
    CharLinkedList list(array, 3);
    list.first();
    assert(list.first() != 'o');
}

void firsttrycatch() {
    CharLinkedList list;
    bool thrown_error = false;

    try {
        list.first();
    } catch (const std::runtime_error &e){
        thrown_error = true;
    }

    assert(thrown_error);
}

void lasttesting() {
    char array[3] = {'d','o','g'};
    CharLinkedList list(array, 3);
    assert(list.last() == 'g');
}

void wronglasttesting() {
    char array[3] = {'d','o','g'};
    CharLinkedList list(array, 3);
    assert(list.last() != 'd');
}

void lasttrycatch() {
    CharLinkedList list;
    bool thrown_error = false;

    try {
        list.last();
    } catch (const std::runtime_error &e){
        thrown_error = true;
    }

    assert(thrown_error);
}

void elementattesting() {
    char array[3] = {'d','o','g'};
    CharLinkedList list(array, 3);
    assert(list.elementAt(1) == 'o');
}

void bigelementattesting() {
    char array[14] = {'d','o','g','d','o','g','d','o','g','d','o','g','d','o',};
    CharLinkedList list(array, 14);
    assert(list.elementAt(13) == 'o');
}

void emptyelementattesting() {
    CharLinkedList list;
    bool error_thrown = false;
    try {
        list.elementAt(2);
    } catch(const std::range_error &e) {
        error_thrown = true;
    }
    assert(error_thrown);
}

void wrongelementattesting() {
    char array[3] = {'d','o','g'};
    CharLinkedList list(array, 3);
    assert(list.elementAt(2) != 'o');
}

void toStringTesting() {
    char array[3] = {'d','o','g'};
    CharLinkedList list(array, 3);
    assert(list.toString() ==     "[CharLinkedList of size 3 <<dog>>]");
}

void emptytoStringTesting() {
    CharLinkedList list;
    assert(list.toString() ==     "[CharLinkedList of size 0 <<>>]");
}

void clearwithToStringTesting() {
    char array[3] = {'d','o','g'};
    CharLinkedList list(array, 3);
    assert(list.toString() ==     "[CharLinkedList of size 3 <<dog>>]");

    list.clear();
    assert(list.toString() ==     "[CharLinkedList of size 0 <<>>]");
}

void clearwithToStringTestingandadding() {
    char array[3] = {'d','o','g'};
    CharLinkedList list(array, 3);
    assert(list.toString() ==     "[CharLinkedList of size 3 <<dog>>]");

    list.clear();
    assert(list.toString() ==     "[CharLinkedList of size 0 <<>>]");

    list.pushAtFront('c');
    assert(list.elementAt(0) == 'c');
}

void ReverseStringTesting() {
    char array[3] = {'d','o','g'};
    CharLinkedList list(array, 3);
    assert(list.toReverseString() ==     "[CharLinkedList of size 3 <<god>>]");
}

void emptytoReverseStringTesting() {
    CharLinkedList list;
    assert(list.toString() ==     "[CharLinkedList of size 0 <<>>]");
}

void pushatbackTesting() {
    char array[3] = {'d','o','g'};
    CharLinkedList list(array, 3);
    list.pushAtBack('s');
    assert(list.elementAt(3) == 's');
    assert(list.size() == 4);
}

void pushatfrontTesting() {
    char array[3] = {'d','o','g'};
    CharLinkedList list(array, 3);
    list.pushAtFront('s');
    assert(list.elementAt(0) == 's');
    assert(list.elementAt(2) == 'o');
    assert(list.toString()== "[CharLinkedList of size 4 <<sdog>>]");
}

void pushatfrontTestingempty() {
    CharLinkedList list;
    list.pushAtFront('s');
    assert(list.elementAt(0) == 's');
    assert(list.toString()== "[CharLinkedList of size 1 <<s>>]");
}

void insertAt_empty_correct() { 
    CharLinkedList list;
    list.insertAt('a', 0);
    assert(list.size() == 1);
    assert(list.elementAt(0) == 'a');
}

void insertAt_front_singleton_list() {
    CharLinkedList list('a');
    list.insertAt('b', 0);
    assert(list.size() == 2);
    assert(list.elementAt(0) == 'b');
    assert(list.elementAt(1) == 'a');
}

void insertAtback() {
    CharLinkedList list('a');
    list.insertAt('b', 1);
    assert(list.size() == 2);
    assert(list.elementAt(1) == 'b');
    assert(list.elementAt(0) == 'a');
}

void insertAtmiddle() {
    char array[2] = {'a','c'};
    CharLinkedList list(array, 2);
    list.insertAt('b', 1);
    assert(list.size() == 3);
    assert(list.elementAt(1) == 'b');
    assert(list.elementAt(2) == 'c');
}

void removeAtTestingfromback() {
    char array[3] = {'d','o','g'};
    CharLinkedList list(array, 3);
    list.removeAt(2);
    assert(list.size() == 2);
    assert(list.elementAt(1) == 'o');
}

void removeAtTestingfromfront() {
    char array[3] = {'d','o','g'};
    CharLinkedList list(array, 3);
    list.removeAt(0);
    assert(list.size() == 2);
    assert(list.elementAt(0) == 'o');
    assert(list.elementAt(1) == 'g');
}

void removeAtTestingfrommiddle() {
    char array[3] = {'d','o','g'};
    CharLinkedList list(array, 3);
    list.removeAt(1);
    assert(list.size() == 2);
    assert(list.elementAt(1) == 'g');
}

void popfromfrontTesting() {
    char array[3] = {'d','o','g'};
    CharLinkedList list(array, 3);
    list.popFromFront();
    assert(list.size() == 2);
    assert(list.elementAt(0) == 'o');
}

void popFromFrontcatchtryTesting() {
    CharLinkedList list;
    bool thrown_error = false;

    try{ 
        list.popFromFront();
    } catch(const std::runtime_error &e) {
        thrown_error = true;
    }
    assert(thrown_error);
}

void popfromBackTesting() {
    char array[3] = {'d','o','g'};
    CharLinkedList list(array, 3);
    list.popFromBack();
    assert(list.size() == 2);
    assert(list.elementAt(1) == 'o');
}

void popFromBackcatchtryTesting() {
    CharLinkedList list;
    bool thrown_error = false;


    try{ 
        list.popFromBack();
    } catch(const std::runtime_error &e) {
        thrown_error = true;
    }
    assert(thrown_error);
}

void replaceAttesting() {
    char array[3] = {'d','o','g'};
    CharLinkedList list(array, 3);
    list.replaceAt('b', 0);
    assert(list.elementAt(0) == 'b');
}

void insertinOrdertesting() {
    char array[5] = {'A','B','C','D','E'};
    CharLinkedList list(array, 5);
    list.insertInOrder('C');
    std:: cerr << list.toString() << std::endl;
    assert(list.elementAt(3) == 'C');
}

void insertinOrdertestingmiddle() {
    char array[4] = {'A','B','D','E'};
    CharLinkedList list(array, 4);
    list.insertInOrder('C');
    assert(list.elementAt(2) == 'C');
}

void insertinOrdertestingatend() {
    char array[4] = {'A','B','D','E'};
    CharLinkedList list(array, 4);
    list.insertInOrder('F');
    assert(list.elementAt(4) == 'F');
}

void replaceAtemptytesting() {
    CharLinkedList list;
    bool thrown_error = false;

    try{ 
        list.replaceAt('c',4);
    } catch(const std::runtime_error &e) {
        thrown_error = true;
    }
    assert(thrown_error);
}

void deepcopytesting() {
    char array[3] = {'d','o','g'};
    CharLinkedList newarraylist(array, 3);
    CharLinkedList copyarraylist(newarraylist);
    
    assert(newarraylist.first() == copyarraylist.first());
    assert(newarraylist.size() == copyarraylist.size());
}

void singlecharacterconstructor() {
    CharLinkedList list('c');
    assert(list.size() == 1); 
}

void initializeconstructor() {
    CharLinkedList list;
    assert(list.size() == 0);
}

void testingconcatenate() {
    char array[3] = {'c','a','t'};
    CharLinkedList list(array, 3);
    char array2[8] = {'c','h','e','s','h','i','r','e'};
    CharLinkedList list2(array2, 8);
    list.concatenate(&list2); 
    assert(list.toString() == "[CharLinkedList of size 11 <<catcheshire>>]");
}

void testingmultipleconcatenate() {
    char array[3] = {'c','a','t'};
    CharLinkedList list(array, 3);
    char array2[8] = {'c','h','e','s','h','i','r','e'};
    CharLinkedList list2(array2, 8);
    char array3[1] = {'s',};
    CharLinkedList list3(array3, 1);
    list.concatenate(&list2); 
    list.concatenate(&list3); 
    assert(list.toString() == "[CharLinkedList of size 12 <<catcheshires>>]");
}

void testingselfconcatenating() {
    char array[3] = {'c','a','t'};
    CharLinkedList list(array, 3);
    list.concatenate(&list);
    assert(list.toString() == "[CharLinkedList of size 6 <<catcat>>]");
}

void testingconcatenatingbothempty() {
    CharLinkedList list;
    CharLinkedList list2;

    try {
        list.concatenate(&list2);
    } catch (const std::invalid_argument &e) {
        std::cerr << e.what() << std::endl;
    }

    std::string output = list.toString();
    assert(output == "[CharLinkedList of size 0 <<>>]");
}

void concatenate_tester2() {
    CharLinkedList list;
    char array2[] = {'C', 'H', 'E', 'S', 'H', 'I', 'R', 'E'};
    CharLinkedList list2(array2, 8);

    try {
        list.concatenate(&list2);
    } catch (const std::invalid_argument &e) {
        std::cerr << e.what() << std::endl;
    }

    std::string output = list.toString();
    assert(output == "[CharLinkedList of size 8 <<CHESHIRE>>]");
}

void concatenateonempty() {
    CharLinkedList list;

    char test_arr[3] = {'y','a','y'};
    CharLinkedList list2(test_arr , 3);
 
    list.concatenate(&list2);
    std::cerr << list.toString() << std::endl;
    assert(list.toString() == "[CharLinkedList of size 3 <<yay>>]");
}

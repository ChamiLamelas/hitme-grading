/*
 *  CharLinkedList.cpp
 *  YOUR NAME : Shakhrbonu Shonazarova 
 *  DATE CREATED : 02/05/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  FILE PURPOSE: This file contains the implementation of the 
 *  CharLinkedList class.
 *
 */

#include "CharLinkedList.h"

/*
 * name:      CharLinkedList
 * purpose:   Default constructor that initializes an empty linked list
 * arguments: N/A
 * returns:   N/A
 * effects:   initialized linked list
 */
CharLinkedList::CharLinkedList() {

    front = nullptr;
    back = nullptr; 
    size_l  = 0;
}

/*
 * name:      CharLinkedList
 * purpose:   Second constructor creates a one element linked list consisting 
 *            of the user provided character 
 * arguments: a character 
 * returns:   N/A
 * effects:   a one element linked list
 */
CharLinkedList::CharLinkedList(char c) {

    front = nullptr;
    back = nullptr; 
    size_l  = 0;

    Node *new_node = new Node;
    new_node->chars = c; 
    front = new_node; 
    back = new_node;
    new_node->next = nullptr; 
    new_node->previous = nullptr; 
    size_l++; 
}

/*
 * name:      CharLinkedList
 * purpose:   third constructor creates a linked list containing the 
 *            the characters from the user provided array.
 * arguments: array of character and integer size of the array
 * returns:   N/A
 * effects:   a linked list of user provided size containing characters
 *            provided by the user.
 */
CharLinkedList::CharLinkedList(char arr[], int size) {

    size_l  = 0;
    front = nullptr;
    back = nullptr; 

    for (int i = 0; i < size; i++) {
        pushAtBack(arr[i]); 
    }
}

/*
 * name:      CharLinkedList
 * purpose:   copy constructor for the class that makes a deep copy of a 
 *            given instance
 * arguments: address of the CharLinkedList
 * returns:   N/A
 * effects:   a deep copy of the CharLinkedList class
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other) {

    size_l = 0; 
    front = nullptr;
    back = nullptr;

    Node *curr = other.front; 
    if (other.front == nullptr) {
        return;
    } else {
        while (curr != nullptr) {
        pushAtBack(curr->chars); 
        curr = curr->next; 
        }
    }
}

/*
 * name:      ~CharLinkedList
 * purpose:   destructor that destroys recycles all heap-allocated 
 *            data in the current linked list
 * arguments: N/A
 * returns:   N/A
 * effects:   no memory loss and ssues with valgrind 
 */
CharLinkedList::~CharLinkedList() {

    Node *curr = this->front; 
    helper_destructor(curr); 
    
}

/*
 * name:      CharLinked List &operator=
 * purpose:   recycles the storage associated with the instance
 *            on the left of the assignment and makes a deep copy of 
 *            the instance on the right hand side into
 *            the instance on the left hand side
 * arguments: address of the CharLinkedList 
 * returns:   A copy of CharLinkedList
 * effects:   a deep copy of the CharLinkedList class 
 */
CharLinkedList& CharLinkedList::operator=(const CharLinkedList &other) {

    if (this == &other) {
        return *this; 
    }

    clear(); 
    size_l = 0; 
    front = nullptr;
    back = nullptr;

    Node *curr = other.front; 
    if (other.front == nullptr) {
        return *this;
    } else {
        while (curr != nullptr) {
        pushAtBack(curr->chars); 
        curr = curr->next; 
        }
    }

    return *this; 
}

/*
 * name:      isEmpty
 * purpose:   checks whether the specific instance of the CharLinkedList
 *            is empty
 * arguments: N/A
 * returns:   boolean value 
 * effects:   lets the user know whether the object is empty or not 
 */
bool CharLinkedList::isEmpty() const {

    return size_l == 0; 
}

/*
 * name:      clear 
 * purpose:   makes the class instance into an empty linked list
 * arguments: N/A
 * returns:   N/A 
 * effects:   an empty linked list 
 */
void CharLinkedList::clear() {    

    Node *curr = this->front; 

    helper_destructor(curr); 

    front = nullptr;
    back = nullptr; 
    size_l = 0;
}

/*
 * name:      size
 * purpose:   determines the size of the linked list by determining 
 *            the number of nodes that the lists consists of 
 * arguments: N/A
 * returns:   integer value 
 * effects:   lets the user know the size of the linked list 
 */
int CharLinkedList::size() const {

    return size_l; 
}

/*
 * name:      first
 * purpose:   determines the first character in the linked list and throws an 
 *            error if the linked list is empty 
 * arguments: N/A
 * returns:   character 
 * effects:   lets the user know the first character of the linked list 
 */
char CharLinkedList::first() const {

    if (size_l == 0) {
        throw std::runtime_error ("cannot get first of empty LinkedList");    
    } else {
        return this->front->chars;
    } 
}

/*
 * name:      last
 * purpose:   determines the last character in the linked list and throws an 
 *            error if the linked list is empty 
 * arguments: N/A
 * returns:   character 
 * effects:   lets the user know the last character of the linked list 
 */
char CharLinkedList::last() const {

    if (size_l == 0) {
        throw std::runtime_error ("cannot get last of empty LinkedList");    
    } else {
        return this->back->chars;
    }
}

/*
 * name:      elementAt
 * purpose:   determines the the element (character) in the linked
 *            list at a user provided index
 * arguments: integer index 
 * returns:   character 
 * effects:   lets the user know the character of the linkedlist at a  
 *            given index 
 */
char CharLinkedList::elementAt(int index) const {

    if (index < 0 or size_l - 1 < index) {
        throw std::range_error ("index (" + std::to_string(index) + ")" + 
        " not in range [0.." + std::to_string(size_l) +")"); 
    } else {
        Node *curr = front; 
        return helper_elementAt(curr, index, 0); 
    }
}

/*
 * name:      toString
 * purpose:   creates a string which contains the characters 
 *            of the CharLinkedList
 * arguments: N/A
 * returns:   std::string
 * effects:   string containing characters from the linked list  
 */
std::string CharLinkedList::toString() const {

    std::stringstream ss;
    ss << "[CharLinkedList of size " << size_l;
    ss << " <<";

    Node *curr = this->front;
    while (curr != nullptr) {
        ss << curr->chars;
        curr = curr->next;
    }

    ss << ">>]"; 
    return ss.str();
}

std::string CharLinkedList::toReverseString() const {

    std::stringstream ss;
    ss << "[CharLinkedList of size " << size_l;
    ss << " <<";

    Node *curr = this->back;
    while (curr != nullptr) {
        ss << curr->chars;
        curr = curr->previous;
    }

    ss << ">>]"; 
    return ss.str();
}
/*
 * name:      pushAtBack 
 * purpose:   inserts the user given new element after the end of the 
 *            existing elements of the linked list
 * arguments: character 
 * returns:   N/A
 * effects:   updated linked list with a greater size and a new character
 *            at the end   
 */
void CharLinkedList::pushAtBack(char c) {

    Node* new_node = new Node;
    new_node->next = nullptr; 

    if (back == nullptr) {
        new_node->chars = c; 
        back = new_node; 
        front = new_node; 
        new_node->next = nullptr; 
        new_node->previous = nullptr; 
        size_l++; 
    } else {
        new_node->previous = back; 
        new_node->chars = c;
        back->next = new_node; 
        back = new_node;
        size_l++; 
    }
}

/*
 * name:      pushAtFront 
 * purpose:   inserts the user given new element after the front of the 
 *            existing elements of the linked list
 * arguments: character 
 * returns:   N/A
 * effects:   updated linked list with a greater size and a new character
 *            at the front
 */
void CharLinkedList::pushAtFront(char c) {

    Node* new_node = new Node;
    new_node->previous = nullptr; 

    if (front == nullptr) {
        new_node->chars = c; 
        back = new_node; 
        front = new_node; 
        new_node->next = nullptr; 
        new_node->previous = nullptr; 
        size_l++; 
    } else {
        new_node->next = front; 
        new_node->chars = c;
        front->previous = new_node; 
        front = new_node;
        size_l++; 
    }
}

/*
 * name:      insertAt
 * purpose:   inserts the new element at the user specified index. Throws 
 *            an error if the index is out of range 
 * arguments: character, integer index 
 * returns:   N/A
 * effects:   updated linked list with a greater size and a new character
 *            at the specified index 
 */
void CharLinkedList::insertAt(char c, int index) {

    if (index < 0 or index > size_l) {
        throw std::range_error ("index (" + std::to_string(index) + ")" + 
        " not in range [0.." + std::to_string(size_l) +"]");
        
    } else if (index == size_l - 1 and index != 0 or index == size_l) {
        pushAtBack(c);  

    } else if (index == 0) {
        pushAtFront(c); 

    } else {
        int count = 0; 
        Node *curr = front; 
        while (count != index - 1) {
            curr = curr->next; 
            count++; 
        }
        Node* new_node = new Node;
        new_node->chars = c; 
        new_node->next = curr->next; 
        new_node->previous = curr; 
        curr->next = new_node; 
        new_node->next->previous = new_node; 
        size_l++; 
    }
}

/*
 * name:      insertInOrder 
 * purpose:   inserts the user provided character into the linked list 
 *            in ASCII order
 * arguments: character 
 * returns:   N/A
 * effects:   updated linked list with a greater size and a new character
 *            at the first correct index according to the ASCII order 
 */
void CharLinkedList::insertInOrder(char c) {

    Node *curr = front; 
    if (curr == nullptr) {
        insertAt(c, 0); 
    } else {
        while (c > curr->chars and curr->next != nullptr) {
        curr = curr->next;
    }
    if (curr->previous == nullptr and c <= curr->chars) {
        pushAtFront(c);

    } else if (curr->next == nullptr and c > curr->chars) {
        pushAtBack(c); 

    } else {
        Node* new_node = new Node; 
        new_node->chars = c; 
        new_node->next = curr; 
        new_node->previous = curr->previous;
        curr->previous->next = new_node; 
        curr->previous = new_node; 
        size_l++;  
    }
    }
    
     
}

/*
 * name:      popFromFront 
 * purpose:   removes the first element from the linked list and 
 *            throws an error if it is an empty linked list 
 * arguments: N/A
 * returns:   N/A
 * effects:   updated linked list with a smaller size without the 
 *            previous first element 
 */
void CharLinkedList::popFromFront() {

    if (isEmpty()) {
        throw std::runtime_error ("cannot pop from empty LinkedList");

    } else if (front->next == nullptr){
        delete front; 
        size_l--;
        front = nullptr; 
        back = nullptr; 
    } else {
        front = front->next; 
        delete front->previous; 
        front->previous = nullptr; 
        size_l--; 
    }
}

/*
 * name:      popFromBack
 * purpose:   removes the last element from the linked list and 
 *            throws an error if it is an empty linked list 
 * arguments: N/A
 * returns:   N/A
 * effects:   updated linked list with a smaller size without the 
 *            previous last element 
 */
void CharLinkedList::popFromBack() {

    if (isEmpty()) {
        throw std::runtime_error ("cannot pop from empty LinkedList");

    } else if (back->previous == nullptr) {
        delete back; 
        size_l--;
        front = nullptr; 
        back = nullptr; 
    } else {
        back = back->previous; 
        delete back->next; 
        back->next = nullptr; 
        size_l--; 
    }
}

/*
 * name:      removeAt 
 * purpose:   removes the element at the user specified index and throws 
 *            an error if the index is out of range 
 * arguments: integer index 
 * returns:   N/A
 * effects:   updated array list with a smaller size without the previous 
 *            element 
 */
void CharLinkedList::removeAt(int index) {

    if (index < 0 or index > size_l - 1) {
        throw std::range_error ("index (" + std::to_string(index) + ")" + 
        " not in range [0.." + std::to_string(size_l) +")");

    } else if (index == size_l - 1 and index != 0 or index == size_l) {
        popFromBack();  

    } else if (index == 0) {
        popFromFront();  

    } else {
        int count = 0; 
        Node *curr = front; 
        while (count != index) {
            curr = curr->next; 
            count++; 
        }
        curr->previous->next = curr->next; 
        curr->next->previous = curr->previous; 
        delete curr; 
        size_l--; 
    }
}

/*
 * name:      replaceAt
 * purpose:   replaces the element at the user specified index with the 
 *            new user provided element
 * arguments: character, integer index 
 * returns:   N/A
 * effects:   updated linked list with the same size with a new
 *            element 
 */
void CharLinkedList::replaceAt(char c, int index) {

    if (index < 0 or size_l - 1 < index) {
        throw std::range_error ("index (" + std::to_string(index) + ")" + 
        " not in range [0.." + std::to_string(size_l) +")"); 

    } else {
        Node *curr = front; 
        helper_replaceAt(curr, index, 0, c); 
    }
}

/*
 * name:      concatenate 
 * purpose:   adds a copy of the linked list pointed to by the parameter value 
 *            to the end of the linked list the function was called from 
 * arguments: pointer to a second CharLinkedList
 * returns:   N/A
 * effects:   a linkedlist consiting of 2 joined linkedlists
 */
void CharLinkedList::concatenate(CharLinkedList *other) {

    int count = 0; 
    int size_holder = other->size_l; 

    if (other->front == nullptr) {
        return;
    } else {
        Node *curr = other->front; 
        while (size_holder - 1 >= count) {
        pushAtBack(curr->chars); 
        curr = curr->next; 
        count++; 
        }
    }
}

/*
 * name:      helper_destructor
 * purpose:   recursiveley deletes all the memory allocated for the 
 *            linked list 
 * arguments: pointer to the front node of the CharLinkedList 
 * returns:   N/A
 * effects:   no memory loss and ssues with valgrind   
 */
void CharLinkedList::helper_destructor(Node *curr) {

    if (curr == nullptr) {
        return; 
    } else {
        helper_destructor(curr->next); 
        delete curr; 
    }
}

/*
 * name:      helper_elementAt
 * purpose:   recursiveley visits each link and counts 
 * arguments: pointer to the first node of the CharLinkedList, index and count 
 * returns:   N/A
 * effects:   character at a user provided index 
 */
char CharLinkedList::helper_elementAt(Node *curr, int index, int count) const { 
    
    if (count == index) {
        return curr->chars; 
    } else { 
        return helper_elementAt(curr->next, index, count + 1); 
    }
}

/*
 * name:      helper_replaceAt
 * purpose:   recursiveley visits each link and counts 
 * arguments: pointer to the first node of the CharLinkedList, index and count 
 * returns:   N/A
 * effects:   updated linked list with a user provided character at at 
 *            user specified index 
 */
void CharLinkedList::helper_replaceAt(Node *curr, int index, int count, char c) 
                                      const { 
    if (count == index) {
        curr->chars = c; 
    } else { 
        helper_replaceAt(curr->next, index, count + 1, c); 
    }
}
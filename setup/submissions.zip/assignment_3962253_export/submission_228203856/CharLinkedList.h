/*
 *  CharLinkedList.h
 *  YOUR NAME : Shakhrbonu Shonaarova 
 *  DATE CREATED : 02/05/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  FILE PURPOSE: Contains the declarations of the CharLinkedList 
 *                class members.
 *
 */

#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H
#include <string>
#include <sstream>
#include <iostream>

class CharLinkedList {
    public: 
    CharLinkedList();
    CharLinkedList(char c); 
    CharLinkedList(char arr[], int size); 
    CharLinkedList(const CharLinkedList &other); 
    ~CharLinkedList();
    CharLinkedList &operator=(const CharLinkedList &other); 
    bool isEmpty() const; 
    void clear();
    int size() const; 
    char first() const;
    char last() const;
    char elementAt(int index) const;
    std::string toString() const;
    std::string toReverseString() const;
    void pushAtBack(char c); 
    void pushAtFront(char c);
    void insertAt(char c, int index);
    void insertInOrder(char c);
    void popFromFront();
    void popFromBack();
    void removeAt(int index);
    void replaceAt(char c, int index);
    void concatenate(CharLinkedList *other);

    private: 
    struct Node {

        char chars; 
        Node *previous;
        Node *next; 

    };

    Node *front; 
    Node *back; 
    int size_l; 
    void helper_destructor(Node *curr);
    char helper_elementAt(Node *curr, int index, int count) const;
    void helper_replaceAt(Node *curr, int index, int count, char c) const; 

};

#endif

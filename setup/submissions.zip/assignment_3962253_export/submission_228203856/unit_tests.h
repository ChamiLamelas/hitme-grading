/*
 *  unit_tests.h
 *  YOUR NAME: Shakhrbonu Shonazarova 
 *  DATE CREATED: 02/05/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  FILE PURPOSE: To test the implementations of the CharLinkedList class 
 *
 */

#include "CharLinkedList.h"
#include <cassert>
#include <iostream>

/*
 * constructor test 0
 * Make sure no fatal errors/memory leaks in the default constructor
 */
void constructor_test0() {

    CharLinkedList list;
}

/*
 * constructor2_test0
 * Make sure no fatal errors/memory leaks in the default constructor
 * Make sure the toString function prints the right thing for an empty 
 * linked list 
 */
void constructor2_test0() {

    CharLinkedList list;

    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}

/*
 * constructor2_test1
 * Make sure no fatal errors/memory leaks in the default constructor
 * Make sure it successfully updates the linked list  
 */
void constructor2_test1() {

    CharLinkedList list('a');

    assert(list.toString() == "[CharLinkedList of size 1 <<a>>]");
}

/*
 * constructor3_test0
 * Make sure no fatal errors/memory leaks in the default constructor
 * Make sure it successfully updates the linked list  
 */
void constructor3_test0() {

    char my_array[5] ={'a','l','i','c','e'}; 
    CharLinkedList list(my_array, 5);

    assert(list.toString() == "[CharLinkedList of size 5 <<alice>>]");
}

/*
 * constructor3_test1_singleElementArray
 * Make sure no fatal errors/memory leaks in the default constructor
 * Make sure it successfully updates the linked list  
 */
void constructor3_test1_singleElementArray() {

    char my_array[1] ={'a'}; 
    CharLinkedList list(my_array, 1);

    assert(list.toString() == "[CharLinkedList of size 1 <<a>>]");
}

/*
 * size_test
 * Make sure it successfully returns the size of the linked list 
 */
void size_test() {

    char my_array[5] ={'a','l','i','c','e'}; 
    CharLinkedList list(my_array, 5);

    assert(list.size() == 5); 
}

/*
 * isEmpty_test
 * Make sure it return true when called on an empty linked list 
 */
void isEmpty_test() {

    CharLinkedList list;

    assert(list.isEmpty()); 
}

/*
 * clear_test
 * Make sure it successfully clears the linked list 
 */
void clear_test() {

    char my_array[5] ={'a','l','i','c','e'}; 
    CharLinkedList list(my_array, 5);

    list.clear(); 
    assert(list.size() == 0); 
}

/*
 * clear_test_one_element 
 * Make sure it successfully clears the linked list 
 */
void clear_test_one_element () {

    CharLinkedList list('d');

    list.clear(); 
    assert(list.size() == 0); 
}


/*
 * clear_test_on_empty
 * Make sure it successfully return when the linked list is empty  
 */
void clear_test_on_empty() {

    CharLinkedList list;

    list.clear(); 
    assert(list.size() == 0); 
}

/*
 * first_test
 * Make sure it returns the correct character when the user wants to 
 * access the first element 
 */
void first_test() {

    char my_array[5] ={'a','l','i','c','e'}; 
    CharLinkedList list(my_array, 5);

    assert(list.first() == 'a'); 
}

/*
 * first_test_singleElementArray
 * Make sure it returns the correct character when the user wants to 
 * access the first element 
 */
void first_test_singleElementArray() {
 
    CharLinkedList list('a');

    assert(list.first() == 'a'); 
}

/*
 * first_error
 * Make sure it throws an error when the first function is not able to 
 * successfully return the first character of the array list 
 */
void first_error() {
    bool runtime_error_thrown = false; 

    std::string error_message = ""; 

    CharLinkedList list; 
    try {
        list.first(); 
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true; 
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot get first of empty LinkedList"); 
}

/*
 * last_test
 * Make sure it returns the correct character when the user wants to 
 * access the first element 
 */
void last_test() {

    char my_array[5] ={'a','l','i','c','e'}; 
    CharLinkedList list(my_array, 5);

    assert(list.last() == 'e'); 
}

/*
 * last_test_SingleElementArray
 * Make sure it returns the correct character when the user wants to 
 * access the first element 
 */
void last_test_SingleElementArray() {

    CharLinkedList list('e');

    assert(list.last() == 'e'); 
}

/*
 * first_error
 * Make sure it throws an error when the last function is not able to 
 * successfully return the first character of the array list 
 */
void last_error() {
    bool runtime_error_thrown = false; 

    std::string error_message = ""; 

    CharLinkedList list; 
    try {
        list.last(); 
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true; 
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot get last of empty LinkedList"); 
}

/*
 * ToString_test
 * Make sure it successfully creates a string containing the characters 
 * of the CharLinkedList 
 */
void ToString_test() {

    char my_array[6] ={'k','o','r','o','v','a'}; 
    CharLinkedList list(my_array, 6);

    assert(list.toString() == "[CharLinkedList of size 6 <<korova>>]");
}

/*
 * ToString_test_Empty
 * Make sure it successfully prints the message for an empty string 
 */
void ToString_test_Empty() {
 
    CharLinkedList list;

    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}

/*
 * reverseToString_test
 * Make sure it successfully creates a string containing the characters 
 * of the CharLinkedList in reverse
 */
void reverseToString_test() {

    char my_array[5] ={'a','l','i','c','e'}; 
    CharLinkedList list(my_array, 5);

    assert(list.toReverseString() == "[CharLinkedList of size 5 <<ecila>>]");
}

/*
 * reverseToString_test_SingleElement
 * Make sure it successfully creates a string containing the characters 
 * of the CharLinkedList in reverse
 */
void reverseToString_test_SingleElement() {
 
    CharLinkedList list('b');

    assert(list.toReverseString() == "[CharLinkedList of size 1 <<b>>]");
}

/*
 * elementAt_test
 * Make sure it returns the correct character when the user wants to 
 * access the element at a particular index (in the middle)
 */
void elementAt_test() {

    char my_array[5] ={'a','l','i','c','e'}; 
    CharLinkedList list(my_array, 5);

    assert(list.elementAt(2) == 'i'); 
}

/*
 * elementAt_error
 * Make sure it throws an error when the elementAt function is not able to 
 * successfully return the character at the user provided index 
 * of the linked list 
 */
void elementAt_error() {
    bool range_error_thrown = false; 

    std::string error_message = ""; 

    char my_array[5] ={'a','l','i','c','e'}; 
    CharLinkedList list(my_array, 5); 
    try {
        list.elementAt(21); 
    }
    catch (const std::range_error &e) {
        range_error_thrown = true; 
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (21) not in range [0..5)"); 
}

/*
 * elementAt_error_empty
 * Make sure it throws an error when the elementAt function is not able to 
 * successfully return the character at the user provided index 
 * of the linked list 
 */
void elementAt_error_empty() {
    bool range_error_thrown = false; 

    std::string error_message = "";  
    CharLinkedList list; 
    try {
        list.elementAt(2); 
    }
    catch (const std::range_error &e) {
        range_error_thrown = true; 
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (2) not in range [0..0)"); 
}

/*
 * elementAt_error_indexNegative
 * Make sure it throws an error when the elementAt function is not able to 
 * successfully return the character at the user provided index 
 * of the linked list 
 */
void elementAt_error_indexNegative() {
    bool range_error_thrown = false; 

    std::string error_message = "";  
    CharLinkedList list('r'); 
    try {
        list.elementAt(-1); 
    }
    catch (const std::range_error &e) {
        range_error_thrown = true; 
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (-1) not in range [0..1)"); 
}

/*
 * elementAt_test_first
 * Make sure it returns the correct character when the user wants to 
 * access the element at a particular index (first)
 */
void elementAt_test_first() {

    char my_array[5] ={'a','l','i','c','e'}; 
    CharLinkedList list(my_array, 5);

    assert(list.elementAt(0) == 'a'); 
}

/*
 * elementAt_test_last
 * Make sure it returns the correct character when the user wants to 
 * access the element at a particular index (last)
 */
void elementAt_test_last() {

    char my_array[5] ={'a','l','i','c','e'}; 
    CharLinkedList list(my_array, 5);

    assert(list.elementAt(4) == 'e'); 
}

/*
 * pushAtFront_test1_Empty
 * Make sure it successfully updates an empty linked list by inserting  
 * a character at the front of the list  
 */
void pushAtFront_test1_Empty() {

    CharLinkedList list;
    list.pushAtFront('a'); 

    assert(list.toString() == "[CharLinkedList of size 1 <<a>>]");
}

/*
 * pushAtFront_test2
 * Make sure it successfully updates the linked list  
 */
void pushAtFront_test2() {

    char my_array[5] ={'a','l','i','c','e'}; 
    CharLinkedList list(my_array, 5);

    list.pushAtFront('r'); 

    assert(list.toString() == "[CharLinkedList of size 6 <<ralice>>]");
}

/*
 * pushAtFront_test1_multiple
 * Make sure it successfully updates an empty linked list by inserting  
 * a character at the front of the list  
 */
void pushAtFront_test1_multiple() {

    CharLinkedList list;
    list.pushAtFront('a'); 
    list.pushAtFront('b');
    list.pushAtFront('c');

    assert(list.toString() == "[CharLinkedList of size 3 <<cba>>]");
}

/*
 * pushAtBack_test1_Empty
 * Make sure it successfully updates an empty linked list by inserting  
 * a character at the back of the list  
 */
void pushAtBack_test1_Empty() {

    CharLinkedList list;
    list.pushAtBack('a'); 

    assert(list.toString() == "[CharLinkedList of size 1 <<a>>]");
} 

/*
 * pushAtBack_test2
 * Make sure it successfully updates the linked list  
 */
void pushAtBack_test2() {

    char my_array[5] ={'a','l','i','c','e'}; 
    CharLinkedList list(my_array, 5);

    list.pushAtBack('r'); 

    assert(list.toString() == "[CharLinkedList of size 6 <<alicer>>]");
}

/*
 * pushAtBack_test1_multiple
 * Make sure it successfully updates an empty linked list by inserting  
 * a character at the front of the list  
 */
void pushAtBack_test1_multiple() {

    CharLinkedList list;
    list.pushAtBack('a'); 
    list.pushAtBack('b');
    list.pushAtBack('c');

    assert(list.toString() == "[CharLinkedList of size 3 <<abc>>]");
}

/*
 * popFromFront_test
 * Make sure it successfully removes the caharcter from the front of the 
 * linked list  
 */
void popFromFront_test() {

    char my_array[5] ={'a','l','i','c','e'}; 
    CharLinkedList list(my_array, 5);

    list.popFromFront(); 

    assert(list.toString() == "[CharLinkedList of size 4 <<lice>>]");
}

/*
 * popFromFront_error
 * Make sure it throws an error when the popFromFront function is not able to 
 * successfully remove the first character of the linked list 
 */
void popFromFront_error() {
    bool runtime_error_thrown = false; 

    std::string error_message = ""; 

    CharLinkedList list; 
    try {
        list.popFromFront(); 
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true; 
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList"); 
}

/*
 * popFromBack_test
 * Make sure it successfully removes the caharcter from the back of the 
 * linked list  
 */
void popFromBack_test() {

    char my_array[4] ={'b','o','n','u'}; 
    CharLinkedList list(my_array, 4);

    list.popFromBack(); 

    assert(list.toString() == "[CharLinkedList of size 3 <<bon>>]");
}

/*
 * popFromBack_error
 * Make sure it throws an error when the popFromFront function is not able to 
 * successfully remove the first character of the linked list 
 */
void popFromBack_error() {
    bool runtime_error_thrown = false; 

    std::string error_message = ""; 

    CharLinkedList list; 
    try {
        list.popFromBack(); 
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true; 
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList"); 
}

/*
 * popFromFront_test_one_node
 * Make sure it successfully removes the caharcter from the 
 * linked list with only one node
 */
void popFromFront_test_one_node() { 

    CharLinkedList list('a');

    list.popFromFront(); 

    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}

/*
 * popFromBack_test_one_node
 * Make sure it successfully removes the caharcter from the the 
 * linked list with only one node 
 */
void popFromBack_test_one_node() { 

    CharLinkedList list('z');

    list.popFromBack(); 

    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}

/*
 * insertAt_test
 * Make sure it successfully adds a character at the user provided index 
 */
void insertAt_test() {

    char my_array[5] ={'a','l','i','c','e'}; 
    CharLinkedList list(my_array, 5);

    list.insertAt('b', 2); 

    assert(list.toString() == "[CharLinkedList of size 6 <<albice>>]");
}

/*
 * insertAt_error
 * Make sure it throws an error when the insertAt function is not able to 
 * successfully replaces the caharcter at the user
 * provided index of the linked list
 */
void insertAt_error() {
    bool range_error_thrown = false; 

    std::string error_message = ""; 

    CharLinkedList list; 
    try {
        list.insertAt('a', 21); 
    }
    catch (const std::range_error &e) {
        range_error_thrown = true; 
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (21) not in range [0..0]"); 
}

// Tests correct insertion into an empty LL.
// Afterwards, size should be 1 and element at index 0
// should be the element we inserted.
void insertAt_empty_correct() { 

    CharLinkedList list;

    list.insertAt('a', 0);

    assert(list.size() == 1);
    assert(list.elementAt(0) == 'a'); 

}

// Tests correct insertAt for front of 1-element list.
void insertAt_front_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at front
    test_list.insertAt('b', 0);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'a');
    
}

// Tests correct insertAt for back of 1-element list.
void insertAt_back_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at back
    test_list.insertAt('b', 1);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    
}

// Tests calling insertAt for a large number of elements.
// Not only does this test insertAt, it also checks that
// array expansion works correctly.
void insertAt_many_elements() {
    
    CharLinkedList test_list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.insertAt('a', i);
    }

    assert(test_list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
    
}

// Tests insertion into front of a larger list
void insertAt_front_large_list() {
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    test_list.insertAt('y', 0);

    assert(test_list.size() == 10);
    assert(test_list.elementAt(0) == 'y');
    assert(test_list.toString() == 
    "[CharLinkedList of size 10 <<yabczdefgh>>]");
}

// Tests insertion into the back of a larger list
void insertAt_back_large_list() {

    char test_arr[10] = { 'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 10);  

    test_list.insertAt('x', 10);

    assert(test_list.size() == 11);
    assert(test_list.elementAt(10) == 'x');
    assert(test_list.toString() == 
    "[CharLinkedList of size 11 <<yabczdefghx>>]"); 

}

// Tests insertion into the middle of a larger list
void insertAt_middle_large_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.insertAt('z', 3);

    assert(test_list.size() == 9);
    assert(test_list.elementAt(3) == 'z');
    assert(test_list.toString() ==     
    "[CharLinkedList of size 9 <<abczdefgh>>]");

}

// Tests out-of-range insertion for a non-empty list.
void insertAt_nonempty_incorrect() {
   
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8]");
    
}

/*
 * insertInOrder_test
 * Make sure it successfully adds a character to the linked list 
 * in the correct ASCII order  
 */
void insertInOrder_test() {

    char my_array[5] ={'a','c','d','e','f'}; 
    CharLinkedList list(my_array, 5);

    list.insertInOrder('b'); 

    assert(list.toString() == "[CharLinkedList of size 6 <<abcdef>>]");
}

/*
 * insertInOrder_AtFront_test
 * Make sure it successfully adds a character to the front of the linked list  
 */
void insertInOrder_AtFront_test() {

    char my_array[7] ={'s','h','i','s','h','k','a'}; 
    CharLinkedList list(my_array, 7);

    list.insertInOrder('r'); 

    assert(list.toString() == "[CharLinkedList of size 8 <<rshishka>>]");
}

/*
 * insertInOrder_AtEnd_test
 * Make sure it successfully adds a character to the back of the linked list  
 */
void insertInOrder_AtEnd_test() {

    char my_array[7] ={'a','b','c','d','x','f','h'}; 
    CharLinkedList list(my_array, 7);

    list.insertInOrder('z'); 

    assert(list.toString() == "[CharLinkedList of size 8 <<abcdxfhz>>]");
}

/*
 * insertInOrder_SameChars_test
 * Make sure it successfully adds a character to the linked list 
 * in the correct ASCII order   
 */
void insertInOrder_SameChars_test() {

    char my_array[7] ={'a','a','a','a','a','b','a'}; 
    CharLinkedList list(my_array, 7);

    list.insertInOrder('a'); 

    assert(list.toString() == "[CharLinkedList of size 8 <<aaaaaaba>>]");
}

/*
 * insertInOrder_specialChars_test
 * Make sure it successfully adds a character to the linked list 
 * in the correct ASCII order   
 */
void insertInOrder_specialChars_test() {

    char my_array[7] ={'2','1','!','a','S','b','A'}; 
    CharLinkedList list(my_array, 7);

    list.insertInOrder('?'); 

    assert(list.toString() == "[CharLinkedList of size 8 <<21!?aSbA>>]");
}

/*
 * insertInOrder_Many
 * successfully works for many insertions 
 */
void insertInOrder_Many(){
    CharLinkedList list;

    list.insertInOrder('a');
    list.insertInOrder('d');
    list.insertInOrder('b');

    assert(list.toString() == "[CharLinkedList of size 3 <<abd>>]");
}

/*
 * removeAt_test
 * Make sure it successfully removes the caharcter at the user 
 * provided index of the linked list
 */
void removeAt_test() {

    char my_array[5] ={'a','l','i','c','e'}; 
    CharLinkedList list(my_array, 5);

    list.removeAt(2); 

    assert(list.toString() == "[CharLinkedList of size 4 <<alce>>]");
}

/*
 * removeAt_Front_test
 * Make sure it successfully removes the caharcter at the user 
 * provided index of the linked list
 */
void removeAt_Front_test() {

    char my_array[5] ={'a','l','i','c','e'}; 
    CharLinkedList list(my_array, 5);

    list.removeAt(0); 

    assert(list.toString() == "[CharLinkedList of size 4 <<lice>>]");
}

/*
 * removeAt_Back_test
 * Make sure it successfully removes the caharcter at the user 
 * provided index of the linked list
 */
void removeAt_Back_test() {

    char my_array[5] ={'a','l','i','c','e'}; 
    CharLinkedList list(my_array, 5);

    list.removeAt(4); 

    assert(list.toString() == "[CharLinkedList of size 4 <<alic>>]");
}

// Tests out-of-range removal for a non-empty list.
void removeAt_nonempty_incorrect() {
   
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.removeAt(33);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (33) not in range [0..8)");
    
}

/*
 * replaceAt_test
 * Make sure it successfully replaces the caharcter at the user
 * provided index of the linked list 
 */
void replaceAt_test() {

    char my_array[5] ={'a','l','i','c','e'}; 
    CharLinkedList list(my_array, 5);

    list.replaceAt('e', 2); 

    assert(list.toString() == "[CharLinkedList of size 5 <<alece>>]");
}

/*
 * replaceAtFront_test
 * Make sure it successfully replaces the caharcter at the user
 * provided index of the linked list 
 */
void replaceAtFront_test() {

    char my_array[5] ={'a','l','i','c','e'}; 
    CharLinkedList list(my_array, 5);

    list.replaceAt('e', 0); 

    assert(list.toString() == "[CharLinkedList of size 5 <<elice>>]");
}

/*
 * replaceAt_error
 * Make sure it throws an error when the replaceAt function is not able to 
 * successfully replaces the caharcter at the user
 * provided index of the array list
 */
void replaceAt_error() {
    bool range_error_thrown = false; 

    std::string error_message = ""; 

    CharLinkedList list; 
    try {
        list.replaceAt('a', 21); 
    }
    catch (const std::range_error &e) {
        range_error_thrown = true; 
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (21) not in range [0..0)"); 
}

/*
 * replaceAt_error_(Size)
 * Make sure it throws an error when the replaceAt function is not able to 
 * successfully replaces the caharcter at the user
 * provided index of the array list
 */
void replaceAt_error_Size() {
    bool range_error_thrown = false; 

    std::string error_message = ""; 

    CharLinkedList list('b'); 
    try {
        list.replaceAt('a', 1); 
    }
    catch (const std::range_error &e) {
        range_error_thrown = true; 
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (1) not in range [0..1)"); 
}

/*
 * copy_constructor_test 
 * Make sure it successfully creates a copy of the linked List 
 */
void copy_constructor_test() {

    char my_array[5] ={'a','l','i','c','e'}; 
    CharLinkedList list2(my_array, 5);
    CharLinkedList list1(list2); 

    assert(list1.toString() == "[CharLinkedList of size 5 <<alice>>]");
    assert(list2.toString() == "[CharLinkedList of size 5 <<alice>>]");
}

/*
 * copy_constructor_empty_test 
 * Make sure it successfully creates a copy of the linked List 
 */
void copy_constructor_empty_test() {
    CharLinkedList list2;
    CharLinkedList list1(list2); 

    assert(list1.toString() == "[CharLinkedList of size 0 <<>>]");
    assert(list2.toString() == "[CharLinkedList of size 0 <<>>]");
}

/*
 * assignment_operator_test1_empty
 * Make sure it successfully copies the values of one linked List to an 
 * empty one  
 */
void assignment_operator_test1_empty() { 

    CharLinkedList list1;
    char my_array2[5] ={'a','l','i','c','e'}; 

    CharLinkedList list2(my_array2, 5);
    
    list1 = list2; 

    assert(list1.toString() == "[CharLinkedList of size 5 <<alice>>]");
}

/*
 * assignment_operator_test2_DiffSize
 * Make sure it successfully copies the values of one object to the other
 * when the objects are linked lists of different sizes  
 */
void assignment_operator_test2_DiffSize() {

    char my_array[6] ={'a','m','b','e','r','a'}; 
    CharLinkedList list1(my_array, 6);

    char my_array2[4] ={'l','o','l','a'}; 
    CharLinkedList list2(my_array2, 4);
    
    list1 = list2; 

    assert(list1.toString() == "[CharLinkedList of size 4 <<lola>>]");
}

/*
 * assignment_operator_test_SameSize
 * Make sure it successfully copies the values of one object to the other
 * when the objects are array lists of same size  
 */
void assignment_operator_test_SameSize() {

    char my_array[5] ={'a','l','i','c','b'}; 
    CharLinkedList list1(my_array, 5);

    char my_array2[5] ={'a','l','i','c','e'}; 
    CharLinkedList list2(my_array2, 5);
    
    list1 = list2; 

    assert(list1.toString() == "[CharLinkedList of size 5 <<alice>>]");
}

/*
 * concanete_test
 * Make sure it successfully adds all the elements of the linked list pointed 
 * to by the parameter value to the end of the linked list the function 
 * was called from
 */
void concanete_test() {
    char my_array[5] ={'a','l','i','c','e'}; 
    CharLinkedList list1(my_array, 5);

    char my_array2[4] ={'p','o','k','a'}; 
    CharLinkedList list2(my_array2, 4);

    list1.concatenate(&list2); 

    assert(list1.toString() == "[CharLinkedList of size 9 <<alicepoka>>]");
}

/*
 * concanete_test1
 * Make sure it successfully adds all the elements of the linked list pointed 
 * to by the parameter value to the end of the linked list the function 
 * was called from
 */
void concanete_test1() {
    char my_array[3] ={'c','a','t'}; 
    CharLinkedList list1(my_array, 3);

    char my_array2[8] ={'C','H','E','S','H','I','R','E'}; 
    CharLinkedList list2(my_array2, 8);

    list1.concatenate(&list2); 

    assert(list1.toString() == "[CharLinkedList of size 11 <<catCHESHIRE>>]");
}

/*
 * concanete_test2_Empty
 * Make sure it successfully adds all the elements of the linked list pointed 
 * to by the parameter value to the end of the empty linked list the function 
 * was called from
 */
void concanete_test2_Empty() {
    CharLinkedList list1; 

    char my_array2[8] ={'C','H','E','S','H','I','R','E'}; 
    CharLinkedList list2(my_array2, 8);

    list1.concatenate(&list2); 

    assert(list1.toString() == "[CharLinkedList of size 8 <<CHESHIRE>>]");
}

/*
 * concanete_test_Empty2
 * Make sure the linked list remains the same
 */
void concanete_test3_Empty2() { 
    char my_array2[8] ={'C','H','E','S','H','I','R','E'}; 
    CharLinkedList list1(my_array2, 8);

    CharLinkedList list2;

    list1.concatenate(&list2); 
    assert(list1.toString() == "[CharLinkedList of size 8 <<CHESHIRE>>]");
}

/*
 * concanete_test4_Itself
 * Make sure the linked list successfully concatenates with itself
 */
void concanete_test4_Itself() { 
    char my_array2[8] ={'C','H','E','S','H','I','R','E'}; 
    CharLinkedList list2(my_array2, 8);

    list2.concatenate(&list2); 

    assert(list2.toString() == 
    "[CharLinkedList of size 16 <<CHESHIRECHESHIRE>>]");
}

/*
 * concanete_test5_SingleElement
 * Make sure it successfully adds the single element of the linked list pointed 
 * to by the parameter value to the end of the empty linked list the function 
 * was called from
 */
void concanete_test5_SingleElement() { 
    char my_array2[8] ={'C','H','E','S','H','I','R','E'}; 
    CharLinkedList list1(my_array2, 8);

    CharLinkedList list2('M');

    list1.concatenate(&list2); 
    assert(list1.toString() == "[CharLinkedList of size 9 <<CHESHIREM>>]");
}

/*
 * concanete_test5_SingleElements
 * Make sure it successfully adds the single element of the linked list pointed 
 * to by the parameter value to the end of the empty linked list the function 
 * was called from
 */
void concanete_test6_SingleElements() { 

    CharLinkedList list1('a');

    CharLinkedList list2('M');

    list1.concatenate(&list2); 

    assert(list1.toString() == "[CharLinkedList of size 2 <<aM>>]");
}


/*
 *  CharLinkedList.cpp
 *  Dylan Perkins
 *  Feb 2, 2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  This file contains the implementation of the CharLinkedList class, 
 *  including the methods defined in the CharLinkedList.h header file. 
 *  Its purpose is to implement the functionality of the CharLinkedList class.
 *
 */

#include "CharLinkedList.h"
#include <stdexcept>
#include <string>

using namespace std;

/*
 * name: addANode(char c, Node *next, Node *last)
 * input: character data to be stored in the new node, and pointers
 *        to the previous and next nodes in the linked list
 * purpose: this function creates a new node with the given data and 
 *          linkes
 * output: returns a pointer to the newly created node
 * effects: 
 */
CharLinkedList::Node *CharLinkedList::addANode(char c, Node *next, Node *last){
    Node *newNode = new Node;
    newNode->data = c;
    newNode->next = next; //node member assignment
    newNode->last = last;

    return newNode;
}

/*
 * name: CharLinkedList()
 * input: nothing
 * purpose: This is the most basic constructor, creating
 *          an empty LinkedList
 * output: nothing
 * effects: Initializes an empty linked list.
 */
CharLinkedList::CharLinkedList(){
    front = nullptr;
    back = nullptr; //set empty
    listSize = 0;
}

/*
 * name: CharLinkedList(char c)
 * input: A char to be the only value in the linked list
 * purpose: This creates a linked list with one value in it
 *          and a size of one.
 * output: nothing
 * effects: Initializes a linked list with a single character.
 */
CharLinkedList::CharLinkedList(char c){
    front = addANode(c,nullptr,nullptr);
    listSize = 1; //set to linked list of one element
    back = front;
}

/*
 * name: CharLinkedList(char arr[], int size)
 * input: An array of chars that will be put into the linked list
 *        and an int representing the size of the linked list.
 * purpose: This constructor creates a linked list of chars 
 *          in the order in which they are originally given
 *          in the array. The size is the integer inputted.
 * output: nothing
 * effects: Initializes a linked list with characters from an array.
 */
CharLinkedList::CharLinkedList(char arr[], int size){
    front = new Node(); //sets the fornt
    front->data = arr[0]; //longer way of creating node
    front->last = nullptr;

    Node *curr = front;
    //create a new node for each index in the linkedlist
    for(int i = 1; i < size; i++){
        curr->next = new Node();
        curr->next->last = curr;
        curr = curr->next; //all these set the members of the node
        curr->data = arr[i]; //struct to what they need to be
    }
    curr->next = nullptr; //set back next to nullptr
    back = curr; //sets the last node to the back
    listSize = size;
}

/*
 * name: CharLinkedList(const CharLinkedList &other)
 * input: Another CharLinkedList object to copy
 * purpose: Copy constructor for CharLinkedList
 * output: nothing
 * effects: Creates a deep copy of another CharLinkedList.
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other){
    listSize = 0;
    front = nullptr; //base, everything empty
    back = nullptr;

    Node *last = nullptr; //these will be used in while loop to
    Node *curr = other.front; //traverse through the other linkedlist

    while(curr){ //traverses through other linkedlist
        Node *newNode = addANode(curr->data, nullptr, last);
        if (not front) //if there is no front set to front
            front = newNode;
        if (last) //if the last node isnt nullptr set its next member
            last->next = newNode; //to the newnode

        last = newNode; //make this node last
        curr = curr->next; //traverse through
        listSize++;
    }
    back = last;
}

/*
 * name: CharLinkedList& operator=(const CharLinkedList &other)
 * input: Another CharLinkedList object to copy
 * purpose: Assignment operator for CharLinkedList
 * output: Reference to the modified CharLinkedList
 * effects: Creates a deep copy of another CharLinkedList.
 */
CharLinkedList& CharLinkedList::operator=(const CharLinkedList &other){
    if (this != &other) { //if they arent the same list
        clear(); //clear all data in this list
        //set everything to base
        listSize = other.listSize;
        front = nullptr;
        back = nullptr;
        
        Node *curr = other.front;
        Node *last = nullptr;
        while (curr) { //traverse through other list
            Node *newNode = addANode(curr->data, nullptr, last);
            if (not front) //if theres no front assign front
                front = newNode;
            else
                last->next = newNode;

            curr = curr->next; //keep moving through
            last = newNode;
            back = newNode;
        }
    }
    return *this;
}

/*
 * name: isEmpty
 * input: nothing
 * purpose: returns true if the CharLinkedList is empty
 * output: boolean true or false value
 * effects: none
 */
bool CharLinkedList::isEmpty() const{
    return listSize == 0; //this is a boolean value
}

/*
 * name: clear
 * input: nothing
 * purpose: Clears the CharLinkedList, deallocating memory
 * output: nothing
 * effects: Deallocates memory for all nodes in the linked list.
 */
void CharLinkedList::clear(){
    Node* curr = front;
    while (curr) { //runs through whole list deleting each node
        Node* next = curr->next;
        delete curr;
        curr = next;
    }
    // reset front and back pointers
    front = nullptr;
    back = nullptr;
    listSize = 0;
}

/*
 * name: size
 * input: nothing
 * purpose: Determines the number of values in 
 *          the CharLinkedList
 * output: an integer representing that number
 * effects: none
 */
int CharLinkedList::size() const{
    return listSize;
}

/*
 * name: first
 * input: nothing
 * purpose: returns the first value in the CharLinkedList
 *          or an error if the list is empty
 * output: the first char value of the CharLinkedList
 * effects: none
 */
char CharLinkedList::first() const{
    if (listSize == 0) //run_time error if there is no value to be first
        throw std::runtime_error("cannot get first of empty LinkedList");
    else
        return front->data;
}

/*
 * name: last
 * input: nothing
 * purpose:returns the last value in the CharLinkedList
 *         or an error if the list is empty
 * output: the last char value of a CharlinkedList
 * effects: nothing
 */
char CharLinkedList::last() const{
    if (listSize == 0) //run_time error if there is not value to be last
        throw std::runtime_error("cannot get last of empty LinkedList");
    else
        return back->data;
}

/*
 * name: elementAt
 * input: an integer representing the index of the desired char
 * purpose: returns the value at the inputted index or an error
 *          if the index is out of range
 * output: the char at the given index within the CharLinkedList
 * effects: nothing
 */ 
char CharLinkedList::elementAt(int index) const{
    if(index >= 0 and index < listSize)
        return elemAtRecursive(front, index); //recursive helper func
    else //if not throws a range error to the user
        throw std::range_error("index (" + std::to_string(index) 
        + ") not in range [0.." + std::to_string(listSize) + ")");
}

/*
 * name: elemAtRecursive
 * input: a pointer to the current node and an integer representing
 *        index of the desired element
 * purpose: recursively runs through the linked list to find the element
 *          at the given index
 * output: the char at the given index within the CharLinkedList
 * effects: nothing
 */ 
char CharLinkedList::elemAtRecursive(Node *curr, int index) const{
    if (curr == nullptr) //if ran out of items, then out of range
        throw std::range_error("index (" + std::to_string(index) 
        + ") not in range [0.." + std::to_string(listSize) + ")");
    if (index == 0) //base case, node found
        return curr->data; 
    //recursive case, move to next node
    return elemAtRecursive(curr->next, index - 1);
}

/*
 * name: toString
 * input: nothing
 * purpose: Returns a string representation of the CharLinkedList
 * output: a string containing the formatted representation of 
 *         the CharLinkedList
 * effects: nothing
 */
std::string CharLinkedList::toString() const{
    string word = "[CharLinkedList of size ";
    word += std::to_string(listSize); //different parts of 
    word += " <<";                    //the outputted string
    //adds every char in the linked list
    for (Node *i = front; i != nullptr; i = i->next){
        word += i->data;
    }
    //more parts of the string
    word += ">>]";

    return word;
}

/*
 * name: toReverseString
 * input: nothing
 * purpose: Returns a string representation of the CharLinkedList 
 *          in reverse order
 * output: a string containing the formatted reverse representation of
 *         the CharLinkedList
 * effects: 
 */
std::string CharLinkedList::toReverseString() const{
    string word = "[CharLinkedList of size ";
    word += std::to_string(listSize); //string creation
    word += " <<";

    for (Node *i = back; i != nullptr; i = i->last){
        word += i->data; //runs through data in reverse
    }

    word += ">>]"; //more details of string

    return word;
}

/*
 * name: pushAtBack
 * input: a char value to be added to the back of the CharLinkedList
 * purpose: Adds a new character to the back of the CharLinkedList
 * output: nothing
 * effects: Modifies the CharLinkedList by adding a new element to the back
 */
void CharLinkedList::pushAtBack(char c){
    Node* curr = addANode(c, nullptr, back);
    if (listSize == 0) { //if empty list
        front = curr;
    } else { //resetting pointers
        back->next = curr;
        curr->last = back;
    }
    back = curr;
    listSize++;
}

/*
 * name: pushAtFront
 * input: a char value to be added to the front of the CharLinkedList
 * purpose: Adds a new character to the front of the CharLinkedList
 * output: nothing
 * effects: Modifies the CharLinkedList by adding a new element to the front
 */
void CharLinkedList::pushAtFront(char c){
    Node *curr = addANode(c,front,nullptr);
    listSize++;
    if (listSize == 1) //if list empty
        back = curr;
    front = curr;
}

/*
 * name: insertAt
 * input: a char value and an integer index
 * purpose: Inserts a new character at the specified index in 
 *          the CharLinkedList
 * output: nothing
 * effects: Modifies the CharLinkedList by inserting a new element 
 *          at the specified index
 */ 
void CharLinkedList::insertAt(char c, int index){
    if(index <= listSize and index >= 0){
        if(index == 0)
            pushAtFront(c); //reuse other functions
        else {
            Node *curr = front;
            //traverse through the list to element at index - 1
            for(int i = 0; i < index - 1; i++)
                curr = curr->next;
            //create node to be inserted
            Node *inserted = addANode(c,curr->next,curr);
            curr->next = inserted;
            //more node connections
            if(inserted->next)
                inserted->next->last = inserted;
            listSize++;
        }
    }
    else //otherwise throw error
        throw std::range_error("index (" + std::to_string(index) 
        + ") not in range [0.." + std::to_string(listSize) + "]");
}

/*
 * name: insertInOrder
 * input: a char value
 * purpose: Inserts a new character in sorted order in the CharLinkedList
 * output: nothing
 * effects: Modifies the CharLinkedList by inserting a new element 
 *          in sorted order
 */
void CharLinkedList::insertInOrder(char c){
    Node* curr = front;
    Node* holder = nullptr;
    //traverse through until where char fits in order
    while (curr and c > curr->data) {
        holder = curr;
        curr = curr->next;
    }
    //create node to insert
    Node* newNode = addANode(c, curr, holder);
    //if there is a node before it connect it
    if (holder) 
        holder->next = newNode;
    else //if not this node is front
        front = newNode;
    //if there is node after connect it
    if (curr) 
        curr->last = newNode;
    else //else this one is back
        back = newNode;

    listSize++;
}

/*
 * name: popFromFront
 * input: nothing
 * purpose: Removes the element from the front of the CharLinkedList
 * output: nothing
 * effects: Modifies the CharLinkedList by removing the front element
 */
void CharLinkedList::popFromFront(){
    if(listSize == 0) //error to throw if empty 
        throw std::runtime_error("cannot pop from empty LinkedList");
    else {
        Node *oldFront = front;
        front = front->next; //move the front

        if(front) //if the front is a node
            front->last = nullptr; 
        else //if empty then back is empty
            back = nullptr;
        delete oldFront;
        listSize--;
    }
}

/*
 * name: popFromBack
 * input: nothing
 * purpose: Removes the element from the back of the CharLinkedList
 * output: nothing
 * effects: Modifies the CharLinkedList by removing the back element
 */
void CharLinkedList::popFromBack(){
    if(listSize == 0) //throw error
        throw std::runtime_error("cannot pop from empty LinkedList"); 
    else{
        Node *oldBack = back;
        back = back->last; //move back to node before

        if(back) //if back is not empty set its next to nullptr
            back->next = nullptr;
        else //if list empty, set front to nullptr
            front = nullptr;
        delete oldBack;
        listSize--;
    }
}

/*
 * name: removeAt
 * input: an integer index
 * purpose: Removes the element at the specified index in 
 *          the CharLinkedList
 * output: nothing
 * effects: Modifies the CharLinkedList by removing the element 
 *          at the specified index
 */
void CharLinkedList::removeAt(int index){
    if(index >= 0 and index < listSize){ //if within range
        if(index == 0) //if at front reuse popfromfront
            popFromFront();
        else if(index == listSize - 1) //if its last, popfromfront
            popFromBack();
        else { 
            Node *curr = front; 
            for(int i = 0; i < index - 1; i++) //traverse through
                curr = curr->next;
            Node *removed = curr->next;
            curr->next = removed->next; //reassign pointers
            curr->next->last = curr;

            delete removed;
            listSize--;
        }
    }
    else //throw error 
        throw std::range_error("index (" + std::to_string(index) 
        + ") not in range [0.." + std::to_string(listSize) + ")");
}

/*
 * name: replaceAt
 * input: a char value and an integer index
 * purpose: Replaces the element at the specified index with the 
 *          given character
 * output: nothing
 * effects: Modifies the CharLinkedList by replacing the element at 
 *          the specified index
 */
void CharLinkedList::replaceAt(char c, int index){
    if(index >= 0 and index < listSize) //if in range
        replaceAtHelper(front, c, index);
    else  //if not in range trow error
        throw std::range_error("index (" + std::to_string(index) 
        + ") not in range [0.." + std::to_string(listSize) + ")");
}

/*
 * name: replaceAtHelper
 * input: a pointer to the current node, a char value, and an integer index
 * purpose: Recursively replaces the element at the specified index with 
 *          the given character
 * output: nothing
 * effects: Modifies the CharLinkedList by replacing the element at the 
 *          specified index
 */
void CharLinkedList::replaceAtHelper(Node *curr, char c, int index){
    if(curr==nullptr) //throw error if reach end of linked list
        throw std::range_error("index (" + std::to_string(index) 
        + ") not in range [0.." + std::to_string(listSize) + ")");
    if (index == 0) //if reach end of index return that data
        curr->data = c;
    else //recursively go to next node in linkedlist
        replaceAtHelper(curr->next, c, index - 1);
}

/*
 * name: concatenate
 * input: a pointer to another CharLinkedList
 * purpose: Concatenates the provided CharLinkedList to the end of 
 *          the current one
 * output: nothing
 * effects: Modifies the CharLinkedList by adding elements from another 
 *          CharLinkedList
 */
void CharLinkedList::concatenate(CharLinkedList *other){
    if (this == other){ //concatenate with self
        CharLinkedList list(*this);
        concatenate(&list);
    }
    else { //pushAtBack all values in other linkedlist
        Node *curr = other->front;
        while(curr){
            pushAtBack(curr->data);
            curr = curr->next;
        }
    }
}

/*
 * name: ~CharLinkedList
 * input: nothing
 * purpose: deallocates all used memory
 * output: nothing
 * effects: Deallocates memory used by the CharLinkedList
 */
CharLinkedList::~CharLinkedList(){
    destructor(front);
    
    front = nullptr;
    back = nullptr; //just in case they didnt get reset
    listSize = 0;
}

/*
 * name: destructor
 * input: a pointer to a Node
 * purpose: Recursively deallocates memory used by the CharLinkedList
 * output: nothing
 * effects: Deallocates memory used by the CharLinkedList
 */ 
void CharLinkedList::destructor(Node *curr){
    if (curr == nullptr){
        listSize = 0; //if reach end of list
        return;
    }
    if (curr == front) //set front to nullptr
        front = nullptr;
    if (curr == back) //set back to nullptr
        back = nullptr;
    
    Node *next = curr->next; //traverse along
    delete curr; //and delete last one
    destructor(next);
}
/*
 *  CharLinkedList.h
 *  Dylan Perkins
 *  Feb 2, 2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *  
 *  Declares CharLinkedList, a class for flexible character sequence handling.
 *  Each instance offers essential operations like insertion, deletion, and 
 *  concatenation, representing a dynamic chain of characters. The class 
 *  abstracts details with a high-level interface, playing a pivotal role in 
 *  efficient character data management. Its linked list structure supports 
 *  seamless manipulation, emphasizing the significance in dynamic structures.
 *
 */

#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H

#include <string>

class CharLinkedList {
public:
    //constructors
    CharLinkedList();
    CharLinkedList(char c);
    CharLinkedList(char arr[], int size);
    CharLinkedList(const CharLinkedList &other);

    //destructor
    ~CharLinkedList();
    
    //functions
    CharLinkedList &operator=(const CharLinkedList &other);
    bool isEmpty() const;
    void clear();
    int size() const;
    char first() const;
    char last() const;
    char elementAt(int index) const;
    std::string toString() const;
    std::string toReverseString() const;
    void pushAtBack(char c);
    void pushAtFront(char c);
    void insertAt(char c, int index);
    void insertInOrder(char c);
    void popFromFront();
    void popFromBack();
    void removeAt(int index);
    void replaceAt(char c, int index);
    void concatenate(CharLinkedList *other);
//all private variables and functions
private: 
    struct Node{
        char data;
        Node *next;
        Node *last;
    };

    Node *front;
    Node *back;
    int listSize;

    void destructor(Node *curr);
    char elemAtRecursive(Node *curr, int index) const;
    void replaceAtHelper(Node *curr, char c, int index);
    Node* addANode(char c, Node *next, Node *last);
};

#endif

/*
 *  unit_tests.h
 *  Dylan Perkins
 *  Feb 2, 2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  This file serves as our testing ground to thoroughly evaluate the 
 *  functionality of the CharLinkedList class. It plays a crucial role 
 *  in ensuring our linked list of characters operates seamlessly.
 *
 */
#include "CharLinkedList.h"
#include <cassert>
#include <stdexcept>


//-------- constructor one test ----------
//tests that the first constructor is created
void constructorTestOne(){
    CharLinkedList list;
}

//-------- constructor two test ----------
//tests that the second constructor creates a linked list 
// with capacity of 1 and char c in it
void constructorTestTwo(){
    char x = 'a';
    CharLinkedList list(x);
    assert(list.size() == 1);
    assert(list.elementAt(0) == x);
}

//-------- constructor three test ----------
//tests the creation of constructor three, which creates
//a linked list based on an inputted array
void constructorTestThree(){
    char x[3] = {'a','b','c'};
    CharLinkedList list(x,3);
    assert(list.size() == 3);
    assert(list.elementAt(0) == 'a');
    assert(list.elementAt(1) == 'b');
    assert(list.elementAt(2) == 'c');
}

//-------- constructor four test ----------
//tests the creation of constructor four, which creates
//a linked list that is a deep copy of another linked list
void constructorTestFour(){
    char x[3] = {'a','b','c'};
    CharLinkedList list(x,3);
    CharLinkedList list2(list);

    assert(list2.size() == 3);
    assert(list2.first() == 'a');
    assert(list2.last() == 'c');
}

//tests constructor four, but copying an emtpy linked list
void constructorTestFourEmpty(){
    CharLinkedList list;
    CharLinkedList list2(list);

    assert(list2.size() == 0);
    assert(list2.isEmpty());
}

//tests constructor four, but copying a list with caps
void constructorTestFourCaps(){
    char x[3] = {'A','B','C'};
    CharLinkedList list(x,3);
    CharLinkedList list2(list);

    assert(list2.size() == 3);
    assert(list2.first() == 'A');
    assert(list2.last() == 'C');
}

//-------- operator tests ----------
//tests operator, sets empty first list equal to full second list
void copyOverBaseEmpty(){
    CharLinkedList list1;
    char x[3] = {'a','b','c'};
    CharLinkedList list2(x,3);

    list1 = list2;
    assert(list1.size() == 3);
    assert(list1.first() == 'a');
    assert(list1.last() == 'c');
}

//tests operator, sets full first list equal to full second list
void copyOverBaseFull(){
    char x[3] = {'d','o','g'};
    CharLinkedList list1(x,3);
    char y[3] = {'c','a','t'};
    CharLinkedList list2(y,3);

    list1 = list2;
    assert(list1.size() == 3);
    assert(list1.first() == 'c');
    assert(list1.last() == 't');
}

//tests operator, sets full first list equal to empty second list
void copyOverSetEmpty(){
    char x[3] = {'a','b','c'};
    CharLinkedList list1(x,3);
    CharLinkedList list2;

    list1 = list2;
    assert(list1.isEmpty());
}

//-------- isEmpty tests ----------
//tests isEmpty, tests empty list
void isEmptyTrueBasic(){
    CharLinkedList list;
    assert(list.isEmpty());
}
//tests isEmpty, tests list that had its elements removed
// and made the list empty
void isEmptyTrueDiff(){
    char a[0];
    CharLinkedList list(a,0);
    assert(list.isEmpty());
}

///tests isEmpty, test that it returns false for a full list
void isEmptyFalse(){
    char a[3] = {'a','a','a'};
    CharLinkedList list(a,3);
    assert(not list.isEmpty());
}

//-------- clear tests ----------
//tests clear, clear an empty linked list
void clearTestEmpty(){
    CharLinkedList list;
    list.clear();
    assert(list.isEmpty());
}

//tests clear, clear a non empty list
void clearTestNotEmpty(){
    char a[3] = {'a','a','a'};
    CharLinkedList list(a,3);
    list.clear();
    assert(list.isEmpty());
}

//tests clear, add to a list then clear it
void clearTestAddThenClear(){
    char a[3] = {'a','a','a'};
    CharLinkedList list(a,3);
    list.pushAtBack('b');
    list.pushAtFront('b');
    list.clear();
    assert(list.isEmpty());
}

//tests clear, add to a list, clear it, add to it, should be false
void clearTestAddThenClearFalse(){
    char a[3] = {'a','a','a'};
    CharLinkedList list(a,3);
    list.pushAtBack('b');
    list.pushAtFront('b');
    list.clear();
    list.pushAtBack('b');
    assert(not list.isEmpty());
}

//-------- size tests ----------
//tests size, full linked list
void sizeTestNormal(){
    int size = 3;
    char a[3] = {'a','a','a'};
    CharLinkedList list(a,3);
    assert(list.size() == size);
}

//tests clear, empty linked list, should be zero
void sizeTestZeros(){
    int size = 0;
    char a[0];
    CharLinkedList list(a,0);
    assert(list.size() == size);
}

//-------- first tests ----------
//tests first, returns first when there is only one element in list
void firstTestOne(){
    char a[1] = {'a'};
    CharLinkedList list(a, 1);
    assert(list.first() == a[0]);
}

//tests first with a longer list 
void firstTestBigger(){
    char a[5] = {'b','a','a','a','a'};
    CharLinkedList list(a, 5);
    assert(list.first() == a[0]);
}

//tests first, when the list is empty, should get an error
void firstTestNothing(){
    CharLinkedList list;
    std::string error;
    bool thrown = false;
    try{
        list.first();
    }
    catch(const std::runtime_error &e){
        thrown = true;
        error = e.what();
    }
    assert(thrown);
    assert(error == "cannot get first of empty LinkedList");
}

//tests first, when popped from front
void firstTestPop(){
    char a[5] = {'b','a','a','a','a'};
    CharLinkedList list(a, 5);
    list.popFromFront();
    assert(list.first() == a[1]);
}

//-------- last test ----------
//tests last when there is one element in the list
void lastTestOne(){
    char a[1] = {'a'};
    CharLinkedList list(a, 1);
    assert(list.last() == a[0]); 
}

//tests last with a longer list
void lastTestBigger(){
    char a[5] = {'a','b','c','d','e'};
    CharLinkedList list(a, 5);
    assert(list.last() == a[4]);
}

//tests last when there is nothing in list, should get an error
void lastTestNothing(){
    CharLinkedList list;
    std::string error;
    bool thrown = false;
    try{
        list.last();
    }
    catch(const std::runtime_error &e){
        thrown = true;
        error = e.what();
    }
    assert(thrown);
    assert(error == "cannot get last of empty LinkedList");
}

//tests last when popped from back
void lastTestPopped(){
    char a[5] = {'a','b','c','d','e'};
    CharLinkedList list(a, 5);
    list.popFromBack();
    assert(list.last() == a[3]);
}

//-------- elementAt tests ----------
//test elementAt when empty, should produce an error
void elementAtEmptyTestOne(){
    CharLinkedList list;
    std::string error;
    bool thrown = false;
    try{
        list.elementAt(1);
    }
    catch(const std::range_error &e){
        thrown = true;
        error = e.what();
    }
    assert(thrown);
    assert(error == "index (" + std::to_string(1) 
    + ") not in range [0.." + std::to_string(list.size()) + ")");
}

//test elemenetAt with a longer list and many indexes in list
void elementAtTestFirstMiddleLastTest(){
    char a[5] = {'a','b','c','d','e'};
    CharLinkedList list(a, 5);

    assert(list.elementAt(0) == a[0]);
    assert(list.elementAt(2) == a[2]);
    assert(list.elementAt(4) == a[4]);
}

//test elementAt with a full list but index is out of range
void elementAtErrorrTest(){
    char a[5] = {'a','b','c','d','e'};
    CharLinkedList list(a, 5);
    std::string error;
    bool thrown = false;

    try{
        list.elementAt(6);
    }
    catch(const std::range_error &e){
        thrown = true;
        error = e.what();
    }
    assert(thrown);
    assert(error == "index (" + std::to_string(6) 
    + ") not in range [0.." + std::to_string(list.size()) + ")");
}

//-------- toString tests ----------
//test toString when the list is empty
void toStringEmptyTest(){
    CharLinkedList list;
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}
//test toString when the list is short
void toStringShortTest(){
    char a[4] = {'m','a','o','w'};
    CharLinkedList list(a, 4); 
    assert(list.toString() == "[CharLinkedList of size 4 <<maow>>]");
}

//test toString when the list is short with capitals
void toStringShortCapsTest(){
    char a[4] = {'M','a','o','w'};
    CharLinkedList list(a, 4); 
    assert(list.toString() == "[CharLinkedList of size 4 <<Maow>>]");
}

//test toString when the list is longer
void toStringLongTest(){
    char a[8] = {'m','a','o','w','m','a','o','w'};
    CharLinkedList list(a,8);
    assert(list.toString() == "[CharLinkedList of size 8 <<maowmaow>>]");
}

//test toString when the list is longer with capitals
void toStringLongCapsTest(){
    char a[8] = {'m','A','o','W','m','A','o','W'};
    CharLinkedList list(a,8);
    assert(list.toString() == "[CharLinkedList of size 8 <<mAoWmAoW>>]");
}

//-------- toReverseString tests ----------
//test reverse when the list is empty
void toReverseStringEmptyTest(){
    CharLinkedList list;
    assert(list.toReverseString() == "[CharLinkedList of size 0 <<>>]");
}

//test reverse when the list is short
void toReverseStringShortTest(){
    char a[4] = {'w','o','o','f'};
    CharLinkedList list(a, 4); 
    assert(list.toReverseString() == "[CharLinkedList of size 4 <<foow>>]");
}

//test reverse when the list is short with caps
void toReverseStringShortCapsTest(){
    char a[4] = {'W','O','o','F'};
    CharLinkedList list(a, 4); 
    assert(list.toReverseString() == "[CharLinkedList of size 4 <<FoOW>>]");
}

//test reverse when the list is longer
void toReverseStringLongTest(){
    char a[8] = {'w','o','o','f','w','o','o','f'};
    CharLinkedList list(a, 8); 
    assert(list.toReverseString() == "[CharLinkedList of size 8 <<foowfoow>>]");
}

//test reverse when the list is longer with caps
void toReverseStringLongCapsTest(){
    char a[8] = {'w','O','O','f','w','O','O','f'};
    CharLinkedList list(a, 8); 
    assert(list.toReverseString() == "[CharLinkedList of size 8 <<fOOwfOOw>>]");
}

//-------- pushAtBack tests ----------
//tests pushAtBack on empty list
void pushAtBackEmpty(){
    CharLinkedList list;
    char a = 'a';
    list.pushAtBack(a);
    assert(list.first() == a);
}

//tests pushAtBack on a small list
void pushAtBackSmallOne(){
    char a = 'a';
    CharLinkedList list(a);
    list.pushAtBack(a);
    assert(list.last() == a);
}

//tests pushAtBack on an empty but then added to list
void pushAtBackSmallTwo(){
    CharLinkedList list;
    char a = 'a';
    char b = 'b';
    list.pushAtBack(a);
    list.pushAtBack(b);
    assert(list.first() == a);
    assert(list.last() == b);
}

//tests pushAtBack on a larger list
void pushAtBackLargeOne(){
    char a[4] = {'a','a','a','a'};
    char b = 'b';
    CharLinkedList list(a,4);
    list.pushAtBack(b);
    assert(list.elementAt(3) == 'a');
    assert(list.last() == b);
}

//tests pushAtBack on largest list
void pushAtBackLargeTwo(){
    char a[4] = {'a','a','a','a'};
    char b = 'b';
    char c = 'c';
    CharLinkedList list(a,4);
    list.pushAtBack(b);
    list.pushAtBack(b);
    list.pushAtBack(b);
    list.pushAtBack(b);
    list.pushAtBack(b);
    list.pushAtBack(c);
    assert(list.elementAt(8) == b);
    assert(list.last() == c);
}

//-------- pushAtFront ----------
//tests pushAtBack on an empty list
void pushAtFrontEmpty(){
    CharLinkedList list;
    char a = 'a';
    list.pushAtFront(a);
    assert(list.first() == a);
}

//tests pushAtBack on small list
void pushAtFrontSmallOne(){
    char a[1] = {'a'};
    char b = 'b';
    CharLinkedList list(a,1);
    list.pushAtBack(b);
    list.pushAtFront(b);
    assert(list.first() == b);
}

//tests pushAtBack on first empty then added to list
void pushAtFrontSmallTwo(){
    CharLinkedList list;
    char a = 'a';
    char b = 'b';
    list.pushAtFront(a);
    list.pushAtFront(b);
    assert(list.first() == b);
}

//tests pushAtBack on larger list, add multiple times
void pushAtFrontLarge(){
    char a[4] = {'b','a','a','a'};
    char b = 'b';
    CharLinkedList list(a,4);
    list.pushAtBack(b);
    list.pushAtFront(b);
    list.pushAtFront(b);
    assert(list.first() == b);
}

//-------- insertAt ----------
// Tests correct insertion into an empty AL.
// Afterwards, size should be 1 and element at index 0
// should be the element we inserted.
void insertAt_empty_correct() { 
    CharLinkedList test_list;
    test_list.insertAt('a', 0);
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');

}

// Tests incorrect insertion into an empty AL.
// Attempts to call insertAt for index larger than 0.
// This should result in an std::range_error being raised.
void insertAt_empty_incorrect() {
    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    // insertAt for out-of-range index
    test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
    // if insertAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    range_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0]");
    
}

// Tests correct insertAt for front of 1-element list.
void insertAt_front_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at front
    test_list.insertAt('b', 0);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'a');
    
}

// Tests correct insertAt for back of 1-element list.
void insertAt_back_singleton_list() {
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at back
    test_list.insertAt('b', 1);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
}

// Tests calling insertAt for a large number of elements.
// Not only does this test insertAt, it also checks that
// array expansion works correctly.
void insertAt_many_elements() {
    CharLinkedList test_list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.insertAt('a', i);
    }

    assert(test_list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
    
}

// Tests insertion into front of a larger list
void insertAt_front_large_list() {
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    test_list.insertAt('y', 0);

    assert(test_list.size() == 10);
    assert(test_list.elementAt(0) == 'y');
    assert(test_list.toString() == 
    "[CharLinkedList of size 10 <<yabczdefgh>>]");
}

// Tests insertion into the back of a larger list
void insertAt_back_large_list() {

    char test_arr[10] = { 'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 10);  

    test_list.insertAt('x', 10);

    assert(test_list.size() == 11);
    assert(test_list.elementAt(10) == 'x');
    assert(test_list.toString() ==
    "[CharLinkedList of size 11 <<yabczdefghx>>]"); 

}

// Tests insertion into the middle of a larger list
void insertAt_middle_large_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.insertAt('z', 3);

    assert(test_list.size() == 9);
    assert(test_list.elementAt(3) == 'z');
    assert(test_list.toString() == 
    "[CharLinkedList of size 9 <<abczdefgh>>]");

}

// Tests out-of-range insertion for a non-empty list.
void insertAt_nonempty_incorrect() {
   
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8]");
    
}

//-------- insert in order ----------
//tests insertInOrder on an emtpy list
void insertInOrderEmpty(){
    CharLinkedList list;
    char a = 'a';

    list.insertInOrder(a);
    assert(list.elementAt(0) == a);
}

//tests insertInOrder on a list of all the same char
void insertInOrderAllA(){
    char a[5] = {'a','a','a','a','a'};
    char b = 'b';
    CharLinkedList list(a,5);

    list.insertInOrder(b);
    assert(list.last() == b);
    assert(list.toString() == "[CharLinkedList of size 6 <<aaaaab>>]");
}

//tests insertInOrder at the front of a list of all the same char
void insertInOrderAllB(){
    char b[5] = {'b','b','b','b','b'};
    char a = 'a';
    CharLinkedList list(b,5);

    list.insertInOrder(a);
    assert(list.first() == a);
    assert(list.toString() == "[CharLinkedList of size 6 <<abbbbb>>]");
}

//tests insertInOrder on list ABD, should become ABCD
void insertInOrderABD(){
    char abd[3] = {'a','b','d'};
    char c = 'c';
    CharLinkedList list(abd,3);

    list.insertInOrder(c);
    assert(list.elementAt(2) == c);
    assert(list.toString() == "[CharLinkedList of size 4 <<abcd>>]");
}

//tests insertInOrder on list ZED should become AZED
void insertInOrderZED(){
    char zed[3] = {'z','e','d'};
    char a = 'a';
    CharLinkedList list(zed,3);

    list.insertInOrder(a);
    assert(list.first() == a);
    assert(list.toString() == "[CharLinkedList of size 4 <<azed>>]");
}

//tests insertInOrder on a longer list where its inserted in the middle
void insertInOrderLong(){
    char kn[7] = {'k','k','k','k','n','n','n'};
    char m = 'm';
    CharLinkedList list(kn,7);

    list.insertInOrder(m);
    assert(list.elementAt(4) == m);
    assert(list.toString() == "[CharLinkedList of size 8 <<kkkkmnnn>>]");
}

//-------- pop from front ----------
//tests popFromFront on emtpy list, should produce error
void popFromFrontEmpty(){
    CharLinkedList list;
    bool thrown = false;
    std::string error;

    try {
        list.popFromFront();
    }
    catch(const std::runtime_error &e){
        thrown = true;
        error = e.what();
    }
    assert(error == "cannot pop from empty LinkedList");
}

//tests popFromFront on list of size one, should become empty
void popFromFrontOne(){
    char a = 'a';
    CharLinkedList list(a);

    list.popFromFront();
    assert(list.isEmpty());
}

//tests popFromFront on a small list
void popFromFrontSmall(){
    char a[4] = {'a','b','c','d'};
    CharLinkedList list(a,4);

    list.popFromFront();
    assert(list.size() == 3);
    assert(list.first() == 'b');
}

//tests popFromFront on a larger list
void popFromFrontLarge(){
    char n[8] = {'n','x','n','n','n','n','n','n'};
    CharLinkedList list(n,8);

    list.popFromFront();
    assert(list.size() == 7);
    assert(list.first() == 'x');
}

//-------- pop from back ----------
//tests popFromFront on an empty list, should produce error
void popFromBackEmpty(){
    CharLinkedList list;
    bool thrown = false;
    std::string error;

    try {
        list.popFromBack();
    }
    catch(const std::runtime_error &e){
        thrown = true;
        error = e.what();
    }
    assert(error == "cannot pop from empty LinkedList");
}

//tests popFromFront on list of size one, should become empty
void popFromBackOne(){
    char a = 'a';
    CharLinkedList list(a);

    list.popFromBack();
    assert(list.isEmpty());
}

//tests popFromFront on a small list
void popFromBackSmall(){
    char a[3] = {'a','b','c'};
    CharLinkedList list(a,3);

    list.popFromBack();
    assert(list.size() == 2);
    assert(list.last() == 'b');
}

//tests popFromFront on a larger list
void popfromBackLarge(){
    char n[8] = {'n','x','n','n','n','n','n','n'};
    CharLinkedList list(n,8);

    list.popFromFront();
    list.popFromBack();
    assert(list.size() == 6);
    assert(list.first() == 'x');
    assert(list.last() == 'n');
}

//-------- remove at ----------
//tests popFromFront on empty list, should produce an error
void removeAtEmpty(){
    CharLinkedList list;
    bool thrown = false;
    std::string error;

    try{
        list.removeAt(0);
    }
    catch (const std::range_error &e){
        thrown = true;
        error = e.what();
    }
    assert(error == "index (0) not in range [0..0)");
}

//tests popFromFront on an index that is out of range, should produce error
void removeAtError(){
    char a[3] = {'a','b','c'};
    bool thrown = false;
    std::string error;
    CharLinkedList list(a,3);

    try{
        list.removeAt(5);
    }
    catch (const std::range_error &e){
        thrown = true;
        error = e.what();
    }
    assert(error == "index (5) not in range [0..3)");
}

//tests popFromFront on list of size one
void removeAtOneTest(){
    char a = 'a';
    CharLinkedList list(a);

    list.removeAt(0);
    assert(list.isEmpty());
}

//tests popFromFront at the front of a small list
void removeAtFrontSmall(){
    char a[3] = {'a','b','c'};
    CharLinkedList list(a,3);

    list.removeAt(0);
    assert(list.size() == 2);
    assert(list.first() == 'b');
}

//tests popFromFront at the front of a large list
void removeAtFrontLarge(){
    char n[8] = {'n','x','n','n','n','n','n','n'};
    CharLinkedList list(n,8);

    list.removeAt(0);
    assert(list.size() == 7);
    assert(list.first() == 'x');
}

//tests popFromFront in the middle of a small list
void removeAtMidSmall(){
    char a[3] = {'a','b','c'};
    CharLinkedList list(a,3);

    list.removeAt(1);
    assert(list.size() == 2);
    assert(list.toString() == "[CharLinkedList of size 2 <<ac>>]");
}

///tests popFromFront in the middle of a large list
void removeAtMidLarge(){
    char n[8] = {'n','x','n','n','y','n','n','n'};
    CharLinkedList list(n,8);

    list.removeAt(3);
    assert(list.size() == 7);
    assert(list.elementAt(3) == 'y');
}

//tests popFromFront at the back of a list
void removeAtBack(){
    char n[8] = {'n','x','n','n','n','n','x','n'};
    CharLinkedList list(n,8);

    list.removeAt(7);
    assert(list.size() == 7);
    assert(list.last() == 'x');
}

//-------- replace at ----------
//tests popFromFront on an empty list, should produce an error
void replaceAtEmpty(){
    CharLinkedList list;
    char a = 'a';
    bool thrown = false;
    std::string error;

    try {
        list.replaceAt(a,0);
    }
    catch(const std::range_error &e){
        thrown = true;
        error = e.what();
    }
    assert(error == "index (0) not in range [0..0)");
}

//tests popFromFront on a full list, out of range, should producce error
void replaceAtOutOfRange(){
    char a[3] = {'a','a','a'};
    CharLinkedList list(a,3);
    bool thrown = false;
    std::string error;

    try {
        list.replaceAt('b',5);
    }
    catch (const std::range_error &e){
        thrown = true;
        error = e.what();
    }
    assert(error == "index (5) not in range [0..3)");
}

//tests popFromFront at front of a small list
void replaceAtFrontSmall(){
    char a[3] = {'a','a','a'};
    CharLinkedList list(a,3);
    char b = 'b';

    list.replaceAt(b, 0);
    assert(list.first() == b);
}

//tests popFromFront at the front of a large list
void replaceAtFrontLarge(){
    char n[8] = {'n','x','n','n','y','n','n','n'};
    CharLinkedList list(n,8);
    char b = 'b';

    list.replaceAt(b, 0);
    assert(list.first() == b);
}

///tests popFromFront in the middle of a small list
void replaceAtMidSmall(){
    char a[3] = {'a','a','a'};
    CharLinkedList list(a,3);
    char b = 'b';

    list.replaceAt(b, 1);
    assert(list.elementAt(1) == b);
}

//tests popFromFront in the middle of a large list
void replaceAtMidLarge(){
    char n[8] = {'n','x','n','n','y','n','n','n'};
    CharLinkedList list(n,8);
    char b = 'b';

    list.replaceAt(b, 4);
    assert(list.elementAt(4) == b);
}

//tests popFromFront in the back of a list
void replaceAtBack(){
    char n[8] = {'n','x','n','n','y','n','n','n'};
    CharLinkedList list(n,8);
    char b = 'b';

    list.replaceAt(b,7);
    assert(list.last() == b);
}

//-------- concatenate ----------
//tests concatenation of empty list with empty list
void concatNothingNothing(){
    CharLinkedList list1;
    CharLinkedList list2;

    list1.concatenate(&list2);
    assert(list1.isEmpty());
}

//tests concatenation of empty list with itself
void concatNothingSelf(){
    CharLinkedList list1;

    list1.concatenate(&list1);
    assert(list1.isEmpty());
}

//tests concatenation of list with itself
void concatSelf(){
    char a[3] = {'c','a','t'};
    CharLinkedList list1(a,3);
    list1.concatenate(&list1);
    assert(list1.size() == 6);
    assert(list1.toString() == "[CharLinkedList of size 6 <<catcat>>]");
}

//tests concatenation of full list iwht emtpy list
void concatNothingSomething(){
    CharLinkedList list1;
    char a[3] = {'a','a','a'};
    CharLinkedList list2(a,3);

    list1.concatenate(&list2);
    assert(list1.size() == 3);
    assert(list1.toString() == "[CharLinkedList of size 3 <<aaa>>]");
}

//tests concatenation of empty list with full list
void concatSomethingNothing(){
    char a[3] = {'a','a','a'};
    CharLinkedList list1(a,3);
    CharLinkedList list2;

    list1.concatenate(&list2);
    assert(list1.size() == 3);
    assert(list1.toString() == "[CharLinkedList of size 3 <<aaa>>]");
}

//tests concatenation of small list with small list
void concatSmallSmall(){
    char a[3] = {'c','a','t'};
    CharLinkedList list1(a,3);
    char b[3] = {'d','o','g'};
    CharLinkedList list2(b,3);

    list1.concatenate(&list2);
    assert(list1.size() == 6);
    assert(list1.toString() == "[CharLinkedList of size 6 <<catdog>>]");
}

//tests concatenation of small list with large list
void concatSmallLarge(){
    char a[3] = {'c','a','t'};
    CharLinkedList list1(a,3);
    char b[9] = {'l','o','v','e','s','f','o','o','d'};
    CharLinkedList list2(b,9);

    list1.concatenate(&list2);
    assert(list1.size() == 12);
    assert(list1.toString() == 
    "[CharLinkedList of size 12 <<catlovesfood>>]");
}

//tests concatenation of small list with capitalized list
void concatSmallCaps(){
    char a[3] = {'c','a','t'};
    CharLinkedList list1(a,3);
    char b[4] = {'M','A','O','W'};
    CharLinkedList list2(b,4);

    list1.concatenate(&list2);
    assert(list1.size() == 7);
    assert(list1.toString() == "[CharLinkedList of size 7 <<catMAOW>>]");
}

//tests concatenation of large list with small list
void concatLargeSmall(){
    char b[7] = {'i','l','o','v','e','m','y'};
    CharLinkedList list1(b,7);

    char a[3] = {'c','a','t'};
    CharLinkedList list2(a,3);

    list1.concatenate(&list2);
    assert(list1.size() == 10);
    assert(list1.toString() == "[CharLinkedList of size 10 <<ilovemycat>>]");
}

//tests concatenation of large list with large list
void concatLargeLarge(){
    char b[7] = {'i','l','o','v','e','m','y'};
    CharLinkedList list1(b,7);

    char a[7] = {'i','l','o','v','e','m','y'};
    CharLinkedList list2(b,7);

    list1.concatenate(&list2);
    assert(list1.size() == 14);
    assert(list1.toString() == 
    "[CharLinkedList of size 14 <<ilovemyilovemy>>]");
}

//tests concatenation of large with list list with caps
void concatLargeCaps(){
    char b[7] = {'i','l','o','v','e','m','y'};
    CharLinkedList list1(b,7);

    char a[3] = {'C','A','T'};
    CharLinkedList list2(a,3);

    list1.concatenate(&list2);
    assert(list1.size() == 10);
    assert(list1.toString() == "[CharLinkedList of size 10 <<ilovemyCAT>>]");
}

/*
======== PRIVATE FUNCTION TESTS START HERE !!!!! ======== 

//-------- addANode ----------
//tests addANode, makes sure all values are assigned correctly
void addANodeTests() {
     CharLinkedList charList; 

    CharLinkedList::Node* node1 = charList.addANode('a', nullptr, nullptr);
    assert(node1->data == 'a');
    assert(node1->next == nullptr);
    assert(node1->last == nullptr);

    CharLinkedList::Node* node2 = charList.addANode('b', node1, nullptr);
    assert(node2->data == 'b');
    assert(node2->next == node1);
    assert(node2->last == nullptr);

    CharLinkedList::Node* node3 = charList.addANode('c', nullptr, node2);
    assert(node3->data == 'c');
    assert(node3->next == nullptr);
    assert(node3->last == node2);

    CharLinkedList::Node* node4 = charList.addANode('d', node1, node2);
    assert(node4->data == 'd');
    assert(node4->next == node1);
    assert(node4->last == node2);

    delete node1;
    delete node2;
    delete node3;
    delete node4;
}

//-------- replaceAtHelper ----------
//tests replaceAtHelper, makes sure it recursively adds to linked list
void replaceAtHelperTests() {
    CharLinkedList list;

    list.pushAtBack('a');
    list.pushAtBack('b');
    list.pushAtBack('c');

    list.replaceAtHelper(list.front, 'x', 0);
    assert(list.elementAt(0) == 'x');

    list.replaceAtHelper(list.front, 'y', 1);
    assert(list.elementAt(1) == 'y');

    list.replaceAtHelper(list.front, 'z', 2);
    assert(list.elementAt(2) == 'z');

    try {
        list.replaceAtHelper(list.front, 'w', 3);
        assert(false);
    } catch (const std::range_error& e) {
        assert(true);
    }
}

//-------- elemAtRecursive ----------
//tests elemAtRecursive, see if it successfully runs through
//linked list recursively
void elemAtRecTest(){
    CharLinkedList list;

    list.pushAtBack('a');
    list.pushAtBack('b');
    list.pushAtBack('c');

    assert(list.elemAtRecursive(list.front, 0) == 'a');
    assert(list.elemAtRecursive(list.front, 1) == 'b');
    assert(list.elemAtRecursive(list.front, 2) == 'c');

    try {
        list.elemAtRecursive(list.front, 3);
        assert(false);
    } catch (const std::range_error& e) {
        assert(true);
    }

}

//-------- destructor ----------
//tests destructor helper, see if it recursively deletes the linked list
void destructorTests(){
    CharLinkedList list;

    list.pushAtBack('a');
    list.pushAtBack('b');
    list.pushAtBack('c');

    list.destructor(list.front);

    assert(list.size() == 0);
}
*/
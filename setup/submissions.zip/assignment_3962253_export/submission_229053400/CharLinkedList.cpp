/*
 *  CharLinkedList.cpp
 *  Meba Henok
 *  2/2/24
 *  
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Functions titles and their implemntations 
 *
 */

#include "CharLinkedList.h"
#include <sstream>
#include <string>
#include <stdexcept>
#include <iostream>


/*
 * name:      CharLinkedList defualt constuctor
 * purpose:   initialize an empty node with a nullptr
 * arguments: none
 * returns:   none
 * effects:   makes a node with a pointer
 */
CharLinkedList::CharLinkedList(){
    Node *currNode;
    front = nullptr;
    back = nullptr;
}

/*
 * name:      CharLinkedList constructor
 * purpose:   initialize an ArrayList with one char
 * arguments: char
 * returns:   none
 * effects:   array has one char within
 */
CharLinkedList::CharLinkedList(char c){
    Node *currNode = new Node;
    currNode->letter = c;
    front = currNode;
    back = currNode;
}

/*
 * name:      CharLinkedlist constructor
 * purpose:   create an array list containing the characters in the array 
 * arguments: array and size
 * returns:   none
 * effects:   sets array with
 */
CharLinkedList::CharLinkedList(char arr[], int size){
    for(int i = size; i > 0; i--){
        pushAtFront(arr[i - 1]);
    } 

}

/*
 * name:      CharLinkedList constructor
 * purpose:   makes a deep copy of a given instance 
 * arguments: none
 * returns:   none
 * effects:   user has an copy of the array
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other){
    *this = other;

    
}
/*
 * name:      CharLinkedList destructor
 * purpose:   Goes through the linked List and deletes all the nodes
 * arguments: none
 * returns:   none
 * effects:   deletes all nodes
 */
CharLinkedList::~CharLinkedList(){
    clear();
}
/*
 * name:      CharLinkedList deep copy
 * purpose:   copys an array into a new array
 * arguments: other array
 * returns:   none
 * effects:   array with exact same elements
 */
CharLinkedList& CharLinkedList::operator=(const CharLinkedList &other) {
    for(int i = 0; i < other.size(); i++){
        pushAtBack(other.elementAt(i));
    }

    return *this;
}
/*
 * name:      isEmpty
 * purpose:   determines if the CharLinkedList is empty or not
 * arguments: none
 * returns:   true if CharLinkedList contains no elements, false otherwise
 * effects:   none
 */
bool CharLinkedList::isEmpty() const {
    if(size() == 0){
        return true;
    }
    return false;
}
/*
 * name:      size
 * purpose:   determine the number of items in the CharLinkedList
 * arguments: none
 * returns:   number of elements currently stored in the CharLinkedList
 * effects:   none
 */
int CharLinkedList::size() const {
    int listSize = 0;
    Node *currNode = front;
    while(currNode != nullptr){
        listSize++;
        currNode = currNode->next;
    }
    return listSize;
}
// /*
//  * name:      clear
//  * purpose:   Goes through the linked List and deletes all the nodes
//  * arguments: none
//  * returns:   none
//  * effects:   deletes all nodes
//  */
void CharLinkedList::clear(){
    Node *currNode = front;
    while(currNode != nullptr){
        Node *nextNode = currNode->next;
        delete currNode;
        currNode = nextNode;
    }
    front = nullptr;
    back = nullptr;
}
/*
 * name:      First
 * purpose:   determine the first element of an CharLinkedList
 * arguments: none
 * returns:   first element of an CharLinkedList
 * effects:   none
 */
char CharLinkedList::first() const {
    if (isEmpty()) {
        throw std::runtime_error("cannot get first of empty LinkedList");
    }
    return front->letter;
}
/*
 * name:      Last
 * purpose:   determine the last element of an CharLinkedList
 * arguments: none
 * returns:   last element of an CharLinkedList
 * effects:   none
 */
char CharLinkedList::last() const {
    if (isEmpty()) {
        throw std::runtime_error("cannot get last of empty LinkedList");
    }
    return back->letter;
}

/*
 * name:      pushAtFront
 * purpose:   adds a char at the front of the CharLinkedList
 * arguments: char
 * returns:   none
 * effects:   expands the CharLinkedList by one and pushes all elements back one
 */
void CharLinkedList::pushAtFront(char c){
    Node *currNode = new Node;
    currNode->letter = c;
    currNode->next = front;
    if(not isEmpty()){
        front->previous = currNode;
    }
    else if(isEmpty()){
        back = currNode;
    }
    front = currNode;
    listSize++;
}

/*
 * name:      pushAtBack
 * purpose:   adds a char at the end of the CharLinkedList
 * arguments: char
 * returns:   none
 * effects:   expands the CharLinkedList by one
 */
void CharLinkedList::pushAtBack(char c){
    Node *currNode = new Node;
    currNode->letter = c;
    currNode->previous = back;
    if(not isEmpty()){
        back->next = currNode;
    }
    else{
        front = currNode;
    }
    back = currNode;
    listSize++;
}

/*
 * name:      InsertAt
 * purpose:   adds a char at the index entered of the CharLinkedList
 * arguments: char and index
 * returns:   none
 * effects:   expands the CharLinkedList by one and pushes all elements back 
*             one after the given index
 */
void CharLinkedList::insertAt(char c, int index){
    if(index == 0){
        pushAtFront(c);
    }
    if(index == size()){
        pushAtBack(c);
    }
    if (index > 0 and index < size()){
        Node *currNode = front;
        for (int i = 0; i < index; i++) {
            currNode = currNode->next;
        }

        Node *newNode = new Node;
        newNode->letter = c;

        newNode->next = currNode;
        newNode->previous = currNode->previous;
        currNode->previous->next = newNode;
        currNode->previous = newNode;
    } 
    else if(index < 0 or index > size()){
        std::stringstream ss;
        ss << "index (" << index << ") not in range [0.." 
        << listSize << "]";
        throw std::range_error(ss.str());

    }
}
/*
 * name:      elementAt
 * purpose:   determine the element at a set index of an CharLinkedList
 * arguments: index
 * returns:   element at a set index
 * effects:   none
 */
char CharLinkedList::elementAt(int index) const {
    if (index < 0 or index > size()) {
        std::stringstream ss;
        ss << "index (" << index << ") not in range [0.." << listSize << "]";
        throw std::range_error(ss.str());
    }
    if (index >= 0 and index <= size()){
        Node *currNode = front;
        for (int i = 0; i < index; i++) {
            currNode = currNode->next;
        }
        return currNode->letter;
    }
}

// /*
//  * name:      InsertInOrder
//  * purpose:   inserts a char into the array list in ASCII order
//  * arguments: char
//  * returns:   none
//  * effects:   expands array by one
//  */
void CharLinkedList::insertInOrder(char c){
    if(isEmpty()){
        pushAtFront(c);
    }
    int index = 0;
    Node *currNode;
    currNode = front;
    bool insertDone = false;
    while(currNode != nullptr and not insertDone){
        if(currNode->letter <= c){
            insertAt(c, index);
            insertDone = true;
        }
        index++;
        currNode = currNode->next;  
    }
    listSize++;
}

/*
 * name:      popFromFront
 * purpose:   deletes first element of an CharLinkedList
 * arguments: none
 * returns:   none
 * effects:   decreases array by one
 */
void CharLinkedList::popFromFront(){
    if (isEmpty()) {
        throw std::runtime_error("cannot pop from empty LinkedList");
    }
    listSize--;
    Node *currNode;
    currNode = front->next;
    delete front;
    front = currNode;
    if(listSize == 0){
        back = nullptr;
    }
    else{
        front->previous = nullptr;
    }
}

/*
 * name:      popFromBack
 * purpose:   deletes last element of an CharLinkedList
 * arguments: none
 * returns:   none
 * effects:   decreases array by one
 */
void CharLinkedList::popFromBack(){
    if (isEmpty()) {
        throw std::runtime_error("cannot pop from empty LinkedList");
    }
    listSize--;
    Node *currNode;
    currNode = back->previous;
    delete back;
    back = currNode;
    if(listSize == 0){
        front = nullptr;
    }
    else{
        back->next = nullptr;
    }
}

/*
 * name:      removeAt
 * purpose:   deletes an element at a set index of an CharLinkedList
 * arguments: index
 * returns:   none
 * effects:   decreases array by one
 */
void CharLinkedList::removeAt(int index){
    if (index < 0 or index > size()) {
        std::stringstream ss;
        ss << "index (" << index << ") not in range [0.." << listSize << "]";
        throw std::range_error(ss.str());
    }
    listSize--;
    if(index == 0){
        popFromFront();
    }
    if(index == size()){
        popFromBack();
    }
    if (index > 0 and index < size()){
        Node *currNode = front;
        for (int i = 0; i < index; i++) {
            currNode = currNode->next;
        }
        currNode->previous->next = currNode->next;
        currNode->next->previous = currNode->previous;
        delete currNode;
    }
}

/*
 * name:      replaceAt
 * purpose:   replaces an element at a set index of an Linked List
 * arguments: index and char
 * returns:   none
 * effects:   none
 */
void CharLinkedList::replaceAt(char c, int index){
    if (index < 0 or index >= listSize) {
        std::stringstream ss;
        ss << "index (" << index << ") not in range [0.." << listSize << "]";
        throw std::range_error(ss.str());
    }
    if (index >= 0 and index <= size()){
        Node *currNode = front;
        for (int i = 0; i < index; i++) {
            currNode = currNode->next;
        }
        currNode->letter = c;
    }
}

/*
 * name:      concatenate
 * purpose:   combines two arraylist char into one string
 * arguments: pointer to another array
 * returns:   none
 * effects:   combines two arrayLists
 */
 //NEED TO WORK ON THIS
 void CharLinkedList::concatenate(CharLinkedList *other){
    int numToCopy = other->size();
    for (int i = 0; i < numToCopy; i++) {
        pushAtBack(other->elementAt(i));
    }
}

/*
 * name:      toString
 * purpose:   make a string out of a CharLinkedList
 * arguments: none
 * returns:   the string word
 * effects:   none
 */
std::string CharLinkedList::toString() const {
    std::stringstream ss;
    Node *currNode;
    currNode = front;
    ss << "[CharLinkedList of size " << listSize << " <<";
    while (currNode != nullptr) {
        ss << currNode->letter;
        currNode = currNode->next;
    }
    ss << ">>]";
    return ss.str();
}
/*
 * name:      toReverseString
 * purpose:   make a string out of a CharLinkedList in reverse
 * arguments: none
 * returns:   the string word backwords
 * effects:   none
 */
std::string CharLinkedList::toReverseString() const {
    std::stringstream ss;
    Node *currNode;
    currNode = back;
    ss << "[CharLinkedList of size " << listSize << " <<";
    while (currNode != nullptr) {
        ss << currNode->letter;
        currNode = currNode->previous;
    }
    ss << ">>]";
    return ss.str();
}
 
    


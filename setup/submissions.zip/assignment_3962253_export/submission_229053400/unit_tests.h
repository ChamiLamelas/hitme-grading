/*
 *  unit_tests.h
 *  Meba Henok
 *  2/2/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  FILE PURPOSE HERE
 *
 */

#include "CharLinkedList.h"
#include <cassert>

//test to see if array list was created with no major problems
void constructor_test_1(){
    CharLinkedList list;
}

// test to see if constructor with letter argument is created
void constructor_test_2(){
    CharLinkedList list('c');
    assert(list.size() == 1);
    assert(list.isEmpty() == false);
}
// test to see if constructor with arugments with an array of char and a size 
// is created
void constructor_test_3(){
    char arr[3] = {'h', 'e', 'y'};
    CharLinkedList list(arr, 4);
    assert(list.size() == 4);
}
void constructor_test_4(){
    char arr1[3] = {'a', 'b', 'c'};
    CharLinkedList originalList(arr1, 3);

    // Create a new list and assign the original list to it
    CharLinkedList assignedList;
    assignedList = originalList;

    // Check if the sizes are the same
    assert(originalList.size() == assignedList.size());

    // Check if the elements are the same
    for (int i = 0; i < originalList.size(); ++i) {
        assert(originalList.elementAt(i) == assignedList.elementAt(i));
    }
}
//Test to find the size of the array
void size_test_1(){
    char arr[3] = {'h', 'e', 'y'};
    CharLinkedList list(arr, 3);
    assert(list.size() == 3);
}
//Test to find the size of the array
void size_test_2(){
    CharLinkedList list;
    assert(list.size() == 0);
}
//Test to find the first char in the linked list
void find_first_test_1(){
    char arr[3] = {'h', 'e', 'y'};
    CharLinkedList list(arr, 4);
    assert(list.first() == 'h');
}
//Test to find the first char in the linked with only on letter
void find_first_test_2(){
    char arr[3] = {'a'};
    CharLinkedList list(arr, 4);
    assert(list.first() == 'a');
}
//Test to find the first char in the linked with only on letter
void find_first_test_3(){
    CharLinkedList test_list;
    std::string error_message = "";
    bool runtime_error_thrown = false;
    try{
        assert(test_list.first() == 'a');
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot get first of empty LinkedList");
}
//Test to find the last char in the linked list
void find_last_test_1(){
    char arr[3] = {'h', 'e', 'y'};
    CharLinkedList list(arr, 3);
    assert(list.last() == 'y');
}
//Test to find the last char in the linked with only on letter
void find_last_test_2(){
    char arr[1] = {'a'};
    CharLinkedList list(arr, 1);
    assert(list.last() == 'a');
}
//Test to find the last char in the linked with only on letter
void find_last_test_3(){
    CharLinkedList test_list;
    std::string error_message = "";
    bool runtime_error_thrown = false;
    try{
        assert(test_list.last() == 'a');
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot get last of empty LinkedList");
}
// Test to see if push at front works with a large number of letters
void pushAtFront_test_1(){
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    test_list.pushAtFront('c');
    assert(test_list.elementAt(0) == 'c');
}
// Test to see if push at front works with an empty linked list
void pushAtFront_test_2(){
    CharLinkedList test_list;

    test_list.pushAtFront('a');
    assert(test_list.elementAt(0) == 'a');
}
//test to see if push at front works with a linked list of a small amount of
// letters
void pushAtFront_test_3(){
    char test_arr[1] = { 'b' };
    CharLinkedList test_list(test_arr, 1);
    test_list.pushAtFront('a');
    assert(test_list.elementAt(0) == 'a');
}
// Test to see if push at back works with a large number of letters
void pushAtBack_test_1(){
    char test_arr[3] = { 'a', 'b', 'c'};
    CharLinkedList test_list(test_arr, 3);

    test_list.pushAtBack('d');
    assert(test_list.size() == 4);
    assert(test_list.elementAt(3) == 'd');
}
// Test to see if push at back works with an empty linked list

void pushAtBack_test_2(){
    CharLinkedList test_list;

    test_list.pushAtBack('a');
    // assert(test_list.elementAt(0) == 'a');
}
//test to see if push at back works with a linked list of a small amount of
// letters
void pushAtBack_test_3(){
    char test_arr[1] = { 'b' };
    CharLinkedList test_list(test_arr, 1);
    test_list.pushAtBack('a');
    assert(test_list.elementAt(1) == 'a');
}
// Function to test finding an element at a specific index in a list 
// when element is not in range
void find_elementAt_test_1(){
    std::string error_message = "";
    bool range_error_thrown = false;
    char arr[3] = {'h', 'e', 'y'};
    CharLinkedList list(arr, 4);
    try{
        assert(list.elementAt(5) == 'h');
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (5) not in range [0..4]");
}
// Function to test finding an element at a specific index in a list 
// within valid range
void find_elementAt_test_2(){
    char arr[3] = {'b', 'e', 'y'};
    CharLinkedList list(arr, 4);
    assert(list.elementAt(0) == 'b');
}
// Function to test finding an element at a specific index in a list 
// within valid range and out of range
void find_elementAt_test_3(){
    std::string error_message = "";
    bool range_error_thrown = false;
    char arr[3] = {'b', 'e', 'y'};
    CharLinkedList list(arr, 4);
    assert(list.elementAt(0) == 'b');
    try{
        assert(list.elementAt(5) == 'h');
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (5) not in range [0..4]");
}
// Test to find if pop from front works correctly on a linked list
void popFromFront_test_1(){
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    test_list.popFromFront();
    assert(test_list.elementAt(0) == 'b');
}
// test to find if pop throws an error when popping from empty list
void popFromFront_test_2(){
    CharLinkedList test_list;
    std::string error_message = "";
    bool runtime_error_thrown = false;
    try{
        test_list.popFromFront();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}
// Test to find if pop from front works correctly on a linked list with one
// element
void popFromFront_test_3(){
    char test_arr[1] = { 'a'};
    CharLinkedList test_list(test_arr, 1);

    test_list.popFromFront();
}
// Test to find if pop from front works correctly on a linked list with one
// element
void popFromFront_test_4(){
    char test_arr[1] = { 'a'};
    CharLinkedList test_list(test_arr, 1);

    test_list.popFromFront();
    std::string error_message = "";
    bool runtime_error_thrown = false;
    try{
        test_list.popFromFront();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}
// Test to find if pop from Back works correctly on a linked list
void popFromBack_test_1(){
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    test_list.popFromBack();
    assert(test_list.elementAt(7) == 'g');
}
// test to find if pop throws an error when popping from empty list
void popFromBack_test_2(){
    CharLinkedList test_list;
    std::string error_message = "";
    bool runtime_error_thrown = false;
    try{
        test_list.popFromBack();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty Linked List");
}
// Test to find if pop from Back works correctly on a linked list with one
// element
void popFromBack_test_3(){
    char test_arr[1] = {'a'};
    CharLinkedList test_list(test_arr, 1);
    std::cout << test_list.toString() << std::endl;

    test_list.popFromBack();
}

// Test to see if replace at works on a linked list in range
void replaceAt_test_1(){
    char arr[3] = {'b', 'e', 'y'};
    CharLinkedList list(arr, 4);
    list.replaceAt('c', 1);
    assert(list.elementAt(1) == 'c');
}
// Function to test replacing an element at a specific index in a list 
// when element is not in range
void replaceAt_test_2(){
    std::string error_message = "";
    bool range_error_thrown = false;
    char arr[3] = {'h', 'e', 'y'};
    CharLinkedList list(arr, 4);
    try{
        list.replaceAt('g', 5);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (5) not in range [0..4]");
}
// replaces a letter when there is only one letter in the array
void replaceAt_test_3(){
    char arr[1] = {'b'};
    CharLinkedList list(arr, 1);
    list.replaceAt('c', 0);
    assert(list.elementAt(0) == 'c');
}

// removes an element from the middle of the list
void removeAt_test_1(){
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    test_list.removeAt(6);
    assert(test_list.elementAt(6) == 'g');
}
// test to find if pop throws an error when popping from empty list
void removeAt_test_2(){
    std::string error_message = "";
    bool range_error_thrown = false;
    char arr[3] = {'h', 'e', 'y'};
    CharLinkedList test_list(arr, 4);
    try{
        test_list.removeAt(6);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (6) not in range [0..4]");
}
// Test to find if pop from Back works correctly on a linked list with one
// element
void removeAt_test_3(){
    char test_arr[1] = {'a'};
    CharLinkedList test_list(test_arr, 1);
    test_list.removeAt(0);
}
// remove first element
void removeAt_test_4(){
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    test_list.removeAt(0);
    assert(test_list.elementAt(0) == 'b');
}
// remove last element and throw an error
void removeAt_test_5(){
    std::string error_message = "";
    bool range_error_thrown = false;
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    test_list.removeAt(9);
    try{
        assert(test_list.elementAt(9) == 'h');
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (9) not in range [0..7]");
}
// Test to see if push at front works with a large number of letters
void insertAt_test_1(){
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    test_list.insertAt('j', 3);
    assert(test_list.elementAt(3) == 'j');
}
// Test to see if push at front works with an empty linked list
void insertAt_test_2(){
    CharLinkedList test_list;

    test_list.insertAt('a', 0);
    assert(test_list.elementAt(0) == 'a');
}
//test to see if push at front works with a linked list of a small amount of
// letters
void insertAt_test_3(){
    char test_arr[1] = { 'b' };
    CharLinkedList test_list(test_arr, 1);
    test_list.insertAt('a', 1);
    assert(test_list.elementAt(1) == 'a');
}
// test to find if pop throws an error when popping from empty list
void insertAt_test_4(){
    std::string error_message = "";
    bool range_error_thrown = false;
    char arr[3] = {'h', 'e', 'y'};
    CharLinkedList test_list(arr, 4);
    try{
        test_list.insertAt('c', 6);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (6) not in range [0..4]");
}
// Test to see if insert in order works with a large number of letters
void insertInOrder_test_1(){
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    test_list.insertInOrder('j');
    assert(test_list.elementAt(3) == 'j');
}
// // Test to see if insert in order works with an empty linked list
void insertInOrder_test_2(){
    CharLinkedList test_list;

    test_list.insertInOrder('a');
    assert(test_list.elementAt(0) == 'a');
}
//test to see if insert in order works with a linked list of a one letter
void insertInOrder_test_3(){
    char test_arr[1] = { 'b' };
    CharLinkedList test_list(test_arr, 1);
    test_list.insertInOrder('a');
    assert(test_list.elementAt(0) == 'a');
}
//test to see if insert in order works with a linked list of a small amount of
// letters
void insertInOrder_test_4(){
    char test_arr[3] = { 'd', 'c', 'j' };
    CharLinkedList test_list(test_arr, 3);

    test_list.insertInOrder('a');
    assert(test_list.elementAt(0) == 'a');
}
// // test to string on a big list
void toString_test_1(){
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    assert(test_list.toString() == "[CharLinkedList of size 9 <<abczdefgh>>]");
}
// test to string on a list of size one
void toString_test_2(){
    char test_arr[1] = { 'a' };
    CharLinkedList test_list(test_arr, 1);

    assert(test_list.toString() == "[CharLinkedList of size 1 <<a>>]");
}
//test to string on an empty list
void toString_test_3(){
    char test_arr[0] = {};
    CharLinkedList test_list(test_arr, 0);

    assert(test_list.toString() == "[CharLinkedList of size 0 <<>>]");
}
// // test to string on a big list
void toReverseString_test_1(){
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    assert(test_list.toReverseString() == 
        "[CharLinkedList of size 9 <<hgfedzcba>>]");
}
// // test to string on a list of size one
void toReverseString_test_2(){
    char test_arr[1] = { 'a' };
    CharLinkedList test_list(test_arr, 1);

    assert(test_list.toReverseString() == "[CharLinkedList of size 1 <<a>>]");
}
//test to string on an empty list
void toReverseString_test_3(){
    char test_arr[0] = {};
    CharLinkedList test_list(test_arr, 0);

    assert(test_list.toReverseString() == "[CharLinkedList of size 0 <<>>]");
}

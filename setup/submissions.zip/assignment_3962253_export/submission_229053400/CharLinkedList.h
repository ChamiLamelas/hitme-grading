/*
 *  CharLinkedList.h
 *  Meba Henok
 *  2/2/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  The purpose of the program is to allow the user to modify a linked list 
 *  of char however they see if using operations such as, removing from the 
 *  front and back, adding and removing elements at curtain places in the list 
 *  and making a string out of the char values.
 *
 */

#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H
#include <string>

class CharLinkedList {
      public:
        CharLinkedList();
        CharLinkedList(char c);
        CharLinkedList(char arr[], int size);
        CharLinkedList(const CharLinkedList &other);
        ~CharLinkedList();
        CharLinkedList &operator=(const CharLinkedList &other);
        bool isEmpty() const;
        int size() const;
        char first() const;
        char last() const;
        char elementAt(int index) const;
        std::string toString() const;
        std::string toReverseString() const;
        void pushAtBack(char c);
        void pushAtFront(char c);
        void insertAt(char c, int index);
        void insertInOrder(char c);
        void popFromFront();
        void popFromBack();
        void removeAt(int index);
        void replaceAt(char c, int index);
        void concatenate(CharLinkedList *other);
        void clear();


    private:
        struct Node{
            char letter;
            Node *next = nullptr;
            Node *previous = nullptr; 
        };
        Node *front = nullptr;
        Node *back = nullptr;
        int listSize = 0;
        //Node *CharLinkedList nodeAt(Node *currNode, )

};

#endif

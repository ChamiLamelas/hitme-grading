/*
 *  CharLinkedList.cpp
 *  Mainak Nistala
 *  30/01/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Purpose: Implementation for a doubly linked list of characters
 *
 */

#include "CharLinkedList.h"
#include <stdexcept>
#include <sstream>


/*
 * Default constructor
 * Purpose: initializes an empty CharLinkedList
 * Arguments: none
*/
CharLinkedList::CharLinkedList() {
    front = nullptr;
    back = nullptr;
    currSize = 0;
}


/*
 * Single character constructor
 * purpose: initializes a CharLinkedList with a single character
 * arguments: 
 *   char c: the character to initialize the list with
*/
CharLinkedList::CharLinkedList(char c) {
    front = new Node(c, nullptr, nullptr);
    back = front;
    currSize = 1;
}

/*
 * Array constructor
 * purpose: initializes a CharLinkedList with an array of characters
 * arguments: 
 *   char arr[]: the array of characters to initialize the list with
 *   int size: the size of the array
*/
CharLinkedList::CharLinkedList(char arr[], int size) {
    currSize = 0;
    //Push each element of the array to the back of the list
    for (int i = 0; i < size; ++i) {
        pushAtBack(arr[i]);
    }
}

/*
 * Copy constructor
 * purpose: initializes a CharLinkedList with the elements of another list
 * arguments: 
 *   CharLinkedList &other: the list to make a deep copy of
*/
CharLinkedList::CharLinkedList(const CharLinkedList &other) {
    currSize = 0;
    //Push each element of the other list to the back of this list
    Node *currNode = other.front;
    while (currNode != nullptr) {
        pushAtBack(currNode->val);
        currNode = currNode->next;
    }
}

/*
 * Assignment operator
 * purpose: assigns the elements of another list to this list
 * arguments:
 *   CharLinkedList &other: the list to assign to this list
 * returns:   CharLinkedList: the list with the assigned elements
*/
CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other) {
    if (this == &other) { //Check if self assignment
        return *this;
    }
    clear(); //Clear the current list
    currSize = 0;
    //Push each element of the other list to the back of this list
    Node* otherNode = other.front;
    while (otherNode != nullptr) {
        pushAtBack(otherNode->val);
        otherNode = otherNode->next;
    }
    return *this;
}

//Destructor
CharLinkedList::~CharLinkedList() {
    if (currSize > 0) clear_helper(front);
}

/*
 * name:      isEmpty
 * purpose:   returns whether or not the CharLinkedList is empty
 * returns:   true if CharLinkedList is empty, false otherwise
 */
bool CharLinkedList::isEmpty() const {
    return front == nullptr;
}

/*
 * name:      clear
 * purpose:   clears the CharLinkedList
*/
void CharLinkedList::clear() {
    if (currSize > 0) clear_helper(front);
}

/*
 * name:      size
 * purpose:   returns the size of the CharLinkedList
 * returns:   int: the size of the CharLinkedList
 */
int CharLinkedList::size() const {
    return currSize;
}

/*
 * name:      first
 * purpose:   returns the first element of the CharLinkedList
 * returns:   char: the first element of the CharLinkedList
 */
char CharLinkedList::first() const {
    if (front == nullptr) {
        throw std::runtime_error("cannot get first of empty LinkedList");
    }
    return front->val;
}

/*
 * name:      last
 * purpose:   returns the last element of the CharLinkedList
 * returns:   char: the last element of the CharLinkedList
 */
char CharLinkedList::last() const {
    if (back == nullptr) {
        throw std::runtime_error("cannot get last of empty LinkedList");
    }
    return back->val;
}

/*
 * name:      elementAt
 * purpose:   returns the element at the given index of the CharLinkedList
 * arguments:
 *   int index: the index of the element to return
 * returns:   char: the element at the given index of the CharLinkedList
 * effects:   throws a std::range_error if the index is out of range
 */
char CharLinkedList::elementAt(int index) const {
    if (index < 0 or index >= currSize) { //Check if out of range
        throw std::range_error(
            "index (" + std::to_string(index) + 
            ") not in range [0.." + std::to_string(currSize) + ")"
        );
    }
    return findNode(index)->val;
}

/*
 * name:      toString
 * purpose:   returns the CharLinkedList as a formatted string
 * returns:   CharLinkedList as a formatted string
 */
std::string CharLinkedList::toString() const {
    std::string str = "";
    Node *currNode = front;
    while (currNode != nullptr) {
        str += currNode->val; //Add to back of string
        currNode = currNode->next;
    }
    return formatString(str);
}

/*
 * name:      toReverseString
 * purpose:   returns the CharLinkedList as a formatted string in reverse
 * returns:   CharLinkedList as a formatted string in reverse
 */
std::string CharLinkedList::toReverseString() const {
    std::string str = "";
    Node *currNode = front;
    while (currNode != nullptr) {
        str = currNode->val + str; //Add to front of string
        currNode = currNode->next;
    }
    return formatString(str);
}

/*
 * name:      pushAtBack
 * purpose:   pushes a character to the back of the CharLinkedList
 * arguments:
 *   char c: the character to push to the back of the CharLinkedList
 * other:     increases size by 1, creates a new node at the back 
              with value c, and sets the last node to the new node
 */
void CharLinkedList::pushAtBack(char c) {
    if (currSize == 0) { //Check if empty linked list
        front = new Node(c, nullptr, nullptr);
        back = front;
        currSize = 1;
    } else { //Add to back of list
        back->next = new Node(c, nullptr, back);
        back = back->next; //Set back to new node
        currSize++;
    }
}

/*
 * name:      pushAtFront
 * purpose:   pushes a character to the front of the CharLinkedList
 * arguments:
 *   char c: the character to push to the front of the CharLinkedList
 * other:     increases size by 1, creates a new node at the front 
              with value c, and sets the first node to the new node
 */
void CharLinkedList::pushAtFront(char c) {
    if (currSize == 0) { //Check if empty linked list
        currSize = 1;
        front = new Node(c, nullptr, nullptr);
        back = front;
    } else { //Add to front of list
        Node *newFront = new Node(c, front, nullptr);
        front->prev = newFront;
        front = newFront; //Set front to new node
        currSize++;
    }
}

/*
 * name:      insertAt
 * purpose:   inserts a character at the given index of the CharLinkedList
 * arguments:
 *   char c: the character to insert
 *   int index: the index to insert the character at
 * effects:   throws a std::range_error if the index is out of range
 * other:     increases size by 1, creates a new node at the index 
              with value c, and changes pointers to next/prev node accordingly
 */
void CharLinkedList::insertAt(char c, int index) {
    if (index < 0 or index > currSize) { //Check if out of range
        throw std::range_error(
            "index (" + std::to_string(index) + 
            ") not in range [0.." + std::to_string(currSize) + "]"
        );
    }
    if (index == 0) pushAtFront(c);
    else if (index == currSize) pushAtBack(c);
    else {
        Node* nodeAtIndex = findNode(index); //Find the node at the index
        //Inserts new node between the node at the index and the node before it
        Node* newNode = new Node(c, nodeAtIndex, nodeAtIndex->prev);
        //Points the previous node to the new node (next pointer)
        nodeAtIndex->prev->next = newNode;
        //Points the next node back to the new node (prev pointer)
        nodeAtIndex->prev = newNode;
        currSize++;
    }
}

/*
 * name:      insertInOrder
 * purpose:   inserts a character in order in the CharLinkedList
 * arguments:
 *   char c: the character to insert
 * other:     inserts a new node into the linked list in ASCII order, increases
              size by 1, and accordingly changes pointers to next/prev node
 */
void CharLinkedList::insertInOrder(char c) {
    Node *currNode = front;
    bool inserted = false;
    for (int i = 0; i < currSize and not inserted; ++i) {
        if (currNode->val > c) { //Inserts at the first node greater than c
            insertAt(c, i);
            inserted = true;
        }
        currNode = currNode->next;
    }
    //If c is greater than all elements, insert at the end
    if (not inserted) insertAt(c, currSize);
}

/*
 * name:      popFromFront
 * purpose:   pops a character from the front of the CharLinkedList
 * effects:   throws a std::runtime_error if the CharLinkedList is empty
 * other:     decreases size by 1, deletes the first node, and sets the new 
              front to the next node if one exists
 */
void CharLinkedList::popFromFront() {
    if (currSize == 0) { //Check if empty linked list
        throw std::runtime_error("cannot pop from empty LinkedList");
    } else if (currSize == 1) {
        delete front;
        front = nullptr;
        back = nullptr;
    } else {
        Node *newFront = front->next;
        delete front;
        front = newFront;
        front->prev = nullptr;
    }
    currSize--;
}

/*
 * name:      popFromBack
 * purpose:   pops the character at the back of the CharLinkedList
 * effects:   throws a std::runtime_error if the CharLinkedList is empty
 * other:     decreases size by 1, deletes the last node, and sets the new 
              back to the previous node if one exists
 */
void CharLinkedList::popFromBack() {
    if (currSize == 0) { //Check if empty array
        throw std::runtime_error("cannot pop from empty LinkedList");
    }
    if (front == back) { //If only one element
        delete front;
        front = nullptr;
        back = nullptr;
    } else { //Remove the last element
        Node* tempNode = back->prev;
        delete back;
        tempNode->next = nullptr;
        back = tempNode;
    }
    currSize--;
}

/*
 * name:      removeAt
 * purpose:   removes the character at the given index of the CharLinkedList
 * arguments:
 *   int index: the index of the character to remove
 * effects:   throws a std::range_error if the index is out of range
 * other:     decreases size by 1, deletes the node at the index, and changes 
              pointers to next/prev node for surrounding nodes accordingly
 */
void CharLinkedList::removeAt(int index) {
    if (index < 0 or index >= currSize) { //Check if out of range
        throw std::range_error(
            "index (" + std::to_string(index) + 
            ") not in range [0.." + std::to_string(currSize) + ")"
        );
    }
    if (index == 0) popFromFront(); //Edge case of removing first element
    else if (index == currSize - 1) popFromBack(); //Edge case of last element
    else {
        Node* nodeAtIndex = findNode(index); //Find the node at the index
        Node* prevNode = nodeAtIndex->prev;
        Node* nextNode = nodeAtIndex->next;
        prevNode->next = nextNode;
        nextNode->prev = prevNode;
        delete nodeAtIndex;
        currSize--;
    }
}

/*
 * name:      replaceAt
 * purpose:   replaces the character at the given index of the CharLinkedList
 * arguments:
 *   char c: the character to replace the current character with
 *   int index: the index of the character to replace
 * effects:   throws a std::range_error if the index is out of range
 * other:     replaces the value of the node at the index with c
 */
void CharLinkedList::replaceAt(char c, int index) {
    if (index < 0 or index >= currSize) { //Check if out of range
        throw std::range_error(
            "index (" + std::to_string(index) + 
            ") not in range [0.." + std::to_string(currSize) + ")"
        );
    }
    Node* nodeAtIndex = findNode(index); //Find the node at the index

    nodeAtIndex->val = c; //Replace the value
}

/*
 * name:      concatenate
 * purpose:   concatenates the given CharLinkedList 
              to the end of this CharLinkedList
 * arguments:
 *   CharLinkedList *other: the CharLinkedList to concatenate at the end of this
 * other:     increases size by the size of the other list, and pushes each 
              element of the other list to the back of this list
 */
void CharLinkedList::concatenate(CharLinkedList *other) {
    int newElements = other->size(); //Number of new elements
    Node *otherNode = other->front;
    for (int i = 0; i < newElements; ++i) {
        pushAtBack(otherNode->val); //Push each element of other list to back
        otherNode = otherNode->next;
    }
}

/*
 * name:      formatString
 * purpose:   formats the given string with the size of the CharLinkedList
 * arguments:
 *   std::string str: the string to format
 * returns:   the formatted string
 */
std::string CharLinkedList::formatString(std::string str) const {
    std::stringstream ss; //Allows me to use << to join info into a string
    ss << "[CharLinkedList of size " << currSize << " <<" << str << ">>]";
    return ss.str();
}

/*
 * name:      findNode
 * purpose:   finds the node at the given index of the CharLinkedList
 * arguments:
 *   int index: the index of the node to find
 * returns:   the node at the given index of the CharLinkedList
 * other:     starts the recursion from the front or back of the list 
              depending on which is closer to the index
 */
CharLinkedList::Node* CharLinkedList::findNode(int index) const {
    if (currSize - index < index) {
        return findNodeHelper(back, currSize - 1, index);
    } else {
        return findNodeHelper(front, 0, index);
    }
}

/*
 * name:      findNodeHelper
 * purpose:   helper function to find the node at the given index
              of the CharLinkedList recursively
 * arguments:
 *   Node* currNode: the current node to check
 *   int currIndex: the current index of the node
 *   int index: the index of the node to find
 * returns:   the node at the given index of the CharLinkedList
 */
CharLinkedList::Node* CharLinkedList::findNodeHelper
(Node* currNode, int currIndex, int index) const {
    if (currIndex == index) return currNode;
    if (currIndex > index) {
        return findNodeHelper(currNode->prev, currIndex - 1, index);
    } else {
        return findNodeHelper(currNode->next, currIndex + 1, index);
    }
}

/*
 * name:      clear_helper
 * purpose:   helper function to clear the CharLinkedList recursively
 * arguments:
 *   Node* node: the current node to delete
 * other:     deletes each node in the linked list and sets the front and back 
              to nullptr
 */
void CharLinkedList::clear_helper(Node* node) {
    if (node == nullptr) {
        front = nullptr;
        back = nullptr;
        currSize = 0;
    } else {
        Node* newNode = node->next;
        delete node;
        --currSize;
        clear_helper(newNode);
    }
}

//Node constructor
CharLinkedList::Node::Node(char value, Node* nextNode, Node* prevNode) {
    val = value;
    next = nextNode;
    prev = prevNode;
}

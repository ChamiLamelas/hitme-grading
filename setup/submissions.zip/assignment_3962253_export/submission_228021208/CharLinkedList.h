/*
 *  CharLinkedList.h
 *  Mainak Nistala
 *  03/01/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Purpose: Defines a CharLinkedList class that represents a character array.
 *  Can be constructed with a single character, an array of characters,
 *  empty, or a deep copy of another CharLinkedList.
 *  Various functions allow for manipulating the CharLinkedList in various ways.
 *
 */

#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H

#include <iostream>

class CharLinkedList {
    public:
        CharLinkedList();
        CharLinkedList(char c);
        CharLinkedList(char arr[], int size);
        CharLinkedList(const CharLinkedList &other);
        CharLinkedList &operator=(const CharLinkedList &other);

        ~CharLinkedList();
        
        bool isEmpty() const;
        void clear();
        int size() const;
        char first() const;
        char last() const;
        char elementAt(int index) const;
        std::string toString() const;
        std::string toReverseString() const;
        void pushAtBack(char c);
        void pushAtFront(char c);
        void insertAt(char c, int index);
        void insertInOrder(char c);
        void popFromFront();
        void popFromBack();
        void removeAt(int index);
        void replaceAt(char c, int index);
        void concatenate(CharLinkedList *other);

    private:
        struct Node {
            char val;
            Node *next;
            Node *prev;
            Node(char value, Node* nextNode, Node* prevNode);
        };

        Node *front;
        Node *back;
        int currSize;

        std::string formatString(std::string str) const;
        Node* findNode(int index) const;
        Node* findNodeHelper(Node* currNode, int currIndex, int index) const;
        void clear_helper(Node* node);

};

#endif

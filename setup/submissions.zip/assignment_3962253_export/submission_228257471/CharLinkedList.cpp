/*
 *  CharLinkedList.cpp
 *  Curt Johnson
 *  Feb 3 2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  implementation of CharLinkedList class
 *
 */

#include "CharLinkedList.h"
#include <iostream>

/*
 * name: CharLinkedList
 * purpose: default constructor for CharLinkedList
 * arguments: none
 * returns: none
 * effects: creates new empty instance of CharLinkedList
 */
CharLinkedList::CharLinkedList()
{
    numItems = 0;
    front = nullptr;
    back = nullptr;
}

/*
 * name: recycleRecursive
 * purpose: recycles memory stored on the heap
 * arguments: pointer to node
 * returns: none
 * effects: recursively recycles dynamically stored memory 
 */
void CharLinkedList::recycleRecursive(Node *curr) {
    if (curr == nullptr) {
        return;
    } else {
        Node *temp = curr->next;
        delete curr;
        recycleRecursive(temp);
    }
}

/*
 * name: ~CharLinkedList
 * purpose: destructor for CharLinkedList
 * arguments: none
 * returns: none
 * effects: calls helper function to recursively recycle 
 * dynamically stored memory 
 */
CharLinkedList::~CharLinkedList() {
    recycleRecursive(front);
}

/*
 * name: newNode
 * purpose: creates new nodes on the heap
 * arguments: char representing character value of what to store in node,
 * and node pointers to the previous and next nodes
 * returns: pointer to the newly created node
 * effects: allocates memory on the heap 
 */
CharLinkedList::Node *CharLinkedList::newNode(char newData, Node *next, 
                                                                    Node *prev)
{
    Node *new_node = new Node;
    new_node->data = newData;
    new_node->next = next;
    new_node->prev = prev;
    return new_node;
}

/*
 * name: CharLinkedList
 * purpose: constructor for CharLinkedList
 * arguments: a character
 * returns: none
 * effects: creates an instance of CharLinkedList with a single character
 */
CharLinkedList::CharLinkedList(char c)
{
    numItems = 0;
    Node *new_node = newNode(c, nullptr, nullptr);
    front = new_node;
    back = new_node;
    numItems++;
}

/*
 * name: CharLinkedList
 * purpose: constructor for CharLinkedList
 * arguments: a character array, and an integer representing the size of 
 * of the array
 * returns: none
 * effects: creates an instance of CharLinkedList with elements from the given
 * array
 */
CharLinkedList::CharLinkedList(char arr[], int size) {
    if (size == 0) {
        numItems = 0;
        front = nullptr;
        back = nullptr;
    } else {
        numItems = size;
        front = newNode(arr[0], nullptr, nullptr);
        Node *curr = front;
        for (int i = 1; i < size; i++) {
            Node *new_node = newNode(arr[i], curr->next, curr);
            curr->next = new_node;
            curr = curr->next;
        }
        back = curr;
    }
}

/*
 * name: CharLinkedList
 * purpose: copy constructor for CharLinkedList
 * arguments: a constant reference to another CharLinkedList
 * returns: none
 * effects: creates a deep copy of the given CharLinkedList
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other)
{
    front = nullptr;
    back = nullptr;
    numItems = 0;

    Node *other_curr = other.front;
    for (int i = 0; i < other.numItems; i++) {
        pushAtBack(other_curr->data);
        other_curr = other_curr->next;
    }
}

/*
 * name: operator=
 * purpose: assignemnt operator for CharLinkedList
 * arguments: constant reference to a CharLinkedList
 * returns: reference to the current CharLinkedList
 * effects: recycles the storage associated with the instance
 * on the left of the assignment and makes a deep copy of the instance on 
 * the right
 */
CharLinkedList& CharLinkedList::operator=(const CharLinkedList &other)
{
    if (this == &other) {
        return *this;
    }

    recycleRecursive(front);
    numItems = 0;
    front = nullptr;
    back = front;
   
    Node *curr = other.front;

    for (int i = 0; i < other.numItems; i++) {
        pushAtBack(curr->data);
        curr = curr->next;
    }

    return *this;
}


/*
 * name: isEmpty
 * purpose: determine if CharLinkedList is empty
 * arguments: none
 * returns: boolean value, true if the CharLinkedList is empty, false if not
 * effects: none
 */
bool CharLinkedList::isEmpty() const
{
    return (numItems == 0);
}

/*
 * name: clear
 * purpose: empties the CharLinkedList
 * arguments: none
 * returns: none
 * effects: makes the CharLinkedList empty
 */
void CharLinkedList::clear()
{
    recycleRecursive(front);
    numItems = 0;
    front = nullptr;
    back = nullptr;
}

/*
 * name: size
 * purpose: get the number of items in CharLinkedList
 * arguments: none
 * returns: an integer value representing the number of 
 * characters in CharLinkedList
 * effects: none
 */
int CharLinkedList::size() const
{
    return numItems;
}

/*
 * name: first
 * purpose: gets the first item in the CharLinkedList
 * arguments: none
 * returns: a character which represents the first item in CharLinkedList
 * effects: raises a runtime_error if the CharLinkedList is empty
 */
char CharLinkedList::first() const
{
    if (isEmpty()) {
        throw std::runtime_error("cannot get first of empty LinkedList");
    }
    return front->data;
}

/*
 * name: last
 * purpose: gets the last item in the CharLinkedList
 * arguments: none
 * returns: a character which represents the last item in CharLinkedList
 * effects: raises a runtime_error if the CharLinkedList is empty
 */
char CharLinkedList::last() const
{
    if (isEmpty()) {
        throw std::runtime_error("cannot get last of empty LinkedList");
    }
    return back->data;
}

/*
 * name: elementAt
 * purpose: gets a CharLinkedList element at a specified index
 * arguments: an integer representing the index in CharLinkedList
 * returns: a character element at the specified index in CharLinkedList
 * effects: Raises a range_error if idx is out-of-bounds of the CharLinkedList
 */
char CharLinkedList::elementAt(int index) const
{
    if (index < 0 or index >= numItems) {
        std::stringstream ss;
        ss << "index (" << index << ") not in range [0.." << numItems 
        << ")";
        throw std::range_error(ss.str());
    }

    Node *result = elementAtHelper(index, 0, front);

    return result->data;
}

CharLinkedList::Node *CharLinkedList::elementAtHelper(int index, int counter,
                                                            Node *curr) const {
    // base case
    if (counter == index) {
        return curr;
    // recursive case
    } else {
        counter++;
        return elementAtHelper(index, counter, curr->next);
    }
}


/*
 * name: toString
 * purpose: strings together the elements in CharLinkedList to for a string
 * arguments: none
 * returns: a string representing CharLinkedList
 * effects: none
 */
std::string CharLinkedList::toString() const
{
    std::stringstream ss;
    Node *curr = front;
    ss << "[CharLinkedList of size " << numItems << " <<";
    for (int i = 0; i < numItems; i++){
        ss << curr->data;
        curr = curr->next;
    }
    ss << ">>]";
    return ss.str();
}

/*
 * name: toReverseString
 * purpose: strings together the elements in CharLinkedList in reverse to 
 * form a string 
 * arguments: none
 * returns: a string which contains the characters of the CharLinkedList 
 * in reverse
 * effects: none
 */
std::string CharLinkedList::toReverseString() const
{
    std::stringstream ss;
    Node *curr = back;
    ss << "[CharLinkedList of size " << numItems << " <<";
    for (int i = 0; i < numItems; i++) {
        ss << curr->data;
        curr = curr->prev;
    }
    ss << ">>]";
    return ss.str();
}

/*
 * name: pushAtFront
 * purpose: inserts a given character at the front of CharLinkedList
 * arguments: a character to be inserted
 * returns: none
 * effects: adds an element to CharLinkedList
 */
void CharLinkedList::pushAtFront(char c)
{
    insertAt(c, 0);
}

/*
 * name: pushAtBack
 * purpose: inserts a given character at the back of CharLinkedList
 * arguments: a character to be inserted
 * returns: none
 * effects: adds an element to CharLinkedList
 */
void CharLinkedList::pushAtBack(char c)
{
    insertAt(c, numItems);
}

/*
 * name: insertAt
 * purpose: handles range error or is empty cases for inserting into linkedList
 * arguments: a character to be inserted and the index for it to be inserted at
 * returns: none
 * effects: raises a range_error if the index is out of range
 */
void CharLinkedList::insertAt(char c, int index)
{
    if (index < 0 or index > numItems) {
        std::stringstream ss;
        ss << "index (" << index << ") not in range [0.." << numItems 
        << "]";
        throw std::range_error(ss.str());
    }

     if (isEmpty()) {
        front = newNode(c, nullptr, nullptr);
        back = front;
        numItems++;
        return;
    } 

    insertAt_helper(c, index);
}

/*
 * name: insertAt_helper
 * purpose: inserts a given character at a specified index of CharLinkedList
 * arguments: a character to be inserted and the index for it to be inserted at
 * returns: none
 * effects: adds an element to CharLinkedList
 */

void CharLinkedList::insertAt_helper(char c, int index){
    if (index == 0) {
        Node *temp = front;
        front = newNode(c, front, nullptr);
        temp->prev = front;
        numItems++;
        return;
    } else if (index == numItems) {
        Node *temp = back;
        back = newNode(c, nullptr, back);
        temp->next = back;
        numItems++;
        return;
    } else {
        Node *curr = elementAtHelper(index - 1, 0, front);
        Node *temp = curr->next;
        curr->next = newNode(c, curr->next, curr);
        temp->prev = curr->next;
        numItems++;
    }
}


/*
 * name: insertInOrder
 * purpose: inserts a given character in ASCII order in CharLinkedList
 * arguments: a character to be inserted
 * returns: none
 * effects: adds an element to CharLinkedList
 */
void CharLinkedList::insertInOrder(char c)
{ 
    // case for empty CharLinkedList
    if (isEmpty()) {
        insertAt(c, 0);
        return;
    }
    for (int i = 0; i < numItems - 1; i++) {
        // case if char is before first element
        if (c < front->data) {
            insertAt(c, 0);
            return;
        // case for if char is the same
        } else if (c == elementAt(i)) {
            insertAt(c, i);
            return;
        // case for if char is between 2 elements
        } else if (c > elementAt(i) and c < elementAt(i+1)) {
            insertAt(c, i);
            return;
        // case for if char is after last element
        } else if (c > elementAt(numItems - 1)) {
            insertAt(c, numItems);
            return;
        }
    }
}

/*
 * name: popFromFront
 * purpose: removes the first character of CharLinkedList
 * arguments: none
 * returns: none
 * effects: removes an element from CharLinkedList, also raises runtime_error if
 * the CharLinkedList is empty
 */
void CharLinkedList::popFromFront()
{
    if (isEmpty()) {
        throw std::runtime_error("cannot pop from empty LinkedList");
    }
    if (numItems == 1) {
        delete front;
        front = nullptr;
        back = front;
        numItems = 0;
    } else {
        Node *curr = front->next;
        delete front;
        front = curr;
        front->prev = nullptr;
        numItems--;
    }
}

/*
 * name: popFromBack
 * purpose: removes the last character of CharLinkedList
 * arguments: none
 * returns: none
 * effects: removes an element from CharLinkedList, also raises runtime_error if
 *  the CharLinkedList is empty
 */
void CharLinkedList::popFromBack()
{
    if (isEmpty()) {
        throw std::runtime_error("cannot pop from empty LinkedList");
    }
    removeAt(numItems - 1);
}

/*
 * name: removeAt
 * purpose: removes a character of CharLinkedList at a specified index
 * arguments: integer representing the specified index
 * returns: none
 * effects: removes an element from CharLinkedList, also raises range_error if 
 * the index is out of range
 */
void CharLinkedList::removeAt(int index)
{
    if (index < 0 or index >= numItems) {
        std::stringstream ss;
        ss << "index (" << index << ") not in range [0.." << numItems 
        << ")";
        throw std::range_error(ss.str());
    }
    // first element case
    if (index == 0) {
        popFromFront();
    // last element case
    } else if (index == numItems - 1) {
        Node *temp = back;
        back = back->prev;
        if (back != nullptr) {
            back->next = nullptr;
        } 
        numItems--;
        delete temp;
    // all other element case
    } else {
        Node *curr = elementAtHelper(index - 1, 0, front);
        Node *temp = curr->next;
        curr->next = temp->next;
        if (temp->next != nullptr) {
            temp->next->prev = curr;
        }
        delete temp;
        numItems--;
    }
}

/*
 * name: replaceAt
 * purpose: replaced a character of CharLinkedList at a specified index with a 
 * given character
 * arguments: a character and integer value representing the specified index
 * returns: none
 * effects: modifies CharLinkedList by replacing an element, also raises 
 * range_error if the index is out of range
 */
void CharLinkedList::replaceAt(char c, int index)
{
    if (index < 0 or index >= numItems) {
        std::stringstream ss;
        ss << "index (" << index << ") not in range [0.." << numItems 
        << ")";
        throw std::range_error(ss.str());
    }
    Node *curr = elementAtHelper(index, 0, front);
    curr->data = c;
}

/*
 * name: concatenate
 * purpose: concatenates another CharLinkedList to the current CharLinkedList
 * arguments: a pointer to the other CharLinkedList
 * returns: none
 * effects: adds a copy of the elements from the other CharLinkedList to the 
 * current one
 */
void CharLinkedList::concatenate(CharLinkedList *other)
{
    Node *other_curr = other->front;
    int other_numItems = other->numItems;
    for (int i =  0; i < other_numItems; i++) {
        pushAtBack(other_curr->data);
        other_curr = other_curr->next;
    }
}


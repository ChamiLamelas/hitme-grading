/*
 *  unit_tests.h
 *  Curt Johnson
 *  Feb 3 2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 * create unit tests to test CharLinkedList
 *
 */

#include "CharLinkedList.h"
#include <cassert>
#include <iostream>

/*
 * constructor test 0
 * Make sure no fatal errors/memory leaks in the default constructor
 */
void constructor_test_0() {
    CharLinkedList list;
}
 

//  Make sure no items exist in the list upon construction
void constructor_test_1() {
    CharLinkedList list; 
    assert(list.size() == 0);
}

// test constructor with a single char
void constructor2_test_0() {
    CharLinkedList list('A'); 
    assert(list.size() == 1);
}

// test constructor with array of size 3
void constructor3_test_0() {
    char arr[3] = {'a','b','c'};
    CharLinkedList list(arr, 3);
    assert(list.size() == 3);
    assert(list.first() == 'a');
    assert(list.last() == 'c');
}

// test constructor with empty array
void constructor2_test_1() {
    char arr[0] = {};
    CharLinkedList list(arr, 0);
    assert(list.size() == 0);
}

// tests clear on empty array list of size 1
void clear_test_singleton() {
    CharLinkedList list('A');
    list.clear();
    assert(list.isEmpty());
}

// tests clear on empty array list
void clearTest_empty(){
    char arr[0] = {};
    CharLinkedList list1(arr, 0);
    list1.clear();
    assert(list1.isEmpty());
}

// tests clear on array list of size 3
void clearTest_medium_size(){
    char arr[3] = {'a','b','c'};
    CharLinkedList list1(arr, 3);
    list1.clear();
    assert(list1.isEmpty());
}

// tests if pushBack can still be used after clear and with not memory leaks
void clearTest_withPushBack(){
    char arr[3] = {'a','b','c'};
    CharLinkedList list1(arr, 3);
    list1.clear();
    list1.pushAtBack('a');
    assert(list1.size() == 1);
}

void isEmpty_test() {
    CharLinkedList list;
    assert(list.isEmpty());
}

void elementAt_test() {
    char arr[3] = {'a','b','c'};
    CharLinkedList list(arr, 3);
    assert(list.elementAt(2) == 'c');
}


// tests elementAt on array list of size 1
void elementAt_test_singleton() {
    CharLinkedList list('A');
    assert(list.elementAt(0) == 'A');
}

// tests elementAt on array list of size 3
void elementAt_test_medium_size() {
    char arr[3] = {'a','b','c'};
    CharLinkedList list(arr, 3);
    assert(list.elementAt(0) == 'a');
    assert(list.elementAt(1) == 'b');
    assert(list.elementAt(2) == 'c');
}

void elementAt_test_out_of_range() {
    bool range_error_thrown = false;
    std::string error_message = "";

    char arr[3] = {'a','b','c'};
    CharLinkedList test_list(arr, 3);

    try {
        test_list.elementAt(5);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (5) not in range [0..3)");
}

// test last on array list of size 1
void first_test_singleton() {
    CharLinkedList list('A');
    assert(list.first() == 'A');
}

// test last on array list of size 3
void first_test_medium_size() {
    char arr[3] = {'a','b', 'c'};
    CharLinkedList list(arr, 3);
    assert(list.first() == 'a');
}

// test last on array after performing popFromFront
void first_test_popFromFront() {
    char arr[3] = {'a','b', 'c'};
    CharLinkedList list(arr, 3);
    list.popFromFront();
    assert(list.first() == 'b');
}

// test first on empty array list
void first_test_empty() {
    bool runtime_error_thrown = false;
    std::string error_message = "";

    CharLinkedList test_list;
    try {
        test_list.first();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "cannot get first of empty LinkedList");
}

// test last on array list of size 1
void last_test_singleton() {
    CharLinkedList list('A');
    assert(list.last() == 'A');
}

// test last on array list of size 3
void last_test_medium_size() {
    char arr[3] = {'a','b', 'c'};
    CharLinkedList list(arr, 3);
    assert(list.last() == 'c');
}

// test last after performing pop from back
void last_test_popFromBack() {
    char arr[3] = {'a','b','c'};
    CharLinkedList list(arr, 3);
    list.popFromBack();
    assert(list.last() == 'b');
}

// test last on empty array list
void last_test_empty() {
    bool runtime_error_thrown = false;
    std::string error_message = "";

    CharLinkedList test_list;
    try {
        test_list.last();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "cannot get last of empty LinkedList");
    
}

// tests toString on linked list of size 3
void toString_test_medium_size(){
    char arr[3] = {'a','b','c'};
    CharLinkedList list(arr, 3);
    std::string result = list.toString();
    assert(list.size() == 3);
    assert(result == "[CharLinkedList of size 3 <<abc>>]"); 
}

// tests toString on linked list of size 1
void toString_test_singleton(){
    char arr[1] = {'a'};
    CharLinkedList list(arr, 1);
    std::string result = list.toString();
    assert(result == "[CharLinkedList of size 1 <<a>>]");
}

// tests toString on empty linked list
void toString_test_empty(){
    char arr[0] = {};
    CharLinkedList list(arr, 0);
    std::string result = list.toString();
    assert(result == "[CharLinkedList of size 0 <<>>]");
}

// tests toReverseString on linked list of size 3
void toReverseString_medium_size(){
    char arr[3] = {'a','b','c'};
    CharLinkedList list(arr, 3);
    std::string result = list.toReverseString();
    // assert(result == "[CharLinkedList of size 3 <<cba>>]");
    //assert(result == "cba");
    std::cout << result;
}

// tests toReverseString on linked list of size 1
void toReverseString_test_singleton(){
    char arr[1] = {'a'};
    CharLinkedList list(arr, 1);
    std::string result = list.toReverseString();
    assert(result == "[CharLinkedList of size 1 <<a>>]");
}

// tests toReverseString on empty linked list
void toReverseString_test_empty(){
    char arr[0] = {};
    CharLinkedList list(arr, 0);
    std::string result = list.toReverseString();
    assert(result == "[CharLinkedList of size 0 <<>>]");
}

// tests pustAtBack on a linked list of size 1
void pushAtBack_singleton() {
    CharLinkedList list('A');
    list.pushAtBack('a');
    assert(list.size() == 2);
    // assert(list.last() == 'a');
}

// tests pustAtBack on a linked list of size 0
void pushAtBack_empty() {
    CharLinkedList list;
    list.pushAtBack('a');
    assert(list.size() == 1);
    // assert(list.last() == 'a');
}


// tests pushAtFront on a linked list of size 1
void pushAtFront_singleton() {
    CharLinkedList list('A');
    list.pushAtFront('a');
    assert(list.size() == 2);
    assert(list.first() == 'a');
}

// tests pushAtBack on a linked list of size 0
void pushAtFront_empty() {
    char arr[0] = {};
    CharLinkedList list(arr, 0);
    list.pushAtFront('a');
    assert(list.size() == 1);
    assert(list.last() == 'a');
}


// Tests correct insertion into an empty AL.
// Afterwards, size should be 1 and element at index 0
// should be the element we inserted.
void insertAt_empty_correct() { 

    CharLinkedList test_list;
    test_list.insertAt('a', 0);
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');

}

// Tests incorrect insertion into an empty AL.
// Attempts to call insertAt for index larger than 0.
// This should result in an std::range_error being raised.
void insertAt_empty_incorrect() {

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    // insertAt for out-of-range index
    test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
    // if insertAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    range_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0]");
    
}

// Tests correct insertAt for front of 1-element list.
void insertAt_front_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at front
    test_list.insertAt('b', 0);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'a');
    
}

// Tests correct insertAt for back of 1-element list.
void insertAt_back_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at back
    test_list.insertAt('b', 1);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
}

// Tests calling insertAt for a large number of elements.
// Not only does this test insertAt, it also checks that
// linked expansion works correctly.
void insertAt_many_elements() {
    
    CharLinkedList test_list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.insertAt('a', i);
    }

    assert(test_list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
    
}

// Tests insertion into front of a larger list
void insertAt_front_large_list() {
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    test_list.insertAt('y', 0);

    assert(test_list.size() == 10);
    assert(test_list.elementAt(0) == 'y');
    assert(test_list.toString() ==
                                  "[CharLinkedList of size 10 <<yabczdefgh>>]");
}

// Tests insertion into the back of a larger list
void insertAt_back_large_list() {

    char test_arr[10] = { 'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 10);  

    test_list.insertAt('x', 10);

    assert(test_list.size() == 11);
    assert(test_list.elementAt(10) == 'x');
    assert(test_list.toString() == 
    "[CharLinkedList of size 11 <<yabczdefghx>>]"); 

}

// Tests insertion into the middle of a larger list
void insertAt_middle_large_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.insertAt('z', 3);

    assert(test_list.size() == 9);
    assert(test_list.elementAt(3) == 'z');
    assert(test_list.toString() == "[CharLinkedList of size 9 <<abczdefgh>>]");

}

// Tests out-of-range insertion for a non-empty list.
void insertAt_nonempty_incorrect() {
   
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);
    bool range_error_thrown = false;
    std::string error_message = "";

    try {
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8]");
    
}


// test insertInOrder where char being inserted should be placed in middle
void insert_In_Order_Test_0()
{
    char arr[3] = {'a','b','c'};
    CharLinkedList list1(arr, 3);
    list1.insertInOrder('b');
    std::string result = list1.toString();
    assert(result == "[CharLinkedList of size 4 <<abbc>>]");
}

// test insertInOrder where char being inserted should be placed in back
void insert_In_Order_Test_1()
{
    char arr[3] = {'a','b','c'};
    CharLinkedList list1(arr, 3);
    list1.insertInOrder('d');
    std::string result = list1.toString();
    assert(result == "[CharLinkedList of size 4 <<abcd>>]");
}

// test insertInOrder where char being inserted should be placed in front
void insert_In_Order_Test_2()
{
    char arr[3] = {'a','b','c'};
    CharLinkedList list1(arr, 3);
    list1.insertInOrder('a');
    std::string result = list1.toString();
    assert(result == "[CharLinkedList of size 4 <<aabc>>]");
}

// test insertInOrder on empty linked list
void insert_In_Order_Test_3()
{
    char arr[0] = {};
    CharLinkedList list1(arr, 0);
    list1.insertInOrder('a');
    assert(list1.size() == 1);
    assert(list1.first() == 'a');
    std::string result = list1.toString();
    assert(result == "[CharLinkedList of size 1 <<a>>]");
}

void insertAt_empty()
{
    char arr[0] = {};
    CharLinkedList list1(arr, 0);
    list1.insertAt('a', 0);
    assert(list1.size() == 1);
    assert(list1.first() == 'a');
    std::string result = list1.toString();
    assert(result == "[CharLinkedList of size 1 <<a>>]");
}

// test insertInOrder on an out of order char linked list
void insert_In_Order_Test_4()
{
    char arr[3] = {'z','e','d'};
    CharLinkedList list1(arr, 3);
    list1.insertInOrder('a');
    std::string result = list1.toString();
    assert(result == "[CharLinkedList of size 4 <<azed>>]");
}


// single char removal test at index 0 to check for any fatal problems
void removeAtTest_single_test()
{
    char arr[3] = {'a','b','c'};
    CharLinkedList list1(arr, 3);
    list1.removeAt(0);
}

// single char removal test at index 0 of list size 1
void removeAtTest_singleton_test()
{
    CharLinkedList list1('a');
    list1.removeAt(0);
}

// single char removal test at index 0
void removeAtTest_single_test2()
{
    char arr[3] = {'a','b','c'};
    CharLinkedList list1(arr, 3);
    list1.removeAt(0);
    assert(list1.toString() == "[CharLinkedList of size 2 <<bc>>]");
}

void removeAtTest_first_character()
{
    char arr[3] = {'a','b','c'};
    CharLinkedList list1(arr, 3);
    list1.removeAt(0);
    assert(list1.elementAt(0) == 'b');
}

// empty linked with removeAt
void removeAtTest_emptying_linked()
{
    char arr[3] = {'a','b','c'};
    CharLinkedList list1(arr, 3);
    list1.removeAt(0);
    list1.removeAt(0);
    list1.removeAt(0);
    assert(list1.isEmpty());
}

// test removeAt with out of range index
void removeAtTest_out_of_range()
{
    bool range_error_thrown = false;
    std::string error_message = "";

    char arr[3] = {'a','b','c'};
    CharLinkedList list1(arr, 3);
    try {
        list1.removeAt(4);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (4) not in range [0..3)");
}

// test removeAt on empty linked list
void removeAtTest_empty()
{
    bool range_error_thrown = false;
    std::string error_message = "";

    CharLinkedList list1;
    try {
        list1.removeAt(4);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (4) not in range [0..0)");
}


// test popFromFront on empty linked list
void popFromFront_test_empty_list() {
    bool runtime_error_thrown = false;

    std::string error_message = "";

    CharLinkedList test_list;
    try {
        test_list.popFromFront();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

// test popFromFront on size 1 linked list
void popFromFront_test_singleton() {
    CharLinkedList list('a');
    list.popFromFront();
    assert(list.isEmpty());
}

// test popFromFront on size 3 linked list
void popFromFront_test_medium_size() {
    CharLinkedList list('a');
    list.pushAtBack('b');
    list.pushAtBack('c');
    list.popFromFront();
    assert(list.size() == 2);
    assert(list.first() == 'b');
    assert(list.last() == 'c');
}

// test popFromBack on empty linked list
void popFromBack_test0() {
    bool runtime_error_thrown = false;
    std::string error_message = "";

    CharLinkedList test_list;
    try {
        test_list.popFromBack();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

        assert(runtime_error_thrown);
        assert(error_message == "cannot pop from empty LinkedList");
}

// testing popFromBack on single character linked list
void popFromBack_test_singleton() {
    CharLinkedList list('a');
    list.popFromBack();
    assert(list.isEmpty());
}

// testing popFromBack on size 3 linked list
void popFromBack_test_medium_size() {
    CharLinkedList list('a');
    list.pushAtBack('b');
    list.pushAtBack('c');
    list.popFromBack();
    assert(list.size() == 2);
    assert(list.first() == 'a');
    assert(list.last() == 'b');
}


// testing replaceAt for out-of-range index in empty linked list
void replaceAtTest_out_of_range()
{
    bool range_error_thrown = false;
    std::string error_message = "";

    char arr[3] = {'a','b','c'};
    CharLinkedList list1(arr, 3);
    try {
        list1.replaceAt('c', 4);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (4) not in range [0..3)");
}

// testing replaceAt for out-of-range index in empty linked list
void replaceAtTest_empty()
{
    bool range_error_thrown = false;
    std::string error_message = "";

    CharLinkedList list1;
    try {
        list1.replaceAt('c', 4);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (4) not in range [0..0)");
}
// testing replaceAt for single char replacement
void replaceAt_test_singleton() {
    CharLinkedList list('a');
    list.replaceAt('b', 0);
    assert(list.first() == 'b');
}

// testing replaceAt for char replacement in bigger linked list
void replaceAt_test_medium_size() {
    CharLinkedList list('a');
    list.pushAtBack('b');
    list.pushAtBack('c');
    list.replaceAt('c', 1);
    assert(list.first() == 'a');
    assert(list.elementAt(1) == 'c');
}



// check for any fatal error or memory leaks
void assignment_Operator_test_1()
{
    char arr[3] = {'a','b','c'};
    CharLinkedList list1(arr, 3);
    CharLinkedList list2;
    list2 = list1;
}

// assign an empty linked list with linked list of size 3
void assignment_Operator_test_2()
{
    char arr[3] = {'a','b','c'};
    CharLinkedList list1(arr, 3);
    CharLinkedList list2;
    list2 = list1;
    assert(list2.size() == list1.size());
}

void assignment_Operator_deep_copy_test()
{
    char arr[3] = {'a','b','c'};
    CharLinkedList list1(arr, 3);
    CharLinkedList list2;
    list2 = list1;
    list2.removeAt(1);
    assert(list2.size() != list1.size());
}

void overloadedAssignmentTest(){
    CharLinkedList list;
    list.pushAtBack('j');
    list.pushAtBack('u');
    list.pushAtBack('l');
    list.pushAtBack('i');
    list.pushAtBack('a');
    list.pushAtBack('n');
    list.pushAtBack(' ');
    list.pushAtBack('s');
    CharLinkedList list2;
    list2.pushAtBack('j');
    list2.pushAtBack('u');
    list2.pushAtBack('l');
    list2 = list;
    assert(list2.size() == list.size());
}

void assignment_Operator_empty_deep_copy2()
{
    char arr[3] = {'a','b','c'};
    CharLinkedList list1(arr, 3);
    CharLinkedList list2;
    list1 = list2;
    assert(list2.size() == list1.size());
}


// copy constructor on empty linked list
void copyConstructorTest_0(){
    char arr[0] = {};
    CharLinkedList list1(arr, 0);
    CharLinkedList list2(list1);
    assert(list2.size() == list1.size());
}

// copy constructor on linked list of size 1
void copyConstructorTest_1(){
    char arr[1] = {'a'};
    CharLinkedList list1(arr, 1);
    CharLinkedList list2(list1);
    assert(list2.size() == list1.size());
}

// copy constructor on linked list of size 3
void copyConstructorTest_2(){
    char arr[3] = {'a','b','c'};
    CharLinkedList list1(arr, 3);
    CharLinkedList list2(list1);
    assert(list2.size() == list1.size());
    assert(list2.toString() == list1.toString());
}

// test concatenate with char linked list of size 3
void concatenate_medium_with_empty()
{
    char arr[3] = {'a','b','c'};
    CharLinkedList list1(arr, 3);
    CharLinkedList list2;
    CharLinkedList *list2_p = &list2;
    list1.concatenate(list2_p);
    std::string result = list1.toString();
    assert(result == "[CharLinkedList of size 3 <<abc>>]");
}

void concatenate_test_with_self()
{
    char arr[3] = {'a','b','c'};
    CharLinkedList list1(arr, 3);
    char arr2[3] = {'a','b','c'};
    CharLinkedList list2(arr2, 3);
    CharLinkedList *list2_p = &list2;
    list1.concatenate(list2_p);
    std::cout << "list1 size is: " << list1.size();
    assert(list1.size() == 6);
    std::string result = list1.toString();
    assert(result == "[CharLinkedList of size 6 <<abcabc>>]");
}

void concatenate_test_with_copy_constructor()
{
    char arr[3] = {'a','b','c'};
    CharLinkedList list1(arr, 3);
    CharLinkedList *list1_p = &list1;
    list1.concatenate(list1_p);
    std::string result = list1.toString();
    assert(result == "[CharLinkedList of size 6 <<abcabc>>]");
}
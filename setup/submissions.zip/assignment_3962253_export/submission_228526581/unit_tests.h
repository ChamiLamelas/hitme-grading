/*
 *  unit_tests.h
 *  Placide Shema
 *  7th/February/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  Purpose: the file is to test the CharLinkedList.cpp functionality.
 *
 */
#include "CharLinkedList.h"
#include <cassert>

// make a dummyTest that test nothing
void dummyTest() {}

// create an empty linked list
// check if it is an empty
void empty_LinkedList()
{
  CharLinkedList test_list;
  assert(test_list.size() == 0);
  assert(test_list.isEmpty());
}

// Create a linked list with one element
// check if it is well adjusted
void unempty_linkedList()
{
  CharLinkedList test_list('d');
  assert(test_list.first() == 'd');
  assert(test_list.size() == 1);
  test_list.pushAtFront('c');
  assert(test_list.last() == 'd');
}

// create a LinkedList of one element
// clear the list and check
void clear_LinkedList()
{
  CharLinkedList test_list('a');
  test_list.clear();
  assert(test_list.isEmpty());
}

// make an empty LinkedList
//  clear it and check
void clear_empty_list()
{
  CharLinkedList test_list;
  test_list.clear();
  assert(test_list.isEmpty());
}

// create unempty LinkedList
// add an element at its back
void pushback_LinkedList()
{
  CharLinkedList test_list('a');
  test_list.pushAtBack('b');
  assert(test_list.size() == 2);
  assert(test_list.last() == 'b');
}

// copy an array to the LinkedList
// delete from front
void popFront_from_largeList()
{
  char test_arr[3] = {'n', 'e', 'w'};
  CharLinkedList test_list(test_arr, 3);
  test_list.popFromFront();
  assert(test_list.last() == 'w');
}

// create an empty list
// add an element from front
void pushAtFront_smallList()
{
  CharLinkedList test_list;
  test_list.pushAtBack('a');
  test_list.pushAtFront('b');
  assert(test_list.last() == 'a');
}

// copy elements of an array to Linked List
// add from front
void pushAtFront_largeList()
{
  char test_arr[7] = {'e', 'w', 'c', 'l', 'a', 's', 's'};
  CharLinkedList test_list(test_arr, 7);
  test_list.pushAtFront('n');
  assert(test_list.first() == 'n');
}

// copying an array of elements to the LinkedList
void array_to_LinkedList()
{
  char test_arr[3] = {'n', 'e', 'w'};
  CharLinkedList test_list(test_arr, 3);
  assert(test_list.size() == 3);
}

// create an empty array and copy it to the Linked list
void emptyArray_to_LinkedList()
{
  char test_arr[] = {};
  CharLinkedList test_list(test_arr, 0);
  assert(test_list.size() == 0);
}

// create an linkedlist
// retrieve the element from a certain index
void element_in_LinkedList()
{
  CharLinkedList test_list;
  test_list.pushAtBack('e');
  test_list.pushAtBack('w');
  assert(test_list.elementAt(1) == 'w');
}

// create a Linked List with one element
// access an element at an index above the list
void elementAt_aboveList()
{
  CharLinkedList test_list;
  test_list.pushAtBack('e');
  // var to track whether range_error is thrown
  bool range_error_thrown = false;

  // var to track any error messages raised
  std::string error_message = "";

  try
  {
    test_list.elementAt(4);
  }
  catch (const std::range_error &e)
  {
    range_error_thrown = true;
    error_message = e.what();
  }

  assert(range_error_thrown);
  assert(error_message == "index (4) not in range [0..1)");
}

// create a Linked List with one element
// access an element at an index below the list
void elementAt_belowList()
{
  CharLinkedList test_list;
  test_list.pushAtBack('e');
  // var to track whether range_error is thrown
  bool range_error_thrown = false;

  // var to track any error messages raised
  std::string error_message = "";

  try
  {
    test_list.elementAt(-1);
  }
  catch (const std::range_error &e)
  {
    range_error_thrown = true;
    error_message = e.what();
  }

  assert(range_error_thrown);
  assert(error_message == "index (-1) not in range [0..1)");
}

// create a linked list and add on element
// make them a string
void string_LinkedList()
{
  CharLinkedList test_list('c');
  test_list.pushAtBack('s');
  test_list.pushAtBack('1');
  test_list.pushAtBack('5');
  assert(test_list.size() == 4);
  assert(test_list.toString() == "[CharLinkedList of size 4 <<cs15>>]");
}

//create single linkedList, add element on it
//reverse the elements into string
void ReverseString_LinkedList()
{
  CharLinkedList test_list('5');
  test_list.pushAtBack('1');
  test_list.pushAtBack('s');
  test_list.pushAtBack('c');
  assert(test_list.size() == 4);
  assert(test_list.toReverseString() == "[CharLinkedList of size 4 <<cs15>>]");
}

//create single linkedList, add element on it
//remove the element from back
void pop_at_back()
{

  // testing for un_empty list
  CharLinkedList test_list('c');
  test_list.pushAtBack('s');
  test_list.pushAtBack('1');
  test_list.popFromBack();
  assert(test_list.last() == 's');
}

//create single linkedList, add element on it
//replace one element from the list
void replaceAtLinkedList()
{
  // testing for un_empty list
  CharLinkedList test_list('t');
  test_list.pushAtBack('e');
  test_list.pushAtBack('e');
  test_list.replaceAt('a', 2);
  assert(test_list.size() == 3);
  assert(test_list.last() == 'a');
}

//copy an array to LinkedList 
//replace out of range
void replaceAt_outOfRange()
{
  char test_arr[4] = {'t', 'e', 's', 't'};
  CharLinkedList test_list(test_arr, 4);

  // var to track whether range_error is thrown
  bool range_error_thrown = false;

  // var to track any error messages raised
  std::string error_message = "";

  try
  {
    test_list.replaceAt('c', 6);
  }
  catch (const std::range_error &e)
  {
    range_error_thrown = true;
    error_message = e.what();
  }

  assert(range_error_thrown);
  assert(error_message == "index (6) not in range [0..4)");
}

//copy an array to LinkedList 
//remove an element from different positions of the list
void remove_from_LinkedList()
{
  char test_arr[5] = {'t', 'e', 's', 't', 'y'};
  CharLinkedList test_list(test_arr, 5);

  // remove in the middle
  test_list.removeAt(3);
  assert(test_list.size() == 4);
  assert(test_list.toString() == "[CharLinkedList of size 4 <<tesy>>]");

  // from the front
  test_list.removeAt(3);
  assert(test_list.toString() == "[CharLinkedList of size 3 <<tes>>]");

  // considering the back case
  test_list.removeAt(0);
  assert(test_list.toString() == "[CharLinkedList of size 2 <<es>>]");
}

//copy an array to LinkedList 
//insert an element from different positions of the list
void insert_at_LinkedList()
{
  char test_arr[4] = {'t', 'e', 's', 't'};
  CharLinkedList test_list(test_arr, 4);

  // check for the front case
  test_list.insertAt('c', 0);
  assert(test_list.elementAt(0) == 'c');

  // check for the middle case
  test_list.insertAt('d', 2);
  assert(test_list.elementAt(2) == 'd');

  // check for the back case

  test_list.insertAt('e', 6);
  assert(test_list.elementAt(6) == 'e');
}

//copy an array to LinkedList 
//remove an element out of range 
void insert_at_outOfRange()
{
  char test_arr[4] = {'t', 'e', 's', 't'};
  CharLinkedList test_list(test_arr, 4);

  // var to track whether range_error is thrown
  bool range_error_thrown = false;

  // var to track any error messages raised
  std::string error_message = "";

  try
  {
    test_list.insertAt('c', 6);
  }
  catch (const std::range_error &e)
  {
    range_error_thrown = true;
    error_message = e.what();
  }

  assert(range_error_thrown);
  assert(error_message == "index (6) not in range [0..4]");
}

//copy an array to LinkedList and create other single linkedList 
// concatenete them
void concatenate_LinkedList()
{
  char test_arr[4] = {'t', 'e', 's', 't'};
  CharLinkedList test_list(test_arr, 4);
  CharLinkedList test_list2('y');
  test_list2.concatenate(&test_list);
  assert(test_list.toString() == "[CharLinkedList of size 4 <<test>>]");
}

//create two empty linkedList 
// concatenete them
void concatenate_EmptyLists()
{
  CharLinkedList test_list;
  CharLinkedList test_list2;
  test_list2.concatenate(&test_list);
  assert(test_list2.isEmpty());
}

//copy an array to LinkedList and create empty linkedList 
// concatenete them
void concatenate_to_emptyList()
{
  char test_arr[4] = {'t', 'e', 's', 't'};
  CharLinkedList test_list(test_arr, 4);
  CharLinkedList test_list2;
  test_list2.concatenate(&test_list);
  assert(test_list2.toString() == "[CharLinkedList of size 4 <<test>>]");
}

//copy an empty array to LinkedList and create empty linkedList 
// concatenete them
void concatenate_emptyArray_toList()
{
  char test_arr[] = {};
  CharLinkedList test_list(test_arr, 0);
  CharLinkedList test_list2;
  test_list2.concatenate(&test_list);
  assert(test_list2.toString() == "[CharLinkedList of size 0 <<>>]");
}

//copy an empty array to LinkedList and create unempty linkedList 
// concatenete them
void concatenate_emptyArray_toUnEmptyList()
{
  char test_arr[] = {};
  CharLinkedList test_list(test_arr, 0);
  CharLinkedList test_list2('y');
  test_list2.concatenate(&test_list);
  assert(test_list2.toString() == "[CharLinkedList of size 1 <<y>>]");
}

// Function to copy elements from a non-empty linked list to another.
void copy_to_UnEmptyLinkedList()
{
  // check for un empty list
  char test_arr[4] = {'t', 'e', 's', 't'};
  CharLinkedList test_list(test_arr, 4);
  CharLinkedList test_list2('y');
  test_list2 = test_list;
  assert(test_list2.toString() == "[CharLinkedList of size 4 <<test>>]");
}

// Function to copy elements from an empty linked list to another.
void copy_to_Emptylinked_list()
{
  char test_arr[4] = {'t', 'e', 's', 't'};
  CharLinkedList test_list(test_arr, 4);
  CharLinkedList test_list2(test_list);
  assert(test_list2.toString() == "[CharLinkedList of size 4 <<test>>]");
}

// Function to insert an element in an ordered manner into the linked list.
void insert_inOrder()
{
  char test_arr[4] = {'a', 'b', 'd', 'e'};
  CharLinkedList test_list(test_arr, 4);
  test_list.insertInOrder('c');
  assert(test_list.toString() == "[CharLinkedList of size 5 <<abcde>>]");
}

// Function to test toString() method for an empty linked list.
void emptyList_toString()
{
  CharLinkedList test_list;
  assert(test_list.toString() == "[CharLinkedList of size 0 <<>>]");
}

// Function to test toString() method for a linked list with a single element.
void SingleLinkedList_toString()
{
  CharLinkedList test_list('c');
  assert(test_list.toString() == "[CharLinkedList of size 1 <<c>>]");
}

// Function to test retrieving the first element from an empty linked list.
void first_from_emptyList()
{
  CharLinkedList test_list;

  // var to track whether range_error is thrown
  bool runtime_error_thrown = false;

  // var to track any error messages raised
  std::string error_message = "";
  try
  {
    test_list.first();
  }
  catch (const std::runtime_error &e)
  {
    runtime_error_thrown = true;
    error_message = e.what();
  }
  assert(runtime_error_thrown);
  assert(error_message == "cannot get first of empty LinkedList");
}

// Function to test popping from the back of an empty linked list.
void popFromBack_emptyList()
{
  CharLinkedList test_list;

  // var to track whether runtime_error is thrown
  bool runtime_error_thrown = false;

  // var to track any error messages raised
  std::string error_message = "";
  try
  {
    test_list.popFromBack();
  }
  catch (const std::runtime_error &e)
  {
    runtime_error_thrown = true;
    error_message = e.what();
  }
  assert(runtime_error_thrown);
  assert(error_message == "cannot pop from empty LinkedList");
}

// Function to test removing an element out of the edge of the linked list.
void remove_outOf_edge()
{
  char test_arr[4] = {'a', 'b', 'd', 'e'};
  CharLinkedList test_list(test_arr, 4);
  // var to track whether range_error is thrown
  bool range_error_thrown = false;

  // var to track any error messages raised
  std::string error_message = "";

  try
  {
    test_list.removeAt(5);
  }
  catch (const std::range_error &e)
  {
    range_error_thrown = true;
    error_message = e.what();
  }

  assert(range_error_thrown);
  assert(error_message == "index (5) not in range [0..4)");
}

// Function to test removing an element from an empty linked list.
void removeFrom_emptyList()
{
  CharLinkedList test_list;

  // var to track whether range_error is thrown
  bool range_error_thrown = false;

  // var to track any error messages raised
  std::string error_message = "";

  try
  {
    test_list.removeAt(0);
  }
  catch (const std::range_error &e)
  {
    range_error_thrown = true;
    error_message = e.what();
  }

  assert(range_error_thrown);
  assert(error_message == "index (0) not in range [0..0)");
}

// Function to test popping from the front of an empty linked list.
void popFromFront_emptyList()
{
  CharLinkedList test_list;

  // var to track whether runtime_error is thrown
  bool runtime_error_thrown = false;

  // var to track any error messages raised
  std::string error_message = "";
  try
  {
    test_list.popFromFront();
  }
  catch (const std::runtime_error &e)
  {
    runtime_error_thrown = true;
    error_message = e.what();
  }
  assert(runtime_error_thrown);
  assert(error_message == "cannot pop from empty LinkedList");
}

// Function to test the size of the linked list after removing elements.
void size_by_removingElements()
{
  char test_arr[4] = {'a', 'b', 'd', 'e'};
  CharLinkedList test_list(test_arr, 4);
  test_list.popFromBack();
  assert(test_list.size() == 3);
  test_list.removeAt(2);
  assert(test_list.size() == 2);
}

// Function to test the size of the linked list after adding elements.
void size_by_addingElements()
{
  char test_arr[1] = {'e'};
  CharLinkedList test_list(test_arr, 1);
  test_list.pushAtBack('a');
  assert(test_list.size() == 2);
  test_list.pushAtFront('t');
  assert(test_list.size() == 3);
}

// Function to test retrieving the first element from an expanding list.
void first_from_expandingList()
{
  char test_arr[4] = {'a', 'b', 'd', 'e'};
  CharLinkedList test_list(test_arr, 4);
  test_list.pushAtBack('f');
  assert(test_list.first() == 'a');
  test_list.pushAtFront('h');
  assert(test_list.first() == 'h');
}

// Function to test retrieving the first element while removing elements.
void first_while_removingElements()
{
  char test_arr[4] = {'a', 'b', 'd', 'e'};
  CharLinkedList test_list(test_arr, 4);
  test_list.popFromBack();
  assert(test_list.first() == 'a');
  test_list.popFromFront();
  assert(test_list.first() == 'b');
}

// Function to test popping from the front of a single-element list.
void popFront_from_singleList()
{ 
  CharLinkedList test_list;
  test_list.pushAtFront('c');
  test_list.popFromFront();
  assert(test_list.size() == 0);
}

// Function to test popping from the back of a single-element list.
void popBack_from_singleList()
{
  CharLinkedList test_list;
  test_list.pushAtBack('c');
  test_list.popFromBack();
  assert(test_list.size() == 0);
}

// Function to test inserting at an incorrect index in an empty list.
void insertAt_empty_incorrect()
{
    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try
    {
        // insertAt for out-of-range index
        test_list.insertAt('a', 2);
    }
    catch (const std::range_error &e)
    {
        // if insertAt is correctly implemented, a range_error will be thrown,
        // and we will end up here
        range_error_thrown = true;
        error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (2) not in range [0..0]");
}
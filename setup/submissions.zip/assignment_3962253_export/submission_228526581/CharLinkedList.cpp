/*
 *  CharLinkedList.cpp
 *  Name: Placide Shema
 *  7th/February/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Purpose: Is to develop the LinkedList Datastructure that can allow the user
 *           make an input and output but with LinkedList structure. 
 *
 */

#include "CharLinkedList.h"
#include <stdexcept>

/*
 * name:      CharLinkedList
 * purpose:   Construct an empty CharLinkedList.
 * arguments: None.
 * returns:   None.
 * effects:   Initializes the CharLinkedList with front and back pointers
 * set to nullptr, and the current size set to 0.
 */
CharLinkedList::CharLinkedList()
{
    front = back = nullptr;
    curr_size = 0;
}

/*
 * name:      ~CharLinkedList
 * purpose:   Destructor for CharLinkedList.
 * arguments: None.
 * returns:   None.
 * effects:   Recursively deallocates memory for all nodes.
 */
CharLinkedList::~CharLinkedList()
{
    recycleRecursive(front);
}

/*
 * name:      ~CharLinkedList
 * purpose:   Destructor for CharLinkedList.
 * arguments: None.
 * returns:   None.
 * effects:   Recursively deallocates memory for all nodes.
 */
void CharLinkedList::recycleRecursive(Node *curr)
{
    if (curr == nullptr)
    {
        return;
    }
    else
    {
        Node *next = curr->next;
        recycleRecursive(next);
        delete curr;
    }
    curr_size--;
}

/*
 * name:      CharLinkedList
 * purpose:   Construct a CharLinkedList with a single character.
 * arguments: The character to be added.
 * returns:   None.
 * effects:   Initializes the CharLinkedList with a single node
 *            containing the given character.
 */
CharLinkedList::CharLinkedList(char c)
{
    front = nullptr;
    front = newNode(c, front, nullptr);
    back = front;
    curr_size = 1;
}

CharLinkedList::Node *CharLinkedList::
    newNode(char new_data, Node *next, Node *prev)
{
    Node *new_node = new Node;
    new_node->data = new_data;
    new_node->next = next;
    new_node->prev = prev;
    if (next != nullptr)
    {
        next->prev = new_node;
    }
    return new_node;
}

/*
 * name:      CharLinkedList
 * purpose:   Construct a CharLinkedList from an array of characters.
 * arguments: The array of characters and its size.
 * returns:   None.
 * effects:   Initializes the CharLinkedList with nodes containing the
 *            characters from the array.
 */
CharLinkedList::CharLinkedList(char arr[], int size)
{
    front = back = nullptr;
    curr_size = 0;
    for (int i = 0; i < size; i++)
    {
        pushAtBack(arr[i]);
    }
}

/*
 * name:      CharLinkedList
 * purpose:   Copy constructor for CharLinkedList.
 * arguments: Another CharLinkedList to copy from.
 * returns:   None.
 * effects:   Initializes the CharLinkedList with a copy of the elements
 *            from the other CharLinkedList.
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other)
{
    front = back = nullptr;
    curr_size = 0;

    for (int i = 0; i < other.curr_size; i++)
    {
        pushAtBack(other.elementAt(i));
    }
}

/*
 * name: CharLinkedList
 * purpose:   Assignment operator for CharLinkedList.
 * arguments: Another CharLinkedList to assign from.
 * returns:   Reference to the assigned CharLinkedList.
 * effects:   Modifies the CharLinkedList to contain a copy of
 *            the elements from the other CharLinkedList.
 */
CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other)
{
    // free the memory
    recycleRecursive(front);

    front = back = nullptr;
    curr_size = 0;

    for (int i = 0; i < other.curr_size; i++)
    {
        pushAtBack(other.elementAt(i));
    }
    return *this;
}

/*
 * name:      empty
 * purpose:   checking if nothing is stored in the LinkedList.
 * arguments: None.
 * returns:   boolean value, true or false
 * effects:   None.
 */
bool CharLinkedList::isEmpty() const
{
    return front == nullptr;
}

/*
 * name:      clear
 * purpose:   clearing the LinkedList or removing all the datas stored.
 * arguments: None.
 * returns:   None
 * effects:   Modifies the CharLinkedList by clearing it.
 */
void CharLinkedList::clear()
{
    recycleRecursive(front);
    front = nullptr;
}

/*
 * name:      size
 * purpose:   get the size of the LinkedList.
 * arguments: None.
 * returns:   current size of the list
 * effects:   None.
 */
int CharLinkedList::size() const
{
    return curr_size;
}

/*
 * name:      firsts
 * purpose:   retrieve or get the first element from the list.
 * arguments: None.
 * returns:   data stored at the front of the list
 * effects:   None.
 */
char CharLinkedList::first() const
{
    if (front == nullptr)
    {
        throw std::runtime_error("cannot get first of empty LinkedList");
    }
    return front->data;
}

/*
 * name:      last
 * purpose:   retrieve or get the last element from the list.
 * arguments: None.
 * returns:   data stored at the back of the list
 * effects:   None.
 */
char CharLinkedList::last() const
{
    if (front == nullptr)
    {
        throw std::runtime_error("cannot get last of empty LinkedList");
    }
    Node *curr = front;
    while (curr->next != nullptr)
    {
        curr = curr->next;
    }
    return curr->data;
}

/*
 * name:      elementAt
 * purpose:   retrieving an element from the CharLinkedList.
 * arguments: index.
 * returns:   element stored at that index
 * effects:   None
 */
char CharLinkedList::elementAt(int index) const
{
    // validate the index
    if (index < 0 or index >= curr_size)
    {
        throw std::range_error("index (" +
                               std::to_string(index) + ") not in range [0.." +
                               std::to_string(curr_size) + ")");
    }
    Node *curr = front;
    for (int i = 0; i < index; i++)
    {
        curr = curr->next;
    }
    return curr->data;
}

/*
 * name:      toString
 * purpose:   make the elements of the CharLinkedList into string.
 * arguments: None.
 * returns:   string
 * effects:   None.
 */
std::string CharLinkedList::toString() const
{
    Node *curr = front;
    std::string String = "[CharLinkedList of size " +
                         std::to_string(curr_size) + " <<";
    for (int i = 0; i < curr_size; i++)
    {
        String += curr->data;
        curr = curr->next;
    }
    String += ">>]";

    // string is now combination of each element
    return String;
}

/*
 * name:      toReverseString
 * purpose:   reverse the elements of the CharLinkedList.
 * arguments: None.
 * returns:   reversed string.
 * effects:   None.
 */
std::string CharLinkedList::toReverseString() const
{
    Node *curr = back;
    std::string String = "[CharLinkedList of size " +
                         std::to_string(curr_size) + " <<";
    for (int i = curr_size - 1; i >= 0; i--)
    {
        String += curr->data;
        curr = curr->prev;
    }
    String += ">>]";

    // string is now combination of each element
    return String;
}

/*
 * name:      pushAtBack
 * purpose:   Add a character to the back of the CharLinkedList.
 * arguments: The character to be added.
 * returns:   None.
 * effects:   Modifies the CharLinkedList by adding a character at the end.
 */
void CharLinkedList::pushAtBack(char c)
{
    if (front == nullptr)
    {
        front = newNode(c, nullptr, nullptr);
        back = front;
        curr_size++;
        return;
    }
    back->next = newNode(c, nullptr, back);
    back = back->next;
    curr_size++;
}

/*
 * name:      pushAtFront
 * purpose:   Add a character to the front of the CharLinkedList.
 * arguments: The character to be added.
 * returns:   None.
 * effects:   Modifies the CharLinkedList by adding a character at
 *            the beginning.
 */
void CharLinkedList::pushAtFront(char c)
{
    front = newNode(c, front, nullptr);
    curr_size++;
}

/*
 * name:      insertAt
 * purpose:   Insert a character at a specified index in the CharLinkedList.
 * arguments: The character to be inserted and the index at which to insert.
 * returns:   None.
 * effects:   Modifies the CharLinkedList by inserting a character at the
 *            specified index.
 */
void CharLinkedList::insertAt(char c, int index)
{
    if (index < 0 or index > curr_size)
    {
        throw std::range_error("index (" +
                               std::to_string(index) + ") not in range [0.." +
                               std::to_string(curr_size) + "]");
    }
    if (index == 0)
    {
        pushAtFront(c);
        return;
    }
    if (index == curr_size)
    {
        pushAtBack(c);
        return;
    }
    Node *new_node = new Node;
    new_node->data = c;
    Node *curr = front;
    for (int i = 0; i < index - 1; i++)
    {
        curr = curr->next;
    }
    new_node->next = curr->next;
    new_node->prev = curr;
    curr->next = new_node;
    curr->next->prev = new_node;
    curr_size++;
}

/*
 * name:      insertInOrder
 * purpose:   Insert a character in order in the CharLinkedList.
 * arguments: The character to be inserted.
 * returns:   None.
 * effects:   Modifies the CharLinkedList by inserting a character in order.
 */
void CharLinkedList::insertInOrder(char c)
{
    Node *curr = front;
    int insertIndex = 0;
    // find the correct index for inserting the element for
    while (curr->next != nullptr and curr->data < c)
    {
        curr = curr->next;
        insertIndex++;
    }
    if (curr->data < c)
    {
        insertIndex++;
    }

    // insert the new element at the found index
    insertAt(c, insertIndex);
}

/*
 * name:      popFromFront
 * purpose:   Remove and return the first character of the CharLinkedList.
 * arguments: None.
 * returns:   None.
 * effects:   Modifies the CharLinkedList by removing the first character.
 */
void CharLinkedList::popFromFront()
{
    if (front == nullptr)
    {
        throw std::runtime_error("cannot pop from empty LinkedList");
    }

    Node *curr = front;
    front = curr->next;
    delete curr;
    curr_size--;
    if (isEmpty())
    {
        back = nullptr;
    }
}

/*
 * name:      popFromBack
 * purpose:   Remove and return the last character of the CharLinkedList.
 * arguments: None.
 * returns:   None.
 * effects:   Modifies the CharLinkedList by removing the last character.
 */
void CharLinkedList::popFromBack()
{
    if (front == nullptr)
    {
        throw std::runtime_error("cannot pop from empty LinkedList");
    }
    if (curr_size == 1)
    {
        popFromFront();
        return;
    }
    Node *curr = back;
    back = curr->prev;
    delete curr;
    back->next = nullptr;
    curr_size--;
}

/*
 * name:      removeAt
 * purpose:   Remove the character at a specified index in the CharLinkedList.
 * arguments: The index of the element to be removed.
 * returns:   None.
 * effects:   Modifies the CharLinkedList by removing the character at
 *            the specified index.
 */
void CharLinkedList::removeAt(int index)
{
    if (index < 0 or index >= curr_size)
    {
        throw std::range_error("index (" +
                               std::to_string(index) + ") not in range [0.." +
                               std::to_string(curr_size) + ")");
    }

    // considering both front case, back and middle case
    if (index == 0)
    {
        popFromFront();
        return;
    }
    if (index == curr_size - 1)
    {
        popFromBack();
        return;
    }
    Node *curr = front;
    for (int i = 0; i < index; i++)
    {
        curr = curr->next;
    }
    Node *new_node = curr;
    curr->prev->next = curr->next;
    curr->next->prev = curr->prev;
    delete curr;
    curr_size--;
}

/*
 * name:      replaceAt
 * purpose:   Replace the character at a specified index in the CharLinkedList.
 * arguments: The character to replace with and the index at which to replace.
 * returns:   None.
 * effects:   Modifies the CharLinkedList by replacing the character at the
 *            specified index.
 */
void CharLinkedList::replaceAt(char c, int index)
{
    if (index < 0 or index >= curr_size)
    {
        throw std::range_error("index (" +
                               std::to_string(index) + ") not in range [0.." +
                               std::to_string(curr_size) + ")");
    }
    Node *curr = front;
    for (int i = 0; i < index; i++)
    {
        curr = curr->next;
    }
    curr->data = c;
}

/*
 * name:      concatenate
 * purpose:   Concatenate the elements of another CharLinkedList to the end
 *            of the current CharLinkedList.
 * arguments: A pointer to another CharLinkedList to concatenate.
 * returns:   None.
 * effects:   Modifies the CharLinkedList by adding elements from the other
 *            CharLinkedList.
 */
void CharLinkedList::concatenate(CharLinkedList *other)
{

    for (int i = 0; i < other->size(); i++)
    {
        pushAtBack(other->elementAt(i));
    }
}
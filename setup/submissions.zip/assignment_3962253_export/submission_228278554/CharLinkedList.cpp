/*
 *  CharLinkedList.cpp
 *  Cisco Hadden chadde01
 *  2/1/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Create a dynamic list of linked structs to hold and manage data
 *
 */

#include "CharLinkedList.h"
#include <sstream>

using namespace std;

/*
 * name:      CharLinkedList default constructor
 * purpose:   initialize an empty CharLinkedList
 * arguments: none
 * returns:   none
 * effects:   list_size to 0
 */
CharLinkedList::CharLinkedList(){
    list_size = 0;
}


/*
 * name:      CharLinkedList constructor for one element list
 * purpose:   initialize a 1 element CharLinkedList
 * arguments: none
 * returns:   none
 * effects:   list_size to 0 (also updates capacity and data list)
 */
CharLinkedList::CharLinkedList(char c){
    list_size = 1;
    front = new Node;
    front->data = c;
    front->next = nullptr;
    front->prev = nullptr;
}

/*
 * name:      CharLinkedList constructor set list 
 * purpose:   initialize a CharLinkedList with given list values
 * arguments: none
 * returns:   none
 * effects:   list_size to 0 (also updates capacity and data list)
 */
CharLinkedList::CharLinkedList(char arr[], int size){
    list_size = 1;
    front = new Node;
    front->data = arr[0];
    front->next = nullptr;
    front->prev = nullptr;
    for(int i = 1; i < size; i++){
        pushAtBack(arr[i]);
    }
}

/*
 * name:      CharLinkedList copy constructor
 * purpose:   defines and assignment operator for the class that recycles
 *            the storage associated with the instance
 * arguments: CharLinkedList pointer
 * returns:   none
 * effects:   makes a copy of data
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other){
    list_size = other.list_size;
    if(list_size == 0){
        return;
    }
    front = new Node;
    Node * current_element = front;
    Node *other_element = other.front;
    while(other_element != nullptr){
        current_element->data = other_element->data;
        if(other_element->next != nullptr){
            current_element->next = new Node;
            current_element->next->prev = current_element;
            current_element = current_element->next;
        }
        else{
            current_element->next = nullptr;
        }
        other_element = other_element->next;

    }
}

/*
 * name:      CharLinkedList overload assignment operator
 * purpose:   recycles the storage associated with the instance
 *            and makes a deep copy of the instance into the instance 
 *            on the left hand side
 * arguments: CharLinkedList pointer
 * returns:   none
 * effects:   assigns an operator to the class
 */
CharLinkedList & CharLinkedList::operator=(const CharLinkedList &other){
    if(this == &other){
        return *this;
    }
    else{
        clear();
        CharLinkedList copy(other);
    }
    return *this;
} 

/*
 * name:      isEmpty
 * purpose:   determine if Linkedlist is empty
 * arguments: none
 * returns:   bool of if Linkedlist is empty
 * effects:   none
 */
bool CharLinkedList::isEmpty() const{
    if (list_size == 0){
        return true;
    }
    else{
        return false;
    }
}

/*
 * name:      pushAtBack
 * purpose:   adds element to end of list
 * arguments: character input value
 * returns:   none
 * effects:   increments size of list and adds element
*/
void CharLinkedList::pushAtBack(char c){
    if(list_size == 0){
        front = new Node;
        front->data = c;
        front->next = nullptr;
        front->prev = nullptr;
    }
    else{
        Node * last = itterate_through(front, list_size - 1);
        Node * new_element = new Node;
        last->next = new_element;
        new_element->data = c;
        new_element->next = nullptr;
        new_element->prev = last;
    }
    list_size ++;
}

/*
 * name:      pushAtFront
 * purpose:   adds element to begining of list
 * arguments: character input value
 * returns:   none
 * effects:   increments size of list and adds element
 */
void CharLinkedList::pushAtFront(char c){
    insertAt(c, 0);
}

/*
 * name:      clear_memory
 * purpose:   erases linkedlist
 * arguments: Node pointer
 * returns:   none
 * effects:   cleans memory; isEmpty will be true
 */
void CharLinkedList::clear_memory(Node * element){
    if(element == nullptr){
        return;
    }
    else{
        //Node * next_element = element->next;
        clear_memory(element->next);
        delete element;
    }
}

/*
 * name:      clear
 * purpose:   erases linkedlist and lets list_size to 0
 * arguments: none
 * returns:   none
 * effects:   no memory leaks; isEmpty will be true
 */
void CharLinkedList::clear(){
    list_size = 0;
    clear_memory(front);
    front = nullptr;
}

/*
 * name:      size
 * purpose:   tells number of characters in linkedlist
 * arguments: none
 * returns:   int number of characters
 * effects:   none
 */
int CharLinkedList::size() const{
    return list_size;
}

/*
 * name:      first 
 * purpose:   gets first element in linkedlist
 * arguments: none
 * returns:   character element
 * effects:   none
 */
char CharLinkedList::first() const{
    if(list_size > 0){
        return front->data;
    }
    //if linkedlist is empty, error thrown 
    else{
        throw std::runtime_error("cannot get first of empty LinkedList");
    }
}

/*
 * name:      itterate_through
 * purpose:   traverses list to given index
 * arguments: Node pointer and integer index value
 * returns:   node pointer to node at given index
 * effects:   if nullptr index is out of range
 */
CharLinkedList::Node * CharLinkedList::itterate_through
                                (Node * element, int index) const{
    if(index < 0 or element == nullptr or index >= list_size){
        return nullptr;
    }
    else if(index == 0 or element->next == nullptr){
        return element;
    }
    else{
        index--;
        return itterate_through(element->next, index);
    }
}

/*
 * name:      last
 * purpose:   gets last element in linkedlist
 * arguments: none
 * returns:   character element
 * effects:   none
 */
char CharLinkedList::last() const{
    if(list_size > 0){
        Node * last = itterate_through(front, list_size - 1);
        return last->data;
    }
    //if linkedlist is empty, error thrown 
    else{
        throw std::runtime_error("cannot get last of empty LinkedList");
    }
}

/*
 * name:      element at
 * purpose:   gets any element in linkedlist
 * arguments: none
 * returns:   character element
 * effects:   none
 */
char CharLinkedList::elementAt(int index) const{
    // if(index < 0 or index >= list_size){
    //     throw std::range_error("index (" + std::to_string(index) + 
    //                ") not in range [0.." + std::to_string(list_size) +")");
    // }
    Node * element = itterate_through(front, index);
    if(element == nullptr){
        throw std::range_error("index (" + std::to_string(index) + 
                   ") not in range [0.." + std::to_string(list_size) +")");
    }
    else{
        return element->data;
    }
}

/*
 * name:      toString 
 * purpose:   turns linkedlist into a string
 * arguments: none
 * returns:   string of linkedlist
 * effects:   none
 */
std::string CharLinkedList::toString() const {
    std::stringstream ss;
    ss << "[CharLinkedList of size "  << this->list_size << " <<";

    //loop through and add each element to string
    Node * next_element = this->front;
    while(next_element != nullptr){
        ss << next_element->data;
        next_element = next_element->next;
    }

    ss << ">>]";
    return ss.str();
}

/*
 * name:      toReverseString 
 * purpose:   turns linkedlist into a reversed order string
 * arguments: none
 * returns:   string of reversed linkedlist
 * effects:   none
 */
std::string CharLinkedList::toReverseString() const {
    std::stringstream ss;
    
    ss << "[CharLinkedList of size " << this->list_size << " <<";

    //loop through and add each element to string
    Node * next_element = itterate_through(this->front, this->list_size - 1);
    while(next_element != nullptr){
        ss << next_element->data;
        next_element = next_element->prev;
    }
    ss << ">>]";
    return ss.str();
}

/*
 * name:      insertAt
 * purpose:   adds element to anywehere in the list
 * arguments: character input and iteger index
 * returns:   none
 * effects:   increments size of list and adds element
 */
void CharLinkedList::insertAt(char c, int index){
    Node * right_element = itterate_through(front, index);
    //if list is empty or index is at the end, use pushAtBack
    if((isEmpty() and index == 0) or (index == list_size)){
        pushAtBack(c);
    }
    else if(right_element == nullptr){
        //if index is out of bounds, error thrown
       throw std::range_error("index (" + std::to_string(index) + 
                    ") not in range [0.." + std::to_string(list_size) +")");
    }
    else if(index == 0){
        Node * old_first = front;
        front = new Node;
        front->data = c;
        front->prev = nullptr;
        front->next = old_first;
        old_first->prev = front;
        list_size = list_size + 1;
    }
    else{
        Node * left_element = itterate_through(front, index - 1);
        Node * new_node = new Node;
        left_element->next = new_node;
        new_node->data = c;
        new_node->next = right_element;
        right_element->prev = new_node;
        new_node->prev = left_element;
        list_size = list_size + 1;
    }
}

/*
 * name:      insertInOrder
 * purpose:   inserts an element in alphabetical order 
 * arguments: character input value
 * returns:   none
 * effects:   adds new element and increases character count
 */
void CharLinkedList::insertInOrder(char c){
    Node * current_node = front;
    Node * last = itterate_through(front, list_size-1);
    int i = 0;
    //check endpoints
    if(current_node->data > c){
        pushAtFront(c);
    }
    else if(last->data < c){
        pushAtBack(c);
    }
    else{
        while(i < list_size){
            if(current_node->data <= c and current_node->next->data > c){
                insertAt(c, i + 1);
                i = list_size;
            }
            current_node = current_node->next;
            i++;
        }
    }
}

 /*
 * name:      popFromBack
 * purpose:   removes element from back of linkedlist
 * arguments: none
 * returns:   none
 * effects:   decrements character count
 */
void CharLinkedList::popFromBack(){
    if(isEmpty()){
        throw std::runtime_error("cannot pop from empty LinkedList");
    }
    Node * last = itterate_through(front, list_size - 1);
    last->prev->next = nullptr;
    delete last;
    list_size--;
}

/*
 * name:      popFromFront
 * purpose:   removes element from front of linkedlist
 * arguments: none
 * returns:   none
 * effects:   decrements character count
 */
void CharLinkedList::popFromFront(){
    if(isEmpty()){
        throw std::runtime_error("cannot pop from empty LinkedList");
    }
    Node * delete_node = front;
    front = front->next;
    front->prev = nullptr;
    delete delete_node;
    list_size--;
}

/*
 * name:      removeAt
 * purpose:   removes element anywhere in linkedlist
 * arguments: none
 * returns:   none
 * effects:   decrements character count
 */
void CharLinkedList::removeAt(int index){
    Node * remove_node = itterate_through(front, index);
    if(remove_node == nullptr){
        throw std::range_error("index (" + std::to_string(index) + 
                ") not in range [0.." + std::to_string(list_size) +")");
    }
    //check endpoints
    if(index == 0){
        popFromFront();
        return;
    }
    else if(index == (list_size - 1)){
        popFromBack();
        return;
    }
    else{
        remove_node->next->prev = remove_node->prev;
        remove_node->prev->next = remove_node->next;
        delete remove_node;
        list_size--;
    }
}

/*
 * name:      replaceAt
 * purpose:   replaces an element in linkedlist
 * arguments: character input value and integer index
 * returns:   none
 * effects:   changes character at specified index
 */
void CharLinkedList::replaceAt(char c, int index){
    Node * old_node = itterate_through(front, index);
    if(old_node == nullptr){
        throw std::range_error("index (" + std::to_string(index) + 
                ") not in range [0.." + std::to_string(list_size) +")");
    }
    else{
        Node * new_node = new Node;
        new_node->data = c;
        new_node->next = old_node->next;
        new_node->prev = old_node->prev;
        old_node->prev->next = new_node;
        old_node->next->prev = new_node;
        delete old_node;
    }
}

/*
 * name:      concatenate
 * purpose:   combines two linkedlist
 * arguments: CharLinkedList pointer
 * returns:   none
 * effects:   creates new, larger linkedlist
 */
void CharLinkedList::concatenate(CharLinkedList *other){
    if(other == nullptr){
        return;
    }
    if(this == other){
        CharLinkedList copy(*other);
        Node * first_other = copy.front;
        for(int i = 0; i < copy.list_size; i++){
            pushAtBack(first_other->data);
            first_other = first_other->next;
        }
        return;
    }
    Node * first_other = other->front;
    for(int i = 0; i < other->list_size; i++){
        pushAtBack(first_other->data);
        first_other = first_other->next;
    }
}

/*
 * name:      CharLinkedList destructor
 * purpose:   free memory associated with the linkedlist
 * arguments: none
 * returns:   none
 * effects:   frees memory allocated by CharLinkedlist instances
 */
CharLinkedList::~CharLinkedList(){
    clear();
}

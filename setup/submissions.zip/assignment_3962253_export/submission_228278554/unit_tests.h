/*
 *  unit_tests.h
 *  Cisco Hadden
 *  2/1/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  Create tests for each function implemented in CharLinkedList.cpp
 *
 */

#include "CharLinkedList.h"
#include <cassert>

// var to track whether runtime_error is thrown
bool runtime_error_thrown = false;
// var to track whether range_error is thrown
bool range_error_thrown = false;
// var to track any error messages raised
std::string error_message = "";

void test_first_constructor(){
    CharLinkedList test_empty;
}

void test_second_constructor(){
    CharLinkedList test_one_element('a');
}

void test_third_constructor(){
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList test_list(arr, 3);
}

// Tests size function.
// should return size of 1
void test_size(){
    CharLinkedList test_list('a');
    assert(test_list.size() == 1);
}

// Tests size when list is empty.
// Afterwards, size should be 0
void test_size_empty(){
    CharLinkedList test_list;
    assert(test_list.size() == 0);
}

// Tests when isEmpty is false.
// bool should return false
void test_isEmpty_false(){
    CharLinkedList test_arr('a');
    assert(not test_arr.isEmpty());
}


// Tests when isEmpty is true.
// bool should return true
void test_isEmpty_true(){
    CharLinkedList test_arr;
    assert(test_arr.isEmpty());
}

// Tests first function on larger list.
// should return 'a'
void test_first(){
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList test_arr(arr, 3);
    assert(test_arr.first() == 'a');
}

// Tests first function on empty list.
// should throw runtime error
void test_first_empty(){
    CharLinkedList test_arr;
    try {
    // front for out-of-range index
        test_arr.first();
    }
    catch (const std::runtime_error &e) {
    // if front is correctly implemented, a runtime_error will be thrown,
    // and we will end up here
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
}

// Tests last function on larger list.
// should return 'c'
void test_last(){
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList test_arr(arr, 3);
    assert(test_arr.last() == 'c');
}

// Tests last function on empty list.
// should throw runtime error
void test_last_empty(){
    CharLinkedList test_arr;
    try {
    // front for out-of-range index
        test_arr.last();
    }
    catch (const std::runtime_error &e) {
    // if front is correctly implemented, a runtime_error will be thrown,
    // and we will end up here
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
}

//test correct elementAt function for middle of list
void test_elementAt(){
    char test_arr[6] = { 'b', 'c', 'd', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 6);
    assert(test_list.elementAt(5) == 'h');
}

//test elementAt when list is empty
//should throw range error
void test_elementAt_empty(){
    CharLinkedList test_list;
    try{
    // removeAt for out-of-range index
        test_list.elementAt(2);
    }
    catch (const std::range_error &e) {
    // if removeAt is correctly implemented, a runtime_error will be thrown,
    // and we will end up here
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (2) not in range [0..0)");
}

//test elementAt when index is out of range
//should throw range error
void elementAt_out_of_range_above(){
    char test_arr[6] = { 'b', 'c', 'd', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 6);
    try{
    // removeAt for out-of-range index
        test_list.elementAt(22);
    }
    catch (const std::range_error &e) {
    // if removeAt is correctly implemented, a runtime_error will be thrown,
    // and we will end up here
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (22) not in range [0..6)");
}

//test elementAt when index is out of range
//should throw range error
void elementAt_out_of_range_below(){
    char test_arr[6] = { 'b', 'c', 'd', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 6);
    try{
    // removeAt for out-of-range index
        test_list.elementAt(-1);
    }
    catch (const std::range_error &e) {
    // if removeAt is correctly implemented, a runtime_error will be thrown,
    // and we will end up here
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (-1) not in range [0..6)");
}

//test pushAtBack function for larger list
void test_pushAtBack(){
    char test_arr[6] = { 'b', 'c', 'd', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 6);
    test_list.pushAtBack('z');
    assert(test_list.elementAt(6) == 'z');
    assert(test_list.toString() == "[CharLinkedList of size 7 <<bcdfghz>>]");
}

//test pushAtBack function for empty list
void test_pushAtBack_empty(){
    CharLinkedList test_list;
    test_list.pushAtBack('z');
    assert(test_list.elementAt(0) == 'z');
    assert(test_list.toString() == "[CharLinkedList of size 1 <<z>>]");
}

// Tests correct insertion into an empty AL.
// Afterwards, size should be 1 and element at index 0
// should be the element we inserted.
void insertAt_empty_correct() { 

    CharLinkedList test_list;
    test_list.insertAt('a', 0);
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');

}

// Tests incorrect insertion into an empty AL.
// Attempts to call insertAt for index larger than 0.
// This should result in an std::range_error being raised.
void insertAt_empty_incorrect() {

    CharLinkedList test_list;
    try {
        // insertAt for out-of-range index
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        // if insertAt is correctly implemented, a range_error will be thrown,
        // and we will end up here
        range_error_thrown = true;
        error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0)");
    
}

// Tests correct insertAt for front of 1-element list.
void insertAt_front_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at front
    test_list.insertAt('b', 0);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'a');
    
}

// Tests correct insertAt for back of 1-element list.
void insertAt_back_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at back
    test_list.insertAt('b', 1);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    
}

// Tests calling insertAt for a large number of elements.
// Not only does this test insertAt, it also checks that
// list expansion works correctly.
void insertAt_many_elements() {
    
    CharLinkedList test_list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.insertAt('a', i);
    }

    assert(test_list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
}

// Tests calling insertAt for a large number of elements.
void insertAt_middle(){
    // initialize multi-element list
    char test_arr[6] = { 'b', 'c', 'd', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 6);

    // insert at back
    test_list.insertAt('z', 2);

    assert(test_list.size() == 7);
    assert(test_list.elementAt(2) == 'z');
    assert(test_list.elementAt(3) == 'd');
}

//tests insertAt for a non-empty array when index is out of range
//should throw range error
void insertAt_out_of_range_nonempty(){
    // initialize multi-element list
    char test_arr[6] = { 'b', 'c', 'd', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 6);

    try {
        // insertAt for out-of-range index
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        // if insertAt is correctly implemented, a range_error will be thrown,
        // and we will end up here
        range_error_thrown = true;
        error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..6)");
}

//tests insertAt for a non-empty array when index is negative
//should throw range error
void insertAt_out_of_range_negative(){
    // initialize multi-element list
    char test_arr[6] = { 'b', 'c', 'd', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 6);

    try {
        // insertAt for out-of-range index
        test_list.insertAt('a', -1);
    }
    catch (const std::range_error &e) {
        // if insertAt is correctly implemented, a range_error will be thrown,
        // and we will end up here
        range_error_thrown = true;
        error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (-1) not in range [0..6)");
}

//test toString function
void test_toString(){
    char test_arr[6] = { 'b', 'c', 'd', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 6);
    assert(test_list.toString() == "[CharLinkedList of size 6 <<bcdfgh>>]");
}

//test toString function when given an empty lsit
void test_toString_empty(){
    CharLinkedList test_list;
    assert(test_list.toString() == "[CharLinkedList of size 0 <<>>]");
}

//test toReverseString function
void test_toReverseString(){
    char test_arr[6] = { 'b', 'c', 'd', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 6);
    assert(test_list.toReverseString() == 
    "[CharLinkedList of size 6 <<hgfdcb>>]");
}

//test toReverseString function when given an empty list
void test_toReverseString_empty(){
    CharLinkedList test_list;
    assert(test_list.toReverseString() == "[CharLinkedList of size 0 <<>>]");
}

// Tests insertInOrder function on larger list.
// should insert 'e' at index 3
void test_insertInOrder(){
    char test_arr[7] = { 'a', 'b', 'c', 'd', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 7);
    test_list.insertInOrder('e');
    assert(test_list.elementAt(4) == 'e');
    assert(test_list.toString() == "[CharLinkedList of size 8 <<abcdefgh>>]");
}

//test insertInOrder when inserting an element that already exists in the list
void test_insertInOrder_same(){
    char test_arr[7] = { 'a', 'b', 'c', 'd', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 7);
    test_list.insertInOrder('a');
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'a');
    assert(test_list.toString() == "[CharLinkedList of size 8 <<aabcdfgh>>]");
}

//test insertInOrder when instering to begining of list
void test_insertInOrder_begining(){
    char test_arr[6] = { 'b', 'c', 'd', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 6);
    test_list.insertInOrder('a');
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    assert(test_list.toString() == "[CharLinkedList of size 7 <<abcdfgh>>]");
}

//test insertInOrder when instering to end of list
void test_insertInOrder_end(){
    char test_arr[6] = { 'b', 'c', 'd', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 6);
    test_list.insertInOrder('z');
    assert(test_list.elementAt(5) == 'h');
    assert(test_list.elementAt(6) == 'z');
    assert(test_list.toString() == "[CharLinkedList of size 7 <<bcdfghz>>]");
}

// Tests popFromFront function on larger list.
// should remnove first element 'a'
void test_popFromFront(){
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList test_arr(arr, 3);
    test_arr.popFromFront();
    assert(test_arr.first() == 'b');
}

// Tests popFromFront function on empty list.
// should throw runtime error
void test_popFromFront_empty(){
    CharLinkedList test_arr;
    try{
    // removeAt for out-of-range index
        test_arr.popFromFront();
    }
    catch (const std::runtime_error &e) {
    // if removeAt is correctly implemented, a runtime_error will be thrown,
    // and we will end up here
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
}

// Tests popFromBack function on larger list.
// should remnove last element 'c'
void test_popFromBack(){
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList test_arr(arr, 3);
    test_arr.popFromBack();
    assert(test_arr.last() == 'b');
}

// Tests popFromBack function on empty list.
// should throw runtime error
void test_popFromBack_empty(){
    CharLinkedList test_arr;
    try{
    // removeAt for out-of-range index
        test_arr.popFromBack();
    }
    catch (const std::runtime_error &e) {
    // if removeAt is correctly implemented, a runtime_error will be thrown,
    // and we will end up here
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
}

// Tests removeAt function on middle of list.
// should remnove middle element 'b'
void test_removeAt(){
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList test_arr(arr, 3);
    test_arr.removeAt(1);
    assert(test_arr.first() == 'a');
    assert(test_arr.elementAt(1) == 'c');
}

// Tests removeAt function on empty list.
// should throw range error
void test_removeAt_empty(){
    CharLinkedList test_arr;
    try{
    // removeAt for out-of-range index
        test_arr.removeAt(2);
    }
    catch (const std::range_error &e) {
    // if removeAt is correctly implemented, a runtime_error will be thrown,
    // and we will end up here
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (2) not in range [0..0)");
}

// Tests removeAt function out of range.
// should throw range error
void test_removeAt_out_of_range(){
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList test_arr(arr, 3);
    try{
    // removeAt for out-of-range index
        test_arr.removeAt(4);
    }
    catch (const std::range_error &e) {
    // if removeAt is correctly implemented, a runtime_error will be thrown,
    // and we will end up here
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (4) not in range [0..3)");
}

// Tests removeAt function on end of list.
// should remnove last element 'c'
void test_removeAt_last(){
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList test_arr(arr, 3);
    test_arr.removeAt(2);
    assert(test_arr.first() == 'a');
    assert(test_arr.last() == 'b');
}

// Tests removeAt function on begining of list.
// should remnove first element 'c'
void test_removeAt_first(){
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList test_arr(arr, 3);
    test_arr.removeAt(0);
    assert(test_arr.first() == 'b');
    assert(test_arr.last() == 'c');
}

//test replaceAt function in the middle of a larger list
void test_replaceAt(){
    char test_arr[6] = { 'b', 'c', 'd', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 6);
    test_list.replaceAt('z', 2);
    assert(test_list.elementAt(2) == 'z');
    assert(test_list.toString() == "[CharLinkedList of size 6 <<bczfgh>>]");
}

//test replaceAt function on empty list
//should throw range error
void test_replaceAt_empty(){
    CharLinkedList test_list;
    try{
    // replaceAt for out-of-range index
        test_list.replaceAt('z', 0);
    }
    catch (const std::range_error &e) {
    // if replaceAt is correctly implemented, a runtime_error will be thrown,
    // and we will end up here
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (0) not in range [0..0)");
}

//test replaceAt function index out of range
//should throw range error
void test_replaceAt_out_of_bounds(){
    char test_arr[6] = { 'b', 'c', 'd', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 6);
    try{
    // replaceAt for out-of-range index
        test_list.replaceAt('z', 22);
    }
    catch (const std::range_error &e) {
    // if replaceAt is correctly implemented, a runtime_error will be thrown,
    // and we will end up here
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (22) not in range [0..6)");
}

//test replaceAt function index out of range
//should throw range error
void test_replaceAt_negative(){
    char test_arr[6] = { 'b', 'c', 'd', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 6);
    try{
    // replaceAt for out-of-range index
        test_list.replaceAt('z', -1);
    }
    catch (const std::range_error &e) {
    // if replaceAt is correctly implemented, a runtime_error will be thrown,
    // and we will end up here
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (-1) not in range [0..6)");
}

//test concatinate function on two lists
void test_concatenate(){
    char test_arr_1[6] = { 'b', 'c', 'd', 'f', 'g', 'h' };
    CharLinkedList test_list_1(test_arr_1, 6);
    char test_arr_2[2] = { 'z', 'y' };
    CharLinkedList test_list_2(test_arr_2, 2);
    CharLinkedList * ptr = &test_list_2;

    test_list_1.concatenate(ptr);
    std::cerr << test_list_1.toString() << "\n";
    assert(test_list_1.toString() == 
                "[CharLinkedList of size 8 <<bcdfghzy>>]");
}

//test concatinate function on an list and a pointer to itself
void test_self_concatenate(){
    char test_arr_1[6] = { 'b', 'c', 'd', 'f', 'g', 'h' };
    CharLinkedList test_list_1(test_arr_1, 6);
    CharLinkedList * ptr = &test_list_1;

    test_list_1.concatenate(ptr);
    assert(test_list_1.toString() == 
    "[CharLinkedList of size 12 <<bcdfghbcdfgh>>]");
}

//test concatinate function on an List and a nullptr
void test_concatenate_empty(){
    char test_arr_1[6] = { 'b', 'c', 'd', 'f', 'g', 'h' };
    CharLinkedList test_list_1(test_arr_1, 6);
    CharLinkedList * ptr = nullptr;
    test_list_1.concatenate(ptr);
    assert(test_list_1.toString() == "[CharLinkedList of size 6 <<bcdfgh>>]");
}
/*
 *  CharLinkedList.h
 *  Amanda Sunga (asunga01)
 *  February 6, 2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  A header file containing all the public and private properties of the 
 *  CharLinkedList class - includes packages to be used in certain funtions and
 *  the Node struct, which holds the data for the list.
 *
 */

#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H

#include <stdexcept>
#include <sstream>

class CharLinkedList {
public:
    CharLinkedList();
    CharLinkedList(char c);
    CharLinkedList(char arr[], int size);
    CharLinkedList(const CharLinkedList &other);
    
    ~CharLinkedList();
    
    CharLinkedList &operator=(const CharLinkedList &other);
    
    bool isEmpty() const;
    void clear();
    
    int size() const;
    char first() const;
    char last() const;
    char elementAt(int index) const;
    
    std::string toString() const;
    std::string toReverseString() const;
    
    void pushAtBack(char c);
    void pushAtFront(char c);
    
    void insertAt(char c, int index);
    void insertInOrder(char c);
    
    void popFromBack();
    void popFromFront();
    
    void removeAt(int index);
    void replaceAt(char c, int index);
    
    void concatenate(CharLinkedList *other);

private:
    struct Node {
        char data;
        Node *next;
    };

    Node *front;
    int numChars;

    // helper functions:
    Node *newNode(char c, Node *next);
    void recycleRecursive(Node *curr);
    char findElementRecursive(Node *curr, int index) const;
    void clearRecursive(Node *curr);
    void replaceAtRecursive(Node *curr, char c, int index);
};

#endif

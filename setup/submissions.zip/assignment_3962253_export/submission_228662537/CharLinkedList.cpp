/*
 *  CharLinkedList.cpp
 *  Amanda Sunga (asunga01)
 *  February 6, 2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  A file that holds the implementation of both public and private functions
 *  for the CharLinkedList class. Includes all public functions mentioned in
 *  the spec, as well as private helper functions that improve the modularity
 *  of the class and assist with recursion.
 *
 */

#include "CharLinkedList.h"

/*
 * name: CharLinkedList
 * purpose: default constructor that initializes an empty list
 * arguments: none
 * returns: none - constructs list
 * effects: none
 */
CharLinkedList::CharLinkedList() {
    front = nullptr;
    numChars = 0;
}

/*
 * name: CharLinkedList
 * purpose: constructor that creates a single-element list
 * arguments: character to be initialized to the list
 * returns: none - constructs list
 * effects: none
 */
CharLinkedList::CharLinkedList(char c) {
    numChars = 1;
    front = newNode(c, nullptr);
}

/*
 * name: CharLinkedList
 * purpose: constructor that creates a list containing the characters in an
 *          array
 * arguments: array of characters to be added to the list and the size of the
 *            array
 * returns: none - constructs list
 * effects: none
 */
CharLinkedList::CharLinkedList(char arr[], int size) {
    numChars = size;
    front = nullptr;

    Node *curr = nullptr;
    
    for (int i = 0; i < size; i++) {
        Node *temp = newNode(arr[i], nullptr);

        if (not front) {
            front = temp;
            curr = front;
        } else {
            curr->next = temp;
            curr = temp;
        }
    }
}

/*
 * name: CharLinkedList
 * purpose: copy constructor that makes deep copy of given instance
 * arguments: address of instance to be copied (on right hand size)
 * returns: none - constructs list
 * effects: none
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other) {
    front = nullptr;
    Node *otherCurr = other.front;
    Node *curr = nullptr;

    while (otherCurr) {
        Node *temp = newNode(otherCurr->data, nullptr);

        if (not front) {
            front = temp;
            curr = front;
        } else {
            curr->next = temp;
            curr = temp;
        }

        otherCurr = otherCurr->next;
    }

    numChars = other.numChars;
}

/*
 * name: ~CharLinkedList
 * purpose: destructor that deletes/recycles all heap-allocated data in list
 * arguments: none
 * returns: none - clears memory on heap
 * effects: prevents memory leaks
 */
CharLinkedList::~CharLinkedList() {
    recycleRecursive(front);
}

/*
 * name: recycleRecursive
 * purpose: recursive helper function for destructor
 * arguments: pointer to the current node
 * returns: none
 * effects: deletes/recycles created nodes via recursion
 */
void CharLinkedList::recycleRecursive(Node *curr) {
    if (curr == nullptr) {
        return;
    } else {
        Node *next = curr->next;
        delete curr;
        recycleRecursive(next);
    }
}

/*
 * name: operator
 * purpose: assignment operator that recycles storage associated with instance
 *          and creates a deep copy
 * arguments: address of instance to make a deep copy of
 * returns: deep copy of copied instance
 * effects: allocates needed memory on heap
 */
CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other) {
    if (this == &other) {
        return *this;
    }

    clear();

    front = nullptr;
    Node *curr = other.front;

    while (curr) {
        pushAtBack(curr->data);
        curr = curr->next;
    }

    return *this;
}

/*
 * name: newNode
 * purpose: helper function that creates a new node and adds necessary data
 * arguments: character associated with the node and a pointer to the next node
 * returns: new node with relevant data
 * effects: allocates new memory on heap; can result in segfault if not
 *          implemented correctly
 */
CharLinkedList::Node *CharLinkedList::newNode(char c, Node *next) {
    Node *newNode = new Node;

    newNode->data = c;
    newNode->next = next;
    
    return newNode;
}

/*
 * name: isEmpty
 * purpose: checks to see if the linked list is empty or not
 * arguments: none
 * returns: boolean value declaring if there are no nodes in the list
 * effects: none
 */
bool CharLinkedList::isEmpty() const {
    if (front == nullptr) {
        return true;
    } else {
        return false;
    }
}

/*
 * name: clear
 * purpose: makes instance into an empty list
 * arguments: none
 * returns: none - clears list
 * effects: when implemented correctly, isEmpty() returns true
 */
void CharLinkedList::clear() {
    clearRecursive(front);
    front = nullptr;
    numChars = 0;
}

/*
 * name: clearRecursive
 * purpose: helper function that clears nodes
 * arguments: pointer to the current node
 * returns: none - clears list
 * effects: recurses through the linked list and sets all the data to nullptrs
 */
void CharLinkedList::clearRecursive(Node *curr) {
    if (curr == nullptr) {
        return;
    } else {
        clearRecursive(curr->next);
        delete curr;
    }
}

/*
 * name: size
 * purpose: gets the number of character nodes in the list
 * arguments: none
 * returns: integer value of the number of characters in the list
 * effects: is 0 if and only if isEmpty is true
 */
int CharLinkedList::size() const {
    return numChars;
}

/*
 * name: first
 * purpose: gets the first character of the list
 * arguments: none
 * returns: first character in the list
 * effects: throws runtime_error if the list is empty
 */
char CharLinkedList::first() const {
    if (isEmpty()) {
        throw std::runtime_error("cannot get first of empty LinkedList");
    }
    return front->data;
}

/*
 * name: last
 * purpose: gets the last character of the list
 * arguments: none
 * returns: last character in the list
 * effects: throws runtime_error if the list is empty
 */
char CharLinkedList::last() const {
    if (isEmpty()) {
        throw std::runtime_error("cannot get last of empty LinkedList");
    }
    return elementAt(numChars - 1);
}

/*
 * name: elementAt
 * purpose: finds integer at a given index
 * arguments: integer of the index
 * returns: character at the specified index
 * effects: throws range_error if the index is negative and/or out-of-bounds
 */
char CharLinkedList::elementAt(int index) const {
    if (index > numChars or index < 0) {
        throw std::range_error("index (" + std::to_string(index) + ") not in " 
        + "range [0.." + std::to_string(numChars) + ")");
    }

    return findElementRecursive(front, index);
}

/*
 * name: findElementRecursive
 * purpose: recursive helper function for elementAt
 * arguments: pointer to the current node and the integer of the index
 * returns: charcter at the specified index
 * effects: none
 */
char CharLinkedList::findElementRecursive(Node *curr, int index) const {
    if (index == 0) {
        return curr->data;
    }

    return findElementRecursive(curr->next, index - 1);
}

/*
 * name: toString
 * purpose: converts list into a string
 * arguments: none
 * returns: string containing the characters of the linked list
 * effects: creates string in the form of [CharLinkedList of size 5 <<Alice>>]
 */
std::string CharLinkedList::toString() const {
    std::string word = "[CharLinkedList of size " + std::to_string(size()) 
                        + " <<";

    for (int i = 0; i < numChars; i++) {
        word += elementAt(i);
    }

    word += ">>]";

    return word;
}

/*
 * name: toReverseString
 * purpose: converts list into a string (in reversed order)
 * arguments: none
 * returns: string containing the characters of the linked list in reversed
 *          order
 * effects: creates string in the form of [CharLinkedList of size 5 <<ecilA>>]
 */
std::string CharLinkedList::toReverseString() const {
    std::string word = "[CharLinkedList of size " + std::to_string(size()) 
                        + " <<";
    
    for (int i = numChars - 1; i >= 0; i--) {
        word += elementAt(i);
    }

    word += ">>]";

    return word;
}

/*
 * name: pushAtBack
 * purpose: inserts new character after the last exisiting character on the list
 * arguments: character to be inserted
 * returns: none
 * effects: adds character to back of list
 */
void CharLinkedList::pushAtBack(char c) {
    insertAt(c, numChars);
}

/*
 * name: pushAtFront
 * purpose: inserts new character before the first existing character of the
 *          list
 * arguments: character to be inserted
 * returns: none
 * effects: adds character to front of the list
 */
void CharLinkedList::pushAtFront(char c) {
    insertAt(c, 0);
}

/*
 * name: insertAt
 * purpose: inserts new character at specified index
 * arguments: character to be inserted and index to be inserted at
 * returns: none
 * effects: throws range_error if index is negative and/or out-of-bounds
 */
void CharLinkedList::insertAt(char c, int index) {
    if (index > numChars or index < 0) {
        throw std::range_error("index (" + std::to_string(index) + ") not in " 
        + "range [0.." + std::to_string(numChars) + "]");
    }

    if (index == 0) {
        front = newNode(c, front);
        numChars++;
        return;
    }

    Node *curr = front;
    int currIndex = 0;
    
    while (currIndex != index - 1) {
        curr = curr->next;
        currIndex++;
    }
    
    curr->next = newNode(c, curr->next);
    numChars++;
}

/*
 * name: insertInOrder
 * purpose: inserts charcter into the list in ASCII order
 * arguments: character to be inserted
 * returns: none
 * effects: none
 */
void CharLinkedList::insertInOrder(char c) {
    Node *curr = front;
    int currIndex = 0;

    while (currIndex < numChars and c > curr->data) {
        curr = curr->next;
        currIndex++;
    }

    insertAt(c, currIndex);
}

/*
 * name: popFromFront
 * purpose: removes first element from the list
 * arguments: none
 * returns: none
 * effects: throws runtime_error if the list is empty
 */
void CharLinkedList::popFromFront() {
    if (isEmpty()) {
        throw std::runtime_error("cannot pop from empty LinkedList");
    }
    removeAt(0);
}

/*
 * name: popFromBack
 * purpose: removes last element from the list
 * arguments: none
 * returns: none
 * effects: throws runtime_error if the list is empty
 */
void CharLinkedList::popFromBack() {
    if (isEmpty()) {
        throw std::runtime_error("cannot pop from empty LinkedList");
    }
    removeAt(numChars - 1);
}

/*
 * name: removeAt
 * purpose: removes character at specified index
 * arguments: integer of the index to remove at
 * returns: none
 * effects: throws range_error if the index is negative and/or out-of-bounds
 */
void CharLinkedList::removeAt(int index) {
    if (index > numChars or index < 0) {
        throw std::range_error("index (" + std::to_string(index) + ") not in " 
        + "range [0.." + std::to_string(numChars) + ")");
    }

    Node *curr = front;
    int currIndex = 0;

    if (index > 0) {
        while (currIndex != index - 1) {
            curr = curr->next;
            currIndex++;
        }
    }
    // temporary pointers to hold the future two nodes:
    Node *temp1 = curr->next;
    Node *temp2 = temp1->next;

    while (temp2) {
        curr = temp1;
        temp1 = temp2;
    }

    numChars--;

}

/*
 * name: replaceAt
 * purpose: replaces character at specified index with new character
 * arguments: new character to replace and the index to replace at
 * returns: none
 * effects: throws range_error if index is negative and/or out-of-bounds
 */
void CharLinkedList::replaceAt(char c, int index) {
    if (index > numChars or index < 0) {
        throw std::range_error("index (" + std::to_string(index) + ") not in " 
        + "range [0.." + std::to_string(numChars) + ")");
    }

    replaceAtRecursive(front, c, index);
} 

/*
 * name: replaceAtRecursive
 * purpose: recursive helper function that replaces the character
 * arguments: pointer to the current node, character to replace with, and index
 *            to replace at
 * returns: none
 * effects: none - updates data in specified node
 */
void CharLinkedList::replaceAtRecursive(Node *curr, char c, int index) {
    if (index == 0) {
        curr->data = c;
    } else {
        replaceAtRecursive(curr->next, c, index - 1);
    }
}

/*
 * name: concatenate
 * purpose: adds copy of list to the end of another list
 * arguments: pointer to a second list to be added
 * returns: none
 * effects: updates the first list in memory with the content of the second
 *          list added to the end
 */
void CharLinkedList::concatenate(CharLinkedList *other) {
    if (other->front == nullptr or other->numChars == 0) return;

    for (int i = 0; i < other->numChars; i++) {
        pushAtBack(other->elementAt(i));
    }

    numChars += other->numChars;
}
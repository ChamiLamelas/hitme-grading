/*
 *  unit_tests.h
 *  Amanda Sunga (asunga01)
 *  February 6, 2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  A header file containing unit tests to assess the functionality of the
 *  CharLinkedList funcitons (featuring new tests and tests borrowed from the
 *  previous assignment).
 *
 */

#include "CharLinkedList.h"
#include <cassert>

// Testing Constructors
void test_constructors() {
    CharLinkedList list1;
    CharLinkedList list2('a');

    char test_arr[5] = {'a','c','b','d','j'};
    CharLinkedList list3(test_arr, 5);

    assert(list1.isEmpty());

    assert(not list2.isEmpty());
    assert(list2.size() == 1);
    assert(list2.first() == 'a');

    assert(not list3.isEmpty());
    assert(list3.size() == 5);
    assert(list3.last() == 'j');
    assert(list3.elementAt(2) == 'b');
}

// Testing empty and clear
void test_empty() {
    char test_arr[7] = {'a','a','a','a','a','a','a'};

    CharLinkedList list(test_arr, 7);

    assert(not list.isEmpty());

    list.clear();

    assert(list.isEmpty());
}

// Testing insert and elementAt
void test_inserting() {
    char test_arr[3] = {'a','b','c'};
    CharLinkedList list(test_arr, 3);

    list.insertAt('d', 2);

    assert(list.elementAt(0) == 'a');
    assert(list.elementAt(2) == 'd');

    list.insertInOrder('c');

    assert(list.elementAt(2) == 'c');
}

// Testing push functions
void test_push() {
    char test_arr[3] = {'a','b','c'};
    CharLinkedList list(test_arr, 3);

    list.pushAtFront('z');
    list.pushAtBack('x');

    assert(list.first() == 'z');
    assert(list.last() == 'x');
}


// Testing string conversion functions
void test_strings() {
    char test_arr[5] = {'A','l','i','c','e'};
    CharLinkedList list(test_arr, 5);

    assert(list.toString() == "[CharLinkedList of size 5 <<Alice>>]");
    assert(list.toReverseString() == "[CharLinkedList of size 5 <<ecilA>>]");
}

// Testing remove functions
void test_remove() {
    char test_arr[3] = {'a','b','c'};
    CharLinkedList list(test_arr, 3);

    list.removeAt(2);

    assert(list.last() == 'b');
}

// Testing replace
void test_replace() {
    char test_arr[3] = {'a','b','c'};
    CharLinkedList list(test_arr, 3);

    assert(list.elementAt(1) == 'b');

    list.replaceAt('z', 1);

    assert(list.elementAt(1) == 'z');
}

// Tests from previous homework

// Tests correct insertion into an empty AL.
// Afterwards, size should be 1 and element at index 0
// should be the element we inserted.
void insertAt_empty_correct() { 

    CharLinkedList test_list;
    test_list.insertAt('a', 0);
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');

}

// Tests incorrect insertion into an empty AL.
// Attempts to call insertAt for index larger than 0.
// This should result in an std::range_error being raised.
void insertAt_empty_incorrect() {

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    // insertAt for out-of-range index
    test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
    // if insertAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    range_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0]");
    
}

// Tests correct insertAt for front of 1-element list.
void insertAt_front_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at front
    test_list.insertAt('b', 0);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'a');
    
}

// Tests correct insertAt for back of 1-element list.
void insertAt_back_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at back
    test_list.insertAt('b', 1);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    
}

// Tests calling insertAt for a large number of elements.
// Not only does this test insertAt, it also checks that
// array expansion works correctly.
void insertAt_many_elements() {
    
    CharLinkedList test_list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.insertAt('a', i);
    }

    assert(test_list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
    
}

// Tests insertion into front of a larger list
void insertAt_front_large_list() {
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    test_list.insertAt('y', 0);

    assert(test_list.size() == 10);
    assert(test_list.elementAt(0) == 'y');
    assert(test_list.toString()== "[CharLinkedList of size 10 <<yabczdefgh>>]");

}

// Tests insertion into the back of a larger list
void insertAt_back_large_list() {

    char test_arr[10] = { 'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 10);  

    test_list.insertAt('x', 10);

    assert(test_list.size() == 11);
    assert(test_list.elementAt(10) == 'x');
    assert(test_list.toString() == 
    "[CharLinkedList of size 11 <<yabczdefghx>>]"); 

}

// Tests insertion into the middle of a larger list
void insertAt_middle_large_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.insertAt('z', 3);

    assert(test_list.size() == 9);
    assert(test_list.elementAt(3) == 'z');
    assert(test_list.toString() == "[CharLinkedList of size 9 <<abczdefgh>>]");

}

// Tests out-of-range insertion for a non-empty list.
void insertAt_nonempty_incorrect() {
   
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8]");
    
}


// ADDITIONAL UNIT TESTS FOR INDIVIDUAL FUNCTIONS

// Tests to see that the constructors are working
void testConstructor1() {
    CharLinkedList list;
}

void testConstructor2() {
    CharLinkedList list('a');
}

void testConstructor3() {
    char test_arr[5] = {'z','b','q','x','g'};
    CharLinkedList list(test_arr, 5);

    assert(list.first() == 'z');
}

// Testing the copy constructor by creating two different instances and copying
// into a third instance
void testCopy() {
    char test_arr1[5] = {'m','o','t','e','l'};
    char test_arr2[3] = {'s','a','d'};

    CharLinkedList list1(test_arr1, 5);
    CharLinkedList list2(test_arr2, 3);

    assert(list2.toString() == "[CharLinkedList of size 3 <<sad>>]");
   
    // create a "deep copy" of the first ArrayList
    CharLinkedList list3(list1);

    assert(list3.toString() == "[CharLinkedList of size 5 <<motel>>]");

}

// Autograder Test
void test_push_to_string() {
    CharLinkedList list;

    list.pushAtBack('n');
    assert(list.toString() == "[CharLinkedList of size 1 <<n>>]");

    list.clear();
    assert(list.isEmpty());

    list.pushAtFront('z');
    assert(list.toString() == "[CharLinkedList of size 1 <<z>>]");
}
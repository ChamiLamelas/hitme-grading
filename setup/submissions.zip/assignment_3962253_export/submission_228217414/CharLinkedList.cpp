/*
 *  CharLinkedList.cpp
 *  Bryan Cho
 *  1/30/2023
 *  Edited by Bryan Cho 2/6/2024
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  File implementations for function definitions in the CharLinkedList class
 *
 */

#include "CharLinkedList.h"
#include <sstream>
#include <iostream>

using namespace std;

//  name:      CharLinkedList default constructor
//  purpose:   initialize an empty CharLinkedList
//  arguments: none
//  returns:   none
//  effects:   set front to nullptr and size to zero
CharLinkedList::CharLinkedList(){
    front = nullptr;
    tail = nullptr;
    numItems = 0;
}

//  name:      CharLinkedList 2nd constructor with char
//  purpose:   initialize a linked list with a char element
//  arguments: inputted char element
//  returns:   none
//  effects:   point to the first char value
CharLinkedList::CharLinkedList(char c){
    front = newNode(c,nullptr, nullptr);
    tail = front;
    numItems = 1;
}

/*
 * name:      CharLinkedList 3rd constructor
 * purpose:   initialize a linked list copying from a list and its size
 * arguments: inputted linked list and size
 * returns:   none
 * effects:   have the linked list store the values from linked list
 */
CharLinkedList::CharLinkedList(char arr[],int size){
    if(size == 0){
        front = nullptr;
        tail = nullptr;
        numItems = 0;
        return;
    }
    numItems = 0;
    front = nullptr;
    tail = nullptr;

    for (int i = 0; i < size; i++){
        pushAtBack(arr[i]);
    }
}

/*
 * name:      LinkedList 4th constructor
 * purpose:   initialize a LinkedList and make a deep copy of LinkedList 
                object other
 * arguments: another LinkedList object 
 * returns:   none
 * effects:   deep copy of LinkedList object other 
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other){
    numItems = 0;
    front = nullptr;
    tail = nullptr;

    for(int i = 0; i < other.size(); i++){
        pushAtBack(other.elementAt(i));
    }
    
}

/*
 * name:      CharLinkedList destructor
 * purpose:   delete all memory
 * arguments: none
 * returns:   none
 * effects:   pass valgrind with no leak memory
 */
CharLinkedList::~CharLinkedList(){
    recycleRecursive(front);
}

/*
 * name:      CharLinkedList &Operator=(const CharLinkedList &other)
 * purpose:   deep copy CharLinkedList object other 
 * arguments: another CharLinkedList object
 * returns:   CharLinkedList object 
 * effects:   make a deep copy using the other CharLinkedList object
 *             from an already initialized list
 */
CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other){
    
    recycleRecursive(front);
    front = nullptr;
    tail = nullptr;

    for(int i = 0; i < other.size(); i++){
        pushAtBack(other.elementAt(i));
    }

    return* this;
}

/*
 * name:      CharLinkedList recycleRecursive
 * purpose:   delete all memory
 * arguments: curr
 * returns:   none
 * effects:   pass valgrind with no leak memory helper function
 */
void CharLinkedList::recycleRecursive(Node* curr){
    if(curr == nullptr){
        return;
    }
    else {
        Node* next = curr->next;
        delete curr;
        numItems--;
        recycleRecursive(next);
    }
}

/*
 * name:      CharLinkedList newNode
 * purpose:   make a new node 
 * arguments: a char value, the next node pointer and previous node pointer
 * returns:   the new node
 * effects:   creates a new node within a linked list
 */
CharLinkedList::Node *CharLinkedList::newNode(char c, Node* next, Node* prev){
    Node* new_node = new Node;
    new_node->data = c;
    new_node->next = next;
    new_node->prev = prev;
    return new_node;
}


//  name:      int size() const
//  purpose:   get the size of the linked list
//  arguments: none
//  returns:   number of items
//  effects:   return the number of items
int CharLinkedList::size() const{
    return numItems;
}

/*
 * name:      void empty()
 * purpose:   makes an instance into an empty Linked List
 * arguments: none
 * returns:   none
 * effects:   clears an Linked List into an Linked List 
 */
void CharLinkedList::clear(){
    recycleRecursive(front);
    numItems = 0;
    front = nullptr;
    tail = nullptr;
}

/*
 * name:      char first() const
 * purpose:   get the first value of Linked List element
 * arguments: none
 * returns:   the first value in linked list if it isn't null
 * effects:   return last value of linked list
 */
char CharLinkedList::first() const{
    if(numItems != 0){
        return front->data;
    }
    throw std::runtime_error("cannot get first of empty LinkedList"); 
}

/*
 * name:      char last() const
 * purpose:   get the last value of Linked List element
 * arguments: none
 * returns:   the last value in linked list if it isn't null
 * effects:   return last value of linked list
 */
char CharLinkedList::last() const{
    if(numItems != 0){ // if it is empty, you can't retrieve anything
        return tail->data;
    }
    throw std::runtime_error("cannot get last of empty LinkedList");
}

/*
 * name:      char elementAt(int index) const
 * purpose:   get the value of CharLinkedList of indexed value
 * arguments: user inputted value
 * returns:   the value in linked list if it isn't null
 * effects:   return element at index unless there's an error
 */
char CharLinkedList::elementAt(int index) const{
    if (index < 0 or index >= numItems){
        throw std::range_error("index (" + to_string(index) + ") not in" +
        " range [0.." + std::to_string(numItems) + ")");
    }

    Node* curr = front;

    curr = indexHelper(curr,index);  //iterates to wanted index
    const char character = curr->data;   
    return character;
}

/*
 * name:      Node* indexHelper() const
 * purpose:   get to the wanted user inputted index
 * arguments: user inputted value, a node 
 * returns:   the node of wanted index
 * effects:   return node of wanted index
 */
CharLinkedList::Node* CharLinkedList::indexHelper(Node* curr, int index) const{
    
    if (index == 0){
        return curr;
    } else{
        return indexHelper(curr->next, index - 1);
    }
}


/*
 * name:      void pushAtFront
 * purpose:   insert a char at the beginning of Linked List
 * arguments: user inputted char value
 * returns:   none
 * effects:   inserts a char at the beginning of linked list
 */
void CharLinkedList::pushAtFront(char c){
    front = newNode(c, front, nullptr); // make new node for front
    if(front -> next != nullptr)
        front -> next -> prev = front;
    numItems++;
    if(numItems == 1){
        tail = front;
    }
}

/*
 * name:      void pushAtBack(char c)
 * purpose:   insert a char at the end of Linked List
 * arguments: user inputted char value
 * returns:   none
 * effects:   inserts a char at the end of linked list
 */
void CharLinkedList::pushAtBack(char c){
    
    if(numItems == 0){
        pushAtFront(c);
        return;
    }
    tail->next = newNode(c, nullptr, tail); // make a new tail 
    tail = tail->next;  // make the previous tail into the new tail
    tail -> prev -> next = tail;
    numItems++;
}


/*
 * name:      void isEmpty()
 * purpose:   check to see if list is empty
 * arguments: none
 * returns:   return if list is empty
 * effects:   return to see if a list is empty
 */
bool CharLinkedList::isEmpty() const{
    if (numItems == 0){
        return true;
    }
    return false;
}

/*
 * name:      std::string toString() const
 * purpose:   convert all the info into a string
 * arguments: none
 * returns:   string that contains characters of the CharLinkedList
 * effects:   a returned string of contents of size and char's in the linked
 *             list 
 */
std::string CharLinkedList::toString() const{
    std::string result = "[CharLinkedList of size " + std::to_string(numItems)
                            + " <<";
    for(Node* curr = front; curr != nullptr; curr = curr->next){
        result += curr->data;
    }
    result += ">>]";
    return result;
}

/*
 * name:      std::string toReverseString() const
 * purpose:   convert all the info into a string in reverse order
 * arguments: none
 * returns:   string that contains characters of the CharLinkedList
 * effects:   a returned string of contents in reverse order of size and 
 *            char's in the linked list
 */
std::string CharLinkedList::toReverseString() const{
    std::string result = "[CharLinkedList of size " + std::to_string(numItems)
                            + " <<";
    for(Node* curr = tail; curr != nullptr; curr = curr->prev){
        result += curr->data;
    }
    result += ">>]";
    return result;
}

/*
 * name:      insertInOrder(char c)
 * purpose:   insert user inputted char into a list in correct order ASCII
 * arguments: none
 * returns:   string that contains characters of the CharLinkedList
 * effects:   a returned string of contents in reverse order of size and 
 *            char's in the linked list
 */
void CharLinkedList::insertInOrder(char c){
    
    if(isEmpty()){
        insertAt(c,0);
        return;
    }


    if(c <= front->data){
        pushAtFront(c);
        return;
    } else if(c >= tail->data){
        pushAtBack(c);
        return;
    }

    int counter = 0; 
    for(Node* curr = front->next; curr != nullptr; curr = curr->next){
        counter++;
        if(c >= curr->data and c <= curr->next->data){
            insertAt(c,counter+1);
            return;
        }
    }
}

/*
 * name:      insertInOrder(char c)
 * purpose:   insert user inputted char into list in correct order ASCII
 * arguments: none
 * returns:   string that contains characters of the CharLinkedList
 * effects:   a returned string of contents in reverse order of size and 
 *            char's in the linked list
 */
void CharLinkedList::insertAt(char c, int index){ 
    
    if (index < 0 or index > numItems) {
        throw std::range_error("index (" + to_string(index) + ") not in range" 
        + " [0.." + to_string(numItems) + "]");
    }
    
    if(index == 0){
        pushAtFront(c);
        return;                                  
    }
    if (index == numItems){
        pushAtBack(c);
        return;
    }
    
    
    Node* curr = front;
    int curr_index = 0;
    while (curr_index < index - 1){
        curr = curr->next;
        curr_index++;
    }

    curr->next = newNode(c, curr->next, curr->prev); //implement this function 
    numItems++;
}

/*
 * name:      void removeAt(int index)
 * purpose:   remove an element at a certain index
 * arguments: user inputted index value
 * returns:   none
 * effects:   removes an element at a certain index
 */
void CharLinkedList::removeAt(int index){
    if (index < 0 or index >= numItems){
        throw std::range_error("index (" + to_string(index) + ") not in range" 
        + " [0.." + to_string(numItems) + ")");
    }
    Node* curr = front;
    if (index == 0){
        popFromFront();
        return;
    }
    if (index == numItems - 1){
        popFromBack();
        return;
    }
    curr = indexHelper(curr, index);
    curr->prev->next = curr->next;
    curr->next->prev = curr->prev;
    delete curr;
    numItems--;

}

/*
 * name:      void replaceAt
 * purpose:   replace an element with an inputted char value at specified 
              index
 * arguments: user inputted char value and index value 
 * returns:   none
 * effects:   replaces an element at an index with a another char value 
 */
void CharLinkedList::replaceAt(char c, int index){
    if (index < 0 or index >= numItems){
        throw std::range_error("index (" + to_string(index) + ") not in range" 
        + " [0.." + to_string(numItems) + ")");
    }

    removeAt(index);
    insertAt(c, index);
}


/*
 * name:      void popFromFront()
 * purpose:   remove first index
 * arguments: none
 * returns:   none
 * effects:   removes first element in linked list
 */
void CharLinkedList::popFromFront(){
    if (isEmpty()){
        throw std::runtime_error("cannot pop from empty LinkedList");
    }
    Node* curr = front;
    
    if(numItems == 1){
        delete curr;
        front = nullptr;    
        tail = nullptr;    // because nothing would be pointing to anything
    } else {   
        front = curr->next;
        front->prev = nullptr;
        delete curr;
    }
    numItems--;
}

/*
 * name:      void popFromBack()
 * purpose:   remove last index
 * arguments: none
 * returns:   none
 * effects:   removes last element in linked list
 */
void CharLinkedList::popFromBack(){
    if (isEmpty()){
        throw std::runtime_error("cannot pop from empty LinkedList");
    }
    Node* curr = tail;

    if(numItems == 1){
        popFromFront();
    } else{
        tail = curr->prev;
        tail->next = nullptr;
        numItems--;
        delete curr;
    }
}

/*
 * name:      void concatenate(CharLinkedList *other)
 * purpose:   combines two linked list elements together 
 * arguments: a pointer to another CharLinkedList object 
 * returns:   none
 * effects:   adds the elements of another linked list to the first instance
 *            linked list
 */
void CharLinkedList::concatenate(CharLinkedList* other){
    
    Node* curr = other->front;
    int origSize = other->size();
    for (int i = 0; i < origSize; i++){
        pushAtBack(curr->data);
        curr = curr->next;
    }
}




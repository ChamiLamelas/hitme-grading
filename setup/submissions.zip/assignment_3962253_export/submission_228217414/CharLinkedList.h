/*
 *  CharLinkedList.h
 *  Bryan Cho
 *  1/30/2023
 *  Edited by Bryan Cho 2/6/2024
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Class declarations for the CharLinkedList class 
    A linked list is a data structure that links nodes in a linear system and
    within each node there is data that is stored. The CharLinkedClass has an
    instantenous access to the front and back and can efficiently and quickly
    remove and add elements at the front and back, but for elements in the 
    middle, accessing the element is is lackluster because it is very slow 
    due to the fact it needs to recurse through the entire list in order 
    to retrive an element in the middle of the list. 
 *
 */

#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H

#include <string>

class CharLinkedList {
        
    public:
        CharLinkedList(); // default constructor
        // constructor below takes in single character as a parameter
        // and creates one element array list consisting of that character
        CharLinkedList(char c);
        // // constructor takes an array of characters and the integer length
        // // of that array of characters as parameters, creating a list 
        // // containing the characters in the array
        CharLinkedList(char arr[], int size);
        // // constructor that makes a deep copy of a given instance
        CharLinkedList(const CharLinkedList &other); 
        // //destructor
        ~CharLinkedList();


        CharLinkedList &operator=(const CharLinkedList &other);

        bool isEmpty() const;
        void clear(); 
        int size() const;
        char first() const;
        char last() const;
        char elementAt(int index) const;

        std::string toString() const;
        std::string toReverseString() const;
        
        void pushAtBack(char c);
        void pushAtFront(char c);


        void insertAt(char c, int index);
        void insertInOrder(char c);
        void popFromFront();
        void popFromBack();
        void removeAt(int index);
        void replaceAt(char c, int index);
        void concatenate(CharLinkedList *other);

    private:
        struct Node{
            char data;
            Node* next;
            Node* prev;
        };

        Node* front;
        Node* tail;
        Node* newNode(char c, Node* next, Node* prev);
        int numItems; // size
        void recycleRecursive(Node* curr);
        Node* indexHelper(Node* curr, int index) const;

};

#endif

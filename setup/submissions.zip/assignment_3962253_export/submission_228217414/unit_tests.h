/*
 *  unit_tests.h
 *  Bryan Cho
 *  1/30/2023
 * Edited by Bryan Cho 2/6/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  test the functions in the CharLinkedList class 
 *
 */

#include "CharLinkedList.h"
#include <cassert>


/*
 * constructor test 0
 * Make sure no fatal errors/memory leaks in the constructor
 * for zero elements
 */
void constructor_test_0(){
    CharLinkedList list;
    assert(list.size() == 0);
}

/*
 * constructor test 1
 * Make sure no fatal errors/memory leaks in the constructor
 * for one element
 */
void constructor_test_1(){
    CharLinkedList list('a');
    assert(list.size() == 1);
}
/*
 * constructor test 2
 * Make sure no fatal errors/memory leaks in the constructor
 * copy constructor
 */
void constructor_test_2(){
    char arr[1] = {'a'};
    CharLinkedList list(arr, 1);
    assert(list.size() == 1);
}
/*
 * constructor test 3
 * Make sure no fatal errors/memory leaks in the  constructor
 * deep copy Linked List
 */
void constructor_test_3(){
    CharLinkedList list('a');
    CharLinkedList list1(list);
    assert(list1.size()==list.size());
    assert(list.toString() == list1.toString());
}

/*
* constructor test 4
* tests both the copy constructor and deep copy LinkedList
*/
void constructor_test_4(){
    char arr[7] = {'b','e','i','h','w','q','v'};
    CharLinkedList list(arr,7);
    CharLinkedList list2(list);
    assert(list.toString() == list2.toString());
}

//test constructor for deep copy
void constructor_test_5(){
    char arr[7] = {'a','b','c','d','e','f','g'};
    CharLinkedList list(arr,7);
    CharLinkedList list2(list);
    list.clear();
    assert(list.toString() != list2.toString());
}

//test for overload operator for empty linked list
void overloadOperator_test(){
    char arr[3] = {'a','b','c'};
    CharLinkedList list(arr,3);
    CharLinkedList list2;
    list2 = list;
    assert(list2.toString() == list.toString());
}

// test for overload operator for two multielemental linked list
void overloadOperator_test_2(){
    char arr[3] = {'a','b','c'};
    char arr2[2] = {'a','b'};
    CharLinkedList list(arr,3);
    CharLinkedList list2(arr2,2);
    list2 = list;
    assert(list.toString() == list2.toString());
}

// if first instance list was empty
void overloadOperator_test_3(){
    char arr2[2] = {'a','b'};
    CharLinkedList list;
    CharLinkedList list2(arr2,2);
    list2 = list;
    assert(list.toString() == list2.toString());
}

// tests if isEmpty should be true
void isEmpty_true(){
    CharLinkedList list;
    assert(list.isEmpty());
}

// tests if isEmpty should be false
void isEmpty_false(){
    CharLinkedList list('a');
    assert(not list.isEmpty());
}

//isEmpty after multiple other functions                     
void isEmpty_afterCalls(){
    char arr[3] = {'a','b','c'};
    CharLinkedList list(arr,3);
    list.removeAt(2);
    list.insertInOrder('d');
    list.popFromBack();
    list.popFromBack();
    list.popFromBack();
    assert(list.size() == 0);
    assert(list.isEmpty());
}

// test for an empty array implemented for constructor
void empty_array_1(){;
    char arr[0];
    CharLinkedList list(arr,0);
    list.insertInOrder('a');
    assert(list.first() == 'a');
    assert(list.size() == 1);
}

//tests if first works in one element linked list
void first(){
    CharLinkedList list('a');
    assert(list.first() == 'a');
}
//tests if first works in mult-element linked list
void first_2nd(){
    char arr[5] = {'a','b','c'};
    CharLinkedList list(arr, 3);
    assert(list.first() == 'a');
}

// tests if first should fail 
void first_fail(){
    CharLinkedList list;
    std::string message = "";
    bool test = true;
    try {
        list.first();
    }
    catch (std::runtime_error& error){
        test = false;
        message = error.what();
    }
    assert(not test);
    assert(list.size() == 0);
    assert(message == "cannot get first of empty LinkedList");
}

// test if last works in a multielement linked list
void last(){
    char arr[3] = {'a','b','c'};
    CharLinkedList list(arr, 3);
    assert(list.last() == 'c');
}
//tests if last should fail
void last_fail(){
    CharLinkedList list;
    bool test = true;
    std::string message = "";
    try {
        list.last();
    }
    catch (std::runtime_error& error){
        test = false;
        message = error.what();
    }
    assert(not test);
    assert(list.size() == 0);
    assert(message == "cannot get last of empty LinkedList");
}

// tests if clear works 
void clear(){
    char arr[3] = {'d','g','h'}; 
    CharLinkedList list(arr,3);
    list.clear();
    assert(list.size() == 0);
    assert(list.isEmpty());
}

// tests if clear works as intended
void clear_1(){
    char arr[3] = {'a','b','c'};
    CharLinkedList list(arr,3);
    list.clear();
    assert(list.size() == 0);
    assert(list.isEmpty());
}

// clear and print out linked list
void clear_2(){
    char arr[3] = {'a','b','c'};
    CharLinkedList list(arr,3);
    list.clear();
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}


//test for everything just randomly lol 
// don't have to grade
void justtest(){
    char arr[4] = {'a','b','c','d'};
    CharLinkedList list(arr,4);
    list.insertAt('b',1);
    list.insertAt('c',3);
    list.insertInOrder('z');
    assert(list.toString() == "[CharLinkedList of size 7 <<abbccdz>>]");
}

//test for everything but again randomy, don't grade
void justtest_2(){
    char arr[4] = {'a','c','d','e'};
    CharLinkedList list(arr,4);
    CharLinkedList list1;
    list.pushAtFront('a');
    assert(list.first() == 'a');
    assert(list.last() == 'e');
    std::string message = "";
    try {
        list.popFromFront();
    } catch(std::runtime_error& error){
        message = error.what();
    }
    list1.concatenate(&list);
    
}

// tests if elementAt works for capturing an element in the middle
void elementAt(){
    char arr[3] = {'d','g','h'}; 
    CharLinkedList list(arr,3);
    assert(list.elementAt(1) == 'g');
}

// tests elementAt in a single element linked list
void elementAt_2(){
    CharLinkedList list;
    list.pushAtBack('a');
    assert(list.elementAt(0) == 'a');
}

//test first element
void elementAt_1(){
    char arr[4] = {'d','g','h','a'}; 
    CharLinkedList list(arr,4);
    assert(list.elementAt(0) == 'd');
}

// tests if elementAt should fail
void elementAt_fail(){ 
    char arr[3] = {'a','b','c'}; 
    CharLinkedList list(arr,3);
    list.pushAtFront('a');
    std::string message = "";
    bool test = false;
    try {
        list.elementAt(5);
    }
    catch(std::runtime_error& error) {
        test = true;
        message = error.what();
    }
    assert(test);
    assert(message == "index (5) not in range [0..4)" );
}



//tests if toString works as intended and prints correct characters 
void toString_test(){
    char arr[3] = {'a','b','c'};
    CharLinkedList list(arr,3);
    std::string result = list.toString();
    std::string result2 = "[CharLinkedList of size " + std::to_string(3)
                     + " <<abc>>]";
    assert(result==result2);
}

//empty toString check
void toString_empty(){
    CharLinkedList list;
    std::string result = list.toString();
    std::string result2 = "[CharLinkedList of size 0 <<>>]";
    assert(result == result2);
}


// tests if toReverseString works as intended printers correct characters
// in reverse order
void toReverseString_test(){
    char arr[5] = {'A','l','i','c','e'};
    CharLinkedList list(arr,5);
    std::string result = list.toReverseString();
    std::string result2 = "[CharLinkedList of size " + std::to_string(5)
                     + " <<ecilA>>]";
    assert(result==result2);
}

// toReverseString in empty linked list
void toReverseString_empty(){
    CharLinkedList list;
    std::string result = "[CharLinkedList of size " + std::to_string(0)
                     + " <<>>]";
    assert(list.toString() == result);
}

//tests if pushAtBack works with multielement functions
void pushAtBack_test(){
    char arr[3] = {'a','b','c'};
    CharLinkedList list(arr,3);
    list.pushAtBack('d');
    
    assert(list.last() == 'd');
}


//tests if pushAtBack works as intended in size 
void pushAtBack_2 () {
    CharLinkedList list('a');
    list.pushAtBack('a');
    list.pushAtBack('a');
    assert(list.size() == 3);
    assert(list.elementAt(2) == 'a');
}


//push at back if empty 
void pushAtBack_3_empty(){
    CharLinkedList list;
    list.pushAtBack('a');
    assert(not list.isEmpty());
    assert(list.first() == 'a');
    assert(list.size() == 1);
}

// tests if pushAtFront works as intended in multielement linked list
void pushAtFront_test(){
    char arr[3] = {'b','c','d'};
    CharLinkedList list(arr,3);
    list.pushAtFront('a');
    std::string result = "[CharLinkedList of size 4 <<abcd>>]";
    assert(list.first() == 'a');
    assert(list.toString() == result);
}

// // checks if pushAtFront works as intended in size
void pushAtFront_2 () {
    CharLinkedList list('a');
    list.pushAtFront('a');
    list.pushAtFront('a');
    assert(list.size() == 3);
}
//pushAtFront in an empty Linkedlist
void pushAtFront_3(){
    CharLinkedList list;
    list.pushAtFront('a');
    assert(list.size() == 1);
    assert(list.elementAt(0) == 'a');
}

void insertInOrderRandom(){
    char arr[4] = {'a','d','g','h'}; 
    CharLinkedList list(arr,4);
    CharLinkedList list1('z');
    list.insertInOrder('d');
    assert(list.toString() == "[CharLinkedList of size 5 <<addgh>>]");
}

//triple repeat 
void insertInOrder_1(){
    char arr[6] = {'a','a','b','c','d','e'};
    CharLinkedList list(arr,6);
    list.insertInOrder('a');
    std::string result = "[CharLinkedList of size 7 <<aaabcde>>]";
    assert(list.toString() == result);
}

//inserted in first element in multielemental
void insertInOrder_first_letter(){
    char arr[3] = {'b','c','d'};
    CharLinkedList list(arr,3);
    list.insertInOrder('a');
    assert(list.first() == 'a');
}

//inserted in last element in multielemental
void insertInOrder_back_letter(){
    char arr[3] = {'b','c','d'};
    CharLinkedList list(arr,3);
    list.insertInOrder('d');
    assert(list.last() == 'd');
    assert(list.size() == 4);
}

//inserted somehwere in the middle in multielemental
void insertInOrder_middle_letter(){
    char arr[3] = {'a','h','z'};
    CharLinkedList list(arr,3);
    list.insertInOrder('i');
    assert(list.elementAt(2) == 'i');
}

// insert in order first letter again in multielemental
void insertInOrder_firstletter_2(){
    char arr[3] = {'Z','E','D'};
    CharLinkedList list(arr,3);
    list.insertInOrder('A');
    assert(list.first() == 'A');
}

//inserted somewhere in the middle
void insertInOrder_middle_letter2(){
    char arr[8] = {'a','c','f','g','h','l','p','z'};
    CharLinkedList list(arr,8);
    list.insertInOrder('n');
    assert(list.elementAt(6) == 'n');
}

//inserted in the middle in front of same letter
void insertInOrder_tie_1(){
    char arr[8] = {'a','c','f','g','h','l','p','z'};
    CharLinkedList list(arr,8);
    list.insertInOrder('l');
    assert(list.elementAt(6) == 'l');
}

//inserted in the middle behind of same letter
void insertInOrder_tie_2(){
    char arr[8] = {'a','c','f','g','h','l','p','z'};
    CharLinkedList list(arr,8);
    list.insertInOrder('l');
    assert(list.elementAt(6) == 'l');
}

//inserted in the middle between two same letter
void insertInOrder_tie_3(){
    char arr[8] = {'a','c','f','g','h','p','p','z'};
    CharLinkedList list(arr,8);
    list.insertInOrder('p');
    assert(list.elementAt(5) == 'p');
    assert(list.elementAt(6) == 'p');
    assert(list.elementAt(7) == 'p');
}

// last element check 
void insertInOrder_last(){
    char arr[3] = {'a','b','c'};
    CharLinkedList list(arr,3);
    list.insertInOrder('z');
    assert(list.last() == 'z');
}

// insert in order in an empty linked list
void insertInOrder_empty(){
    CharLinkedList list;
    list.insertInOrder('a');
    assert(list.size() == 1);
}

//checks if remove at first index
void removeAt_1(){
    char arr[8] = {'a','b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList list(arr,8);
    list.removeAt(0);
    assert(list.first() == 'b');
    assert(list.size() == 7);
    assert(list.elementAt(3) == 'e');
}

//checks if remove at middle 
void removeAt_middle(){
    char arr[8] = {'a','b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList list(arr,8);
    list.removeAt(3);
    std::string result = "[CharLinkedList of size 7 <<abcefgh>>]";
    assert(list.elementAt(3) == 'e');
    assert(list.size() == 7);
    assert(list.toString() == result); 
}

//double check for remove at middle multiple iterations
void removeAt_middle2(){
    char arr[8] = {'a','b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList list(arr,8);
    list.removeAt(5);
    list.removeAt(6);
    list.removeAt(0);
    assert(list.toString() == "[CharLinkedList of size 5 <<bcdeg>>]");
}

// //checks if remove at end
void removeAt_end(){
    char arr[8] = {'a','b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList list(arr,8);
    list.removeAt(7);
    std::string result = "[CharLinkedList of size 7 <<abcdefg>>]";
    assert(list.toString() == result);
}

// removeAt test if index is out of bounds
void removeAt_fail(){
    char arr[3] = {'a','b','c'};
    CharLinkedList list(arr,3);
    bool test = false;
    std::string message = "";
    try {
        list.removeAt(50);
    }
    catch (std::range_error& error){
        test = true;
        message = error.what();
    }
    assert(test);
    assert(message == "index (50) not in range [0..3)");
}

// removeAt in an empty linked list
void removeAt_empty(){
    CharLinkedList list;
    std::string message = "";
    try {
        list.removeAt(0);
    } catch(std::range_error& error){
        message = error.what();
    }
    assert(message == "index (0) not in range [0..0)");
}

// removeAt test if index is out of bounds, again
void removeAt_fail_2(){
    char arr[3] = {'a','b','c'};
    CharLinkedList list(arr,3);
    std::string message = "";
    bool test = false;
    try {
        list.removeAt(3);
    }
    catch (std::range_error& error){
        test = true;
        message = error.what();
    }
    assert(test);
    assert(message == "index (3) not in range [0..3)");
}

//single element remove at
void removeAt_single(){
    CharLinkedList list('a');
    list.removeAt(0);
    assert(list.size() == 0);
}


// popFromFront if it works in multielemental linked list
void popFromFront_success(){
    char arr[3] = {'a','b','c'};
    CharLinkedList list(arr,3);
    list.popFromFront();
    assert(list.size() == 2);
    assert(list.first() == 'b');
}

//popFromFront after clear
void popFromFront_clear(){
    CharLinkedList list('a');
    list.clear();
    list.insertAt('a', 0);
    list.popFromFront();
    assert(list.size() == 0);

}

//popFromFront in one element linked list
void popfromFront_one(){
    CharLinkedList list('a');
    list.popFromFront();
    assert(list.size() == 0);
}


// popFromFront in an empty linked list
void popFromFront_2(){
    bool test = false;
    std::string message = "";
    CharLinkedList list;
    try {
        list.popFromFront();
    } catch(std::runtime_error& error){
        test = true;
        message = error.what();
    }
    assert(list.size() == 0);
    assert(test);
    assert(message == "cannot pop from empty LinkedList");
}
// popFromBack if it works
void popFromBack_success(){
    char arr[3] = {'a','b','c'};
    CharLinkedList list(arr,3);
    list.popFromBack();
    assert(list.size() == 2);
    assert(list.last() == 'b');
}
//popFromBack in a one letter linked list (failure)
void popFromBack_2(){
    bool test = false;
    char arr[1] = {'a'};
    std::string message = "";
    CharLinkedList list(arr,1);
    list.popFromBack();
    try {
        list.popFromBack();
    } catch(std::runtime_error& error){
        test = true;
        message = error.what();
    }
    assert(list.size() == 0);
    assert(test);
    assert(message == "cannot pop from empty LinkedList");
}

//popFromBack in one element linked list
void popFromBack_1(){
    CharLinkedList list('a');
    list.popFromBack();
    assert(list.size() == 0);

}

//popFromBack in an empty linked list
void popFromBack_fail(){
    bool test = false;
    CharLinkedList list;
    std::string message = "";
    try{
        list.popFromBack();
    } catch(std::runtime_error &error){
        test = true;
        message = error.what();
    }
    assert(test);
    assert(message == "cannot pop from empty LinkedList");
}

// ---------------------------------------------------------------

// checks replaceAt works correctly multielemental
void replaceAt_success(){
    char arr[3] = {'a','b','c'};
    CharLinkedList list(arr,3);
    list.replaceAt('h', 1);
    assert(list.size() == 3);
    assert(list.elementAt(1) == 'h');
}
//checks to see if it works correctly again
void replaceAt_success2(){
    char arr[3] = {'a','b','c'};
    CharLinkedList list(arr,3);
    list.replaceAt('h', 0);
    assert(list.size() == 3);
    assert(list.elementAt(2) == 'c');
}
// replaceAt out of bounds error 3
void replaceAt_3(){
    char arr[3] = {'a','b','c'};
    CharLinkedList list(arr,3);
    bool test = false;
    std::string message = "";
    try{
        list.replaceAt('a',3);
    } catch (std::range_error error){
        test = true;
        message = error.what();
    }
    assert(test);
    assert(message == "index (3) not in range [0..3)");
}

//replaceAt out of bounds error 2
void replaceAt_fail(){
    bool test = false;
    std::string message = "";
    char arr[3] = {'a','b','c'};
    CharLinkedList list(arr,3);
    try{
        list.replaceAt('h',10);
    } catch(std::range_error &error){
        test = true;
        message = error.what();
    }
    assert(test);
    assert(message == "index (10) not in range [0..3)");
}

// replaceAt function in a single element LinkedList
void replaceAt_single(){
    CharLinkedList list('a');
    list.replaceAt('b',0);
    assert(list.size() == 1);
    assert(list.elementAt(0) == 'b');
}

// replaceAt function at end of element
void replaceAt_end(){
    char arr[3] = {'a','b','c'};
    CharLinkedList list(arr,3);
    list.replaceAt('b',2);
    std::string result = "[CharLinkedList of size 3 <<abb>>]";
    assert(list.toString() == result);
}

//test if size and string prints out properly in multielemental linked list
void concatenateTest_1(){
    char arr[3] = {'a','b','c'};
    CharLinkedList list(arr,3);
    CharLinkedList list2(arr,3);
    list.concatenate(&list2);
    std::string result;
    for (int i = 0; i < list.size(); i++){
        result += list.elementAt(i);
    }
    assert(list.size() == 6);
    assert(result == "abcabc");
}

//test if size and string prints out properly in one multielemental linked
// linked list and one empty linked list
void concatenateTest_2(){
    char arr[3] = {'a','b','c'};
    CharLinkedList list(arr,3);
    CharLinkedList list2;
    list.concatenate(&list2);
    std::string result;
    for (int i = 0; i < list.size(); i++){
        result += list.elementAt(i);
    }
    assert(list.size() == 3);
    assert(result == "abc");

}
//one multivariable list and single variable Linked list test
void concatenateTest_3(){
    char arr[3] = {'a','b','c'};
    CharLinkedList list(arr,3);
    CharLinkedList list2('a');
    list.concatenate(&list2);
    std::string result;
    for (int i = 0; i < list.size(); i++){
        result += list.elementAt(i);
    }
    assert(list.size() == 4);
    assert(result == "abca");
}
// two empty variable linked list
void concatenateTest_4(){
    CharLinkedList list;
    CharLinkedList list2;
    list.concatenate(&list2);
    std::string result;
    for (int i = 0; i < list.size(); i++){
        result += list.elementAt(i);
    }
    assert(list.size() == 0);
    assert(result == "");
}

// checks if it concatenates from an empty linked list to a 
// multielemental linked list
void concatenateTest_5(){
    CharLinkedList list;
    char arr[12] = {'a','b','c','d','a','b','c','d','a','b','c','d'};
    CharLinkedList list2(arr,12);
    list.concatenate(&list2);
    std::string result;
    for (int i = 0; i < list.size(); i++){
        result += list.elementAt(i);
    }  

    assert(list.size() == 12);
    assert(result == "abcdabcdabcd");
}

//concatenates on itself
void concatenateTest_6(){
    char arr[3] = {'a','b','c'};
    CharLinkedList list(arr,3);
    list.concatenate(&list);
    assert(list.toString() == "[CharLinkedList of size 6 <<abcabc>>]");
}

//Tests correct insertion into an empty AL.
//Afterwards, size should be 1 and element at index 0
//should be the element we inserted.
void insertAt_empty_correct() { 

    CharLinkedList test_list;
    test_list.insertAt('a', 0);
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');

}

// Tests incorrect insertion into an empty AL.
// Attempts to call insertAt for index larger than 0.
// This should result in an std::range_error being raised.
void insertAt_empty_incorrect() {

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    // insertAt for out-of-range index
    test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
    // if insertAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    range_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0]");
    
}

// Tests correct insertAt for front of 1-element list.
void insertAt_front_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at front
    test_list.insertAt('b', 0);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'a');
    
}

// Tests correct insertAt for back of 1-element list.
void insertAt_back_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at back
    test_list.insertAt('b', 1);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    
}

// Tests calling insertAt for a large number of elements.
void insertAt_many_elements() {
    
    CharLinkedList test_list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.insertAt('a', i);
    }
    assert(test_list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
    
}



// Tests insertion into front of a larger list
void insertAt_front_large_list() {
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    test_list.insertAt('y', 0);

    assert(test_list.size() == 10);
    assert(test_list.elementAt(0) == 'y');
    assert(test_list.toString() ==
    "[CharLinkedList of size 10 <<yabczdefgh>>]");

}

// Tests insertion into the back of a larger list
void insertAt_back_large_list() {

    char test_arr[10] = { 'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 10);  

    test_list.insertAt('x', 10);

    assert(test_list.size() == 11);
    assert(test_list.elementAt(10) == 'x');
    assert(test_list.toString() == 
    "[CharLinkedList of size 11 <<yabczdefghx>>]"); 

}

// Tests insertion into the middle of a larger list
void insertAt_middle_large_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.insertAt('z', 3);

    assert(test_list.size() == 9);
    assert(test_list.elementAt(3) == 'z');
    assert(test_list.toString() == "[CharLinkedList of size 9 <<abczdefgh>>]");

}



// Tests out-of-range insertion for a non-empty list.
void insertAt_nonempty_incorrect() {
   
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8]");
    
}


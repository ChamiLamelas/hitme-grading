/*
 *  unit_tests.h
 *  Name: Hannah Friedlander
 *  Date: 2/2/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  Purpose: Unit tests for CharLinkedList class. Contains tests for each
 *           individual method, along with tests that make sure methods
 *           function properly when called together.
 *
 */

#include "CharLinkedList.h"
#include <cassert>


/*
 * constructor test 0
 * Make sure no fatal errors/memory leaks in the default constructor
 */
void first_construct_memory_test() {
    CharLinkedList test_list;
}

/*
 * constructor variable test
 * Make sure no items exist in the list upon construction
 */
void first_construct_variable_test() {
    CharLinkedList test_list; // One way to invoke the default constructor.
    assert(test_list.size() == 0);
}

/*
 * second constructor memory test
 * Make sure no fatal errors/memory leaks in the second constructor
 */
void second_construct_memory_test() {
    // creates an instance with one element in it
    CharLinkedList test_list('c');
}

/*
 * second constructor first test
 * Make sure correct items are initilized in the list
 */
void second_construct_variable_test() {
    CharLinkedList test_list('a');

    // check linked list is correct
    assert(test_list.size() == 1);
    assert(test_list.toString() == "[CharLinkedList of size 1 <<a>>]");
}

// third constructor memory test
// Make sure no fatal errors/memory leaks in the third constructor
void third_construct_memory_test() {
    char arr_test[3] = {'b', 'a', 'g'};
    CharLinkedList test_list(arr_test, 3);
}


// third constructor variable test
// Make sure correct items are initilized in the list
void third_construct_variable_test() {
    char arr_test[7] = {'a', 'b', 'c', 'd', 'e', 'f', 'g'};
    CharLinkedList test_list(arr_test, 7);
    assert(test_list.size() == 7);
    assert(test_list.toString() == "[CharLinkedList of size 7 <<abcdefg>>]");
}

// overloaded assignment operator memory test
// Make sure no fatal errors/memory leaks in the assignment operator
void assignment_operator_memory_test() {
    // create copied instance
    CharLinkedList copied_test;
    // create orignal instance
    CharLinkedList original_test;

    // call overloaded assignment operator
    original_test = copied_test;

    // check contents
    assert(original_test.toString() == "[CharLinkedList of size 0 <<>>]");
}

// overloaded assignment operator same size test
// Make sure copying works correctly in the assignment operator, even when 
// sizes are different
void assignment_operator_same_size() {
    // create copied instance
    char arr_test_c[3] = {'c', 'a', 't'};
    CharLinkedList copied_test(arr_test_c, 3);
    // create orignal instance
    char arr_test_o[3] = {'b', 'a', 'g'};
    CharLinkedList original_test(arr_test_o, 3);

    // call overloaded assignment operator
    original_test = copied_test;

    // check size
    assert(original_test.size() == 3);

    // check contents
    assert(original_test.toString() == "[CharLinkedList of size 3 <<cat>>]");
}

// overloaded assignment operator diff size test
// Make sure copying works correctly in the assignment operator, even when 
// sizes are different
void assignment_operator_diff_size() {
    // create copied instance
    char arr_test_c[3] = {'b', 'a', 'g'};
    CharLinkedList copied_test(arr_test_c, 3);
    // create orignal instance
    char arr_test_o[5] = {'h', 'a', 'p', 'p', 'y'};
    CharLinkedList original_test(arr_test_o, 5);

    // call overloaded assignment operator
    original_test = copied_test;

    // check size
    assert(original_test.size() == 3);

    // check contents
    assert(original_test.toString() == "[CharLinkedList of size 3 <<bag>>]");
}

// overloaded assignment operator operations test
// Make sure other operations in the linked list class still work 
void assignment_operator_operations() {
    // create copied instance
    char arr_test_c[3] = {'b', 'a', 'g'};
    CharLinkedList copied_test(arr_test_c, 3);
    // create orignal instance
    char arr_test_o[5] = {'h', 'a', 'p', 'p', 'y'};
    CharLinkedList original_test(arr_test_o, 5);

    // call overloaded assignment operator
    original_test = copied_test;

    // check size
    assert(original_test.size() == 3);

    // check contents
    assert(original_test.toString() == "[CharLinkedList of size 3 <<bag>>]");

    original_test.pushAtBack('t');

    assert(original_test.toString() == "[CharLinkedList of size 4 <<bagt>>]");
    assert(original_test.toReverseString() == 
                                        "[CharLinkedList of size 4 <<tgab>>]");

}

// copy constructor memory test
// Make sure no fatal errors/memory leaks in the copy constructor
void copy_constructor_memory_test() {
    CharLinkedList copied_test;
    // create instance
    CharLinkedList original_test(copied_test);

    assert(original_test.toString() == "[CharLinkedList of size 0 <<>>]");
}

// copy constructor variable test
// Make sure no fatal errors/memory leaks in the copy constructor
void copy_constructor_variable_test() {
    // create first instance
    char arr_test[3] = {'b', 'a', 'g'};
    CharLinkedList copied_test(arr_test, 3);
    // create instance
    CharLinkedList original_test(copied_test);

    // check size
    assert(original_test.size() == 3);

    // check contents
    assert(original_test.toString() == "[CharLinkedList of size 3 <<bag>>]");
}

// copy constructor operations test
// Make sure other operations in the linked list class still work 
void copy_constructor_operations() {
    // create first instance
    char arr_test[3] = {'b', 'a', 'g'};
    CharLinkedList copied_test(arr_test, 3);
    // create instance
    CharLinkedList original_test(copied_test);

    // check size
    assert(original_test.size() == 3);

    // check contents
    assert(original_test.toString() == "[CharLinkedList of size 3 <<bag>>]");

    original_test.pushAtBack('t');

    assert(original_test.toString() == "[CharLinkedList of size 4 <<bagt>>]");
    assert(original_test.toReverseString() == 
                                        "[CharLinkedList of size 4 <<tgab>>]");
}

// isEmpty true test
// Make sure isEmpty returns true when the linked list is empty and size is 0
void isEmpty_true() {
    CharLinkedList test_list;
    assert(test_list.isEmpty());
    assert(test_list.size() == 0);
}

// isEmpty false test
// Make sure isEmpty returns false when the size isn't zero
void isEmpty_false() {
    char arr_test[3] = {'b', 'a', 'g'};
    CharLinkedList test_list(arr_test, 3);
    assert(not test_list.isEmpty());
    assert(test_list.size() != 0);
}

// isEmpty singleton test
// Make sure isEmpty returns false when the size isn't zero
void isEmpty_singleton_list() {
    char arr_test[1] = {'b'};
    CharLinkedList test_list(arr_test, 1);
    assert(not test_list.isEmpty());
    assert(test_list.size() != 0);
}

// clear_empty test
// Make sure clear works and that isEmpty returns true afterwards on linked 
// list intially empty
void clear_empty(){
    CharLinkedList test_list;
    assert(test_list.isEmpty());
}

// clear_many_elements test
// Make sure clear works and that isEmpty returns true afterwards on linked 
// list with 1 element initially
void clear_singleton_list(){
    char arr_test[1] = {'b'};
    CharLinkedList test_list(arr_test, 1);
    test_list.clear();
    assert(test_list.isEmpty());
}


// clear_large_list test
// Make sure clear works and that isEmpty returns true afterwards on linked 
// list with many elements initially
void clear_large_list(){
    char arr_test[7] = {'a', 'b', 'c', 'd', 'e', 'f', 'g'};
    CharLinkedList test_list(arr_test, 7);
    test_list.clear();
    assert(test_list.isEmpty());
}

// clear_large_insertAt test
// Make sure clear works and that isEmpty returns true afterwards on linked 
// list with many elements initially
void clear_large_insertAt(){
    char arr_test[7] = {'a', 'b', 'c', 'd', 'e', 'f', 'g'};
    CharLinkedList test_list(arr_test, 7);
    test_list.clear();
    assert(test_list.isEmpty());
}

// first_empty
// Make sure error is thrown when the linked list is originally empty and the 
// first element is being accessed
void first_empty(){
    bool runtime_error_thrown = false;
    try {
        CharLinkedList test_list;
        test_list.first();
    } 
    catch (runtime_error){
        runtime_error_thrown = true;
    }  
    assert(runtime_error_thrown);
}

// first_cleared_empty
// Make sure error is thrown when the linked list, originally not empty, is
// cleared and then the first element is accessed
void first_cleared_empty(){
    bool runtime_error_thrown = false;
    try {
        char arr_test[4] = {'b', 'a', 'g', 's'};
        CharLinkedList test_list(arr_test, 4);
        test_list.clear();
        test_list.first();
    } 
    catch (runtime_error){
        // make sure error is thrown
        runtime_error_thrown = true;
    }  
    assert(runtime_error_thrown);
}

// first_singleton_list
// Make sure that the correct first element is determined in a linked list
// with only one element
void first_singleton_list(){
    char arr_test[1] = {'b'};
    CharLinkedList test_list(arr_test, 1);
    assert(test_list.first() == 'b');
}

// first_large_list
// Make sure that the correct first element is determined in a linked list
// with many elements
void first_large_list(){
    char arr_test[5] = {'h', 'a', 'p', 'p', 'y'};
    CharLinkedList test_list(arr_test, 4);
    assert(test_list.first() == 'h');
}

// last_empty
// Make sure error is thrown when trying to access the last element of an 
// originally empty linked list
void last_empty(){
    bool runtime_error_thrown = false;
    try {
        CharLinkedList test_list;
        test_list.last();
    } 
    catch (runtime_error){
        // make sure error is thrown
        runtime_error_thrown = true;
    }  
    assert(runtime_error_thrown);
}

// last_cleared_empty
// Make sure error is thrown when the linked list, originally not empty, is
// cleared and then the last element is accessed
void last_cleared_empty(){
    bool runtime_error_thrown = false;
    try {
        char arr_test[4] = {'b', 'a', 'g', 's'};
        CharLinkedList test_list(arr_test, 4);
        test_list.clear();
        test_list.last();
    } 
    catch (runtime_error){
        runtime_error_thrown = true;
    }  
    assert(runtime_error_thrown);
}

// last_singleton_list
// Make sure that the correct last element is determined in a linked list
// with only one element
void last_singleton_list(){
    char arr_test[1] = {'h'};
    CharLinkedList test_list(arr_test, 1);
    assert(test_list.last() == 'h');
}


// last_large_list
// Make sure that the correct last element is determined in a linked list
// with many elements
void last_large_list(){
    char arr_test[5] = {'h', 'a', 'p', 'p', 'y'};
    CharLinkedList test_list(arr_test, 5);
    assert(test_list.last() == 'y');
}

// elementAt_first
// Make sure that the correct element is returned, this test being for the
// when the first element is wanted
void elementAt_first(){
    char arr_test[5] = {'h', 'a', 'p', 'p', 'y'};
    CharLinkedList test_list(arr_test, 5);
    assert(test_list.elementAt(0) == 'h');
}

// elementAt_last
// Make sure that the correct element is returned, this test being for the
// when the last element is wanted
void elementAt_last(){
    char arr_test[5] = {'h', 'a', 'p', 'p', 'y'};
    CharLinkedList test_list(arr_test, 5);
    assert(test_list.elementAt(4) == 'y');
}

// elementAt_middle
// Make sure that the correct element is returned, this test being for the
// when the char in one of the nodes somewhere in the middle of the linked 
// list is wanted
void elementAt_middle(){
    char arr_test[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList test_list(arr_test, 5);
    assert(test_list.elementAt(3) == 'd');
}

// elementAt_empty
// makes sure that error is thrown when the linked list is empty
void elementAt_empty(){
    bool range_error_thrown = false;
    string error_message = "";
    try {
        CharLinkedList test_list;
        assert(test_list.elementAt(3) == 'd');
    } 
    catch (const range_error &e){
        range_error_thrown = true;
        error_message = e.what();
    }  
    assert(range_error_thrown);
    assert(error_message == "index (3) not in range [0..0)");
}

// element_at_incorrect
// makes sure that error is thrown when the index chosen is out of range
void elementAt_incorrect(){
    bool range_error_thrown = false;
    string error_message = "";
    try {
        char arr_test[5] = {'a', 'b', 'c', 'd', 'e'};
        CharLinkedList test_list(arr_test, 5);
        assert(test_list.elementAt(7) == 'd');
    } 
    catch (const range_error &e){
        range_error_thrown = true;
        error_message = e.what();
    }  
    assert(range_error_thrown);
    assert(error_message == "index (7) not in range [0..5)");
}

// toString_empty
// Make sure that the correct string is created, checking for the both the 
// content and the size when the linked list is empty
void toString_empty(){
    CharLinkedList test_list;
    assert(test_list.toString() == "[CharLinkedList of size 0 <<>>]");
}

// toString_singleton_list
// Make sure that the correct string is created, checking for the both the 
// content and the size when the linked list has only one node
void toString_singleton_list(){
    char arr_test[1] = {'r'};
    CharLinkedList test_list(arr_test, 1);
    assert(test_list.size() == 1);
    assert(test_list.toString() == "[CharLinkedList of size 1 <<r>>]");
}

// toString_large_list
// Make sure that the correct string is created, checking for the both the 
// content and the size when the list has many nodes
void toString_large_list(){
    char arr_test[5] = {'A', 'l', 'i', 'c', 'e'};
    CharLinkedList test_list(arr_test, 5);
    assert(test_list.toString() == "[CharLinkedList of size 5 <<Alice>>]");
}

// toReverseString_empty
// Make sure that the correct string is created, checking for the both the 
// content and the size when the linked list is empty
void toReverseString_empty(){
    CharLinkedList test_list;
    //assert(test_list.toReverseString() == "[CharLinkedList of size 0 <<>>]");
    assert(test_list.isEmpty());
}

// toReverseString_singleton_list
// Make sure that the correct string is created, checking for the both the 
// content and the size when the word has one element
void toReverseString_singleton_list(){
    char arr_test[1] = {'e'};
    CharLinkedList test_list(arr_test, 1);
    assert(test_list.size() == 1);
    assert(test_list.toReverseString() == "[CharLinkedList of size 1 <<e>>]");
}

// toReverseString_large_list
// Make sure that the correct string is created, checking for the both the 
// content and the size when the word is Alice
void toReverseString_large_list(){
    char arr_test[5] = {'A', 'l', 'i', 'c', 'e'};
    CharLinkedList test(arr_test, 5);
    assert(test.toReverseString() == "[CharLinkedList of size 5 <<ecilA>>]");
}

// toReverseString_large_random
// Make sure that the correct string is created, checking for the both the 
// content and the size when the word has random characters
void toReverseString_large_random(){
    char arr_test[7] = {'A', 'l', 'i', '/', 'c', 'e', ' ',};
    CharLinkedList test(arr_test, 7);
    assert(test.toReverseString() == "[CharLinkedList of size 7 << ec/ilA>>]");
}

// pushAtBack_empty
// makes sure that element is correctly added to the back
// of linked list that was intially empty, ensure size was updated
void pushAtBack_empty(){
    CharLinkedList test_list;
    test_list.pushAtBack('q');
    assert(test_list.last() == 'q');
    assert(test_list.size() == 1);
}

// pushAtBack_singleton_list
// makes sure that element is correctly added to the back
// of string with size 1, checking updated size and concatenation
void pushAtBack_singleton_list(){
    char arr_test[1] = {'a'};
    CharLinkedList test_list(arr_test, 1);
    test_list.pushAtBack('e');
    assert(test_list.last() == 'e');
    assert(test_list.size() == 2);
    assert(test_list.toString() == "[CharLinkedList of size 2 <<ae>>]");
}

// pushAtBack_many_elements
// makes sure that element is correctly added to the back
// of linked list with original size bigger than 1
void pushAtBack_many_elements(){
    char arr_test[3] = {'e', 'f', 'g'};
    CharLinkedList test_list(arr_test, 3);
    for (int i = 0; i < 4; i ++){
        test_list.pushAtBack('h');
    }
    assert(test_list.last() == 'h');
    assert(test_list.size() == 7);
    assert(test_list.toString() == "[CharLinkedList of size 7 <<efghhhh>>]");
    
}

// pushAtBack_large_list
// test element is pushed correctly to back of a large list,
// making sure size is updated accurately and concatenation is right after
void pushAtBack_large_list(){
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(test_arr, 8);

    test_list.pushAtBack('z');

    assert(test_list.size() == 9);
    assert(test_list.last() == 'z');
    assert(test_list.toString() == "[CharLinkedList of size 9 <<abcdefghz>>]");
}

// pushAtFront_empty
// makes sure that element is correctly added to the front
// of linked list that was intially empty, ensure size was updated
void pushAtFront_empty(){
    CharLinkedList test_list;
    test_list.pushAtFront('r');
    assert(test_list.first() == 'r');
    assert(test_list.size() == 1);
}

// pushAtFront_singleton_list
// makes sure that element is correctly added to the front
// of string with size 1, checking updated size and concatenation
void pushAtFront_singleton_list(){
    char arr_test[1] = {'b'};
    CharLinkedList test_list(arr_test, 1);
    test_list.pushAtFront('d');
    assert(test_list.first() == 'd');
    assert(test_list.size() == 2);
    assert(test_list.toString() == "[CharLinkedList of size 2 <<db>>]");
}

// pushAtFront_many_elements
// makes sure that element is correctly added to the front
// of linked list with size bigger than 1
void pushAtFront_many_elements(){
    char arr_test[3] = {'a', 'b', 'c'};
    CharLinkedList test_list(arr_test, 3);
    for (int i = 0; i < 4; i ++){
        test_list.pushAtFront('a');
    }
    assert(test_list.first() == 'a');
    assert(test_list.size() == 7);
    assert(test_list.toString() == "[CharLinkedList of size 7 <<aaaaabc>>]");
    
}

// pushAtFront_large_list
// test element is pushed correctly to front of a large list,
// making sure size is updated accurately and concatenation is right after
void pushAtFront_large_list(){
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(test_arr, 8);

    test_list.pushAtFront('z');

    assert(test_list.size() == 9);
    assert(test_list.first() == 'z');
    assert(test_list.toString() == "[CharLinkedList of size 9 <<zabcdefgh>>]");
}

// insertAt_empty_correct
// Tests correct insertion into an empty AL.
// Afterwards, size should be 1 and element at index 0
// should be the element we inserted.
void insertAt_empty_correct() { 
    CharLinkedList test_list;
    test_list.insertAt('a', 0);
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');
}

// insertAt_empty_incorrect
// Tests incorrect insertion into an empty linked list.
// Attempts to call insertAt for index larger than 0.
// This should result in an std::range_error being raised.
void insertAt_empty_incorrect() {
    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    // insertAt for out-of-range index
    test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
    // if insertAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    range_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0]");
}

// insertAt_front_singleton_list
// Tests correct insertAt for front of 1-element list.
void insertAt_front_singleton_list() {
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at front
    test_list.insertAt('b', 0);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'a');
}

// insertAt_back_singleton_list
// Tests correct insertAt for back of 1-element list.
void insertAt_back_singleton_list() {
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at back
    test_list.insertAt('b', 1);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
}

// insertAt_many_elements
// Tests calling insertAt for a large number of elements.
void insertAt_many_elements() {
    CharLinkedList test_list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.insertAt('a', i);
    }

    assert(test_list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
}

// insertAt_front_large_list
// Tests insertion into front of a larger list
void insertAt_front_large_list() {
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    test_list.insertAt('y', 0);

    assert(test_list.size() == 10);
    assert(test_list.elementAt(0) == 'y');
    assert(test_list.toString() == 
                                "[CharLinkedList of size 10 <<yabczdefgh>>]");
}

// insertAt_back_large_list
// Tests insertion into the back of a larger list
void insertAt_back_large_list() {
    char test_arr[10] = { 'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 10);  

    test_list.insertAt('x', 10);

    assert(test_list.size() == 11);
    assert(test_list.elementAt(10) == 'x');
    assert(test_list.toString() == 
                                "[CharLinkedList of size 11 <<yabczdefghx>>]"); 
}

// insertAt_middle_large_list
// Tests insertion into the middle of a larger list
void insertAt_middle_large_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.insertAt('z', 3);

    assert(test_list.size() == 9);
    assert(test_list.elementAt(3) == 'z');
    assert(test_list.toString() == "[CharLinkedList of size 9 <<abczdefgh>>]");
}

// insertAt_nonempty_incorrect
// Tests out-of-range insertion for a non-empty list.
void insertAt_nonempty_incorrect() {

    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8]");
}

// insertInOrder_empty
// Tests inserting (in order) a char into an empty list, making sure size is
// updated
void insertInOrder_empty() { 
    CharLinkedList test_list;

    test_list.insertInOrder('q');

    assert(test_list.size() == 1);
    assert(test_list.toString() == "[CharLinkedList of size 1 <<q>>]");
}

// insertInOrder_singleton_front
// Tests inserting (in order) a char into a 1 element list, making sure size 
// is updated and it is inserted in the front
void insertInOrder_singleton_front() { 
    // initialize 1-element list
    CharLinkedList test_list('z');

    // replace first element
    test_list.insertInOrder('t');

    assert(test_list.size() == 2);
    assert(test_list.toString() == "[CharLinkedList of size 2 <<tz>>]");
}

// insertInOrder_singleton_back
// Tests inserting (in order) a char into a 1 element list, making sure size 
// isupdated and it is inserted in the back
void insertInOrder_singleton_back() { 
    // initialize 1-element list
    CharLinkedList test_list('d');

    // replace first element
    test_list.insertInOrder('j');

    assert(test_list.size() == 2);
    assert(test_list.toString() == "[CharLinkedList of size 2 <<dj>>]");
}

// insertInOrder_many_diff
// Tests calling insertInOrder for a multiple elements, all different
// makes sure size is updated and so are right indices
void insertInOrder_many_diff() {
    char test_arr[5] = { 'a', 'f', 'h', 'p', 't' };
    CharLinkedList test_list(test_arr, 5);
    
    test_list.insertInOrder('c');
    test_list.insertInOrder('z');
    test_list.insertInOrder('u');
    test_list.insertInOrder('d');

    assert(test_list.size() == 9);
    assert(test_list.toString() == "[CharLinkedList of size 9 <<acdfhptuz>>]");
}

// insertInOrder_many_same
// Tests calling insertInOrder for a multiple elements, all same
// makes sure size is updated and so are right indices
void insertInOrder_many_same() {
    char test_arr[5] = { 'a', 'f', 'h', 'p', 't' };
    CharLinkedList test_list(test_arr, 5);
    
    for (int i = 0; i < 4; i++){
        test_list.insertInOrder('c');
    }

    assert(test_list.size() == 9);
    assert(test_list.toString() == "[CharLinkedList of size 9 <<accccfhpt>>]");
}

// insertInOrder_front_large
// Tests calling insertInOrder to insert in the front of linked list
// makes sure size is updated and so is first index
void insertInOrder_front_large() {
    char test_arr[6] = { 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 6);

    test_list.insertInOrder('a');

    assert(test_list.size() == 7);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.toString() == "[CharLinkedList of size 7 <<acdefgh>>]");
}

// insertInOrder_back_large
// Tests calling insertInOrder to insert in the back of linked list
// makes sure size is updated and so is first index
void insertInOrder_back_large() {
     char test_arr[6] = { 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 6);

    test_list.insertInOrder('t');

    assert(test_list.size() == 7);
    assert(test_list.last() == 't');
    assert(test_list.toString() == "[CharLinkedList of size 7 <<cdefght>>]");
}

// insertInOrder_large_middle_diff
// Tests inserting an element in order into the middle of a large list that is
// different than all of the other elements
void insertInOrder_large_middle_diff() {
    // initialize list
    char test_arr[7] = {'a', 'b', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(test_arr, 7);

    // insert element
    test_list.insertInOrder('c');

    assert(test_list.size() == 8);
    assert(test_list.elementAt(2) == 'c');
    assert(test_list.toString() == "[CharLinkedList of size 8 <<abcdefgh>>]"); 
}

// insertInOrder_large_middle_same
// Tests inserting an element in list with multiple of the same elements,
// make sure size and index is updated
void insertInOrder_large_middle_same() {
    // initialize list
    char test_arr[7] = {'a', 'b', 'd', 'd', 'd', 'g', 'h'};
    CharLinkedList test_list(test_arr, 7);

    // insert element
    test_list.insertInOrder('d');

    assert(test_list.size() == 8);
    assert(test_list.elementAt(2) == 'd');
    assert(test_list.toString() == "[CharLinkedList of size 8 <<abddddgh>>]"); 
}

// insertInOrder_large_random_diff
// Tests inserting an element in list that is not actually in order, should
// still follow the same rules
void insertInOrder_large_random_diff() {
    // initialize list
    char test_arr[3] = {'z', 'e', 'd'};
    CharLinkedList test_list(test_arr, 3);

    // insert element
    test_list.insertInOrder('a');

    assert(test_list.size() == 4);
    assert(test_list.first() == 'a');
    assert(test_list.toString() == "[CharLinkedList of size 4 <<azed>>]"); 
}

// insertInOrder_large_random_same
// Tests inserting an element in list that is not actually in order, should
// still follow the same rules, also same element already found in original
// linked list
void insertInOrder_large_random_same() {
    // initialize list
    char test_arr[5] = {'c', 'd', 'e', 'a', 'f'};
    CharLinkedList test_list(test_arr, 5);

    // insert element
    test_list.insertInOrder('e');

    assert(test_list.size() == 6);
    assert(test_list.elementAt(2) == 'e');
    assert(test_list.toString() == "[CharLinkedList of size 6 <<cdeeaf>>]"); 
}

// insertInOrder_large_uppercase
// Tests inserting an element in list that has uppercase letters in it,
// making sure they still follow the ASCII values
void insertInOrder_large_uppercase() {
    // initialize list
    char test_arr[4] = {'c', 'd', 'e', 'f'};
    CharLinkedList test_list(test_arr, 4);

    // insert element
    test_list.insertInOrder('G');
    test_list.insertInOrder('F');

    assert(test_list.size() == 6);
    assert(test_list.first() == 'F');
    assert(test_list.toString() == "[CharLinkedList of size 6 <<FGcdef>>]"); 
}

// insertInOrder_large_symbols
// Tests inserting an element in list that random elements in it,
// making sure they still follow the ASCII values
void insertInOrder_large_symbols() {
    // initialize list
    char test_arr[4] = {'c', 'd', 'e', 'f'};
    CharLinkedList test_list(test_arr, 4);

    // insert element
    test_list.insertInOrder('{');
    test_list.insertInOrder('$');
    test_list.insertInOrder('0');
    test_list.insertInOrder('B');


    assert(test_list.size() == 8);
    assert(test_list.first() == '$');
    assert(test_list.last() == '{');
    assert(test_list.toString() == "[CharLinkedList of size 8 <<$0Bcdef{>>]");
    assert(test_list.toReverseString() == 
                                    "[CharLinkedList of size 8 <<{fedcB0$>>]");
}


// popFromFront_empty
// makes sure error is thrown when element is popped from the front
// of linked list that was intially empty
void popFromFront_empty(){
    // keep tracks of whether error happened or not
    bool exception = false;

    try {
        CharLinkedList test_list;
        test_list.popFromFront();
    } 
    catch (runtime_error){
        exception = true;
    }  
    assert(exception);
}

// popFromFront_singleton_list
// makes sure that element is correctly popped from the front
// of linked list that was intially had size 1
void popFromFront_singleton_list(){
    char arr_test[1] = {'b'};
    CharLinkedList test_list(arr_test, 1);
    test_list.popFromFront();
    assert(test_list.isEmpty());
}


// popFromFront_many_elements
// makes sure that multiple elements are correctly popped from the front
// of linked list with an initial size greater than 1
// checks size is decreased by right amoung and string is concatenated 
// correctly
void popFromFront_many_elements(){
    char arr_test[10] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j'};
    CharLinkedList test_list(arr_test, 10);
    for (int i = 0; i < 5; i ++){
        test_list.popFromFront();
    }
    assert(test_list.first() == 'f');
    assert(test_list.size() == 5);
    assert(test_list.toString() == "[CharLinkedList of size 5 <<fghij>>]");
}


// popFromFront_large_list
// test element is popped correctly from front of a large list,
// making sure size is updated accurately and concatenation is right after
void popFromFront_large_list(){
    char test_arr[9] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i'};
    CharLinkedList test_list(test_arr, 9);

    test_list.popFromFront();

    assert(test_list.size() == 8);
    assert(test_list.first() == 'b');
    assert(test_list.toString() == "[CharLinkedList of size 8 <<bcdefghi>>]");
    assert(test_list.toReverseString() == 
                                "[CharLinkedList of size 8 <<ihgfedcb>>]");
}

// popFromBack_empty
// makes sure error is thrown when element is popped from the back
// of linked list that was intially empty
void popFromBack_empty(){
    bool exception = false;
    try {
        CharLinkedList test_list;
        test_list.popFromBack();
    } 
    catch (runtime_error){
        exception = true;
    }  
    assert(exception);
}

// popFromBack_singleton_list
// makes sure that element is correctly popped from the back
// of linked list that was intially had size 1
void popFromBack_singleton_list(){
    char arr_test[1] = {'b'};
    CharLinkedList test_list(arr_test, 1);
    test_list.popFromBack();
    assert(test_list.isEmpty());
}


// popFromBack_many_elements
// makes sure that multiple elements are correctly popped from the back
// of linked list with an initial size greater than 1
// checks size is decreased by right amoung and string is concatenated 
// correctly
void popFromBack_many_elements(){
    char arr_test[10] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j'};
    CharLinkedList test_list(arr_test, 10);
    for (int i = 0; i < 5; i ++){
        test_list.popFromBack();
    }
    assert(test_list.last() == 'e');
    assert(test_list.size() == 5);
    assert(test_list.toString() == "[CharLinkedList of size 5 <<abcde>>]");
}


// popFromBack_large_list
// test element is popped correctly from back of a large list,
// making sure size is updated accurately and concatenation is right after
void popFromBack_large_list(){
    char test_arr[9] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i'};
    CharLinkedList test_list(test_arr, 9);

    test_list.popFromBack();

    assert(test_list.size() == 8);
    assert(test_list.last() == 'h');
    assert(test_list.toString() == "[CharLinkedList of size 8 <<abcdefgh>>]");
    assert(test_list.toReverseString() 
                                == "[CharLinkedList of size 8 <<hgfedcba>>]");
}

// concatenate_both_empty
// Tests concatenate() when both linked lists are empty, resulting in 
// an empty linked list
void concatenate_both_empty() {
    // initialize list
    CharLinkedList test_list;

    // create second empty instance
    CharLinkedList test_list_2;
    test_list.concatenate(&test_list_2);

    assert(test_list.size() == 0);
    assert(test_list.toString() == "[CharLinkedList of size 0 <<>>]"); 
}

// concatenate_first_empty
// Tests concatenate() when the first linked list is empty, which should
// essentially copy everything over from the second to the first
void concatenate_first_empty() {
    // initialize empty list
    CharLinkedList test_list;

    // initalize second linked list
    char second_arr[8] = {'c', 'h', 'e', 's', 'h', 'i', 'r', 'e'};
    CharLinkedList test_list_2(second_arr, 8);
    test_list.concatenate(&test_list_2);

    assert(test_list.size() == 8);
    assert(test_list.toString() == "[CharLinkedList of size 8 <<cheshire>>]"); 
}

// concatenate_second_empty
// Tests concatenate() when the second linked list is empty, which shouldn't
// change the first
void concatenate_second_empty() {
    // initialize list
    char test_arr[4] = {'a', 'b', 'c', 'd'};
    CharLinkedList test_list(test_arr, 4);

    CharLinkedList test_list_2;
    test_list.concatenate(&test_list_2);

    assert(test_list.size() == 4);
    assert(test_list.toString() == "[CharLinkedList of size 4 <<abcd>>]"); 
}

// concatenate_both_not_empty 
// Tests concatenate() on two linked lists that aren't empty
void concatenate_both_not_empty() {
    // initialize list
    char test_arr[2] = {'c', 'd'};
    CharLinkedList test_list(test_arr, 2);

    char second_arr[2] = {'e', 'f'};
    CharLinkedList test_list_2(second_arr, 2);
    test_list.concatenate(&test_list_2);

    assert(test_list.size() == 4);
    assert(test_list.toString() == "[CharLinkedList of size 4 <<cdef>>]"); 
}

// concatenate_itself
// Tests concatenate() on the same instance, resulting in the same contents
// repeated
void concatenate_itself() {
    // initialize list
    char test_arr[8] = {'C', 'H', 'E', 'S', 'H', 'I', 'R', 'E'};
    CharLinkedList test_list(test_arr, 8);

    test_list.concatenate(&test_list);

    // for breaking up code
    string result = "[CharLinkedList of size 16 <<CHESHIRECHESHIRE>>]"; 

    assert(test_list.size() == 16);
    assert(test_list.toString() == result); 
}

// removeAt_empty
// test correct removal of element from an linked list that was intially empty,
// should result in error
void removeAt_empty(){
    bool runtime_error_thrown = false;
    string error_message = "";
    try {
        CharLinkedList test_list;
        test_list.removeAt(2);
    } 
    catch (const range_error &e){
        runtime_error_thrown = true;
        error_message = e.what();
    }  
    assert(runtime_error_thrown);
    assert(error_message == "index (2) not in range [0..0)");
}

// removeAt_singleton_list
// test correct removal of element from an linked list that was intially size 1
void removeAt_singleton_list(){
    char arr_test[1] = {'w'};
    CharLinkedList test_list(arr_test, 1);
    test_list.removeAt(0);
    assert(test_list.isEmpty());
}

// removeAt_many_elements
// test correct removal of multiple elements from an linked list, checks size 
// and updated list
void removeAt_many_elements(){
    char arr_test[10] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j'};
    CharLinkedList test_list(arr_test, 10);
    for (int i = 0; i < 4; i ++){
        test_list.removeAt(3);
    }
    assert(test_list.elementAt(3) == 'h');
    assert(test_list.size() == 6);
}

// removeAt_front_large_list
// test correct removal of first element in large linked list, making sure
// size is updated and string is concatenated correctly
void removeAt_front_large_list(){
    char test_arr[9] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i'};
    CharLinkedList test_list(test_arr, 9);

    test_list.removeAt(0);

    assert(test_list.size() == 8);
    assert(test_list.first() == 'b');
    assert(test_list.toString() == "[CharLinkedList of size 8 <<bcdefghi>>]");
}

// removeAt_back_large_list
// test correct removal of last element in large linked list, making sure
// size is updated and string is concatenated correctly
void removeAt_back_large_list(){
    char test_arr[9] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i'};
    CharLinkedList test_list(test_arr, 9);

    test_list.removeAt(8);

    assert(test_list.size() == 8);
    assert(test_list.last() == 'h');
    assert(test_list.toString() == "[CharLinkedList of size 8 <<abcdefgh>>]");
}

// removeAt_middle_large_list
// test correct removal of middle element in large linked list, making sure
// size is updated and string is concatenated correctly
void removeAt_middle_large_list(){
    char test_arr[9] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i'};
    CharLinkedList test_list(test_arr, 9);

    test_list.removeAt(5);

    assert(test_list.size() == 8);
    assert(test_list.elementAt(5) == 'g');
    assert(test_list.toString() == "[CharLinkedList of size 8 <<abcdeghi>>]");
}

// removeAt_non_empty_incorrect
// test removal of an element that is out of range for a nonempty linked list,
// causing an error to be thrown
void removeAt_non_empty_incorrect(){
    bool runtime_error_thrown = false;
    string error_message = "";
    try {
        char test_arr[9] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i'};
        CharLinkedList test_list(test_arr, 9);
        test_list.removeAt(14);
    } 
    catch (const range_error &e){
        runtime_error_thrown = true;
        error_message = e.what();
    }  
    assert(runtime_error_thrown);
    assert(error_message == "index (14) not in range [0..9)");
}

// replaceAt_empty
// Tests replacement of 'a' into an empty list with no elements, resulting in
// an error
void replaceAt_empty() { 
    CharLinkedList test_list;

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.replaceAt('a', 1);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (1) not in range [0..0)");
}

// eplaceAt_singleton_list
// Tests correct replace At for 1-element list, making sure size stayed the
// same
void replaceAt_singleton_list() {
    // initialize 1-element list
    CharLinkedList test_list('a');

    // replace first element
    test_list.replaceAt('b', 0);

    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'b');
}

// replaceAt_many_elements
// Tests calling replaceAt for a large number of elements, making sure the 
// correct indices were updated 
void replaceAt_many_elements() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);
    
    for (int i = 3; i < 6; i ++){
        test_list.replaceAt('q', i);
    }
    assert(test_list.size() == 8);
    for (int i = 3; i < 6; i ++){
        assert(test_list.elementAt(i) == 'q');
    }
    assert(test_list.toString() == "[CharLinkedList of size 8 <<abcqqqgh>>]");
}

// replaceAt_front_large_list
// Tests calling replaceAt into front of a larger list
void replaceAt_front_large_list() {
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    test_list.replaceAt('y', 0);

    assert(test_list.elementAt(0) == 'y');
    assert(test_list.toString() == "[CharLinkedList of size 9 <<ybczdefgh>>]");
}

// replaceAt_back_large_list
// Tests calling replace in the back of a larger list
void replaceAt_back_large_list() {
    char test_arr[10] = { 'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 10);  

    test_list.replaceAt('x', 9);

    assert(test_list.elementAt(9) == 'x');
    assert(test_list.toString() == 
                              "[CharLinkedList of size 10 <<yabczdefgx>>]"); 
}

// replaceAt_middle_large_list
// Tests calling replace in the middle of a larger list
void replaceAt_middle_large_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(test_arr, 8);

    test_list.replaceAt('z', 3);

    assert(test_list.elementAt(3) == 'z');
    assert(test_list.toString() == "[CharLinkedList of size 8 <<abczefgh>>]");
}

// replaceAt_nonempty_incorrect
// Tests out-of-range replacement for a non-empty list.
void replaceAt_nonempty_incorrect() {
   
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.replaceAt('a', 17);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (17) not in range [0..8)");
}

// whole_test
// Tests multiple methods at once, making sure they all work together
void whole_test() {
    // initialize list
    char test_arr[4] = {'a', 'b', 'c', 'd'};
    CharLinkedList test_list(test_arr, 4);
    
    test_list.pushAtBack('g');
    test_list.popFromBack();
    test_list.clear();
    test_list.insertAt('t', 0);
    test_list.insertInOrder('h');
    test_list.popFromFront();
    test_list.removeAt(0);
    test_list.insertAt('g', 0);

    // create second instance
    char second_arr[2] = {'e', 'f'};
    CharLinkedList test_list_2(second_arr, 2);
    
    // call concatenate code
    test_list.concatenate(&test_list_2);

    // for breaking up code
    string toString_result = "[CharLinkedList of size 3 <<gef>>]";
    string toReverseString_result = "[CharLinkedList of size 3 <<feg>>]";

    // check results
    assert(test_list.size() == 3);
    assert(test_list.elementAt(1) == 'e');
    assert(test_list.first() == 'g');
    assert(test_list.last() == 'f');
    assert(test_list.toString() == toString_result); 
    assert(test_list.toReverseString() == toReverseString_result); 

}




// PRIVATE RECURSIVE HELPER TESTS 
// (the others are tested implicitly within the other unit tests)

// // findNode_singleton
// // makes sure helper function returns the right node with one node
// void findNode_singleton(){
//     char arr_test[1] = {'r'};
//     CharLinkedList test(arr_test, 1);

//     CharLinkedList::Node *node_result = test_list.findNode(0, test.front);
    
//     assert(node_result->data = 'r');
// }

// // findNode_large
// // makes sure helper function returns the right node with large list
// void findNode_large(){
//     char arr_test[4] = {'r', 'a', 't', 's'};
//     CharLinkedList test(arr_test, 4);

//    CharLinkedList::Node *node_result = test.findNode(0, test.front);
    
//     assert(node_result->data = 't');
// }

// // findNode_front
// // makes sure helper function returns the right node in the front of the
// // list
// void findNode_front(){
//     char arr_test[7] = {'r', 'a', 't', 's', 'h', 't', 'r'};
//     CharLinkedList test(arr_test, 7);

//    CharLinkedList::Node *node_result = test.findNode(0, test.front);
    
//     assert(node_result->data = 'r');
// }

// // findNode_back
// // makes sure helper function returns the right node in back of list
// void findNode_back(){
//     char arr_test[7] = {'r', 'a', 't', 's', 'h', 't', 'y'};
//     CharLinkedList test(arr_test, 7);

//     CharLinkedList::Node *node_result = test.findNode(6, test.front);
    
//     assert(node_result->data = 'y');
// }


// // recursiveBackHelper_singleton
// // Tests that helper function returns the right back node in single list
// void recursiveBackHelper_singleton() {
//     // initialize list
//     char test_arr[1] = {'c'};
//     CharLinkedList test(test_arr, 1);

//     // insert element
//     CharLinkedList::Node *back = test.recursiveBackHelper(test.front);

//     assert(back->data == 'c'); 
// }

// // recursiveBackHelper_large
// // Tests that helper function returns the right back node in big list
// void recursiveBackHelper_large() {
//     // initialize list
//     char test_arr[3] = {'c', 'a', 't'};
//     CharLinkedList test(test_arr, 3);

//     // insert element
//     CharLinkedList::Node *back = test.recursiveBackHelper(test.front);

//     assert(back->data == 't'); 
// }

// // deepCopyHelper_correct
// // Tests that helper function returns right index when middle is right
// void insertInOrderHelper_singleton() {
//     // create first instance
//     char arr_test[3] = {'b', 'a', 'g'};
//     CharLinkedList copied_test(arr_test, 3);
//     // create instance
//     CharLinkedList original;

//     // check front is originally null
//     assert(original.front == nullptr);

//     original.deepCopyHelper(copied_test);

//     // check that nodes were made and front isn't nullptr anymore
//     assert(original.front->data == 'b');

//     // check contents
//     assert(original.toString() == "[CharLinkedList of size 3 <<bag>>]");
// }


// // newNode_empty
// // Tests that new node helper function words properly on empty list
// void newNode_empty() {
//     // initialize empty list
//     CharLinkedList test_list;

//     // create new node
//     CharLinkedList::Node *node = test_list.newNode('t', nullptr, nullptr);

//     assert(test_list.front->data == 't');
//     assert(node->prev == nullptr);
//     assert(node->next == nullptr);
//     assert(test_list.size() == 1);
// }


// // newNode_singleton
// // Tests that new node helper function words properly
// void newNode_singleton() {
//     // initialize list
//     char test_arr[1] = {'c'};
//     CharLinkedList test(test_arr, 1);

//     // create new node
//     CharLinkedList::Node *node = test.newNode('r', nullptr, test.front);

//     assert(node->data == 'r');
//     assert(node->prev->data == 'c');
//     assert(node->next == nullptr);
//     assert(test.size() == 2);
// }

// // destructorHelper
// // Tests that helper destructor function correctly deletes node
// void destructiveHelper() {
//     // initialize list
//     char test_arr[1] = {'c'};
//     CharLinkedList test(test_arr, 1);

//     // insert element
//     CharLinkedList::Node *back = test.recursiveBackHelper(test.front);

//     test_list.destructiveHelper(back);

//     assert(back == nullptr); 
// }

// // insertInOrderHelper_front
// // Tests that helper function returns right index when front is right
// void insertInOrderHelper_front() {
//     // initialize list
//     char test_arr[4] = {'c', 'd', 'e', 'f'};
//     CharLinkedList test_list(test_arr, 4);

//     // insert element
//     int index = test_list.insertInOrderHelper('a', test_list.front, 0);

//     assert(index == 0); 
// }

// // insertInOrderHelper_back
// // Tests that helper function returns right index when back is right
// void insertInOrderHelper_back() {
//     // initialize list
//     char test_arr[4] = {'c', 'd', 'e', 'f'};
//     CharLinkedList test_list(test_arr, 4);

//     // insert element
//     int index = test_list.insertInOrderHelper('g', test_list.front, 0);

//     assert(index == 4); 
// }

// // insertInOrderHelper_front
// // Tests that helper function returns right index when middle is right
// void insertInOrderHelper_middle() {
//     // initialize list
//     char test_arr[3] = {'c', 'd', 'f'};
//     CharLinkedList test_list(test_arr, 3);

//     // insert element
//     int index = test_list.insertInOrderHelper('e', test_list.front, 0);

//     assert(index == 2); 
// }

// // insertInOrderHelper_singleton
// // Tests that helper function returns right index when middle is right
// void insertInOrderHelper_singleton() {
//     // initialize list
//     char test_arr[1] = {'c'};
//     CharLinkedList test_list(test_arr, 1);

//     // insert element
//     int index = test_list.insertInOrderHelper('a', test_list.front, 0);

//     assert(index == 0); 
// }





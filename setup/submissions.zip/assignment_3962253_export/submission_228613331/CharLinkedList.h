/*
 *  CharLinkedList.h
 *  Name: Hannah Friedlander
 *  Date: 2/2/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Purpose: Serves as the interface file for the CharLinkedList class, which 
 *           represents an list of characters. By performing the listed 
 *           operations, these lists can be modified. Instances of this
 *           class can either be intialized as empty or have any amount of 
 *           elements.
 *
 */

#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H
#include "stdexcept"
using namespace std;
#include <string>

class CharLinkedList {
    public:
    CharLinkedList();
    CharLinkedList(char c);
    CharLinkedList(char arr[], int size);
    CharLinkedList(const CharLinkedList &other);
    ~CharLinkedList();
    CharLinkedList &operator=(const CharLinkedList &other);
    bool isEmpty() const;
    void clear();
    int size() const;
    char first() const;
    char last() const;
    char elementAt(int index) const;
    string toString() const;
    string toReverseString() const;
    void pushAtBack(char c);
    void pushAtFront(char c);
    void insertAt(char c, int index);
    void insertInOrder(char c);
    void popFromFront();
    void popFromBack();
    void removeAt(int index);
    void replaceAt(char c, int index);
    void concatenate(CharLinkedList *other);

    private:
    struct Node {
        Node *next;
        Node *prev;
        char data;
    };
    
    Node *front;
    int listSize;

    // helper methods
    Node *newNode(char newData, Node *next, Node *prev);
    void deepCopyHelper(const CharLinkedList &other);
    void destructorHelper(Node *curr);
    Node *thirdConstrHelper(char arr[], int size, int idx, Node *prev_node);
    Node *findNode(int index, Node *curr) const;
    Node *recursiveBackHelper(Node *curr) const;
    string concatenateStringHelper(string word) const;
    int insertInOrderHelper(char c, Node *curr, int index);
};

#endif

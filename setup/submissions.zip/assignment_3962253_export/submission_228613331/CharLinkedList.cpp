/*
 *  CharLinkedList.cpp
 *  Name: Hannah Friedlander
 *  Date: 2/2/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Purpose: Implements the methods delcared in CharLinkedList.h. These methods
 *           perform specific objectives an the list of characters, which 
 *           allows the characters and the size of the list to be modified.
 *    
 *
 */

#include "CharLinkedList.h"


/*
 * name:      CharLinkedList default constructor
 * purpose:   initialize an empty list
 * arguments: none
 * returns:   none
 * effects:   front to nullptr since list is empty, size is set to 0
 */
CharLinkedList::CharLinkedList(){
    front = nullptr;
    listSize = 0;
}

/*
 * name:      CharLinkedList second constructor
 * purpose:   takes in a single character as a parameter and creates a one 
 *            element list consisting of that character
 * arguments: none
 * returns:   none
 * effects:   new node created, front pointer sent to new node, size updated
 */
CharLinkedList::CharLinkedList(char c){
    Node *new_node = new Node;
    new_node->data = c;
    front = new_node;
    new_node->next = nullptr;
    listSize = 1;
}

/*
 * name:      CharLinkedList third constructor
 * purpose:   create a list containing the characters in the linked
 *            passed in
 * arguments: none
 * returns:   none
 * effects:   new node created, front pointer sent to new node
 */
CharLinkedList::CharLinkedList(char arr[], int size){
    front = nullptr;
    listSize = 0;
    front = thirdConstrHelper(arr, size, 0, nullptr);
    
}

/*
 * name:      thirdConstrHelper
 * purpose:   recursively creates nodes for linked list from array
 * arguments: character array, integer size, integer index, and pointer
 *            pointing to the previous node
 * returns:   pointer to the new node created 
 * effects:   new nodes created, next and prev pointers set up
 */
CharLinkedList::Node *CharLinkedList::thirdConstrHelper(char arr[], int size, 
                                                    int idx, Node *prev_node){
    // base case, check if all nodes are done
    if (idx >= size){
        return nullptr;
    }
    // updates size
    listSize++;

    Node *new_node = newNode(arr[idx], nullptr, prev_node);

    // sets next of new node equal to the next node created
    Node *next = thirdConstrHelper(arr, size, idx + 1, new_node);


    // calls recursive function again
    return new_node;

}

// /*
//  * name:      CharLinkedList copy constructor 
//  * purpose:   makes a deep copy of a given instance
//  * arguments: takes a constant instance of the linked list class
//  * returns:   none
//  * effects:   deep copy created with helper function, both intances have 
//               same values after
//  */
CharLinkedList::CharLinkedList(const CharLinkedList &other){

    // call helper function to make deep copy
    deepCopyHelper(other);
}


/*
 * name:      overloaded assignment operator
 * purpose:   recycles the storage associated with the instance on the left of
 *            the assignment and makes a deep copy of the instance on the right
 *            hand side into the instance on the left hand side
 * arguments: takes a constant instance of the linekd list class
 * returns:   reference to char linked list 
 * effects:   deep copy created with helper function, recycles storage from
 *            original instance and clears it, both intances have same values
 *            after
 */
CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other){
    // check to see if they are already the same
    if (this == &other){
        return *this;
    }

    // clear current instance 
    clear();

    // call helper function to make deep copy
    deepCopyHelper(other);
    
    // return instance
    return *this;
}

/*
 * name:      deep copy helper
 * purpose:   creates the deep copy needed for both the copy constructor
 *            and overloaded assignment operator
 * returns:   reference to char linked list 
 * effects:   deep copy created, both intances have same values after
 */
void CharLinkedList::deepCopyHelper(const CharLinkedList &other){
    front = nullptr;

    // change list size of other new instance
    listSize = other.size();
    // pointer to current node in other instance
    Node *other_curr = other.front;
    // pointer to prev current instance
    Node *prev= nullptr;

    // set an intege variable to keep track of the index
    int index = 0;
    while (index < listSize){
        // create new nodes
        Node *prev_node = newNode(other_curr->data, nullptr, prev);
        // set up next pointers
         if (prev != nullptr) {
            prev->next = prev_node;
        }
        // use for prev pointers
        prev = prev_node;
        // move current pointer through other instance
        other_curr = other_curr->next;
        index++;
    }
}

/*
 * name:      isEmpty
 * purpose:   determines if the list is empty or not
 * arguments: none
 * returns:   none
 * effects:   checks if size is 0
 */
bool CharLinkedList::isEmpty() const{
    if (listSize == 0){
        return true;
    }
    return false;
}


/*
 * name:      clear
 * purpose:   makes the instance into an empty linked list
 * arguments: none
 * returns:   none
 * effects:   calls destructorHelper() method to clear list, sets front to
 *            nullptr so double frees don't occur
 */
void CharLinkedList::clear(){
    destructorHelper(front);
    front = nullptr;
    listSize = 0;
}

/*
 * name:      first
 * purpose:   returns the first character in the linked list
 * arguments: none
 * returns:   first character in the linked list
 * effects:   determines first character, or throws error if empty
 */
char CharLinkedList::first() const{
    if (not isEmpty()){
        return front->data;
    } else {
        throw runtime_error("cannot get first of empty LinkedList");
    }
}

/*
 * name:      last
 * purpose:   returns the last character in the linked list
 * arguments: none
 * returns:   last character in the linked list
 * effects:   determines last character with recursive helper function, or
 *            throws error if empty
 */
char CharLinkedList::last() const{
    if (not isEmpty()){
        // call recursive back helper
        Node *back = recursiveBackHelper(front);
        return back->data;
    } else {
        throw runtime_error("cannot get first of empty LinkedList");
    }
}

/*
 * name:      elementAt
 * purpose:   accesses the element at a certain specified index
 * arguments: an index that is unchangeable
 * returns:   the element at that index, or an error if the index is out of 
 *            range
 * effects:   checks if in range, calls helper recursive function, gets 
 *            data
 */
char CharLinkedList::elementAt(int index) const{
    string index_s = to_string(index);
    string size_s = to_string(listSize);

    if (index >= 0 and index < listSize){
        // find element with recursive helper function
        Node *element_result = findNode(index, front);
        // get the data stored at that node
        char element_data = element_result->data;
        return element_data;
    } else {
        throw range_error("index (" + index_s + ") not in range [0.." 
                                    + size_s + ")");
    }
}

/*
 * name:      findNode
 * purpose:   helper function that uses recursion to keep going through the 
 *            links until the desires index is reached
 * arguments: an index that is unchangeable
 * returns:   the node at the specified index
 * effects:   goes through links, keep updating index and pointer,
 *            until element is found
 */
CharLinkedList::Node *CharLinkedList::findNode(int index, Node *curr) const{
    if (index == 0){
        return curr;
    } else {
        return findNode(index - 1, curr->next);
    }
}

/*
 * name:     pushAtBack
 * purpose:   inserts the given new element after the end of the existing 
 *            elements of the linked list
 * arguments: single character
 * returns:   none
 * effects:   adds node to back of linked list, updates prev and next
 */
void CharLinkedList::pushAtBack(char c){
    Node *back = recursiveBackHelper(front);

    // check is first link is empty and if it is, put node there
    if (front == nullptr){
        newNode(c, nullptr, nullptr);
    } else {
        newNode(c, nullptr, back);
    }

    // update size
    listSize++;
}

/*
 * name:     pushAtFront
 * purpose:   inserts the given new element at the front of the existing 
 *            elements of the linked list
 * arguments: single character
 * returns:   none
 * effects:   creates node for front link, updates front pointer, prev, and
 *            next
 */
void CharLinkedList::pushAtFront(char c){

    // check if list is empty
    if (front == nullptr){
        // create new node
        front = newNode(c, nullptr, nullptr);
    } else {
        front = newNode(c, front, nullptr);
    }

    //update size of linked list
    listSize++;
}

/*
 * name:      insertAt
 * purpose:   inserts the element at the specified index
 * arguments: none
 * returns:   a char and an integer index
 * effects:   calls newNode function, updates size, throws error if out of 
 *            range
 */
void CharLinkedList::insertAt(char c, int index){
    // turn int size into a string
    string index_s = to_string(index);

    if (index >= 0 and index <= listSize){
        if (index == 0 or isEmpty()){ 
            pushAtFront(c); // push element to front if empty or zero index
        } else if (index == listSize){
            pushAtBack(c); // push to back if last index
        } else {
            // make pointer to before node
            Node *before = findNode(index - 1, front);
            // make pointer to after node
            Node *after = findNode(index, front);

            Node *new_node = newNode(c, after, before);
            listSize++;
        }
    } else {
        string size_s = to_string(listSize);
        throw range_error("index (" + index_s + ") not in range [0.." 
                                    + size_s + "]");
    }
}

/*
 * name:      insertInOrder
 * purpose:   inserts provided char into list at first correct index
 *            based on ASCII value so list is ascending
 * arguments: one char variable
 * returns:   none
 * effects:   finds right spot, calls insertAt()
 */
void CharLinkedList::insertInOrder(char c){
    // store index value from recursive function
    int next_index = insertInOrderHelper(c, front, 0);

    // call insertAt code
    insertAt(c, next_index);
}


/*
 * name:      insertInOrder
 * purpose:   recursive helper function to find index where new node should be
 *            inserted based on ASCII table values
 * arguments: one char variable
 * returns:   integer index where the node should be inserted
 * effects:   recursively finds index
 */
int CharLinkedList::insertInOrderHelper(char c, Node *curr, int index){
    if (curr == nullptr or c <= curr->data){
        return index;
    }
    else {
        // update index
        return insertInOrderHelper(c, curr->next, index + 1);
    }
}

/*
 * name:      new node helper function
 * purpose:   creates a new node with the data passed on and updates its 
 *            next pointer
 *            is created
 * returns:   pointer to the new node created
 * effects:   creates new node, updates next pointer
 */
CharLinkedList::Node * CharLinkedList::newNode(char newData, Node *next,
                                                                Node *prev){
    // create new node
    Node *new_node = new Node;
    new_node->data = newData;
    // set next of new node equal to the node passed in so it goes before it
    new_node->next = next;
    // update next node to point back to new node

    // make sure next isn't nullptr
    if (next != nullptr){
        next->prev = new_node;
    }

    // reset prev pointer
    new_node->prev = prev;
    // is prev is null, only node in the list so should be the front
    if (prev == nullptr){
        front = new_node;
    } else {
        prev->next = new_node;
    }

    return new_node;
}

/*
 * name:      popFromFront
 * purpose:   pops an element from the front of linked list
 * arguments: single character
 * returns:   none
 * effects:   resets pointers, deletes front node, throws error if empty
 */
void CharLinkedList::popFromFront(){
    if (listSize != 0){
        // set pointer to front
        Node *curr = front;
        // move pointer over to next node
        front = curr->next;
        // delete front
        delete curr;
        listSize--;
        if (front != nullptr){
            // update prev pointer so reverse still works, as long as 
            // list isn't empty now
            front->prev = nullptr;
        }
    } else {
        throw runtime_error("cannot pop from empty LinkedList");
    }
}

/*
 * name:      popFromBack
 * purpose:   pops an element from the back of linked list
 * arguments: single character
 * returns:   none
 * effects:   calls recursive back helper function, throws error if empty
 */
void CharLinkedList::popFromBack(){
    if (listSize != 0){
        // set pointer to the back node
        Node *back = recursiveBackHelper(front);
        if (listSize == 1){
            front = nullptr;
        } else {
            back->prev->next = nullptr;
        }
        delete back;
        listSize--;
    } else {
        throw runtime_error("cannot pop from empty LinkedList");
    }

}


/*
 * name:     toString
 * purpose:   creates a string which contains the characters of the 
 *            CharLinkedList
 * arguments: none
 * returns:   final string with new word and size
 * effects:   loops through and adds each node's data to string, concatenates
 */
string CharLinkedList::toString() const{
    string elements_string = "";

    // set pointer equal to the front node
    Node *curr = front;

    // iterate through and add each node's char to string
    while (curr != nullptr){
        elements_string += curr->data;
        curr = curr->next;
    }

    // call concatenate helper function
    string final = concatenateStringHelper(elements_string);
    return final;
}

/*
 * name:     toReverseString
 * purpose:   creates a reversed string which contains the characters of the 
 *            linked list nodes
 * arguments: none
 * returns:   final string with new word and size
 * effects:   
 */
string CharLinkedList::toReverseString() const{
    string elements_string = "";

    // get last node using recursive helper function
    Node *curr = recursiveBackHelper(front);

    // // adds each character using prev pointers to string
    while (curr != nullptr){
        elements_string += curr->data;
        curr = curr->prev;
    }

    string final = concatenateStringHelper(elements_string);
    return final;
}

/*
 * name:     concatenateStringHelper
 * purpose:   helper function used to concatenate the strings for both
 *            toString and toReverseString
 * arguments: string passed in from those functions
 * returns:   the concatenated string
 * effects:   concatenates the string in the correct order with size and word
 */
string CharLinkedList::concatenateStringHelper(string word) const{
    string first_string = "[CharLinkedList of size " + to_string(listSize);
    string list_string = " <<" + word + ">>]";
    // concatenate
    string final_string = first_string + list_string;
    return final_string;
}

/*
 * name:      recursiveBackHelper
 * purpose:   helper function used to find the back node of a linked list
 * arguments: pointer that points to a node
 * returns:   the last node
 * effects:   recursively finds last node
 */
CharLinkedList::Node * CharLinkedList::recursiveBackHelper(Node *curr) const{
    // check if current is null or next is null, meaning it is the last node
    if (curr == nullptr or curr->next == nullptr){
        return curr;
    } else {
        // keep iterating through using recursion
        return recursiveBackHelper(curr->next);
    }
}

/*
 * name:      CharLinkedList destructor
 * purpose:   destroys/deletes/recycles all heap-allocated data in the 
 *            current linked list
 * arguments: none
 * returns:   none
 * effects:   frees memory
 */
CharLinkedList::~CharLinkedList(){
    destructorHelper(front);
    front = nullptr;
}

/*
 * name:      destructorHelper
 * purpose:   performs recursive process of deleting the linked list
 *            nodes and freeing memory
 * arguments: pointer to the current node
 * returns:   none
 * effects:   frees memory
 */
void CharLinkedList::destructorHelper(Node *curr){
    if (curr == nullptr){
        return;
    }   
    Node *next = curr->next;
    destructorHelper(next);
    delete curr;
}


/*
 * name:      size
 * purpose:   returns the number of chars found in the linked list
 * arguments: none
 * returns:   number of items
 * effects:   gets the size of the list to be used for other functions
 */
int CharLinkedList::size() const{
    return listSize;
}

/*
 * name:      removeAt
 * purpose:   removes the element at the specified index
 * arguments: none
 * returns:   an integer index
 * effects:   check for edge cases, use recursive helper function to find
 *            correct nodes, throw error if out of range
 */
void CharLinkedList::removeAt(int index){
    string index_s = to_string(index);

    // check index
    if (index >= 0 and index < listSize){
        Node *remove = findNode(index, front);

        if (index == 0){
            popFromFront(); // pop from front if first index
        } else if (index == listSize - 1){
            popFromBack(); // pop from back if last index
        } else {
            if (listSize == 1){
            front = nullptr; // set front to nullptr since list will be empty
            } else {
                Node *before = findNode(index - 1, front); // before
                Node *after = findNode(index + 1, front); // find after
                // update pointers so node can be deleted
                before->next = after;
                after->prev = before;
            }
        listSize--; // decrease size
        delete remove; // delete node
        }
    } else {
        string size_s = to_string(listSize);
        throw range_error("index (" + index_s + ") not in range [0.." 
                                    + size_s + ")");
    }
}

/*
 * name:      replaceAt
 * purpose:   replaces the element at the specified index with the new element
 * arguments: none
 * returns:   a char and an integer index
 * effects:   calls elementAt recursive helper, throws erorr if out of range
 */
void CharLinkedList::replaceAt(char c, int index){
    string index_s = to_string(index);
    if (index >= 0 and index < listSize){
            // use recursive helper
            Node* replaceNode = findNode(index, front);
            // replace data at the node
            replaceNode->data = c;
    } else {
        string size_s = to_string(listSize);
        throw range_error("index (" + index_s + ") not in range [0.." 
                                    + size_s + ")");
    }
}

/*
 * name:      concatenate
 * purpose:   adds a copy of the linked list pointed to by the parameter value
 *            to the end of the linked list the function was called from
 * arguments: pointer to a second CharLinkedList
 * returns:   none
 * effects:   uses pushAtBack() and elementAt() to add object elements together
 */
void CharLinkedList::concatenate(CharLinkedList *other){
    // get size of object passed in
    int other_size = other->size();

    for (int i = 0; i < other_size; i++){
        // push elements one by one
        this->pushAtBack(other->elementAt(i));
    }
}
/*
 *  CharLinkedList.cpp
 *  Claire Zhang
 *  2/1/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  This file contains an implementation of the CharLinkedList class
 *
 */

#include "CharLinkedList.h"
#include <sstream>
#include <stdexcept>
#include <iostream>

using namespace std;

/*
 * CharLinkedList Default Constructor
 * purpose: initializes an empty linked list
 * arguments: none
 * returns: none
 * effects: size and capacity of the linked list are set to 0; data is nullptr
*/
CharLinkedList::CharLinkedList() {
    front = nullptr;
    back = nullptr;
    currSize = 0;
}

/*
 * CharLinkedList Constructor
 * purpose: creates a one element linked list consisting of the character 
 *          parameter 
 * arguments: a char that will be the single element in the linked list
 * returns: none
 * effects: size and capacity of the linked list are set to 1; data is 
 *          dynamically allocated on the heap
*/
CharLinkedList::CharLinkedList(char c) {
    // create new node with given char
    Node *new_node = newNode(c, nullptr, nullptr);
    // front and back pointers point to the new node
    front = new_node;
    back = new_node;
    currSize = 1;
}

/*
 * CharLinkedList Constructor
 * purpose: creates a linked list containing characters in the array parameter
 * arguments: an array of characters that the linked list will contain and an
 *            int representing the size of the linked parameter
 * returns: none
 * effects: size and capacity of the linked list are set to the size of the 
 *          array parameter; data is dynamically allocated on the heap
*/
CharLinkedList::CharLinkedList(char arr[], int size) {
    // create back node with last char in the array
    Node *back_node = newNode(arr[size - 1], nullptr, nullptr);
    front = back_node;
    back = back_node;
    Node *curr = back_node;

    // loop through array and add the chars as new nodes to the linked list
    for (int i = size - 2; i > -1; i--) {
        Node *new_node = newNode(arr[i], nullptr, curr);
        curr->previous = new_node;
        curr = new_node;
        front = new_node;
    }
    currSize = size;
}

/*
 * CharLinkedList Copy Constructor
 * purpose: makes a deep copy of a given linked list
 * arguments: address of the linked list to be copied
 * returns: none
 * effects: data is dynamically allocated on the heap; size and capacity of the 
 *          linked list are set to the size and capacity the linked list 
 *          parameter
*/
CharLinkedList::CharLinkedList(const CharLinkedList &other) {
    // set members equal to those of other
    currSize = 0;
    front = nullptr;
    back = nullptr;

    // fill data with the chars in other
    for (int i = 0; i < other.currSize; i++)  {
        pushAtBack(other.elementAt(i));
    }
}

/*
 * CharLinkedList Destructor
 * purpose: recycles all heap-allocated data in the current linked list
 * arguments: none
 * returns: none
 * effects: heap-allocated data is no longer accessible
*/
CharLinkedList::~CharLinkedList() {
    recycleRecursive(front);
}

/*
 * CharLinkedList recycleRecursive
 * purpose: help recycle heap-allocated data recursively
 * arguments: pointer to the current node
 * returns: none
 * effects: none
*/
void CharLinkedList::recycleRecursive(Node *curr) {
    if (curr == nullptr) {
        return;
    }
    else {
        Node *next = curr->next;
        delete curr;
        recycleRecursive(next);
    }
}

/*
 * CharLinkedList Assignment Operator
 * purpose: recycles the storage associated with the instance on the left of the
 *          and makes a deep copy of the instance on the right hand side into
 *          the instance on the left hand side
 * arguments: address of the linked list to be copied
 * returns: a deep copy of the instance on the right of the assignment
 * effects: original heap-allocated data of the instance on the left of the
 *          assignment is no longer accessible; new data is dynamically
 *          allocated on the heap
*/
CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other) {
    // return current instance if this and other are the same
    if (this == &other) {
        return *this;
    }

    // recycle memory
    recycleRecursive(front);

    // initialize private variables
    currSize = 0;
    front = nullptr;
    back = nullptr;

    // fill data with the chars in other
    for (int i = 0; i < other.currSize; i++)  {
        pushAtBack(other.elementAt(i));
    }

    return *this;
}

/*
 * name: isEmpty
 * purpose: determines if the linked list is empty
 * arguments: none
 * returns: bool true if the linked list is empty and bool false if the linked
 *          list contains characters
 * effects: none
*/
bool CharLinkedList::isEmpty() const {
    // check if there are elements in the linked list
    if (currSize == 0) {
        return true;
    }
    return false;
}

/*
 * name: clear
 * purpose: makes the current linked list into an empty linked list
 * arguments: none
 * returns: none
 * effects: size of the linked list becomes 0
*/
void CharLinkedList::clear() {
    // recycle heap-allocated memory
    recycleRecursive(front);
    // reset private variables
    front = nullptr;
    back = nullptr;
    currSize = 0;
}

/*
 * name: size
 * purpose: provides the number of characters in the linked list
 * arguments: none
 * returns: an int representing the number of characters in the linked list
 * effects: none
*/
int CharLinkedList::size() const {
    return currSize;
}

/*
 * name: first
 * purpose: provides the first character in the linked list
 * arguments: none
 * returns: char at the first index of the linked list
 * effects: throws an std::runtime_error exception if the linked list is empty
*/
char CharLinkedList::first() const {
    if (isEmpty()) {
        throw runtime_error("cannot get first of empty LinkedList");
    }

    return front->data;
}

/*
 * name: last
 * purpose: provides the last character in the linked list
 * arguments: none
 * returns: char at the last index of the linked list
 * effects: throws an std::runtime_error exception if the linked list is empty
*/
char CharLinkedList::last() const {
    if (isEmpty()) {
        throw runtime_error("cannot get last of empty LinkedList");
    }

    return back->data;
} 

/*
 * name: elementAt
 * purpose: provides the char in the linked list at the provided index
 * arguments: an int representing an index of a CharLinkedList 
 * returns: char at the given index
 * effects: throws an std::range_error if the index is out of range
*/
char CharLinkedList::elementAt(int index) const {
    // check if index is out of bounds
    if (index < 0 or index >= currSize) {
        throw range_error("index (" + to_string(index) + ") not in range [0.." 
                                    + to_string(currSize) + ")");
    }

    if (index == 0) {
        return front->data;
    }
    else if (index == currSize - 1) {
        return back->data;
    }
    else {
        return elementAtHelper(front, index, 0)->data;
    }
}

/*
 * name: toString
 * purpose: provides a string which contains the size and characters of the 
 *          CharLinkedList
 * arguments: none
 * returns: a string with the size and characters of the linked list
 * effects: none
*/
std::string CharLinkedList::toString() const {
    std::stringstream ss;
    ss << "[CharLinkedList of size " << currSize << " <<";

    // add the chars in the linked list to the string
    for (int i = 0; i < currSize; i++) {
        ss << elementAt(i);
    }

    ss << ">>]";
    return ss.str();
}

/*
 * name: toReverseString
 * purpose: provides a string which contains the size and characters in reverse
 *          order of the CharLinkedList
 * arguments: none
 * returns: a string with the size and characters in reverse order of the linked
 *          list
 * effects: none
*/
std::string CharLinkedList::toReverseString() const {
    std::stringstream ss;
    ss << "[CharLinkedList of size " << currSize << " <<";

    // add the chars in the linked list to the string in reverse
    for (int i = currSize - 1; i > -1; i--) {
        ss << elementAt(i);
    }

    ss << ">>]";
    return ss.str();
}

/*
 * name: pushAtBack
 * purpose: inserts the given char after the end of the existing elements of
 *          the linked list
 * arguments: char to be added to the back of the linked list
 * returns: none
 * effects: adds 1 to the size of the linked list
*/
void CharLinkedList::pushAtBack(char c) {
    if (isEmpty()) {
        // create new node in empty linked list
        Node *new_node = newNode(c, nullptr, nullptr);
        front = new_node;
        back = new_node;
    }
    else {
        // create temporary pointer to back
        Node *temp = back;
        // new node is now back
        back = newNode(c, temp, nullptr);
        temp->next = back;
    }
    currSize++;
}

/*
 * name: pushAtFront
 * purpose: inserts the given char in of the existing elements of the linked 
 *          list
 * arguments: char to be added to the back of the linked list
 * returns: none
 * effects: adds 1 to the size of the linked list
*/
void CharLinkedList::pushAtFront(char c) {
    if (isEmpty()) {
        // create new node in empty linked list
        Node *new_node = newNode(c, nullptr, nullptr);
        front = new_node;
        back = new_node; 
    }
    else {
        Node *temp = front;
        front = newNode(c, nullptr, front);
        temp->previous = front;
    }
    currSize++;
}

/*
 * name: insertAt
 * purpose: inserts the given char at the specified index and shift the existing
 *          elements as necessary
 * arguments: char to be added to the linked list and an int that is the index 
 *            at which the char is to be added
 * returns: none
 * effects: adds 1 to the size of the linked list
*/
void CharLinkedList::insertAt(char c, int index) {
    // check if index is in range
    if (index < 0 or index > currSize) {
        throw range_error("index (" + to_string(index) + ") not in range [0.." 
                          + to_string(currSize) + "]");
    }
    
    if (index == 0) {
        pushAtFront(c);
    }
    else if (index == currSize) {
        pushAtBack(c);
    }
    else {
        Node *curr = front;
        int currIndex = 0;
        // get to node at the index
        while (currIndex < index - 1) {
            curr = curr->next;
            currIndex++;
        }

        // insert new node at index
        curr->next = newNode(c, curr, curr->next);
        curr->next->next->previous = curr->next;

        currSize++;
    }
}

/*
 * name: insertInOrder
 * purpose: inserts the given char into the linked list in ASCII order
 * arguments: char to be added to the linked list
 * returns: none
 * effects: adds 1 to the size of the linked list
*/
void CharLinkedList::insertInOrder(char c) {
    // check if the linked list is empty or if c should go before the first 
    // element
    if (isEmpty() or c < elementAt(0)) {
        pushAtFront(c);
    }
    // check if c should go after the last element
    else if (c > elementAt(currSize - 1)) {
        pushAtBack(c);
    }
    else {
        for (int i = 0; i < currSize; i++) {
            // check if c is less than the element at the current index
            if (c < elementAt(i)) {
                insertAt(c, i);
                break;
            }
        }
    }
}

/*
 * name: popFromFront
 * purpose: removes the last element from the linked list
 * arguments: none
 * returns: none
 * effects: substracts 1 from the size of the linked list
*/
void CharLinkedList::popFromFront() {
    // check if the linked list is empty
    if (isEmpty()) {
        throw runtime_error("cannot pop from empty LinkedList");
    }

    // change front pointer to next node
    Node *temp = front;
    front = front->next;

    // delete front node
    delete temp;

    currSize--;
}

/*
 * name: popFromBack
 * purpose: removes the first element from the linked list
 * arguments: none
 * returns: none
 * effects: substracts 1 from the size of the linked list
*/
void CharLinkedList::popFromBack() {
    // check if linked list is empty
    if (isEmpty()) {
        throw runtime_error("cannot pop from empty LinkedList");
    }
    
    // check if linked list has 1 element
    if (currSize == 1) {
        // recycle memory
        delete back;
        // reset private variables
        back = nullptr;
        front = nullptr;
    }
    else {
        // create temporary pointer to back
        Node *temp = back;
        // point back to the node before the original back node
        back = back->previous;
        if (back != nullptr) {
            back->next = nullptr;
        }

        // recycle memory
        delete temp;
    }

    currSize--;
}

/*
 * name: removeAt
 * purpose: removes the the element at the specified index
 * arguments: an int representing the index at which a char should be removed
 * returns: none
 * effects: substracts 1 from the size of the linked list
*/
void CharLinkedList::removeAt(int index) {
    // check if index is in range
    if (index < 0 or index >= currSize) {
        throw range_error("index (" + to_string(index) + ") not in range [0.." 
                          + to_string(currSize) + ")");
    }
    
    if (index == 0) {
        popFromFront();
    }
    else if (index == currSize - 1) {
        popFromBack();
    }
    else {
        // create temporary pointer to the node at the given index
        Node *temp = elementAtHelper(front, index, 0);
        temp->previous->next = temp->next;
        temp->next->previous = temp->previous;
        
        // recycle memory
        delete temp;

        currSize--;
    }
}

/*
 * name: replaceAt
 * purpose: replaces the element at the specified index with the new element
 * arguments: a char to replace an element and an int that is the index to be 
 *            replaced
 * returns: none
 * effects: throws an std::range_error if the index is out of range
*/
void CharLinkedList::replaceAt(char c, int index) {
    // check if index is in range
    if (index < 0 or index >= currSize) {
        throw range_error("index (" + to_string(index) + ") not in range [0.." 
                          + to_string(currSize) + ")");
    }

    removeAt(index);
    insertAt(c, index);
}

/*
 * name: concatenate
 * purpose: adds a copy of the linked list pointed to by the parameter value to
 *          the end of the linked list the function was called from
 * arguments: a pointer to a CharLinkedList to be added
 * returns: none
 * effects: may increase the size of the linked list
*/
void CharLinkedList::concatenate(CharLinkedList *other) {
    // check if the instance is being concatenated with itself
    if (this == other) {
        int new_size = currSize;
        for (int i = 0; i < new_size; i++) {
            pushAtBack(other->elementAt(i));
        }
    }
    // only concatenate if other is not empty
    else if (other->size() != 0) {      
        for (int j = 0; j < other->size(); j++) {
            pushAtBack(other->elementAt(j));
        }
    }
}

/*
 * name: newNode
 * purpose: creates a new node containing a given char, previous node pointer, 
 *          and next node pointer
 * arguments: a char to be added to the linked list, a pointer to the previous
 *            node, a pointer to the next node
 * returns: a pointer to the new node created
 * effects: none
*/
CharLinkedList::Node *CharLinkedList::newNode(char newData, Node *previous, 
                                              Node *next) {
    // allocate memory on the heap for a new node
    Node *new_node = new Node;
    // initialize private variables to given values
    new_node->data = newData;
    new_node->previous = previous;
    new_node->next = next;

    return new_node;
}

/*
 * name: elementAtHelper
 * purpose: finds the node located at the given index
 * arguments: a pointer to the current node, an int representing the index of 
 *            the node to be returned, and an int with the current index
 * returns: a pointer to the node at the given index
 * effects: none
*/
CharLinkedList::Node *CharLinkedList::elementAtHelper(Node *curr, int index, 
                                                      int currIndex) const {
    // check if the current index is the target index
    if (currIndex == index) {
        return curr;
    }

    return elementAtHelper(curr->next, index, currIndex + 1);
}



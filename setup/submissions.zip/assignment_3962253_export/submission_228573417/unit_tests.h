/*
 *  unit_tests.h
 *  Claire Zhang
 *  2/1/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  Uses Matt Russell's unit_test framework to test the CharArrayList class.
 *
 */

#include "CharLinkedList.h"
#include <cassert>
#include <stdexcept>
#include <iostream>

using namespace std;

// Tests whether the class definition is syntactically correct
void test() {

}

// Tests the default constructor to make sure there are no errors
void defaultConstructor_test0() {
    CharLinkedList test_list;
}

// Makes sure there are no items in the list after a call to th default 
// constructor
void defaultConstructor_test1() {
    CharLinkedList test_list;
    assert(test_list.front == nullptr);
    assert(test_list.back == nullptr);
}

// Tests the second constructor to make sure there are no errors
void constructor2_test0() {
    CharLinkedList test_list('a');
}

// Makes sure there is 1 element in the list after a call to the second 
// constructor and that the element is the char passed as an argument
void constructor2_test1() {
    CharLinkedList test_list('a');
    assert(test_list.front->data == 'a');
    assert(test_list.back->data == 'a');
}

// Tests the third constructor to make sure there are no errors
void constructor3_test0() {
    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList test_list(arr, 5);
}

// Makes sure there are 5 elements in the list that are the same as those in 
// the linked list passed as an argument. Also check that the capacity is 5/
void constructor3_test1() {
    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList test_list(arr, 5);
    assert(test_list.front->data == 'a');
    assert(test_list.front->next->data == 'b');
    assert(test_list.front->next->next->data == 'c');
    assert(test_list.front->next->next->next->data == 'd');
    assert(test_list.back->data == 'e');
}

// Tests the copy constructor to make sure there are no errors
void copyConstructor_test0() {
    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList other(arr, 5);
    CharLinkedList test_list(other);
}

// Makes sure the copy constructor creates a new char linked list that is the
// same size and capacity as other and contains the same elements in the same
// order
void copyConstructor_test1() {
    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList other(arr, 5);
    CharLinkedList test_list(other);
    assert(test_list.currSize == other.currSize);
    assert(test_list.front->data == other.front->data);
    assert(test_list.back->data == other.back->data);
    // for (int i = 0; i < 5; i++) {
    //     assert(test_list.elementAt(i) == other.elementAt(i));
    // }    
}

// assignment operator test
// Makes sure that the overloaded assignment operator recycles the storage of
// the instance on the left of the assignment and makes a deep copy of the rhs 
// into the lhs
void overloadedAssignmentOperator() {
    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList other(arr, 5);
    CharLinkedList test_list;
    test_list = other;
    assert(test_list.currSize == other.currSize);
    for (int i = 0; i < 5; i++) {
        assert(test_list.elementAt(i) == other.elementAt(i));
    }  
}

// isEmpty test
// Makes sure that isEmpty returns true when there are no elements in the list
void isEmpty_true() {
    CharLinkedList test_list;
    assert(test_list.isEmpty());
}

// Makes sure that isEmpty returns false when there are elements in the list
void isEmpty_false() {
    CharLinkedList test_list('a');
    assert(not test_list.isEmpty());
}

// clear test
// Makes sure the clear function results in a list with size 0 when called with
// an empty list
void clear_empty() {
    CharLinkedList test_list;
    test_list.clear();
    assert(test_list.currSize == 0);
}

// Makes sure the clear function results in a list with size 0 when called with
// a list containing one element
void clear_oneElement() {
    CharLinkedList test_list('a');
    test_list.clear();
    assert(test_list.currSize == 0);
}

// Makes sure the clear function results in a list with size 0 when called with
// a list containing multiple elements
void clear_multipleElements() {
    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList test_list(arr, 5);
    test_list.clear();
    assert(test_list.currSize == 0);    
}

// size test
// Makes sure the size function returns a size of 0 for an empty list
void size_empty() {
    CharLinkedList test_list;
    assert(test_list.currSize == 0);
}

// Makes sure the size function returns a size of 1 for a list containing one
// element
void size_oneElement() {
    CharLinkedList test_list('a');
    assert(test_list.currSize == 1);
}

// Makes sure the size function returns a size of 5 for a list containing 5
// elements
void size_multipleElements() {
    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList test_list(arr, 5);
    assert(test_list.currSize == 5);
}

// first test
// Makes sure the first function throws an std::runtime_error exception when
// called with a list containing no elements
void first_noElements() {
    CharLinkedList test_list;

    bool runtime_error_thrown = false;

    std::string error_message = "";

    try {
        test_list.first();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot get first of empty LinkedList");
}

// Makes sure the first function returns the first element in a list containing
// one element
void first_oneElement() {
    CharLinkedList test_list('a');
    try {
        assert(test_list.first() == 'a');
    }
    catch (const runtime_error &e) {
        cout << "We just got the following eror message: ";
        cout << e.what();
    }
}

// Makes sure the first function returns the first element in a list containing
// multiple elements
void first_multipleElements() {
    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList test_list(arr, 5);
    try {
        assert(test_list.first() == 'a');
    }
    catch (const runtime_error &e) {
        cout << "We just got the following eror message: ";
        cout << e.what();
    }
}

// last test
// Makes sure the last function throws an std::runtime_error exception when
// called with a list containing no elements
void last_noElements() {
    CharLinkedList test_list;

    bool runtime_error_thrown = false;

    std::string error_message = "";

    try {
        test_list.last();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot get last of empty LinkedList");
}

// Makes sure the last function returns the first element in a list containing
// one element
void last_oneElement() {
    CharLinkedList test_list('a');
    try {
        assert(test_list.last() == 'a');
    }
    catch (const runtime_error &e) {
        cout << "We just got the following eror message: ";
        cout << e.what();
    }    
}

// Makes sure the last function returns the first element in a list containing
// multiple elements
void last_multipleElements() {
    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList test_list(arr, 5);
    try {
        assert(test_list.last() == 'e');
    }
    catch (const runtime_error &e) {
        cout << "We just got the following eror message: ";
        cout << e.what();
    }   
}

// elementAt test
// Makes sure the elementAt function throws an std::range_error when too high  
// of an index is passed to the function
void elementAt_invalidIndex1() {
    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList test_list(arr, 5);

    bool range_error_thrown = false;

    std::string error_message = "";

    try {
        test_list.elementAt(5);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (5) not in range [0..5)");
}

// Makes sure the elementAt function throws an std::range_error when a negative
// index is passed to the function
void elementAt_invalidIndex2() {
    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList test_list(arr, 5);

    bool range_error_thrown = false;

    std::string error_message = "";

    try {
        test_list.elementAt(-1);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (-1) not in range [0..5)");  
}

// Makes sure the elementAt function returns the correct char when called with a
// list of one element
void elementAt_oneElement() {
    CharLinkedList test_list('a');
    try {
        assert(test_list.elementAt(0) == 'a');
    }
    catch (const range_error &e) {
        cout << "We just got the following eror message: ";
        cout << e.what();
    }     
}

// Makes sure the elementAt function returns the correct char when called with a
// list of multiple elements 
void elementAt_multipleElements() {
    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList test_list(arr, 5);
    try {
        assert(test_list.elementAt(3) == 'd');
    }
    catch (const range_error &e) {
        cout << "We just got the following eror message: ";
        cout << e.what(); 
    }   
}

// toString test
// Makes sure the toString function returns the appropriate string for an empty
// linked list
void toString_noElements() {
    CharLinkedList test_list;
    assert(test_list.toString() == "[CharLinkedList of size 0 <<>>]");
}

// Makes sure the toString function returns the appropriate string for a linked
// list containing one element
void toString_oneElement() {
    CharLinkedList test_list('a');
    assert(test_list.toString() == "[CharLinkedList of size 1 <<a>>]");
}

// Makes sure the toString function returns the appropriate string for a linked
// list containing multiple elements
void toString_multipleElements() {
    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList test_list(arr, 5);
    assert(test_list.toString() == "[CharLinkedList of size 5 <<abcde>>]");
}

// toReverse String test
// Makes sure the toReverseString function returns the appropriate string for  
// an empty linked list
void toReverseString_noElements() {
    CharLinkedList test_list;
    assert(test_list.toReverseString() == "[CharLinkedList of size 0 <<>>]");
}

// Makes sure the toReverseString function returns the appropriate string for  
// a linked list containing one element
void toReverseString_oneElement() {
    CharLinkedList test_list('a');
    assert(test_list.toReverseString() == "[CharLinkedList of size 1 <<a>>]");
}

// Makes sure the toReverseString function returns the appropriate string for  
// a linked list containing multiple elements
void toReverseString_multipleElements() {
    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList test_list(arr, 5);
    assert(test_list.toReverseString() == 
           "[CharLinkedList of size 5 <<edcba>>]");
}

// pushAtBack test
// Makes sure that pushAtBack adds the char argument as to an empty list
void pushAtBack_noElements() {
    CharLinkedList test_list;
    test_list.pushAtBack('a');
    assert(test_list.toString() == "[CharLinkedList of size 1 <<a>>]");
}

// Makes sure that pushAtBack adds the char argument to the end of a list
// containing one element
void pushAtBack_oneElement() {
    CharLinkedList test_list('a');
    test_list.pushAtBack('b');
    assert(test_list.toString() == "[CharLinkedList of size 2 <<ab>>]");
}

// Makes sure that pushAtBack adds the char argument to the end of a list
// containing multiple elements
void pushAtBack_multipleElements() {
    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList test_list(arr, 5);
    test_list.pushAtBack('f');   
    assert(test_list.toString() == "[CharLinkedList of size 6 <<abcdef>>]");
}

// pushAtFront test
// Makes sure that pushAtFront adds the char argument as to an empty list
void pushAtFront_noElements() {
    CharLinkedList test_list;
    test_list.pushAtFront('a');
    assert(test_list.toString() == "[CharLinkedList of size 1 <<a>>]");
}

// Makes sure that pushAtFront adds the char argument to the beginning of a list
// containing one element
void pushAtFront_oneElement() {
    CharLinkedList test_list('a');
    test_list.pushAtFront('b');
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.toString() == "[CharLinkedList of size 2 <<ba>>]");
}

// Makes sure that pushAtFront adds the char argument to the beginning of a list
// containing multiple elements
void pushAtFront_multipleElements() {
    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList test_list(arr, 5);
    test_list.pushAtFront('f');   
    assert(test_list.elementAt(0) == 'f');
    assert(test_list.toString() == "[CharLinkedList of size 6 <<fabcde>>]");
}

// insertAt test
// Tests correct insertion into an empty AL.
// Afterwards, size should be 1 and element at index 0
// should be the element we inserted.
void insertAt_empty_correct() { 
    CharLinkedList test_list;
    test_list.insertAt('a', 0);
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');

}

// Tests incorrect insertion into an empty AL.
// Attempts to call insertAt for index larger than 0.
// This should result in an std::range_error being raised.
void insertAt_empty_incorrect() {

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    // insertAt for out-of-range index
    test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
    // if insertAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    range_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0]");
    
}

// Tests correct insertAt for front of 1-element list.
void insertAt_front_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at front
    test_list.insertAt('b', 0);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'a');
    
}

// Tests correct insertAt for back of 1-element list.
void insertAt_back_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at back
    test_list.insertAt('b', 1);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    
}

// Tests calling insertAt for a large number of elements.
// Not only does this test insertAt, it also checks that
// linked expansion works correctly.
void insertAt_many_elements() {
    
    CharLinkedList test_list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.insertAt('a', i);
    }

    assert(test_list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
    
}

// Tests insertion into front of a larger list
void insertAt_front_large_list() {
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    test_list.insertAt('y', 0);

    assert(test_list.size() == 10);
    assert(test_list.elementAt(0) == 'y');
    assert(test_list.toString() == 
           "[CharLinkedList of size 10 <<yabczdefgh>>]");

}

// Tests insertion into the back of a larger list
void insertAt_back_large_list() {

    char test_arr[10] = { 'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 10);  

    test_list.insertAt('x', 10);

    assert(test_list.size() == 11);
    assert(test_list.elementAt(10) == 'x');
    assert(test_list.toString() == 
    "[CharLinkedList of size 11 <<yabczdefghx>>]"); 

}

// Tests insertion into the middle of a larger list
void insertAt_middle_large_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.insertAt('z', 3);

    assert(test_list.size() == 9);
    assert(test_list.elementAt(3) == 'z');
    assert(test_list.toString() == "[CharLinkedList of size 9 <<abczdefgh>>]");

}

// Tests out-of-range insertion for a non-empty list.
void insertAt_nonempty_incorrect() {
   
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8]");
    
}

// insertInOrder test
// Makes sure insertInOrder adds a char when called from a linked list with no 
// elements
void insertInOrder_noElements() {
    CharLinkedList test_list;
    test_list.insertInOrder('a');
    assert(test_list.toString() == "[CharLinkedList of size 1 <<a>>]");
}

// Makes sure insertInOrder correctly inserts a char when called from a linked
// list with one element
void insertInOrder_oneElement() {
    CharLinkedList test_list('a');
    test_list.insertInOrder('b');
    assert(test_list.toString() == "[CharLinkedList of size 2 <<ab>>]");
}

// Makes sure insertInOrder correctly inserts a char when called from a linked
// list containing multiple elements
void insertInOrder_multipleElements() {
    char arr[5] = {'a', 'b', 'd', 'e', 'f'};
    CharLinkedList test_list(arr, 5);
    test_list.insertInOrder('c');
    assert(test_list.toString() == "[CharLinkedList of size 6 <<abcdef>>]");
}

// Makes sure insertInOrder correctly inserts a char when called from a linked
// list containing symbols
void insertInOrder_symbols() {
    char arr[10] = {'!', '#', '&', '(', ')', '*', '+', '-', '.'};
    CharLinkedList test_list(arr, 9); 
    test_list.insertInOrder('%');
    assert(test_list.toString() == 
           "[CharLinkedList of size 10 <<!#%&()*+-.>>]");  
}

// popFromFront test
// Makes sure an std::runtime_error is thrown when popFromFront is called from
// a linked list with no elements
void popFromFront_noElements() {
    CharLinkedList test_list;

    bool runtime_error_thrown = false;

    std::string error_message = "";

    try {
        test_list.popFromFront();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

// Makes sure popFromFront removes the element when called from a linked list
// containing one element
void popFromFront_oneElement() {
    CharLinkedList test_list('a');
    test_list.popFromFront();
    assert(test_list.toString() == "[CharLinkedList of size 0 <<>>]");
}

// Makes sure popFromFront removes the first element when called from a linked
// list containing multiple elements
void popFromFront_multipleElements() {
    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList test_list(arr, 5);
    test_list.popFromFront();
    assert(test_list.toString() == "[CharLinkedList of size 4 <<bcde>>]");
}

// popFromBack test
// Makes sure an std::runtime_error is thrown when popFromBack is called from
// a linked list with no elements
void popFromBack_noElements() {
    CharLinkedList test_list;

    bool runtime_error_thrown = false;

    std::string error_message = "";

    try {
        test_list.popFromBack();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

// Makes sure popFromBack removes the element when called from a linked list
// containing one element
void popFromBack_oneElement() {
    CharLinkedList test_list('a');
    test_list.popFromBack();
    assert(test_list.toString() == "[CharLinkedList of size 0 <<>>]");
}

// Makes sure popFromBack removes the last element when called from a linked
// list containing multiple elements
void popFromBack_multipleElements() {
    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList test_list(arr, 5);
    test_list.popFromBack();
    assert(test_list.toString() == "[CharLinkedList of size 4 <<abcd>>]");
}

// removeAt test
// Makes sure removeAt throws an std::range_error when called from an empty 
// linked list
void removeAt_noElements() {
    CharLinkedList test_list;

    bool range_error_thrown = false;

    std::string error_message = "";

    try {
        test_list.removeAt(5);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (5) not in range [0..0)");
}

// Makes sure removeAt removes the element at the 0th index when called from a 
// linked list containing one element
void removeAt_oneElement() {
    CharLinkedList test_list('a');
    test_list.removeAt(0);
    assert(test_list.toString() == "[CharLinkedList of size 0 <<>>]");
}

// Makes sure removeAt removes the element at the specified index when called
// from a linked list containing multiple elements 
void removeAt_multipleElements() {
    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList test_list(arr, 5);
    test_list.removeAt(3);
    assert(test_list.toString() == "[CharLinkedList of size 4 <<abce>>]"); 
}

// replaceAt test
// Makes sure replaceAt throws an std::range_error when called from an empty
// linked list
void replaceAt_noElements() {
    CharLinkedList test_list;

    bool range_error_thrown = false;

    std::string error_message = "";

    try {
        test_list.replaceAt('a', 5);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (5) not in range [0..0)");
}

// Makes sure replaceAt replaces the element at the specified index with the 
// given char when called from a linked list containing one element
void replaceAt_oneElement() {
    CharLinkedList test_list('a');
    test_list.replaceAt('b', 0);
    assert(test_list.toString() == "[CharLinkedList of size 1 <<b>>]");
}

// Makes sure replaceAt replaces the element at the specified index with the 
// given char when called from a linked list containing multiple elements
void replaceAt_multipleElements() {
    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList test_list(arr, 5);
    test_list.replaceAt('!', 1);
    assert(test_list.toString() == "[CharLinkedList of size 5 <<a!cde>>]");
}

// concatenate test
// Makes sure concatenate adds the given linked list when called from an empty
// linked list
void concatenate_noElements() {
    CharLinkedList test_list;
    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList add(arr, 5);
    test_list.concatenate(&add);
    assert(test_list.toString() == "[CharLinkedList of size 5 <<abcde>>]");
}

// Makes sure concatenate adds the given linked list when called from a linked
// list containing one element
void concatenate_oneElement() {
    CharLinkedList test_list('a');
    char arr[5] = {'a', 'b', 'c', 'd', 'e'}; 
    CharLinkedList add(arr, 5);
    test_list.concatenate(&add);
    assert(test_list.toString() == "[CharLinkedList of size 6 <<aabcde>>]");
}

// Makes sure concatenate adds the given linked list when called from a linked 
// list containing multiple elements
void concatenate_multipleElements() {
    char arr1[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList test_list(arr1, 5);
    char arr2[10] = {'q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p'};
    CharLinkedList add(arr2, 10);
    test_list.concatenate(&add);
    assert((test_list.toString() == 
            "[CharLinkedList of size 15 <<abcdeqwertyuiop>>]"));
}

// Makes sure the linked list concatenate it called from concatenates with 
// itself when passed itself 
void concatenate_sameList() {
    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList test_list(arr, 5);
    test_list.concatenate(&test_list);
    assert(test_list.toString() == 
           "[CharLinkedList of size 10 <<abcdeabcde>>]");
}
 
// Makes sure concatenate does not change the linked list it is called from when
// given an empty linked list to add
void concatenate_addEmptyList() {
    CharLinkedList test_list;
    CharLinkedList add;
    test_list.concatenate(&add);
    assert(test_list.toString() == "[CharLinkedList of size 0 <<>>]");
}

// Makes sure concatenate does not change the linked list it was called from 
// when given an empty list to add
void concatenate_addEmptyListToOneElement() {
    CharLinkedList test_list('a');
    CharLinkedList add;
    test_list.concatenate(&add);
    assert(test_list.toString() == "[CharLinkedList of size 1 <<a>>]");
}


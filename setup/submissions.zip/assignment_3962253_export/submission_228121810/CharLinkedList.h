/*
 *  CharLinkedList.h
 *  Hannah Fiarman
 *  1/30/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  CharLinkedList is a doubly linked list class that can store, access, and
 *  remove data of type character through its various methods. It is also
 *  able to retrieve data regarding the list such as its size and whether it
 *  is empty or not. It is also capable of merging two separate CharLinkedLists
 *  into one given list.
 * 
 *  An instance of this class can either be created as an empty list, a list
 *  with one character, or a list created based on a character array provided.
 *
 */

#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H

#include <string>
#include <sstream>
#include <stdexcept>

class CharLinkedList {

public:
    //Constructors
    CharLinkedList();
    CharLinkedList(char c);
    CharLinkedList(char arr[], int size);
    CharLinkedList(const CharLinkedList &other);

    // //Destructor
    ~CharLinkedList();

    //Assignment Operator
    CharLinkedList &operator=(const CharLinkedList &other);

    bool isEmpty() const;
    void clear();
    int size() const;
    char first() const;
    char last() const;
    char elementAt(int index) const;

    std::string toString() const;
    std::string toReverseString() const;

    void pushAtBack(char c);
    void pushAtFront(char c);

    void insertAt(char c, int index);
    void insertInOrder(char c);

    void popFromFront();
    void popFromBack();

    void removeAt(int index);
    void replaceAt(char c, int index);

    void concatenate(CharLinkedList *other);

private:
    struct Node {
        char data;
        Node *previous;
        Node *next;
    };

    Node *front;
    Node *back;
    int numChars;

    // //helper functions
    Node *newNode(char newData, Node *previous, Node *next);
    void recycleList(Node *curr);
    Node *locate(int index, int count, Node *curr_node) const;
    void deepCopy(const CharLinkedList &other);
    
    //exception error message creators
    std::string rangeError(int IDX, int SIZE) const;
    std::string rangeErrorInclusive(int IDX, int SIZE) const;
};

#endif

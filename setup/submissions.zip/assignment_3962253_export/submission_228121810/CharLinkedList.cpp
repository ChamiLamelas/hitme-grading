/*
 *  CharLinkedList.cpp
 *  Hannah Fiarman
 *  1/30/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  This file contains the implementation of the CharLinkedList class.
 *
 */

#include "CharLinkedList.h"

/*
 * name:        CharLinkedList default constructor
 * purpose:     Initializes an empty CharLinkedList
 * arguments:   none
 * returns:     none
 * effects:     sets numChars to 0 and the front and back node pointers to 
 *              nullptr
 */
CharLinkedList::CharLinkedList() {
    front = nullptr;
    back = nullptr;
    numChars = 0;
}

/*
 * name:        CharLinkedList second constructor
 * purpose:     Initializes a one element CharLinkedList
 * arguments:   Character c that is the character stored in the one element list
 * returns:     none
 * effects:     sets numChars to 1 and the front and back node pointers to 
 *              the address of the new node created
 */
CharLinkedList::CharLinkedList(char c) {
    front = newNode(c, nullptr, nullptr);
    back = front;
    numChars = 1;
}

/*
 * name:        CharLinkedList third constructor
 * purpose:     Initializes a CharLinkedList based on a pre-existing array
 * arguments:   Character arr[] is the pre-existing array that the list will 
 *              be based on in creation and int size is the size of the list
 * returns:     none
 * effects:     sets numChars to size, front and back pointers to the first and
 *              last nodes respectively, and fills the linked list with nodes
 *              based on the array
 */
CharLinkedList::CharLinkedList(char arr[], int size) {
    //creates the first node of the list
    front = newNode(arr[0], nullptr, nullptr);

    Node *pastNode = front;
    int count = 1;
    
    //creates new nodes until array has been transferred, setting the previous
    //node's next to the address of the new node, then updating pastNode for
    //the next loop iteration
    while (count < size) {
        Node *created = newNode(arr[count], pastNode, nullptr);
        
        pastNode->next = created;
        pastNode = created;

        count++;
    }

    back = pastNode;
    numChars = size;
}

/*
 * name:        CharLinkedList copy constructor
 * purpose:     Creates a new instance of deep copy of a pre-existing linked 
 *              list
 * arguments:   A referenced linked list other that refers to the linked list
 *              being used as a base for the copy
 * effects:     Creates a new deep copy character linked list instance
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other) {
    //edge case if copying an empty list
    if (other.isEmpty()) {
        front = nullptr;
        back = nullptr;
        numChars = 0;
        return;
    }
    
    //creates the first node of the deep copy list
    front = newNode(other.elementAt(0), nullptr, nullptr);
    numChars = other.numChars;

    //creates the other nodes for copied list
    deepCopy(other);
}

/*
 * name:        CharLinkedList destructor
 * purpose:     Frees the memory associated with the character linked list
 * arguments:   none
 * returns:     none
 * effects:     frees the dynamically allocated memory on the heap for the list
 */
CharLinkedList::~CharLinkedList() {
    recycleList(front);
}

CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other) {
    //checks if Linked Lists are already the same
    if (this == &other) {
        return *this;
    }

    clear();
    numChars = other.numChars;

    //edge case if list is empty
    if (other.isEmpty()) {
        front = nullptr;
        back = nullptr;
        return *this;
    }

    front = newNode(other.elementAt(0), nullptr, nullptr);

    //creates other nodes for copied list
    deepCopy(other);

    //returns deep copy
    return *this;
}

/*
 * name:        isEmpty
 * purpose:     Determines if a given list is empty or not
 * arguments:   none
 * returns:     a boolean that is true if the list is indeed empty or false if
 *              is not
 * effects:     none
 */
bool CharLinkedList::isEmpty() const {
    if (numChars == 0) {
        return true;

    } else {
        return false;
    }
}

/*
 * name:        clear
 * purpose:     To create an instance of a Linked List into an empty one
 * arguments:   none
 * returns:     none
 * effects:     Recycles all of the memory of the old linked list (deleting all
 *              of the pre-established nodes), sets the front/back pointers to
 *              nullptr, and sets numChars to 0
 */
void CharLinkedList::clear() {
    recycleList(front);
    
    front = nullptr;
    back = nullptr;
    numChars = 0;
}

/*
 * name:        size
 * purpose:     a getter to retrieve the size of the linked list
 * arguments:   none
 * returns:     an integer value representing the size of the list
 * effects:     none
 */
int CharLinkedList::size() const {
    return numChars;
}

/*
 * name:        first
 * purpose:     to retrieve the first character stored in the list
 * arguments:   none
 * returns:     a character that is the character stored in the first node on 
 *              the list
 * effects:     none
 */
char CharLinkedList::first() const {
    //checks if list is empty and thus an error needs to be thrown
    if (isEmpty()) {
        throw std::runtime_error("cannot get first of empty LinkedList");
    }

    return front->data;
}

/*
 * name:        last
 * purpose:     to retrieve the last character stored in the list
 * arguments:   none
 * returns:     a character that is the character stored in the last node on 
 *              the list
 * effects:     none
 */
char CharLinkedList::last() const {
    //checks if list is empty and thus an error needs to be thrown
    if (isEmpty()) {
        throw std::runtime_error("cannot get last of empty LinkedList");
    }

    return back->data;
}

/*
 * name:        elementAt
 * purpose:     Retrieves a character in a given index of the linked list
 * arguments:   integer representing the location of the character desired
 * returns:     the character requested by the user
 * effects:     Throws a range_error if an invalid index is requested
 */
char CharLinkedList::elementAt(int index) const {
    //checks for valid index
    if (index < 0 or index >= numChars) {
        throw std::range_error(rangeError(index, numChars));
    }

    //retrieves the character from the desired index
    return (locate(index, 0, front))->data;
}

/*
 * name:        toString
 * purpose:     converts the linked list into a string
 * arguments:   none
 * returns:     the string containing the size of the linked list and the 
 *              characters contained within it
 * effects:     none
 */
std::string CharLinkedList::toString() const {
    //creates stringstream for formatting the toString message
    std::stringstream fullString;
    fullString << "[CharLinkedList of size " << numChars << " <<";

    //creates node pointer to iterate through the list
    Node *curr = front;

    //iterates through the list until the last node
    while (curr != nullptr) {
        fullString << curr->data;
        curr = curr->next;
    }

    fullString << ">>]";
    return fullString.str();
}

/*
 * name:        toReverse
 * purpose:     converts the linked list into a string with the characters
 *              in reverse
 * arguments:   none
 * returns:     the string containing the size of the linked list and the 
 *              characters contained within it, displayed in reverse
 * effects:     none
 */
std::string CharLinkedList::toReverseString() const {
    //creates stringstream for formatting the toReverseString message
    std::stringstream fullString;
    fullString << "[CharLinkedList of size " << numChars << " <<";

    //creates node pointer to iterate through the list
    Node *curr = back;

    //iterates through the list until the last node
    while (curr != nullptr) {
        fullString << curr->data;
        curr = curr->previous;
    }

    fullString << ">>]";
    return fullString.str();
}

/*
 * name:        pushAtBack
 * purpose:     inserts a new element at the back of the linked list
 * arguments:   Character c that is the character to be added to the linked list
 * returns:     none
 * effects:     Reassigns the back's pointer location to the new node (and 
 *              front if it is the first node), reassigns the original back 
 *              pointer's next to the new node, increments numChars by 1
 */
void CharLinkedList::pushAtBack(char c) {
    //edge-case if called on empty list
    if (front == nullptr) {
        front = newNode(c, nullptr, nullptr);
        back = front;

        numChars++;
        return;
    }

    Node *addition = newNode(c, back, nullptr);

    //re-assigns the original back's pointer and back's pointer
    back->next = addition;
    back = addition;

    numChars++;
}

/*
 * name:        pushAtFront
 * purpose:     inserts a new element at the front of the linked list
 * arguments:   Character c that is the character to be added to the linked list
 * returns:     none
 * effects:     Reassigns the front's pointer location to the new node (and 
 *              back if it is the first node), reassigns the original front
 *              pointer's previous to the new node, increments numChars by 1
 */
void CharLinkedList::pushAtFront(char c) {
    //edge-case if called on empty list
    if (front == nullptr) {
        front = newNode(c, nullptr, nullptr);
        back = front;
        
        numChars++;
        return;
    }

    Node *addition = newNode(c, nullptr, front);

    //re-assigns the original front's pointer and front's pointer
    front->previous = addition;
    front = addition;

    numChars++;
}

/*
 * name:        insertAt
 * purpose:     inserts a new element in a given index of the linked list
 * arguments:   Character c that is the character to be added to the linked list
 *              and integer index that is where the character is to be added
 * returns:     none
 * effects:     Adds a new node with character c to the list, updates numChars
 *              by 1, and updates the front/back pointers (when applicable)
 */
void CharLinkedList::insertAt(char c, int index) {
    //checks for proper index
    if (index < 0 or index > numChars) {
        throw std::range_error(rangeErrorInclusive(index, numChars));
    }
    //edge-case if called on empty list
    if (front == nullptr) {
        front = newNode(c, nullptr, nullptr);
        back = front;
        numChars++;
        return;
    //edge-case if adding to front/back of list
    } else if (index == 0) {
        pushAtFront(c);
        return;
    } else if (index == numChars) {
        pushAtBack(c);
        return;
    }

    //find the node before the index of the desired insertion and creates the
    //new node based on it
    Node *insertionNode = locate(index - 1, 0, front);
    Node *addition = newNode(c, insertionNode, insertionNode->next);
    numChars++;

    //updates next/previous pointers for nodes next to the new node
    insertionNode->next->previous = addition;
    insertionNode->next = addition;
}

/*
 * name:        insertInOrder
 * purpose:     inserts a new element in the linked list in ASCII order
 * arguments:   Character c that is the character to be added to the linked list
 * returns:     none
 * effects:     Adds a new node with character c to the list according to ASCII
 *              order, updates numChars by 1, and updates the front/back 
 *              pointers (when applicable)
 */
void CharLinkedList::insertInOrder(char c) {
    //variables to assist in locating where in order "c" should go
    Node *curr = front;
    int index = 0;
    bool looking = true;

    //iterates through the list to find where to put "c"
    while (looking and curr != nullptr) {
        if (c <= curr->data) {
            looking = false;
        } else {
            curr = curr->next;
            index++;
        }
    }

    insertAt(c, index);
}

/*
 * name:        popFromFront
 * purpose:     removes the first element of the linked list
 * arguments:   none
 * returns:     none
 * effects:     re-assigns the front (and when applicable back) pointer to the 
 *              updated address for the list, subtracts 1 from the list size
 *              clears the memory of the old front node, and (when applicable)
 *              throws a runtime error if called on an empty list
 */
void CharLinkedList::popFromFront() {
    //checks if list is empty
    if (isEmpty()) {
        throw std::runtime_error("cannot pop from empty LinkedList");
    }

    //edge-case if list has 1 element
    if (numChars == 1) {
        delete front;
        numChars--;

        front = nullptr;
        back = nullptr;
        return;
    }

    //updates the first node of the list and reassigns its next/previous
    Node *oldFront = front;
    front = oldFront->next;
    front->previous = nullptr;
    
    //clears off the original front node from memory and the list
    delete oldFront;
    numChars--;
}

/*
 * name:        popFromBack
 * purpose:     removes the last element of the linked list
 * arguments:   none
 * returns:     none
 * effects:     re-assigns the back (and when applicable front) pointer to the 
 *              updated address for the list, subtracts 1 from the list size
 *              clears the memory of the old back node, and (when applicable)
 *              throws a runtime error if called on an empty list
 */
void CharLinkedList::popFromBack() {
    //checks if list is empty
    if (isEmpty()) {
        throw std::runtime_error("cannot pop from empty LinkedList");
    }

    //edge-case if list has 1 element
    if (numChars == 1) {
        delete back;
        numChars--;

        front = nullptr;
        back = nullptr;
        return;
    }

    //updates the last node of the list and reassigns its next/previous
    Node *oldBack = back;
    back = oldBack->previous;
    back->next = nullptr;
    
    //clears off the original back node from memory and the list
    delete oldBack;
    numChars--;
}

/*
 * name:        removeAt
 * purpose:     removes a given indictated element in the linked list
 * arguments:   integer index which is the location of the element to be removed
 * returns:     none
 * effects:     throws a range error if invalid index, subtracts 1 from list
 *              size, updates the pointers near the removed element (including 
 *              front/back when applicable), and deletes the memory associated
 *              with the removed node
 */
void CharLinkedList::removeAt(int index) {
    //checks for valid index
    if (index < 0 or index >= numChars) {
        throw std::range_error(rangeError(index, numChars));
    }
    //edge case for 1 element list
    if (numChars == 1) {
        delete front;
        front = nullptr;
        back = nullptr;
        numChars--;
        return;
    //edge cases if called on front/back of list
    } else if (index == 0) {
        popFromFront();
        return;
    } else if (index == numChars - 1) {
        popFromBack();
        return;
    }
    
    //find the node that to be removed, and update its neighboring node's
    //pointers to point at each other
    Node *oldNode = locate(index, 0, front);
    oldNode->previous->next = oldNode->next;
    oldNode->next->previous = oldNode->previous;

    delete oldNode;
    numChars--;
}

/*
 * name:        replaceAt
 * purpose:     replaces a given element in the list with a new value
 * arguments:   Character c which is the updated element to be replaced at
 *              integer index
 * returns:     none
 * effects:     throws range error if invalid index and updates the data of the
 *              node at the desired index with the new character value c
 */
void CharLinkedList::replaceAt(char c, int index) {
    //checks for valid index
    if (index < 0 or index >= numChars) {
        throw std::range_error(rangeError(index, numChars));
    }
    
    //finds the location of the replacement node and updates its data
    Node *location = locate(index, 0, front);
    location->data = c;
}

/*
 * name:        concatenate
 * purpose:     to add the elements of one linked list to the back of the list
 *              that this method was called in
 * arguments:   A CharLinkedList pointer other that contains the address to the
 *              list who's elements will be added
 *              added to the 
 * returns:     none
 * effects:     increases numChars by the size of other, adds all of the data
 *              from list other to the original list, and updates the back
 *              pointer
 * 
 */
void CharLinkedList::concatenate(CharLinkedList *other) {
    //helper function when transfering elements to first list
    Node *curr = back;

    //for-loop to copy list2's elements to list 1
    for (int i = 0; i < other->numChars; i++) {
        //edge-case for if this is the first node being added to the list
        if (curr == nullptr) {
            front = newNode(other->elementAt(i), nullptr, nullptr);
            curr = front;
            continue;
        }
        
        Node *addition = newNode(other->elementAt(i), curr, nullptr);
        curr->next = addition;
        curr = addition;
    }

    back = curr;
    numChars = numChars + other->numChars;
}

/*
 * name:        newNode
 * purpose:     Helper function to create a new node to be added to the linked 
 *              list
 * arguments:   a character newData that contains the character to be stored in
 *              the node, and two Node pointers that indicate what the new
 *              node will point to in the linked list (the previous and next
 *              nodes next to it)
 * returns:     the address to the newly created node
 * effects:     none
 */
CharLinkedList::Node *CharLinkedList::newNode(char newData, Node *previous, 
                                                Node *next) {
    Node *newNode = new Node;
    newNode->data = newData;
    newNode->previous = previous;
    newNode->next = next;

    return newNode;
}

/*
 * name:        recycleList
 * purpose:     Helper function to recycle the heap-allocated data from the 
 *              nodes of the linked list
 * arguments:   a pointer to a node on the linked list
 * returns:     none
 * effects:     deletes each node (when applicable) in the linked list,
 *              recycling their dynamically-allocated memory
 */
void CharLinkedList::recycleList(Node *curr) {
    // base case
    if (curr == nullptr) {
        return;

    // recursive case
    } else {
        Node *next = curr->next;
        delete curr;
        recycleList(next);
    }
}

/*
 * name:        locate
 * purpose:     Helper function to get the address of a given node in the list
 * arguments:   A node pointer pointing to a given node in the list (as it
 *              cycles through it) and integers representing the index of the 
 *              node being sought after and a count to keep track of the 
 *              position in the linked list that is currently being looked at
 * returns:     a Node pointer to the desired node in the list
 * effects:     none
 */
CharLinkedList::Node *CharLinkedList::locate(int index, int count, 
                                            Node *curr) const {
    if (count == index) {
        return curr;

    } else {
        count++;
        Node *next = curr->next;
        return locate(index, count, next);
    }
}

/*
 * name:        deepCopy
 * purpose:     helper method to create the other nodes after the first node
 *              when performing a deep copy of some linked list
 * arguments:   A referenced linked list other that refers to the linked list
 *              being used as a base for the copy
 * returns:     none
 * effects:     Creates the other nodes on the list based on the nodes in 
 *              other's linked list (when applicable) and updates the back
 *              pointer
 */
void CharLinkedList::deepCopy(const CharLinkedList &other) {
    //helper variables in creating the copy
    Node *curr = front;
    int count = 1;

    //creates deep copied nodes of the other linked list
    while (count < numChars) {
        Node *created = newNode(other.elementAt(count), curr, nullptr);
        curr->next = created;
        curr = created;

        count++;
    }

    //sets back pointer
    back = curr;
}

/*
 * name:      rangeError
 * purpose:   to create a range error message not including the size of the
 *            linked list in the acceptable range
 * arguments: integer IDX which is the index that was requested for a given
 *            method and integer SIZE which is the current size of the linked
 *            list
 * returns:   a string containing the range error message not including
 *            size in the range
 * effects:   none
 */
std::string CharLinkedList::rangeError(int IDX, int SIZE) const {
    //variable to store range error message being created
    std::string message = "index (" + std::to_string(IDX) + ") not in range "
                            "[0.." + std::to_string(SIZE) + ")";

    return message;
}

/*
 * name:      rangeErrorInclusive
 * purpose:   to create a range error message including the size of the linked
 *            list in the acceptable range
 * arguments: integer IDX which is the index that was requested for a given
 *            method and integer SIZE which is the current size of the link
 *            list
 * returns:   a string containing the range error message including
 *            size in the range
 * effects:   none
 */
std::string CharLinkedList::rangeErrorInclusive(int IDX, int SIZE) const {
    //variable to store range error message being created
    std::string message = "index (" + std::to_string(IDX) + ") not in range "
                            "[0.." + std::to_string(SIZE) + "]";

    return message;
}

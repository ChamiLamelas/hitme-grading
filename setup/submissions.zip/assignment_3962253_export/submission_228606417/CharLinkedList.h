/*
 *  CharLinkedList.h
 *  KIRK HASKELL
 *  2/3/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  This file contains the defanition of the CharLinkedList class, a dobubly 
 *  linked list containing chars as its elements.
 *
 */

#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H

#include <stdexcept>

class CharLinkedList {
    private:
        struct Node {
            char data;
            Node* next;
            Node* prev;

            // Typical constructor
            Node(char c) {
                data = c;
                next = nullptr;
                prev = nullptr;
            }
            Node(char c, Node* nnext, Node* pprev){
                data = c;
                next = nnext;
                prev = pprev;
            }
        };

        Node* head;
        Node* tail;
        int listSize;

        // Private recursive helper functions
        void copyList(Node* otherHead); 
        char getRecursive(Node* node, int index) const;
        void replaceRecursive(Node* node, char c, int index);
        

        std::string toReverseStringRecursive(Node* node) const;
        
    public:
        // Constructors
        CharLinkedList();
        CharLinkedList(char c); 
        CharLinkedList(char arr[], int size); 
        CharLinkedList(const CharLinkedList &other); 

        ~CharLinkedList(); 

        CharLinkedList& operator=(const CharLinkedList &other); 

        //big boy public funcitons and sheet
        bool isEmpty() const;  
        void clear();  
        int size() const; 
        char first() const; 
        char last() const; 
        char elementAt(int index) const;
        //to string stuff and all that la
        std::string toString() const; 
        std::string toReverseString() const;  
        void pushAtBack(char c);  
        void pushAtFront(char c);
        void insertAt(char c, int index);
        void insertInOrder(char c);
        void popFromFront();
        void popFromBack();
        void removeAt(int index);
        void replaceAt(char c, int index);
        void concatenate(CharLinkedList *other);
};

#endif

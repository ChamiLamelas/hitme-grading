/*
 *  unit_tests.h
 *  KIRK HASKELL
 *  2/3/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  This file is a unit test file for the charLinkedList file. Each void 
 * function runs as its own test and has an assert at the end of it.
 *
 */
#include <iostream>
#include <cassert>
#include <string>
#include "CharLinkedList.h"


//inputs: None
//Description: Tests the default constructor of CharLinkedList class.
//Outputs: None
void testDefaultConstructor() {
    // Create a CharLinkedList instance using the default constructor
    CharLinkedList list;

    // Test if the list is initially empty
    assert(list.isEmpty());
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}

//inputs: none
//Description: Tests the single character constructor of CharLinkedList class.
//Outputs: None
void testSingleCharConstructor() {
    // Create a CharLinkedList instance using the single char constructor
    CharLinkedList list('A');

    // Test if the list contains the single character 'A'
    assert(!list.isEmpty());
    assert(list.toString() == "[CharLinkedList of size 1 <<A>>]");
}

//inputs: None
//Description: Tests the array constructor of CharLinkedList class.
//Outputs: None
void testArrayConstructor() {
    // Create an array of characters
    char arr[] = {'A', 'B', 'C', 'D', 'E'};

    // Create a CharLinkedList instance using the array constructor
    CharLinkedList list(arr, 5);

    // Test if the list contains all elements from the array
    assert(!list.isEmpty());
    assert(list.toString() == "[CharLinkedList of size 5 <<ABCDE>>]");
}

//inputs: None
//Description: Tests the copy constructor of CharLinkedList class.
//Outputs: None
void testCopyConstructor() {
    // Create a CharLinkedList instance and populate it with elements
    CharLinkedList original;
    original.pushAtBack('A');
    original.pushAtBack('B');
    original.pushAtBack('C');

    // Create a new CharLinkedList instance using the copy constructor
    CharLinkedList copy(original);

    // Test if the copy contains the same elements as the original
    assert(!copy.isEmpty());
    assert(copy.toString() == "[CharLinkedList of size 3 <<ABC>>]");
}
// Input: N/A
// Description: Tests the toString() method of the CharLinkedList class by 
//              creating a list, pushing characters 'A', 'l', 'i', 'c', 'e' to
//               it, and then checks if the string representation matches the 
//               expected value.
// Output: N/A

void testToString() {
    CharLinkedList list;
    list.pushAtBack('A');
    list.pushAtBack('l');
    list.pushAtBack('i');
    list.pushAtBack('c');
    list.pushAtBack('e');
    assert(list.toString() == "[CharLinkedList of size 5 <<Alice>>]");
    
}

//inputs: None
//Description: Tests the pushAtBack function of the CharLinkedList class by 
//              pushing elements to the back of the list and asserting the 
//              resulting string representation.
//outputs: None
void testPushAtBack() {
    // Create a CharLinkedList instance
    CharLinkedList list;

    // Push elements to the back of the list
    list.pushAtBack('A');
    assert(list.toString() == "[CharLinkedList of size 1 <<A>>]");

    list.pushAtBack('B');
    assert(list.toString() == "[CharLinkedList of size 2 <<AB>>]");

    list.pushAtBack('C');
    assert(list.toString() == "[CharLinkedList of size 3 <<ABC>>]");
}

//inputs: None
//Description: Tests the isEmpty and clear functions of the CharLinkedList 
//              class by creating an instance, checking if it's initially 
//              empty, pushing elements, checking if it's non-empty, 
//              clearing the list, and checking if it's empty again.
//outputs: None
void testClearAndIsEmpty() {
    // Create a CharLinkedList instance
    CharLinkedList list;

    // Test isEmpty on an empty list
    assert(list.isEmpty());

    // Push elements to the list
    list.pushAtBack('A');
    list.pushAtBack('B');
    list.pushAtBack('C');

    // Test isEmpty on a non-empty list
    assert(!list.isEmpty());

    // Clear the list and test isEmpty again
    list.clear();
    assert(list.isEmpty());
}

//inputs: None
//Description: Tests the size function of the CharLinkedList class by 
//              creating an instance, checking the size on an empty list,
//               pushing elements, and checking the size on a non-empty list.
//outputs: None
void testSize() {
    // Create a CharLinkedList instance
    CharLinkedList list;

    // Test size on an empty list
    assert(list.size() == 0);

    // Push elements to the list
    list.pushAtBack('A');
    list.pushAtBack('B');
    list.pushAtBack('C');

    // Test size on a non-empty list
    assert(list.size() == 3);
}

//inputs: None
//Description: Tests the first function of the CharLinkedList class by 
//              creating an instance, attempting to get the first element
//               on an empty list (expects an exception), pushing elements, 
//              and getting the first element on a non-empty list.
//outputs: None
void testFirst() {
    // Create a CharLinkedList instance
    CharLinkedList list;

    // Test first on an empty list
    try {
        list.first();
        // If we reach here, the test has failed
        assert(false);
    } catch (const std::runtime_error& e) {
        // Check if the exception message is correct
        assert(e.what()==std::string("cannot get first of empty LinkedList"));
    }

    // Push elements to the list
    list.pushAtBack('A');
    list.pushAtBack('B');
    list.pushAtBack('C');

    // Test first on a non-empty list
    assert(list.first() == 'A');
}

//inputs: None
//Description: Tests the last function of the CharLinkedList class by 
//              creating an instance, attempting to get the last element
///              on an empty list (expects an exception), pushing elements,
//               and getting the last element on a non-empty list.
//outputs: None
void testLast() {
    // Create a CharLinkedList instance
    CharLinkedList list;

    // Test last on an empty list
    try {
        list.last();
        // If we reach here, the test has failed
        assert(false);
    } catch (const std::runtime_error& e) {
        // Check if the exception message is correct
        assert(e.what() == std::string("cannot get last of empty LinkedList"));
    }

    // Push elements to the list
    list.pushAtBack('A');
    list.pushAtBack('B');
    list.pushAtBack('C');

    // Test last on a non-empty list
    assert(list.last() == 'C');
}

//inputs: None
//Description: Tests the elementAt function of the CharLinkedList class by
//               creating an instance, pushing elements to the list, and 
//              accessing elements at valid and out-of-range indices, 
//             expecting the correct values or exceptions.
//outputs: None
void testElementAt() {
    // Create a CharLinkedList instance
    CharLinkedList list;

    // Push elements to the list
    list.pushAtBack('A');
    list.pushAtBack('B');
    list.pushAtBack('C');

    // Test valid indices
    assert(list.elementAt(0) == 'A');
    assert(list.elementAt(1) == 'B');
    assert(list.elementAt(2) == 'C');

    // Test out of range indices
    try {
        list.elementAt(-1);
        // If we reach here, the test has failed
        assert(false);
    } catch (const std::range_error& e) {
        // Check if the exception message is correct
        assert(e.what() == std::string("index (-1) not in range [0..3)"));
    }

    try {
        list.elementAt(3);
        // If we reach here, the test has failed
        assert(false);
    } catch (const std::range_error& e) {
        // Check if the exception message is correct
        assert(e.what() == std::string("index (3) not in range [0..3)"));
    }
}

//inputs: None
//Description: Tests the toReverseString function of the CharLinkedList class
//               by creating an instance, checking the reverse string 
//            representation on an empty list, pushing elements, and 
//          checking the reverse string representation on a non-empty list.
//outputs: None
void testToReverseString() {
    // Create a CharLinkedList instance
    CharLinkedList list;

    // Test toReverseString on an empty list
    assert(list.toReverseString() == "[CharLinkedList of size 0 <<>>]");

    // Push elements to the list
    list.pushAtBack('A');
    list.pushAtBack('B');
    list.pushAtBack('C');

    // Test toReverseString on a non-empty list
    assert(list.toReverseString() == "[CharLinkedList of size 3 <<CBA>>]");
}

//inputs: None
//Description: Tests the pushAtFront function of the CharLinkedList 
//          class by creating an instance and pushing elements at the 
//              front, asserting the resulting string representation.
//outputs: None
void testPushAtFront() {
    // Create a CharLinkedList instance
    CharLinkedList list;

    // Push 'A', 'B', 'C' at the front
    list.pushAtFront('A');
    assert(list.toString() == "[CharLinkedList of size 1 <<A>>]");

    list.pushAtFront('B');
    assert(list.toString() == "[CharLinkedList of size 2 <<BA>>]");

    list.pushAtFront('C');
    assert(list.toString() == "[CharLinkedList of size 3 <<CBA>>]");
}

//inputs: None
//Description: Tests the insertAt function of the CharLinkedList class
//           by creating an instance, pushing elements, and inserting 
//              characters at specific indices, asserting the resulting string
///             representation. Also tests inserting at an out-of-range index.
//outputs: None
void testInsertAt() {
    // Create a CharLinkedList instance
    CharLinkedList list;

    // Push elements to the list
    list.pushAtBack('A');
    list.pushAtBack('B');
    list.pushAtBack('C');

    // Insert 'X' at index 1
    list.insertAt('X', 1);
    assert(list.toString() == "[CharLinkedList of size 4 <<AXBC>>]");

    // Insert 'Y' at index 0
    list.insertAt('Y', 0);
    assert(list.toString() == "[CharLinkedList of size 5 <<YAXBC>>]");

    // Insert 'Z' at index 5
    list.insertAt('Z', 5);
    assert(list.toString() == "[CharLinkedList of size 6 <<YAXBCZ>>]");

    // Test out of range index
    try {
        list.insertAt('Z', 7);
        // If we reach here, the test has failed
        assert(false);
    } catch (const std::range_error& e) {
        // Check if the exception message is correct
        assert(e.what() == std::string("index (7) not in range [0..6]"));
    }
}

//inputs: None
//Description: Tests the insertInOrder function of the CharLinkedList 
//              class by creating an instance and inserting characters 
//              in random order, asserting the resulting string 
//              representation.
//outputs: None
void testInsertInOrder() {
    // Create a CharLinkedList instance
    CharLinkedList list;

    // Insert characters in random order
    list.insertInOrder('D');
    assert(list.toString() == "[CharLinkedList of size 1 <<D>>]");

    list.insertInOrder('B');
    assert(list.toString() == "[CharLinkedList of size 2 <<BD>>]");

    list.insertInOrder('F');
    assert(list.toString() == "[CharLinkedList of size 3 <<BDF>>]");

    list.insertInOrder('C');
    assert(list.toString() == "[CharLinkedList of size 4 <<BCDF>>]");

    list.insertInOrder('A');
    assert(list.toString() == "[CharLinkedList of size 5 <<ABCDF>>]");
}

//inputs: None
//Description: Tests the popFromFront function of the CharLinkedList class
//               by creating an instance, attempting to pop from an empty 
//              list (expects an exception), pushing elements, popping 
//              from the front, and asserting the resulting string
//               representation. Also tests popping when only one element
//               is left and attempting to pop from an empty
//               list again (expects an exception).
//outputs: None
void testPopFromFront() {
    // Create a CharLinkedList instance
    CharLinkedList list;

    // Try popping from an empty list (expect an exception)
    try {
        list.popFromFront();
        // If we reach here, the test has failed
        assert(false);
    } catch (const std::runtime_error& e) {
        // Check if the exception message is correct
        assert(std::string(e.what()) == "cannot pop from empty LinkedList");
    }

    // Push elements to the list
    list.pushAtBack('A');
    list.pushAtBack('B');
    list.pushAtBack('C');

    // Pop from the front
    list.popFromFront();
    assert(list.toString() == "[CharLinkedList of size 2 <<BC>>]");

    // Pop from the front again
    list.popFromFront();
    assert(list.toString() == "[CharLinkedList of size 1 <<C>>]");

    // Pop from the front when only one element is left
    list.popFromFront();
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");

    // Try popping from an empty list again (expect an exception)
    try {
        list.popFromFront();
        // If we reach here, the test has failed
        assert(false);
    } catch (const std::runtime_error& e) {
        // Check if the exception message is correct
        assert(std::string(e.what()) == "cannot pop from empty LinkedList");
    }
}

//inputs: None
//Description: Tests the popFromBack function of the CharLinkedList 
//              class by creating an instance, attempting to pop from an 
//              empty list (expects an exception), pushing elements, popping
//               from the back, and asserting the resulting string 
//              representation. Also tests popping when only one element 
//              is left and attempting to pop from an empty list again 
//              (expects an exception).
//outputs: None
void testPopFromBack() {
    // Create a CharLinkedList instance
    CharLinkedList list;

    // Try popping from an empty list (expect an exception)
    try {
        list.popFromBack();
        // If we reach here, the test has failed
        assert(false);
    } catch (const std::runtime_error& e) {
        // Check if the exception message is correct
        assert(std::string(e.what()) == "cannot pop from empty LinkedList");
    }

    // Push elements to the list
    list.pushAtBack('A');
    list.pushAtBack('B');
    list.pushAtBack('C');

    // Pop from the back
    list.popFromBack();
    assert(list.toString() == "[CharLinkedList of size 2 <<AB>>]");

    // Pop from the back again
    list.popFromBack();
    assert(list.toString() == "[CharLinkedList of size 1 <<A>>]");

    // Pop from the back when only one element is left
    list.popFromBack();
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");

    // Try popping from an empty list again (expect an exception)
    try {
        list.popFromBack();
        // If we reach here, the test has failed
        assert(false);
    } catch (const std::runtime_error& e) {
        // Check if the exception message is correct
        assert(std::string(e.what()) == "cannot pop from empty LinkedList");
    }
}

//inputs: None
//Description: Tests the removeAt function of the CharLinkedList class by
//               creating an instance, pushing elements, removing 
//              elements at specific indices, and asserting the 
//              resulting string representation. Also tests removing
//               an element at an out-of-range index (expects an exception).
//outputs: None
void testRemoveAt() {
    // Create a CharLinkedList instance
    CharLinkedList list;

    // Push elements to the list
    list.pushAtBack('A');
    list.pushAtBack('B');
    list.pushAtBack('C');
    list.pushAtBack('D');

    // Remove element at index 2 (should remove 'C')
    list.removeAt(2);
    assert(list.toString() == "[CharLinkedList of size 3 <<ABD>>]");

    // Remove element at index 0 (should remove 'A')
    list.removeAt(0);
    assert(list.toString() == "[CharLinkedList of size 2 <<BD>>]");

    // Remove element at index 1 (should remove 'D')
    list.removeAt(1);
    assert(list.toString() == "[CharLinkedList of size 1 <<B>>]");

    // Try removing element at index 1 again (expect an exception)
    try {
        list.removeAt(1);
        // If we reach here, the test has failed
        assert(false);
    } catch (const std::range_error& e) {
        // Check if the exception message is correct
        assert(std::string(e.what()) == "index (1) not in range [0..1)");
    }
}

//inputs: None
//Description: Tests the replaceAt function of the CharLinkedList
//               class by creating an instance, pushing elements,
//               replacing elements at specific indices, and 
//              asserting the resulting string representation. Also
//               tests replacing an element at an out-of-range index
//               (expects an exception).
//outputs: None
void testReplaceAt() {
    // Create a CharLinkedList instance
    CharLinkedList list;

    // Push elements to the list
    list.pushAtBack('A');
    list.pushAtBack('B');
    list.pushAtBack('C');
    list.pushAtBack('D');

    // Replace element at index 2 with 'X' (should replace 'C')
    list.replaceAt('X', 2);
    assert(list.toString() == "[CharLinkedList of size 4 <<ABXD>>]");

    // Replace element at index 0 with 'Z' (should replace 'A')
    list.replaceAt('Z', 0);
    assert(list.toString() == "[CharLinkedList of size 4 <<ZBXD>>]");

    // Replace element at index 3 with 'Y' (should replace 'D')
    list.replaceAt('Y', 3);
    assert(list.toString() == "[CharLinkedList of size 4 <<ZBXY>>]");

    //Try replacing element at index 4 
    //(index out of range, expect an exception)
    try {
        list.replaceAt('W', 4);
        // If we reach here, the test has failed
        assert(false);
    } catch (const std::range_error& e) {
        // Check if the exception message is correct
        assert(std::string(e.what()) == "index (4) not in range [0..4)");
    }
}

//inputs: None
//Description: Tests the concatenate function of the CharLinkedList 
//              class by creating two instances, pushing elements, 
//              concatenating them, and asserting the resulting string 
//              representation. Also tests concatenating with an empty list.
//outputs: None
void testConcatenate() {
    // Create two CharLinkedList instances
    CharLinkedList list1;
    list1.pushAtBack('c');
    list1.pushAtBack('a');
    list1.pushAtBack('t');

    CharLinkedList list2;
    list2.pushAtBack('C');
    list2.pushAtBack('H');
    list2.pushAtBack('E');
    list2.pushAtBack('S');
    list2.pushAtBack('H');
    list2.pushAtBack('I');
    list2.pushAtBack('R');
    list2.pushAtBack('E');

    // Concatenate list2 to list1
    list1.concatenate(&list2);

    // Check if list1 contains the concatenated elements
    std::string a ="[CharLinkedList of size 11 <<catCHESHIRE>>]"; 
    assert(list1.toString() == a);
    std::cout<<list1.toString()<<std::endl;
    // Concatenate list2 with itself
    list2.concatenate(&list2);
    std::cout<<list2.toString()<<std::endl;
    // Check if list2 contains the concatenated elements
    a= "[CharLinkedList of size 16 <<CHESHIRECHESHIRE>>]";
    assert(list2.toString() == a);
    std::cout<<list2.toString()<<std::endl;
    // Concatenate an empty list to list1
    CharLinkedList emptyList;
    list1.concatenate(&emptyList);

    // Check if list1 remains unchanged after concatenating an empty list
    a = "[CharLinkedList of size 11 <<catCHESHIRE>>]";
    assert(list1.toString() == a);
    std::cout<<list1.toString()<<std::endl;
    // Concatenate list1 with itself
    list1.concatenate(&list1);

    // Check if list1 contains the concatenated elements
    a = "[CharLinkedList of size 22 <<catCHESHIREcatCHESHIRE>>]";
    assert(list1.toString() == a);
    std::cout<<list1.toString()<<std::endl;
}
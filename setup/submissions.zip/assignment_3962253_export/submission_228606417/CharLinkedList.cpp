/*
 *  CharLinkedList.cpp
 *  KIRK HASKELL
 *  2/3/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  This file is the implementation of CharLinkedList class a linked list
 *  containing char characters.
 *
 */

#include "CharLinkedList.h"
#include <string>
#include <iostream>


// Function: copyList
// Inputs: otherHead - Describes input types and expectations on them
// Description: Clears the current linked list and copies elements 
//              from another list.
// Outputs: None
void CharLinkedList::copyList(Node* otherHead) {
    // Clear the current list
    clear();

    // Iterate through the other list and copy each element
    Node* currOther = otherHead;
    while (currOther != nullptr) {
        pushAtBack(currOther->data);
        currOther = currOther->next;
    }
    
}

// Function: getRecursive
// Inputs: node - Describes input types and expectations on them
//         index - Describes input types and expectations on them
// Description: Recursively retrieves the data at the specified 
//              index in the linked list.
// Outputs: The character data at the specified index.
char CharLinkedList::getRecursive(Node* node, int index) const {
    // Base case: reached the desired index
    if (index == 0) {
        return node->data;
    }

    // Recursive case: move to the next node and decrement index
    return getRecursive(node->next, index - 1);
}





// Constructor: CharLinkedList
// Inputs: None
// Description: Initializes an empty linked list.
// Outputs: None

CharLinkedList::CharLinkedList() {
    // Initialize an empty list
    head = nullptr;
    tail = nullptr;
    listSize = 0;
}

// Constructor: CharLinkedList
// Inputs: c - The character to create a linked list with
// Description: Creates a new linked list with a 
//              single node containing the given character.
// Outputs: None
CharLinkedList::CharLinkedList(char c) {
    // Create a new node with the given character
    Node* newNode = new Node(c);
    
    // Set head and tail to the new node
    head = newNode;
    tail = newNode;
    
    // Set list size to 1
    listSize = 1;
}

// Constructor: CharLinkedList
// Inputs: arr - An array of characters
//         size - The size of the array
// Description: Initializes a linked list and inserts 
//              each character from the array into the list.
// Outputs: None
CharLinkedList::CharLinkedList(char arr[], int size) {
    // Initialize an empty list
    head = nullptr;
    tail = nullptr;
    listSize = 0;

    // Insert each character from the array into the list
    for (int i = 0; i < size; ++i) {
        pushAtBack(arr[i]);
    }
}

// Copy Constructor: CharLinkedList
// Inputs: other - The CharLinkedList object to be copied
// Description: Initializes a new 
//              linked list as a deep copy of the provided CharLinkedList.
// Outputs: None
CharLinkedList::CharLinkedList(const CharLinkedList &other) {
    // Initialize an empty list
    head = nullptr;
    tail = nullptr;
    listSize = 0;

    // Use the assignment operator to perform deep copy
    *this = other;
}

// Destructor: ~CharLinkedList
// Inputs: None
// Description: Deallocates memory and resets pointers, clearing 
//              the linked list.
// Outputs: None
CharLinkedList::~CharLinkedList() {
    // Call clear to deallocate memory and reset pointers
    clear();
}

// Assignment Operator: operator=
// Inputs: other - The CharLinkedList object to be assigned
// Description: Assigns the contents of the provided CharLinkedList
//              to the current object,
//              performing a deep copy using the copyList function.
// Outputs: A reference to the current CharLinkedList object
CharLinkedList& CharLinkedList::operator=(const CharLinkedList &other) {
    // Check for self-assignment
    if (this == &other) {
        return *this;
    }

    // Clear the current list and perform deep copy using copyList function
    clear();
    copyList(other.head);

    return *this;
}






// Inputs: None
// Description: Checks if the linked list is empty by 
//              examining the head pointer.
// Outputs: Returns true if the linked list is empty, false otherwise.
bool CharLinkedList::isEmpty() const {
    // Check if the head pointer is null, indicating an empty list
    return head == nullptr;
}

// Inputs: None
// Description: Deallocates memory for each node in the linked list, 
//              resetting head, tail, and list size.
// Outputs: None
void CharLinkedList::clear() {
    // Iterate through the list and delete each node
    Node* curr = head;
    while (curr != nullptr) {
        Node* nextNode = curr->next;
        delete curr;
        curr = nextNode;
    }

    // Reset head, tail, and list size
    head = nullptr;
    tail = nullptr;
    listSize = 0;
}

// Inputs: None
// Description: Returns the current size of the linked list.
// Outputs: The size of the linked list.
int CharLinkedList::size() const {
    return listSize;
}





// Inputs: None
// Description: Returns the data of the first node in the linked list.
//              Throws a runtime_error if the list is empty.
// Outputs: The data of the first node.
char CharLinkedList::first() const {
    if (isEmpty()) {
        throw std::runtime_error("cannot get first of empty LinkedList");
    }
    return head->data;
}

// Inputs: None
// Description: Returns the data of the last node in the linked list.
//              Throws a runtime_error if the list is empty.
// Outputs: The data of the last node.
char CharLinkedList::last() const {
    if (isEmpty()) {
        throw std::runtime_error("cannot get last of empty LinkedList");
    }
    return tail->data;
}

// Inputs: index - The index of the element to retrieve
// Description: Returns the data 
//              of the node at the specified index in the linked list.
//              Throws a range_error if the index is out of bounds.
// Outputs: The data of the node at the specified index.
char CharLinkedList::elementAt(int index) const {
    if (index < 0 || index >= listSize) {
        std::string result = "index (" + std::to_string(index); 
        result = result+") not in range [0.." + std::to_string(listSize) + ")";
        throw std::range_error(result);
    }
    return getRecursive(head, index);
}





// Inputs: None
// Description: Returns a string representation of the linked 
//              list, showing its size and elements.
// Outputs: A string representation of the linked list.
std::string CharLinkedList::toString() const {
    std::string result = "[CharLinkedList of size "; 
    result = result + std::to_string(listSize) + " <<";

    // Iterate through the list and append each character to the result string
    Node* curr = head;
    while (curr != nullptr) {
        result += curr->data;
        curr = curr->next;
    }

    result += ">>]";
    return result;
}

// Inputs: None
// Description: Returns a string representation of the 
//              linked list in reverse order, showing its size and elements.
// Outputs: A string representation of the linked list in reverse order.
std::string CharLinkedList::toReverseString() const {
    // Base case: if the list is empty, return an empty string
    if (isEmpty()) {
        return "[CharLinkedList of size 0 <<>>]";
    }

    // Otherwise, start from the tail and build the reverse string recursively
    std::string result = "[CharLinkedList of size " + std::to_string(listSize);
    result = result + " <<" + toReverseStringRecursive(tail) + ">>]";
    return result;
}

// Inputs: node - The current node in the recursive call
// Description: Returns a string representation of the linked
//               list in reverse order starting from the given node.
// Outputs: A string representation of the linked list in reverse order.
std::string CharLinkedList::toReverseStringRecursive(Node* node) const {
    // Base case: if the current node is null, return an empty string
    if (node == nullptr) {
        return "";
    }

    // Recursive case: concatenate the current character with 
    //                  the reverse string of the rest of the list
    return node->data + toReverseStringRecursive(node->prev);
}

// Inputs: c - The character to be added to the back of the linked list
// Description: Inserts a new node with the given character
//               at the back of the linked list.
//              If the list is empty, both head 
//              and tail are set to the new node.
// Outputs: None
void CharLinkedList::pushAtBack(char c) {
    insertAt(c, listSize);
}

// Inputs: c - The character to be added to the front of the linked list
// Description: Inserts a new node with the given character 
//              at the front of the linked list.
//              If the list is empty, both head and tail 
//              are set to the new node.
// Outputs: None
void CharLinkedList::pushAtFront(char c) {
    insertAt(c, 0);
}
// Inputs: c - The character to be inserted
//         index - The index at which the character should be inserted
// Description: Inserts a new node with the given character at 
//              the specified index in the linked list.
//              Throws a range_error if the index is out of bounds.
// Outputs: None
void CharLinkedList::insertAt(char c, int index) {
    // Check if the index is out of range
    if (index < 0 || index > listSize) {
        std::string result = "index (" + std::to_string(index);
        result = result + ") not in range [0.."+std::to_string(listSize)+"]";
        throw std::range_error(result);
    }

    // Create a new node with the given character
    Node* newNode = new Node(c);

    // If the list is empty, or if the index is equal 
    //to the list size, handle accordingly
    if (isEmpty() || index == listSize) {
        // If the list is empty, set both head and tail to the new node
        if (isEmpty()) {
            head = newNode;
            tail = newNode;
        } else {
            // Otherwise, insert at the back
            tail->next = newNode;
            newNode->prev = tail;
            tail = newNode;
        }
    } else if (index == 0) {
        // If the index is 0, insert at the front
        newNode->next = head;
        head->prev = newNode;
        head = newNode;
    } else {
        // Otherwise, find the node at the specified index
        Node* current = head;
        for (int i = 0; i < index; ++i) {
            current = current->next;
        }

        // Adjust the pointers of the adjacent nodes
        current->prev->next = newNode;
        newNode->prev = current->prev;
        newNode->next = current;
        current->prev = newNode;
    }

    // Increment the size of the list
    ++listSize;
}

// Inputs: c - The character to be inserted in order
// Description: Inserts a new node with the given character 
//              in its correct sorted order in the linked list.
//              If the list is empty or the new character is 
//              less than the first character, insert at the front.
// Outputs: None
void CharLinkedList::insertInOrder(char c) {
    // If the list is empty or the new character is less than 
    //the first character, insert at the front
    if (isEmpty() || c < head->data) {
        insertAt(c, 0);
        return;
    }

    // Iterate through the list to find the correct 
    //position to insert the new character
    Node* current = head;
    int index = 0;
    while (current->next != nullptr && c > current->next->data) {
        current = current->next;
        ++index;
    }

    // Insert the new character at the found position
    insertAt(c, index + 1);
}

// Description: Removes the node at the front of the linked list.
//              Throws a runtime_error if the list is empty.
// Outputs: None
void CharLinkedList::popFromFront() {
    // Check if the list is empty
    if (isEmpty()) {
        throw std::runtime_error("cannot pop from empty LinkedList");
    }

    // Remove the node at index 0, which is 
    //equivalent to removing from the front
    removeAt(0);
}

// Description: Removes the node at the back of the linked list.
//              Throws a runtime_error if the list is empty.
// Outputs: None
void CharLinkedList::popFromBack() {
    // Check if the list is empty
    if (isEmpty()) {
        throw std::runtime_error("cannot pop from empty LinkedList");
    }

    // Remove the node at index listSize - 1, which is
    // equivalent to removing from the back
    removeAt(listSize - 1);
}

// Description: Removes the node at the specified index in the linked list.
//              Throws a range_error if the index is out of bounds.
// Outputs: None
void CharLinkedList::removeAt(int index) {
    // Check if the index is out of range
    if (index < 0 || index >= listSize) {
        std::string result = "index (" + std::to_string(index);
        result = result + ") not in range [0.." + std::to_string(listSize)+")";
        throw std::range_error(result);
    }

    // If the index is 0, remove the first element
    if (index == 0) {
        Node* temp = head;
        head = head->next;
        if (head != nullptr) {
            head->prev = nullptr;
        } else {
            tail = nullptr;
        }
        delete temp;
    } else if (index == listSize - 1) { // If the index is 
        //listSize - 1, remove the last element
        Node* temp = tail;
        tail = tail->prev;
        if (tail != nullptr) {
            tail->next = nullptr;
        } else {
            head = nullptr;
        }
        delete temp;
    } else { // For indices other than the first and last,
        // iterate through the list to find the node at the specified index
        Node* current = head;
        for (int i = 0; i < index; ++i) {
            current = current->next;
        }
        // Update the pointers of the adjacent nodes
        // to bypass the current node
        current->prev->next = current->next;
        current->next->prev = current->prev;
        // Delete the current node
        delete current;
    }

    // Decrement the size of the list
    --listSize;
}


// Inputs: node - The current node in the recursive call
//         c - The character to replace with
//         index - The index at which the replacement should occur
// Description: Recursively replaces the character at the specified 
//              index in the linked list.
//              Throws a range_error if the index is out of bounds.
// Outputs: None
void CharLinkedList::replaceRecursive(Node* node, char c, int index) {
    // Base case: If the node is null, the index is out of range
    if (index<0 || index >=listSize) {
        std::string a = "index (" + std::to_string(index) ;
        a = a + ") not in range [0.." + std::to_string(listSize) + ")";
        throw std::range_error(a);
        return;
    }

    // If the current index matches the target index, replace the element
    if (index == 0) {
        node->data = c;
        return;
    }

    // Recursive call to move to the next node and decrement the index
    replaceRecursive(node->next, c, index - 1);
}

// Inputs: c - The character to replace with
//         index - The index at which the replacement should occur
// Description: Calls the recursive helper function to replace 
//              the character at the specified index in the linked list.
//              Throws a range_error if the index is out of bounds.
// Outputs: None
void CharLinkedList::replaceAt(char c, int index) {
    // Call the recursive helper function starting from the head
    replaceRecursive(head, c, index);
}

// Inputs: other - A pointer to the CharLinkedList to be 
//                  concatenated with the current list
// Description: Concatenates the given linked list to the 
//              end of the current linked list.
//              If the other list is empty or if it's the
//               same list, does nothing.
// Outputs: None
void CharLinkedList::concatenate(CharLinkedList *other) {
    // If the other list is empty, or if it's the same list, do nothing
    if (other == nullptr || other->isEmpty() ) {
        return;
    }

    // Make a copy of the other list
    CharLinkedList* copy = new CharLinkedList(*other);

    // Append the copy to the end of the current list
    if (head == nullptr) {
        head = copy->head;
        tail = copy->tail;
    } else {
        tail->next = copy->head;
        copy->head->prev = tail;
        tail = copy->tail;
    }

    // Update the size of the current list
    listSize += copy->size();

    // Clear the copied list to avoid memory leaks
    //copy.clear();
    copy->head = nullptr;
    copy->tail = nullptr;
    delete copy;
}


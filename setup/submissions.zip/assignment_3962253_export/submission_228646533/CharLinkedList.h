/*
 *  CharLinkedList.h
 *  Kevin Lu, klu07
 *  2/3/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  The header file for the CharLinkedList class. This includes 
    the declarations of all of the functions and variables used for linked
    lists. For encapsulation, there are certain private variables and public
    variables to be declared. This file reduces code redundancy and can publicy
    show the user what they should be able to see.
 *
 */

#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H

#include <string>

class CharLinkedList {
private:
    struct Node {
        char data;
        Node *next;
        Node *prev;
    };

    Node *front;
    Node *back;
    int numItems;
    
    void recursiveHelperDel(Node *curr);
    Node* recursiveHelperR(Node *curr, int index);
    char recursiveHelperElem(Node *curr, int index) const;

public:
    CharLinkedList();
    CharLinkedList(char c);
    CharLinkedList(char arr[], int size);
    CharLinkedList(const CharLinkedList &other);
    ~CharLinkedList();

    CharLinkedList &operator=(const CharLinkedList &other);

    bool isEmpty() const;
    void clear();
    int size() const;
    char first() const;
    char last() const;
    char elementAt(int index) const;
    std::string toString() const;
    std::string toReverseString() const;
    void pushAtBack(char c);
    void pushAtFront(char c);
    void insertAt(char c, int index);
    void insertInOrder(char c);
    void popFromFront();
    void popFromBack();
    void removeAt(int index);
    void replaceAt(char c, int index);
    void concatenate(CharLinkedList *other);
    Node* makeNode(char c);


};

#endif

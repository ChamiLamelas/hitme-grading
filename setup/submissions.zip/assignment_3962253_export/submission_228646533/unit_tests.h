/*
 *  unit_tests.h
 *  Kevin Lu, klu07
 *  2/3/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  The testing file that tests all of the functions. For many of them, there 
 *  are multiple tests that will help check edge cases and other special cases.
 *  Within some that could throw exceptions, code in this file will catch it and
 *  determine whether the exception was correct with assertion statements.
 *
 */

#include "CharLinkedList.h"
#include <iostream>
#include <cassert>

//Testing default constructor and asserting the toString
void testConstructor1() {
    CharLinkedList test = CharLinkedList();
    assert(test.toString() == "[CharLinkedList of size 0 <<>>]");
}

//Testing second constructor and asserting the toString
void testConstructor2() {
    CharLinkedList test = CharLinkedList('a');
    assert(test.toString() == "[CharLinkedList of size 1 <<a>>]");
}

//Testing third constructor and asserting the toString
void testConstructor3() {
    char arr[] = {'a', 'b', 'c'};
    CharLinkedList test = CharLinkedList(arr, 3);
    assert(test.toString() == "[CharLinkedList of size 3 <<abc>>]");
}

//Testing the copy constructor and asserting the toStrings
void testConstructor4() {
    char arr[] = {'a', 'b', 'c'};
    CharLinkedList test = CharLinkedList(arr, 3);
    CharLinkedList test2 = CharLinkedList(test);

    assert(test.toString() == test2.toString());
}

//Testing if the defined assignment operator works with size and string 
//assertion
void testAssignmentOperator() {
    char arr[] = {'a', 'b', 'c'};
    CharLinkedList testing = CharLinkedList(arr, 3);

    CharLinkedList copy = testing;

    assert(testing.size() == copy.size());
    assert(testing.toString() == copy.toString());
}

//Testing if .size() return correct size
void testSize() {
    CharLinkedList test = CharLinkedList('a');
    assert(test.size() == 1);
}

//Testing size on empty list
void testSizeOfEmpty() {
    CharLinkedList test = CharLinkedList();
    assert(test.size() == 0);
}

//Testing size on huge list
void testSizeOfHuge() {
    CharLinkedList test;
    for (int i = 0; i < 1000; i++) {
        test.pushAtBack('a');
    }
    assert(test.size() == 1000);
}

//Testing if the toString output is correct
void testToString() {
    CharLinkedList test = CharLinkedList('a');
    assert(test.toString() == "[CharLinkedList of size 1 <<a>>]");
}

//Testing toString on empty list
void testToStringOnEmpty() {
    CharLinkedList test = CharLinkedList();
    assert(test.toString() == "[CharLinkedList of size 0 <<>>]");
}

//Testing if the toReverseString output is correct
void testtoReverseString () {
    char arr[] = {'a', 'b', 'c'};
    CharLinkedList test = CharLinkedList(arr, 3);
    assert(test.toReverseString() == "[CharLinkedList of size 3 <<cba>>]");
}

//Testing toReverseString on empty list
void testToReverseStringOnEmpty() {
    CharLinkedList test = CharLinkedList();
    assert(test.toReverseString() == "[CharLinkedList of size 0 <<>>]");
}

//Testing if pushAtBack works with toString assertion
void testPushAtBack() {
    CharLinkedList test = CharLinkedList('a');
    test.pushAtBack('b');
    assert(test.toString() == "[CharLinkedList of size 2 <<ab>>]");
}

//Testing pushAtBack on empty list
void testPushAtBackOnEmpty() {
    CharLinkedList test = CharLinkedList();
    test.pushAtBack('a');
    assert(test.toString() == "[CharLinkedList of size 1 <<a>>]");
}

//Testing if pushAtFront works with toString assertion
void testPushAtFront() {
    CharLinkedList test = CharLinkedList('a');
    test.pushAtFront('b');
    assert(test.toString() == "[CharLinkedList of size 2 <<ba>>]");
}

//Testing pushAtFront on empty list
void testPushAtFrontOnEmpty() {
    CharLinkedList test = CharLinkedList();
    test.pushAtFront('a');
    assert(test.toString() == "[CharLinkedList of size 1 <<a>>]");
}

//Testing if isEmpty() is correct
void testIsEmpty() {
    CharLinkedList test = CharLinkedList();
    assert(test.isEmpty());
}

//Testing the clear() function with isEmpty() and size assertion
void testClear() {
    CharLinkedList test = CharLinkedList('a');
    test.clear();
    assert(test.isEmpty());
    assert(test.size() == 0);
}

//Testing clear on empty list
void testClearOnEmpty() {
    CharLinkedList test = CharLinkedList();
    test.clear();
    assert(test.isEmpty());
    assert(test.size() == 0);
}

//Testing clear on huge list
void testClearOnHuge() {
    CharLinkedList test;
    for (int i = 0; i < 1000; i++) {
        test.pushAtBack('a');
    }
    test.clear();
    assert(test.isEmpty());
    assert(test.size() == 0);
}

//Testing first() on normal list
void testfirst() {
    char arr[] = {'a', 'b', 'c'};
    CharLinkedList test = CharLinkedList(arr, 3);
    assert(test.first() == 'a');
}

//Testing first() on empty list and catching runtime error
void testFirstOnEmpty() {
    CharLinkedList test = CharLinkedList();
    bool runtime_error_thrown = false;
    std::string em = "";

    try {
        assert(test.first() == 'a');
    } 
    catch (std::runtime_error &e) {
        runtime_error_thrown = true;
        em = e.what();
    }
    assert(runtime_error_thrown);
    assert(em == "cannot get first of empty LinkedList");
}

//Testing first() on huge list
void testFirstOnBig() {
    CharLinkedList test;
    for (int i = 0; i < 1000; i++) {
        test.pushAtBack('b');
    }
    assert(test.first() == 'b');
}

//Testing first() on one element list
void testFirstOnOne() {
    CharLinkedList test = CharLinkedList('v');
    assert(test.first() == 'v');
}

//Testing last() on normal list
void testlast() {
    char arr[] = {'a', 'b', 'c'};
    CharLinkedList test = CharLinkedList(arr, 3);
    assert(test.last() == 'c');
}

//Testing last() on empty list and catching runtime error
void testlastOnEmpty() {
    CharLinkedList test = CharLinkedList();
    bool runtime_error_thrown = false;
    std::string em = "";

    try {
        test.last() == 'c';
    } 
    catch (std::runtime_error &e) {
        runtime_error_thrown = true;
        em = e.what();
    }
    assert(runtime_error_thrown);
    assert(em == "cannot get last of empty LinkedList");
}

//Testing last() on huge list
void testLastOnBig() {
    CharLinkedList test;
    for (int i = 0; i < 1000; i++) {
        test.pushAtBack('b');
    }
    assert(test.last() == 'b');
}

//Testing last() on one char list
void testLastOnOne() {
    CharLinkedList test = CharLinkedList('v');
    assert(test.last() == 'v');
}

//Testing insertAt() with normal index
void testInsertAt() {
    char arr[] = {'a', 'b', 'c'};
    CharLinkedList test = CharLinkedList(arr, 3);

    test.insertAt('x', 1);
    assert(test.toString() == "[CharLinkedList of size 4 <<axbc>>]");
}

//Testing insertAt() with bad index and catching range error
void testInsertAtBadIndex() {
    char arr[] = {'a', 'b', 'c'};
    CharLinkedList test = CharLinkedList(arr, 3);
    bool range_error_thrown = false;
    std::string em = "";

    try {
        test.insertAt('x', 10);
    } 
    catch (std::range_error &e) {
        range_error_thrown = true;
        em = e.what();
    }
    assert(range_error_thrown);
    assert(em == "index (10) not in range [0..3]");
}

//Testing insertInOrder() with middle insertion
void testInsertInOrder() {
    char arr[] = {'a', 'c', 'd'};
    CharLinkedList test = CharLinkedList(arr, 3);

    test.insertInOrder('b');
    assert(test.toString() == "[CharLinkedList of size 4 <<abcd>>]");
}

//Testing insertInOrder when char is bigger than whole list
void testInsertInOrderLast() {
    char arr[] = {'a', 'b', 'c'};
    CharLinkedList test = CharLinkedList(arr, 3);

    test.insertInOrder('d');
    assert(test.toString() == "[CharLinkedList of size 4 <<abcd>>]");
}

//Testing insertInOrder when char is the smallest
void testInsertInOrderFirst() {
    char arr[] = {'b', 'c', 'd'};
    CharLinkedList test = CharLinkedList(arr, 3);

    test.insertInOrder('a');
    assert(test.toString() == "[CharLinkedList of size 4 <<abcd>>]");
}

//Testing insertInOrder on an empty list
void testInsertInOrderOnEmpty() {
    CharLinkedList test = CharLinkedList();
    test.insertInOrder('a');
    assert(test.toString() == "[CharLinkedList of size 1 <<a>>]");
}

//Testing popFromFront on normal list
void testPopFromFront() {
    char arr[] = {'a', 'c', 'd'};
    CharLinkedList test = CharLinkedList(arr, 3);
    test.popFromFront();
    assert(test.toString() == "[CharLinkedList of size 2 <<cd>>]");
}

//Testing popFromFront on one char list
void testPopFromFrontOne() {
    CharLinkedList test = CharLinkedList('a');
    test.popFromFront();
    assert(test.toString() == "[CharLinkedList of size 0 <<>>]");
}

//Testing popFromFront on empty list and catching runtime error
void testPopFromFrontEmpty() {
    CharLinkedList test = CharLinkedList();
    bool runtime_error_thrown = false;
    std::string em = "";

    try {
        test.popFromFront();
    } catch (std::runtime_error &e) {
        runtime_error_thrown = true;
        em = e.what();
    }

    assert(runtime_error_thrown);
    assert(em == "cannot pop from empty LinkedList");
}

//Testing popFromBack() on normal list
void testPopFromBack() {
    char arr[] = {'a', 'c', 'd'};
    CharLinkedList test = CharLinkedList(arr, 3);
    test.popFromBack();
    assert(test.toString() == "[CharLinkedList of size 2 <<ac>>]");

}

//Testing popFromBack on one element list
void testPopFromBackOne() {
    CharLinkedList test = CharLinkedList('a');
    test.popFromBack();
    assert(test.toString() == "[CharLinkedList of size 0 <<>>]");
}

//Testing popFromBack on empty list and catching runtime error
void testPopFromBackEmpty() {
    CharLinkedList test = CharLinkedList();
    bool runtime_error_thrown = false;
    std::string em = "";

    try {
        test.popFromBack();
    } catch (std::runtime_error &e) {
        runtime_error_thrown = true;
        em = e.what();
    }

    assert(runtime_error_thrown);
    assert(em == "cannot pop from empty LinkedList");
}

//Testing removeAt with normal list and index
void testRemoveAt() {
    char arr[] = {'a', 'c', 'd'};
    CharLinkedList test = CharLinkedList(arr, 3);

    test.removeAt(1);
    assert(test.toString() == "[CharLinkedList of size 2 <<ad>>]");

}

//Testing removeAt with out of bounds index and catching range error
void testRemoveAtOutOfRange() {
    char arr[] = {'a', 'c', 'd'};
    CharLinkedList test = CharLinkedList(arr, 3);
    bool range_error_thrown = false;
    std::string em = "";

    try {
        test.removeAt(10);
    } catch (std::range_error &e) {
        range_error_thrown = true;
        em = e.what();
    }

    assert(range_error_thrown);
    assert(em == "index (10) not in range [0..3)");
}

//Testing removeAt with one char list
void testRemoveAtOne() {
    CharLinkedList test = CharLinkedList('a');
    test.removeAt(0);

    assert("[CharLinkedList of size 0 <<>>]");
}

//Testing removeAt at back of list
void testRemoveAtBack() {
    char arr[] = {'a', 'c', 'd'};
    CharLinkedList test = CharLinkedList(arr, 3);
    test.removeAt(2);
    assert("[CharLinkedList of size 2 <<ac>>]");
}

//Testing replaceAt() with normal list and index
void testReplaceAt() {
    char arr[] = {'a', 'c', 'd'};
    CharLinkedList test = CharLinkedList(arr, 3);

    test.replaceAt('z', 2);
    test.toString() == "[CharLinkedList of size 3 <<acz>>]";
}

//Testing replaceAt() with bad index and catching range error
void testReplaceAtOutOfRange() {
    char arr[] = {'a', 'c', 'd'};
    CharLinkedList test = CharLinkedList(arr, 3);
    bool range_error_thrown = false;
    std::string em = "";

    try {
        test.replaceAt('z', 10);
    } catch (std::range_error &e) {
        range_error_thrown = true;
        em = e.what();
    }

    assert(range_error_thrown);
    assert(em == "index (10) not in range [0..3)");
}

//Testing replaceAt with first index
void testReplaceAtFirst() {
    char arr[] = {'a', 'c', 'd'};
    CharLinkedList test = CharLinkedList(arr, 3);
    test.replaceAt('z', 0);
    assert(test.toString() == "[CharLinkedList of size 3 <<zcd>>]");
}

//Testing replaceAt with last index
void testReplaceAtLast() {
    char arr[] = {'a', 'c', 'd'};
    CharLinkedList test = CharLinkedList(arr, 3);
    test.replaceAt('z', 2);
    assert(test.toString() == "[CharLinkedList of size 3 <<acz>>]");
}

//Testing replaceAt with one char list
void testReplaceAtOne() {
    CharLinkedList test = CharLinkedList('a');
    test.replaceAt('z', 0);
    assert(test.toString() == "[CharLinkedList of size 1 <<z>>]");
}

//Testing elementAt() with normal list and index
void testElementAt() {
    char arr[] = {'a', 'b', 'c'};
    CharLinkedList test = CharLinkedList(arr, 3);
    test.elementAt(1) == 'c';
}

//Testing elementAt() with bad index and catching range error
void testElementAtOutOfRange() {
    char arr[] = {'a', 'b', 'c'};
    CharLinkedList test = CharLinkedList(arr, 3);
    bool range_error_thrown = false;
    std::string em = "";

    try {
        test.elementAt(10) == 'c';
    } catch (std::range_error &e) {
        range_error_thrown = true;
        em = e.what();
    }

    assert(range_error_thrown);
    assert(em == "index (10) not in range [0..3)");
}

//Testing elementAt() with first element
void testElementAtFirst() {
    char arr[] = {'a', 'b', 'c'};
    CharLinkedList test = CharLinkedList(arr, 3);
    assert(test.elementAt(0) == 'a');
}

//Testing elementAt() with last element
void testElementAtLast() {
    char arr[] = {'a', 'b', 'c'};
    CharLinkedList test = CharLinkedList(arr, 3);
    assert(test.elementAt(2) == 'c');
}

//Testing elementAt on empty list
void elementAtBlank() {
    CharLinkedList test = CharLinkedList();
    try {
        test.elementAt(3);
    } catch (std::runtime_error) {
        return;
    }
}

//Testing concatenate with two normal linked lists
void testConcatenate() {
    char arr1[] = {'a', 'b', 'c'};
    CharLinkedList test1 = CharLinkedList(arr1, 3);

    char arr2[] = {'d', 'e', 'f'};
    CharLinkedList test2 = CharLinkedList(arr2, 3);

    test1.concatenate(&test2);
    assert(test1.toString() == "[CharLinkedList of size 6 <<abcdef>>]");
}

//Testing concatentate with itself
void testConcatenateWithSelf() {
    char arr1[] = {'a', 'b', 'c'};
    CharLinkedList test1 = CharLinkedList(arr1, 3);
    test1.concatenate(&test1);
    assert(test1.toString() == "[CharLinkedList of size 6 <<abcabc>>]");
}

//Testing concatenate with second list as empty
void testConcatenateWithEmpty() {
    char arr1[] = {'a', 'b', 'c'};
    CharLinkedList test1 = CharLinkedList(arr1, 3);
    CharLinkedList test2 = CharLinkedList();
    test1.concatenate(&test2);
    assert(test1.toString() == "[CharLinkedList of size 3 <<abc>>]");
}

//Testing concatenate starting with empty list
void testConcatenateStartWithEmpty() {
    char arr1[] = {'a', 'b', 'c'};
    CharLinkedList test1 = CharLinkedList();
    CharLinkedList test2 = CharLinkedList(arr1, 3);
    test1.concatenate(&test2);
    assert(test1.toString() == "[CharLinkedList of size 3 <<abc>>]");
}

//Testing inserting into empty list 
void insertAt_empty_correct() { 
    CharLinkedList test_list;
    test_list.insertAt('a', 0);
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');
}

// Tests incorrect insertion into an empty AL.
// Attempts to call insertAt for index larger than 0.
// This should result in an std::range_error being raised.
void insertAt_empty_incorrect() {

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
        // insertAt for out-of-range index
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        // if insertAt is correctly implemented, a range_error will be thrown,
        // and we will end up here
        range_error_thrown = true;
        error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0]");
    
}

// Tests correct insertAt for front of 1-element list.
void insertAt_front_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at front
    test_list.insertAt('b', 0);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'a');
    
}

// Tests correct insertAt for back of 1-element list.
void insertAt_back_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at back
    test_list.insertAt('b', 1);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    
}

// Tests calling insertAt for a large number of elements.
// Not only does this test insertAt, it also checks that
// array expansion works correctly.
void insertAt_many_elements() {
    
    CharLinkedList test_list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.pushAtBack('a');
    }

    assert(test_list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
    
}

// Tests insertion into front of a larger list
void insertAt_front_large_list() {
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    test_list.insertAt('y', 0);

    assert(test_list.size() == 10);
    assert(test_list.elementAt(0) == 'y');
    assert(test_list.toString() =="[CharLinkedList of size 10 <<yabczdefgh>>]");

}

// Tests insertion into the back of a larger list
void insertAt_back_large_list() {

    char test_arr[10] = { 'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 10);  

    test_list.insertAt('x', 10);

    assert(test_list.size() == 11);
    assert(test_list.elementAt(10) == 'x');
    assert(test_list.toString() ==
    "[CharLinkedList of size 11 <<yabczdefghx>>]"); 

}

// Tests insertion into the middle of a larger list
void insertAt_middle_large_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.insertAt('z', 3);

    assert(test_list.size() == 9);
    assert(test_list.elementAt(3) == 'z');
    assert(test_list.toString() == "[CharLinkedList of size 9 <<abczdefgh>>]");

}

// Tests out-of-range insertion for a non-empty list.
void insertAt_nonempty_incorrect() {
   
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8]");
    
}


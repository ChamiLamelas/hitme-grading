/*
 *  CharLinkedList.cpp
 *  Kevin Lu, klu07
 *  2/3/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  The source code or compilation unit for the CharLinkedList
    class. It includes all of the implementations of the functions declared in
    the corresponding header file. This is where the body and algorithms of the
    code are written. 
 *
 */

#include "CharLinkedList.h"
#include <stdexcept>

/*
 * name:      recursiveHelperR
 * purpose:   using recursion to help find node to replace 
 * arguments: a node pointer and index
 * returns:   node pointer
 * effects:   gives the node at the indicated index
 */
CharLinkedList::Node* CharLinkedList::recursiveHelperR(Node *curr, int index) {

    //Base case to return the node
    if (index == 0) {
        return curr;
    } else {

        //Recursive call with next node and index interated one down
        return recursiveHelperR(curr->next, index - 1);
    }
}

/*
 * name:      recursiveHelperElem
 * purpose:   using recursion to help find node
 * arguments: a node pointer and index
 * returns:   char
 * effects:   gives the char data of specific node at index
 */
char CharLinkedList::recursiveHelperElem(Node *curr, int index) const {

    //Base case to return the node
    if (index == 0) {
        return curr->data;

    //Recursive call with next node at specified index
    } else {
        return recursiveHelperElem(curr->next, index - 1);
    }   
}

/*
 * name:      recursiveHelperDel
 * purpose:   using recursion to help delete all associated data and memory
 * arguments: a node pointer
 * returns:   nothing
 * effects:   deletes each and every node data and memory
 */
void CharLinkedList::recursiveHelperDel(Node *curr) {

        //If curr node is not nullptr, create new node to store next and delete
        //curr, then rescursively call 
        if (curr != nullptr) {
            Node *next = curr->next;
            delete curr;
            curr = next;
            recursiveHelperDel(curr);

        //base case when finisehd deleting and returns
        } else {
            return;
        }
    }

/*
 * name:      makeNode
 * purpose:   creates a node
 * arguments: char
 * returns:   node pointer
 * effects:   declares and initializes a node
 */
CharLinkedList::Node* CharLinkedList::makeNode(char c) {

    //Creating new node and storing respective data
    Node *newNode = new Node;
    newNode->data = c;
    newNode->next = nullptr;
    newNode->prev = nullptr;
    return newNode;
}

/*
 * name:      CharLinkedList
 * purpose:   default constructor for CharLinkedList class
 * arguments: nothing
 * returns:   nothing
 * effects:   Constructs a blank char linked list
 */
CharLinkedList::CharLinkedList() {

    //Initializing priv vars
    front = nullptr;
    back = nullptr;
    numItems = 0;
}

/*
 * name:      CharLinkedList
 * purpose:   special constructor for CharLinkedList
 * arguments: char
 * returns:   nothing
 * effects:   creates char linked list of single character
 */
CharLinkedList::CharLinkedList(char c) {

    //Creating new node and initializing varis
    Node* newNode = makeNode(c);
    front = newNode;
    back = newNode;
    newNode->next = nullptr;
    newNode->prev = nullptr;
    numItems = 1;
}


/*
 * name:      CharLinkedList
 * purpose:   special constructor for CharLinkedList
 * arguments: char array and int size
 * returns:   nothing
 * effects:   constructs a CharLinkedList from array and size
 */
CharLinkedList::CharLinkedList(char arr[], int size) {

    //Initialzing priv vars
    front = nullptr;
    back = nullptr;

    //Pushing back all elements of the array to linked list
    for (int i = 0; i < size; i++) {
        pushAtBack(arr[i]);
    }

    //Setting characteristics of linked list 
    front->prev = nullptr;
    back->next = nullptr;
}

/*
 * name:      CharLinkedList
 * purpose:   copy constructor for CharLinkedList 
 * arguments: pointer to const CharLinkedList
 * returns:   nothing
 * effects:   creates deep copy of passed in CharLinkedList
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other) {

    //Initializing priv vats
    front = nullptr;
    back = nullptr;

    //looping to pushback all elements from other to this linked list
    for (int i = 0; i < other.size(); i++) {
        pushAtBack(other.elementAt(i));
    }
}

/*
 * name:      &CharLinkedList
 * purpose:   defines operator for class that creates deep copy and recycles 
 *            old storage
 * arguments: pointer to const CharLinkedList
 * returns:   pointer to CharLinkedList
 * effects:   allows the use of operator for class through the return of
 *            the deep copy 
 */
CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other) {

    //Initializing priv vars
    front = nullptr;
    back = nullptr;
    
    //Looping to pushAtBack all elements from other CharLinkedList to this
    for (int i = 0; i < other.size(); i++) {
        pushAtBack(other.elementAt(i));
    }
    
    //Returns this CharLinkedList
    return *this;
}

/*
 * name:      size
 * purpose:   return the size of CharLinkedList
 * arguments: nothing
 * returns:   int
 * effects:   returns size
 */
int CharLinkedList::size() const {

    //Returning numItems
    return numItems;
}

/*
 * name:      toString
 * purpose:   Creates the string to represent CharLinkedList
 * arguments: nothing
 * returns:   string
 * effects:   constructs the string representing CharLinkedList
 */
std::string CharLinkedList::toString() const {

    //Creating newNode and starting it at front
    Node *newNode = this->front;

    //Constructing the message
    std::string sent = "[CharLinkedList of size ";
    std::string word = "";

    //Looping through the CharLinkedList and building string
    while (newNode != nullptr) {
        word += newNode->data;
        newNode = newNode->next;
    }

    //Return the construced message
    return sent + std::to_string(this->size()) + " <<" + word + ">>]"; 
}

/*
 * name:      toReverseString
 * purpose:   Creates the string to represent CharLinkedList
 * arguments: nothing
 * returns:   string
 * effects:   constructs the string representing CharLinkedList
 */
std::string CharLinkedList::toReverseString() const {

    //Creating newNode starting from back and vars to create string
    Node *newNode = this->back;
    std::string sent = "[CharLinkedList of size ";
    std::string word = "";

    //Looping through CharLinkedList and building string
    while (newNode != nullptr) {
        word += newNode->data;
        newNode = newNode->prev;
    }
    
    //Returning constructed string
    return sent + std::to_string(this->size()) + " <<" + word + ">>]"; 
}

/*
 * name:      ~CharLinkedList
 * purpose:   Delete allocated memory
 * arguments: nothing
 * returns:   nothing
 * effects:   Cleans up allocated memory
 */
CharLinkedList::~CharLinkedList() {

    //Calling recurisve helper that deletes CharLinkedList data and memory
    recursiveHelperDel(front);
}

/*
 * name:      pushAtBack
 * purpose:   puts character at back of CharLinkedList
 * arguments: char c
 * returns:   nothing
 * effects:   adds the character to the back of CharLinkedList
 */
void CharLinkedList::pushAtBack(char c) {

    //Creating new node
    Node *newNode = makeNode(c);

    //If empty array, create linked list with that one char
    if (front == nullptr) {
        front = newNode;
        back = newNode;
        numItems = 1;

    //Setting vars to the point to respective pointers and incrementing numItems
    } else {
        back->next = newNode;
        newNode->prev = back;
        back = newNode;
        numItems++;
    }

}

/*
 * name:      pushAtFront
 * purpose:   adds char to the front
 * arguments: char c
 * returns:   nothing
 * effects:   adds inputted char to front of the CharLinkedList
 */
void CharLinkedList::pushAtFront(char c) {

    //Creating new node
    Node *newNode = makeNode(c);

    //Pointing vars to respective places and incrementing numItems
    newNode->next = front;
    front = newNode;
    numItems++;
}  

/*
 * name:      isEmpty
 * purpose:   Checking if CharLinkedList is empty
 * arguments: nothing
 * returns:   bool
 * effects:   returns whether the CharLinkedList is empty or not
 */
bool CharLinkedList::isEmpty() const {

    //Front points to nullptr, return true, if not, return false
    if (front == nullptr) {
        return true;
    }
    return false;
}

/*
 * name:      clear
 * purpose:   clears the CharLinkedList
 * arguments: nothing
 * returns:   nothing
 * effects:   empties out the CharLinkedList
 */
void CharLinkedList::clear() {
    
    //Creaing new node that is front
    Node *curr = front;

    //Iterating through linked list and deleting each ones memory
    while (curr != nullptr) {
        
        //Creating new node to store prev node to be deleted
        Node *nextN = curr->next;
        delete curr;
        curr = nextN;
    }

    //Setting front and back to nullptr and numItems to 0
    front = nullptr;
    back = nullptr;
    numItems = 0;
}

/*
 * name:      first
 * purpose:   returns first char of CharLinkedlist
 * arguments: nothing
 * returns:   char
 * effects:   returns first char
 */
char CharLinkedList::first() const {

    //If list is empty, throw runtime error
    if (front == nullptr) {
        throw std::runtime_error("cannot get first of empty LinkedList");
    } else {

        //else, return the front's data
        return front->data; 
    }
}

/*
 * name:      last
 * purpose:   returns last char of CharLinkedList
 * arguments: nothing
 * returns:   char
 * effects:   returns the last char of CharLinkedList
 */
char CharLinkedList::last() const {

    //If list is empty, throw runtime error
    if (front == nullptr) {
        throw std::runtime_error("cannot get last of empty LinkedList");
    } else {
        //else, return the data of back node
        return back->data; 
    }
}

/*
 * name:      insertAt
 * purpose:   inserting inputted char at inputted index
 * arguments: char c and in index
 * returns:   nothing
 * effects:   inserts the character inputted at specified index
 */
void CharLinkedList::insertAt(char c, int index) {

    //Checking bounds and throwing range error if not
    if (index < 0 or index > numItems) {
        std::string msg = "index (" + std::to_string(index);
        std::string msg1 = ") not in range [0..";
        throw std::range_error(msg + msg1 + std::to_string(numItems) + "]");
    }

    //Checking if inputted index is front
    if (index == 0) {
        pushAtFront(c);
        return;

    //Checking if inputted index is back
    } else if (index == numItems) {
        pushAtBack(c);
        return;
    }

    //Making new node with data c and current node as front
    Node *newNode = makeNode(c);
    Node *curr = front;

    //Looping to get to indexed node
    for (int i = 0; i < index - 1; i++) {
        curr = curr->next;
    }

    //Pointer logic to slot in the new data and incrementing numItems by 1
    newNode->next = curr->next;
    newNode->next->prev = newNode;
    newNode->prev = curr;
    curr->next = newNode;
    numItems++;
}

/*
 * name:      insertInOrder
 * purpose:   inserting character in ASCII order
 * arguments: char c
 * returns:   nothing
 * effects:   inserts the inputted char in correct place in terms of rising 
 *            ASCII
 */
void CharLinkedList::insertInOrder(char c) {

    //If list is empty, add char c to the list
    if (numItems == 0) {
        pushAtBack(c);
        return;
    }

    //Creating curr node that is front
    //Creating counter 
    Node *curr = front;
    int count = 0;

    //looping to the correct place of list by ASCII value
    while (c > curr->data) {
        curr = curr->next;
        count++;

        //If reach end, pushAtBack
        if (count == numItems - 1) {
            pushAtBack(c);
            return;
        }
    }
    //Insert the char at index
    insertAt(c, count);
}

/*
 * name:      popFromFront
 * purpose:   pops off the first char
 * arguments: nothing
 * returns:   nothing
 * effects:   removes the first char
 */
void CharLinkedList::popFromFront() {

    //If list is empty, throw runtime error
    if (front == nullptr) {
        throw std::runtime_error("cannot pop from empty LinkedList");
    }

    //If there is one char, clear and return
    if (numItems == 1) {
        clear();
        return;
    }

    //Pointer logic to remove the first node
    Node *old_front = front;
    front = front->next;
    delete old_front;
    front->next->prev = nullptr;
    numItems--;
}

/*
 * name:      popFromBack
 * purpose:   pops off the last char
 * arguments: nothing
 * returns:   nothing
 * effects:   removes the last char
 */
void CharLinkedList::popFromBack() {

    //If list is empty, throw runtime error
    if (front == nullptr) {
        throw std::runtime_error("cannot pop from empty LinkedList");
    }

    //If there is one char, clear and return
    if (numItems == 1) {
        clear();
        return;
    }
    
    //Creating node to hold back and curr as the front
    Node *old_back = back;
    Node *curr = front;

    //Getting to the end of list
    while (curr->next != nullptr) {
        curr = curr->next;
    }

    //Pointer logic to remove the last node
    curr->prev->next = nullptr;
    back = curr->prev;
    delete old_back;
    numItems--;
}

/*
 * name:      removeAt
 * purpose:   removes the character at specificed index
 * arguments: int index
 * returns:   nothing
 * effects:   gets rid of character at specified index and shift elements
 */
void CharLinkedList::removeAt(int index) {

    //If index is out of bounds, throw range_error
    if (index < 0 or index >= numItems) {
        std::string msg = "index (" + std::to_string(index);
        std::string msg1 = ") not in range [0..";
        throw std::range_error(msg + msg1 + std::to_string(numItems) + ")");
    }

    //If index is 0, popFromFront
    if (index == 0) {
        popFromFront();
        return;
    }

    //If index is last char, popFromBack
    if (index == numItems - 1) {
        popFromBack();
        return;
    }

    //Creating curr as the front and looping to te indexed char
    Node *curr = front;
    for (int i = 0; i < index; i++) {
        curr = curr->next;
    }

    //Pointer logic to remove that node from list
    curr->prev->next = curr->next;
    curr->next->prev = curr->prev;
    delete curr;
    numItems--;
}

/*
 * name:      replaceAt
 * purpose:   replaces the char at index with new char
 * arguments: char c and int index
 * returns:   nothign
 * effects:   replaces the char at index with specified char
 */
void CharLinkedList::replaceAt(char c, int index) {

    //If index is out of bounds, throw range error
    if (index < 0 or index >= numItems) {
        std::string msg = "index (" + std::to_string(index);
        std::string msg1 = ") not in range [0..";
        throw std::range_error(msg + msg1 + std::to_string(numItems) + ")");
    }

    //Running the recursive helper and storing in new node and setting its data
    Node *newNode = recursiveHelperR(front, index);
    newNode->data = c;
}

/*
 * name:      elementAt
 * purpose:   Finding the char at inputted index
 * arguments: int index
 * returns:   char
 * effects:   returns the character at the specified index
 */
char CharLinkedList::elementAt(int index) const {

    if (front == nullptr) {
        throw std::runtime_error("cannot get element at of empty LinkedList");
    }
    //If index is out of bounds, throw range error
    if (index < 0 or index >= numItems) {
        std::string msg = "index (" + std::to_string(index);
        std::string msg1 = ") not in range [0..";
        throw std::range_error(msg + msg1 + std::to_string(numItems) + ")");
    }
    
    //Run the recursiveHelper to give the data at the specific indexed node
    return recursiveHelperElem(front, index);
}

/*
 * name:      concatenate
 * purpose:   combines two CharLinkedLists
 * arguments: pointer to CharLinkedlist
 * returns:   nothing
 * effects:   concatenates the orig CharLinkedList with inputted pointer to 
 *            CharLinkedList
 */
void CharLinkedList::concatenate(CharLinkedList *other) {

    //If inputted list is empty, return this list
    if (other->isEmpty()) {
        return;
    }
    //Creating deep copy of passed in list
    CharLinkedList copy = CharLinkedList(*other);

    //Copying all the elements over using pushAtBack and elementAt
    for (int i = 0; i < copy.size(); i++) {
        this->pushAtBack(copy.elementAt(i));
    } 
}





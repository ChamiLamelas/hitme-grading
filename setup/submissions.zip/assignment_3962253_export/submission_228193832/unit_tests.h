/*
 *  unit_tests.h
 *  YOUR NAME HERE
 *  DATE CREATED
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  FILE PURPOSE HERE
 *
 */
// Tests correct insertion into an empty AL.
// Afterwards, size should be 1 and element at index 0
// should be the element we inserted.

#include "CharLinkedList.h"
#include <cassert>

void defaultConstructorTest(){
    CharLinkedList newList;
    assert(newList.isEmpty());
}

void characterConstructorTest(){
    CharLinkedList newList('A');
    assert(newList.size() == 1);
    assert(newList.elementAt(0) == 'A');
    assert(newList.first() == 'A');
    assert(newList.last() == 'A');
}

void deepCopyConstructorTest(){
    CharLinkedList originalList;
    originalList.pushAtBack('A');
    originalList.pushAtBack('B');
    originalList.pushAtBack('C');

    CharLinkedList copiedList(originalList);

    assert(originalList.size() == copiedList.size());

    for(int i = 0; i < originalList.size(); i++){
        assert(originalList.elementAt(i) == copiedList.elementAt(i));
    }
}

void operatorTest(){
    char test_arr1[3] = {'c', 'a', 't'};
    char test_arr2[7] = {'t', 'e', 's', 't', 'i', 'n', 'g'};
    CharLinkedList test_list1(test_arr1, 3);
    CharLinkedList test_list2(test_arr1, 3);
    CharLinkedList test_list3(test_arr2, 7);
    CharLinkedList emptyList;
    test_list1 = test_list2;
    assert(test_list1.toString() == 
    "[CharLinkedList of size 3 <<cat>>]"); 
    emptyList = test_list1;
    assert(emptyList.toString() == 
    "[CharLinkedList of size 3 <<cat>>]");
    emptyList.clear();
    test_list1 = emptyList;
    assert(test_list1.toString() == 
    "[CharLinkedList of size 0 <<>>]");  
    test_list1 = test_list3;
    assert(test_list1.toString() == 
    "[CharLinkedList of size 7 <<testing>>]");  
}

void insertAt_empty_correct() { 

    CharLinkedList test_list;
    test_list.insertAt('a', 0);
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');

}

// Tests incorrect insertion into an empty AL.
// Attempts to call insertAt for index larger than 0.
// This should result in an std::range_error being raised.
void insertAt_empty_incorrect() {

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    // insertAt for out-of-range index
    test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
    // if insertAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    range_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0]");
    
}

// Tests correct insertAt for front of 1-element list.
void insertAt_front_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at front
    test_list.insertAt('b', 0);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'a');
    
}

// Tests correct insertAt for back of 1-element list.
void insertAt_back_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at back
    test_list.insertAt('b', 1);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    
}

// Tests calling insertAt for a large number of elements.
// Not only does this test insertAt, it also checks that
// array expansion works correctly.
void insertAt_many_elements() {
    
    CharLinkedList test_list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.insertAt('a', i);
    }

    assert(test_list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
    
}

// Tests insertion into front of a larger list
void insertAt_front_large_list() {
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    test_list.insertAt('y', 0);

    assert(test_list.size() == 10);
    assert(test_list.elementAt(0) == 'y');
    assert(test_list.toString() == 
    "[CharLinkedList of size 10 <<yabczdefgh>>]");

}

// Tests insertion into the back of a larger list
void insertAt_back_large_list() {

    char test_arr[10] = { 'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 10);  

    test_list.insertAt('x', 10);

    assert(test_list.size() == 11);
    assert(test_list.elementAt(10) == 'x');
    assert(test_list.toString() == 
    "[CharLinkedList of size 11 <<yabczdefghx>>]"); 

}

// Tests insertion into the middle of a larger list
void insertAt_middle_large_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.insertAt('z', 3);

    assert(test_list.size() == 9);
    assert(test_list.elementAt(3) == 'z');
    assert(test_list.toString() == "[CharLinkedList of size 9 <<abczdefgh>>]");

}

// Tests out-of-range insertion for a non-empty list.
void insertAt_nonempty_incorrect() {
   
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8]");
    
}

void isEmpty_emptyList() { 
    CharLinkedList test_list;
    assert(test_list.isEmpty());
    assert(test_list.size() == 0);
}

void isEmpty_notEmptyList() { 
    char test_arr[3] = { 'a', 'b', 'c'};
    CharLinkedList test_list(test_arr, 3);
    assert(not(test_list.isEmpty()));
    assert(test_list.size() == 3);
}

void clearTest() {
    char test_arr[3] = { 'a', 'b', 'c'};
    CharLinkedList test_list(test_arr, 3);
    test_list.clear();
    assert(test_list.isEmpty());
    assert(test_list.size() == 0);
}

void clearTestEmpty() {
    CharLinkedList test_list;
    test_list.clear();
    assert(test_list.isEmpty());
    assert(test_list.size() == 0);
}

void sizeTest() {
    char test_arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList test_list(test_arr, 5);
    assert(test_list.size() == 5);
}

void sizeTest_Empty() {
    CharLinkedList test_list;
    assert(test_list.isEmpty());
    assert(test_list.size() == 0);
}

void firstTest() {
    char test_arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList test_list(test_arr, 5);
    assert(test_list.first() == 'a');
}

void firstTest_Empty() {
    bool runtime_error_thrown = false;
    std::string error_message = "";
    CharLinkedList test_list;
    try {
        test_list.first();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot get first of empty LinkedList");
}

void lastTest() {
    char test_arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList test_list(test_arr, 5);
    assert(test_list.last() == 'e');
}

void lastTest_Empty() {
    bool runtime_error_thrown = false;
    std::string error_message = "";
    CharLinkedList test_list;
    try {
        test_list.last();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot get last of empty LinkedList");
}

void elementAtTest() {
    char test_arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList test_list(test_arr, 5);
    assert(test_list.elementAt(3) == 'd');
}

void elementAtTest_error() {

    bool range_error_thrown = false;
    std::string error_message = "";
    char test_arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList test_list(test_arr, 5);
    try {
        test_list.elementAt(5);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (5) not in range [0..5)");
    
}

void elementAtTest_errorNegative() {

    bool range_error_thrown = false;
    std::string error_message = "";
    char test_arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList test_list(test_arr, 5);
    try {
        test_list.elementAt(-1);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (-1) not in range [0..5)");
    
}

void toStringTest() {
    char test_arr[6] = {'Q', 'U', 'A', 'N', 'V', 'U'};
    CharLinkedList test_list(test_arr, 6);
    assert(test_list.toString() == "[CharLinkedList of size 6 <<QUANVU>>]");
}

void toStringTest_sizeOne() {
    char test_arr[6] = {'Q'};
    CharLinkedList test_list(test_arr, 1);
    assert(test_list.toString() == "[CharLinkedList of size 1 <<Q>>]");
}

void toStringTest_Empty() {
    CharLinkedList test_list;
    assert(test_list.size() == 0);
    assert(test_list.isEmpty());
    assert(test_list.toString() == "[CharLinkedList of size 0 <<>>]");
}

void toReverseStringTest() {
    char test_arr[6] = {'Q', 'U', 'A', 'N', 'V', 'U'};
    CharLinkedList test_list(test_arr, 6);
    assert(test_list.toReverseString() == 
    "[CharLinkedList of size 6 <<UVNAUQ>>]");
}

void toReverseStringTest_Empty() {
    CharLinkedList test_list;
    assert(test_list.size() == 0);
    assert(test_list.isEmpty());
    assert(test_list.toString() == "[CharLinkedList of size 0 <<>>]");
}

void pushAtBackTest() {
    char test_arr[5] = {'Q', 'U', 'A', 'N', 'V'};
    CharLinkedList test_list(test_arr, 5);
    test_list.pushAtBack('U');
    assert(test_list.elementAt(0) == 'Q');
    assert(test_list.elementAt(1) == 'U');
    assert(test_list.elementAt(2) == 'A');
    assert(test_list.elementAt(3) == 'N');
    assert(test_list.elementAt(4) == 'V');
    assert(test_list.elementAt(5) == 'U');
    assert(test_list.size() == 6);
}

void pushAtBackTest_emptyLong() {
    CharLinkedList test_list;
    test_list.pushAtBack('T');
    test_list.pushAtBack('E');
    test_list.pushAtBack('S');
    test_list.pushAtBack('T');
    test_list.pushAtBack('I');
    test_list.pushAtBack('N');
    test_list.pushAtBack('G');
    assert(test_list.elementAt(0) == 'T');
    assert(test_list.elementAt(1) == 'E');
    assert(test_list.elementAt(2) == 'S');
    assert(test_list.elementAt(3) == 'T');
    assert(test_list.elementAt(4) == 'I');
    assert(test_list.elementAt(5) == 'N');
    assert(test_list.elementAt(6) == 'G');

    assert(test_list.size() == 7);
}

void pushAtFrontTest() {
    char test_arr[5] = {'U', 'A', 'N', 'V', 'U'};
    CharLinkedList test_list(test_arr, 5);
    test_list.pushAtFront('Q');
    assert(test_list.elementAt(0) == 'Q');
    assert(test_list.elementAt(1) == 'U');
    assert(test_list.elementAt(2) == 'A');
    assert(test_list.elementAt(3) == 'N');
    assert(test_list.elementAt(4) == 'V');
    assert(test_list.elementAt(5) == 'U');
    assert(test_list.size() == 6);
}

void pushAtFrontTest_emptyLong() {
    CharLinkedList test_list;
    test_list.pushAtFront('G');
    test_list.pushAtFront('N');
    test_list.pushAtFront('I');
    test_list.pushAtFront('T');
    test_list.pushAtFront('S');
    test_list.pushAtFront('E');
    test_list.pushAtFront('T');
    assert(test_list.elementAt(0) == 'T');
    assert(test_list.elementAt(1) == 'E');
    assert(test_list.elementAt(2) == 'S');
    assert(test_list.elementAt(3) == 'T');
    assert(test_list.elementAt(4) == 'I');
    assert(test_list.elementAt(5) == 'N');
    assert(test_list.elementAt(6) == 'G');

    assert(test_list.size() == 7);
}

void pushAtFrontTestOneThousand() {
    char test_arr[5] = {'Q', 'U', 'A', 'N', 'V'};
    CharLinkedList test_list(test_arr, 5);
    for(int i = 0; i < 1000; i++){
        test_list.pushAtFront('a');
    }
    for(int i = 0; i < 1000; i++){
        assert(test_list.elementAt(i) == 'a');
    }
    assert(test_list.elementAt(1000) == 'Q');
    assert(test_list.elementAt(1001) == 'U');
    assert(test_list.elementAt(1002) == 'A');
    assert(test_list.elementAt(1003) == 'N');
    assert(test_list.elementAt(1004) == 'V');
    assert(test_list.size() == 1005);
}

void insertAtTest() {
    char test_arr[5] = {'Q', 'U', 'A', 'V', 'U'};
    CharLinkedList test_list(test_arr, 5);
    test_list.insertAt('N', 3);
    assert(test_list.elementAt(0) == 'Q');
    assert(test_list.elementAt(1) == 'U');
    assert(test_list.elementAt(2) == 'A');
    assert(test_list.elementAt(3) == 'N');
    assert(test_list.elementAt(4) == 'V');
    assert(test_list.elementAt(5) == 'U');
    assert(test_list.size() == 6);
}

void insertInOrderTest() {
    char test_arr[6] = {'A', 'B', 'D', 'E', 'F'};
    CharLinkedList test_list(test_arr, 6);
    test_list.insertInOrder('C');
    assert(test_list.elementAt(0) == 'A');
    assert(test_list.elementAt(1) == 'B');
    assert(test_list.elementAt(2) == 'C');
    assert(test_list.elementAt(3) == 'D');
    assert(test_list.elementAt(4) == 'E');
    assert(test_list.elementAt(5) == 'F');
}

void insertInOrderMany() {
    char test_arr[11] = {'A', 'B', 'C', 'E', 'F', 'G', 'I',
    'J', 'K', 'M', 'N'};
    CharLinkedList test_list(test_arr, 11);
    test_list.insertInOrder('D');
    test_list.insertInOrder('H');
    test_list.insertInOrder('L');
    test_list.insertInOrder('A');
    test_list.insertInOrder('C');
    assert(test_list.toString() == 
    "[CharLinkedList of size 16 <<AABCCDEFGHIJKLMN>>]");
}

void insertInOrderTest_last() {
    char test_arr[5] = {'A', 'B', 'C', 'D', 'E'};
    CharLinkedList test_list(test_arr, 5);
    test_list.insertInOrder('F');
    assert(test_list.elementAt(0) == 'A');
    assert(test_list.elementAt(1) == 'B');
    assert(test_list.elementAt(2) == 'C');
    assert(test_list.elementAt(3) == 'D');
    assert(test_list.elementAt(4) == 'E');
    assert(test_list.elementAt(5) == 'F');
}

void insertInOrderTest_empty() {
    CharLinkedList test_list;
    test_list.insertInOrder('A');
    assert(test_list.elementAt(0) == 'A');
    assert(test_list.size() == 1);
}

void popFromFrontTest() {
    char test_arr[6] = {'A', 'B', 'C', 'D', 'E', 'F'};
    CharLinkedList test_list(test_arr, 6);
    test_list.popFromFront();
    assert(test_list.elementAt(0) == 'B');
    assert(test_list.elementAt(1) == 'C');
    assert(test_list.elementAt(2) == 'D');
    assert(test_list.elementAt(3) == 'E');
    assert(test_list.elementAt(4) == 'F');
    assert(test_list.size() == 5);
}

void popFromFrontTest_empty() {

    bool runtime_error_thrown = false;
    std::string error_message = "";
    CharLinkedList test_list;
    try {
        test_list.popFromFront();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
    
}

void popFromBackTest() {
    char test_arr[6] = {'A', 'B', 'C', 'D', 'E', 'F'};
    CharLinkedList test_list(test_arr, 6);
    test_list.popFromBack();
    assert(test_list.elementAt(0) == 'A');
    assert(test_list.elementAt(1) == 'B');
    assert(test_list.elementAt(2) == 'C');
    assert(test_list.elementAt(3) == 'D');
    assert(test_list.elementAt(4) == 'E');
    assert(test_list.size() == 5);
}

void popFromBackTest_empty() {

    bool runtime_error_thrown = false;
    std::string error_message = "";
    CharLinkedList test_list;
    try {
        test_list.popFromBack();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
    
}

void removeAtTest() {
    char test_arr[6] = {'A', 'B', 'C', 'D', 'E', 'F'};
    CharLinkedList test_list(test_arr, 6);
    test_list.removeAt(3);
    assert(test_list.elementAt(0) == 'A');
    assert(test_list.elementAt(1) == 'B');
    assert(test_list.elementAt(2) == 'C');
    assert(test_list.elementAt(3) == 'E');
    assert(test_list.elementAt(4) == 'F');
    assert(test_list.size() == 5);
}

void removeAtTestOutOfRangeSize() {
    bool range_error_thrown = false;
    std::string error_message = "";
    char test_arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList test_list(test_arr, 5);
    try {
        test_list.removeAt(5);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    
    assert(range_error_thrown);
    assert(error_message == "index (5) not in range [0..5)");
}

void removeAtTestOutOfRangeSize1() {
    bool range_error_thrown = false;
    std::string error_message = "";
    char test_arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList test_list(test_arr, 5);
    try {
        test_list.removeAt(6);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    
    assert(range_error_thrown);
    assert(error_message == "index (6) not in range [0..5)");
}

void removeAtTest_error() {

    bool range_error_thrown = false;
    std::string error_message = "";
    char test_arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList test_list(test_arr, 5);
    try {
        test_list.removeAt(20);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    
    assert(range_error_thrown);
    assert(error_message == "index (20) not in range [0..5)");
    
}

void replaceAtTest() {
    char test_arr[6] = {'A', 'B', 'Q', 'D', 'E', 'F'};
    CharLinkedList test_list(test_arr, 6);
    test_list.replaceAt('C', 2);
    assert(test_list.elementAt(0) == 'A');
    assert(test_list.elementAt(1) == 'B');
    assert(test_list.elementAt(2) == 'C');
    assert(test_list.elementAt(3) == 'D');
    assert(test_list.elementAt(4) == 'E');
    assert(test_list.elementAt(5) == 'F');
    assert(test_list.size() == 6);
}

void replaceAtTest_error() {

    bool range_error_thrown = false;
    std::string error_message = "";
    char test_arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList test_list(test_arr, 5);
    try {
        test_list.replaceAt('x', 20);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    
    assert(range_error_thrown);
    assert(error_message == "index (20) not in range [0..5)");
    
}

void concatenateTest() {
    char test_arr1[3] = {'c', 'a', 't'};
    CharLinkedList test_list1(test_arr1, 3);
    CharLinkedList emptyList;
    test_list1.concatenate(&emptyList);
    assert(test_list1.elementAt(0) == 'c');
    assert(test_list1.elementAt(1) == 'a');
    assert(test_list1.elementAt(2) == 't');

    char test_arr2[8] = {'C', 'H', 'E', 'S', 'H', 'I', 'R', 'E'};
    CharLinkedList test_list2(test_arr2, 8);
    emptyList.concatenate(&test_list2);
    assert(emptyList.elementAt(0) == 'C');
    assert(emptyList.elementAt(1) == 'H');
    assert(emptyList.elementAt(2) == 'E');
    assert(emptyList.elementAt(3) == 'S');
    assert(emptyList.elementAt(4) == 'H');
    assert(emptyList.elementAt(5) == 'I');
    assert(emptyList.elementAt(6) == 'R');
    assert(emptyList.elementAt(7) == 'E');

    test_list1.concatenate(&test_list2);
    assert(test_list1.elementAt(0) == 'c');
    assert(test_list1.elementAt(1) == 'a');
    assert(test_list1.elementAt(2) == 't');
    assert(test_list1.elementAt(3) == 'C');
    assert(test_list1.elementAt(4) == 'H');
    assert(test_list1.elementAt(5) == 'E');
    assert(test_list1.elementAt(6) == 'S');
    assert(test_list1.elementAt(7) == 'H');
    assert(test_list1.elementAt(8) == 'I');
    assert(test_list1.elementAt(9) == 'R');
    assert(test_list1.elementAt(10) == 'E');
}

void concatenateEmptyTest() {
    char test_arr1[3] = {'c', 'a', 't'};
    CharLinkedList test_list1(test_arr1, 3);
    CharLinkedList emptyList;
    emptyList.concatenate(&test_list1);
}

void concatenateEmptyTest2() {
    char test_arr1[3] = {'c', 'a', 't'};
    CharLinkedList test_list1(test_arr1, 3);
    CharLinkedList emptyList;
    test_list1.concatenate(&emptyList);
    assert(test_list1.elementAt(0) == 'c');
    assert(test_list1.elementAt(1) == 'a');
    assert(test_list1.elementAt(2) == 't');
}

void concatenateTest_itself() {
    char test_arr1[8] = {'C', 'H', 'E', 'S', 'H', 'I', 'R', 'E'};
    CharLinkedList test_list1(test_arr1, 8);

    test_list1.concatenate(&test_list1);
    assert(test_list1.elementAt(0) == 'C');
    assert(test_list1.elementAt(1) == 'H');
    assert(test_list1.elementAt(2) == 'E');
    assert(test_list1.elementAt(3) == 'S');
    assert(test_list1.elementAt(4) == 'H');
    assert(test_list1.elementAt(5) == 'I');
    assert(test_list1.elementAt(6) == 'R');
    assert(test_list1.elementAt(7) == 'E');
    assert(test_list1.elementAt(8) == 'C');
    assert(test_list1.elementAt(9) == 'H');
    assert(test_list1.elementAt(10) == 'E');
    assert(test_list1.elementAt(11) == 'S');
    assert(test_list1.elementAt(12) == 'H');
    assert(test_list1.elementAt(13) == 'I');
    assert(test_list1.elementAt(14) == 'R');
    assert(test_list1.elementAt(15) == 'E');
}

void concatenateEmptyEmpty() {
    CharLinkedList test_list1;
    CharLinkedList test_list2;
    test_list1.concatenate(&test_list2);
    assert(test_list1.isEmpty());
}
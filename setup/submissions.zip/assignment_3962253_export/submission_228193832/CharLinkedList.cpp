/*
 *  CharLinkedList.cpp
 *  Quan Vu
 *  02/03/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Implement a class, CharLinkedList, for managing Nodes of 
 *  characters, providing various operations such as insertion, removal, 
 *  concatenation, and string representation.
 *
 */

#include "CharLinkedList.h"
#include <sstream>

/*
 * name:      CharLinkedList (default constructor)
 * purpose:   Initializes an empty CharLinkedList with zero elements.
 * arguments: None.
 * returns:   A CharLinkedList object with the front node being set to nullptr.
 */
CharLinkedList::CharLinkedList() {
    front = nullptr;
}

/*
 * name:      CharLinkedList (constructor with single character)
 * purpose:   Initializes a CharLinkedList with a single character.
 * arguments: a char c representing the initial character of the CharLinkedList
 * returns:   A CharLinkedList object with a front node containing character c,
 *            and the next and previous node being nullptr.
 */
CharLinkedList::CharLinkedList(char c) {
    front = new Node;
    front->character = c;
    front->next = nullptr;
    front->previous = nullptr;
}

/*
 * name:      CharLinkedList (constructor with character array and size)
 * purpose:   Initializes a CharLinkedList with the elements 
 *            from a character array.
 * arguments: a char array arr representing the initial elements, 
 *            and an int size representing the size of the array
 * returns:   A CharLinkedList object with int size amount of nodes and each
 *            node containing a character in the character array.
 */
CharLinkedList::CharLinkedList(char arr[], int size) {
    if (size <= 0) {
        front = nullptr;
        return;
    }

    front = new Node;
    front->character = arr[0];
    front->next = nullptr;
    front->previous = nullptr;

    Node* current = front;

    for (int i = 1; i < size; ++i) {
        current->next = new Node;
        current->next->character = arr[i];
        current->next->next = nullptr;
        current->next->previous = current;
        current = current->next;
    }
}

/*
 * name:      CharLinkedList (copy constructor)
 * purpose:   Creates a deep copy of another CharLinkedList instance.
 * arguments: a const reference to another CharLinkedList object (other)
 * returns:   A new CharLinkedList object with the same elements 
 *            as the other instance.
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other) {
    front = new Node;
    front->character = other.front->character;
    front->next = nullptr;
    front->previous = nullptr;

    Node *current = front;
    Node *otherCurrent = other.front->next;

    while(otherCurrent != nullptr){
        Node *newNode = new Node;
        newNode->character = otherCurrent->character;
        newNode->next = nullptr;
        newNode->previous = current;

        current->next = newNode;

        current = newNode;
        otherCurrent = otherCurrent->next;
    }
}

/*
 * name:      ~CharLinkedList (destructor)
 * purpose:   Deallocates memory used by the CharLinkedList.
 * arguments: None.
 * returns:   None.
 */
CharLinkedList::~CharLinkedList() {
    deleteList(front);
}

/*
 * name:      operator=
 * purpose:   Assigns the content of another 
 *            CharLinkedList to this CharLinkedList.
 * arguments: a const reference to a CharLinkedList representing 
 *            the other linked list.
 * returns:   A reference to the modified CharLinkedList.
 */
CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other) {
    if(this == &other){
        return *this;
    }
    clear();
    if(other.isEmpty()){
        return *this;
    }
    front = new Node;
    front->character = other.front->character;
    front->next = nullptr;
    front->previous = nullptr;

    Node *current = front;
    Node *otherCurrent = other.front->next;

    while(otherCurrent != nullptr){
        Node *newNode = new Node;
        newNode->character = otherCurrent->character;
        newNode->next = nullptr;
        newNode->previous = current;

        current->next = newNode;

        current = newNode;
        otherCurrent = otherCurrent->next;
    }
    return *this;
}

/*
 * name:      isEmpty
 * purpose:   Checks if the CharLinkedList is empty.
 * arguments: None.
 * returns:   True if the CharLinkedList is empty and false if not empty.
 */
bool CharLinkedList::isEmpty() const {
    return (front == nullptr);
}

/*
 * name:      clear
 * purpose:   Clears the CharLinkedList
 * arguments: None.
 * returns:   None.
 */
void CharLinkedList::clear() {
    Node *current = front;

    while (current != nullptr){
        Node *nextNode = current->next;
        delete current;
        current = nextNode;
    }

    front = nullptr;
}

/*
 * name:      size
 * purpose:   Returns the number of elements in the CharLinkedList.
 * arguments: None.
 * returns:   An integer representing the number of elements 
 *            in the CharLinkedList.
 */
int CharLinkedList::size() const {
    if(isEmpty()){
        return 0;
    } else {
        int count = 0;
        Node *current = front;
    
        while (current != nullptr){
            count++;
            current = current->next;
        }
        return count;
    }
}

/*
 * name:      first
 * purpose:   Returns the first character in the CharLinkedList.
 * arguments: None.
 * returns:   The first character in the CharLinkedList.
 * effects:   Throws a runtime_error if the CharLinkedList is empty.
 */
char CharLinkedList::first() const {
    if(isEmpty()){
        throw std::runtime_error("cannot get first of empty LinkedList");
    }
    
    return front->character;
}

/*
 * name:      last
 * purpose:   Returns the last character in the CharLinkedList.
 * arguments: None.
 * returns:   The last character in the CharLinkedList.
 * effects:   Throws a runtime_error if the CharLinkedList is empty.
 */
char CharLinkedList::last() const {
    if(isEmpty()){
        throw std::runtime_error("cannot get last of empty LinkedList");
    }

    Node *last = front;
    while(last->next != nullptr){
        last = last->next;
    }
    return last->character;
}

/*
 * name:      elementAt
 * purpose:   Returns the character at the specified index in the CharLinkedList
 * arguments: an int index representing the position in the CharLinkedList
 * returns:   The character at the specified index.
 * effects:   Throws a range_error if the index is out of bounds.
 */
char CharLinkedList::elementAt(int index) const {
    if(index < 0 or index >= size()){
        throw std::range_error("index (" + std::to_string(index) 
        + ") not in range [0.." + std::to_string(size()) + ")");
    }

    return elementAtHelper(front, index);
}

/*
 * name:      toString
 * purpose:   Returns a string representation of the CharLinkedList.
 * arguments: None.
 * returns:   A string containing the CharLinkedList elements and size.
 */
std::string CharLinkedList::toString() const {
    if (isEmpty()){
        return "[CharLinkedList of size 0 <<>>]";
    } else {
        std::string str;
        Node *current = front;
    
        while (current->next != nullptr){
            str += current->character;
            current = current->next;
        }
            str += current->character;

        return "[CharLinkedList of size " + std::to_string(size()) + " <<" 
        + str + ">>]";
    }
}

/*
 * name:      toReverseString
 * purpose:   Returns a reversed string representation of the CharLinkedList.
 * arguments: None.
 * returns:   A string containing the CharLinkedList elements 
 *            in reverse and size.
 */
std::string CharLinkedList::toReverseString() const {
    if (isEmpty()){
        return "[CharLinkedList of size 0 <<>>]";
    } else {
        std::string str;
        Node *current = front;
    
        while (current->next != nullptr){
            current = current->next;
        }

        while(current->previous != nullptr){
            str += current->character;
            current = current->previous;
        }
            str += current->character;

        return "[CharLinkedList of size " + std::to_string(size()) + " <<" 
        + str + ">>]";
    }
}

/*
 * name:      pushAtBack
 * purpose:   Inserts a character at the back of the CharLinkedList.
 * arguments: a char c representing the character to be inserted
 * returns:   None.
 */
void CharLinkedList::pushAtBack(char c) {
    Node *backNode = new Node;
    backNode->character = c;
    backNode->next = nullptr;

    if(isEmpty()) {
        backNode->previous = nullptr;
        front = backNode;
    } else {
        Node *lastNode = front;
        while(lastNode->next != nullptr){
            lastNode = lastNode->next;
        }

        lastNode->next = backNode;
        backNode->previous = lastNode;
    }
}

/*
 * name:      pushAtFront
 * purpose:   Inserts a character at the front of the CharLinkedList.
 * arguments: a char c representing the character to be inserted
 * returns:   None.
 */
void CharLinkedList::pushAtFront(char c) {
    Node *frontNode = new Node;
    frontNode->character = c;
    frontNode->next = front;
    frontNode->previous = nullptr;

    if(front != nullptr) {
        front->previous = frontNode;
    }

    front = frontNode;
}

/*
 * name:      insertAt
 * purpose:   Inserts a character at the specified index in the CharLinkedList.
 * arguments: a char c representing the character to be inserted, 
 *            and an int index representing the position.
 * returns:   None.
 * effects:   Throws a range_error if the index is out of bounds.
 */
void CharLinkedList::insertAt(char c, int index) {
    if(index < 0 or index > size()){
        throw std::range_error("index (" + std::to_string(index) 
        + ") not in range [0.." + std::to_string(size()) + "]");
    }

    if(index == 0){
        pushAtFront(c);
    } else if (index == size()){
        pushAtBack(c);
    } else {
        Node *insertNode = new Node;
        insertNode->character = c;
        insertNode->next = nullptr;
        insertNode->previous = nullptr;
        Node *checkNode  = front;
        for (int i = 0; i < index - 1; i++){
            checkNode = checkNode->next;
        }
        insertNode->next = checkNode->next;
        insertNode->previous = checkNode;
        checkNode->next->previous = insertNode;
        checkNode->next = insertNode;
    }
}

/*
 * name:      insertInOrder
 * purpose:   Inserts a character in ASCII order in the CharLinkedList.
 * arguments: a char c representing the character to be inserted
 * returns:   None.
 */
void CharLinkedList::insertInOrder(char c) {
    Node *insertNode = new Node;
    insertNode->character = c;
    insertNode->next = nullptr;
    insertNode->previous = nullptr;

    if(isEmpty()){
        front = insertNode;
    } else {
        Node *current = front;
        while(current->next != nullptr and c >= current->next->character){
            current = current->next;
        }
        insertNode->next = current->next;
        insertNode->previous = current;

        if(current->next != nullptr){
            current->next->previous = insertNode;
        }

        current->next = insertNode;
    }
}

/*
 * name:      popFromFront
 * purpose:   Removes the character from the front of the CharLinkedList.
 * arguments: None.
 * returns:   None.
 * effects:   Throws a runtime_error if the CharLinkedList is empty.
 */
void CharLinkedList::popFromFront() {
    if(isEmpty()){
        throw std::runtime_error("cannot pop from empty LinkedList");
    } else if (size() == 1){
        clear();
    } else {
        Node *oldFront = front;
        front = front->next;
        front->previous = nullptr;
        delete oldFront;
    }
}

/*
 * name:      popFromBack
 * purpose:   Removes the character from the back of the CharLinkedList.
 * arguments: None.
 * returns:   None.
 * effects:   Throws a runtime_error if the CharLinkedList is empty.
 */
void CharLinkedList::popFromBack() {
    if(isEmpty()){
        throw std::runtime_error("cannot pop from empty LinkedList");
    } else if (size() == 1){
        clear();
    } else {
        Node *backNode = front;
        while(backNode->next != nullptr){
            backNode = backNode->next;
        }
        backNode->previous->next = nullptr;
        delete backNode;
    }
}

/*
 * name:      removeAt
 * purpose:   Removes the character at the specified 
 *            index in the CharLinkedList.
 * arguments: an int index representing the position
 * returns:   None.
 * effects:   Throws a range_error if the index is out of bounds.
 */
void CharLinkedList::removeAt(int index) {
    if(index < 0 or index >= size()){
        throw std::range_error("index (" + std::to_string(index) 
        + ") not in range [0.." + std::to_string(size()) + ")");
    }

    if(index == 0){
        popFromFront();
    } else if (index == size() - 1){
        popFromBack();
    } else {
        Node *previousNode = front;
        for(int i = 0; i < index - 1; i++){
            previousNode = previousNode->next;
        }
        Node *removeNode = previousNode->next;
        previousNode->next = removeNode->next;
        removeNode->next->previous = previousNode;

        delete removeNode;
    }
}

/*
 * name:      replaceAt
 * purpose:   Replaces the character at the specified index in the 
 *            CharLinkedList with a new character.
 * arguments: a char c representing the new character, 
 *            and an int index representing the position
 * returns:   None.
 * effects:   Throws a range_error if the index is out of bounds.
 */
void CharLinkedList::replaceAt(char c, int index) {
    if(index < 0 or index >= size()){
        throw std::range_error("index (" + std::to_string(index) 
        + ") not in range [0.." + std::to_string(size()) + ")");
    }
    
    replaceAtHelper(front, c, index);
}

/*
 * name:      concatenate
 * purpose:   Concatenates the elements of another CharLinkedList to the end 
 *            of the current CharLinkedList.
 * arguments: a pointer to another CharLinkedList
 * returns:   None.
 */
void CharLinkedList::concatenate(CharLinkedList *other) {
    if (this == other){
        CharLinkedList secondList(*other);
        for (int i = 0; i < secondList.size(); i++){
            pushAtBack(secondList.elementAt(i));
        }
    } else {
        for (int i = 0; i < other->size(); i++){
            pushAtBack(other->elementAt(i));
        }
    }
}

/*
 * name:      deleteList
 * purpose:   Helper function used by destructor to deallocate memory used by
 *            the CharLinkedList
 * arguments: a pointer to a Node in the CharLinkedList (should be front Node).
 * returns:   None.
 */

void CharLinkedList::deleteList(Node *current) {
    if (current != nullptr) {
        deleteList(current->next);
        delete current;
    }
}

/*
 * name:      elementAtHelper
 * purpose:   Returns the character at the specified index in the CharLinkedList
 * arguments: a pointer to a Node in the CharLinkedList 
 *            (should initially be front Node), and an int index representing
 *            how far the intended element is.
 * returns:   The character at the node when index is 0 (index is 0 at the
 *            index specified in original elementAt function) or a recursive
 *            call to the function using the next node 
 *            and index - 1 as arguments.
 * effects:   Throws a range_error if the array is empty
 */
char CharLinkedList::elementAtHelper(Node *current, int index) const {
    if (current == nullptr) {
        throw std::range_error("index (" + std::to_string(index) 
        + ") not in range [0.." + std::to_string(size()) + ")");
    }

    if (index == 0) {
        return current->character;
    }

    return elementAtHelper(current->next, index - 1);
}

/*
 * name:      replaceAtHelper
 * purpose:   Replaces the character at the specified index in the 
 *            CharLinkedList with a new character.
 * arguments: a pointer to a Node in the CharLinkedList (should initially be 
 *            front Node), a char c representing the new character, and an int
 *            index representing how far the intended element is.
 * returns:   None.
 */
void CharLinkedList::replaceAtHelper(Node *current, char c, int index){
    if(index == 0){
        current->character = c;
    } else {
        replaceAtHelper(current->next, c, index - 1);
    }
}
/*
 *  CharLinkedList.cpp
 *  Javier Friedman
 *  2/1/23
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  this file is implementing the methods from the charlistarray class. every
 *  function even the private ones are defined here. This is what is under the
 *  hood of each function.
 */

#include "CharLinkedList.h"
#include <sstream>
#include <string>
#include <iostream>
#include <stdexcept>

using namespace std;


/*
 * name:      CharLinkedList default constructor
 * purpose:   initialize an empty Linkedlist
 * arguments: none
 * returns:   none
 * effects:   front and back and numitems are initialized
 */
CharLinkedList::CharLinkedList(){
    front = nullptr;
    back = nullptr;
    numitems = 0;
}

/*
 * name:      CharLinkedList second constructor
 * purpose:   creates a one element list with no links yet. 
 * arguments: character
 * returns:   none
 * effects:   initializes front and back and numitems
 */
CharLinkedList::CharLinkedList(char c){
    front = nullptr;
    back = nullptr;
    numitems = 0;
    pushAtFront(c);
}

/*
 * name:      CharLinkedList third constructor
 * purpose:   The third constructor takes an array of characters and the integer
 *            length of that array and turns it into a linked list
 * arguments: character array and integer size of the array
 * returns:   none
 * effects:   initializes front and back and numitems, and build links
 */
CharLinkedList::CharLinkedList(char arr[], int size){
    front = nullptr;
    back = nullptr;
    numitems = 0;
    
    for (int i = size; i > 0; i--) {
        pushAtFront(arr[i-1]);
    }
}

/*
 * name:      CharLinkedList copy constructor
 * purpose:   makes a deep copy of a given instance
 * arguments: instance of another character linked list
 * returns:   none
 * effects:   initializes front and back and numitems
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other) {
    this->numitems = 0;
    this->front = nullptr;
    this->back = nullptr;

    //edgecase: if other instance doesn't have a list
    if (other.numitems > 0) { 
        Node *curr = other.front;
        
        for ( int i = 0; i < other.numitems; i++) {
            this->pushAtBack(curr->data);
            curr = curr->next;   
        }
    }
    this->numitems = other.numitems;
}

/*
 * name:      CharLinkedList destructor
 * purpose:   free memory associated with the CharLinkedList
 * arguments: none
 * returns:   none
 * effects:   calls the deletedestructor and deletes front
 */
CharLinkedList::~CharLinkedList(){  
    if (numitems > 0) {
        deleteDestructor(front);
        delete front;
    }
}

/*
 * name:      deleteDestructor
 * purpose:   this is a recursive function that goes through the linked list
 *            and frees memory
 * arguments: none
 * returns:   none
 * effects:   frees memory allocated by CharLinkedList instances
 */
void CharLinkedList::deleteDestructor(Node *currnode){
    //basecase: made it to end of list
    if (currnode->next == nullptr) {
        return;
    } else {
        deleteDestructor(currnode->next);
        delete currnode->next;
        return;
    } 
}


/*
 * name:      CharLinkedList Overload Operator
 * purpose:   makes a deep copy of the instance on the right hand side into
 *            the instance on the left hand side
 * arguments: instance of another character linked list
 * returns:   a pointer to the instance of this object
 * effects:   makes this class equal to other class
 */
CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other) {
    // edgecase1: if its accessing itself return itself
    if (this == &other) {
        return *this;
    }
    // delete current list if it has one
    if (this->numitems > 0) {
        deleteDestructor(front);
        delete front;
        numitems = 0;
    }
    // edgecase2: make sure other instance has a list
    if (other.numitems > 0) { 
        Node *curr = other.front;
  
        for (int i = 0; i < other.numitems; i++) { 
            this->pushAtBack(curr->data);
            curr = curr->next;   
        }
    }
    this->numitems = other.numitems;
    return *this;
}



/*
 * name:      isEmpty
 * purpose:   determines if the CharLinkedList is empty or not
 * arguments: none
 * returns:   true if CharLinkedList contains no elements, false otherwise
 * effects:   none
 */
bool CharLinkedList::isEmpty() const{
    if (numitems == 0) {
        return true;
    }
    return false;
}

/*
 * name:      clear
 * purpose:   clears the CharLinkedList of all its elements
 * arguments: none
 * returns:   none
 * effects:   declares new values of class
 */
void CharLinkedList::clear(){  
    if (numitems > 0) {
        deleteDestructor(front);
        delete front;
        numitems = 0;
    }
}

/*
 * name:      size
 * purpose:   determine the number of items in the CharLinkedList
 * arguments: none
 * returns:   number of elements currently stored in the CharLinkedList
 * effects:   none
 */
int CharLinkedList::size() const{
    return numitems;
}

/*
 * name:      first
 * purpose:   returns the first character in the linked list. 
 * arguments: none
 * returns:   a character
 * effects:   If linked list is empty it should throw a runtime_error exception
 */
char CharLinkedList::first() const{
    if (isEmpty()) {
        throw runtime_error("cannot get first of empty LinkedList");
    }
    return front->data;
}

/*
 * name:      last
 * purpose:   returns the last element (char) in the linked list.
 * arguments: none
 * returns:   a character
 * effects:   If linked list is empty it should throw a runtime_error exception
 */
char CharLinkedList::last() const{
    if (isEmpty()) {
        throw runtime_error("cannot get last of empty LinkedList");
    }
    return back->data;
}


/*
 * name:      elementAt
 * purpose:   returns the element (char) in the linked list at given index. 
 * arguments: integer index
 * returns:   a character
 * effects:   If index is out of range it should throw a range_error exception
 */
char CharLinkedList::elementAt(int index) const{
    if (index < 0 or index >= numitems) {
        string errorString = "index (" + to_string(index) 
                        + ") not in range [0.." + to_string(numitems) + ")";
        throw range_error(errorString);
    } else if (index == numitems -1) {
        return back->data;
    } else if (index == 0) {
        return front->data;
    } else {
        Node* curr = front;
        
        for( int i = 0; i < index; i++){
            curr = curr->next;   
        }
        return curr->data;
    }
}

/*
 * name:      toString
 * purpose:   returns a string which contains the characters of the 
 *            CharLinkedList.
 * arguments: none
 * returns:   string of characters
 * effects:   none
 */
string CharLinkedList::toString() const{
    string word = "";

    if (numitems > 0) {
        Node *curr = front;
        int counter = 0;
        
        while (counter != numitems) {
            word = word + curr->data;
            curr = curr->next; 
            counter ++;
        }
    }
    string output = "[CharLinkedList of size " + to_string(numitems) + " <<" 
                    + word + ">>]";
    return output;
}


/*
 * name:      toReverseString
 * purpose:    It returns a string which contains the characters of the 
 *             CharLinkedList in reverse.
 * arguments: none
 * returns:   string of characters
 * effects:   none
 */
string CharLinkedList::toReverseString() const{
    string word = "";

    if (numitems > 0) {
        Node *curr = back;
        int counter = 0;
        
        while (counter != numitems) {
            word = word + curr->data;
            curr = curr->previous; 
            counter ++;
        }
    }
    string output = "[CharLinkedList of size " + to_string(numitems) + " <<" 
                + word + ">>]";
    return output;
}


/*
 * name:      pushAtBack
 * purpose:   It inserts the given new element at the end of the existing 
 *            linked list.
 * arguments: character element
 * returns:   none
 * effects:   builds new node for element, increases numitems, 
 *            realligns pointers, and change front and back if needed
 */
void CharLinkedList::pushAtBack(char c){
    Node* newNode = buildNode(c);
    //edgecase: if its first element
    if (numitems == 0) {
        newNode->next = nullptr;
        newNode->previous = nullptr;
        front = newNode;
    } else {
        newNode->next = nullptr;
        newNode->previous = back;
    }
    back = newNode;
    numitems++;
    untangler(newNode);
}

/*
 * name:      pushAtFront
 * purpose:   It inserts the given new element at the front of the existing 
 *            linked list.
 * arguments: character element
 * returns:   none
 * effects:   builds new node for element, increases numitems, 
 *            realligns pointers, and change front and back if needed
 */
void CharLinkedList::pushAtFront(char c){ 
    Node* newNode = buildNode(c);
    //what if its the first one
    if (numitems == 0) {
        newNode->next = nullptr;
        newNode->previous = nullptr;
        back = newNode;
    } else {
        newNode->next = front;
        newNode->previous = nullptr;
    }
    front = newNode;
    numitems++;
    untangler(newNode);
}


/*
 * name:      insertAt
 * purpose:   It inserts the new element at the specified index in the linked
 *            list, and realligns pointers 
 * arguments: integer index and character element
 * returns:   none
 * effects:   If index is out of range it should throw a range_error exception.
 *            It should build node, untangle pointers and increases numitems
 */
void CharLinkedList::insertAt(char c, int index){   
    if (index < 0 or index > numitems) {
        string errorString = "index (" + to_string(index)  
                       + ") not in range [0.." + to_string(numitems) + "]";

        throw range_error (errorString);
    } else if (index == 0) {
        pushAtFront(c);
    } else if (index == numitems) {
        pushAtBack(c);
    } else {
        Node *curr = findNode(index);
        Node* newNode = buildNode(c);
        newNode->next = curr->next;
        newNode->previous = curr;
        untangler(newNode);
        numitems ++;
    }
}




/*
 * name:      insertInOrder
 * purpose:   it inserts a character into the linked list in ASCII order, at the
 *            first correct index
 * arguments: character element
 * returns:   none
 * effects:   linked list adds new node
 */
void CharLinkedList::insertInOrder(char c){  
    if (numitems == 0) {
        //edgecase1: no items in the list
        pushAtFront(c);
    } else if (front->data >= c) {  
        // edgecase2: first item it greater
        pushAtFront(c);
    } else { 
        Node *curr = front;
        int counter = 0;

        while (curr->next != nullptr) {
            
            if (c >= curr->data and c <= curr->next->data) {
                insertAt(c, counter + 1);
                return; 
            }    
            curr = curr->next; 
            counter ++;
        }     
        //edgecase3: if make it to end of list
        pushAtBack(c);
    }
}

/*
 * name:      popFromFront
 * purpose:   It removes the first element from the linked list. 
 * arguments: none
 * returns:   none
 * effects:   If list is empty it should throw a runtime_error exception
 *            
 */
void CharLinkedList::popFromFront(){ 
    if (isEmpty()) {
        throw runtime_error("cannot pop from empty LinkedList");
    } else if (numitems == 1) {
        delete front;    
    } else {
        Node *nodeP = front->next;
        nodeP->previous = nullptr;
        delete front;
        front = nodeP; 
    }
    numitems --;
}

/*
 * name:      popFromBack
 * purpose:   It removes the last element from the linked list. 
 * arguments: none
 * returns:   none
 * effects:   If the list is empty it should throw a runtime_error exception,
 *            and it should readjust class member values.
 *            
 */
void CharLinkedList::popFromBack(){   
    if (isEmpty()) {
        throw runtime_error("cannot pop from empty LinkedList");
    } else if (numitems == 1) {
        delete back;      
    } else {
        Node *nodeP = back->previous;
        nodeP->next = nullptr;
        delete back;
        back = nodeP;
    }  
    numitems --;  
}

/*
 * name:      removeAt
 * purpose:   It removes the element at the specified index.  
 * arguments: integer index
 * returns:   none
 * effects:   If index is out of range it should throw a range_error exception
 */
void CharLinkedList::removeAt(int index){
    if (index < 0 or index >= numitems) {
        string errorString = "index (" + to_string(index) 
                    + ") not in range [0.." + to_string(numitems) + ")";

        throw range_error(errorString);
    }

    if (numitems > 0) {
        
        if (index == 0) {
            popFromFront();
        } else {
            Node *curr = findNode(index);
            Node *deleteP = curr->next;
            curr->next = deleteP->next;
            delete deleteP;
            untangler(curr);
            numitems --;
        }
    }
}

/*
 * name:      replaceAt
 * purpose:   It replaces the element at the specified index with the new 
 *            element.  
 * arguments: integer index and character element
 * returns:   none
 * effects:   If index is out of range it should throw a range_error exception
 */
void CharLinkedList::replaceAt(char c, int index){    
    if (index < 0 or index >= numitems) {
        string errorString = "index (" + to_string(index) 
                    + ") not in range [0.."  + to_string(numitems) + ")";
        throw range_error (errorString);
    }
    if (index == 0) {
        front->data = c;
    } else {
        Node *nodeP = findNode(index);
        nodeP->next->data = c;
    }
}



/*
 * name:      concatenate
 * purpose:   It adds a copy of linked list pointed to by the parameter value
 *            to the end of the this instance of the linked list.
 * arguments: pointer to a second CharLinkedList
 * returns:   none
 * effects:   linked list member values adjusted for
 */  

void CharLinkedList::concatenate(CharLinkedList *other){     
    int maxNumItems = other->numitems;
    //edgecase1: make sure other list has a list
    if (other->numitems > 0) {
        Node *currP1 = other->front;

        for (int i = 0; i < maxNumItems; i++) {
            this->pushAtBack(currP1->data);
            currP1 = currP1->next;      
        }
    }
}




/*
 * name:      buildNode
 * purpose:   Allocates memory in heap for new Node and returns pointer to it
 * arguments: character element
 * returns:   node pointer
 * effects:   makes new node
 */
CharLinkedList::Node *CharLinkedList::buildNode(char c){  
    Node* newNode = new Node;
    newNode->data = c;
    return newNode;
}

/*
 * name:      untangler
 * purpose:   takes in a node and makes sure that surrounding nodes point to it
 * arguments: node pointer
 * returns:   none
 * effects:   changes neighboring nodes' pointers
 */
void CharLinkedList::untangler(Node *currnode){     
    if (currnode->previous == nullptr and currnode->next ==nullptr) {
        //edgecase1 : nothing surrounding it, do nothing
        return;
    } else if (currnode->previous == nullptr) {
        // edgecase2: at beginning, so only one node pointing to this node
        currnode->next->previous = currnode;
    } else if (currnode->next == nullptr) {
        //edgecase3: at end, so only one node pointing to this node
        currnode->previous->next = currnode;
    } else {
        //normal
        currnode->previous->next = currnode;
        currnode->next->previous = currnode;
    }
}

/*
 * name:      findNode
 * purpose:   takes in an index value, and returns pointer to Node at the point
 *            in the linked list
 * arguments: index
 * returns:   node pointer
 * effects:   none
 */
CharLinkedList::Node *CharLinkedList::findNode(int index){   
    Node *curr = front;
    int curr_index = 0;

    // loop to position right before desired node
    while (curr_index < index -1) {
        curr = curr->next;
        curr_index ++;
    }   
    return curr;
}
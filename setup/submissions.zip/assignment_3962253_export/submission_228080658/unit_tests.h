/*
 *  unit_tests.h
 *  Javier Friedman
 *  2/6/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  this purpose of this file is to provide the framework of the unit_test,
 *  test file. There are various small tests that are used to test normal
 *  and edgecases of the charlinkedlist class methods.
 *
 */

/********************************************************************\
*                       CHAR LINKED LIST TESTS                        *
\********************************************************************/


#include "CharLinkedList.h"
#include <cassert>
#include <iostream>
#include <string>

using namespace std;

//////////COPY CONSTRUCTOR///////


// copy constructor test normal
void copy_constructor_normal() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList first_array(test_arr, 8);
    CharLinkedList copy_constructor(first_array);
    assert(copy_constructor.size() == 8);
    assert(copy_constructor.elementAt(3) == 'd');
    assert(copy_constructor.toString() 
            == "[CharLinkedList of size 8 <<abcdefgh>>]");

}

//if parameter is class with no array
void copy_constructor_no_array() {
    CharLinkedList empty_array;
    CharLinkedList copy_constructor(empty_array);
    assert(copy_constructor.size() == 0);
    assert(copy_constructor.toString() 
            == "[CharLinkedList of size 0 <<>>]");

}
// if paramater has array one index long
void copy_constructor_1_array() {
    CharLinkedList one_array('A');
    CharLinkedList copy_constructor(one_array);
    assert(copy_constructor.toString() 
            == "[CharLinkedList of size 1 <<A>>]");

}


///////////OVERLOAD OPERATOR////////////

//two arrays
void overload_two_arrays(){
    char test_arr1[6] = { 'j', 'a', 'v', 'i','e','r'}; 
    char test_arr2[6] = { 'n', 'a', 'n', 'b','o','o'}; 
    CharLinkedList test_list1(test_arr1, 6);
    CharLinkedList test_list2(test_arr2, 6 );
    test_list1 = test_list2;
    assert(&test_list1 != &test_list2);
    assert(test_list1.toString() == "[CharLinkedList of size 6 <<nanboo>>]");
}

//one array and one with one index
void overload_one_letter_arrayA(){
    char test_arr3[6] = { 'j', 'a', 'v', 'i','e','r'}; 
    CharLinkedList test_list3(test_arr3, 6);
    CharLinkedList test_list4('a');
    test_list3 = test_list4;
    assert(test_list3.toString() == "[CharLinkedList of size 1 <<a>>]");


}

//one array and one with one index
void overload_one_letter_arrayB(){
    char test_arr3[6] = { 'j', 'a', 'v', 'i','e','r'}; 
    CharLinkedList test_list3(test_arr3, 6);
    CharLinkedList test_list4('a');
    test_list4 = test_list3;
    assert(test_list3.toString() == "[CharLinkedList of size 6 <<javier>>]");

}

//if other array doesn't have anything but this array is normal
void overload_no_arrayA(){
    char test_arr5[6] = { 'j', 'a', 'v', 'i','e','r'}; 
    CharLinkedList test_list5(test_arr5, 6);
    CharLinkedList test_list6;
    test_list5 = test_list6;
    assert(test_list5.toString()== "[CharLinkedList of size 0 <<>>]");

}

//if other array is normal but this doesn't have an array yet
void overload_no_arrayB(){
    char test_arr5[6] = { 'j', 'a', 'v', 'i','e','r'}; 
    CharLinkedList test_list5(test_arr5, 6);
    CharLinkedList test_list6;
    test_list6 = test_list5;
    assert(test_list5.toString()== "[CharLinkedList of size 6 <<javier>>]");

}


////////////////isempty & clear & size/////////

// makes an array, then checks if its empty, then clears, then checks empty 
void is_empty_and_clear_checker(){
    char test_arr[6] = { 'j', 'a', 'v', 'i','e','r'}; 
    CharLinkedList test_list(test_arr, 6);
    assert(test_list.size() == 6);
    assert(not test_list.isEmpty());
    test_list.clear();
    assert(test_list.isEmpty());

}

//size checker to see if its accurate
void size_checker(){
    CharLinkedList test_list;
    assert(test_list.size() == 0);
    char test_arr[6] = { 'j', 'a', 'v', 'i','e','r'}; 
    CharLinkedList test_list2(test_arr, 6);
    assert(test_list2.size() == 6);

}


//////////FIRST AND LAST/////////

// first and last checker normal
void first_last_normal(){
    char test_arr[6] = { 'j', 'a', 'v', 'i','e','r'}; 
    CharLinkedList test_list(test_arr, 6);
    assert(test_list.last() == 'r');
    assert(test_list.first() == 'j');

}

//first and last with array with one index
void first_last_1(){
    CharLinkedList test_list('J');
    assert(test_list.last() == 'J');
    assert(test_list.first() == 'J');

}

//first with empty array
void first_empty_constructor(){
    CharLinkedList empty_array;
    string error_message = "";
    try{
        empty_array.first();

    }
    catch (runtime_error &e){
    error_message = e.what();
    assert(error_message == "cannot get first of empty LinkedList");

    }
}

//last with empty array
void last_empty_constructor(){
    CharLinkedList empty_array;
    string error_message = "";
    try{
        empty_array.last();

    }
    catch (runtime_error &e){
    error_message = e.what();
    assert(error_message == "cannot get last of empty LinkedList");

    }
}


///////////////ELEMENT AT TESTER////////////


//checks that error is thrown when out of context
void elementat_abnormal_array(){
    char test_arr[6] = { 'j', 'a', 'v', 'i','e','r'}; 
    CharLinkedList test_list(test_arr, 6);
    string error_message = "";

    try {
    test_list.elementAt(42);

    }
    catch (const range_error &e) {
    error_message = e.what();
    assert(error_message == "index (42) not in range [0..6)");
    
    } 
}

//checks for out of range lower bound
void elementat_abnormal_array2(){
    char test_arr[6] = { 'j', 'a', 'v', 'i','e','r'}; 
    CharLinkedList test_list(test_arr, 6);
    string error_message = "";

    try {
    test_list.elementAt(-1);

    }
    catch (const range_error &e) {
    error_message = e.what();
    assert(error_message == "index (-1) not in range [0..6)");
    
    } 
}

//checks in range with normal array
void elementat_normal_array(){
    char test_arr[6] = { 'j', 'a', 'v', 'i','e','r'}; 
    CharLinkedList test_list(test_arr, 6);
    assert(test_list.elementAt(0)=='j');
    assert(test_list.elementAt(5)=='r');
    assert(test_list.elementAt(2)=='v');
}

//checks in range with array with size 1
void elementat_normal_array_one(){
    CharLinkedList test_list('j');
    assert(test_list.elementAt(0)=='j');
}

//checks out of range with no array
void elementat_no_array_and_out_of_range(){
    CharLinkedList test_list;
    string error_message = "";
    
    try {
    test_list.elementAt(-1);

    }
    catch (const range_error &e) {
    error_message = e.what();
    assert(error_message == "index (-1) not in range [0..0)");
    
    } 
}

//checks with no array at position 0
void elementat_no_array(){
    CharLinkedList test_list1;
    string error_message = "";
    try {
    test_list1.elementAt(0);

    }
    catch (const range_error &e) {

    error_message = e.what();
    assert(error_message == "index (0) not in range [0..0)");
    
    } 
}
   
/////destructor test
void destruct_with_none(){
    CharLinkedList testlist;

}



///////////////////INSERT TESTER/////////////
//////also some element at///////

// // Tests incorrect insertion into an empty AL.
// Attempts to call insertAt for index larger than 0.
// This should result in an std::range_error being raised.
void insertAt_empty_incorrect() {

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    string error_message = "";

    CharLinkedList test_list;
    try {
    // insertAt for out-of-range index
    test_list.insertAt('a', 42);
    }
    catch (const range_error &e) {
    // if insertAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    range_error_thrown = true;

    error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0]");
    
}

// Tests correct insertAt for front of 1-element list.
void insertAt_front_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at front
    test_list.insertAt('b', 0);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'a');
    
}

// Tests correct insertAt for back of 1-element list.
void insertAt_back_singleton_list() { 
    // initialize 1-element list
    CharLinkedList test_list('a');
    // insert at back
    test_list.insertAt('b', 1);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    
}

// Tests calling insertAt for a large number of elements.
// Not only does this test insertAt, it also checks that
// array expansion works correctly.
void insertAt_many_elements() {
    
    CharLinkedList test_list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.insertAt('a', i);
    }

    assert(test_list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
    
}

// Tests insertion into front of a larger list
void insertAt_front_large_list() {
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);
    test_list.insertAt('y', 0);
    assert(test_list.size() == 10);
    assert(test_list.elementAt(0) == 'y');
    assert(test_list.toString() 
                == "[CharLinkedList of size 10 <<yabczdefgh>>]");

}

// Tests insertion into the back of a larger list
void insertAt_back_large_list() {
    char test_arr[10] = { 'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 10);  
    test_list.insertAt('x', 10);
    assert(test_list.size() == 11);
    assert(test_list.elementAt(10) == 'x');
    assert(test_list.toString() == 
    "[CharLinkedList of size 11 <<yabczdefghx>>]"); 

}

// Tests insertion into the middle of a larger list
void insertAt_middle_large_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);
    test_list.insertAt('z', 3);
    assert(test_list.size() == 9);
    assert(test_list.elementAt(3) == 'z');
    assert(test_list.toString() ==  "[CharLinkedList of size 9 <<abczdefgh>>]");

}

// // Tests out-of-range insertion for a non-empty list.
void insertAt_nonempty_incorrect() { 
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);
    // var to track whether range_error is thrown
    bool range_error_thrown = false;
    // var to track any error messages raised
    string error_message = "";

    try {
        test_list.insertAt('a', 42);
    }
    catch (const range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8]");
    
}

////////////TEST REMOVE AT///////////


//checks that error is thrown when out of context
void removeat_abnormal_array(){
    char test_arr[6] = { 'j', 'a', 'v', 'i','e','r'}; 
    CharLinkedList test_list(test_arr, 6);
    string error_message = "";
    try {
    test_list.removeAt(42);
    }
    catch (const range_error &e) {
    error_message = e.what();
    assert(error_message == "index (42) not in range [0..6)");  
    } 
}

//checks for out of range
void removeat_abnormal_array2(){
    char test_arr[6] = { 'j', 'a', 'v', 'i','e','r'}; 
    CharLinkedList test_list(test_arr, 6);
    string error_message = "";
    try {
    test_list.elementAt(-1);
    }
    catch (const range_error &e) {
    error_message = e.what();
    assert(error_message == "index (-1) not in range [0..6)");
    
    } 
}

//checks in range
void removeat_normal_array(){
    char test_arr[6] = { 'j', 'a', 'v', 'i','e','r'}; 
    CharLinkedList test_list(test_arr, 6);
    assert(test_list.toString()
        == "[CharLinkedList of size 6 <<javier>>]");
    test_list.removeAt(5);
    assert(test_list.toString()
         == "[CharLinkedList of size 5 <<javie>>]");
    test_list.removeAt(0);
    assert(test_list.toString()
         == "[CharLinkedList of size 4 <<avie>>]");

}

//what happens if we try to remove from and array with only one index
void remove_from_one(){
    CharLinkedList testlist('j');
    assert(testlist.toString() == "[CharLinkedList of size 1 <<j>>]");
    testlist.removeAt(0);
    assert(testlist.toString() == "[CharLinkedList of size 0 <<>>]");

}


//try to remove from array that is empty
void remove_no_array(){
    CharLinkedList test_list1;
    string error_message = "";
    try {
    // element for out-of-range index
    test_list1.removeAt(0);
    }
    catch (const range_error &e) {
    error_message = e.what();
    assert(error_message == "index (0) not in range [0..0)");  
    } 
}


//////////REPLACE AT//////////////

//when we try to replace something out of range
void replaceat_out__of_range1(){
    CharLinkedList test_list1;
    string error_message = "";
    try {
    test_list1.replaceAt('j', 0);
    }
    catch (const range_error &e) {
    error_message = e.what();
    assert(error_message == "index (0) not in range [0..0)");
    } 
}

//try another one
void replaceat_out__of_range2(){
    CharLinkedList test_list1('j');
    string error_message = "";
    try {
    test_list1.replaceAt('y', 24);
    }
    catch (const range_error &e) {
    error_message = e.what();
    assert(error_message == "index (24) not in range [0..1)");
    } 
}

//normal replacement test
void replaceat_normal(){
    char test_arr[3] = { 'j', 'a', 'v'}; 
    CharLinkedList test_list(test_arr, 3);  
    assert(test_list.toString() == "[CharLinkedList of size 3 <<jav>>]");
    test_list.replaceAt('y',2);
    assert(test_list.toString() == "[CharLinkedList of size 3 <<jay>>]");
    test_list.replaceAt('y',0);
    assert(test_list.toString() == "[CharLinkedList of size 3 <<yay>>]");

}

//reaplce at with 0 and end of list
void replaceat_front_back(){
    char test_arr[3] = { 'j', 'a', 'v'}; 
    CharLinkedList test_list(test_arr, 3);  
    test_list.replaceAt('y',0);
    assert(test_list.toString() == "[CharLinkedList of size 3 <<yav>>]");
    test_list.replaceAt('y',2);
    assert(test_list.toString() == "[CharLinkedList of size 3 <<yay>>]");

}

void replaceat_one_index(){
    CharLinkedList test_list('a');  
    test_list.replaceAt('y',0);
    assert(test_list.toString() == "[CharLinkedList of size 1 <<y>>]");

}

///////PUSH AT BACK AND PUSH AT FRONT///////


//function that tests to see if push at back work in normal array
void pushat_back_normal(){
    CharLinkedList testlist;
    testlist.pushAtBack('j');
    assert(testlist.toString() == "[CharLinkedList of size 1 <<j>>]");
    testlist.pushAtBack('j');
    assert(testlist.toString() == "[CharLinkedList of size 2 <<jj>>]");

}

//push at front works normally
void pushat_front_normal(){
    CharLinkedList testlist;
    testlist.pushAtFront('j');
    assert(testlist.toString() == "[CharLinkedList of size 1 <<j>>]");
    testlist.pushAtFront('j');
    assert(testlist.toString() == "[CharLinkedList of size 2 <<jj>>]");

}

////////////pop fromt front and pop from back/////

//pop from back out of range
void pop_from_back_no_array(){
    CharLinkedList testlist;
    string error_message = "";
    try{
    testlist.popFromBack();
    }
    catch (const runtime_error &e) {
    error_message = e.what();
    assert(error_message == "cannot pop from empty LinkedList");
    
    }
}

//pop from front out of range
void pop_from_front_no_array(){
    CharLinkedList testlist;
    string error_message = "";
    try{
    testlist.popFromFront();
    }
    catch (const runtime_error &e) {
    error_message = e.what();
    assert(error_message == "cannot pop from empty LinkedList");
    
    }
}

// normal testing moving back and forth
void pop_from_front_and_back(){
    CharLinkedList testlist;
    testlist.pushAtBack('j');
    assert(testlist.toString() == "[CharLinkedList of size 1 <<j>>]");
    testlist.popFromBack();
    assert(testlist.toString() == "[CharLinkedList of size 0 <<>>]");
    testlist.pushAtBack('a');
    assert(testlist.toString() == "[CharLinkedList of size 1 <<a>>]");
    testlist.popFromFront();
    assert(testlist.toString() == "[CharLinkedList of size 0 <<>>]");
    testlist.pushAtFront('g');
    assert(testlist.toString() == "[CharLinkedList of size 1 <<g>>]");

}

//////////INSERT IN ORDER TESTING////////


//no array 
void iio_no_array(){
    CharLinkedList testlist;
    testlist.insertInOrder('a');
    string tester = testlist.toString();
    assert(tester == "[CharLinkedList of size 1 <<a>>]");

}

//random test normal of putting random characters in order 
void iio_random_test(){
    CharLinkedList testlist('B');
    testlist.insertInOrder('!');
    assert(testlist.toString() == "[CharLinkedList of size 2 <<!B>>]");
    testlist.insertInOrder('A');
    assert(testlist.toString() == "[CharLinkedList of size 3 <<!AB>>]");
    testlist.insertInOrder('$');
    assert(testlist.toString() == "[CharLinkedList of size 4 <<!$AB>>]");
    testlist.insertInOrder('c');
    assert(testlist.toString() == "[CharLinkedList of size 5 <<!$ABc>>]");
    testlist.insertInOrder('B');
    assert(testlist.toString() == "[CharLinkedList of size 6 <<!$ABBc>>]");

}

//AZED insertinorder tester 
void IIO_AZED(){
    char test_arr[3] = { 'Z', 'E', 'D'};
    CharLinkedList first_array(test_arr, 3);  
    first_array.insertInOrder('A');
    assert(first_array.toString() == "[CharLinkedList of size 4 <<AZED>>]");

}


//back to back letters first
void iio_back_to_back_first(){
    CharLinkedList testlist('B');
    testlist.insertInOrder('B');
    assert(testlist.toString() == "[CharLinkedList of size 2 <<BB>>]");

}

//back to back letters in the middle
void iio_back_to_back_middle(){
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList testlist(test_arr, 8);
    testlist.insertInOrder('d');
    assert(testlist.toString() == "[CharLinkedList of size 9 <<abcddefgh>>]");
    testlist.insertInOrder('h');
    assert(testlist.toString() == "[CharLinkedList of size 10 <<abcddefghh>>]");

}

void iio_multiple_back_to_back(){
    char test_arr[3] = { 'Z', 'Z','Z'};
    CharLinkedList first_array(test_arr, 3);  
    first_array.insertInOrder('Z');
    assert(first_array.toString() == "[CharLinkedList of size 4 <<ZZZZ>>]");

}

//if first index is less than input
void iio_one_in_array1(){
    CharLinkedList testlist('a');
    testlist.insertInOrder('b');
    assert(testlist.toString() == "[CharLinkedList of size 2 <<ab>>]");

}

//if first index is greater than 
void iio_one_in_array2(){
    CharLinkedList testlist('b');
    testlist.insertInOrder('a');
    assert(testlist.toString() == "[CharLinkedList of size 2 <<ab>>]");

}

//makes it to the end with nothing
void iio_last_in_array(){
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList testlist(test_arr, 8);
    testlist.insertInOrder('i');
    assert(testlist.toString() == "[CharLinkedList of size 9 <<abcdefghi>>]");

}



// /////////////concatenate TESTER/////////

//two full arrays normal
void concatenate_two_full(){
    char test_arr1[4] = { 'j', 'a', 'v', 'i'};
    char test_arr2[4] = { 'e', 'r', 's','!'};
    CharLinkedList testlist1(test_arr1, 4);
    CharLinkedList testlist2(test_arr2, 4);
    testlist1.concatenate(&testlist2);
    assert(testlist1.toString() == "[CharLinkedList of size 8 <<javiers!>>]");

}

// //copyitself
void concatenate_itself(){
    char test_arr1[4] = { 'j', 'a', 'v', 'i'};
    CharLinkedList testlist1(test_arr1, 4);
    testlist1.concatenate(&testlist1);
    assert(testlist1.toString() == "[CharLinkedList of size 8 <<javijavi>>]");

}

//one full array one single index array
void concatenate_single_full1(){
    char test_arr1[4] = { 'j', 'a', 'v', 'i'};
    CharLinkedList testlist1(test_arr1, 4);
    CharLinkedList testlist2('!');
    testlist1.concatenate(&testlist2);
    assert(testlist1.toString() == "[CharLinkedList of size 5 <<javi!>>]");

}

//one full array one single swap pos
void concatenate_single_full2(){
    char test_arr1[4] = { 'j', 'a', 'v', 'i'};
    CharLinkedList testlist2(test_arr1, 4);
    CharLinkedList testlist1('!');
    testlist1.concatenate(&testlist2);
    assert(testlist1.toString() == "[CharLinkedList of size 5 <<!javi>>]");

}

//one full array and one empty array
void concatenate_empty_full1(){
    char test_arr1[4] = { 'j', 'a', 'v', 'i'};
    CharLinkedList testlist2(test_arr1, 4);
    CharLinkedList testlist1;
    testlist1.concatenate(&testlist2);
    assert(testlist1.toString() == "[CharLinkedList of size 4 <<javi>>]");

}


// //one full array and one empty array swap pos
void concatenate_empty_full2(){
    char test_arr1[4] = { 'j', 'a', 'v', 'i'};
    CharLinkedList testlist1(test_arr1, 4);
    CharLinkedList testlist2;
    testlist1.concatenate(&testlist2);
    assert(testlist1.toString() == "[CharLinkedList of size 4 <<javi>>]");

}

//both empty
void concatenate_empty_empty(){
    CharLinkedList testlist1;
    CharLinkedList testlist2;
    testlist1.concatenate(&testlist2);
    assert(testlist1.toString() == "[CharLinkedList of size 0 <<>>]");

}

//one at one index array, other at 0
void concatenate_empty_one1(){
    CharLinkedList testlist1('a');
    CharLinkedList testlist2;
    testlist1.concatenate(&testlist2);
    assert(testlist1.toString() == "[CharLinkedList of size 1 <<a>>]");
}

//one at one index array, other at 0 swap pos
void concatenate_empty_one2(){
    CharLinkedList testlist2('a');
    CharLinkedList testlist1;
    testlist1.concatenate(&testlist2);
    assert(testlist1.toString() == "[CharLinkedList of size 1 <<a>>]");

}




// ////////////TOSTRING TESTING///////

//no array string
void string_no_array(){
    CharLinkedList testlist;
    string tester;
    tester = testlist.toString();
    assert(tester == "[CharLinkedList of size 0 <<>>]");

}

//one index array string
void string_one_index(){
    CharLinkedList testlist('a');
    string tester;
    tester = testlist.toString();
    assert(tester == "[CharLinkedList of size 1 <<a>>]");

}

//normal array string
void string_array(){
    char test_arr[3] = { 'j', 'a', 'v'}; 
    CharLinkedList test_list(test_arr, 3);  
    string tester;
    tester = test_list.toString();
    assert(tester == "[CharLinkedList of size 3 <<jav>>]");

}


/////////////REVERSESTRINGTESTER//////

//nothing in array
void reverse_normal(){
    char test_arr[3] = { 'j', 'a', 'v'}; 
    CharLinkedList test_list(test_arr, 3);  
    string tester;
    tester = test_list.toReverseString();
    assert(tester == "[CharLinkedList of size 3 <<vaj>>]");

}

//one thing in array reverser tester
void reverse_one(){
    CharLinkedList test_list('j');  
    string tester;
    tester = test_list.toReverseString();
    assert(tester == "[CharLinkedList of size 1 <<j>>]");

}

//reverse tester on no array
void reverse_empty(){
    CharLinkedList test_list;  
    string tester;
    tester = test_list.toReverseString();
    assert(tester == "[CharLinkedList of size 0 <<>>]");

}
/*
 *  CharLinkedList.cpp
 *  Lev Barnett
 *  2/1/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Implementation for the CharLinkedList class
 *
 */

#include "CharLinkedList.h"
#include <stdexcept>

/*
 * name:      CharLinkedList default constructor
 * purpose:   initialize an empty CharLinkedList
 * arguments: none
 * returns:   none
 * effects:   numItems to 0 with front/back nullptrs
 */
CharLinkedList::CharLinkedList() {
    front = nullptr;
    back = nullptr;
    numItems = 0;
}

/*
 * name:      CharLinkedList second constructor
 * purpose:   initialize a CharLinkedList with 1 element
 * arguments: a char
 * returns:   none
 * effects:   numItems to 1 and 1 node created for char c
 */
CharLinkedList::CharLinkedList(char c) {
    front = new Node;
    front->value = c;
    front->nextNode = nullptr;
    front->prevNode = nullptr;
    back = front;
    numItems = 1;
}

/*
 * name:      CharLinkedList third constructor
 * purpose:   initialize a CharLinkedList given a starter array
 * arguments: the array to make a CharLinkedList and its int size
 * returns:   none
 * effects:   numItems to size with the full list of chars linked to each other
 */
CharLinkedList::CharLinkedList(char arr[], int size) {
    //Throw exception if size is negative
    if(size < 0) {
        throw std::range_error("size (" + std::to_string(size) + 
                                ") is less than 0");
    }

    if (size == 0) {
        front = nullptr;
        back = nullptr;
        numItems = 0;
        return;
    }
    
    Node *last = new Node;
    last->value = arr[0];
    last->prevNode = nullptr;
    front = last;
    
    //Copy the array into the CharLinkedList
        for (int i = 1; i < size; i++) {
            Node *curr = new Node;
            curr->value = arr[i];
            curr->prevNode = last;
            last->nextNode = curr;
            last = curr;
        }

    back = last;
    back->nextNode = nullptr;
    numItems = size;
}

/*
 * name:      CharLinkedList copy constructor
 * purpose:   create a CharLinkedList that is a copy of another one
 * arguments: a pointer to another CharLinkedList
 * returns:   none
 * effects:   create a deep copy of the list
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other) {
    //Copy the array into the CharLinkedList
    Node *curr = other.front;
    numItems = 0;
    while (curr != nullptr and curr->nextNode != nullptr) {
        pushAtBack(curr->value);
        curr = curr->nextNode;
    }
    pushAtBack(curr->value);
}

/*
 * name:      CharLinkedList destructor
 * purpose:   free heap memory of a CharLinkedList
 * arguments: none
 * returns:   none
 * effects:   calls a helper function to clear the nodes from the heap
 */
CharLinkedList::~CharLinkedList() {
    if (not isEmpty()) {
        clearMemory(front);
    }
}

/*
 * name:      CharLinkedList overloaded assignment operator
 * purpose:   copy one CharLinkedList's information to another
 * arguments: a pointer to the list to be copied
 * returns:   none
 * effects:   create a deep copy of the list
 */
CharLinkedList& CharLinkedList::operator=(const CharLinkedList &other) {
    //Check if the lists are the same list
    if (this == &other) {
        return *this;
    }

    //Delete the old array and create a new one
    if (not isEmpty()) {
        clearMemory(front);
    }

    //Copy the given array into the new array
    Node *curr = other.front;
    numItems = 0;
    while (curr != nullptr and curr->nextNode != nullptr) {
        pushAtBack(curr->value);
        curr = curr->nextNode;
    }
    pushAtBack(curr->value);
    return *this;
}

/*
 * name:      isEmpty()
 * purpose:   check whether the CharLinkedList is empty
 * arguments: none
 * returns:   a boolean value (whether the list is empty)
 * effects:   none
 */
bool CharLinkedList::isEmpty() const {
    return (numItems == 0);
}

/*
 * name:      clear()
 * purpose:   clears the LinkedList to make it empty
 * arguments: none
 * returns:   none
 * effects:   clear all nodes, numItems to 0, front and back = nullptrs
 */
void CharLinkedList::clear() {
    clearMemory(front);
    front = nullptr;
    back = nullptr;
    numItems = 0;
}

/*
 * name:      size()
 * purpose:   get the size of the CharLinkedList
 * arguments: none
 * returns:   an int number of items in the list
 * effects:   none
 */
int CharLinkedList::size() const {
    return numItems;
}

/*
 * name:      first()
 * purpose:   gets the first element of the CharLinkedList
 * arguments: none
 * returns:   the first char in the list
 * effects:   if the list is empty, throws an error
 */
char CharLinkedList::first() const {
    if (isEmpty())
        throw std::runtime_error("cannot get first of empty LinkedList");

    return front->value;
}

/*
 * name:      last()
 * purpose:   gets the last element of the CharLinkedList
 * arguments: none
 * returns:   the last char in the list
 * effects:   if the list is empty, throws an error
 */
char CharLinkedList::last() const {
    if (isEmpty())
        throw std::runtime_error("cannot get last of empty LinkedList");

    return back->value;
}

/*
 * name:      elementAt()
 * purpose:   gets the element at a given index of the CharLinkedList
 * arguments: none
 * returns:   the char at the given index
 * effects:   calls helper function to iterate through the nodes, if 
 *            the index is out of range, throws an error
 */
char CharLinkedList::elementAt(int index) const {
    if (index > numItems - 1 or index < 0 or isEmpty())
        throw std::range_error("index (" + std::to_string(index) + 
                        ") not in range [0.." + std::to_string(numItems) + ")");
    
    return findNode(index)->value;
}

/*
 * name:     toString() 
 * purpose:   converts the CharLinkedList to a string
 * arguments: none
 * returns:   the string form of the CharLinkedList
 * effects:   none
 */
std::string CharLinkedList::toString() const {
    std::string listString = "[CharLinkedList of size ";
    listString += std::to_string(numItems);
    listString += " <<";
    //Add each char to the string
    Node *curr = front;
    if (curr != nullptr) {  
        for (int i = 0; i < numItems; i++) {
            listString += curr->value;
            curr = curr->nextNode;
        }
    }
    listString += ">>]";

    return listString;
}

/*
 * name:      toReverseString()
 * purpose:   converts the CharLinkedList to a string in reverse
 * arguments: none
 * returns:   the string form of the CharLinkedList, in reverse
 * effects:   none
 */
std::string CharLinkedList::toReverseString() const {
    std::string listString = "[CharLinkedList of size ";
    listString += std::to_string(numItems);
    listString += " <<";
    //Add each char to the string starting from the back of the list
    Node *curr = back;
    if (curr != nullptr) {
        for (int i = numItems - 1; i >= 0; i--) {
            listString += curr->value;
            curr = curr->prevNode;
        }
    }
    listString += ">>]";

    return listString;
}

/*
 * name:      pushAtBack()
 * purpose:   inserts a char at the back of the CharLinkedList
 * arguments: a char to insert
 * returns:   none
 * effects:   inserts a new node at the back of the list, changing
 *            node pointers as necessary
 */
void CharLinkedList::pushAtBack(char c) {
    if (isEmpty()) {
        insertAt(c, 0);
    } else {
        back->nextNode = new Node;
        back->nextNode->nextNode = nullptr;
        back->nextNode->prevNode = back;
        back->nextNode->value = c;
        back = back->nextNode;
        back->prevNode->nextNode = back;
        numItems++;
    }
}

/*
 * name:      pushAtFront()
 * purpose:   inserts a char at the front of the CharLinkedList
 * arguments: a char to insert
 * returns:   none
 * effects:   calls insertAt() to insert the char at the front of the list
 */
void CharLinkedList::pushAtFront(char c) {
    insertAt(c, 0);
}

/*
 * name:      insertAt()
 * purpose:   inserts a char at a given index of the CharLinkedList
 * arguments: a char to insert and an int index to insert it at
 * returns:   none
 * effects:   creates a new node at the given index, changing node pointers.
 *            calls findNode() to find the index and pushAtBack() if the index
 *            is at the back
 */
void CharLinkedList::insertAt(char c, int index) {
    if (index > numItems or index < 0)
        throw std::range_error("index (" + std::to_string(index) + 
                        ") not in range [0.." + std::to_string(numItems) + "]");
    if (isEmpty()) {
        front = new Node;
        front->prevNode = nullptr;
        front->nextNode = nullptr;
        front->value = c;
        back = front;
        numItems++;
        return;
    }

    if (index == numItems) {
        pushAtBack(c);
        return;
    }

    Node *toAdd = new Node;
    toAdd->value = c;
    Node *addBefore = findNode(index);

    if (addBefore->prevNode != nullptr) {
        addBefore->prevNode->nextNode = toAdd;
    }
    toAdd->prevNode = addBefore->prevNode;
    addBefore->prevNode = toAdd;
    toAdd->nextNode = addBefore;
    if (front == addBefore) {
        front = toAdd;
    }
    numItems++;
}

/*
 * name:      insertInOrder()
 * purpose:   inserts a char in the CharLinkedList in ASCII order
 * arguments: a char to insert
 * returns:   none
 * effects:   inserts the char in the list using ASCII order and 
 *            the insertAt() or pushAtBack() function
 */
void CharLinkedList::insertInOrder(char c) {
    if (isEmpty()) {
        pushAtBack(c);
        return;
    }

    bool inserted = false;
    Node *curr = front;
    for (int i = 0; i < numItems; i++) {
        if (c <= curr->value) {
            insertAt(c, i);
            inserted = true;
        }
        if (inserted) {
            return;
        }
        curr = curr->nextNode;
    }
    pushAtBack(c);
}

/*
 * name:      popFromFront()
 * purpose:   removes the first char from the CharLinkedList
 * arguments: none
 * returns:   none
 * effects:   calls removeAt() to remove the first char
 */
void CharLinkedList::popFromFront() {
    if (isEmpty()) 
        throw std::runtime_error("cannot pop from empty LinkedList");
        
    removeAt(0);
}

/*
 * name:      popFromBack()
 * purpose:   removes the last char from the CharLinkedList
 * arguments: none
 * returns:   none
 * effects:   calls removeAt() to remove the last char
 */
void CharLinkedList::popFromBack() {
    if (isEmpty()) 
        throw std::runtime_error("cannot pop from empty LinkedList");
    
    removeAt(numItems - 1);
}

/*
 * name:      removeAt()
 * purpose:   removes the char at a given index from the CharLinkedList
 * arguments: an int index at which to remove the char
 * returns:   none
 * effects:   deletes the node at the given index, changing node pointers
 *            around it to link its links together
 */
void CharLinkedList::removeAt(int index) {
    if (index > numItems - 1 or index < 0 or isEmpty())
        throw std::range_error("index (" + std::to_string(index) + 
                        ") not in range [0.." + std::to_string(numItems) + ")");

    Node *toRemove = findNode(index);
    // Make sure that nextNode and prevNode are not nullptr before changing
    // their properties
    if (toRemove->nextNode != nullptr) {
        toRemove->nextNode->prevNode = toRemove->prevNode;
    }
    if (toRemove->prevNode != nullptr) {
        toRemove->prevNode->nextNode = toRemove->nextNode;
    }
    if (toRemove == front) {
        front = toRemove->nextNode;
    }
    if (toRemove == back) {
        back = toRemove->prevNode;
    }

    delete toRemove;
    numItems--;
}

/*
 * name:      replaceAt()
 * purpose:   replaces the char at a given index with another char
 * arguments: the char to replace with and the index to replace at
 * returns:   none
 * effects:   changes the char at the given index using findNode(),
 *            throwing an error if the index is out of range
 */
void CharLinkedList::replaceAt(char c, int index) {
    if (index > numItems - 1 or index < 0 or isEmpty())  
        throw std::range_error("index (" + std::to_string(index) + 
                        ") not in range [0.." + std::to_string(numItems) + ")");
    
    findNode(index)->value = c;
}

/*
 * name:      concatenate()
 * purpose:   concatenates another CharLinkedList to the end of this one
 * arguments: a pointer to the CharLinkedList to add on
 * returns:   none
 * effects:   uses pushAtBack() to add the other list's elements
 *            to the end of this one
 */
void CharLinkedList::concatenate(CharLinkedList *other) {
    if (other->isEmpty()) {
        return;
    }

    Node *curr = other->front;
    // Only push the number of items in the other list (using NumItems
    // directly will result in an infinite loop because it will always
    // increment as we push items to the back of the list)
    int pushLimit = other->numItems;
    for (int i = 0; i < pushLimit; i++) {
        pushAtBack(curr->value);
        curr = curr->nextNode;
    }
}

/*
 * name:      findNode()
 * purpose:   iterates through the nodes to find the one at a given index
 * arguments: an int index
 * returns:   a pointer to the node at the given index
 * effects:   none
 */
CharLinkedList::Node *CharLinkedList::findNode(int index) const {
    //Start from the front if the index is in the first half of the list
    if (index < numItems / 2) {
        Node *curr = front;
        for (int i = 0; i < numItems; i++) {
            if (i == index) {
                return curr;
            } else {
                curr = curr->nextNode;
            }
        }
    //otherwise, start from the back
    } else {
        Node *curr = back;
        for (int i = numItems - 1; i >= 0; i--) {
            if (i == index) {
                return curr;
            } else {
                curr = curr->prevNode;
            }
        }
    }
    return nullptr;
}

/*
 * name:      clearMemory()
 * purpose:   recursively free heap memory of a CharLinkedList
 * arguments: the node to start clearing from
 * returns:   none
 * effects:   deletes nodes from heap starting from the back of the list
 */
void CharLinkedList::clearMemory(Node *start) {
    if (start->nextNode != nullptr) {
        clearMemory(start->nextNode);
    }
    delete start;
}
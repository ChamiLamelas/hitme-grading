/*
 *  CharLinkedList.h
 *  Lev Barnett
 *  2/1/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Interface for the CharLinkedList class
 *
 */

#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H

#include<string>

class CharLinkedList {
    public:
        //Constructors
        CharLinkedList();
        CharLinkedList(char c);
        CharLinkedList(char arr[], int size);
        //Copy constructor
        CharLinkedList(const CharLinkedList &other);

        //Destructor
        ~CharLinkedList();

        //Overloaded assignment operator
        CharLinkedList &operator=(const CharLinkedList &other);

        //Getters
        bool isEmpty() const;
        void clear();
        int size() const;
        char first() const;
        char last() const;
        char elementAt(int index) const;

        //Convert to string functions
        std::string toString() const;
        std::string toReverseString() const;

        //Setters (inserting, removing, replacing)
        void pushAtBack(char c);
        void pushAtFront(char c);
        void insertAt(char c, int index);
        void insertInOrder(char c);
        void popFromFront();
        void popFromBack();
        void removeAt(int index);
        void replaceAt(char c, int index);
        void concatenate(CharLinkedList *other);

    private:
        //Node struct
        struct Node {
            char value;
            //Pointers to link the nodes together
            Node *nextNode;
            Node *prevNode;
        };

        //Pointers to the front and back of the list
        Node *front;
        Node *back;

        //Size of the list
        int numItems;

        //Helper functions
        Node *findNode(int index) const;
        void clearMemory(Node *start);
};

#endif

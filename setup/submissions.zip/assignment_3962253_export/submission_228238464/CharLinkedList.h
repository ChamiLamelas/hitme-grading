/*
 *  CharLinkedList.h
 *  Celina Kwon (ckwon04)
 *  February 2, 2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  This is a class declaration for a CharLinkedList. CharLinkedList is a class
 *  that represents an linked list of characters. A CharLinkedList starts empty
 *  with one character, or with multiple characters. Clients can then remove, 
 *  replace, and add characters.
 *
 */

#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H
#include <string>

class CharLinkedList {
public:
    //constructors and destructors
    CharLinkedList();
    CharLinkedList(char c);
    CharLinkedList(char arr[], int size);
    CharLinkedList(const CharLinkedList &other);
    ~CharLinkedList();
    CharLinkedList &operator=(const CharLinkedList &other);

    //functions that get information of the linked list
    int size() const;
    bool isEmpty() const;
    void clear();
    char first() const;
    char last() const;
    char elementAt(int index) const;

    //functions that returns a string containing chars from the linked list
    std::string toString() const;
    std::string toReverseString() const;

    //functions that add characters into the linked list
    void pushAtBack(char c);
    void pushAtFront(char c);
    void insertAt(char c, int index);
    void insertInOrder(char c);

    //functions that remove characters from the linked list
    void popFromFront();
    void popFromBack();
    void removeAt(int index);

    //function replaces a character
    void replaceAt(char c, int index);

    //function that strings together two linked lists
    void concatenate(CharLinkedList *other);
    
private:
    //variables holding information for linked list
    struct Node{
        char data;
        Node *next;
        Node *prev;
    };
    Node *back;
    Node *front;
    int numElements;

    //helper functions
    void recycleRecursive(Node *curr);
    void copyList(Node *currNode);
    Node *newNode(char newData, Node *next, Node *prev);
    Node *elementAtRecursive(int index, Node *currNode) const;
    void replaceRecursive(char newElement, int index, Node *curr);

};

#endif

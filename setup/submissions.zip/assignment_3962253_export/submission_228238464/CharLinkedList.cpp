/*
 *  CharLinkedList.cpp
 *  Celina Kwon
 *  February 2, 2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  This file contains an implementation of the CharLinkedList class
 *
 */

#include "CharLinkedList.h"
#include  <stdexcept>
#include  <iostream>

/*
 * name: CharLinkedList default constructor
 * purpose: initialize an empty CharLinkedList
 * arguments: none
 * returns: none
 * effects: front and back equal to nullptr, numElements to 0
 */
CharLinkedList::CharLinkedList(){
    front = nullptr;
    back = nullptr;
    numElements = 0;
}

/*
 * name: newNode
 * purpose: takes in a single character, the next node, and the previous node
            and creates a new node
 * arguments: a char, pointer to a next node, pointer to a previous node
 * returns: the new node created
 * effects: creates a new node and initializes data, next and prev pointers
 */
CharLinkedList::Node *CharLinkedList::newNode(char newData, Node *next,
                                            Node *prev){
    Node *newNode = new Node;
    newNode->data = newData;
    newNode->next = next;
    newNode->prev = prev;

    return newNode;
}

/*
 * name: CharLinkedList constructor
 * purpose: constructs a CharLinkedList with one node containing the given 
            character
 * arguments: a char
 * returns: none
 * effects: allocates new node to store the given char c, sets front and back 
            pointers to this new node, and sets new node next and prev pointers 
            to nullptr, numElements to 1
 */
CharLinkedList::CharLinkedList(char c){
    front = newNode(c, nullptr, nullptr);
    back = front;
    numElements = 1;
}

/*
 * name: pushAtBack
 * purpose: takes an element (char) and inserts the given new element after the
            end of the existing elements of the list.
 * arguments: char
 * returns: none
 * effects: added node at back of linked list, back set to new node, updated
            numElements
 */
void CharLinkedList::pushAtBack(char c){

    //add element to back of list
    if (front == nullptr){
        front = newNode(c, nullptr, nullptr);
        back = front;
    }
    else{
        Node *newBack = newNode(c, nullptr, back);
        back->next = newBack;
        back = newBack;
    }
    numElements++;
}

/*
 * name: pushAtFront
 * purpose: takes an element (char) and inserts the given new element in front 
            of the existing elements of the list.
 * arguments: char
 * returns: none
 * effects: added node at the front of linked list, front set to new node, 
            updated numElements
 */
void CharLinkedList::pushAtFront(char c){
    if (front == nullptr){
        front = newNode(c, nullptr, nullptr);
        back = front;
    }
    else{
        Node *currNode = newNode(c, front, nullptr);
        front->prev = currNode;
        front = currNode;
    }
    numElements++;
}

/*
 * name: CharLinkedList constructor
 * purpose: creates a linked list containing the characters from the array
 * arguments: an array of characters and int holding the length of the arary
 * returns: none
 * effects: creates linked lists with nodes containing the chars from arr, 
            front equal to first node, back equal to last node, next/prev 
            pointers connect nodes in order they appear in arr, numElements
            equal to size of arr
 */
CharLinkedList::CharLinkedList(char arr[], int size){
    front = nullptr;
    back = nullptr;

    for (int i = 0; i < size; i++){
        if (front == nullptr){
            //if the list is empty create the first node
            pushAtFront(arr[i]);
        }
        else{
            //add new nodes and update back
            pushAtBack(arr[i]);
        }
    }
    numElements = size;
}

/*
 * name: copyList
 * purpose: copies contents from another linked list to the current linked list
 * arguments: a node
 * returns: none
 * effects: adds contents from linked lists, updates prev/next and front/back
            pointers, updates numElements
 */
void CharLinkedList::copyList(Node *currNode){
    while(currNode != nullptr){
        pushAtBack(currNode->data);
        currNode = currNode->next;
    }
}


/*
 * name: CharLinkedList copy constructor
 * purpose: makes a deep copy of a given instance
 * arguments: a CharLinkedList
 * returns: none
 * effects: linked list created, front and back set to first and last node,
            numElements equal to other list's numElements
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other){
    front = nullptr;
    back = nullptr;
    numElements = 0;

    copyList(other.front);
}

/*
 * name: recycleRecursive
 * purpose: delete all nodes of a linked list using a helper recursive function
 * arguments: a Node
 * returns: none
 * effects: all nodes in a linked list deleted
 */
void CharLinkedList::recycleRecursive(Node *curr){
    if (curr == nullptr){
        return;
    }
    else{
        Node *next = curr->next;
        recycleRecursive(next);
        delete curr;
    }
}

/*
 * name: CharLinkedList destructor
 * purpose: deletes all nodes in the linked lists using recycleRecursive 
            function
 * arguments: none
 * returns: none
 * effects: linked list deleted
 */
CharLinkedList::~CharLinkedList(){
    recycleRecursive(front);
}

/*
 * name: clear
 * purpose: removes all nodes from the linked list
 * arguments: none
 * returns: none
 * effects: empties the linked list and sets front and back to nullptr and 
            numElements to 0
 */
void CharLinkedList::clear(){
    recycleRecursive(front);
    
    front = nullptr;
    back = nullptr;
    numElements = 0;
}

/*
 * name: CharLinkedList assignment operator
 * purpose: deletes the storage of the left side instance and copies the 
            instance of the right hand side into the instance on the left
 * arguments: instance to be copied
 * returns: reference to the new linkedList
 * effects: left side instance holds copy of right side instance, numElements
            equal to other list's numElements
 */
CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other){
    //delete left side list
    clear();

    //copy nodes from second linked list into first linked list
    copyList(other.front);
    
    return *this;
}

/*
 * name: size
 * purpose: returns size of linked list
 * arguments: none
 * returns: the int representing size
 * effects: none
 */
int CharLinkedList::size() const{
    return numElements;
}

/*
 * name: isEmpty
 * purpose: checks if front is a nullptr, if it is then the linked list is empty
 * arguments: none
 * returns: true if the linked list is empty, false otherwise
 * effects: none
 */
bool CharLinkedList::isEmpty() const{
    if (front == nullptr){
        return true;
    }
    return false;
}


/*
 * name: first
 * purpose: returns the char in the front node of the linked list, otherwise 
            throws an exception
 * arguments: none
 * returns: the first char or exception message 
 * effects: none
 */
char CharLinkedList::first() const{
    if(front == nullptr){
        throw std::runtime_error("cannot get first of empty LinkedList");
    }
    return front->data;
}

/*
 * name: last
 * purpose: returns the char in the back node of the linked list, otherwise
            throws an exception
 * arguments: none
 * returns: the last char or exception message
 * effects: none
 */
char CharLinkedList::last() const{
    if(front == nullptr){
        throw std::runtime_error("cannot get last of empty LinkedList");
    }
    return back->data;
}

/*
 * name: elementAt
 * purpose: uses a revursive helper function to return the char at the given 
            index, otherwise throws an exception
 * arguments: integer index
 * returns: the char in the linked list at that index or exception message
 * effects: none
 */
char CharLinkedList::elementAt(int index) const{
    if((index < 0) or (index >= numElements) or (numElements == 0)){
        throw std::range_error("index (" + std::to_string(index) + ") not in"
                                + " range [0.." + std::to_string(numElements) 
                                + ")");
    }
    Node *currNode = elementAtRecursive(index, front);
    return currNode->data;
}

/*
 * name: elementAtRecursive
 * purpose: recursively traverses through linked list to find element at 
            specified index
 * arguments: index of element to retrieve, current node in recursive traversal
 * returns: a char
 * effects: traverses list by recursively calling on next nodes, returns
            current ndoe data when index is reached
 */
CharLinkedList::Node *CharLinkedList::elementAtRecursive
                                      (int index, Node *currNode) const{
    if (index == 0){
        return currNode;
    }
    return elementAtRecursive(index - 1, currNode->next);
}

/*
 * name: toString
 * purpose: creates a string that contains the chars of the CharLinkedList
 * arguments: none
 * returns: a string containing the chars of the CharLinkedList
 * effects: none
 */
std::string CharLinkedList::toString() const{
    Node *currNode = front;
    std::string currString = "";

    while(currNode != nullptr){
        currString += currNode->data;
        currNode = currNode->next;
    }

    return "[CharLinkedList of size " + std::to_string(numElements) + " <<"
            + currString + ">>]";
}

/*
 * name: toReverseString
 * purpose: creates a string that contains the chars of the CharLinkedList
            in reverse
 * arguments: none
 * returns: a string that contains the chars of the CharLinkedList in reverse
 * effects: none
 */
std::string CharLinkedList::toReverseString() const{
    Node *currNode = back;
    std::string currString = "";

    while(currNode != nullptr){
        currString += currNode->data;
        currNode = currNode->prev;
    }

    return "[CharLinkedList of size " + std::to_string(numElements) + " <<"
            + currString + ">>]";
}



/*
 * name: insertAt
 * purpose: takes an element (char) and inserts the new element at the 
            specified index
 * arguments: char
 * returns: none
 * effects: inserts the node at specified index, changes next and prev of 
            necessary nodes, updates front/back if necessary, updated 
            numElements
 */
void CharLinkedList::insertAt(char c, int index){
    if ((index < 0) or (index > numElements)){
        throw std::range_error("index (" + std::to_string(index) + ") not in"
                                + " range [0.." + std::to_string(numElements) 
                                + "]");
    }
    //depending on length of LL and index, add node and update front/back
    if (index == 0){
        pushAtFront(c);
    }else if (not(index > numElements - 1)){
        Node *currNode = elementAtRecursive(index - 1, front);
        Node *insertedNode = newNode(c, currNode->next, currNode);
        currNode->next = insertedNode;
        currNode->next->prev = insertedNode;
        numElements++;
    }else if (index >= numElements - 1){
        pushAtBack(c);
    }
    
}

/*
 * name: insertInOrder
 * purpose: takes an element (char), inserts it into the list in ASCII order
 * arguments: char
 * returns: none
 * effects: inserts node at specified index, changes next/prev of necessary
            nodes, and updates front/back if necessary, updated numElements
 */
void CharLinkedList::insertInOrder(char c){
    //depending on length of LL, add node and update front/back
    int index = 0;
    if((front == nullptr) or (c < front->data)){
        index = 0;
    }
    else{
        Node *currNode = front;
        while((currNode->next != nullptr) and (currNode->next->data < c)){
            currNode = currNode->next;
            index++;
        }
        index++;
    }
    insertAt(c, index);
}

/*
 * name: popFromFront
 * purpose: it removes the first node from linked list
 * arguments: none
 * returns: none
 * effects: removes node at front and updates front, updated numElements
 */
void CharLinkedList::popFromFront(){
    if(numElements == 0){
        throw std::runtime_error("cannot pop from empty LinkedList");
    }

    //depending on size of LL, remove first node and update front
    if(numElements == 1){
        delete front;
        front = nullptr;
        back = nullptr;
    }
    else{
        Node *oldFront = front;
        front = front->next;
        delete oldFront;
        front->prev = nullptr;
    } 
    numElements--;
}

/*
 * name: popFromBack
 * purpose: it removes the last node from the linked list
 * arguments: none
 * returns: none
 * effects: removes node at back and updates back, updated numElements
 */
void CharLinkedList::popFromBack(){
    if(numElements == 0){
        throw std::runtime_error("cannot pop from empty LinkedList");
    }
    
    //depending on size of LL, remove last node and update back
    if(numElements == 1){
        delete front;
        front = nullptr;
        back = nullptr;
    }
    else{
        Node *oldBack = back;
        back = back->prev;
        delete oldBack;
        back->next = nullptr;
    } 
    numElements--;
}

/*
 * name: removeAt
 * purpose: it removes the node at the specified index
 * arguments: integer index
 * returns: none
 * effects: updates next/prev for necessary nodes and updates front/back if
            necessary, updated numElements
 */
void CharLinkedList::removeAt(int index){
    if ((index < 0) or (index >= numElements)){
        throw std::range_error("index (" + std::to_string(index) + ") not in"
                                + " range [0.." + std::to_string(numElements)
                                + ")");
    }
    //depending on index, remove node and update front/back if necessary
    if (index == 0){
        popFromFront();
    }else if (index == numElements - 1){
        popFromBack();
    }else{
        Node *currNode = elementAtRecursive(index, front);
        currNode->prev->next = currNode->next;
        currNode->next->prev = currNode->prev;
        delete currNode;
        numElements--; 
    }
}

/*
 * name: replaceAt
 * purpose: it replaces the node at the specified index with new node using
            a reursive helper function
 * arguments: char and an integer index
 * returns: none
 * effects: new node, next/prev updated if necessary, front/back updated if 
            necessary
 */
void CharLinkedList::replaceAt(char c, int index){
    if ((index < 0) or (index >= numElements)){
        throw std::range_error("index (" + std::to_string(index) + ") not in"
                                + " range [0.." + std::to_string(numElements) 
                                + ")");
    }
    if(index == 0){
        front->data = c;
    }else if(index == numElements - 1){
        back->data = c;
    }else{
        replaceRecursive(c, index, front);
    }
}

/*
 * name: replaceRecursive
 * purpose: recursively traverses linked list and replaces node at target index
 * arguments: char to replace existing element, index of node to replace, 
              current node in recursive traversal
 * returns: none
 * effects: creates new node when reaching index 0, links next and prev 
            pointers to insert new node, deletes the node being replaced
 */
void CharLinkedList::replaceRecursive(char newElement, int index, Node *curr){
    if(index == 0){
        Node *insertedNode = newNode(newElement, curr->next, curr->prev);
        curr->next->prev = insertedNode;
        curr->prev->next = insertedNode;
        delete curr;
    }
    else{
        replaceRecursive(newElement, index - 1, curr->next);
    }
}

/*
 * name: concatenate
 * purpose: it adds a copy of the list pointed to by the parameter value to the 
            end of the list the function was called from
 * arguments: pointer to a second CharLinkedList
 * returns: none
 * effects: added nodes to the end of linked list, updates back and necessary
            next/prev pointers, updated numElements
 */
void CharLinkedList::concatenate(CharLinkedList *other){
    CharLinkedList concatenatedList;

    // copy elements of the current list to the merged list
    concatenatedList.copyList(front);

    // copy the elements of the other list to the merged list
    concatenatedList.copyList(other->front);

    //update current list to merged list
    *this = concatenatedList;

}

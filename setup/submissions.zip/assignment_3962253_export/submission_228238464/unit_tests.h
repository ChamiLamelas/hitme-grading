/*
 *  unit_tests.h
 *  Celina Kwon
 *  February 2, 2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  Uses Matt Russell's unit_test framework to test the CharLinkedList class.
 *
 */

#include "CharLinkedList.h"
#include <cassert>

// Tests the default constructor.
// Afterwards, an empty linked list should be created.
void default_constructor_test(){
    CharLinkedList list;
}

//Tests the constructor that takes creates a one element linked list
//Afterwards, the size should be one
void single_element_constructor_test(){
    CharLinkedList list('a');
    assert(list.size() == 1);
}

//Tests the constructor that takes in an array and its size.
//Afterwards, the size should be equal to the array size.
void array_constructor_test(){
    char arr[] = {'a', 'b', 'c', 'd'};
    CharLinkedList list(arr, 4);
    assert(list.size() == 4);
}

//Tests a constructor that takes in an array of size one.
//Afterwards, the size should be equal to one.
void single_array_constructor_test(){
    char arr[] = {'a'};
    CharLinkedList list(arr, 1);
    assert(list.size() == 1);
}

//Tests a constructor that takes in an array and size of 0
//Afterwards, the size should be 0
void array_constructor_zero_test(){
    char arr[] = {'a', 'b', 'c', 'd'};
    CharLinkedList list(arr, 0);
    assert(list.size() == 0);
}

//Tests the copy constructor.  
//Afterwards, the size should be equal to the array size.
void copy_constructor_test(){
    char arr[] = {'a', 'b', 'c', 'd'};
    CharLinkedList other_list(arr, 4);
    CharLinkedList list(other_list);
    assert(list.size() == 4);
}   

//Tests the assignment opperator that copies a LL with one char to an empty LL
//Afterwards, the size of both LLs should be equal.
void assign_opperator_second_empty_test(){
    CharLinkedList list1('a');
    int list1_size = list1.size();
    CharLinkedList list2;
    list2 = list1;
    assert(list1_size == list2.size());
}

//Tests the assignment opperator that copies an empty LL to another empty LL
//Afterwards, the size of both LLs should be equal.
void assign_opperator_both_empty_test(){
    CharLinkedList list1;
    int list1_size = list1.size();
    CharLinkedList list2;
    list2 = list1;
    assert(list1_size == list2.size());
}

//Tests the assignment opperator that copies an LL with chars to another LL
//with chars
//Afterwards, the size of both LLs should be equal to 4.
void assign_opperator_both_full_test(){
    char arr1[] = {'a', 'b', 'c', 'd'};
    CharLinkedList list1(arr1, 4); 
    int list1_size = list1.size();
    char arr2[] = {'h', 'e', 'l', 'l', 'o'};
    CharLinkedList list2(arr2, 5); 
    list2 = list1;
    assert(list1_size = list2.size());
    assert(list2.size() == 4);
}

//Tests the size function with an empty LL.
//Afterwards, the size should equal 0.
void size_empty_test(){
    CharLinkedList list;
    assert(list.size() == 0);
}

//Tests the size function with a LL containing one char.
//Afterwards, the size should equal 1.
void size_one_test(){
    CharLinkedList list('a');
    assert(list.size() == 1);
}

//Tests the size function with a LL containing one char which is an int.
//Afterwards, the size should equal 1.
void size_num_test(){
    CharLinkedList list('1');
    assert(list.size() == 1);
}

//Tests the size function with a LL containing many chars.
//Afterwards, the size should equal 10.
void size_many_test(){
    char arr1[] = {'1', 'b', '3', 'd', 'h', '#', 't', 'e', 's'};
    CharLinkedList list(arr1, 10); 
    assert(list.size() == 10);
}

//Tests the size function with a LL containing null chars.
//Afterwards, the size should equal 3.
void size_null_test(){
    char arr[] = {'\0', '\0', '\0'};
    CharLinkedList list(arr, 3);
    assert(list.size() == 3);
}

//Tests the isEmpty function with an empty LL.
//Afterwards, the isEmpty should return true.
void isEmpty_true_test(){
    CharLinkedList list;
    assert(list.isEmpty());
}

//Tests the isEmpty function with an LL containing a char.
//Afterwards, the isEmpty should return false.
void isEmpty_false_test(){
    CharLinkedList list('a');
    assert(not(list.isEmpty()));
}

//Tests the clear function with an LL containing one char.
//The function should remove all elements from the LL.
//Afterwards, isEmpty should return true.
void clear_singlet_test(){
    CharLinkedList list('a');
    list.clear();
    assert(list.isEmpty());
}

//Tests the clear function with an empty LL.
//Afterwards, isEmpty should return true.
void clear_empty_test(){
    CharLinkedList list;
    list.clear();
    assert(list.isEmpty());
}

//Tests the clear function with a LL full of chars.
//Afterwards, isEmpty should return true.
void clear_many_test(){
    char arr[] = {'1', 'b', '3', 'd', 'h', '#', 't', 'e', 's'};
    CharLinkedList list1(arr, 10); 
    list1.clear();
    assert(list1.isEmpty());
}

//Tests the first function with a LL containing chars.
//Afterwards, first() should return the first char, 'a'.
void first_many_test_correct(){
    char arr[] = {'a', 'b', 'c', 'd'};
    CharLinkedList list(arr, 4);
    assert(list.first() == 'a');
}

//Tests the first function with a LL containing chars with the first one null.
//Afterwards, first() should return the first char, '\0'.
void first_null_test_correct(){
    char arr[] = {'\0', 'b', 'c', 'd'};
    CharLinkedList list(arr, 4);
    assert(list.first() == '\0');
}

//Tests incorrect call to the first function.
//Attempts to call first for empty LL.
//This should result in an std::runtime_error being raised.
void first_test_incorrect(){
    CharLinkedList list;

    //var to track whether runtime_error is thrown
    bool runtime_error_thrown = false;

    //var to track any error messages raised
    std::string error_message = "";

    try {
        //first for empty AL
        list.first();
    }
    catch(const std::runtime_error &e){
        //if first is correctly implemented, a runtime_error will be thrown, 
        //and we will end up here
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot get first of empty LinkedList");
}


//Tests the last function with a LL containing chars.
//Afterwards, last should return the last char 'd'.
void last_test_correct(){
    char arr[] = {'a', 'b', 'c', 'd'};
    CharLinkedList list(arr, 4);
    assert(list.last() == 'd');
}

//Tests incorrect call to the last function.
//Attempts to call last for empty LL.
//This should result in an std::runtime_error being raised.
void last_test_incorrect(){
    CharLinkedList list;

    //var to track whether runtime_error is thrown
    bool runtime_error_thrown = false;

    //var to track any error messages raised
    std::string error_message = "";

    try{
        //last for empty LL
        list.last();
    }
    catch(const std::runtime_error &e){
        //if last is correctly implemented, a runtime_error will be thrown, 
        //and we will end up here
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot get last of empty LinkedList");
}



//Tests the elementAt function with a LL containing chars and middle index.
//Afterwards, elementAt should return the char at 2 which is 'c'.
void elementAt_correct_mid(){
    char arr[] = {'a', 'b', 'c', 'd'};
    CharLinkedList list(arr, 4);
    assert(list.elementAt(2) == 'c');
}

//Tests the elementAt function with a LL containing chars and first index.
//Afterwards, elementAt should return the char at 0 which is 'a'.
void elementAt_correct_first(){
    char arr[] = {'a', 'b', 'c', 'd'};
    CharLinkedList list(arr, 4);
    assert(list.elementAt(0) == 'a');
}

//Tests the elementAt function with a LL containing chars and last index.
//Afterwards, elementAt should return the char at 3 which is 'd'.
void elementAt_correct_last(){
char arr[] = {'a', 'b', 'c', 'd'};
    CharLinkedList list(arr, 4);
    assert(list.elementAt(3) == 'd');
}

//Tests incorrect call to the elementAt function when the LL is empty.
//This should result in an std::range_error being raised.
void elementAt_empty_incorrect(){
    CharLinkedList list;

    bool range_error_thrown = false;
    std::string error_message = "";

    try{
        //elementAt for empty LL
        list.elementAt(0);
    }
    catch(const std::range_error &e){
        //if elementAt is correctly implemented, a range_error will be thrown, 
        //and we will end up here
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (0) not in range [0..0)");
}

//Tests incorrect call to the elementAt function when the index equals currSize
//This should result in an std::range_error being raised.
void elementAt_index_size_incorrect(){
    char arr[] = {'a', 'b', 'c', 'd'};
    CharLinkedList list(arr, 4);

    bool range_error_thrown = false;
    std::string error_message = "";

    try{
        //elementAt for empty LL
        list.elementAt(4);
    }
    catch(const std::range_error &e){
        //if elementAt is correctly implemented, a range_error will be thrown, 
        //and we will end up here
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (4) not in range [0..4)");
}

//Tests incorrect elementAt index when the index is too low
void elementAt_incorrect_low(){
    char arr[] = {'a', 'b', 'c', 'd'};
    CharLinkedList list(arr, 4);

    bool range_error_thrown = false;
    std::string error_message = "";

    try{
        //elementAt with an index too low for the LL
        list.elementAt(-1);
    }
    catch(const std::range_error &e){
        //if elementAt is correctly implemented, a range_error will be thrown, 
        //and we will end up here
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (-1) not in range [0..4)");
}

//Tests incorrect elementAt index when the index is too high
void elementAt_incorrect_high(){
    char arr[] = {'a', 'b', 'c', 'd'};
    CharLinkedList list(arr, 4);

    bool range_error_thrown = false;
    std::string error_message = "";

    try{
        //elementAt with an index too high for the LL
        list.elementAt(10);
    }
    catch(const std::range_error &e){
        //if elementAt is correctly implemented, a range_error will be thrown, 
        //and we will end up here
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (10) not in range [0..4)");
}

//Tests the toString function with an LL containing lowercase letters.
//Afterwards, toString should return the correct statement with size 5 and 
//"hello".
void toString_lower(){
    char arr[] = {'h', 'e', 'l', 'l', 'o'};
    CharLinkedList list(arr, 5);
    assert(list.toString() == "[CharLinkedList of size 5 <<hello>>]");
}

//Tests toString with an LL containing capital letters.
//Afterwards, toString should return the correct statement with size 5 and 
//"HELLO".
void toString_upper(){
    char arr[] = {'H', 'E', 'l', 'l', 'O'};
    CharLinkedList list(arr, 5);
    assert(list.toString() == "[CharLinkedList of size 5 <<HEllO>>]");
}

//Tests toString with an LL containing one char.
//Afterwards, toString should return the correct statement with size 1 and 
//"a".
void toString_singlet(){
    CharLinkedList list('a');
    assert(list.toString() == "[CharLinkedList of size 1 <<a>>]");
}

//Tests the toString with an empty LL. Afterwards, toString should return the
//correct statement with size 0.
void toString_empty(){
    CharLinkedList list;
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}

//Tests the toReverseString function with an LL containing lowercase letters.
//Afterwards, toReverseString should return the correct statement with 
//size 5 and "olleh".
void toReverseString_lower(){
    char arr[] = {'h', 'e', 'l', 'l', 'o'};
    CharLinkedList list(arr, 5);
    assert(list.toReverseString() == "[CharLinkedList of size 5 <<olleh>>]");
}

//Tests toReverseString with an LL containing capital letters. Afterwards, 
//toReverseString should return the correct statement with size 5 and "OllEH".
void toReverseString_upper(){
    char arr[] = {'H', 'E', 'l', 'l', 'O'};
    CharLinkedList list(arr, 5);
    assert(list.toReverseString() == "[CharLinkedList of size 5 <<OllEH>>]");
}

//Tests toReverseString with an LL containing one char.
//Afterwards, toReverseString should return the correct statement with size 1 
//and "a".
void toReverseString_singlet(){
    CharLinkedList list('a');
    assert(list.toString() == "[CharLinkedList of size 1 <<a>>]");
}

//Tests toReverseString with an empty LL. Afterwards, toReverseString should
//return size 0.
void toReverseString_empty(){
    CharLinkedList list;
    assert(list.toReverseString() == "[CharLinkedList of size 0 <<>>]");
}

// Tests the pushAtBack function with an LL containing chars. Afterwards, 
// pushAtBack should add the specified char to the back of the LL.
void pushAtBack_array(){
    char arr[] = {'H', 'E', 'l', 'l', 'O'};
    CharLinkedList list(arr, 5);
    list.pushAtBack('s');
    assert(list.size() == 6);
    assert(list.toString() == "[CharLinkedList of size 6 <<HEllOs>>]");
}

//Tests pushAtBack with an empty LL. Afterwards, pushAtBack should add
//the specified char to the LL.
void pushAtBack_empty(){
    CharLinkedList list;
    list.pushAtBack('a');
    assert(list.size() == 1);
    assert(list.elementAt(0)== 'a');
}

// Tests the pushAtFront function with an LL containing chars. Afterwards, 
// pushAtFront should add the specified char to the front of the LL.
void pushAtFront_array(){
    char arr[] = {'H', 'E', 'l', 'l', 'O'};
    CharLinkedList list(arr, 5);
    list.pushAtFront('s');
    assert(list.size() == 6);
    assert(list.toString() == "[CharLinkedList of size 6 <<sHEllO>>]");
}

// Tests calling insertAt for a large number of elements.
// Not only does this test insertAt, it also checks that
// array expansion works correctly.
void pushAtFront_many_elements() {
    
    CharLinkedList test_list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.pushAtFront('a');
    }

    assert(test_list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }

}

//Tests pushAtFront with an empty LL. Afterwards, pushAtFront should add the
//specified char to the front of the LL.
void pushAtFront_empty(){
    CharLinkedList list;
    list.pushAtFront('a');
    assert(list.size() == 1);
    assert(list.elementAt(0) == 'a');
}

//Tests correct insertion into an empty LL.
//Afterwards, size should be 1 and element at index 0 should be the element 
//we inserted.
void insertAt_empty_correct() { 
    CharLinkedList test_list;
    test_list.insertAt('a', 0);
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');
}

//Tests incorrect insertion into an empty LL.
//Attempts to call insertAt for index larger than 0.
//This should result in an std::range_error being raised.
void insertAt_empty_incorrect() {

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    // insertAt for out-of-range index
    test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
    // if insertAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    range_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0]");
    
}

//Tests correct insertAt for front of 1-element list.
void insertAt_front_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at front
    test_list.insertAt('b', 0);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'a');
    
}

void insertAt_second_back_list(){
    char arr[] = {'H', 'E', 'l', 'l', 'O'};
    CharLinkedList list(arr, 5);

    list.insertAt('s', 4);
    assert(list.elementAt(4) == 's');
}

//Tests correct insertAt for back of 1-element list.
void insertAt_back_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at back
    test_list.insertAt('b', 1);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    
}

// Tests calling insertAt for a large number of elements.
// Not only does this test insertAt, it also checks that
// array expansion works correctly.
void insertAt_many_elements() {
    
    CharLinkedList test_list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.insertAt('a', i);
    }

    assert(test_list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }

}

// Tests insertion into front of a larger list
void insertAt_front_large_list() {
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    test_list.insertAt('y', 0);

    assert(test_list.size() == 10);
    assert(test_list.elementAt(0) == 'y');
    assert(test_list.toString() == 
    "[CharLinkedList of size 10 <<yabczdefgh>>]");
}

// Tests insertion into the back of a larger list
void insertAt_back_large_list() {

    char test_arr[10] = { 'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 10);  

    test_list.insertAt('x', 10);

    assert(test_list.size() == 11);
    assert(test_list.elementAt(10) == 'x');
    assert(test_list.toString() ==
    "[CharLinkedList of size 11 <<yabczdefghx>>]"); 

}

// Tests insertion into the middle of a larger list
void insertAt_middle_large_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.insertAt('z', 3);
    assert(test_list.size() == 9);
    assert(test_list.elementAt(3) == 'z');
    assert(test_list.toString() == "[CharLinkedList of size 9 <<abczdefgh>>]");
}

// Tests out-of-range insertion for a non-empty list.
void insertAt_nonempty_incorrect() {
   
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8]");
    
}

//Afterwards, size should be 5 and element at index 2 should be 'c'.
void insertInOrder_lower() { 
    char arr[] = {'a', 'b', 'd', 'e'};
    CharLinkedList list(arr, 4);    
    list.insertInOrder('c');
    assert(list.size() == 5);
    assert(list.elementAt(2) == 'c');
    assert(list.toString() == "[CharLinkedList of size 5 <<abcde>>]");
}

//Tests correct insertion in order into an LL with uppercase letters.
//Afterwards, size should be 5 and element at index 0 should be 'A'.
void insertInOrder_upper() { 
    char arr[] = {'Z', 'E', 'D'};
    CharLinkedList list(arr, 3);    
    list.insertInOrder('A');
    assert(list.size() == 4);
    assert(list.elementAt(0) == 'A');
    assert(list.toString() == "[CharLinkedList of size 4 <<AZED>>]");
}

//Tests correct insertion in order into an LL with lower and uppercase letters.
//Afterwards, size should be 5 and element at index 0 should be 'Z'.
void insertInOrder_lowupp() { 
    char arr[] = {'a', 'b', 'E', 's'};
    CharLinkedList list(arr, 4);    
    list.insertInOrder('d');
    assert(list.size() == 5);
    assert(list.toString() == "[CharLinkedList of size 5 <<abEds>>]");
}

//Tests correct insertion in order into an LL with numbers.
//Afterwards, size should be 5 and element at index 4 should be '9'.
void insertInOrder_numbers(){
    char arr[] = {'1', '6', '4', '9'};
    CharLinkedList list(arr, 4);
    list.insertInOrder('2');
    assert(list.size() == 5);
    assert(list.elementAt(4) == '9');
    assert(list.toString() == "[CharLinkedList of size 5 <<12649>>]");
}

//Tests correct insertion in order into an empty LL.
//Afterwards, size should be 5 and element at index 0 should be 'a'.
void insertInOrder_empty(){
    CharLinkedList list;
    list.insertInOrder('a');
    assert(list.elementAt(0) == 'a');
}

//Tests correct insertion in order into an LL with one char.
//Afterwards, size should be 2 and element at index 1 should be 'b'.
void insertInOrder_single_back() {
    
    // initialize 1-element list
    CharLinkedList list('a');

    list.insertInOrder('b');
    assert(list.size() == 2);
    assert(list.elementAt(0) == 'a');
    assert(list.elementAt(1) == 'b');
}

//Tests correct insertion in order into an LL with one char.
//Afterwards, size should be 2 and element at index 2 should be 'd'.
void insertInOrder_single_front() {
    
    // initialize 1-element list
    CharLinkedList list('d');

    // insert at back
    list.insertInOrder('b');

    assert(list.size() == 2);
    assert(list.elementAt(0) == 'b');
    assert(list.elementAt(1) == 'd');
}

void insertInOrder_duplicate(){
    char arr[] = {'a', 'a', 'E', 's'};
    CharLinkedList list(arr, 4);
    list.insertInOrder('a');
    list.insertInOrder('E');

    assert(list.size() == 6);
    assert(list.toString() == "[CharLinkedList of size 6 <<EaaaEs>>]");
}


//Tests correct popFromFront with an LL with chars.
//Afterwards, size should be 3 and element at index 0 should be 'b'.
void popFromFront_array_correct(){
    char arr[] = {'a', 'b', 'E', 's'};
    CharLinkedList list(arr, 4); 
    list.popFromFront();
    assert(list.size() == 3);
    assert(list.toString() == "[CharLinkedList of size 3 <<bEs>>]");
}

//Tests correct popFromFront with an LL with one char.
//Afterwards, size should be 0 and element at index 0 should not exist.
void popFromFront_array_single(){
    CharLinkedList list('a');
    list.popFromFront();
    assert(list.size() == 0);
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}

//Tests incorrect call to the popFromFront function.
//Attempts to call popFromFront on an empty LL.
//This should result in an std::runtime_error being raised.
void popFromFront_empty(){
    CharLinkedList list;

    //var to track whether runtime_error is thrown
    bool runtime_error_thrown = false;

    //var to track any error messages raised
    std::string error_message = "";

    try{
        //popFromFront for empty LL
        list.popFromFront();
    }
    catch(const std::runtime_error &e){
        //if popFromFront is correctly implemented, a runtime_error will be 
        //thrown, and we will end up here
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

//Tests correct popFromBack with and LL with chars.
//Afterwards, size should be 3 and element at index 2 should be 'E'.
void popFromBack_correct(){
    char arr[] = {'a', 'b', 'E', 's'};
    CharLinkedList list(arr, 4); 
    list.popFromBack();
    assert(list.size() == 3);
    assert(list.toString() == "[CharLinkedList of size 3 <<abE>>]");
}

//Tests correct popFromBack with an LL with one char.
//Afterwards, size should be 0 and element at index 0 should not exist.
void popFromBack_array_single(){
    CharLinkedList list('a');
    list.popFromBack();
    assert(list.size() == 0);
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}

//Tests incorrect call to the popFromBack function.
//Attempts to call popFromBack on an empty AL.
//This should result in an std::runtime_error being raised.
void popFromBack_empty(){
    CharLinkedList list;

    //var to track whether runtime_error is thrown
    bool runtime_error_thrown = false;

    //var to track any error messages raised
    std::string error_message = "";
    try{
        //popFromBack for empty AL
        list.popFromBack();
    }
    catch(const std::runtime_error &e){
        //if popFromBack is correctly implemented, a runtime_error will be 
        //thrown, and we will end up here
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

//Tests correct removeAt with an LL with chars.
//Afterwards, size should be 3 and element at given index should be removed.
void removeAt_correct() {
    char arr[] = {'a', 'b', 'c', 'd'};
    CharLinkedList list(arr, 4); 

    list.removeAt(2);
    assert(list.size() == 3);
    assert(list.toString() == "[CharLinkedList of size 3 <<abd>>]");
}

//Tests correct removeAt with an LL with chars.
//Afterwards, size should be 3 and first element should be removed.
void removeAt_front_correct() {
    char arr[] = {'a', 'b', 'c', 'd'};
    CharLinkedList list(arr, 4); 

    list.removeAt(0);
    assert(list.size() == 3);
    assert(list.toString() == "[CharLinkedList of size 3 <<bcd>>]");
}

//Tests correct removeAt with an LL with chars.
//Afterwards, size should be 3 and last element should be removed.
void removeAt_back_correct() {
    char arr[] = {'a', 'b', 'c', 'd'};
    CharLinkedList list(arr, 4); 

    list.removeAt(3);
    assert(list.size() == 3);
    assert(list.toString() == "[CharLinkedList of size 3 <<abc>>]");
}

//Tests incorrect call to the removeAt function.
//Attempts to call removeAt on an empty LL.
//This should result in an std::range_error being raised.
void removeAt_empty_incorrect(){
    //var to track whether range_error is thrown
    bool range_error_thrown = false;

    //var to track any error messages raised
    std::string error_message = "";

    CharLinkedList list;
    try{
        //removeAt for empty LL
        list.removeAt(0);
    }
    catch (const std::range_error &e) {
        //if removeAt is correctly implemented, a range_error will be 
        //thrown, and we will end up here
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (0) not in range [0..0)");
}

//Tests correct removeAt with an LL with one char.
//Afterwards, size should be 0 and element should be removed.
void removeAt_singleton_list() {
    CharLinkedList list('a');
    list.removeAt(0);
    assert(list.size() == 0);
}

//Tests incorrect call to the removeAt function.
//Attempts to call removeAt for an index that is too high.
void removeAt_high_incorrect(){
    //var to track whether range_error is thrown
    bool range_error_thrown = false;

    //var to track any error messages raised
    std::string error_message = "";

    char arr[] = {'a', 'b', 'c', 'd'};
    CharLinkedList list(arr, 4); 

    try{
        //removeAt for LL of size 4
        list.removeAt(6);
    }
    catch (const std::range_error &e) {
        //if removeAt is correctly implemented, a range_error will be 
        //thrown, and we will end up here
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (6) not in range [0..4)");

}


//Tests incorrect call to the removeAt function.
//Attempts to call removeAt for an index that is too low.
void removeAt_low_incorrect(){
    //var to track whether range_error is thrown
    bool range_error_thrown = false;

    //var to track any error messages raised
    std::string error_message = "";

    char arr[] = {'a', 'b', 'c', 'd'};
    CharLinkedList list(arr, 4); 

    try{
        //removeAt for LL of size 4
        list.removeAt(-1);
    }
    catch (const std::range_error &e) {
        //if removeAt is correctly implemented, a range_error will be 
        //thrown, and we will end up here
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (-1) not in range [0..4)");

}

//Tests incorrect call to the removeAt function.
//Attempts to call removeAt for an index equal to currSize.
void removeAt_index_incorrect(){
    //var to track whether range_error is thrown
    bool range_error_thrown = false;

    //var to track any error messages raised
    std::string error_message = "";

    char arr[] = {'a', 'b', 'c', 'd'};
    CharLinkedList list(arr, 4); 

    try{
        //removeAt for LL of size 4
        list.removeAt(4);
    }
    catch (const std::range_error &e) {
        //if removeAt is correctly implemented, a range_error will be 
        //thrown, and we will end up here
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (4) not in range [0..4)");
}

//Tests correct replaceAt with an LL with chars.
//Afterwards, size should be 4 and element at index 2 should be 'k'.
void replaceAt_correct() {
    char arr[] = {'a', 'b', 'c', 'd'};
    CharLinkedList list(arr, 4); 

    list.replaceAt('k', 2);
    assert(list.size() == 4);
    assert(list.toString() == "[CharLinkedList of size 4 <<abkd>>]");
}

//Tests correct replaceAt with an LL with chars.
//Afterwards, size should be 4 and element at index 0 should be 'z'.
void replaceAt_front_correct() {
    char arr[] = {'a', 'b', 'c', 'd'};
    CharLinkedList list(arr, 4); 

    list.replaceAt('z', 0);
    assert(list.size() == 4);
    assert(list.toString() == "[CharLinkedList of size 4 <<zbcd>>]");
}

//Tests correct replaceAt with an LL with chars.
//Afterwards, size should be 4 and element at index 3 should be 'z'.
void replaceAt_back_correct() {
    char arr[] = {'a', 'b', 'c', 'd'};
    CharLinkedList list(arr, 4); 

    list.replaceAt('z', 3);
    assert(list.size() == 4);
    assert(list.toString() == "[CharLinkedList of size 4 <<abcz>>]");
}

//Tests incorrect call to the replaceAt function.
//Attempts to call replaceAt for an empty LL.
void replaceAt_empty_incorrect(){
    //var to track whether range_error is thrown    
    bool range_error_thrown = false;

    //var to track any error messages raised
    std::string error_message = "";

    CharLinkedList list;
    try{
        //removeAt for empty LL
        list.replaceAt('h', 0);
    }
    catch (const std::range_error &e) {
        //if replaceAt is correctly implemented, a range_error will be 
        //thrown, and we will end up here
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (0) not in range [0..0)");
    
}

//Tests correct replaceAt with an LL with one char.
//Afterwards, size should be 1 and element at index 0 should be 'z'.
void replaceAt_singleton_list() {
    CharLinkedList list('a');

    list.replaceAt('z', 0);
    assert(list.size() == 1);
    assert(list.elementAt(0) == 'z');
}

//Tests incorrect call to the replaceAt function.
//Attempts to call replaceAt for an index that is too high.
void replaceAt_high_incorrect(){
    //var to track whether range_error is thrown    
    bool range_error_thrown = false;
    
    //var to track any error messages raised
    std::string error_message = "";

    char arr[] = {'a', 'b', 'c', 'd'};
    CharLinkedList list(arr, 4); 

    try{
        //replaceAt for AL of size 4
        list.replaceAt('a', 6);
    }
    catch (const std::range_error &e) {
        //if replaceAt is correctly implemented, a range_error will be 
        //thrown, and we will end up here
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (6) not in range [0..4)");

}

//Tests incorrect call to the replaceAt function.
//Attempts to call replaceAt for an index that is too low.
void replaceAt_low_incorrect(){
    //var to track whether range_error is thrown
    bool range_error_thrown = false;
    
    //var to track any error messages raised
    std::string error_message = "";

    char arr[] = {'a', 'b', 'c', 'd', 'e', 'f'};
    CharLinkedList list(arr, 6); 

    try{
        //replaceAt for LL of size 4
        list.replaceAt('a', -1);
    }
    catch (const std::range_error &e) {
        //if replaceAt is correctly implemented, a range_error will be 
        //thrown, and we will end up here
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (-1) not in range [0..6)");
}

//Tests incorrect call to the replaceAt function.
//Attempts to call replaceAt for an index equal to currSize.
void replaceAt_index_incorrect(){
    //var to track whether range_error is thrown
    bool range_error_thrown = false;

    //var to track any error messages raised
    std::string error_message = "";

    char arr[] = {'a', 'b', 'c', 'd'};
    CharLinkedList list(arr, 4); 

    try{
        //replaceAt for LL of size 4
        list.replaceAt('k', 4);
    }
    catch (const std::range_error &e) {
        //if replaceAt is correctly implemented, a range_error will be 
        //thrown, and we will end up here
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (4) not in range [0..4)");
}

//Tests concatenate fucntion with two LL.
//Afterwards, size should be 10 and list1 contains list1 and list2 concatenated.
//NOTE: capacity must be public to test the capacity test.
void concatenate_correct(){
    char arr1[] = {'h', 'e', 'l', 'l', 'o'};
    CharLinkedList list1(arr1, 5); 
    char arr2[] = {'w', 'o', 'r', 'l', 'd'};
    CharLinkedList list2(arr2,5);
    list1.concatenate(&list2);
    assert(list1.size() == 10);
    assert(list1.toString() == "[CharLinkedList of size 10 <<helloworld>>]");
}

//Tests concatenate fucntion with one LL.
//Afterwards, size should be 10 and list1 contains list1 concatenated with
//itself.
//NOTE: capacity must be public to test the capacity test.
void concatenate_same(){
    char arr1[] = {'c', 'e', 'n', 't'};
    CharLinkedList list1(arr1, 4);
    list1.concatenate(&list1);
    assert(list1.size() == 8);
    assert(list1.toString() == "[CharLinkedList of size 8 <<centcent>>]");
}

//Tests concatenate fucntion with one empty LL and one LL with chars.
//Afterwards, size should be 5 and list1 contains list2.
void concatenate_empty_array1(){
    CharLinkedList list1; 
    char arr2[] = {'w', 'o', 'r', 'l', 'd'};
    CharLinkedList list2(arr2,5);
    list1.concatenate(&list2);
    assert(list1.size() == 5);
    assert(list1.toString() == "[CharLinkedList of size 5 <<world>>]");
}

//Tests concatenate fucntion with one LL with chars and one empty LL.
//Afterwards, size should be 5 and list1 contains list1.
void concatenate_empty_array2(){
    char arr1[] = {'h', 'e', 'l', 'l', 'o'};
    CharLinkedList list1(arr1, 5);    
    CharLinkedList list2;
    list1.concatenate(&list2);
    assert(list1.size() == 5);
    assert(list1.toString() == "[CharLinkedList of size 5 <<hello>>]");
}

//Tests concatenate fucntion with two empty LLs.
//Afterwards, size should be 0 and list1 no chars.
void concatenate_both_empty(){
    CharLinkedList list1;    
    CharLinkedList list2;
    list1.concatenate(&list2);
    assert(list1.size() == 0);
    assert(list1.toString() == "[CharLinkedList of size 0 <<>>]");
}
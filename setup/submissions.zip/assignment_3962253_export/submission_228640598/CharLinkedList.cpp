/*
 *  CharLinkedList.cpp
 *  Vina Le (vle04)
 *  01/31/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Function definitions for the CharLinkedList
 *
 */

#include "CharLinkedList.h"
#include <sstream>

using namespace std;

/*
 * name:      CharLinkedList default constructor
 * purpose:   initialize an empty CharLinkedList
 * arguments: none
 * returns:   none
 * effects:   numItems to 0 (also updates pointers)
 */
CharLinkedList::CharLinkedList() {
    front = nullptr;
    back = nullptr;
    numItems = 0;
}

/*
 * name:      CharLinkedList constructor 2
 * purpose:   initialize a single element CharLinkedList consisting of one char
 * arguments: a char to initialize the CharLinkedList with
 * returns:   none
 * effects:   numItems to 1 (also updates pointers)
 */
CharLinkedList::CharLinkedList(char c) { 
    // update size
    numItems = 1;

    // create new node and update its contents
    Node *new_node = new Node;
    new_node->data = c;
    new_node->next = nullptr;
    new_node->prev = nullptr;

    // update front and back pointers of list
    front = new_node;
    back = new_node;
}

/*
 * name:      CharLinkedList constructor 3
 * purpose:   initialize a CharLinkedList containing the chars of an array
 * arguments: an array of chars and the integer length of that array of chars
 * returns:   none
 * effects:   numItems to the given size (also updates pointers)
 */
CharLinkedList::CharLinkedList(char arr[], int size) {
    front = nullptr;
    back = nullptr;
    numItems = 0;
    for (int i = 0; i < size; i++) {
        pushAtBack(arr[i]);
    }
}

/*
 * name:      CharLinkedList copy constructor
 * purpose:   makes a deep copy of a given CharLinkedList instance
 * arguments: the address of a CharLinkedList instance
 * returns:   none
 * effects:   numItems to the numItems of other (also updates pointers)
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other) {
    numItems = 0;
    front = back = nullptr;
    Node *curr = other.front;
    if (curr == nullptr) {
        front = back = nullptr;
    } else {
        while (curr != nullptr) {
            pushAtBack(curr->data);
            curr = curr->next;
        }
    }
}

/*
 * name:      CharLinkedList destructor
 * purpose:   free memory associated with the CharLinkedList
 * arguments: none
 * returns:   none
 * effects:   frees memory allocated by CharLinkedlist instances
 */
CharLinkedList::~CharLinkedList() {
    deleteAll();
}

/*
 * name:      deleteAll
 * purpose:   a recursive function that helps free memory in the destructor
 * arguments: none
 * returns:   none
 * effects:   recursively frees memory allocated by CharArraylist instances
 */
void CharLinkedList::deleteAll() {
    if (front != nullptr) {
        Node *temp = front->next;
        delete front;
        front = temp;
        deleteAll();
    }
    front = back = nullptr;
    numItems = 0;
}

/*
 * name:      &operator=
 * purpose:   recycles the storage associated with the instance on the left of
 *            the assignment and makes a deep copy of the instance on the right
 *            into the instance on the right
 * arguments: none
 * returns:   the list after the instance on the right is copied into it
 * effects:   none
 */
CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other) {
    if (this == &other) {
        return *this;
    }

    deleteAll();
    
    Node *curr = other.front;
    if (curr == nullptr) {
        front = back = nullptr;
    } else {
        while (curr != nullptr) {
            pushAtBack(curr->data);
            curr = curr->next;
        }
    }

    return *this;
}

/*
 * name:      size
 * purpose:   determine the number of items in the list
 * arguments: none
 * returns:   number of elements currently stored in the list
 * effects:   none
 */
int CharLinkedList::size() const {
    return numItems;
}

/*
 * name:      isEmpty
 * purpose:   determines if the CharLinkedList is empty or not
 * arguments: none
 * returns:   true if CharLinkedList contains no elements, false otherwise
 * effects:   none
 */
bool CharLinkedList::isEmpty() const {
    if (numItems == 0) {
        return true;
    }
    return false;
}

/*
 * name:      clear
 * purpose:   makes the instance into an empty list
 * arguments: none
 * returns:   none
 * effects:   numItems to 0 (also updates capacity and data array)
 */
void CharLinkedList::clear() {
    deleteAll();
    numItems = 0;
}

/*
 * name:      first
 * purpose:   finds the first character in the list
 * arguments: none
 * returns:   the first character in the list
 * effects:   none
 */
char CharLinkedList::first() const {
    // check for runtime error
    if (isEmpty()) {
        throw std::runtime_error("cannot get first of empty LinkedList");
    }
    return front->data;
}

/*
 * name:      last
 * purpose:   finds the last character in the list
 * arguments: none
 * returns:   the last character in the list
 * effects:   none
 */
char CharLinkedList::last() const {
    // check for runtime error
    if (isEmpty()) {
        throw std::runtime_error("cannot get last of empty LinkedList");
    }
    return back->data;
}

CharLinkedList::Node* CharLinkedList::findNode(Node *front, int index) const {
    if (index == 0) {
        return front;
    }
    return findNode(front->next, index - 1);
}

/*
 * name:      elementAt
 * purpose:   finds the element (char) in the list at a given index
 * arguments: an integer index 
 * returns:   the element (char) in the list at a give index
 * effects:   none
 */
char CharLinkedList::elementAt(int index) const {
    // check for range error
    if (index < 0 or index >= numItems) {
        throw std::range_error("index (" + to_string(index) +
        ") not in range [0.." + to_string(numItems) + ")");
    }

    return findNode(front, index)->data;
}

/*
 * name:      toString
 * purpose:   turns the array into a string, and returns it
 * arguments: none
 * returns:   a string representation of the array
 * effects:   none
 */
std::string CharLinkedList::toString() const {
    std::stringstream ss;
    ss << "[CharLinkedList of size " << numItems << " <<";

    Node *curr = front;
    for (int i = 0; i < numItems; i++) {
        ss << curr->data;
        curr = curr->next;
    }

    ss << ">>]";
    return ss.str();
}

/*
 * name:      toReverseString
 * purpose:   creates a string which contains the characters of the list in 
 *            reverse
 * arguments: none
 * returns:   a string which contains the characters of the list in 
 *            reverse
 * effects:   none
 */
std::string CharLinkedList::toReverseString() const {
    std::stringstream ss;
    ss << "[CharLinkedList of size " << numItems << " <<";

    Node *curr = back;
    for (int i = numItems - 1; curr != nullptr; i--) {
        ss << curr->data;
        curr = curr->prev;
    }

    ss << ">>]";
    return ss.str();
}

/*
 * name:      pushAtBack
 * purpose:   push the given char into the back of the list
 * arguments: a char to add to the back of the list
 * returns:   none
 * effects:   updates numItems
 */
void CharLinkedList::pushAtBack(char c) {
    Node *new_node = new Node;
    new_node->data = c;

    if (back == nullptr) {
        emptyInsert(new_node);
    } else {
        new_node->prev = back;
        back->next = new_node;
        back = new_node;
        new_node->next = nullptr;
    }
    numItems++;
}

/*
 * name:      pushAtFront
 * purpose:   push the given char into the front of the list
 * arguments: a char to add to the front of the list
 * returns:   none
 * effects:   updates numItems
 */
void CharLinkedList::pushAtFront(char c) {
    Node *new_node = new Node;
    new_node->data = c;

    if (front == nullptr) {
        emptyInsert(new_node);
    } else {
        new_node->next = front;
        front->prev = new_node;
        front = new_node;
        new_node->prev = nullptr;
    }
    numItems++;
}

/*
 * name:      emptyInsert
 * purpose:   a helper function that inserts a node when the list is empty
 * arguments: the new node to insert
 * returns:   none
 * effects:   none
 */
void CharLinkedList::emptyInsert(Node *new_node) {
    front = new_node;
    back = new_node;
    new_node->prev = nullptr;
    new_node->next = nullptr;
}

/*
 * name:      insertAt
 * purpose:   inserts the new element at the specified index
 * arguments: an element (char) and an integer index
 * returns:   none
 * effects:   updates numItems
 */
void CharLinkedList::insertAt(char c, int index) {
    if (index < 0 or index > numItems) {
        throw std::range_error("index (" + to_string(index) +
        ") not in range [0.." + to_string(numItems) + "]");
    }

    // front insert
    if (isEmpty() or index == 0) {
        pushAtFront(c);
    } else if (index == numItems) {
        pushAtBack(c);
    } else {
        // find the position before new node needs to be inserted
        Node *new_node = new Node;
        new_node->data = c;
        Node *curr = front;
        for (int i = 0; i < index - 1; i++) {
            curr = curr->next;
        }

        // middle insert
        new_node->next = curr->next;
        new_node->next->prev = new_node;
        curr->next = new_node;
        new_node->prev = curr;
        numItems++;
    }
}

/*
 * name:      popFromFront
 * purpose:   removes the first element from the list
 * arguments: none
 * returns:   none
 * effects:   updates numItems
 */
void CharLinkedList::popFromFront() {
    // check for runtime error
    if (isEmpty()) {
        throw std::runtime_error("cannot pop from empty LinkedList");
    } else if (numItems == 1) {
        clear();
    } else {
        Node *next_node = front->next;
        next_node->prev = nullptr;
        delete front;
        front = next_node;
        numItems--;
    }
}

/*
 * name:      popFromBack
 * purpose:   removes the last element from the list
 * arguments: none
 * returns:   none
 * effects:   updates numItems
 */
void CharLinkedList::popFromBack() {
    // check for runtime error
    if (isEmpty()) {
        throw std::runtime_error("cannot pop from empty LinkedList");
    } else if (numItems == 1) {
        clear();
    } else {
        Node *prev_node = back->prev;
        prev_node->next = nullptr;
        delete back;
        back = prev_node;
        numItems--;
    }
}

/*
 * name:      removeAt
 * purpose:   removes the element at the specified index
 * arguments: an integer index
 * returns:   none
 * effects:   updates numItems
 */
void CharLinkedList::removeAt(int index) {
    if (index < 0 or index >= numItems) {
        throw std::range_error("index (" + to_string(index) +
        ") not in range [0.." + to_string(numItems) + ")");
    }

    // front removal
    if (index == 0) {
        popFromFront();
    } else if (index == numItems - 1) {
        popFromBack();
    } else {
        // find the node we want to remove
        Node *node_remove = front;
        for (int i = 0; i < index; i++) {
            node_remove = node_remove->next;
        }
        node_remove->next->prev = node_remove->prev;
        node_remove->prev->next = node_remove->next;
        delete node_remove;
        numItems--;
    }
}

/*
 * name:      replaceAt
 * purpose:   removes the first element from the list
 * arguments: an element (char) and an integer index
 * returns:   none
 * effects:   none
 */
void CharLinkedList::replaceAt(char c, int index) {
    // check for range error
    if (index < 0 or index >= numItems) {
        throw std::range_error("index (" + to_string(index) +
        ") not in range [0.." + to_string(numItems) + ")");
    }

    findNode(front, index)->data = c;
}

/*
 * name:      insertInOrder
 * purpose:   inserts a new element (char) into the list in ASCII order
 *            at the first correct index
 * arguments: an element (char)
 * returns:   none
 * effects:   none
 */
void CharLinkedList::insertInOrder(char c) {
    // iterate through list and check for ASCII values for where to insert c
    Node *curr = front;
    int index = 0;
    for (int i = 0; i < numItems; i++) {
        if (curr->data < c) {
            index = i + 1;
        }
        curr = curr->next;
    }

    insertAt(c, index);
}

/*
 * name:      concatenate
 * purpose:   adds a copy of the list pointed to by the parameter value to
              the end of the list the function was called from
 * arguments: a pointer to a second CharLinkedList
 * returns:   none
 * effects:   updates numItems
 */
void CharLinkedList::concatenate(CharLinkedList *other) {
    Node *curr = other->front;
    int index = other->numItems;
    for (int i = 0; i < index; i++) {
        pushAtBack(curr->data);
        curr = curr->next;
    }
}

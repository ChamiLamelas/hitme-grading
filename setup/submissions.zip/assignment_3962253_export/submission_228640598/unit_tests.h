/*
 *  unit_tests.h
 *  Vina Le (vle04)
 *  01/31/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  Functions for unit testing
 *
 */

#include "CharLinkedList.h"
#include <cassert>

using namespace std;

// make sure no fatal errors/memory leaks in the default constructor
void default_constructor_test0() {
    CharLinkedList list;
}

// make sure no items exist upon construction of the list
void default_constructor_test1() {
    CharLinkedList list;
    assert(list.size() == 0);
}

// make sure that there is only one element upon construction
void constructor_2_test() {
    CharLinkedList list('a');
    cout << list.toString();
    assert(list.toString() == "[CharLinkedList of size 1 <<a>>]");
    assert(list.size() == 1);
}

// make sure that the elements of an array match the elements of the
// CharLinkedList upon its construction
void constructor_3_test() {
    char arr[] = {'a', 'b', 'c'};
    CharLinkedList list(arr, 3);
    cout << list.toString();
    assert(list.toString() == "[CharLinkedList of size 3 <<abc>>]");
    assert(list.size() == 3);
}

// checks that the copy constructor made an accurate deep copy of a 1-elem list
// while constructing another list
void copy_constructor_single_list() {
    CharLinkedList list1('a');
    CharLinkedList list2(list1);
    cout << list1.toString();
    cout << list2.toString();
    assert(list2.toString() == list1.toString());
}

// checks that the copy constructor made an accurate deep copy of a larger list
// while constructing another list
void copy_constructor_large() {
    char arr[] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList list1(arr, 8);
    CharLinkedList list2(list1);
    cout << list1.toString();
    cout << list2.toString();
    assert(list2.toString() == list1.toString());
}

// checks that the copy constructor made an accurate deep copy of an empty list
void copy_constructor_empty() {
    CharLinkedList list1;
    CharLinkedList list2(list1);
    cout << list1.toString();
    cout << list2.toString();
    assert(list2.toString() == list1.toString());
}

// tests if the assignment operator creates a deep copy by checking the chars in
// the list and the number of items in each list (same size)
void assignment_test() {
    CharLinkedList list1('a');
    CharLinkedList list2('b');
    list1 = list2;
    assert(list1.toString() == "[CharLinkedList of size 1 <<b>>]");

    // check that adding a char to one list would not change the other
    list2.pushAtBack('c');
    assert(list1.toString() == "[CharLinkedList of size 1 <<b>>]");
}

// checks that the copy constructor made an accurate deep copy of a larger list
// while constructing another list
void assignment_large_list() {
    char arr[] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList list1(arr, 8);
    CharLinkedList list2;
    list2 = list1;
    cout << list1.toString();
    cout << list2.toString();
    assert(list2.toString() == list1.toString());
}

// tests if the assignment operator creates a deep copy of a nonempty list
// to an empty list
void assignment_empty_test() {
    CharLinkedList list1('a');
    CharLinkedList list2;
    list2 = list1;
    assert(list2.toString() == "[CharLinkedList of size 1 <<a>>]");
    assert(list2.toString() == list1.toString());
}

// tests if the assignment operator creates a deep copy of a nonempty list
// to an empty list
void assignment_both_empty_test() {
    CharLinkedList list1;
    CharLinkedList list2;
    list2 = list1;
    assert(list2.toString() == "[CharLinkedList of size 0 <<>>]");
    assert(list2.toString() == list1.toString());
}

// tests for errors when an instance of a list is assigned to itself
void self_assign_test() {
    CharLinkedList list('a');
    list = list;

    // make sure the list did not change
    assert(list.toString() == "[CharLinkedList of size 1 <<a>>]");
    assert(list.size() == 1);
}

// checks if the CharLinkedList is empty and that we report an empty list 
// correctly
void isEmpty_test() {
    CharLinkedList list;
    assert(list.isEmpty());
}

// attempts to call clear on an empty list
void clear_empty() {
    CharLinkedList list;
    list.clear();
    assert(list.isEmpty());
}

// check that there are no items in the 1-element list after calling clear
void clear_singleton_list() {
    CharLinkedList list('a');
    list.clear();
    assert(list.isEmpty());
}

// check that there are no items in a larger list after calling clear
void clear_large_list() {
    char arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList list(arr, 8);
    list.clear();
    assert(list.isEmpty());
}

// checks that the given list is as we expect it to be (without pushing any
// items on to the list)
void toString_empty_list() {
    CharLinkedList list;
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}

// checks that the given large list is as we expect it
void toString_large_list() {
    char arr[] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList list(arr, 8);
    assert(list.toString() == "[CharLinkedList of size 8 <<abcdefgh>>]");
}

// checks that the given list is as we expect it to be (without any items on the
// list)
void toReverseString_empty_list() {
    CharLinkedList list;
    cout << list.toReverseString();
    assert(list.toReverseString() == "[CharLinkedList of size 0 <<>>]");
}

// checks that the given large list is as we expect it
void toReverseString_large_list() {
    char arr[] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList list(arr, 8);
    assert(list.toReverseString() == "[CharLinkedList of size 8 <<hgfedcba>>]");
}

// checks that correct first char is returned from a 1-element list
void first_singleton_list() {
    CharLinkedList list('a');
    assert(list.first() == 'a');
}

// checks that correct first char is returned from a larger list
void first_large_list() {
    char arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList list(arr, 8);
    assert(list.first() == 'a');
}

// tests for a runtime error, attempts to call first on an empty list
void first_empty_list() {
    // var to track whether runtime_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList list;
    try {
        // first on an empty list
        list.first();
    }
    catch (const std::runtime_error &e) {
        // if first is correctly implememted, a runtime_error will be thrown,
        // and we will end up here
        runtime_error_thrown = true;
        error_message = e.what();
    }

    // make assertions
    assert(runtime_error_thrown);
    assert(error_message == "cannot get first of empty LinkedList");
}

// checks that correct last char is returned from a 1-element list
void last_singleton_list() {
    CharLinkedList list('a');
    assert(list.last() == 'a');
}

// checks that correct last char is returned from a larger list
void last_large_list() {
    char arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList list(arr, 8);
    assert(list.last() == 'h');
}

// tests for a runtime error, attempts to call last on an empty list
void last_empty_list() {
    // var to track whether runtime_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList list;
    try {
        // first on an empty list
        list.last();
    }
    catch (const std::runtime_error &e) {
        // if last is correctly implememted, a runtime_error will be thrown,
        // and we will end up here
        runtime_error_thrown = true;
        error_message = e.what();
    }

    // make assertions
    assert(runtime_error_thrown);
    assert(error_message == "cannot get last of empty LinkedList");
}

// checks that correct char is returned 
void elementAt_singleton_list() {
    CharLinkedList list('a');
    assert(list.elementAt(0) == 'a');
}

// tests for a range error, attempts to call elementAt for index larger or equal
// to the size of the list
void elementAt_incorrect() {
    //var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList list('a');
    try {
    // elementAt for out-of-range index
    list.elementAt(1);
    }
    catch (const std::range_error &e) {
    // if elementAt is correctly implemented, a range_error will be thrown, and
    // we will end up here
    range_error_thrown = true;
    error_message = e.what();
    }

    // make assertions
    assert(range_error_thrown);
    assert(error_message == "index (1) not in range [0..1)");
}

// check for correct char from front of larger list
void elementAt_front_large_list() {
    char arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList list(arr, 8);
    assert(list.elementAt(0) == 'a');
}

// check for correct char from back of larger list
void elementAt_back_large_list() {
    char arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList list(arr, 8);
    cout << list.elementAt(7);
    assert(list.elementAt(7) == 'h');
}

// check for correct char from middle of larger list
void elementAt_middle_large_list() {
    char arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList list(arr, 8);
    cout << list.elementAt(4);
    assert(list.elementAt(4) == 'e');
}

// inserts a char into the back of an empty list
void pushAtBack_empty() {
    CharLinkedList list;
    list.pushAtBack('a');
    cout << list.toString();
    assert(list.toString() == "[CharLinkedList of size 1 <<a>>]");
    assert(list.size() == 1);
}

// inserts a char into the back of a 1-element list
void pushAtBack_singleton_list() {
    CharLinkedList list('a');
    list.pushAtBack('b');
    cout << list.toString();
    assert(list.toString() == "[CharLinkedList of size 2 <<ab>>]");
    assert(list.size() == 2);
}

// inserts a char into the back of a larger list
void pushAtBack_large_list() {
    char arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList list(arr, 8);
    list.pushAtBack('z');
    cout << list.toString();
    assert(list.toString() == "[CharLinkedList of size 9 <<abcdefghz>>]");
    assert(list.size() == 9);
}

// tests calling pushAtBack for a large number of elements
void pushAtBack_many_elements() {
    CharLinkedList list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        list.pushAtBack('a');
    }

    assert(list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(list.elementAt(i) == 'a');
    }
}

// inserts a char into the front of an empty list
void pushAtFront_empty() {
    CharLinkedList list;
    list.pushAtFront('a');
    cout << list.toString();
    assert(list.toString() == "[CharLinkedList of size 1 <<a>>]");
    assert(list.size() == 1);
}

// inserts a char into the front of a 1-element list
void pushAtFront_singleton_list() {
    CharLinkedList list('a');
    list.pushAtFront('b');
    cout << list.toString();
    assert(list.toString() == "[CharLinkedList of size 2 <<ba>>]");
    assert(list.size() == 2);
}

// inserts a char into the front of a larger list
void pushAtFront_large_list() {
    char arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList list(arr, 8);
    list.pushAtFront('z');
    cout << list.toString();
    assert(list.toString() == "[CharLinkedList of size 9 <<zabcdefgh>>]");
    assert(list.size() == 9);
}

// tests calling pushAtFront for a large number of elements
void pushAtFront_many_elements() {
    CharLinkedList list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the front of the list
        list.pushAtFront('a');
    }

    assert(list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(list.elementAt(i) == 'a');
    }
}

// test correct insertion into an empty list. afterwards, size should be 1 and
// element at index 0 should be the element we inserted
void insertAt_empty_correct() { 
    CharLinkedList list;
    list.insertAt('a', 0);
    assert(list.size() == 1);
    assert(list.elementAt(0) == 'a');
}

// tests incorrect insertion into an empty list. attempts to call insertAt for 
// index larger than 0. should result in a range error
void insertAt_empty_incorrect() {

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList list;
    try {
        // insertAt for out-of-range index
        list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        // if insertAt is correctly implemented, a range_error will be thrown,
        // and we will end up here
        range_error_thrown = true;
        error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0]");
    
}

// tests correct insertAt for front of 1-element list.
void insertAt_front_singleton_list() {

    // initialize 1-element list
    CharLinkedList list('a');

    // insert at front
    list.insertAt('b', 0);

    assert(list.size() == 2);
    assert(list.toString() == "[CharLinkedList of size 2 <<ba>>]");
    assert(list.elementAt(0) == 'b');
    assert(list.elementAt(1) == 'a');
    
}

// tests correct insertAt for back of 1-element list.
void insertAt_back_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList list('a');

    // insert at back
    list.insertAt('b', 1);

    assert(list.size() == 2);
    assert(list.toString() == "[CharLinkedList of size 2 <<ab>>]");
    assert(list.elementAt(0) == 'a');
    assert(list.elementAt(1) == 'b');
    
}

// tests calling insertAt for a large number of elements
void insertAt_many_elements() {
    
    CharLinkedList list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        list.insertAt('a', i);
    }

    assert(list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(list.elementAt(i) == 'a');
    }
    
}

// tests insertion into front of a larger list
void insertAt_front_large_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.insertAt('z', 0);

    assert(test_list.size() == 9);
    assert(test_list.elementAt(0) == 'z');
    assert(test_list.toString() == "[CharLinkedList of size 9 <<zabcdefgh>>]");
}

// tests insertion into back of a larger list
void insertAt_back_large_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.insertAt('z', 8);

    assert(test_list.size() == 9);
    assert(test_list.elementAt(8) == 'z');
    assert(test_list.toString() == "[CharLinkedList of size 9 <<abcdefghz>>]");
}

// tests insertion into middle of a larger list
void insertAt_middle_large_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.insertAt('z', 4);

    assert(test_list.size() == 9);
    assert(test_list.elementAt(4) == 'z');
    assert(test_list.toString() == "[CharLinkedList of size 9 <<abcdzefgh>>]");
}

// tests out-of-range insertion for a non-empty list
void insertAt_nonempty_incorrect() {
   
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8]");
}

// tests that popFromFront removes the first char from a 1-element list
void popFromFront_singleton_list() {
    CharLinkedList list('a');
    list.popFromFront();
    cout << list.toString();
    assert(list.size() == 0);
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}

// tests that popFromFront removes the first char from a larger list
void popFromFront_large_list() {
    char arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList list(arr, 8);
    list.popFromFront();
    cout << list.toString();
    assert(list.size() == 7);
    assert(list.toString() == "[CharLinkedList of size 7 <<bcdefgh>>]");
}

// tests popFromFront on an empty list
void popFromFront_incorrect() {
    // var to track whether range_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList list;
    try {
        list.popFromFront();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

// tests that popFromBack removes the first char from a 1-element list
void popFromBack_singleton_list() {
    CharLinkedList list('a');
    list.popFromBack();
    cout << list.toString();
    assert(list.size() == 0);
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}

// tests that popFromBack removes the first char from a larger list
void popFromBack_large_list() {
    char arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList list(arr, 8);
    list.popFromBack();
    cout << list.toString();
    assert(list.size() == 7);
    assert(list.toString() == "[CharLinkedList of size 7 <<abcdefg>>]");
}

// tests popFromBack on an empty list
void popFromBack_incorrect() {
    // var to track whether range_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList list;
    try {
        list.popFromBack();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

// tests correct removal from front of nonempty list
void removeAt_front() {
    char arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList list(arr, 8);
    list.removeAt(0);
    cout << list.toString();
    assert(list.size() == 7);
    assert(list.toString() == "[CharLinkedList of size 7 <<bcdefgh>>]");
}

// tests correct removal from middle of nonempty list
void removeAt_middle() {
    char arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList list(arr, 8);
    list.removeAt(4);
    cout << list.toString();
    assert(list.size() == 7);
    assert(list.toString() == "[CharLinkedList of size 7 <<abcdfgh>>]");
}

// tests correct removal from back of nonempty list
void removeAt_back() {
    char arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList list(arr, 8);
    list.removeAt(7);
    cout << list.toString();
    assert(list.size() == 7);
    assert(list.toString() == "[CharLinkedList of size 7 <<abcdefg>>]");
}

// tests out-of-range removal for an empty list.
void removeAt_empty_incorrect() {
    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList list;
    try {
        list.removeAt(0);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (0) not in range [0..0)");
}

// tests out-of-range removal for a non-empty list.
void removeAt_nonempty_incorrect() {
    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    char arr[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(arr, 5);
    try {
        list.removeAt(10);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (10) not in range [0..5)");
}

// tests correct replacement in front of nonempty list
void replaceAt_front() {
    char arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList list(arr, 8);
    list.replaceAt('z', 0);
    cout << list.toString();
    assert(list.size() == 8);
    assert(list.toString() == "[CharLinkedList of size 8 <<zbcdefgh>>]");
}

// tests correct replacement in middle of nonempty list
void replaceAt_middle() {
    char arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList list(arr, 8);
    list.replaceAt('z', 4);
    cout << list.toString();
    assert(list.size() == 8);
    assert(list.toString() == "[CharLinkedList of size 8 <<abcdzfgh>>]");
}

// tests correct replacement in back of nonempty list
void replaceAt_back() {
    char arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList list(arr, 8);
    list.replaceAt('z', 7);
    cout << list.toString();
    assert(list.size() == 8);
    assert(list.toString() == "[CharLinkedList of size 8 <<abcdefgz>>]");
}

// tests out-of-range replacement for an empty list.
void replaceAt_empty_incorrect() {
    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList list;
    try {
        list.replaceAt('x', 0);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (0) not in range [0..0)");
}

// tests out-of-range replacement for a non-empty list.
void replaceAt_nonempty_incorrect() {
    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    char arr[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(arr, 5);
    try {
        list.replaceAt('x', 10);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (10) not in range [0..5)");
}

// tests correct insertion into an empty array list. afterwards, size should be 
// 1 and element at index 0. should be the element we inserted.
void insertInOrder_empty() { 
    CharLinkedList list;
    list.insertInOrder('a');
    cout << list.toString();
    assert(list.size() == 1);
    assert(list.elementAt(0) == 'a');
}

// tests correct insertion into the front a list with a char whose ASCII would 
// place it at the front
void insertInOrder_front() { 
    char arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList list(arr, 8);
    list.insertInOrder('A');
    cout << list.toString();
    assert(list.size() == 9);
    assert(list.elementAt(0) == 'A');
    assert(list.toString() == "[CharLinkedList of size 9 <<Aabcdefgh>>]");
}

// tests correct insertion into the front a list with a char whose ASCII would 
// place it at the middle
void insertInOrder_middle() { 
    char arr[7] = { 'a', 'b', 'c', 'e', 'f', 'g', 'h' };
    CharLinkedList list(arr, 7);
    list.insertInOrder('d');
    cout << list.toString();
    assert(list.size() == 8);
    assert(list.elementAt(3) == 'd');
    assert(list.toString() == "[CharLinkedList of size 8 <<abcdefgh>>]");
}

// tests correct insertion into the front a list with a char whose ASCII would 
// place it at the back
void insertInOrder_back() { 
    char arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList list(arr, 8);
    list.insertInOrder('i');
    cout << list.toString();
    assert(list.size() == 9);
    assert(list.elementAt(8) == 'i');
    assert(list.toString() == "[CharLinkedList of size 9 <<abcdefghi>>]");
}


// tests calling insertInOrder for a large number of elements
void insertInOrder_many_elements() {
    
    CharLinkedList list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        list.insertInOrder('a');
    }

    assert(list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(list.elementAt(i) == 'a');
    }
    
}

// tests concatenating two different lists
void concatenate_two_diff_lists() {
    char word1[] = {'r', 'a', 'c', 'e'};
    char word2[] = {'c', 'a', 'r'};
    CharLinkedList list1(word1, 4);
    CharLinkedList list2(word2, 3);
    list1.concatenate(&list2);
    cout << list1.toString();
    assert(list1.size() == 7);
    assert(list1.toString() == "[CharLinkedList of size 7 <<racecar>>]");
}

// tests concatenating an list with itself
void concatenate_itself() {
    char word[] = {'c', 'a', 'r'};
    CharLinkedList list(word, 3);
    list.concatenate(&list);
    cout << list.toString();
    assert(list.size() == 6);
    assert(list.toString() == "[CharLinkedList of size 6 <<carcar>>]");
}

// tests empty list being concatenated with nonempty list
void concatenate_empty_nonempty() {
    char word[] = {'c', 'a', 'r'};
    CharLinkedList list1;
    CharLinkedList list2(word, 3);
    list1.concatenate(&list2);
    cout << list1.toString();
    assert(list1.size() == 3);
    assert(list1.toString() == "[CharLinkedList of size 3 <<car>>]");
}

// tests nonempty list being concatenated with empty list
void concatenate_nonempty_empty() {
    char word[] = {'c', 'a', 'r'};
    CharLinkedList list1;
    CharLinkedList list2(word, 3);
    list2.concatenate(&list1);
    cout << list2.toString();
    assert(list2.size() == 3);
    assert(list2.toString() == "[CharLinkedList of size 3 <<car>>]");
}
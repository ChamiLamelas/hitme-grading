/*
 *  CharLinkedList.h
 *  Vina Le (vle04)
 *  01/31/2023
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  This is a class declaration for a CharLinkedList for hw02
 *
 */

#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H

#include <string>

class CharLinkedList {
public:
    // constructors
    CharLinkedList();
    CharLinkedList(char c);
    CharLinkedList(char arr[], int size);
    CharLinkedList(const CharLinkedList &other);

    // destructor
    ~CharLinkedList();

    // other functions 
    int size() const;
    bool isEmpty() const;
    std::string toString() const;
    std::string toReverseString() const;
    CharLinkedList &operator=(const CharLinkedList &other);
    void pushAtBack(char c);
    void pushAtFront(char c);
    char elementAt(int index) const;
    void clear();
    char first() const;
    char last() const;
    void insertAt(char c, int index);
    void insertInOrder(char c);
    void removeAt(int index);
    void popFromFront();
    void popFromBack();
    void replaceAt(char c, int index);
    void concatenate(CharLinkedList *other);

private:
    struct Node {
        char data;
        Node *next;
        Node *prev;
    };
    
    Node *front;
    Node *back;
    int numItems;

    // helper functions
    void deleteAll();
    void emptyInsert(Node *new_node);
    Node* findNode(Node *curr, int index) const;
};

#endif

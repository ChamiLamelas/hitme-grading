/*
 *  CharLinkedList.cpp
 *  Charlotte Yamamoto
 *  2-2-2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  implement the methods of the CharLinkedList class
 *
 */

#include "CharLinkedList.h"

/* 
 * default constructor (constructor 0)
 * input: none
 * purpose: create an empty CharLinkedList
 * output: empty instance of a CharLinkedList
 */
CharLinkedList::CharLinkedList(){
    list_size = 0;
    front = nullptr;
    tail = nullptr;
}

/* 
 * constructor 1
 * input: a character
 * purpose: create a CharLinkedList of size 1 containing the input character
 * output: the described instance of a CharLinkedList
 */
CharLinkedList::CharLinkedList(char c){
    list_size = 1;
    Node *n = make_node(c);
    front = n;
    tail = n;
}

/* 
 * constructor 2
 * input: an array of characters and the size of that array
 * purpose: create a CharLinkedList containing the input array
 * output: ^^ that
 */
CharLinkedList::CharLinkedList(char arr[], int size){
    list_size = size;
    Node *prev;
    front = make_node(arr[0]);
    prev = front;

    for (int i = 1; i < list_size; i++){
        Node *n = make_node(arr[i]);
        link(prev, n);
        tail = n;
        prev = n;
    }


}

/* 
 * constructor 3
 * input: another CharLinkedList
 * purpose: create a deep copy of the input CharLinkedList
 * output: ^^that
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other){
    list_size = other.list_size;
    Node *prev;
    front = make_node(other.first());
    prev = front;

    for (int i = 1; i < list_size; i++){
        Node *n = make_node(other.elementAt(i));
        link(prev, n);
        prev = n;
        tail = n;
    }
}

/* 
 * destructor
 * input: none
 * purpose: deallocate all heap memory associated with the object
 * output: none
 */
CharLinkedList::~CharLinkedList(){
    if (not isEmpty()){
        destroy_helper(front);
    }
}

/* 
 * equals operator
 * input: another CharLinkedList
 * purpose: create a deep copy of object on right
 * effects: any previous memory associated with object on left is destroyed
 * output: deep copy of object on right
 */
CharLinkedList CharLinkedList::operator=(const CharLinkedList &other){
    if (not isEmpty()){
        destroy_helper(front);
    }
    list_size = other.list_size;
    Node *prev;
    front = make_node(other.first());
    prev = front;

    for (int i = 1; i < list_size; i++){
        Node *n = make_node(other.elementAt(i));
        link(prev, n);
        prev = n;
        tail = n;
    }

    return *this;
}

/* 
 * isEmpty
 * input: none
 * purpose: return true if the list is empty, false otherwise
 * output: bool determining whether or not the list is empty
 */
bool CharLinkedList::isEmpty() const{
    return list_size == 0;
}

/* 
 * clear
 * input: none
 * purpose: remove all elements from the list
 * effects: deletes all elements in the list
 * output: none
 */
void CharLinkedList::clear(){
    if (not isEmpty()){
        destroy_helper(front);
    }
    front = nullptr;
    tail = nullptr;
    list_size = 0;
}

/* 
 * size
 * input: none
 * purpose: return the number of elements in the list
 * output: the number of elements in the list
 */
int CharLinkedList::size() const{
    return list_size;
}

/* 
 * first
 * input: none
 * purpose: return the first element of the list
 * output: the first element of the list
 */
char CharLinkedList::first() const{
    if (isEmpty()){
        throw std::runtime_error("cannot get first of empty LinkedList");
    }
    return front->ch;
}

/* 
 * last
 * input: none
 * purpose: return the last element of the list
 * output: the last element of the list
 */
char CharLinkedList::last() const{
    if (isEmpty()){
        throw std::runtime_error("cannot get last of empty LinkedList");
    }
    return tail->ch;
}

/* 
 * elementAt
 * input: an int (index)
 * purpose: find and return the element at the specified index
 * output: the element at the specified index
 */
char CharLinkedList::elementAt(int index) const{
    if (index < 0 or index >= list_size){
        std::stringstream msg;
        msg << "index (" << index << ") not in range [0.." << list_size << ")";
        throw std::range_error(msg.str());
    }

    if (index > list_size / 2){
        return get_at(index - list_size + 1, tail)->ch;
    }

    return get_at(index, front)->ch;
}

/* 
 * toString
 * input: none
 * purpose: create a string summarizing the contents of the list
 * output: that string ^^
 */
std::string CharLinkedList::toString() const{
    std::stringstream ss;
    ss << "[CharLinkedList of size " << list_size << " <<";
    if (not isEmpty()){
        Node *current = front;
        ss << current->ch;

        while (current->next != nullptr){
            current = current->next;
            ss << current->ch;
        }
    }
    
    ss << ">>]";
    return ss.str();
}

/* 
 * toReverseString
 * input: none
 * purpose: create a string summarizing the contents of the list in 
 *          reverse order
 * output: that string ^^
 */
std::string CharLinkedList::toReverseString() const{
    std::stringstream ss;
    ss << "[CharLinkedList of size " << list_size << " <<";
    if (not isEmpty()){
        Node *current = tail;
        ss << current->ch;

        while (current->previous != nullptr){
            current = current->previous;
            ss << current->ch;
        }
    }
    ss << ">>]";
    return ss.str();
}

/* 
 * pushAtBack
 * input: the character to add at the back
 * purpose: append a character to the end of a list
 * effects: increases size by 1
 * output: none
 */
void CharLinkedList::pushAtBack(char c){
    Node *new_node = make_node(c);
    if (isEmpty()){
        front = new_node;
    } else {
        link(tail, new_node);
    }
    tail = new_node;
    list_size++;
}

/* 
 * pushAtFront
 * input: the character to add to the front
 * purpose: insert a character at the front of a list
 * effects: increases size by 1
 * output: none
 */
void CharLinkedList::pushAtFront(char c){
    Node *new_node = make_node(c);
    if (isEmpty()){
        tail = new_node;
    } else {
        link(new_node, front);
    }
    front = new_node;
    list_size++;
}


/* 
 * insertAt
 * input: the character to insert and the index to insert it at
 * purpose: insert a character into the list at the specified index
 * effects: increases size by 1
 * output: none
 */
void CharLinkedList::insertAt(char c, int index){
    if (index < 0 or index > list_size){
        std::stringstream msg;
        msg << "index (" << index << ") not in range [0.." << list_size << "]";
        throw std::range_error(msg.str());
    }

    if (index == 0){
        pushAtFront(c);
    } else if (index == list_size){
        pushAtBack(c);
    } else{
        Node *new_node = make_node(c);
        Node *right = get_at(index, front);
        Node *left = right->previous;
        list_size++;
        link(left, new_node);
        link(new_node, right);
    }
}

/* 
 * insertInOrder
 * input: char to insert
 * purpose: insert char into list in ascii order
 * effects: increases size by 1
 * output: none
 */
void CharLinkedList::insertInOrder(char c){
    if (not isEmpty()){
        Node *curr = front;
        int idx = 0;
        while (curr->ch < c){
            idx++;
            curr = curr->next;
        }
        insertAt(c, idx);
    } else {
        pushAtFront(c); // if the list is empty, just add it to the beginning
    }
}


/* 
 * popFromFront
 * input: none
 * purpose: remove first element in list
 * effects: decreases size by 1
 * output: none
 */
void CharLinkedList::popFromFront(){
    if (isEmpty()){
        throw std::runtime_error("cannot pop from empty LinkedList");
    }

    front = get_at(1, front);
    delete front->previous;
    front->previous = nullptr;
    list_size--;
}

/* 
 * popFromBack
 * input: none
 * purpose: remove last element in list
 * effects: decreases size by 1
 * output: none
 */
void CharLinkedList::popFromBack(){
    if (isEmpty()){
        throw std::runtime_error("cannot pop from empty LinkedList");
    }
    tail = get_at(-1, tail);
    delete tail->next;
    tail->next = nullptr;
    list_size--;
}

/* 
 * removeAt
 * input: index to remove at
 * purpose: remove char at given index
 * effects: links together nodes on either side of the removed node, 
 *          decreases size by 1
 * output: none
 */
void CharLinkedList::removeAt(int index){
    if (index < 0 or index >= list_size){
        std::stringstream msg;
        msg << "index (" << index << ") not in range [0.." << list_size << ")";
        throw std::range_error(msg.str());
    }
    if (index == 0){ // check to see if another function can be used
        popFromFront();
    } else if (index == list_size - 1){
        popFromBack();
    } else{
        Node *curr = get_at(index, front);
        list_size--;
        link(curr->previous, curr->next);
        delete curr;
    }
}

/* 
 * replaceAt
 * input: index to replace at and char to replace with
 * purpose: replace the element at the given index with the provided char
 * output: none
 */
void CharLinkedList::replaceAt(char c, int index){
    if (index < 0 or index >= list_size){
        std::stringstream msg;
        msg << "index (" << index << ") not in range [0.." << list_size << ")";
        throw std::range_error(msg.str());
    }
    get_at(index, front)->ch = c;
}


/* 
 * concatenate
 * input: pointer to another CharLinkedList
 * purpose: append a copy of the other list to the end of this list
 * effects: increases size of list by size of other list
 * output: none
 */
void CharLinkedList::concatenate(CharLinkedList *other){
    if (not other->isEmpty()){ // make sure the other list isn't empty
       Node *curr = other->front;
        pushAtBack(curr->ch);
        while (curr->next != nullptr){
            curr = curr->next;
            pushAtBack(curr->ch);
        } 
    }
}

/* 
 * get_at
 * input: index and a pointer to the current node
 * purpose: to find the node at the index (index of current node + index input)
 * output: a pointer to the node in the specified position
 */
CharLinkedList::Node *CharLinkedList::get_at(int index, Node *curr) const{
    if (index == 0){
        return curr;
    } else if (index < 0 and curr->previous != nullptr){
        return get_at(index + 1, curr->previous);
    } else if (index > 0 and curr->next != nullptr){
        return get_at(index - 1, curr->next);
    } else {
        throw std::range_error("if you're seeing this, "
            "you need to fix another function");
    }
}

/* 
 * make_node
 * input: char for the node to hold
 * purpose: simplify the process of creating a new node
 * output: a pointer to the new node
 */
CharLinkedList::Node *CharLinkedList::make_node(char c){
    Node *node = new Node;
    node->ch = c;
    node->next = nullptr;
    node->previous = nullptr;
    return node;
}

/* 
 * destroy_helper
 * input: pointer to a node
 * purpose: to delete all memory associated with the object
 * output: none
 */
void CharLinkedList::destroy_helper(Node *n){
    if (n->next != nullptr){
        destroy_helper(n->next);
    }
    delete n;
}

/* 
 * link
 * input: two pointers to nodes to link together
 * purpose: establish links between the two nodes
 * output: none
 */
void CharLinkedList::link(Node *one, Node *two){
    if (one != nullptr){
        one->next = two;
    } else {
        two->previous = nullptr;
        front = two;
    }
    if (two != nullptr){
        two->previous = one;
    } else {
        one->next = nullptr;
        tail = one;
    }
}
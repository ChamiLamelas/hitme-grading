/*
 *  CharLinkedList.h
 *  YOUR NAME HERE
 *  DATE CREATED
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  interface for CharLinkedList
 *
 */

#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H

#include <string>
#include <sstream>

class CharLinkedList {
    public:

        // constructors
        CharLinkedList();
        CharLinkedList(char c);
        CharLinkedList(char arr[], int size);
        CharLinkedList(const CharLinkedList &other);

        // destructor
        ~CharLinkedList();

        // assignment operator =
        CharLinkedList operator=(const CharLinkedList &other);

        bool isEmpty() const; // returns true if empty
        void clear(); // removes all elements from list
        int size() const; // returns number of elements in list
        char first() const; // returns first element in list
        char last() const; // returns last element in list
        char elementAt(int index) const; // returns element at given index

        std::string toString() const;
        std::string toReverseString() const;

        void pushAtBack(char c);
        void pushAtFront(char c);

        void insertAt(char c, int index);
        void insertInOrder(char c);

        void popFromFront();
        void popFromBack();

        void removeAt(int index);
        void replaceAt(char c, int index);

        void concatenate(CharLinkedList *other);

    private:
        struct Node {
            char ch;
            Node *previous;
            Node *next;
        };

        Node *front;
        Node *tail;
        int list_size;

        Node *get_at(int index, Node *curr) const;
        
        void link(Node *one, Node *two);

        Node *make_node(char c);
        void destroy_helper(Node *n);

};

#endif

/*
 *  unit_tests.h
 *  Charlotte Yamamoto
 *  2-2-2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  unit testing
 *
 */

#include "CharLinkedList.h"
#include <iostream>
#include <cassert>

void constructor_test0(){
    CharLinkedList a;
}

void constructor_test1(){
    CharLinkedList b('x');
}

void constructor_test2(){
    char d[] = {'a','b','c'};
    CharLinkedList c(d, 3);
}

void constructor_test3(){
    char d[] = {'a','b','c','d','e','f'};
    CharLinkedList c(d, 6);
    CharLinkedList e(c);

    assert(c.toString() == e.toString());

    e.replaceAt('Q', 2);

    assert(not (c.toString() == e.toString()));
}

void operator_test(){
    char chars[] = {'a','b','c','d','e','f'};
    CharLinkedList test(chars, 6);
    char chars_1[] = {'x','y','z'};
    CharLinkedList test_1(chars_1, 3);

    test_1 = test;

    assert(test_1.toString() == "[CharLinkedList of size 6 <<abcdef>>]");
    
    test_1.replaceAt('Q', 2);
    assert(not (test.toString() == test_1.toString()));
}

void isEmpty_test_true(){
    CharLinkedList a;
    assert(a.isEmpty());
}

void isEmpty_test_false(){
    char chars[] = {'a','b','c','d','e','f'};
    CharLinkedList test(chars, 6);
    assert(not test.isEmpty());
}

void size_test_nonzero(){
    char chars[] = {'a','b','c','d','e','f'};
    CharLinkedList test(chars, 6);
    assert(test.size() == 6);
}

void size_test_zero(){
    CharLinkedList a;
    assert(a.size() == 0);
}

void first_test_nonempty(){
    char chars[] = {'a','b','c','d','e','f'};
    CharLinkedList test(chars, 6);
    assert(test.first() == 'a');
}

void first_test_empty(){
    CharLinkedList test;
    bool runtime_error_thrown = false;
    std::string error_message = "";
    try {
        test.first();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot get first of empty LinkedList");
}

void last_test_nonempty(){
    char chars[] = {'a','b','c','d','e','f'};
    CharLinkedList test(chars, 6);
    assert(test.last() == 'f');
}

void last_test_empty(){
    CharLinkedList test;
    bool runtime_error_thrown = false;
    std::string error_message = "";
    try {
        test.last();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot get last of empty LinkedList");
}

void elementAt_test(){
    char chars[] = {'a','b','c'};
    CharLinkedList test(chars, 3);
    assert(test.elementAt(1) == 'b');
}

void elementAt_test_range(){
    CharLinkedList test('a');
    bool range_error_thrown = false;
    std::string error_message = "";
    try {
        test.elementAt(-1);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (-1) not in range [0..1)");
}

void string_test(){
    char chars[] = {'a','b','c','d','e','f'};
    CharLinkedList test(chars, 6);

    assert(test.toString() == "[CharLinkedList of size 6 <<abcdef>>]");
}

void reverse_string_test(){
    char chars[] = {'a','b','c','d','e','f'};
    CharLinkedList test(chars, 6);
    assert(test.toReverseString() == "[CharLinkedList of size 6 <<fedcba>>]");
}

void pushAtBack_test(){
    char chars[] = {'a','b','c','d','e','f'};
    CharLinkedList test(chars, 6);
    test.pushAtBack('g');
    assert(test.toString() == "[CharLinkedList of size 7 <<abcdefg>>]");

}

void pushAtFront_test(){
    char chars[] = {'a','b','c','d','e','f'};
    CharLinkedList test(chars, 6);
    test.pushAtFront('Q');
    assert(test.toString() == "[CharLinkedList of size 7 <<Qabcdef>>]");

}

void insertAt_test(){
    char chars[] = {'a','b','c'};
    CharLinkedList test(chars, 3);
    test.insertAt('Q', 2);
    assert(test.toString() == "[CharLinkedList of size 4 <<abQc>>]");
}

void insertAt_test_front(){
    char chars[] = {'a','b','c'};
    CharLinkedList test(chars, 3);
    test.insertAt('Q', 0);
    assert(test.toString() == "[CharLinkedList of size 4 <<Qabc>>]");
}

void insertAt_test_back(){
    char chars[] = {'a','b','c'};
    CharLinkedList test(chars, 3);
    test.insertAt('Q', 3);
    assert(test.toString() == "[CharLinkedList of size 4 <<abcQ>>]");
}

void insertAt_test_range(){
    char chars[] = {'a','b','c','d','e','f'};
    CharLinkedList test(chars, 6);
    bool range_error_thrown = false;
    std::string error_message = "";
    try {
        test.insertAt('c',10);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (10) not in range [0..6]");
}

void insertInOrder_alpha(){
    char chars[] = {'a','b','c','d','e','f'};
    CharLinkedList test(chars, 6);
    test.insertInOrder('b');
    assert(test.toString() == "[CharLinkedList of size 7 <<abbcdef>>]");
}

void insertInOrder_nonalpha(){
    char chars[] = {'a','b','c','d','e','f'};
    CharLinkedList test(chars, 6);
    test.insertInOrder('!');
    assert(test.toString() == "[CharLinkedList of size 7 <<!abcdef>>]");

}

void insertInOrder_empty(){
    CharLinkedList test;
    test.insertInOrder('G');
    assert(test.toString() == "[CharLinkedList of size 1 <<G>>]");
}

void popFromFront_test(){
    char chars[] = {'a','b','c'};
    CharLinkedList test(chars, 3);

    test.popFromFront();
    assert(test.toString() == "[CharLinkedList of size 2 <<bc>>]");

}

void popFromFront_test_empty(){
    CharLinkedList test;
    bool runtime_error_thrown = false;
    std::string error_message = "";
    try {
        test.popFromFront();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

void popFromBack_test(){
    char chars[] = {'a','b','c'};
    CharLinkedList test(chars, 3);

    test.popFromBack();
    assert(test.toString() == "[CharLinkedList of size 2 <<ab>>]");
}

void popFromBack_test_empty(){
    CharLinkedList test;
    bool runtime_error_thrown = false;
    std::string error_message = "";
    try {
        test.popFromBack();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

void removeAt_test(){
    char chars[] = {'a','b','c'};
    CharLinkedList test(chars, 3);
    test.removeAt(1);
    assert(test.toString() == "[CharLinkedList of size 2 <<ac>>]");
}

void removeAt_test_back(){
    char chars[] = {'a','b','c'};
    CharLinkedList test(chars, 3);
    test.removeAt(2);
    assert(test.toString() == "[CharLinkedList of size 2 <<ab>>]");
}

void removeAt_test_front(){
    char chars[] = {'a','b','c'};
    CharLinkedList test(chars, 3);
    test.removeAt(0);
    assert(test.toString() == "[CharLinkedList of size 2 <<bc>>]");
}

void removeAt_test_empty(){
    CharLinkedList test;
    bool range_error_thrown = false;
    std::string error_message = "";
    try {
        test.removeAt(1);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (1) not in range [0..0)");
}

void removeAt_test_range(){
    char chars[] = {'a','b','c','d','e','f'};
    CharLinkedList test(chars, 6);

    bool range_error_thrown = false;
    std::string error_message = "";
    try {
        test.removeAt(10);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (10) not in range [0..6)");
}

void replaceAt_test(){
    char chars[] = {'a','b','c','d','e','f'};
    CharLinkedList test(chars, 6);

    test.replaceAt('Q',2);

    assert(test.toString() == "[CharLinkedList of size 6 <<abQdef>>]");
}

void replaceAt_test_front(){
    char chars[] = {'a','b','c','d','e','f'};
    CharLinkedList test(chars, 6);

    test.replaceAt('Q',0);

    assert(test.toString() == "[CharLinkedList of size 6 <<Qbcdef>>]");
}

void replaceAt_test_back(){
    char chars[] = {'a','b','c','d','e','f'};
    CharLinkedList test(chars, 6);

    test.replaceAt('Q',5);

    assert(test.toString() == "[CharLinkedList of size 6 <<abcdeQ>>]");
}

void replaceAt_test_range(){
    char chars[] = {'a','b','c','d','e','f'};
    CharLinkedList test(chars, 6);
    
    bool range_error_thrown = false;
    std::string error_message = "";
    try {
        test.replaceAt('c',10);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (10) not in range [0..6)");
}

void concatenate_test(){
    char chars1[] = {'a','b','c','d','e','f'};
    CharLinkedList test1(chars1, 6);
    char chars2[] = {'g','h','i','j','k','l'};
    CharLinkedList test2(chars2, 6);

    test1.concatenate(&test2);
    assert(test1.toString() == "[CharLinkedList of size 12 <<abcdefghijkl>>]");

}

void concatenate_test_empty(){
    char chars1[] = {'a','b','c','d','e','f'};
    CharLinkedList test1(chars1, 6);

    CharLinkedList test3;

    test3.concatenate(&test1);
    assert(test3.toString() == "[CharLinkedList of size 6 <<abcdef>>]");
}
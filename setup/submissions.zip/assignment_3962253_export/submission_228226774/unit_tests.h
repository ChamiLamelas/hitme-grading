/*
 *  unit_tests.h
 *  Jonah Reisner
 *  2/1/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  FILE PURPOSE HERE
 *
 */

/*
 * unit_tests.h
 * Jonah Reisner
 * 
 * Uses Matt Russell's unit_test framework to test the CharLinkedList class.
 *
 * Instructions for using testing framework can be found at in CS 15's lab
 * 1 -- both in the spec and in the provided ArrayList_tests.h and Makefile.
 * More in-depth information for those who are curious as to how it works can
 * be found at http://www.github.com/mattrussell2/unit_test.
 */
#include "CharLinkedList.h"
#include <cassert>

/********************************************************************\
*                       CHAR ARRAY LIST TESTS                        *
\********************************************************************/

/* To give an example of thorough testing, we are providing
 * the unit tests below which test the insertAt function. Notice: we have
 * tried to consider all of the different cases insertAt may be
 * called in, and we test insertAt in conjunction with other functions!
 *
 * You should emulate this approach for all functions you define.
 */


// Tests correct insertion into an empty AL.
// Afterwards, size should be 1 and element at index 0
// should be the element we inserted.
void insertAt_empty_correct() { 

    CharLinkedList test_list;
    test_list.insertAt('a', 0);
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');

}

// // Tests incorrect insertion into an empty AL.
// // Attempts to call insertAt for index larger than 0.
// // This should result in an std::range_error being raised.
void insertAt_empty_incorrect() {

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    // insertAt for out-of-range index
    test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
    // if insertAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    range_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0]");
    
}

// // Tests correct insertAt for front of 1-element list.
void insertAt_front_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at front
    test_list.insertAt('b', 0);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'a');
    
}

// // Tests correct insertAt for back of 1-element list.
void insertAt_back_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at back
    test_list.insertAt('b', 1);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    
}

// // Tests calling insertAt for a large number of elements.
// // Not only does this test insertAt, it also checks that
// // array expansion works correctly.
void insertAt_many_elements() {
    
    CharLinkedList test_list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.insertAt('a', i);
    }

    assert(test_list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
    
}

// // Tests insertion into front of a larger list
void insertAt_front_large_list() {
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    test_list.insertAt('y', 0);

    assert(test_list.size() == 10);
    assert(test_list.elementAt(0) == 'y');
    assert(test_list.toString() == 
        "[CharLinkedList of size 10 <<yabczdefgh>>]");

}

// // Tests insertion into the back of a larger list
void insertAt_back_large_list() {

    char test_arr[10] = { 'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 10);  

    test_list.insertAt('x', 10);

    assert(test_list.size() == 11);
    assert(test_list.elementAt(10) == 'x');
    assert(test_list.toString() == 
    "[CharLinkedList of size 11 <<yabczdefghx>>]"); 

}

// // Tests insertion into the middle of a larger list
void insertAt_middle_large_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.insertAt('z', 3);

    assert(test_list.size() == 9);
    assert(test_list.elementAt(3) == 'z');
    assert(test_list.toString() == "[CharLinkedList of size 9 <<abczdefgh>>]");
}

// Tests out-of-range insertion for a non-empty list.
void insertAt_nonempty_incorrect() {
   
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8]");
    
}

//tests to make sure the constructor with zero arguments works correctly
void basic_constructor(){
    CharLinkedList list();
}

//testing elementAt function for a list with a single element
void element_at_singleChar(){
    char chars[1] = {'a'};
    CharLinkedList list(chars, 1);
    assert(list.elementAt(0) == 'a');
    assert(list.size() == 1);
    assert(list.toString() == "[CharLinkedList of size 1 <<a>>]");
    assert(list.toReverseString() == "[CharLinkedList of size 1 <<a>>]");
}

//just checking all the elements of a list are where they should be
void elementAt_multiChar(){
    char chars[5] = {'a','b','c','d','e'};
    CharLinkedList list(chars, 5);
    assert(list.elementAt(0) == 'a');
    assert(list.elementAt(1) == 'b');
    assert(list.elementAt(2) == 'c');
    assert(list.elementAt(3) == 'd');
    assert(list.elementAt(4) == 'e');
    assert(list.size() == 5);
    assert(list.toString() == "[CharLinkedList of size 5 <<abcde>>]");
    assert(list.toReverseString() == "[CharLinkedList of size 5 <<edcba>>]");
}

//making sure the correct error message is thrown when accessing an element
//out of range more than the number of elements in the list
void element_at_multiChar_out_of_range_more(){
    char chars[5] = {'a','b','c','d','e'};
    CharLinkedList list(chars, 5);
    try{
        list.elementAt(5);
        assert(false);
    }
    catch(const std::range_error &e){
        assert(e.what() == std::string("index (5) not in range [0..5)"));
    }
}

//making sure the correct error message is thrown when accessing an element
//out of range less than 0
void element_at_multiChar_out_of_range_less(){
    char chars[5] = {'a','b','c','d','e'};
    CharLinkedList list(chars, 5);
    try{
        list.elementAt(-1);
        assert(false);
    }
    catch(const std::range_error &e){
        assert(e.what() == std::string("index (-1) not in range [0..5)"));
    }
}

//test adding an element to a list constructed using a char array
void pushAtFront_list_chars(){
    char chars[5] = {'a','b','c','d','e'};
    CharLinkedList list(chars, 5);
    list.pushAtFront('z');
    assert(list.size() == 6);
    assert(list.toString() == "[CharLinkedList of size 6 <<zabcde>>]");
    assert(list.toReverseString() == "[CharLinkedList of size 6 <<edcbaz>>]");
}

//test adding an element to a list constructed using a single char element
void pushAtFront_one_char(){
    CharLinkedList list('a');
    list.pushAtFront('z');
    assert(list.size() == 2);
    assert(list.toString() == "[CharLinkedList of size 2 <<za>>]");
    assert(list.toReverseString() == "[CharLinkedList of size 2 <<az>>]");
}

//text adding an element to an empty list
void pushAtFront_empty_char(){
    CharLinkedList list;
    list.pushAtFront('a');
    assert(list.size() == 1);
    assert(list.toString() == "[CharLinkedList of size 1 <<a>>]");
    assert(list.toReverseString() == "[CharLinkedList of size 1 <<a>>]");
}

//test toString works with an empty list
void toString_empty_char(){
    CharLinkedList list;
    assert(list.size() == 0);
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
    assert(list.toReverseString() == "[CharLinkedList of size 0 <<>>]");
}

//just adds a bunch of elements to a list and make sure it works as expected
void whole_lotta_pushAtFront(){
    CharLinkedList list;
    list.pushAtFront('a');
    list.pushAtFront('b');
    list.pushAtFront('c');
    list.pushAtFront('d');
    list.pushAtFront('e');
    list.pushAtFront('f');
    list.pushAtFront('g');
    list.pushAtFront('h');
    list.pushAtFront('i');
    list.pushAtFront('j');
    list.pushAtFront('k');
    list.pushAtFront('l');
    list.pushAtFront('m');
    list.pushAtFront('n');
    list.pushAtFront('o');
    list.pushAtFront('p');
    list.pushAtFront('q');
    list.pushAtFront('r');
    assert(list.size() == 18);
    assert(list.toReverseString() == 
        "[CharLinkedList of size 18 <<abcdefghijklmnopqr>>]");
    assert(list.toString() ==
        "[CharLinkedList of size 18 <<rqponmlkjihgfedcba>>]");
}

//test  a single pushback on a list constructed using a char array
void single_pushback(){
    char chars[5] = {'a','b','c','d','e'};
    CharLinkedList list(chars, 5);
    list.pushAtBack('z');
    assert(list.size() == 6);
    assert(list.toString() == "[CharLinkedList of size 6 <<abcdez>>]");
    assert(list.toReverseString() == "[CharLinkedList of size 6 <<zedcba>>]");
}

//test  a lotta pushbacks on a list constructed using a char array
void lotta_pushback(){
    char chars[5] = {'a','b','c','d','e'};
    CharLinkedList list(chars, 5);
    list.pushAtBack('f');
    list.pushAtBack('g');
    list.pushAtBack('h');
    list.pushAtBack('i');
    list.pushAtBack('j');
    list.pushAtBack('k');
    list.pushAtBack('l');
    list.pushAtBack('m');
    list.pushAtBack('n');
    list.pushAtBack('o');
    list.pushAtBack('p');
    assert(list.size() == 16);
    assert(list.toString() == 
        "[CharLinkedList of size 16 <<abcdefghijklmnop>>]");
    assert(list.toReverseString() ==
        "[CharLinkedList of size 16 <<ponmlkjihgfedcba>>]");
}

//tests pushAtBack on an empty list
void pushAtBack_empty(){
    CharLinkedList list;
    list.pushAtBack('a');
    assert(list.size() == 1);
    assert(list.toString() == "[CharLinkedList of size 1 <<a>>]");
}

//tests pushAtBack 3 times on an empty list
void pushAtBack_empty3x(){
    CharLinkedList list;
    list.pushAtBack('a');
    list.pushAtBack('b');
    list.pushAtBack('c');
    assert(list.size() == 3);
    assert(list.toString() == "[CharLinkedList of size 3 <<abc>>]");
}
//tests the function first()
void first_simple(){
    char chars[5] = {'a','b','c','d','e'};
    CharLinkedList list(chars, 5);
    assert(list.first() == 'a');
}

//checks to make sure the error is correct when calling first on an empty list
void first_empty_list(){
    CharLinkedList list;
    try{
        list.first();
        assert(false);
    }
    catch(const std::runtime_error &e){
        assert(e.what() == std::string("cannot get first of empty LinkedList"));
    }
}

//tests the function last()
void last_simple(){
    char chars[5] = {'a','b','c','d','e'};
    CharLinkedList list(chars, 5);
    assert(list.last() == 'e');
}

//checks to make sure the error is correct when calling last on an empty list
void last_empty_list(){
    CharLinkedList list;
    try{
        list.last();
        assert(false);
    }
    catch(const std::runtime_error &e){
        assert(e.what() == std::string("cannot get last of empty LinkedList"));
    }
}

//tests that clear works on an empty list
void clear_empty_list(){
    CharLinkedList list;
    list.clear();
    assert(list.size() == 0);
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}

//tests that clear works on a list with elements in it
void clear_full_list(){
    char chars[5] = {'a','b','c','d','e'};
    CharLinkedList list(chars, 5);
    list.clear();
    assert(list.size() == 0);
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}

//makes sure is_empty works when the list has/doesn't have elements
void is_empty(){
    char chars[5] = {'a','b','c','d','e'};
    CharLinkedList list(chars, 5);
    assert(not list.isEmpty());
    list.clear();
    assert(list.isEmpty());
}

//tests that popFromFront works with elements in the list
void popFromFront_one_char(){
    CharLinkedList list;
    list.pushAtBack('a');
    list.popFromFront();
    assert(list.isEmpty());
}

//tests that popFromFront works with one element in the list
void popFromFront_full(){
    char chars[5] = {'a','b','c','d','e'};
    CharLinkedList list(chars, 5);
    list.popFromFront();
    assert(list.size() == 4);
    assert(list.toString() == "[CharLinkedList of size 4 <<bcde>>]");
}

//tests that popFromFront throws the correct expection when called on empty list
void popFromFront_empty(){
    CharLinkedList list;
    try{
        list.popFromFront();
        assert(false);
    }
    catch(const std::runtime_error &e){
        assert(e.what() == std::string("cannot pop from empty LinkedList"));
    }
}

//tests removeAt with one char in list
void removeAt_one_char(){
    char chars[1] = {'a'};
    CharLinkedList list(chars, 1);
    list.removeAt(0);
    assert(list.isEmpty());
}

//tests that removeAt throws the correct expection when called on empty list
void removeAt_empty(){
    CharLinkedList list;
    try{
        list.removeAt(1);
        assert(false);
    }
    catch(const std::range_error &e){
        assert(e.what() == std::string("index (1) not in range [0..0)"));
    }
}

//removes 2 elements from a big list
void removeAt_lotta_elements(){
    char chars[14] = {'a','b','c','d','e','f','g','h','i','j','k','l','m','n'};
    CharLinkedList list(chars, 14);
    list.removeAt(0);
    list.removeAt(4);
    assert(list.toString() == 
        "[CharLinkedList of size 12 <<bcdeghijklmn>>]");
    assert(list.toReverseString() ==
        "[CharLinkedList of size 12 <<nmlkjihgedcb>>]");
}

//tests insertInOrder the front of large list
void insertInOrder_front_large(){
    char chars[14] = {'a','b','c','d','e','f','g','h','i','j','k','l','m','n'};
    CharLinkedList list(chars, 14);
    list.insertInOrder('a');
    assert(list.toString() == 
        "[CharLinkedList of size 15 <<aabcdefghijklmn>>]");
}

//tests insertInOrder on empty list
void insertInOrder_empty(){
    CharLinkedList list;
    list.insertInOrder('z');
    assert(list.toString() == 
        "[CharLinkedList of size 1 <<z>>]");
}

//test custom equal operator with an empty list
void equal_operator_empty(){
    CharLinkedList list_to_be_copied;
    CharLinkedList list(list_to_be_copied);
}

//test custom equal operator on a list created with a single char constuctor
void equal_operator_single_char(){
    CharLinkedList list_to_be_copied('a');
    CharLinkedList list(list_to_be_copied);
    assert(list.toString() == list_to_be_copied.toString());
}

//test custom equal operator on a list created with a char array constuctor
void equal_operator_char_array(){
    char chars[14] = {'a','b','c','d','e','f','g','h','i','j','k','l','m','n'};
    CharLinkedList list_to_be_copied(chars, 14);
    CharLinkedList list(list_to_be_copied);
    assert(list.toString() == list_to_be_copied.toString());
}

//test custom equal operator on a list created with a char array constuctor
//plus a couple of insertionInOrder function calls on the array to be copied
void equal_operator_char_array_with_insertInOrder(){
    char chars[14] = {'a','b','c','d','e','f','g','h','i','j','k','l','m','n'};
    CharLinkedList list_to_be_copied(chars, 14);
    list_to_be_copied.insertInOrder('z');
    list_to_be_copied.insertInOrder('g');
    list_to_be_copied.insertInOrder('a');
    list_to_be_copied.insertInOrder('z');
    CharLinkedList list(list_to_be_copied);
    assert(list.toString() == list_to_be_copied.toString());
    assert(list.toString() == 
        "[CharLinkedList of size 18 <<aabcdefgghijklmnzz>>]");
}

//tests multiple out of order insertInOrder function calls on a big list
void insertInOrder_lotta_out_of_order_inserts(){
    char chars[14] = {'a','b','c','d','e','f','g','h','i','j','k','l','m','n'};
    CharLinkedList list(chars, 14);
    list.insertInOrder('z');
    list.insertInOrder('g');
    list.insertInOrder('a');
    list.insertInOrder('z');
    assert(list.toString() == 
        "[CharLinkedList of size 18 <<aabcdefgghijklmnzz>>]");
}

//tests the constructor that takes a reference to another arrayList that's empty
void another_arrayList_reference_constructor_empty(){
    CharLinkedList list_to_copy;
    CharLinkedList list(list_to_copy);
    assert(list_to_copy.toString() == list.toString());
}

//tests the constructor that takes a reference to another arrayList that's
//initialized with one char
void another_arrayList_reference_constructor_one_char(){
    CharLinkedList list_to_copy('a');
    CharLinkedList list(list_to_copy);
    assert(list_to_copy.toString() == list.toString());
}

//tests the constructor that takes a reference to another arrayList that's
//initialized with a char array
void another_arrayList_reference_constructor_char_list(){
    char chars[14] = {'a','b','c','d','e','f','g','h','i','j','k','l','m','n'};
    CharLinkedList list_to_copy(chars, 14);
    CharLinkedList list(list_to_copy);
    assert(list_to_copy.toString() == list.toString());
}

//tests that an empty list concatenates with an empty list
void concatenate_empty_with_empty(){
    CharLinkedList list_to_copy;
    CharLinkedList list;
    list.concatenate(&list_to_copy);
    assert(list.isEmpty());
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}

//tests that an empty list concatenates with an single char list
void concatenate_empty_with_single_char(){
    CharLinkedList list_to_copy('a');
    CharLinkedList list;
    list.concatenate(&list_to_copy);
    assert(list.toString() == "[CharLinkedList of size 1 <<a>>]");
}

//tests that an empty list concatenates with an big list
void concatenate_empty_with_char_array(){
    char chars[8] = {'C','H','E','S','H','I','R','E'};
    CharLinkedList list_to_copy(chars, 8);
    CharLinkedList list;
    list.concatenate(&list_to_copy);
    assert(list.toString() == "[CharLinkedList of size 8 <<CHESHIRE>>]");
}

//tests that a single element list concatenates with an empty list
void concatenate_single_with_char_empty(){
    CharLinkedList list_to_copy;
    CharLinkedList list('a');
    list.concatenate(&list_to_copy);
    assert(list.toString() == "[CharLinkedList of size 1 <<a>>]");
}

//tests that a single element list concatenates with an single element list
void concatenate_single_with_single_char(){
    CharLinkedList list_to_copy('b');
    CharLinkedList list('a');
    list.concatenate(&list_to_copy);
    assert(list.toString() == "[CharLinkedList of size 2 <<ab>>]");
}

//tests that a single element list concatenates with a big list
void concatenate_single_with_char_array(){
    char chars[8] = {'C','H','E','S','H','I','R','E'};
    CharLinkedList list_to_copy(chars, 8);
    CharLinkedList list('a');
    list.concatenate(&list_to_copy);
    assert(list.toString() == "[CharLinkedList of size 9 <<aCHESHIRE>>]");
}

//tests that a 3 element list concatenates with an empty list
void concatenate_array_with_char_empty(){
    char list_char[3] = {'c','a','t'};
    CharLinkedList list_to_copy;
    CharLinkedList list(list_char, 3);
    list.concatenate(&list_to_copy);
    assert(list.toString() == "[CharLinkedList of size 3 <<cat>>]");
}

//tests that a 3 element list concatenates with an single element list
void concatenate_array_with_single_char(){
    char list_char[3] = {'c','a','t'};
    CharLinkedList list_to_copy('b');
    CharLinkedList list(list_char, 3);
    list.concatenate(&list_to_copy);
    assert(list.toString() == "[CharLinkedList of size 4 <<catb>>]");
}

//tests that a 3 element list concatenates with a large list
void concatenate_array_with_char_array(){
    char list_char[3] = {'c','a','t'};
    char chars[8] = {'C','H','E','S','H','I','R','E'};
    CharLinkedList list_to_copy(chars, 8);
    CharLinkedList list(list_char, 3);
    list.concatenate(&list_to_copy);
    assert(list.toString() == "[CharLinkedList of size 11 <<catCHESHIRE>>]");
}

//concatenates a list of size 3 with itself
void concatenate_non_emtpy_with_itself(){
    char list_char[3] = {'c','a','t'};
    CharLinkedList list(list_char, 3);
    list.concatenate(&list);
    assert(list.toString() == "[CharLinkedList of size 6 <<catcat>>]");
}


//testing the single char constructor
void one_char_constructor(){
    CharLinkedList list('a');
    assert(list.size() == 1);
    assert(list.toString() == "[CharLinkedList of size 1 <<a>>]");
}

//testing the char array constructor
void list_constructor(){
    char chars[3] = {'a','b','c'};
    CharLinkedList list(chars, 3);
    assert(list.size() == 3);
    assert(list.toString() == "[CharLinkedList of size 3 <<abc>>]");
    assert(list.toReverseString() == "[CharLinkedList of size 3 <<cba>>]");
}

//tests the removeAtLastNode helper function by removing the last element
void removeAtLastNode(){
    char chars[5] = {'a','b','c','d','e'};
    CharLinkedList list(chars, 5);
    list.removeAt(4);
    assert(list.size() == 4);
    assert(list.toString() == "[CharLinkedList of size 4 <<abcd>>]");
}

//tests the removeAtLastNode helper function by removing the last element
void removeAtFirstNode(){
    char chars[5] = {'a','b','c','d','e'};
    CharLinkedList list(chars, 5);
    list.removeAt(0);
    assert(list.size() == 4);
    assert(list.toString() == "[CharLinkedList of size 4 <<bcde>>]");
}

//tests the removeAtFirstNode helper function by removing the first element
//then makes sure pushAtFront still works with the now empty list
void removeAtFirstNode_thenPushAtFront(){
    char chars[5] = {'a','b','c','d','e'};
    CharLinkedList list(chars, 5);
    list.removeAt(0);
    list.pushAtFront('a');
    assert(list.size() == 5);
    assert(list.toString() == "[CharLinkedList of size 5 <<abcde>>]");
}

//tests the removeAtOnlyNode helper function by removing the only element of
//a list
void removeAtOnlytNode(){
    CharLinkedList list('a');
    list.removeAt(0);
    assert(list.size() == 0);
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}

//tests the removeAtMiddleNode helper function by removing an element
//with elements both ahead and behind it
void removeAtMiddleNode(){
    char chars[5] = {'a','b','c','d','e'};
    CharLinkedList list(chars, 5);
    list.removeAt(2);
    assert(list.size() == 4);
    assert(list.toString() == "[CharLinkedList of size 4 <<abde>>]");
}

/*
 * Because replaceAt really just calls the nodeAt helper function, the following
 * replaceAt unit tests assure that both replaceAt and nodeAt function as
 * intended
 */

//tests replaceAt by replacing the first element of a list
void replaceAt_first(){
    char chars[5] = {'a','b','c','d','e'};
    CharLinkedList list(chars, 5);
    list.replaceAt('z', 0);
    assert(list.size() == 5);
    assert(list.toString() == "[CharLinkedList of size 5 <<zbcde>>]");
}

//tests replaceAt by replacing the last element of a list
void replaceAt_last(){
    char chars[5] = {'a','b','c','d','e'};
    CharLinkedList list(chars, 5);
    list.replaceAt('z', 4);
    assert(list.size() == 5);
    assert(list.toString() == "[CharLinkedList of size 5 <<abcdz>>]");
}

//tests replaceAt by replacing a middle element of a list
void replaceAt_middle(){
    char chars[5] = {'a','b','c','d','e'};
    CharLinkedList list(chars, 5);
    list.replaceAt('z', 2);
    assert(list.size() == 5);
    assert(list.toString() == "[CharLinkedList of size 5 <<abzde>>]");
}

//tests replaceAt by replacing the only element of a list
void replaceAt_only(){
    char chars[1] = {'a'};
    CharLinkedList list(chars, 1);
    list.replaceAt('z', 0);
    assert(list.size() == 1);
    assert(list.toString() == "[CharLinkedList of size 1 <<z>>]");
}
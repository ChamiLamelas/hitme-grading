/*
 *  CharLinkedList.cpp
 *  Jonah Reisner
 *  2/1/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Implements the CharLinkedList class functions
 *
 */

#include "CharLinkedList.h"

/*
 * name:      CharLinkedList
 * purpose:   construct an empty CharLinkedList
 * arguments: none
 * returns:   none
 * effects:   none
 */
CharLinkedList::CharLinkedList() {
    numItems = 0;
    front = nullptr;
    back = nullptr;
}

/*
 * name:      CharLinkedList
 * purpose:   construct a  CharLinkedList with one character
 * arguments: a character that will be the lone first element of the LinkedList
 * returns:   none
 * effects:   none
 */
CharLinkedList::CharLinkedList(char c) {
    numItems = 0;
    pushAtFront(c);
}

/*
 * name:      CharLinkedList
 * purpose:   construct a CharLinkedList for characters from a given input array
 * arguments: an array of chars that will be the first elements of the new
 * linked list, and an integer corresponding to the size of that array.
 * returns:   none
 * effects:   none
 */
CharLinkedList::CharLinkedList(char arr[], int size) {
    //numItems is incremented in the pushAtFront function
    numItems = 0;
    for (int i = 0; i < size; i++){
        pushAtFront(arr[size - i - 1]); //we have to add the elements starting
        //from the back of arr which is why the arr indexing looks a little odd
    } 
}

/*
 * name:      CharLinkedList
 * purpose:   construct a CharLinkedList, copying all the elements
 * of an input CharLinkedList
 * arguments: the address of another CharLinkedList
 * returns:   none
 * effects:   none
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other) {
    numItems = 0;
    //just copies over every element from other to this intance by value
    for (int i = 0; i < other.size(); i++){
        pushAtBack(other.elementAt(i));
    } 
}

/*
 * name:      ~CharLinkedList
 * purpose:   A destructor for the CharLinkedList object
 * arguments: none
 * returns:   none
 * effects:   Frees all heap memory allocated for the given CharLinkedList
 */
CharLinkedList::~CharLinkedList() {
    if (numItems > 0)
        destructorHelper(front);
}

/*
 * name:      destructorHelper
 * purpose:   A recursive destructor for the CharLinkedList object
 * arguments: none
 * returns:   none
 * effects:   Frees all heap memory allocated for the given CharLinkedList
 */
void CharLinkedList::destructorHelper(Node* currNode) {
    if(currNode->next != nullptr){
        destructorHelper(currNode->next);
    }
    delete currNode;
}

/*
 * name:      operator=
 * purpose:   Defines an assignment operator for the class. Makes a deep 
 * copy of the instance of the CharLinkedList on the right side of an "=" 
 * operator. The instance of CharLinkedList on the left side of the "="
 * operator becomes the deep copy, and it is that instance that actually
 * calls this function.
 * arguments: A constant reference to a CharLinkedList instance which a
 * deep copy is made from.
 * returns:   A reference to itself
 * effects:   any previous values associated with this instance are lost
 */
CharLinkedList& CharLinkedList::operator=(const CharLinkedList &other) {
    numItems = 0;
    for (int i = 0; i < other.size(); i++){
        pushAtBack(other.elementAt(i));
    }
    return *this;
}

/*
 * name:      isEmpty
 * purpose:   See returns below
 * arguments: none
 * returns:   A boolean value that is true if the calling instance has no 
 * characters and false otherwise
 * effects:   none
 */
bool CharLinkedList::isEmpty() const {
    return numItems == 0;
}

/*
 * name:      clear
 * purpose:   Makes the instance into an empty linked list, freeing all memory
 * in the process
 * arguments: none
 * returns:   none
 * effects:   Any values previously stored in the instance are lost
 */
void CharLinkedList::clear() {
    //essentially a constructor + freeing memory
    if(numItems > 0)
        destructorHelper(front);
    numItems = 0;
}

/*
 * name:      size
 * purpose:   see returns below
 * arguments: none
 * returns:   integer value corresponding to the number of elements in the list
 * effects:   none
 */
int CharLinkedList::size() const {
    return numItems;
}

/*
 * name:      first
 * purpose:   see returns below
 * arguments: none
 * returns:   the character value corresponding to the first element in the list
 * effects:   none
 */
char CharLinkedList::first() const {
    if(numItems == 0)
        throw std::runtime_error("cannot get first of empty LinkedList");
    return front->character;
}

/*
 * name:      last
 * purpose:   see returns below
 * arguments: none
 * returns:   the character value that is the last element in the list
 * effects:   none
 */
char CharLinkedList::last() const {
    if(numItems == 0)
        throw std::runtime_error("cannot get last of empty LinkedList");
    return back->character;
}

/*
 * name:      elementAt
 * purpose:   see returns below
 * arguments: an integer of a requested index position
 * returns:   the character value that is at the requested index
 * effects:   none
 */
char CharLinkedList::elementAt(int index) const {
    if(index < 0 or index >= numItems)
        throw std::range_error("index (" + std::to_string(index) + 
        ") not in range [0.." + std::to_string(numItems) + ")");
    return nodeAt(front, 0, index)->character;
}

/*
 * name:      nodeAt
 * purpose:   a recursive helper function to aid in retrieving node information
 * at a desired index in the list
 * arguments: a pointer to the first node we want to check. We almost always 
 * want to pass the pointer "front" to it, an integer that should always
 * be 0, and an integer of the requested index position
 * returns:   a pointer to the node at "goalIndex"
 * effects:   none
 */
CharLinkedList::Node 
    *CharLinkedList::nodeAt(Node *currNode, int index, int goalIndex) const {
    //return currNode if it is at the index we want
    if(index == goalIndex){
        return currNode;
    }
    //if we're not at the goalIndex then we look at the next node and repeat
    return nodeAt(currNode->next, index + 1, goalIndex);
}


/*
 * name:      toString
 * purpose:   see returns below
 * arguments: none
 * returns:   a string which contains the characters of the 
 * instance in the form [CharLinkedList of size 5 <<Alice>>]
 * effects:   none
 */
std::string CharLinkedList::toString() const {
    //message is used to build the string being returned
    std::string message("[CharLinkedList of size ");
    message.append(std::to_string(numItems));
    message.append(" <<");

    Node *currNode = front;
    for (int i = 0; i < numItems; i++){
        message.append(1, currNode->character);
        currNode = currNode->next;
    }
    message.append(">>]");
    return message;
}

/*
 * name:      toReverseString
 * purpose:   see returns below
 * arguments: none
 * returns:   a string which contains the characters of the 
 * instance in the reverse order they are stored. It will be 
 * in the form of [CharLinkedList of size 5 <<ecilA>>]
 * effects:   none
 */
std::string CharLinkedList::toReverseString() const {
    //message is used to build the string being returned
    std::string message("[CharLinkedList of size ");
    message.append(std::to_string(numItems));
    message.append(" <<");

    Node *currNode = back;
    for (int i = 0; i < numItems; i++){
        message.append(1, currNode->character);
        currNode = currNode->behind;
    }
    message.append(">>]");
    return message;
}

/*
 * name:      pushAtBack
 * purpose:   takes a char argument and appends it to the end
 * of the instance's linked list of char elements
 * arguments: a character to be appended
 * returns:   none
 * effects:   the instance's size is incremented by one
 */
void CharLinkedList::pushAtBack(char c) {
    //creating the new Node
    Node *node = new Node;
    node->character = c;
    node->behind = nullptr;
    node->next = nullptr;

    if (numItems > 0){
        node->behind = back;
        back->next = node;
    }
    else{
        front = node;
    }

    back = node;
    numItems++; 
}

/*
 * name:      pushAtFront
 * purpose:   takes a char argument and appends it to the front
 * of the instance's linked list of char elements
 * arguments: a character to be appended
 * returns:   none
 * effects:   the instance's size is incremented by one
 */
void CharLinkedList::pushAtFront(char c) {
    //creating the new Node
    Node *node = new Node;
    node->character = c;
    node->behind = nullptr;
    node->next = nullptr;

    if (numItems > 0){
        node->next = front;
        front->behind = node;
    }
    else{
        back = node;
    }

    front = node;
    numItems++; 
}

/*
 * name:      insertAt
 * purpose:   takes a char argument and inserts it in the instance's
 * linked list of char elements at the specified index
 * arguments: a character to be inserted, and an int of where to insert
 * returns:   none
 * effects:   the instance's size is incremented by one
 */
void CharLinkedList::insertAt(char c, int index) {
    if (index < 0 or index > numItems){
        throw std::range_error("index (" + std::to_string(index) + ")" 
        + " not in range [0.." + std::to_string(numItems) + "]");
    }
    //if else statements to determine how to add the element
    if (index == 0){
        pushAtFront(c);
    }
    else if(index == numItems){
        pushAtBack(c);
    }
    else{
        //creating the new Node
        Node *node = new Node;
        node->character = c;
        node->behind = nullptr;
        node->next = nullptr;

        //reworking how the nodes on either side of the new node are connected
        //to one another
        Node *nodeAtIndex = nodeAt(front, 0, index);
        nodeAtIndex->behind->next = node;
        node->behind = nodeAtIndex->behind;
        node->next = nodeAtIndex;
        nodeAtIndex->behind = node;

        numItems++;
    }
}

/*
 * name:      insertInOrder
 * purpose:   takes a char argument and inserts it in ascending
 * alphabetical order assuming the list is already sorted
 * arguments: a character to be inserted
 * returns:   none
 * effects:   the instance's size is incremented by one
 */
void CharLinkedList::insertInOrder(char c) {
    //inserts c in 0th index if list is empty
    if (numItems == 0){
        pushAtFront(c);
    }
    //otherwise will comb through arr looking for where to insert
    else{
        bool still_comparing = true;
        int index = 0;
        //stops looking if an insert place is found or index exceeds size
        while(still_comparing and index < numItems){
            if(c <= elementAt(index)){
                insertAt(c, index); //numItems gets incremented in this function
                still_comparing = false;
            }
            index++;
        }
        //if c was not inserted we add it to the back of the linked list
        if(still_comparing){
            pushAtBack(c); //numItems gets incremented in this function
        }
    }
}

/*
 * name:      popFromFront
 * purpose:   removes the first element from the linked list
 * arguments: none
 * returns:   none
 * effects:   the instance's size is decremented by one, former first element is
 * lost
 */
void CharLinkedList::popFromFront() {
    if(numItems == 0)
        throw std::runtime_error("cannot pop from empty LinkedList");
    removeAt(0);
}

/*
 * name:      popFromBack
 * purpose:   removes the last element from the linked list
 * arguments: none
 * returns:   none
 * effects:   the instance's size is decremented by one, last element is lost
 */
void CharLinkedList::popFromBack() {
    if(numItems == 0)
        throw std::runtime_error("cannot pop from empty LinkedList");
    removeAt(numItems - 1);
}

/*
 * name:      removeAt
 * purpose:   removes an element at a given index
 * arguments: an integer value that represents the index of an element that will
 * be removed from the list
 * returns:   none
 * effects:   the instance's size is decremented by one, the removed element 
 * is lost
 */
void CharLinkedList::removeAt(int index) {
    //throws an error if trying to remove an element that doesn't exist
    if(index < 0 or index >= numItems)
        throw std::range_error("index (" + std::to_string(index) + 
        ") not in range [0.." + std::to_string(numItems) + ")");
    
    //if else tree to determine which removeAt helper to call
    if (index == 0 and numItems != 1){
        removeAtFirstNode();
    }
    else if (index == (numItems - 1) and numItems != 1){
        removeAtLastNode();
    }
    else if (index == 0 and numItems == 1){
        removeAtOnlyNode();
    }
    else if (numItems > 0){
        removeAtMiddleNode(index);
    }

    
}

/*
 * name:      removeAtLastNode
 * purpose:   removes the last element in the instance's linked list
 * arguments: none
 * returns:   none
 * effects:   the instance's size is decremented by one, the removed element 
 * is lost
 */
void CharLinkedList::removeAtLastNode() {
    back = back->behind;
    delete back->next;
    back->next = nullptr;
    numItems--;
    
}

/*
 * name:      removeAtFirstNode
 * purpose:   removes the first element in the instance's linked list
 * arguments: none
 * returns:   none
 * effects:   the instance's size is decremented by one, the removed element 
 * is lost
 */
void CharLinkedList::removeAtFirstNode() {
    front = front->next;
    delete front->behind;
    front->behind = nullptr;
    numItems--;
}

/*
 * name:      removeAtOnlyNode
 * purpose:   removes the sole element in the instance's linked list of size 1
 * arguments: none
 * returns:   none
 * effects:   the instance's size is decremented by one, the removed element 
 * is lost
 */
void CharLinkedList::removeAtOnlyNode() {
    delete front;
    front = nullptr;
    back = nullptr;
    numItems--;
}

/*
 * name:      removeAtLastNode
 * purpose:   removes any node with a node both infront of and behind it
 * arguments: none
 * returns:   none
 * effects:   the instance's size is decremented by one, the removed element 
 * is lost
 */
void CharLinkedList::removeAtMiddleNode(int index) {
    Node *removingNode = nodeAt(front, 0, index);
    removingNode->next->behind = removingNode->behind;
    removingNode->behind->next = removingNode->next;
    delete removingNode;
    numItems--;
}


/*
 * name:      replaceAt
 * purpose:   replaces one element with another at a given
 * index
 * arguments: a character that's replacing the element at 
 * the position index
 * returns:   none
 * effects:   the former element at positon "index" is lost
 */
void CharLinkedList::replaceAt(char c, int index) {
    if(index < 0 or index >= numItems)
        throw std::range_error("index (" + std::to_string(index) + 
        ") not in range [0.." + std::to_string(numItems) + ")");
    nodeAt(front, 0, index)->character = c;
}

/*
 * name:      concatenate
 * purpose:   adds each element from an input CharLinkedList
 * instance at the back of the current instances list
 * arguments: a pointer to another CharLinkedList instance
 * returns:   none
 * effects:   the instance's size is incremented by the size of the input 
 * CharLinkedList
 */
void CharLinkedList::concatenate(CharLinkedList *other) {
    int copyAmount = other->size();
    for (int i = 0; i < copyAmount; i++){
        //*note: numItems gets incremented in pushAtBack
        pushAtBack(other->elementAt(i)); 
    }
}
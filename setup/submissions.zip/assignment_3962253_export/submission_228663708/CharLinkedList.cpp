/*
 *  CharLinkedList.cpp
 *  Peter Morganelli
 *  2/1/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  .cpp file for CharLinkedList.h
 *
 */

#include "CharLinkedList.h"
#include <iostream>
using namespace std;

/*
 * name:      CharLinkedList
 * purpose:   Default constructor for an empty CharLinkedList
 * arguments: None
 * returns:   None
 * effects:   Edits the private variables with zero/nullptr values
 */
CharLinkedList::CharLinkedList(){
    numElements = 0;
    front = nullptr;
    back = nullptr;
}

/*
 * name:      CharLinkedList(char c)
 * purpose:   Constructor for a Doubly Linked List of one element
 * arguments: char c
 * returns:   None
 * effects:   Populates a CharLinkedList with one element, creates a node
 *            with that info, assigns both front and back pointers to the 
 *            singular node, and assigns next and previous pointers to nullptr
 *            
 */
CharLinkedList::CharLinkedList(char c){
    numElements = 1;
    Node *newNode = new Node;

    newNode->info = c;
    newNode->next = nullptr;
    newNode->previous = nullptr;

    //in our singleton list, the node is both the front and the back
    front = newNode;
    back = newNode;
}

/*
 * name:      CharLinkedist
 * purpose:   Constructor for a Linked List of multiple elements
 * arguments: a character array and the size of that array
 * returns:   None
 * effects:   sets front and back pointers to nullptr and calls pushAtBack to 
 *            add each element to the linkedlist
 */
CharLinkedList::CharLinkedList(char arr[], int size){
    numElements = 0;
    front = nullptr;
    back = nullptr;
    for(int i = 0; i < size; i++){
        pushAtBack(arr[i]);
    }
}

//CharLinkedList copy constructor
CharLinkedList::CharLinkedList(const CharLinkedList &other){
    numElements = 0;
    front = nullptr;
    back = nullptr;
    for(int i = 0; i < other.numElements; i++) {
        pushAtBack(other.elementAt(i));
    }
}

//CharLinkedList destructor that calls a private recursive function
CharLinkedList::~CharLinkedList(){
   deleteList(front);
}

//CharLinkedList assignment operator
CharLinkedList& CharLinkedList::operator=(const CharLinkedList &other){
    numElements = other.numElements;
    if(this == &other){
        return *this;
    }
    clear();
    front = nullptr;
    back = nullptr;
    for(int i = 0; i < other.numElements; i++){
        pushAtBack(other.elementAt(i));
    }
        return *this;
}

/*
 * name:      isEmpty
 * purpose:   checks to see if a CharLinkedList is empty or not
 * arguments: none
 * returns:   a boolean
 * effects:   none
 */
bool CharLinkedList::isEmpty() const{
    return numElements == 0;
}

/*
 * name:      clear
 * purpose:   reset the array variables so that isEmpty() will return true
 * arguments: none
 * returns:   none
 * effects:   sets numElements equal to zero and DELETES all nodes
 *            *important to not double free*
 */
void CharLinkedList::clear(){
    if(front == nullptr){
        return;
    }
    deleteList(front);
    front = nullptr;
    back = nullptr;
    numElements = 0;
    //the destructor will be called automatically after
}

/*
 * name:      size
 * purpose:   a getter function for the size of the CharLinkedList
 * arguments: none
 * returns:   an int
 * effects:   returns how many elements/nodes are in the linked list
 */
int CharLinkedList::size() const{
    return numElements;
}

/*
 * name:      first
 * purpose:   gets the first element of the array if it exists using front ptr
 * arguments: none
 * returns:   a the info at the first node in the linked list
 * effects:   throws an error if the array is empty
 */
char CharLinkedList::first() const{
    if (numElements == 0){
        throw std::runtime_error("cannot get first of empty LinkedList");
    }
    return front->info;
}

/*
 * name:      last
 * purpose:   to retrieve the last element in the CharLinkedList pointed to
 *            by the back pointer
 * arguments: none
 * returns:   the last element in the CharLinkedList
 * effects:   raises and error if the CharLinkedList is empty
 */
char CharLinkedList::last() const{
    if (numElements == 0){
       throw std::runtime_error("cannot get last of empty LinkedList");
    }
    return back->info;
}

/*
 * name:      elementAt
 * purpose:   get the CharLinkedList element at a given index
 * arguments: an int index
 * returns:   the char element at int idex
 * effects:   Raises an error if idx is out-of-bounds of the linked list
 */
char CharLinkedList::elementAt(int index) const{
    //check to see if index is a valid index
    string errorMessage = "index (" + std::to_string(index) + ") not in range " 
    + "[0.." + std::to_string(numElements) + ")";

    if(index < 0 or index > numElements){
       throw std::range_error(errorMessage);
    }
    if(index == 0){
        return first();
    }
    return (findElementAt(index, front))->info;
}

/*
 * name:      toString
 * purpose:   to make the CharLinkedList into a string
 * arguments: none
 * returns:   a string which contains the characters of the CharLinkedList 
 * effects:   none
 */
std::string CharLinkedList::toString() const{
    string completedWord = "[CharLinkedList of size " + 
    std::to_string(numElements) + " <<";
    string word;
    Node *curr = front;
    while(curr != nullptr){
        word += curr->info;
        curr = curr->next;
    }
    completedWord += word + ">>]";
    return completedWord;
}

/*
 * name:      toReverseString
 * purpose:   to print out the characters of CharLinkedList in reverse
 *            aka to reverse a doubly linked list!
 * arguments: none
 * returns:   a string of characters in the linked list in reverse order
 * effects:   none
 */
std::string CharLinkedList::toReverseString() const{
    //same exact thing as toString, except starting at the back instead 
    //of the front
    string completedWord = "[CharLinkedList of size " +
    std::to_string(numElements) + " <<";
    string word;
    Node *curr = back;
    while(curr != nullptr){
        word += curr->info;
        curr = curr->previous;
    }
    completedWord += word + ">>]";
    return completedWord;
}

/*
 * name:      pushAtBack
 * purpose:   to add a Node at the back of the CharLinkedList
 * arguments: a character that should be put into the new Node that is added
 * returns:   none
 * effects:   increments numElements and reassigns back pointer
 *            (and front pointer if it is nullptr)
 */
void CharLinkedList::pushAtBack(char c){
    //make a new node and populate it with the info of c
    Node *newNode = new Node;
    newNode->info = c;
    newNode->next = nullptr;
    newNode->previous = nullptr;

    if(front == nullptr){
        front = newNode;
        back = newNode;
    }
    else {
        newNode->previous = back; 
        back->next = newNode;
        back = newNode;
    }
   numElements++;
}

/*
 * name:      pushAtFront
 * purpose:   to put a new Node with char c at the front of the CharLinkedList
 * arguments: a character that should be put at the first index of linked list
 * returns:   none
 * effects:   increments numElements and reassigns front pointer
 */
void CharLinkedList::pushAtFront(char c){
    //make new node with char c
    Node *newNode = new Node;
    newNode->info = c;
    newNode->previous = nullptr;
    newNode->next = nullptr;

    if(front == nullptr){
        front = newNode;
        back = newNode;
    } 
    else {
        newNode->next = front;
        front->previous = newNode;
        front = newNode;
    }
    numElements++;
}

/*
 * name:      insertAt
 * purpose:   to insert a given character at a given index in the linked list
 * arguments: a char c to be inserted at int index
 * returns:   none
 * effects:   increments numElements, reassigns previous and next pointers
 *            of edge nodes
 */
void CharLinkedList::insertAt(char c, int index){
    string errorMessage = "index (" + std::to_string(index) + ") not in range " 
    + "[0.." + std::to_string(numElements) + "]";
    if(index < 0 or index > numElements){
       throw std::range_error(errorMessage);
    }
    //create the new node and populate the info
    Node *newNode = new Node;
    newNode->info = c;
    if(index == 0){
        pushAtFront(c);
        delete newNode;
    }
    //insert it at the proper index
    if((index > 0) and (index < numElements)){
        Node* correctNode = findElementAt(index, front);
        newNode->next = correctNode;
        newNode->previous = correctNode->previous;
        correctNode->previous->next = newNode;
        correctNode->previous = newNode;
        numElements++;
    }
    if(index == numElements){
       pushAtBack(newNode->info);
       delete newNode;  
    }
}

/*
 * name:      insertInOrder
 * purpose:   insert a Node with char c into the linked list at its correct 
 *            spot such that the CharLinkedList is in ascending ASCII order
 * arguments: char c
 * returns:   none
 * effects:   inserts an element according to its ASCII value in the list
 *            also increments numElements and reassigns next and previous ptrs
 */
void CharLinkedList::insertInOrder(char c){

    Node *curr = front;
    int index = 0;
    while(curr != nullptr){
        if(c < curr->info){
            insertAt(c, index);
            return;
        }
        index++;
        curr = curr->next;
    }
    insertAt(c, numElements);
}


/*
 * name:      popFromFront
 * purpose:   to remove the first element in the CharLinkedList by calling
 *            removeAt()
 * arguments: none
 * returns:   none
 * effects:   returns an error message if the CharLinkedList is empty
 *            numElements should decrement from the removeAt call
 *            reassigns front pointer     
 */
void CharLinkedList::popFromFront(){
    string errorMessage = "cannot pop from empty LinkedList";   
    if(numElements == 0){
        throw std::runtime_error(errorMessage);
    }
    removeAt(0);
}

/*
 * name:      popFromBack
 * purpose:   to remove the last element in the CharLinkedList using
 *            removeAt()
 * arguments: none
 * returns:   none
 * effects:   returns an error message if the CharLinkedList is empty,
 *            numElements should decrement from the removeAt call
 *            also reassigns back pointer
 */
void CharLinkedList::popFromBack(){
    string errorMessage = "cannot pop from empty ArrayList";   
    if(numElements == 0){
        throw std::runtime_error(errorMessage);
    }
    removeAt(numElements - 1);
}

/*
 * name:      removeAt
 * purpose:   to remove an element at a given index
 * arguments: int index
 * returns:   none
 * effects:   removes element at int index, so numElements decrements
 *            and surrounding Node's next and previous pointers will change
 */

void CharLinkedList::removeAt(int index){
    string errorMessage = "index (" + std::to_string(index) + ") not in range " 
    + "[0.." + std::to_string(numElements) + ")";
    if(index >= numElements or index < 0){
       throw std::range_error(errorMessage);
    }
    if(index == 0){
        if(front == back){ //which means this is a singleton list
            delete front;
            front = nullptr;
            back = nullptr;
        } else {
            Node *tempFront = front;
            front = front->next;
            front->previous = nullptr;
            delete tempFront;
            return;
        }
    } else {
        //first, find the node at that index and then reassign pointers 
        //then delete
        Node *correctNode = findElementAt(index, front);
        correctNode->previous->next = correctNode->next;
        correctNode->next->previous = correctNode->previous;
        correctNode->next = nullptr;
        correctNode->previous = nullptr;
        delete correctNode;
    }
    numElements--;
}

/*
 * name:      replaceAt
 * purpose:   replaces a Node at a given index
 * arguments: a character char c to replace with character at int index
 * returns:   none
 * effects:   replaces Node at given index with a new Node of given char
 *            reassigns next and previous pointers
 */
void CharLinkedList::replaceAt(char c, int index){
    //check to see if the index is a valid index
    string errorMessage = "index (" + std::to_string(index) + ") not in range " 
    + "[0.." + std::to_string(numElements) + ")";

    if(index >= numElements or index < 0){
       throw std::range_error(errorMessage);
    }

    Node* correctNode = findElementAt(index, front);
    correctNode->info = c;
}

/*
 * name:      concatenate
 * purpose:   to combine two strings into one string
 * arguments: a pointer to another CharLinkedList
 * returns:   none
 * effects:   increases the numElements size
 *            calls pushAtBack and elementAt to help
 */
void CharLinkedList::concatenate(CharLinkedList *other){
    const int otherSize = other->numElements;
    for(int i = 0; i < otherSize; i++){
        pushAtBack(other->elementAt(i));
    }
}


/*
 * name:      deleteList
 * purpose:   a private recursive helper function for the clear() and
 *            destructor functions
 * arguments: a pointer to a starting Node
 * returns:   none
 * effects:   deletes each Node in the Linked List
 */
void CharLinkedList::deleteList(Node *curr){
    if (curr == nullptr){
        return;
    }
    else {
        deleteList(curr->next);
        numElements--;
        delete curr;
    }
}


/*
 * name:      findElementAt
 * purpose:   a private recursive helper function the elementAt(),
 *            insertAt(), removeAt(), replaceAt(), and insertInOrder() 
 *            functions 
 * arguments: a pointer to a Node (starting Node)
 * returns:   A pointer to the Node that we were looking for at index
 * effects:   none
 */
CharLinkedList::Node* CharLinkedList::findElementAt(int index, Node *curr) 
const
{
    if (index == 0){
        return curr;
    }
    else {
        return findElementAt(index - 1, curr->next);
    }
}
/*
 *  unit_tests.h
 *  Peter Morganelli
 *  2/1/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  Testing file for the CharLinkedList class
 *
 */

#include "CharLinkedList.h"
#include <cassert>
#include <iostream>

/********************************************************************\
*                       CHAR LINKED LIST TESTS                        *
\********************************************************************/

/* To give an example of thorough testing, we are providing
 * the unit tests below which test the insertAt function. Notice: we have
 * tried to consider all of the different cases insertAt may be
 * called in, and we test insertAt in conjunction with other functions!
 *
 * You should emulate this approach for all functions you define.
 */


void test_isEmpty() {
    CharLinkedList test_list1;
    std::cerr << test_list1.size() << endl;
    assert(test_list1.isEmpty()); //should return true

    CharLinkedList test_list2('a');
    assert(not (test_list2.isEmpty())); //should return true 
    //(NOT empty - on elem)

    char char_arr[] = {'a', 'b', 'c'};
    CharLinkedList test_list3(char_arr, 3);

    assert(not (test_list3.isEmpty()));
}

void test_clear(){
    char char_arr[] = {'a', 'b', 'c'};
    CharLinkedList test_list(char_arr, 3);
    test_list.clear();
    assert(test_list.isEmpty());
    test_list.pushAtBack('a');
    assert(test_list.elementAt(0) == 'a');
    //check STATE of the functions
}

void test_size(){
    char char_arr[] = {'a', 'b', 'c'};
    CharLinkedList test_list1(char_arr, 3);
    assert(test_list1.size() == 3);
    
    CharLinkedList test_list2('a');
    assert(test_list2.size() == 1);

    CharLinkedList test_list3;
    assert(test_list3.size() == 0);
}

void test_first(){
    char char_arr[] = {'a', 'b', 'c'};
    CharLinkedList test_list2(char_arr, 3);
    assert(test_list2.first() == 'a');

    CharLinkedList test_list3('a');
    assert(test_list2.first() == 'a');
}

void test_smallElementAt(){
    CharLinkedList test_list('a');
    assert(test_list.elementAt(0) == 'a');
}

void test_last(){

    char char_arr[] = {'a', 'b', 'c'};
    CharLinkedList test_list2(char_arr, 3);
    assert(test_list2.last() == 'c');

    CharLinkedList test_list3('a');
    assert(test_list3.last() == 'a');
}

void test_toString(){
    char char_arr[] = {'a', 'b', 'c'};
    CharLinkedList test_list(char_arr, 3);
    assert(test_list.toString() == "[CharLinkedList of size 3 <<abc>>]");
    
    CharLinkedList test_list2;
    assert(test_list2.toString() == "[CharLinkedList of size 0 <<>>]");

    CharLinkedList test_list3('a');
    assert(test_list3.toString() == "[CharLinkedList of size 1 <<a>>]");
}

void test_toReverseString(){
    char char_arr[] = {'a', 'b', 'c'};
    CharLinkedList test_list(char_arr, 3);
    assert(test_list.toReverseString() == 
    "[CharLinkedList of size 3 <<cba>>]");
    
    CharLinkedList test_list2;
    assert(test_list2.toReverseString() == 
    "[CharLinkedList of size 0 <<>>]");

    CharLinkedList test_list3('a');
    assert(test_list3.toReverseString() == 
    "[CharLinkedList of size 1 <<a>>]");
}

void test_elementAt(){
    char char_arr[] = {'a', 'b', 'c'};
    CharLinkedList test_list(char_arr, 3);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    assert(test_list.elementAt(2) == 'c');

    bool range_error_thrown = false;
    std::string error_message = "";
    try {
        test_list.elementAt(32);
    }
    catch (const std::range_error &e) {
    range_error_thrown = true;
    error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (32) not in range [0..3)");


    CharLinkedList test_list2('a');
    assert(test_list2.elementAt(0) == 'a');
}

void more_test_elementAt(){
    CharLinkedList test_list;
    bool range_error_thrown = false;
    std::string error_message = "";
    try {
        test_list.elementAt(-1);
    }
    catch (std::range_error &e){
        range_error_thrown = true;
        error_message = e.what();
    }
        assert(range_error_thrown);
        assert(error_message == "index (-1) not in range [0..0)");
}

void test_pushAtBack(){
    CharLinkedList test_list;
    test_list.pushAtBack('d');
    assert(test_list.elementAt(0) == 'd');

    CharLinkedList test_list2('a');
    test_list2.pushAtBack('b');
    assert(test_list2.elementAt(1) == 'b');

    char char_arr[] = {'a', 'b', 'c'};
    CharLinkedList test_list3(char_arr, 3);
    test_list3.pushAtBack('d');
    assert(test_list3.elementAt(0) == 'a');

    test_list3.clear();
    test_list3.pushAtBack('g');
    assert(test_list3.elementAt(0) == 'g');

}

void test_pushAtFront(){
    CharLinkedList test_list;
    assert(test_list.isEmpty());
    test_list.pushAtFront('z');
    assert(!test_list.isEmpty());
    assert(test_list.elementAt(0) == 'z');
    assert(test_list.size() == 1);
    test_list.clear();
    assert(test_list.isEmpty());

    CharLinkedList test_list2('a');
    test_list2.pushAtFront('z');
    assert(test_list2.elementAt(0) == 'z');

    char char_arr[] = {'a', 'b', 'c'};
    CharLinkedList test_list3(char_arr, 3);
    assert(test_list3.size() == 3);
    test_list3.pushAtFront('z');
    assert(test_list3.elementAt(0) == 'z');
    assert(test_list3.size() == 4);
    assert(test_list3.elementAt(1) == 'a');

}


// Tests correct insertion into an empty AL.
// Afterwards, size should be 1 and element at index 0
// should be the element we inserted.
void insertAt_empty_correct() { 
    CharLinkedList test_list;
    test_list.insertAt('a', 0);
    cout << test_list.size() << endl;
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');
}

// Tests incorrect insertion into an empty AL.
// Attempts to call insertAt for index larger than 0.
// This should result in an std::range_error being raised.
void insertAt_empty_incorrect() {

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    // insertAt for out-of-range index
    test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
    // if insertAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    range_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0]");
    
}

// Tests correct insertAt for front of 1-element list.
void insertAt_front_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at front
    test_list.insertAt('b', 0);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'a');
    
}

// Tests correct insertAt for back of 1-element list.
void insertAt_back_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at back
    test_list.insertAt('b', 1);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    
}

// Tests calling insertAt for a large number of elements.
// Not only does this test insertAt, it also checks that
// array expansion works correctly.
void insertAt_many_elements() {
    
    CharLinkedList test_list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.insertAt('a', i);
    }

    assert(test_list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
    
}

//Tests insertion into front of a larger list
void insertAt_front_large_list() {
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    test_list.insertAt('y', 0);

    assert(test_list.size() == 10);
    assert(test_list.elementAt(0) == 'y');
    assert(test_list.toString() ==     
    "[CharLinkedList of size 10 <<yabczdefgh>>]");

}

//Tests insertion into the back of a larger list
void insertAt_back_large_list() {

    char test_arr[10] = { 'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 
'g', 'h' };
    CharLinkedList test_list(test_arr, 10);  

    test_list.insertAt('x', 10);

    assert(test_list.size() == 11);
    assert(test_list.elementAt(10) == 'x');
    assert(test_list.toString() == 
    "[CharLinkedList of size 11 <<yabczdefghx>>]"); 

}   

// Tests insertion into the middle of a larger list
void insertAt_middle_large_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.insertAt('z', 3);
    assert(test_list.size() == 9);
    assert(test_list.elementAt(3) == 'z');
    cout << test_list.toString() << endl;
    assert(test_list.toString() ==     
    "[CharLinkedList of size 9 <<abczdefgh>>]");
}

// Tests out-of-range insertion for a non-empty list.
void insertAt_nonempty_incorrect() {
   
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8]");
    
}


void test_removeAt(){
    char char_arr[] = {'a', 'b', 'c'};
    CharLinkedList test_list1(char_arr, 3);
    test_list1.removeAt(1);
    assert(test_list1.elementAt(1) == 'c');
    

    CharLinkedList test_list2('a');
    test_list2.removeAt(0);
    assert(test_list2.isEmpty());

    CharLinkedList test_list3;
    std::string error_message = "";
    bool range_error_thrown = false;
    try {
        test_list3.removeAt(0);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);

    char char_arr5[] = {'a', 'b'};
    CharLinkedList test_list5(char_arr5, 2);
    test_list5.removeAt(0);
    assert(test_list5.elementAt(0) == 'b');

}



void test_replaceAt(){
    char char_arr[] = {'a', 'b', 'c'};
    CharLinkedList test_list1(char_arr, 3);
    test_list1.replaceAt('d', 2);
    assert(test_list1.elementAt(2) == 'd');
    assert(test_list1.size() == 3);    

    CharLinkedList test_list2;
    std::string error_message = "";
    bool range_error_thrown = false;
    try {
        test_list2.replaceAt(0, 'a');
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
}


void test_insertInOrder(){
    char char_arr[] = {'z', 'e', 'd'};
    CharLinkedList test_list1(char_arr, 3);
    test_list1.insertInOrder('a');
    assert(test_list1.elementAt(0) == 'a');

    CharLinkedList test_list2('b');
    test_list2.insertInOrder('a');
    assert(test_list2.elementAt(0) == 'a');

    CharLinkedList test_list3('b');
    test_list3.insertInOrder('a');
    assert(test_list3.elementAt(0) == 'a');

    char char_arr2[] = {'a', 'b', 'd', 'e', 'f'};
    CharLinkedList test_list4(char_arr2, 5);
    test_list4.insertInOrder('c');
    assert(test_list4.elementAt(2) == 'c');

    CharLinkedList test_list5;
    test_list5.insertInOrder('a');
    assert(test_list5.elementAt(0) == 'a');

    char char_arr3[] = {'a', 'b', 'c'};
    CharLinkedList test_list6(char_arr3, 3);
    test_list6.insertInOrder('a');
    assert(test_list6.elementAt(1) == 'a');

    CharLinkedList test_list7(char_arr3, 3);
    test_list7.insertInOrder('c');
    assert(test_list7.elementAt(2) and test_list7.elementAt(3) == 'c');

    char char_arr4[] = {'$', 'A', 'B'};
    CharLinkedList test_list8(char_arr4, 3);
    test_list8.insertInOrder('z');
    assert(test_list8.elementAt(3) == 'z');

}

void test_concatenate(){
    char char_arr[] = {'c', 'a', 't'};
    CharLinkedList test_list1(char_arr, 3);

    char char_arr2[] = {'C', 'H', 'E', 'S', 'H', 'I', 'R', 'E'};
    CharLinkedList other_test_list(char_arr2, 8);
    
    test_list1.concatenate(&other_test_list);
    assert(test_list1.elementAt(2) == 't');
    assert(test_list1.elementAt(3) == 'C');
    assert(test_list1.elementAt(10) == 'E');

    CharLinkedList test_list4(char_arr, 3);
    test_list4.concatenate(&test_list4);
    assert(test_list4.elementAt(5) == 't');

    CharLinkedList new_test_list;
    CharLinkedList new_test_list2;

    new_test_list.concatenate(&new_test_list2);
    assert(new_test_list.isEmpty());
}

void test_copyConstructor(){
    char char_arr[] = {'c', 'a', 't'};
    CharLinkedList l1(char_arr, 3);    
    CharLinkedList l2(l1);
    
    assert(l1.elementAt(0) == 'c');

    //changing and making sure it doesn't persist to the other
    assert(l1.size() == 3);
    assert(l2.size() == 3);
}

void test_assignmentOperator(){
    char char_arr[] = {'c', 'a', 't'};
    CharLinkedList l1(char_arr, 3);    
    CharLinkedList l2 = l1;
    assert(l1.elementAt(0) == 'c');

    assert(l1.size() == 3);
    assert(l2.size() == 3);
}

/*
 *  CharLinkedList.cpp
 *  Alejandra Sabater
 *  2/4/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  An implementation of the CharLinkedList interface, the LinkedList can be 
 *  used to store characters.
 *
 */

#include "CharLinkedList.h"
#include <stdexcept>
#include <sstream>

/*
 * name:      CharLinkedList
 * purpose:   Constructor, initializes an empty list
 * arguments: None
 * returns:   Nothing
 * effects:   Initializes front and back pointers to nullptr and sets
 *            number of items to 0
 */
CharLinkedList::CharLinkedList() {
    front = nullptr;
    back = nullptr;
    items  = 0;
}

/*
 * name:      CharLinkedList
 * purpose:   Constructor 2, creates a one element list consisting of that 
 *            character
 * arguments: Single character
 * returns:   Nothing  
 * effects:   Initializes list with a single node containing character given
 */
CharLinkedList::CharLinkedList(char c) {
    front = createNode(c);
    back = front;
    items = 1;
}

/*
 * name:      CharLinkedList
 * purpose:   Constructor 3, create a linked list containing
 *            characters in array
 * arguments: array of characters and int length of that array of characters
 * returns:   Nothing  
 * effects:   Initializes list with nodes of characters from given array
 */
CharLinkedList::CharLinkedList(char arr[], int size) {
    //Make an empty list
    front = nullptr;
    back = nullptr;
    items = 0;

    //Iterate through the array and add each character to the list
    for (int i = 0; i < size; i++) {
        Node *newNode = createNode(arr[i]);

        if (isEmpty()) {
            front = newNode;
            back = newNode;
        } else {
            back->next = newNode;
            newNode->prev = back;
            back = newNode;
        }

        items++;
    }

}

/*
 * name:      CharLinkedList
 * purpose:   Constructor 4, 
 * arguments: address of another linkedlist
 * returns:   Nothing  
 * effects:   Initializes new list as deep copy of the given linked list
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other) {
    front = nullptr;
    back = nullptr;
    items = 0;

    Node *current = other.front; //Initialize current to point to other's front

    while (current != nullptr) {
        pushAtBack(current->data);
        current = current->next;
    }
}

/*
 * name:      ~CharLinkedList
 * purpose:   Destructor, deletes data nodes from the heap
 * arguments: None
 * returns:   Nothing
 * effects:   Frees memory allocated for linked list nodes
 */
CharLinkedList::~CharLinkedList() {
    destroy(front);
}

/*
 * name:      createNode
 * purpose:   creates new node to put into linked list and points front
 *            and back pointers to where they belong now
 * arguments: character to put in data of new node
 * returns:   a pointer to newly created node
 * effects:   Allocates memory for new node and initializes data
 */
CharLinkedList::Node *CharLinkedList::createNode(char c) {
    Node *newNode = new Node;
    newNode->prev = nullptr;
    newNode->next = nullptr;
    newNode->data = c;

    return newNode;
}

/*
 * name:      destroy
 * purpose:   runs through linked list and deletes all nodes
 * arguments: a pointer to node at which to begin deletions
 * returns:   Nothing
 * effects:   Frees memory allocated for each node in linked list
 */
void CharLinkedList::destroy(Node *current) {
    if (current != nullptr) {
        destroy(current->next);
        delete current;
    } 
}

/*
 * name:      findElement
 * purpose:   find specific element in list
 * arguments: a pointer to node at which to start searching and
 *            index of data you are looking for
 * returns:   the character at a specific node
 * effects:   None
 */
char CharLinkedList::findElement(Node *current, int index) const {
    if (current == nullptr or index == 0) {
        return current->data;
    }

    return findElement(current->next, index - 1);
}

/*
 * name:      findElementNode
 * purpose:   find a specific node in list
 * arguments: a pointer to node at which to start searching, 
 *            and index of the data you are looking for
 * returns:   a pointer to node containing the specified data
 * effects:   None
 */
CharLinkedList::Node *CharLinkedList::findElementNode(Node *curr, int index)
    const {
    if (curr == nullptr or index == 0) {
        return curr;
    }

    return findElementNode(curr->next, index - 1);
}


/*
 * name:      isEmpty
 * purpose:   Check if lists are empty
 * arguments: None
 * returns:   True or False
 * effects:   None  
 */
bool CharLinkedList::isEmpty() const {
    return (items == 0);
}

/*
 * name:      size
 * purpose:   give us the size of the array
 * arguments: None
 * returns:   an integer value that is the number of 
 *            characters in the array list  
 * effects:   None
 */
int CharLinkedList::size() const {
    return items;
}

/*
 * name:      clear
 * purpose:   makes the instance into an empty list
 * arguments: None
 * returns:   None  
 * effects:   Frees memory used for nodes and resets the front and back pointers
 */
void CharLinkedList::clear() {
    destroy(front); //recursively destroy the nodes

    front = nullptr;
    back = nullptr;
    items  = 0;
}

/*
 * name:      first
 * purpose:   gives us the first character in the linked list
 * arguments: none
 * returns:   first character in the list 
 * effects:   Throws runtime error if list is empty
 */
char CharLinkedList::first() const {
    if (isEmpty()) {
        throw std::runtime_error("cannot get first of empty LinkedList");
    } else {
        return front->data;
    }
}

/*
 * name:      last
 * purpose:   give us the last character in the linked list
 * arguments: None
 * returns:   last character in the list 
 * effects:   Throws runtime error if list is empty
 */
char CharLinkedList::last() const {
    if (isEmpty()) {
        throw std::runtime_error("cannot get last of empty LinkedList");
    } else {
        return back->data;
    }
}

/*
 * name:      elementAt
 * purpose:   return the element at index specified by user
 * arguments: integer index of thing user wants
 * returns:   the character in that element 
 * effects:   Throws range error if index is out of bounds
 */
char CharLinkedList::elementAt(int index) const {
    std::stringstream sent;
    if (isEmpty() or index >= items or index < 0) {
        sent << "index (" <<  index << ") not in range [0.." 
        << items << ")"; 
        throw std::range_error(sent.str());
    }

    return findElement(front, index);;
}

/*
 * name:      toString
 * purpose:   turn the list into a string
 * arguments: none
 * returns:   a string formated "CharLinkedList of size ... <<...>>" 
 * effects:   none
 */
std::string CharLinkedList::toString() const {
    std::stringstream sentence;
    sentence << "[CharLinkedList of size "; 
    sentence << items; 
    sentence << " <<";

    if (not isEmpty()) {
        for (int i = 0; i < items; i++) {
            sentence << findElement(front, i);
        }
    }

    sentence << ">>]";

    return sentence.str();
}

/*
 * name:      toReverseString
 * purpose:   turn the list into a reversed string
 * arguments: none
 * returns:   a string formated "CharLinkedList of size ... <<...>>" 
 * effects:   none
 */
std::string CharLinkedList::toReverseString() const {
    std::stringstream sentence;
    sentence << "[CharLinkedList of size "; 
    sentence << items; 
    sentence << " <<";

    if (not isEmpty()) {
        for (int i = (items - 1); i >= 0; i--) {
            sentence << findElement(front, i);
        }
    }

    sentence << ">>]";

    return sentence.str();
}

/*
 * name:      pushAtBack
 * purpose:   puts in a character given by the user into the back of the list
 * arguments: takes in a character
 * returns:   nothing
 * effects:   Increases the size of the list by one
 */
void CharLinkedList::pushAtBack(char c) {
    Node *newNode = createNode(c);

    if (isEmpty()) {
        front = newNode;
        back = newNode;
    } else {
        back->next = newNode;
        newNode->prev = back;
        back = newNode;
    }

    items++;
}

/*
 * name:      pushAtFront
 * purpose:   puts in a character given by the user into the front of the list
 * arguments: takes in a character
 * returns:   nothing
 * effects:   Increases the size of the list by one
 */
void CharLinkedList::pushAtFront(char c) {
    Node *newNode = createNode(c);

    if (isEmpty()) {
        front = newNode;
        back = newNode;
    } else {
        newNode->next = front;
        front->prev = newNode;
        front = newNode;
    }

    items++;
}

/*
 * name:      insertAt
 * purpose:   inserts a character at the specified index in the list
 * arguments: a character and an index
 * returns:   None
 * effects:   Increases the size of the list by one
 */
void CharLinkedList::insertAt(char c, int index) {
    if (index < 0 or index > items) {
        std::stringstream message;
        message << "index (" << index << ") not in range [0.." << items << "]";
        throw std::range_error(message.str());
    }

    if (index == 0) { // Insert at beginning
        pushAtFront(c);
    } else if (index == items) { // Insert at end
        pushAtBack(c);
    } else { // Insert in the middle
        Node *current = front;

        for (int i = 0; i < index; ++i) {
            current = current->next;
        }

        Node *newNode = createNode(c);
        newNode->next = current;
        newNode->prev = current->prev;
        current->prev->next = newNode;
        current->prev = newNode;
        
        items++;
    }
}

/*
 * name:      insertInOrder
 * purpose:   puts character given by the user into list
 *            in ASCII order 
 * arguments: a character 
 * returns:   nothing
 * effects:   Increases the size of the list by one
 */
void CharLinkedList::insertInOrder(char c) {
    if (isEmpty() or c <= front->data) { // Insert at the beginning
        insertAt(c, 0);
    } else if (back->data <= c) { // Insert at the end
        insertAt(c, items);
    } else { // Find somewhere in the middle
        Node *newNode = createNode(c);
        Node *current = front;

        while (current->next != nullptr and c > current->next->data) {
            current = current->next;
        }

        newNode->next = current->next;
        newNode->prev = current;
        current->next->prev = newNode;
        current->next = newNode;

        items++;
    }
}

/*
 * name:      operator=
 * purpose:   edits the = operator to create a deep copy of two linked lists
 * arguments: the address of a linked list
 * returns:   nothing
 * effects:   Frees memory allocated for current list and creates
 *            a deep copy of the given list
 */
CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other) {
    if (this == &other) { //Check if attempting to assign list to itself
        return *this;
    }

    clear(); 

    front = nullptr; //make new list
    back = nullptr;
    items = 0;

    // Initialize current to point to other's front
    Node *current = other.front;  

    while (current != nullptr) { //go through other, copy elements to current
        pushAtBack(current->data);
        current = current->next;
    }

    return *this;
 }

/*
 * name:      popFromFront
 * purpose:   removes the first element from the list 
 * arguments: none
 * returns:   nothing
 * effects:   Decreases the size of the list by one
 */
void CharLinkedList::popFromFront() {
    Node *temp = front; //variable to erase the front more easily
    if (isEmpty()) {
        throw std::runtime_error("cannot pop from empty LinkedList");
    } else {
        if (front == back) { //If there's only one element
            front = nullptr;
            back = nullptr;
        } else {
            front = front->next;
            front->prev = nullptr;
        }
    }

    delete temp;
    items--;
}

/*
 * name:      popFromBack
 * purpose:   removes the last element from the list 
 * arguments: none
 * returns:   nothing
 * effects:   Decreases the size of the list by one
 */
void CharLinkedList::popFromBack() {
    Node *temp = back; //variable to erase the back more easily
    if (isEmpty()) { //for error
        throw std::runtime_error("cannot pop from empty LinkedList");
    } else {
        if (front == back) { //If there's only one element
            front = nullptr;
            back = nullptr;
        } else { 
            back = back->prev;
            back->next = nullptr;
        }
    }

    delete temp;
    items--;
}

/*
 * name:      removeAt
 * purpose:   removes element at specificed index from the list 
 * arguments: takes in an index number
 * returns:   nothing
 * effects:   Decreases the size of the list by one and throws range error
 *            if index is out of bounds
 */
void CharLinkedList::removeAt(int index) {
    std::stringstream sent;
    Node *current = front;

    if (index < 0 or index > items) { //for error
        sent << "index (" << index << ") not in range [0.." << items << ")"; 
        throw std::range_error(sent.str());
    } else if (index == 0) { //removing the front
        popFromFront();
    } else if (index == items - 1) { //removing the end
        popFromBack();
    } else { //removing the middle
        current = findElementNode(current, index);

        current->prev->next = current->next; //reassigning pointers
        current->next->prev = current->prev;
        delete current;

        items--;   
    }
}

/*
 * name:      replaceAt
 * purpose:   replaces the element at the specified index with the new element
 * arguments: a character and the index the user wants to replace with it
 * returns:   nothing  
 * effects:   Throws range error if index is out of bounds
 */
void CharLinkedList::replaceAt(char c, int index) {
    std::stringstream sent;
    if (index < 0 or index > items) {
        sent << "index (" <<  index << ") not in range [0.." 
        << items << ")"; 
        throw std::range_error(sent.str());
    } else {
        removeAt(index); //remove function uses a recursive function
        insertAt(c, index);
    }
}

/*
 * name:      Concatenate
 * purpose:   combines two linked lits
 * arguments: takes in a pointer to another linked list
 * returns:   nothing
 * effects:   nothing
 */
void CharLinkedList::concatenate(CharLinkedList *other) {
    if (other->isEmpty()) { //Check if the second list is empty
        return;
    } else { 
        CharLinkedList otherCopy(*other); //make deep copy of linked list

        Node *current = otherCopy.front; //start at beginning

        while(current != nullptr) { //push back second list into first list
            pushAtBack(current->data);
            current = current->next;
        }
    }
}

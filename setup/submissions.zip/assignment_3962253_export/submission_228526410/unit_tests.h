/*
 *  unit_tests.h
 *  Alejandra Sabater
 *  2/4/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  A testing file for your Linked List class that uses the unit_test framework
 *
 *  CharLinkedList is a class that represents a linked list of characters. 
 *  Each node in contains a single character. The list can grow or shrink 
 *  dynamically. An instance of CharLinkedList is a sequencfe of characters
 *  or an empty list. Characters can be added or removed from any position in 
 *  the list, and the list automatically adjusts its size accordingly. This 
 *  contains all of the tests for the functions created in the .cpp file. 
 *  These tests are logical to make sure that the functions work normally and 
 *  then there are a couple tests for edge cases, where the code might not work
 *  but I checked to make sure mine does.
 */ 


#include "CharLinkedList.h"
#include <cassert>


// //Tests for constructor 1
void testConstructor1_1() {
    CharLinkedList list1;
    
    assert(list1.isEmpty());
    assert(list1.size() == 0);
}

//tests for constructor 2
void testConstructor2_1() {
    CharLinkedList list1('o');

    assert(not list1.isEmpty());
    assert(list1.size() == 1);
}

//Tests for constructor 3
//creates an list with 5 characters
void testConstructor3_1() {
    char test_arr[] = {'a', 'b', 'c', 'd', 'e'};
    int size = 5;

    CharLinkedList list1(test_arr, size); 

    assert(not list1.isEmpty());
    assert(list1.size() == 5);
}

//Test for Size function
void testSize_1() { //empty array
    char test_arr[] = {};
    int size = 0;

    CharLinkedList list1(test_arr, size); //checking one constructor

    assert(list1.isEmpty());
    assert(list1.size() == 0);
}

void testSize_2() { //empty list
    CharLinkedList list1; //checking another constructor

    assert(list1.isEmpty());
    assert(list1.size() == 0);
}

void testSize_3() { //non empty array
    char test_arr[] = {'a', 'b', 'c', 'd', 'e'};
    int size = 5;

    CharLinkedList list1(test_arr, size);

    assert(not list1.isEmpty());
    assert(list1.size() == 5);
}

void testSize_4() { //non empty array
    CharLinkedList list1('o'); 

    assert(not list1.isEmpty());
    assert(list1.size() == 1);
}

//Test for clear function
void testClear_1() { //empty array
    char test_arr[] = {};
    int size = 0;

    CharLinkedList list1(test_arr, size); //checking one constructor

    list1.clear();

    assert(list1.isEmpty());
    assert(list1.size() == 0);
}

void testClear_2() { //empty array
    char test_arr[] = {'a', 'b', 'c', 'd', 'e'};
    int size = 5;

    CharLinkedList list1(test_arr, size);

    list1.clear();

    assert(list1.isEmpty());
    assert(list1.size() == 0);
}

void testClear_3() { //empty list
    CharLinkedList list1;

    list1.clear();

    assert(list1.isEmpty());
    assert(list1.size() == 0);
}

void testClear_4() { //empty list
    CharLinkedList list1('a');

    list1.clear();

    assert(list1.isEmpty());
    assert(list1.size() == 0);
}

//Test for First function
void testFirst_1() {//non empty array
    char test_arr[] = {'a', 'b', 'c', 'd', 'e'};
    int size = 5;

    CharLinkedList list1(test_arr, size);

    assert(not list1.isEmpty());
    assert(list1.size() == 5);
    assert(list1.first() == 'a');
}

void testFirst_2() {//non empty array
    CharLinkedList list1('b');

    assert(not list1.isEmpty());
    assert(list1.size() == 1);
    assert(list1.first() == 'b');
}

void testFirst_3() {// empty list
    CharLinkedList list1;

    std::string error_message = "";
    bool runtime_error_thrown = false;

    try {
        list1.first(); //will throw an exception
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what(); // Returns const char* describing exception
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot get first of empty LinkedList");
}

void testFirst_4() {// empty array
    char test_arr[] = {};
    int size = 0;

    CharLinkedList list1(test_arr, size);

    std::string error_message = "";
    bool runtime_error_thrown = false;

    try {
        list1.first(); //will throw an exception
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what(); // Returns const char* describing exception
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot get first of empty LinkedList");
}

//Test for Last function
void testLast_1() {//non empty array
    char test_arr[] = {'a', 'b', 'c', 'd', 'e'};
    int size = 5;

    CharLinkedList list1(test_arr, size);

    assert(not list1.isEmpty());
    assert(list1.size() == 5);
    assert(list1.last() == 'e');
}

void testLast_2() {//non empty array
    CharLinkedList list1('d');

    assert(not list1.isEmpty());
    assert(list1.size() == 1);
    assert(list1.last() == 'd');
}

void testLast_3() {// empty list
    CharLinkedList list1;

    std::string error_message = "";
    bool runtime_error_thrown = false;

    try {
        list1.last(); //will throw an exception
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what(); // Returns const char* describing exception
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot get last of empty LinkedList");
}

void testLast_4() {// empty array
    char test_arr[] = {};
    int size = 0;

    CharLinkedList list1(test_arr, size);

    std::string error_message = "";
    bool runtime_error_thrown = false;

    try {
        list1.last(); //will throw an exception
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what(); // Returns const char* describing exception
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot get last of empty LinkedList");
}

//test for finding element
void testElementAt_1() {//non empty array
    char test_arr[] = {'a', 'b', 'c', 'd', 'e'};
    int size = 5;

    CharLinkedList list1(test_arr, size);

    assert(not list1.isEmpty());
    assert(list1.size() == 5);
    assert(list1.last() == 'e');
    assert(list1.elementAt(0) == 'a');
    assert(list1.elementAt(1) == 'b');
    assert(list1.elementAt(2) == 'c');
    assert(list1.elementAt(3) == 'd');
    assert(list1.elementAt(4) == 'e');
}

void testElementAt_2() {//non empty array
    CharLinkedList list1('d');

    assert(not list1.isEmpty());
    assert(list1.size() == 1);
    assert(list1.last() == 'd');
    assert(list1.elementAt(0) == 'd');
}

void testElementAt_3() {// empty array
    char test_arr[] = {};
    int size = 0;

    CharLinkedList list1(test_arr, size);

    std::string error_message = "";
    bool range_error_thrown = false;

    try {
        list1.elementAt(3); //will throw an exception
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what(); // Returns const char* describing exception
    }

    assert(range_error_thrown);
    assert(error_message == "index (3) not in range [0..0)");
}

void testElementAt_4() {// empty array
    CharLinkedList list1;

    std::string error_message = "";
    bool range_error_thrown = false;

    try {
        list1.elementAt(3); //will throw an exception
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what(); // Returns const char* describing exception
    }

    assert(range_error_thrown);
    assert(error_message == "index (3) not in range [0..0)");
}

void testElementAt_5() {// empty array
    CharLinkedList list1('d');

    std::string error_message = "";
    bool range_error_thrown = false;

    try {
        list1.elementAt(3); //will throw an exception
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what(); // Returns const char* describing exception
    }

    assert(range_error_thrown);
    assert(error_message == "index (3) not in range [0..1)");
}

//Test for to string function
void testToString_1() { //nonempty array should correclty convert to string
    char test_arr[] = {'A', 'l', 'i', 'c', 'e'};
    int size = 5; 

    CharLinkedList list(test_arr, size);

    assert(list.toString() == "[CharLinkedList of size 5 <<Alice>>]");
}

void testToString_2() { //empty array should convert to string
    char test_arr[] = {};
    int size = 0; 

    CharLinkedList list(test_arr, size);

    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");  
}

void testToString_3() { //nonempty array should convert to string
    char test_arr[] = {'a'};
    int size = 1; 

    CharLinkedList list(test_arr, size);

    assert(list.toString() == "[CharLinkedList of size 1 <<a>>]");  
}

//Test for reversing the string function
void testToReverseString_1() { //nonempty array should convert to string
    char test_arr[] = {'A', 'l', 'i', 'c', 'e'};
    int size = 5; 

    CharLinkedList list(test_arr, size);

    assert(list.toReverseString() == "[CharLinkedList of size 5 <<ecilA>>]");
}

void testToReverseString_2() { //empty array should convert to string
    char test_arr[] = {};
    int size = 0; 

    CharLinkedList list(test_arr, size);

    assert(list.toReverseString() == "[CharLinkedList of size 0 <<>>]");  
}

void testToReverseString_3() { //nonempty array should convert to string
    char test_arr[] = {'a'};
    int size = 1; 

    CharLinkedList list(test_arr, size);

    assert(list.toReverseString() == "[CharLinkedList of size 1 <<a>>]");  
}

//Test for Push back function
void testPushAtBack_1() { //nonempty array 
    char test_arr[] = {'A', 'l', 'i', 'c', 'e'};
    int size = 5; 

    CharLinkedList list(test_arr, size);

    list.pushAtBack('s');

    assert(list.size() == 6);
    assert(list.last() == 's');
}

void testPushAtBack_2() { //empty array 
    char test_arr[] = {};
    int size = 0; 

    CharLinkedList list(test_arr, size);

    list.pushAtBack('a');

    assert(list.size() == 1);
    assert(list.last() == 'a'); 
}

void testPushAtBack_3() { //nonempty array 
    char test_arr[] = {'a'};
    int size = 1; 

    CharLinkedList list(test_arr, size);

    list.pushAtBack('b');

    assert(list.size() == 2);
    assert(list.last() == 'b');  
}

void testPushAtBack_4() { //nonempty array 
    char test_arr[] = {'a'};
    int size = 1; 

    CharLinkedList list(test_arr, size);

    list.pushAtBack('b');
    list.pushAtBack('c');

    assert(list.size() == 3);
    assert(list.last() == 'c');  
}

//Test for push at front function
void testPushAtFront_1() { //nonempty array 
    char test_arr[] = {'A', 'l', 'i', 'c', 'e'};
    int size = 5; 

    CharLinkedList list(test_arr, size);

    list.pushAtFront('s');

    assert(list.size() == 6);
    assert(list.first() == 's');
}

void testPushAtFront_2() { //empty array 
    char test_arr[] = {};
    int size = 0; 

    CharLinkedList list(test_arr, size);

    list.pushAtFront('a');

    assert(list.size() == 1);
    assert(list.first() == 'a'); 
}

void testPushAtFront_3() { //nonempty array
    char test_arr[] = {'b'};
    int size = 1; 

    CharLinkedList list(test_arr, size);

    list.pushAtFront('a');

    assert(list.size() == 2);
    assert(list.last() == 'b');  
}

//Test for insertAt
void testInsertAt_1() { //nonempty array 
    char test_arr[] = {'A', 'l', 'i', 'e', 's'};
    int size = 5; 

    CharLinkedList list(test_arr, size);

    list.insertAt('c', 3);
    assert(list.size() == 6);
    assert(list.toString() == "[CharLinkedList of size 6 <<Alices>>]");
}

void testInsertAt_2() { //empty array 
    char test_arr[] = {};
    int size = 0; 

    CharLinkedList list(test_arr, size);

    list.insertAt('a', 0);

    assert(list.size() == 1);
    assert(list.first() == 'a'); 
}

void testInsertAt_6() { //empty array 
    char test_arr[] = {};
    int size = 0; 

    CharLinkedList list(test_arr, size);

    list.insertAt('c', 0);

    assert(list.size() == 1);
    assert(list.first() == 'c'); 
}

void testInsertAt_3() { //nonempty array 
    char test_arr[] = {'b'};
    int size = 1; 

    CharLinkedList list(test_arr, size);

    list.insertAt('a', 0);

    assert(list.size() == 2);
    assert(list.last() == 'b');  
    assert(list.first() == 'a');

}

void testInsertAt_4() {// empty list
    CharLinkedList list1;
    int index = 3;

    std::string error_message = "";
    bool range_error_thrown = false;

    try {
        list1.insertAt('a', index); //will throw an exception
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what(); // Returns const char* describing exception
    }

    assert(range_error_thrown);
    assert(error_message == "index (3) not in range [0..0]");
}

void testInsertAt_5() {// empty list
    char test_arr[] = {'A', 'l', 'i', 'e', 's'};
    int size = 5; 
    int index = 13;

    CharLinkedList list1(test_arr, size);

    std::string error_message = "";
    bool range_error_thrown = false;

    try {
        list1.insertAt('a', index); //will throw an exception
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what(); // Returns const char* describing exception
    }

    assert(range_error_thrown);
    assert(error_message == "index (13) not in range [0..5]");
}

void testInsertAt_7() { //nonempty array 
    char test_arr[] = {'b', 'c'};
    int size = 2; 

    CharLinkedList list(test_arr, size);

    list.insertAt('a', 0);
    assert(list.size() == 3);

    list.insertAt('d', 3);
    assert(list.size() == 4);


    assert(list.first() == 'a');
    assert(list.last() == 'd');  

}

//test for insert in order function
void testInsertInOrder_1() { //nonempty array 
    char test_arr[] = {'a', 'b', 'c', 'e'};
    int size = 4; 

    CharLinkedList list(test_arr, size);

    list.insertInOrder('d');

    assert(list.size() == 5);
    assert(list.toString() == "[CharLinkedList of size 5 <<abcde>>]");
}

void testInsertInOrder_2() { //nonempty array 
    char test_arr[] = {'b'};
    int size = 1; 

    CharLinkedList list(test_arr, size);

    list.insertInOrder('c');
    
    assert(list.size() == 2);
    assert(list.toString() == "[CharLinkedList of size 2 <<bc>>]");
}

void testInsertInOrder_3() { //empty array 
    char test_arr[] = {};
    int size = 0; 

    CharLinkedList list(test_arr, size);

    list.insertInOrder('c');
       
    assert(list.size() == 1);
    assert(list.toString() == "[CharLinkedList of size 1 <<c>>]");
}

void testInsertInOrder_4() { //empty array  
    CharLinkedList list;

    list.insertInOrder('a');
       
    assert(list.size() == 1);
    assert(list.toString() == "[CharLinkedList of size 1 <<a>>]");
}

void testInsertInOrderWithNumber() { //empty array  
    char test_arr[] = {'a', 'b', 'c', 'd',};
    int size = 4; 

    CharLinkedList list(test_arr, size);

    list.insertInOrder('7');
       
    assert(list.size() == 5);
    assert(list.toString() == "[CharLinkedList of size 5 <<7abcd>>]");
}

//Test for remove from front function
void testPopFromFront_1() { //nonempty array
    char test_arr[] = {'A', 'l', 'i', 'c', 'e'};
    int size = 5; 

    CharLinkedList list(test_arr, size);

    list.popFromFront();

    assert(list.size() == 4);
    assert(list.first() == 'l');
}

void testPopFromFront_2() { // nonempty array
    char test_arr[] = {};
    int size = 0; 

    CharLinkedList list(test_arr, size);

    std::string error_message = "";
    bool runtime_error_thrown = false;

    try {
        list.popFromFront(); //will throw an exception
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what(); //Returns const char* describing exception
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

//Test for remove from back function
void testPopFromBack_1() { // nonempty array
    char test_arr[] = {'A', 'l', 'i', 'c', 'e'};
    int size = 5; 

    CharLinkedList list(test_arr, size);

    list.popFromBack();

    assert(list.size() == 4);
    assert(list.last() == 'c');

}

void testPopFromBack_2() { //empty array
    char test_arr[] = {};
    int size = 0; 

    CharLinkedList list(test_arr, size);

    std::string error_message = "";
    bool runtime_error_thrown = false;

    try {
        list.popFromFront(); //will throw an exception
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what(); //Returns const char* describing exception
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

//Test for remove at function 
void testRemoveAt_1() { // nonempty array
    char test_arr[] = {'A', 'l', 'i', 'c', 'e'};
    int size = 5; 
    int index = 3;

    CharLinkedList list(test_arr, size);

    list.removeAt(index);

    assert(list.size() == 4);
    assert(list.toString() == "[CharLinkedList of size 4 <<Alie>>]");
}

void testRemoveAt_2() { //empty array
    char test_arr[] = {};
    int size = 0; 
    int index = 3;

    CharLinkedList list(test_arr, size);

    std::string error_message = "";
    bool range_error_thrown = false;

    try {
        list.removeAt(index); //will throw an exception
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what(); //Returns const char* describing exception
    }

    assert(range_error_thrown);
    assert(error_message == "index (3) not in range [0..0)");
}

void testRemoveAt_3() { // nonempty array
    char test_arr[] = {'A', 'l', 'i', 'c', 'e'};
    int size = 5; 
    int index = 0;

    CharLinkedList list(test_arr, size);

    list.removeAt(index);

    assert(list.size() == 4);
    assert(list.toString() == "[CharLinkedList of size 4 <<lice>>]");
}

void testRemoveAt_4() { // nonempty array
    char test_arr[] = {'A', 'l', 'i', 'c', 'e'};
    int size = 5; 
    int index = 4;

    CharLinkedList list(test_arr, size);

    list.removeAt(index);

    assert(list.size() == 4);
    assert(list.toString() == "[CharLinkedList of size 4 <<Alic>>]");
}

void testRemoveAt_5() { //nonempty array
    char test_arr[] = {'A', 'l', 'i', 'c', 'e'};
    int size = 5; 
    int index = size + 1;

    CharLinkedList list(test_arr, size);

    std::string error_message = "";
    bool range_error_thrown = false;

    try {
        list.removeAt(index); //will throw an exception
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what(); //Returns const char* describing exception
    }

    assert(range_error_thrown);
    assert(error_message == "index (6) not in range [0..5)");
}

//Test for replace at function
void testReplaceAt_1() { // nonempty array
    char test_arr[] = {'A', 'l', 'x', 'c', 'e'};
    int size = 5; 
    int index = 2;

    CharLinkedList list(test_arr, size);

    list.replaceAt('i', index);

    assert(list.size() == 5);
    assert(list.toString() == "[CharLinkedList of size 5 <<Alice>>]");
}

void testReplaceAt_2() { //empty array
    char test_arr[] = {};
    int size = 0; 
    int index = 3;

    CharLinkedList list(test_arr, size);

    std::string error_message = "";
    bool range_error_thrown = false;

    try {
        list.replaceAt('a', index); //will throw an exception
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what(); //Returns const char* describing exception
    }

    assert(range_error_thrown);
    assert(error_message == "index (3) not in range [0..0)");
}

void testReplaceAt_3() { // nonempty array
    char test_arr[] = {'x', 'l', 'i', 'c', 'e'};
    int size = 5; 
    int index = 0;

    CharLinkedList list(test_arr, size);

    list.replaceAt('A', index);

    assert(list.size() == 5);
    assert(list.toString() == "[CharLinkedList of size 5 <<Alice>>]");
}

void testReplaceAt_4() { // nonempty array
    char test_arr[] = {'A', 'l', 'i', 'c', 'x'};
    int size = 5; 
    int index = 4;

    CharLinkedList list(test_arr, size);

    list.replaceAt('e', index);

    assert(list.size() == 5);
    assert(list.toString() == "[CharLinkedList of size 5 <<Alice>>]");
}

void testReplaceAt_5() { //empty array
    char test_arr[] = {'a', 'b'};
    int size = 2; 
    int index = 3;

    CharLinkedList list(test_arr, size);

    std::string error_message = "";
    bool range_error_thrown = false;

    try {
        list.replaceAt('a', index); //will throw an exception
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what(); //Returns const char* describing exception
    }

    assert(range_error_thrown);
    assert(error_message == "index (3) not in range [0..2)");
}

void testReplaceAt_6() { //empty array
    char test_arr[] = {'a', 'b'};
    int size = 2; 
    int index = size + 1;

    CharLinkedList list(test_arr, size);

    std::string error_message = "";
    bool range_error_thrown = false;

    try {
        list.replaceAt('a', index); //will throw an exception
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what(); //Returns const char* describing exception
    }

    assert(range_error_thrown);
    assert(error_message == "index (3) not in range [0..2)");
}

void testReplaceAt_7() { //empty array
    char test_arr[] = {'a', 'b'};
    int size = 2; 
    int index = -1;

    CharLinkedList list(test_arr, size);

    std::string error_message = "";
    bool range_error_thrown = false;

    try {
        list.replaceAt('a', index); //will throw an exception
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what(); //Returns const char* describing exception
    }

    assert(range_error_thrown);
    assert(error_message == "index (-1) not in range [0..2)");
}

// Test for concatenating lists
void testConcatenating_1() { // nonempty lists
    char test_arr_1[] = {'A', 'l', 'i', 'c', 'e'};
    int size_1 = 5; 
    CharLinkedList list_1(test_arr_1, size_1);

    char test_arr_2[] = {'R', 'a', 'b', 'b', 'i', 't'};
    int size_2 = 6; 
    CharLinkedList list_2(test_arr_2, size_2);

    list_1.concatenate(&list_2);

    assert(list_1.size() == 11);
    assert(list_1.toString() == "[CharLinkedList of size 11 <<AliceRabbit>>]");
}

void testConcatenating_2() { // nonempty list with empty list
    char test_arr_1[] = {'A', 'l', 'i', 'c', 'e'};
    int size_1 = 5; 
    CharLinkedList list_1(test_arr_1, size_1);

    CharLinkedList list_2;

    list_1.concatenate(&list_2);

    assert(list_1.size() == 5);
    assert(list_1.toString() == "[CharLinkedList of size 5 <<Alice>>]");
}

void testConcatenating_3() { // empty list with nonempty list
    CharLinkedList list_1;

    char test_arr_2[] = {'A', 'l', 'i', 'c', 'e'};
    int size_2 = 5; 
    CharLinkedList list_2(test_arr_2, size_2);


    list_1.concatenate(&list_2);
    assert(list_1.size() == 5);
    assert(list_1.toString() == "[CharLinkedList of size 5 <<Alice>>]");
}

void testConcatenating_4() { // nonempty list with itself
    char test_arr_1[] = {'A', 'l', 'i', 'c', 'e'};
    int size_1 = 5; 
    CharLinkedList list_1(test_arr_1, size_1);

    list_1.concatenate(&list_1);

    assert(list_1.size() == 10);
    assert(list_1.toString() == "[CharLinkedList of size 10 <<AliceAlice>>]");
}

void testConcatenating_5() { //empty array with itself
    CharLinkedList list_1;

    list_1.concatenate(&list_1);

    assert(list_1.size() == 0);
    assert(list_1.toString() == "[CharLinkedList of size 0 <<>>]"); 
}

void testConcatenating_6() { //empty array with itself
    CharLinkedList list_1;
    CharLinkedList list_2;

    list_1.concatenate(&list_2);

    assert(list_1.size() == 0);
    assert(list_1.toString() == "[CharLinkedList of size 0 <<>>]"); 
}

//Test for the third constructor
void thirdConstructorTest_1() { // nonempty array
    char test_arr[] = {'A', 'l', 'i', 'c', 'e'};
    int size = 5;
    CharLinkedList list_2(test_arr, size);

    CharLinkedList list_1(list_2);

    assert(list_2.size() == list_1.size());
    assert(list_2.toString() == list_1.toString());
}

void thirdConstructorTest_2() { //empty array
    char test_arr[] = {};
    int size = 0;
    CharLinkedList list_2(test_arr, size);

    CharLinkedList list_1(list_2);

    assert(list_2.size() == list_1.size());
    assert(list_2.toString() == list_1.toString());
}

//test for the assignment operator 
void AssignmentOperatorTest_1 () { //non empty lists
    char test_arr[] = {'A', 'l', 'i', 'c', 'e'};
    int size = 5;
    CharLinkedList list_2(test_arr, size);

    char test_arr2[] = {'A', 'l', 'i', 'c', 'e', 'f'};
    int size2 = 6;
    CharLinkedList list_1(test_arr2, size2);

    list_1 = list_2;

    assert(list_2.size() == list_1.size());
    assert(list_2.toString() == list_1.toString());
}

//Test for continously using functions
void testMany_1 () { //non empty lists
    char test_arr[] = {'A', 'l', 'i', 'c', 'e'};
    int size = 5;
    CharLinkedList list_1(test_arr, size);

    list_1.removeAt(0);
    assert(list_1.size() ==  4);

    list_1.removeAt(2);
    assert(list_1.size() ==  3);

    CharLinkedList list_2('a');

    list_1.concatenate(&list_2);
    assert(list_1.size() == 4);
    assert(list_1.toString() == "[CharLinkedList of size 4 <<liea>>]");
    assert(list_1.first() == 'l');
    assert(list_1.elementAt(1) == 'i');
}
/*
 *  unit_tests.h
 *  Alina Xie
 *  2/2/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  Test the functions in CharLinkedList.cpp and make sure that 
 *  functions produce the correct output.
 *
 */

#include "CharLinkedList.h"
#include <cassert>

using namespace std;

// tests isEmpty for an empty list
void isEmpty_emptyList() {
    CharLinkedList test_list;
    assert(test_list.isEmpty());
}

// tests isEmpty for an non-empty list
void isEmpty_nonEmptyList() {
    char test_arr[7] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f'};
    CharLinkedList test_list(test_arr, 7);
    assert(not(test_list.isEmpty()));
}

// test size for an empty list
void sizeEmptyList_test() {
    CharLinkedList test_list;
    assert(test_list.size() == 0);
}

// test size for a non-empty list
void sizeNonEmptyList_test() {
    char test_arr1[1] = {'a'};
    CharLinkedList test_list1(test_arr1, 1);
    assert(test_list1.size() == 1);

    char test_arr2[5] = {'h', 'e', 'l', 'l', 'o'};
    CharLinkedList test_list2(test_arr2, 5);
    assert(test_list2.size() == 5);
}

// tests insertAt into an empty list
void insertAtEmptyList_test() {
    CharLinkedList test_list;
    test_list.insertAt('a', 0);
    assert(test_list.toString() == "[CharLinkedList of size 1 <<a>>]");
}

// test insertAt into beginning of an non-empty list
void insertAt_FrontNonEmptyList_test() {
    char test_arr[7] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f'};
    CharLinkedList test_list(test_arr, 7);
    test_list.insertAt('a', 0);
    assert(test_list.toString() == 
    "[CharLinkedList of size 8 <<aabczdef>>]");
}

// test insertAt into middle of an non-empty list
void insertAt_MidNonEmptyList_test() {
    char test_arr[7] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f'};
    CharLinkedList test_list(test_arr, 7);
    test_list.insertAt('m', 3);
    assert(test_list.toString() == 
    "[CharLinkedList of size 8 <<abcmzdef>>]");
    test_list.insertAt('n', 4);
    assert(test_list.toString() == 
    "[CharLinkedList of size 9 <<abcmnzdef>>]");
}

// test insertAt into end of an non-empty list
void insertAt_BackNonEmptyList_test() {
    char test_arr[7] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f'};
    CharLinkedList test_list(test_arr, 7);
    
    test_list.insertAt('i', 6);
    assert(test_list.toString() == 
    "[CharLinkedList of size 8 <<abczdeif>>]");
}

// test insertAt length of list of an non-empty list
void insertAt_AtEndNonEmptyList_test() {
    char test_arr[7] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f'};
    CharLinkedList test_list(test_arr, 7);
    
    test_list.insertAt('i', 7);
    assert(test_list.toString() == 
    "[CharLinkedList of size 8 <<abczdefi>>]");
}

// tests insertAt for an invalid index
void insertAtInvalidIndex_test() {
    char test_arr[5] = { 'h', 'e', 'l', 'l', 'o'};
    CharLinkedList test_list(test_arr, 5);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;
    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.insertAt('z', -1);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (-1) not in range [0..5]");
}

// tests clear on non-empty list by checking that the size of the list is 0
void clearSize_NonEmptyList_test() {
    char test_arr[7] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f'};
    CharLinkedList test_list(test_arr, 7);
    test_list.clear();
    assert(test_list.size() == 0);
}

// tests clear on empty list by checking that the size of the list is 0
void clearSizeEmptyList_test() {
    CharLinkedList test_list;
    test_list.clear();
    assert(test_list.size() == 0);
}

// tests clear on non-empty list and if it returns true for isEmpty
void clearNonEmptyList_CheckEmpty() {
    char test_arr[7] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f'};
    CharLinkedList test_list(test_arr, 7);
    test_list.clear();
    assert(test_list.isEmpty());
}

// tests first for a non-empty list
void first_test() {
    char test_arr[7] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f'};
    CharLinkedList test_list(test_arr, 7);
    assert(test_list.first() == 'a');
}

// test first for an empty list and prints error message
void firstEmptyList_test() {
     CharLinkedList test_list;
  
    // var to track whether runtime_error is thrown
    bool runtime_error_thrown = false;
    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.first();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "cannot get first of empty LinkedList");
} 

// tests last for a non-empty list
void last_test() {
    char test_arr[7] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f'};
    CharLinkedList test_list(test_arr, 7);
    assert(test_list.last() == 'f');
}

// test first and last for an empty list and prints error messages
void lastEmptyList_test() {
    CharLinkedList test_list;
  
    // var to track whether runtime_error is thrown
    bool runtime_error_thrown = false;
    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.last();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "cannot get last of empty LinkedList");
}

// tests elementAt with valid indexes in the middle of the list
void elementAtMid_test() {
    char test_arr[5] = { 'w', 'a', 't', 'e', 'r'};
    CharLinkedList test_list(test_arr, 5);
    assert(test_list.elementAt(1) == 'a');
    assert(test_list.elementAt(2) == 't');
    assert(test_list.elementAt(3) == 'e');
}

// tests elementAt at the front of the list
void elementAtFront_test() {
    char test_arr[5] = { 'w', 'a', 't', 'e', 'r'};
    CharLinkedList test_list(test_arr, 5);
    assert(test_list.elementAt(0) == 'w');
}

// tests elementAt at the end of the list
void elementAtBack_test() {
    char test_arr[5] = { 'w', 'a', 't', 'e', 'r'};
    CharLinkedList test_list(test_arr, 5);
    assert(test_list.elementAt(4) == 'r');
}

// test elementAt if there is an invalid index and prints the 
// error message
void elementAtInvalidIndex_test() {
    char test_arr[5] = { 'h', 'e', 'l', 'l', 'o'};
    CharLinkedList test_list(test_arr, 5);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;
    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.elementAt(6);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (6) not in range [0..5)");
}

// tests toReverseString method
void toReverseString_test() {
    char test_arr[7] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g'};
    CharLinkedList test_list(test_arr, 7);
    assert(test_list.toReverseString() == 
    "[CharLinkedList of size 7 <<gfedcba>>]");

    char test_arr1[5] = { 'a', 'p', 'p', 'l', 'e'};
    CharLinkedList test_list1(test_arr1, 5);
    assert(test_list1.toReverseString() == 
    "[CharLinkedList of size 5 <<elppa>>]");
}

// tests pushAtFront method
void pushAtFront_test() {
    char test_arr[7] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g'};
    CharLinkedList test_list(test_arr, 7);

    test_list.pushAtFront(test_list.elementAt(6));
    assert(test_list.toString() == 
    "[CharLinkedList of size 8 <<gabcdefg>>]");
}

// tests pushAtBack method
void pushAtBack_test() {
    char test_arr[7] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g'};
    CharLinkedList test_list(test_arr, 7);

    test_list.pushAtBack(test_list.elementAt(2));
    assert(test_list.toString() == 
    "[CharLinkedList of size 8 <<abcdefgc>>]");
}

// tests insertInOrder for char 'a' and inserts 'a' at the front of the list
void insertInOrder_a_test() {
    char test_arr[6] = { 'a', 'c', 'd', 'e', 'f', 'y'};
    CharLinkedList test_list(test_arr, 6);
    test_list.insertInOrder('a');
    assert(test_list.toString() == "[CharLinkedList of size 7 <<aacdefy>>]");
}

// tests insertInOrder for char 'y' and inserts 'y' at the end of the list
void insertInOrder_y_test() {
    char test_arr[7] = { 'a', 'a', 'c', 'd', 'e', 'f', 'y'};
    CharLinkedList test_list(test_arr, 7);
    test_list.insertInOrder('y');
    assert(test_list.toString() == "[CharLinkedList of size 8 <<aacdefyy>>]");
}

// tests insertInOrder for chars that greater than the first element and 
// less than the last element
void insertInOrder_middleChars() {
    char test_arr[8] = { 'a', 'a', 'c', 'd', 'e', 'f', 'y', 'y'};
    CharLinkedList test_list(test_arr, 8);
    test_list.insertInOrder('b');
    assert(test_list.toString() == 
    "[CharLinkedList of size 9 <<aabcdefyy>>]");

    test_list.insertInOrder('m');
    assert(test_list.toString() == 
    "[CharLinkedList of size 10 <<aabcdefmyy>>]");
}

// tests insertInOrder for an empty list
void insertInOrder_EmptyList() {
    CharLinkedList test_list;
    test_list.insertInOrder('x');
    assert(test_list.toString() == "[CharLinkedList of size 1 <<x>>]");
}

// tests popFromFront for a non-empty list
void popFromFront_nonEmpty() {
    char test_arr[5] = {'w', 'a', 't', 'e', 'r'};
    CharLinkedList test_list(test_arr, 5);
    test_list.popFromFront();
    assert(test_list.toString() == "[CharLinkedList of size 4 <<ater>>]");

    test_list.popFromFront();
    assert(test_list.toString() == "[CharLinkedList of size 3 <<ter>>]");
}

// tests popFromBack for a non-empty list
void popFromBack_nonEmpty() {
    char test_arr[5] = {'w', 'a', 't', 'e', 'r'};
    CharLinkedList test_list(test_arr, 5);

    test_list.popFromBack();
    assert(test_list.toString() == "[CharLinkedList of size 4 <<wate>>]");

    test_list.popFromBack();
    assert(test_list.toString() == "[CharLinkedList of size 3 <<wat>>]");
}

// test popFromFront for an empty list and prints the error message
void popFromFrontEmpty_test() {
    CharLinkedList test_list;

    // var to track whether runtime_error is thrown
    bool runtime_error_thrown = false;
    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.popFromFront();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

// test popFromFront for an empty list and prints the error message
void popFromBackEmpty_test() {
    CharLinkedList test_list;

    // var to track whether runtime_error is thrown
    bool runtime_error_thrown = false;
    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.popFromBack();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

// tests removeAt for the valid index 0 and removes the first element
void removeAtFront_test() {
    char test_arr[6] = { 'a', 'c', 'd', 'e', 'f', 'y'};
    CharLinkedList test_list(test_arr, 6);

    test_list.removeAt(0);
    assert(test_list.toString() == "[CharLinkedList of size 5 <<cdefy>>]");
}

// tests removeAt for valid indexes that are greater than the front index
// and less than the index of the last element
void removeAtMiddle_test() {
    char test_arr[6] = {'a', 'c', 'd', 'e', 'f', 'y'};
    CharLinkedList test_list(test_arr, 6);

    test_list.removeAt(2);
    assert(test_list.toString() == "[CharLinkedList of size 5 <<acefy>>]");

    test_list.removeAt(3);
    assert(test_list.toString() == "[CharLinkedList of size 4 <<acey>>]");
}

// tests removeAt for the valid index of the list size
void removeAtEnd_test() {
    char test_arr[6] = {'a', 'c', 'd', 'e', 'f', 'y'};
    CharLinkedList test_list(test_arr, 6);

    test_list.removeAt(5);
    assert(test_list.toString() == "[CharLinkedList of size 5 <<acdef>>]");
}

// tests removeAt with an invalid index and prints error message
void removeAtInvalidIndex_test() {
    char test_arr[6] = { 'a', 'c', 'd', 'e', 'f', 'y'};
    CharLinkedList test_list(test_arr, 6);

     // var to track whether range_error is thrown
    bool range_error_thrown = false;
    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.elementAt(6);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (6) not in range [0..6)");
}

// tests replaceAt with valid indexes in the middle of the list
void replaceAtMiddle_test() {
    char test_arr[6] = {'w', 'a', 't', 'e', 'r', 's'};
    CharLinkedList test_list(test_arr, 6);

    test_list.replaceAt('b', 2);
    assert(test_list.toString() == "[CharLinkedList of size 6 <<wabers>>]");

    test_list.replaceAt('z', 3);
    assert(test_list.toString() == "[CharLinkedList of size 6 <<wabzrs>>]");
}

// tests replaceAt with valid index 0 
void replaceAtFront_test() {
    char test_arr[6] = {'w', 'a', 't', 'e', 'r', 's'};
    CharLinkedList test_list(test_arr, 6);

    test_list.replaceAt('x', 0);
    assert(test_list.toString() == "[CharLinkedList of size 6 <<xaters>>]");
}

// test replaceAtBack with the index of the list size
void replaceAtBack_test() {
    char test_arr[6] = {'w', 'a', 't', 'e', 'r', 's'};
    CharLinkedList test_list(test_arr, 6);

    test_list.replaceAt('l', 5);
    assert(test_list.toString() == "[CharLinkedList of size 6 <<waterl>>]");
}

// tests replaceAt with an invalid index. Prints the error message
void replaceAtInvalidIndex_test() {
    char test_arr[5] = {'w', 'a', 't', 'e', 'r'};
    CharLinkedList test_list(test_arr, 5);

     // var to track whether range_error is thrown
    bool range_error_thrown = false;
    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.replaceAt('a', -1);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (-1) not in range [0..5)");
}

// tests concatente with a non-empty list
void concatenate_test() {
    char test_arr[5] = {'w', 'a', 't', 'e', 'r'};
    CharLinkedList test_list(test_arr, 5);
    char test_arr1[5] = {'m', 'e', 'l', 'o', 'n'};
    CharLinkedList test_list1(test_arr1, 5);

    test_list.concatenate(&test_list1);
    assert(test_list.toString() == 
    "[CharLinkedList of size 10 <<watermelon>>]");

    test_list.concatenate(&test_list1);
    assert(test_list.toString() == 
    "[CharLinkedList of size 15 <<watermelonmelon>>]");
}

// tests concatente with a non-empty list
void concatenateItself_test() {
    char test_arr[5] = {'h', 'e', 'l', 'l', 'o'};
    CharLinkedList test_list(test_arr, 5);

    test_list.concatenate(&test_list);
    assert(test_list.toString() == 
    "[CharLinkedList of size 10 <<hellohello>>]");
}

void concatenateEmptyList_test() {
    CharLinkedList test_list1;
    char test_arr[5] = {'h', 'e', 'l', 'l', 'o'};
    CharLinkedList test_list(test_arr, 5);

    test_list.concatenate(&test_list1);
    assert(test_list.toString() == 
    "[CharLinkedList of size 5 <<hello>>]");
}

// test insertAt in the middle 100 times
void insertAtMiddle_100() {
    char test_arr[5] = {'w', 'a', 't', 'e', 'r'};
    CharLinkedList test_list(test_arr, 5);
    const int DEFAULT_NUM_OPS   = 100;
    const char DUMMY_CHAR = 'a';
    int curr_size = 5;

    for (int i = 0; i < DEFAULT_NUM_OPS; i++) {
        test_list.insertAt(DUMMY_CHAR, curr_size / 2);
        curr_size++;
    }

    assert(test_list.size() == 5 + DEFAULT_NUM_OPS);
}

// test the default constructor
void constructor_test() {
    // invoke the default constructor
    CharLinkedList test_list1;
    assert(test_list1.size() == 0);
}

// test the copy constructor
void copyConstructor_test() {
    char test_arr2[3] = {'a', 'b', 'c'};
    CharLinkedList test_list2(test_arr2, 3);

    // invoke the copy constructor
    CharLinkedList test_list3(test_list2);
    assert(test_list3.toString() == "[CharLinkedList of size 3 <<abc>>]");
}

// tests assignment operator for non-empty list
void assignmentOperator_nonEmpty() {
    char test_arr1[3] = {'d', 'e', 'f'};
    CharLinkedList test_list1(test_arr1, 3);
    char test_arr2[3] = {'a', 'b', 'c'};
    CharLinkedList test_list2(test_arr2, 3);

    test_list2 = test_list1;
    assert(test_list1.toString() == test_list2.toString());
}

// test assignment operator
void assignmentOperator_test() {
    char test_arr1[3] = {'d', 'e', 'f'};
    CharLinkedList test_list1(test_arr1, 3);
    CharLinkedList test_list2;

    test_list2 = test_list1;
    assert(test_list1.toString() == test_list2.toString());
}




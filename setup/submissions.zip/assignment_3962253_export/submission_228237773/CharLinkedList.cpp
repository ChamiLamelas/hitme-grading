/*
 *  CharLinkedList.cpp
 *  Alina Xie
 *  2/2/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Implement a doubly linked data structure that contains characters
 *
 */

#include "CharLinkedList.h"
#include <sstream>
#include <stdexcept>
#include <iostream>

using namespace std;

/*
 * name:      CharLinkedList default constructor
 * purpose:   initialize an empty CharLinkedList
 * arguments: none
 * returns:   none
 * effects:   length to 0
 */
CharLinkedList::CharLinkedList() {
    front = nullptr;
    length = 0;
}

/*
 * name:      newNode
 * purpose:   helper function that creates a new node on the heap
 * arguments: a char with the data and a node pointer
 * returns:   a new node
 */
CharLinkedList::Node *CharLinkedList::newNode(char newInfo, Node *next) {
    // assign data to a new Node on the heap
    Node *new_node = new Node;

    new_node->info = newInfo;
    new_node->next = next;
    new_node->prev = nullptr;
    
    return new_node;
}

/*
 * name:      CharLinkedList constructor
 * purpose:   initialize a CharLinkedList with one charcter
 * arguments: a char that will be added to the linked list
 * returns:   none
 * effects:   length to 1
 */
CharLinkedList::CharLinkedList(char c) {
    length = 1;
    front = newNode(c, nullptr);
}

/*
 * name:      CharLinkedList constructor
 * purpose:   creates an linked list containing the characters in the array
 * arguments: an array of characters and the int length of that array
 * returns:   none
 * effects:   length to array length
 */
CharLinkedList::CharLinkedList(char arr[], int size) {
    length = size;
    Node *curr = nullptr;
    Node *temp = nullptr;
    int index = 0;
    front = nullptr;

    // iterate while index is less than the size and create new 
    // nodes for the chars
    while(index < size) {
        curr = newNode(arr[index], nullptr);
        if(front == nullptr) {
            front = curr;
        }
        if(temp != nullptr) {
            temp->next = curr;
            curr->prev = temp;
        }

        temp = curr;
        index++;
    }

}

/*
 * name:      CharLinkedList copy constructor
 * purpose:   makes a copy of a given instance
 * arguments: address an other CharLinkedList
 * returns:   none
 * effects:   length to length of other
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other) {
    length = other.length;
    Node *oCurr = other.front;
    front = nullptr;
    Node *curr = nullptr;
    Node *temp = nullptr;

    while(oCurr != nullptr) {
        curr = newNode(oCurr->info, nullptr);
        if(front == nullptr) {
            front = curr;
        }
        if(temp != nullptr) {
            temp->next = curr;
            curr->prev = temp;
        }
        temp = curr;
        oCurr = oCurr->next;
    }
}

/*
 * name:      CharLinkedList destructor
 * purpose:   free memory associated with the CharLinkedList
 * arguments: none
 * returns:   none
 * effects:   frees memory allocated by CharArraylist instances
 */
CharLinkedList::~CharLinkedList() {
    recycle(front);
    front = nullptr;
    length = 0;
}

/*
 * name:      recycle
 * purpose:   helper function that recycles each node in the list beginning
 *            at curr
 * arguments: Node pointer
 * returns:   none
 * effects:   deletes the nodes
 */
void CharLinkedList::recycle(Node *curr) {
    if(curr == nullptr) {
        return;
    }

    else {
        Node *next = curr->next;
        delete curr;
        recycle(next);
    }
}

/*
 * name:      operator
 * purpose:   recycles the storage associated with the instance on the left 
 *            of the assignment operator and makes a deep copy of the instance
 *            on the right side into the instance on the left side
 * arguments: address an other CharLinkedList
 * returns:   this pointer
 */
CharLinkedList & CharLinkedList::operator=(const CharLinkedList &other) {
    // clear the linked list to recycle everything
    clear();
    
    length = other.length;
    Node *oCurr = other.front;
    front = nullptr;
    Node *curr = nullptr;
    Node *temp = nullptr;

    while(oCurr != nullptr) {
        curr = newNode(oCurr->info, nullptr);
        if(front == nullptr) {
            front = curr;
        }
        if(temp != nullptr) {
            temp->next = curr;
            curr->prev = temp;
        }
        temp = curr;
        oCurr = oCurr->next;
    }

    return *this;
}

/*
 * name:      isEmpty
 * purpose:   determines if the CharLinkedList is empty or not
 * arguments: none
 * returns:   true if CharLinkedList contains no elements, false otherwise
 * effects:   none
 */
bool CharLinkedList::isEmpty() const {
    if(front == nullptr) {
        return true;
    }

    else {
        return false;
    }
}

/*
 * name:      clear
 * purpose:   empties the linked list
 * arguments: none
 * returns:   none
 * effects:   length to 0
 */
void CharLinkedList:: clear() {
    if(front == nullptr) {
        return;
    }

    Node *n = front;
    // delete all of the nodes in the linked list
    while(n != nullptr) {
        Node *next = n->next;
        delete n;
        n = next;
    }
    front = nullptr;
    length = 0;
}

/*
 * name:      size
 * purpose:   determine the number of items in the CharLinkedList
 * arguments: none
 * returns:   the length of the linked list
 * effects:   none
 */
int CharLinkedList::size() const {
    if(isEmpty()) {
        return 0;
    }

    return length;
}

/*
 * name:      calculateLength
 * purpose:   helper function to calculate the length of the linked list
 * arguments: none
 * returns:   updated length of the linked list
 * effects:   none
 */
int CharLinkedList::calculateLength() {
    Node *curr = front;

    // set length to 0 to make sure the counting will be correct
    length = 0;
    // increment length for all of the chars in the linked list
    while(curr != nullptr) {
        length++;
        curr = curr->next;
    }

    return length;
}

/*
 * name:      first
 * purpose:   returns the first character in the linked list
 * arguments: none
 * returns:   first character in the linked list
 * effects:   none
 */
char CharLinkedList::first() const {
    if(isEmpty()) {
        throw runtime_error("cannot get first of empty LinkedList");
    }

    else {
        return front->info;
    }
}

/*
 * name:      last
 * purpose:   returns the last character in the linked list
 * arguments: none
 * returns:   last character in the linked list
 * effects:   none
 */
char CharLinkedList::last() const {
    if(isEmpty()) {
        throw runtime_error("cannot get last of empty LinkedList");
    }

    else {
        Node *last = front;
        // find last node
        while(last != nullptr and last->next != nullptr) {
            last = last->next;
        }

        return last->info;
    }
}

/*
 * name:      elementAt
 * purpose:   returns the character in the linked list at the index
 * arguments: an integer index
 * returns:   character in the linked list at the index
 * effects:   none
 */
char CharLinkedList::elementAt(int index) const {
    if(index < 0  or index >= length) {
        std::string message;
        message = "index (";
        message += std::to_string(index);
        message += ") not in range [0..";
        message += std::to_string(length);
        message += ")";
        throw range_error(message);
    }

    Node *curr = front;
    return elementAtHelper(curr, index, 0);
}

/*
 * name:      elementAtHelper
 * purpose:   recursive helper function to find the element at a given index
 * arguments: Node pointer, given integer index, and an int to compare with 
 *            given index
 * returns:   character in the array list at the index
 * effects:   none
 */
char CharLinkedList::elementAtHelper(Node *curr, int i, int currIndex) const {
    // increment currIndex until it equals i and return the char at curr
    if(currIndex == i) {
        return curr->info;
    }

    else {
        curr = curr->next;
        currIndex++;
        return elementAtHelper(curr, i, currIndex);
    }
    
}

/*
 * name:      toString
 * purpose:   returns the a string containing the characters of the linked
 *            list and its size
 * arguments: none
 * returns:   string containing the characters of the linked list and 
 *            its size
 * effects:   none
 */
std::string CharLinkedList::toString() const {
    std::stringstream ss;
    ss << "[CharLinkedList of size " << length << " <<";
    Node *curr = front;
    while(curr != nullptr) {
        ss << curr->info;
        curr = curr->next;
    }
    ss << ">>]";
    return ss.str();
}

/*
 * name:      toReverseString
 * purpose:   returns the a string containing the characters of the linked
 *            list in reverse order and its size
 * arguments: none
 * returns:   string containing the characters of the linked list in reverse
 *            order and its size
 * effects:   none
 */
std::string CharLinkedList::toReverseString() const {
    std::stringstream ss;
    ss << "[CharLinkedList of size " << length << " <<";
    Node *back = findBack(front);

    // print chars starting from the back of the linked list
    while(back != nullptr) {
        ss << back->info;
        back = back->prev;
    }

    ss << ">>]";
    return ss.str();
}

/*
 * name:      findBack
 * purpose:   recursive helper function to get the back node of the linked
 *            list
 * arguments: Node pointer
 * returns:   pointer to the end of the linked list
 */
CharLinkedList::Node *CharLinkedList::findBack(Node *back) const {
    Node *curr = back;
    // finds the last element in the linked list
    while(curr != nullptr and curr->next != nullptr) {
        curr = curr->next;
    }
    return curr;
}

/*
 * name:      pushAtBack
 * purpose:   inserts a char at the end of the elements in the linked list
 * arguments: a character 
 * returns:   none
 * effects:   length increases by 1
 */
void CharLinkedList::pushAtBack(char c) {
    if(length == 0 and not(isEmpty())) {
        calculateLength();
    }

    Node *last = front;
    // finds the last element in the linked list
    while(last != nullptr and last->next != nullptr) {
        last = last->next;
    }

    // creates a new node with the char
    Node *node = newNode(c, nullptr);

    if(last == nullptr) {
        front = node;
    }
    else {
        last->next = node;
        node->prev = last;
    }
    
    length++;
}

/*
 * name:      pushAtFront
 * purpose:   inserts a char at the front of the elements in the linked list
 * arguments: a character 
 * returns:   none
 * effects:   length increases by 1
 */
void CharLinkedList::pushAtFront(char c) {
    if(length == 0 and not(isEmpty())) {
        calculateLength();
    }

    Node *temp = front;
    // create a new node with the char at front
    front = newNode(c, front);
    if(temp != nullptr) {
        temp->prev = front;
    }
    length++;
}

/*
 * name:      insertAt
 * purpose:   inserts a character at the index
 * arguments: a character and an integer index
 * returns:   none
 * effects:   length increases by 1
 */
void CharLinkedList::insertAt(char c, int index) {
    if(length == 0 and not(isEmpty())) {
        calculateLength();
    }
    // if index equals 0 pushAtFront and if index equals length pushAtBack
    if(index == 0) {
        pushAtFront(c);
        return;
    }
    if(index == length) {
        pushAtBack(c);
        return;
    }
    if(index < 0  or index > length) {
        std::string message;
        message = "index (";
        message += std::to_string(index);
        message += ") not in range [0..";
        message += std::to_string(length);
        message += "]";
        throw range_error(message);
    }

    Node *curr = front;
    int currIndex = 0;
    // stop the loop at the element before index
    while(currIndex < index - 1) {
        curr = curr->next;
        currIndex++;
    }
    // create new node with the char at next of curr
    Node *temp = newNode(c, curr->next);
    curr->next->prev = temp;
    temp->prev = curr;
    curr->next = temp;
    length++;
}

/*
 * name:      insertInOrder
 * purpose:   inserts a character into the linked list in ascending order
 * arguments: a character 
 * returns:   none
 * effects:   length increases by 1
 */
void CharLinkedList::insertInOrder(char c) {
    Node* curr = front;
    Node* back = findBack(front);

    // if list is empty, push front c
    if(isEmpty()) {
        pushAtFront(c);
        return;
    }

    // if c is the same or less than the 1st character, push front c
    if(curr->info >= c) {
        pushAtFront(c);
        return;
    }

    // if c is the same or greater than the last character, push back c
    if(back->info <= c) {
        pushAtBack(c);
        return;
    }

    int index = 0; 
    int i = 0;
    bool found = false;
    // find the index for when c is greater than or equal to a character
    // and less than the next character
    while(not found and curr != nullptr and curr->next != nullptr) {
        if(curr->info <= c and c < curr->next->info) {
            index = i + 1;
            found = true;
        }
        curr = curr->next;
        i++;
    } 

   insertAt(c, index);
}

/*
 * name:      popFromFront
 * purpose:   removes the first element from the linked list
 * arguments: none
 * returns:   none
 * effects:   length decreases by 1
 */
void CharLinkedList::popFromFront() {
    if(isEmpty()) {
        throw runtime_error("cannot pop from empty LinkedList");
    }

    if(length == 0) {
        calculateLength();
    }

    Node *temp = front;
    front = temp->next;

    if(front != nullptr) {
       front->prev = nullptr;
    }

    length--;

    delete temp;

}

/*
 * name:      popFromBack
 * purpose:   removes the last element from the linked list
 * arguments: none
 * returns:   none
 * effects:   length decreases by 1
 */
void CharLinkedList::popFromBack() {
    if(isEmpty()) {
        throw runtime_error("cannot pop from empty LinkedList");
    }

    if(length == 0) {
        calculateLength();
    }

    Node *curr = front;
    Node *prevNode = nullptr;

    // find the last node while keeping track of the previous node,
    // set the second to last node to nullptr,
    while(curr != nullptr and curr->next != nullptr) {
        prevNode = curr;
        curr = curr->next;
    }

    if(prevNode != nullptr) {
        prevNode->next = nullptr;
    }

    // decrement the length and delete the last node
    length--;
    delete curr;
}

/*
 * name:      removeAt
 * purpose:   removes a character at an index
 * arguments: an integer index
 * returns:   none
 * effects:   length decreases by 1
 */
void CharLinkedList::removeAt(int index) {
    if(length == 0 and not(isEmpty())) {
        calculateLength();
    }
    // if index equals 0, popFromFront()
    if(index == 0) {
        popFromFront();
        return;
    }
    if(index < 0 or index >= length) {
        std::string message;
        message = "index (";
        message += std::to_string(index);
        message += ") not in range [0..";
        message += std::to_string(length);
        message += ")";
        throw range_error(message);
    }
    // if index equals length - 1, popFromBack()
    if(index == length - 1) {
        popFromBack();
        return;
    }

    Node *curr = front;
    int currIndex = 0;
    // find the node at index
    while(currIndex < index) {
        curr = curr->next;
        currIndex++;
    } 
    Node *prevNode = curr->prev;
    prevNode->next = curr->next;
    curr->next->prev = prevNode;
    length--;
    delete curr;
}

/*
 * name:      replaceAt
 * purpose:   replaces a character at an index
 * arguments: a character and an integer index
 * returns:   none
 * effects:   none
 */
void CharLinkedList::replaceAt(char c, int index) {
    if(isEmpty()) {
        return;
    }
    if(length == 0) {
        calculateLength();
    }
    if(index < 0 or index >= length) {
        std::string message;
        message = "index (";
        message += std::to_string(index);
        message += ") not in range [0..";
        message += std::to_string(length);
        message += ")";
        throw range_error(message);
    }

    Node *curr = front;
    replaceAtHelper(curr, index, 0, c);
}

/*
 * name:      replaceAtHelper
 * purpose:   recursive helper function that replaces a character at an index
 * arguments: Node pointer, the given integer index, an int to compare with
 *            the index, the given character
 * returns:   none
 */
void CharLinkedList::replaceAtHelper(Node* curr, int i, int currI, char c) {
    // when currI equals i, assign curr->info to c
    if(currI == i) {
        curr->info = c;
    }
    else {
        curr = curr->next;
        currI++;
        replaceAtHelper(curr, i, currI, c);
    }
}

/*
 * name:      concatenate
 * purpose:   adds a copy of the linked list pointed to by the parameter
 *            to the end of the linked list that the function was called from
 * arguments: a pointer to a CharLinkedList
 * returns:   none
 * effects:   none
 */
void CharLinkedList::concatenate(CharLinkedList *other) {
    if(other == nullptr) {
        return;
    }

    // If list concatenates itself create a copy of other if 
    // this equals temp
    CharLinkedList temp;
    if(this == other) {
        temp = *other;
        other = &temp;
    }

    // push back the characters from the other linked list to the linked 
    // list the function was called from
    for(int i = 0; i < other->size(); i++) {
        char c = other->elementAt(i);
        pushAtBack(c);
    }
}
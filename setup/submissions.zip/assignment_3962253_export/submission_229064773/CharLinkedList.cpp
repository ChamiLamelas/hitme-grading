/*
 *  CharLinkedList.cpp
 *  Peter Ren (jren03)
 *  02/01/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Function definitions for the CharLinkedList class
 *
 */

#include "CharLinkedList.h"
#include <sstream>

/*
 * name:      CharLinkedList default constructor
 * purpose:   initializes an empty linked list
 * arguments: none
 * returns:   none
 * effects:   size to 0
 */
CharLinkedList::CharLinkedList() {
    head = nullptr;
    tail = nullptr;
    listSize = 0;
}

/*
 * name:      CharLinkedList second constructor
 * purpose:   takes in a character and initializes a one-element CharLinkedList
 * arguments: a character to add to the list
 * returns:   none
 * effects:   creates a one-element array list consisting of that character
 */
CharLinkedList::CharLinkedList(char c) {
    head = new Node;
    head->data = c;
    head->prev = nullptr;
    head->next = nullptr;
    tail = head;
    listSize = 1;
}

/*
 * name:      CharLinkedList third constructor
 * purpose:   initialize a CharLinkedList taking an array of characters
 * arguments: an array of characters and the integer length 
 *            of that array of characters
 * returns:   none
 * effects:   creates a linked list containing the characters in the array
 */
CharLinkedList::CharLinkedList(char arr[], int size) {
    head = nullptr;
    tail = nullptr;
    listSize = 0;

    for (int i = 0; i < size; ++i) {
        Node* newNode = new Node;
        newNode->data = arr[i];
        newNode->prev = tail;
        newNode->next = nullptr;

        // link to the next Node from the preceding Node
        // and update the tail Node
        if (tail != nullptr) {
            tail->next = newNode;
        }
        tail = newNode;

        if (head == nullptr) {
            head = newNode;
        }
        listSize++;
    }
}

/*
 * name:      CharLinkedList copy constructor
 * purpose:   To make a deep copy of a given instance.
 * arguments: a reference to a CharLinkedList called "other"
 * returns:   nothing.
 * effects:   creates a deep copy of an instance
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other) {
    head = nullptr;
    tail = nullptr;
    listSize = 0;

    Node *curr = other.head;
    copyList(curr);
}

/*
 * name:      CharLinkedList destructor
 * purpose:   free memory associated with the CharLinkedList
 * arguments: none
 * returns:   none
 * effects:   frees memory allocated by CharLinkedlist instances
 */
CharLinkedList::~CharLinkedList() {
    recycleRecursive(head);
}

/*
 * name:      CharLinkedList assignment operator
 * purpose:   recycles the storage associated with the instance on the left 
 *            of the assignment and makes a deep copy of the instance on the 
 *            right hand side into the instance on the left hand side.
 * arguments: a reference to a CharLinkedList object
 * returns:   a reference to the CharLinkedList object 
 *            that is on the left-hand side of the assignment
 * effects:   deletes the current object's existing data and performs 
 *            a deep copy of the data from the other object
 */
CharLinkedList& CharLinkedList::operator=(const CharLinkedList &other) {
    if (this != &other) {
        clear();
        
        Node* curr = other.head;
        copyList(curr);
    }
    return *this;
}

// Member functions implementations
/*
 * name:      isEmpty
 * purpose:   determines if the CharLinkedList is empty
 * arguments: none
 * returns:   true if CharLinkedList contains no elements, false otherwise
 * effects:   none
 */
bool CharLinkedList::isEmpty() const {
    return listSize == 0;
}

/*
 * name:      clear
 * purpose:   makes the instance into an empty linked list
 * arguments: none
 * returns:   none
 * effects:   elements in CharLinkedList get all cleared, 
 *            size of CharLinkedList is updated to zero
 */
void CharLinkedList::clear() {
    recycleRecursive(head);
}

/*
 * name:      size
 * purpose:   determine the number of char in the CharLinkedList
 * arguments: none
 * returns:   number of elements currently stored in the CharLinkedList
 * effects:   none
 */
int CharLinkedList::size() const {
    return listSize;
}

/*
 * name:      first
 * purpose:   gets the first character in the CharLinkedList
 * arguments: none
 * returns:   first character in the CharLinkedList
 * effects:   if the linked list is empty, it throws a std::runtime_error
 *            exception with the message
 */
char CharLinkedList::first() const {
    if (isEmpty()) {
        throw std::runtime_error("cannot get first of empty LinkedList");
    }

    return head->data;
}

/*
 * name:      last
 * purpose:   gets the last character in the CharLinkedList
 * arguments: none
 * returns:   last character in the CharLinkedList
 * effects:   if the linked list is empty, it throws a std::runtime_error
 *            exception with the message
 */
char CharLinkedList::last() const {
    if (isEmpty()) {
        throw std::runtime_error("cannot get last of empty LinkedList");
    }

    return tail->data;
}

/*
 * name:      elementAt
 * purpose:   gets the character in specific index of the CharLinkedList
 * arguments: an integer representing the index in the CharLinkedList
 * returns:   the character in the certain index of CharLinkedList
 * effects:   if the linked list is empty, it throws a std::range_error
 *            exception with the message
 */
char CharLinkedList::elementAt(int index) const {
    if (index < 0 or index >= listSize) {
        throw std::range_error(elementAtToString(index));
    }

    Node* current = head;
    for (int i = 0; i < index; ++i) {
        current = current->next;
    }
    return current->data;
}

/*
 * name:      toString
 * purpose:   get the content in the CharLinkedList
 * arguments: none
 * returns:   a string which contains all characters of the CharLinkedList
 *            and the size of the linked list
 * effects:   none
 */
std::string CharLinkedList::toString() const {
    std::stringstream ss;
    ss << "[CharLinkedList of size " << size() << " <<";   
    for (Node* curr = head; curr != nullptr; curr = curr->next) {
        ss << curr->data;
    }
    ss << ">>]";

    return ss.str();
}

/*
 * name:      toReverseString
 * purpose:   get the content in the CharLinkedList in a reversed order
 * arguments: none
 * returns:   a string which contains the characters of the CharLinkedList
 *            in a reversed order and the size of the CharLinkedList
 * effects:   none
 */
std::string CharLinkedList::toReverseString() const {
    std::stringstream ss;
    ss << "[CharLinkedList of size " << size() << " <<";   
    for (Node* curr = tail; curr != nullptr; curr = curr->prev) {
        ss << curr->data;
    }
    ss << ">>]";

    return ss.str();
}

/*
 * name:      pushAtBack
 * purpose:   add a new character at the end of the linked list
 * arguments: a new character
 * returns:   none
 * effects:   a new character is added at the end of the linked list;
 *            the size of the linked list is incremented by 1.
 */
void CharLinkedList::pushAtBack(char c) {
    Node* newNode = new Node;
    newNode->data = c;
    newNode->next = nullptr;
    newNode->prev = tail;

    if (tail != nullptr) tail->next = newNode;
    tail = newNode;
    if (head == nullptr) head = newNode;
    listSize++;
}

/*
 * name:      pushAtFront
 * purpose:   add a new character at the front of the linked list
 * arguments: a new character
 * returns:   none
 * effects:   a new character is added at the front of the linked list;
 *            the size of the linked list is incremented by 1.
 */
void CharLinkedList::pushAtFront(char c) {
    Node* newNode = new Node;
    newNode->data = c;
    newNode->prev = nullptr;
    newNode->next = head;

    if (head != nullptr) head->prev = newNode;
    head = newNode;
    if (tail == nullptr) tail = newNode;
    listSize++;
}

/* name:      insertAt
 * purpose:   insert a new character at the specified index and 
 *            shifts the existing elements as necessary
 * arguments: a new character and the index where the new character is
 *            going to be inserted
 * returns:   none
 * effects:   a new character is inserted at the specified index in 
 *            the array list; If the index is out of range it should 
 *            throw a C++ std::range_error exception with the message.
 */
void CharLinkedList::insertAt(char c, int index) {
    if (index < 0 or index > listSize) {
        throw std::range_error(indexToString(index));
    }

    if (index == 0) {
        pushAtFront(c);
        return;
    }

    if (index == listSize) {
        pushAtBack(c);
        return;
    }

    Node* current = head;
    for (int i = 0; i < index; i++) current = current->next;
    Node* newNode = new Node;
    newNode->data = c;
    newNode->prev = current->prev;
    newNode->next = current;
    current->prev->next = newNode;
    current->prev = newNode;
    listSize++;
}

/* name:      insertInOrder
 * purpose:   insert a new character into the linked list in ASCII order and
 *            shifts the existing elements as necessary
 * arguments: a new character
 * returns:   none
 * effects:   a new character is inserted into the linked list in ASCII order;
 *            the size of the array list is incremented by 1.
 */
void CharLinkedList::insertInOrder(char c) {
    if (isEmpty() or c <= head->data) {
        pushAtFront(c);
        return;
    }

    if (c >= tail->data) {
        pushAtBack(c);
        return;
    }

    Node* current = head->next;
    while (current != nullptr and current->data < c) {
        current = current->next;
    }

    Node* newNode = new Node;
    newNode->data = c;
    newNode->prev = current->prev;
    newNode->next = current;
    current->prev->next = newNode;
    current->prev = newNode;
    listSize++;
}

/* name:      popFromFront
 * purpose:   removes the first element in the linked list
 * arguments: none
 * returns:   none
 * effects:   the existing elements shift one index forward;
 *            the size of the linked list is decreased by 1;
 *            the capacity get shrinked if necessary to save memory.
 */
void CharLinkedList::popFromFront() {
    if (isEmpty()) {
        throw std::runtime_error("cannot pop from empty LinkedList");
    }

    Node* toDelete = head;
    head = head->next;
    if (head != nullptr) head->prev = nullptr;
    else tail = nullptr; // List became empty
    delete toDelete;
    listSize--;
}

/* name:      popFromBack
 * purpose:   removes the last element in the linked list
 * arguments: none
 * returns:   none
 * effects:   the size of the linked list is decreased by 1;
 *            the capacity get shrinked if necessary to save memory.
 */
void CharLinkedList::popFromBack() {
    if (isEmpty()) {
        throw std::runtime_error("cannot pop from empty LinkedList");
    }

    Node* toDelete = tail;
    tail = tail->prev;
    if (tail != nullptr) tail->next = nullptr;
    else head = nullptr; // List became empty
    delete toDelete;
    listSize--;
}

/* name:      removeAt
 * purpose:   removes the element in the certain index in the linked list
 * arguments: an integer indicates the index of removal
 * returns:   none
 * effects:   the size of the linked list is decreased by 1;
 *            the capacity get shrinked if necessary to save memory.
 */
void CharLinkedList::removeAt(int index) {
    if (index < 0 or index >= listSize) {
        throw std::range_error(elementAtToString(index));
    }

    if (index == 0) {
        popFromFront();
        return;
    }
    if (index == listSize - 1) {
        popFromBack();
        return;
    }
    Node* current = head;
    for (int i = 0; i < index; i++) current = current->next;
    current->prev->next = current->next;
    current->next->prev = current->prev;
    delete current;
    listSize--;
}

/* name:      replaceAt
 * purpose:   replaces the element in the certain index in the linked list
 * arguments: a character and an integer indicates the index of replacement
 * returns:   none
 * effects:   the element at specific index is updated while the rest 
 *            remains unchanged
 */
void CharLinkedList::replaceAt(char c, int index) {
    if (index < 0 or index >= listSize) {
        throw std::range_error(elementAtToString(index));
    }

    Node* current = head;
    for (int i = 0; i < index; i++) current = current->next;
    current->data = c;
}

/* name:      concatenate
 * purpose:   adds a copy of the linked list pointed to by the parameter value 
 *            to the end of the linked list the function was called from
 * arguments: a pointer to a second CharLinkedList
 * returns:   none
 * effects:   the copy of the second linked list is added to the end of the 
 *            current linked list; size of the linked list is updated.
 */
void CharLinkedList::concatenate(CharLinkedList *other) {
    if (other == nullptr or other->isEmpty()) {
        return;
    }

    for (Node* curr = other->head; curr != nullptr; curr = curr->next) {
        pushAtBack(curr->data);
    }
}

// Private helper functions
/*
 * name:      recyclyRecursive
 * purpose:   help to free memory associated with the CharLinkedList 
 *            using while loop and prevent private data get accessed
 * arguments: a Node pointer
 * returns:   none
 * effects:   frees memory allocated by CharLinkedlist instances
 */
void CharLinkedList::recycleRecursive(Node *curr) {
    while (curr != nullptr) {
        Node* toDelete = curr;
        curr = curr->next;
        delete toDelete;
    }

    head = nullptr;
    tail = nullptr;
    listSize = 0;
}

/*
 * name:      copyList
 * purpose:   help to copy the content from another linked list
 * arguments: a Node pointer
 * returns:   none
 * effects:   a new linked list is created and the content 
 *            is copied from another linked list
 */
void CharLinkedList::copyList(Node *curr) {
    while (curr != nullptr) {
        Node* newNode = new Node;
        newNode->data = curr->data;
        newNode->prev = tail;
        newNode->next = nullptr;

        if (tail != nullptr) {
            tail->next = newNode;
        }
        tail = newNode;
        if (head == nullptr) {
            head = newNode;
        }
        listSize++;
        curr = curr->next;
    }
}

/*
 * name:      elementAtToString
 * purpose:   converts the index received in elementAt() to a string of
 *            error message warning that the index is out of range
 * arguments: an integer representing the index
 * returns:   the string of a range_error message
 * effects:   none
 */
std::string CharLinkedList::elementAtToString(int &index) const {
    std::stringstream ss;
    ss << "index (" << index << ") not in range [0.." << listSize << ")";
    return ss.str();
}

/*
 * name:      indexToString
 * purpose:   converts the index received in insertAt() to a string of 
 *            error message warning that the index is out of range
 * arguments: an integer representing the index
 * returns:   the string of a range_error message
 * effects:   none
 */
std::string CharArrayList::indexToString(int &index) const {
    std::stringstream ss;
    ss << "index (" << index << ") not in range [0.." << numItems << "]";
    return ss.str();
}

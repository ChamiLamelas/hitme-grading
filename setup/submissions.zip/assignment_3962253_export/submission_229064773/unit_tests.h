/*
 *  unit_tests.h
 *  Peter Ren (jren03)
 *  02/01/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  Use unit_test framework to test the CharLinkedList class.
 *
 */
#include "CharLinkedList.h"
#include <cassert>
#include <iostream>
#include <string>

using namespace std;

/*
 * constructor_test_0
 * Make sure no fatal errors/memory leaks in the default constructor
 */
void constructor_test_0() {
    CharLinkedList list;
}

/*
 * constructor_test_1
 * Make sure no items exist in the list upon defualt construction
 */
void constructor_test_1() {
    CharLinkedList list;
    assert(list.size() == 0);
    assert(list.isEmpty());
}

/*
 * constructor_test_2
 * Make sure only one item exists in the list upon second construction
 */
void constructor_test_2() {
    char element = 'a';
    CharLinkedList list(element);
    assert(list.size() == 1);
}

/*
 * constructor_test_3
 * Make sure the third construction works properly and the content
 * within the linked list is correct; also test toString() works properly
 */
void constructor_test_3() {
    char test[] = {'C','S','1','5','!'};
    int size = 5;
    CharLinkedList list(test, size);

    string content = list.toString();
    string expected = "[CharLinkedList of size 5 <<CS15!>>]";
    assert(content == expected);
}

/*
 * constructor_copy_0
 * Make sure copying an empty linked list works properly 
 * and the new linked list should be empty too
 */
void constructor_copy_0() {
    CharLinkedList original;
    CharLinkedList copy(original);

    assert(copy.isEmpty());
}

/*
 * constructor_copy
 * Make sure copy construction works properly and the content
 * within the linked list is correct
 */
void constructor_copy() {
    char test[] = {'C','S','1','5'};
    int size = 4;

    CharLinkedList original(test, size);
    CharLinkedList copy(original);

    string content = copy.toString();
    string expected = original.toString();
    assert(content == expected);
}

/*
 * operator_empty
 * Make sure the empty copy is corret
 */
void operator_empty() {
    CharLinkedList emptyList;
    CharLinkedList list;

    list.pushAtBack('x');
    list = emptyList;

    assert(list.size() == 0); 
}

/*
 * operator_test_self
 * Make sure the self-assignment is corret
 */
void operator_test_self() {
    char test[] = {'C','S','1','5'};
    int size = 4;
    CharLinkedList list1(test, size);

    // self-assignment
    list1 = list1;

    string content = list1.toString();
    string expected = "[CharLinkedList of size 4 <<CS15>>]";
    assert (content == expected);
}

/*
 * operator_test
 * Make sure the data content copy is corret
 */
void operator_test() {
    CharLinkedList fullList;
    for (int i = 0; i < 10; i++) {
        fullList.pushAtBack('a' + i);
    }

    CharLinkedList list;
    list = fullList;

    assert(list.size() == 10);
    // check elements
    for (int i = 0; i < 10; i++) {
        assert(list.elementAt(i) == 'a' + i); 
    }
}


/*
 * operator_test_copy
 * Make sure the deep copy is corret
 */
void operator_test_copy() {
    char test[] = {'C','S','1','5'};
    int size = 4;
    CharLinkedList list1(test, size);
    string expected = list1.toString();

    CharLinkedList list2 = list1;
    list1.pushAtBack('!');

    assert (list2.toString() == expected);
}

/*
 * operator_test_copy2
 * Make sure the multiple copy is corret
 */
void operator_test_copy2() {
    char test[] = {'C','S','1','5'};
    int size = 4;
    CharLinkedList list1(test, size);

    // multiple copies
    CharLinkedList list2 = list1;
    CharLinkedList list3 = list2;

    assert (list3.toString() == list1.toString());
}

/*
 * clear_test
 * make sure the content in the linked list is empty and the size is set to 0
 */
void clear_test() {
    char test[] = {'C','S','1','5'};
    int size = 4;
    CharLinkedList list(test, size);

    list.clear();
    assert(list.isEmpty());
}

/*
 * first_test_empty
 * Attemps to get the first character in an empty linked list.
 * This should result in std::runtime_errro being raised.
 */
void first_test_empty() {
    bool runtime_error_thrown = false;
    std::string error_message = "";
    CharLinkedList list;
    char first_c;

    try {
        first_c = list.first();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot get first of empty LinkedList");
}

/*
 * first_test
 * Attemps to get the first character in the linked list.
 */
void first_test() {
    char test[] = {'C','S','1','5'};
    int size = 4;
    char first_c;
    CharLinkedList list(test, size);

    first_c = list.first();
    assert(first_c == 'C');
}

/*
 * last_test_empty
 * Attemps to get the last character in an empty linked list.
 * This should result in std::runtime_error being raised.
 */
void last_test_empty() {
    bool runtime_error_thrown = false;
    std::string error_message = "";
    CharLinkedList list;
    char last_c;

    try {
        last_c = list.last();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot get last of empty LinkedList");
}

/*
 * last_test
 * Attemps to get the last character in the linked list.
 */
void last_test() {
    char test[] = {'C','S','1','5'};
    int size = 4;
    char last_c;
    CharLinkedList list(test, size);

    last_c = list.last();
    assert(last_c == '5');
}

/*
 * elementAt_below
 * Attemps to get the character in index-th in the linked list, 
 * but the index is less than 0.
 * This should result in std::range_error being raised.
 */
 void elementAt_below() {
    bool range_error_thrown = false;
    std::string error_message = "";
    char test[] = {'C','S','1','5'};
    int size = 4;
    char last_c;
    CharLinkedList list(test, size);

    try {
        last_c = list.elementAt(-1);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (-1) not in range [0..4)");
}

/*
 * elementAt_above
 * Attemps to get the character in index-th in the linked list, 
 * but the index is over the size of the linked list.
 * This should result in std::range_error being raised.
 */
 void elementAt_above() {
    bool range_error_thrown = false;
    std::string error_message = "";
    char test[] = {'C','S','1','5'};
    int size = 4;
    char last_c;
    CharLinkedList list(test, size);

    try {
        last_c = list.elementAt(4);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (4) not in range [0..4)");
}

/*
 * elementAt_test
 * Attemps to get the character in index-th in the array list.
 */
 void elementAt_test() {
    char test[] = {'C','S','1','5'};
    int size = 4;
    char last_c;
    CharLinkedList list(test, size);
    
    assert(list.elementAt(1) == 'S');
}

/*
 * toString_test_0
 * Make sure toString() works properly when taking an empty linked list
 * within the linked list is correct; also test toString() works properly
 */
void toString_test_0() {
    CharLinkedList list;

    string expected = "[CharLinkedList of size 0 <<>>]";
    assert(list.toString() == expected);
}

/*
 * toReverseString_test_0
 * Checks that the string for empty list is as we expect it to be
 */
void toReverseString_test_0() {
    CharLinkedList list;

    string expected = "[CharLinkedList of size 0 <<>>]";
    assert(list.toReverseString() == expected);
}

/*
 * toReverseString_test
 * Checks that the reversed string for linked list is as we expect it to be
 */
void toReverseString_test() {
    char test[] = {'C','S','1','5'};
    int size = 4;
    CharLinkedList list(test, size);

    string expected = "[CharLinkedList of size 4 <<51SC>>]";
    assert(list.toReverseString() == expected);
}

/*
 * pushAtBack_test_empty
 * Add a new character to the end of an empty linked list
 */
void pushAtBack_test_empty() {
    CharLinkedList list;
    char c = 'C';
    list.pushAtBack(c);

    assert(list.size() == 1);
    assert(list.last() == 'C');
}

/*
 * pushAtBack_test
 * Add a new character to the end of a linked list 
 */
void pushAtBack_test() {
    CharLinkedList list;
    char first = 'C';
    char second = 'S';

    list.pushAtBack(first);
    list.pushAtBack(second);

    assert(list.size() == 2);
    assert(list.first() == 'C');
    assert(list.last() == 'S');
}

/*
 * pushAtBack_test_large
 * Add a new character to the end of a linked list 
 * when a linked list is super big
 */
void pushAtBack_test_large() {
    CharLinkedList list;
    char c = 'C';

    for (int i = 0; i < 18000; i++) {
        list.pushAtBack(c);
    }

    char d = 'S';
    list.pushAtBack(d);

    assert(list.size() == 18001);
    assert(list.first() == 'C');
    assert(list.last() == 'S');
}

/*
 * pushAtFront_test_empty
 * Add a new character to the front of an empty linked list
 */
void pushAtFront_test_empty() {
    CharLinkedList list;
    char c = 'C';
    list.pushAtFront(c);

    assert(list.size() == 1);
    assert(list.first() == 'C');
}

/*
 * pushAtFront_test
 * Add a new character to the front of a linked list 
 */
void pushAtFront_test() {
    CharLinkedList list;
    char first = 'C';
    char second = 'S';

    list.pushAtFront(second);
    list.pushAtFront(first);

    assert(list.size() == 2);
    assert(list.first() == 'C');
    assert(list.last() == 'S');
}

/*
 * pushAtFront_test_large
 * Add a new character to the front of a linked list 
 * when a linked list is super big
 */
void pushAtFront_test_large() {
    CharLinkedList list;

    for (int i = 0; i < 18000; i++) {
        list.pushAtFront('S');
    }

    list.pushAtFront('C');

    assert(list.size() == 18001);
    assert(list.first() == 'C');
    assert(list.last() == 'S');
}

/* Tests correct insertion into an empty linked list.
 * Afterwards, size should be 1 and element at index 0
 * should be the element we inserted.
 */
void insertAt_empty_correct() { 
    CharLinkedList test_list;
    test_list.insertAt('a', 0);

    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');
}

/* Tests incorrect insertion into an empty linked list.
 * Attempts to call insertAt for index larger than 0.
 * This should result in an std::range_error being raised.
 */
void insertAt_empty_incorrect() {
    bool range_error_thrown = false;
    std::string error_message = "";

    CharLinkedList test_list;
    try {
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0]");
}

// Tests correct insertAt for front of 1-element list.
void insertAt_front_singleton_list() {
    
    CharLinkedList test_list('a');
    test_list.insertAt('b', 0);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'a');
    
}

// Tests correct insertAt for back of 1-element list.
void insertAt_back_singleton_list() {

    CharLinkedList test_list('a');
    test_list.insertAt('b', 1);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
}

// Tests insertion into front of a larger list
void insertAt_front_large_list() {
    char test_arr[7] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f'};
    CharLinkedList test_list(test_arr, 7);

    test_list.insertAt('y', 0);

    assert(test_list.size() == 8);
    assert(test_list.elementAt(0) == 'y');
    assert(test_list.toString() == "[CharLinkedList of size 10 <<yabczdef>>]");
}

// Tests insertion into the back of a larger list
void insertAt_back_large_list() {
    char test_arr[7] = { 'y', 'a', 'b', 'c', 'z', 'd', 'e'};
    CharLinkedList test_list(test_arr, 7);  

    test_list.insertAt('x', 7);

    assert(test_list.size() == 8);
    assert(test_list.elementAt(8) == 'x');
    assert(test_list.toString() == 
    "[CharArrayList of size 11 <<yabczdex>>]"); 

}

// Tests insertion into the middle of a larger list
void insertAt_middle_large_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.insertAt('z', 3);

    assert(test_list.size() == 9);
    assert(test_list.elementAt(3) == 'z');
    assert(test_list.toString() == "[CharArrayList of size 9 <<abczdefgh>>]");

}

// Tests out-of-range insertion for a non-empty list.
void insertAt_nonempty_incorrect() {
   
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);
    bool range_error_thrown = false;
    std::string error_message = "";

    try {
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8]");
}

/*
 * insertInOrder_empty
 * insert a new element in the empty list in order
 */
void insertInOrder_empty() {
    CharArrayList list;
    list.insertInOrder('a');

    assert (list.size() == 1);
    assert (list.first() == 'a');
}

/*
 * insertInOrder_beginning
 * insert a new element in an array list in order
 * the new element will be inserted at the front
 */
void insertInOrder_beginning() {
    CharArrayList list;
    list.insertInOrder('c');
    list.insertInOrder('a');
    
    assert (list.size() == 2);
    assert (list.first() == 'a');
    assert (list.last() == 'c');
}

/*
 * insertInOrder_end
 * insert a new element in an array list in order
 * the new element will be inserted at the end
 */
void insertInOrder_end() {
    CharArrayList list;
    list.insertInOrder('a');
    list.insertInOrder('c');
    
    assert (list.size() == 2);
    assert (list.first() == 'a');
    assert (list.last() == 'c');
}

/*
 * insertInOrder_middle
 * insert a new element in an array list in order
 * the new element will be inserted in the middle
 */
void insertInOrder_middle() {
    CharArrayList list;
    list.insertInOrder('a');
    list.insertInOrder('c');
    list.insertInOrder('b');
    
    assert (list.size() == 3);
    assert (list.elementAt(0) == 'a');
    assert (list.elementAt(1) == 'b');
    assert (list.elementAt(2) == 'c');
}

/*
 * insertInOrder_same
 * insert a new element in an array list in order
 * there is a same element in the array list already
 */
void insertInOrder_same() {
    CharArrayList list;
    list.insertInOrder('a');
    list.insertInOrder('b');
    list.insertInOrder('b');
    
    assert (list.size() == 3);
    assert (list.elementAt(0) == 'a');
    assert (list.elementAt(1) == 'b');
    assert (list.elementAt(2) == 'b');
}

/*
 * insertInOrder_many_letter
 * insert many elements in an array list in order
 */
void insertInOrder_many_letter() {
    CharArrayList list;
    list.insertInOrder('d');
    list.insertInOrder('b');
    list.insertInOrder('c');
    list.insertInOrder('a');
    list.insertInOrder('c');
    list.insertInOrder('e');
    
    assert (list.size() == 6);
    assert (list.elementAt(0) == 'a');
    assert (list.elementAt(1) == 'b');
    assert (list.elementAt(2) == 'c');
    assert (list.elementAt(3) == 'c');
    assert (list.elementAt(4) == 'd');
    assert (list.elementAt(5) == 'e');
}

/*
 * insertInOrder_many_number
 * insert many elements in an array list in order
 */
void insertInOrder_many_number() {
    CharArrayList list;
    list.insertInOrder('3');
    list.insertInOrder('9');
    list.insertInOrder('5');
    list.insertInOrder('0');
    list.insertInOrder('2');
    list.insertInOrder('7');
    
    assert (list.size() == 6);
    assert (list.elementAt(0) == '0');
    assert (list.elementAt(1) == '2');
    assert (list.elementAt(2) == '3');
    assert (list.elementAt(3) == '5');
    assert (list.elementAt(4) == '7');
    assert (list.elementAt(5) == '9');
}

/*
 * popFromFront_empty
 * try to pop the first element of an empty array list
 * this should result in a runtime_error
 */
void popFromFront_empty() {
    bool range_error_thrown = false;
    std::string error_message = "";
    CharArrayList list;

    // try to catch the runtime_error
    try {
        list.popFromFront();
    }
    catch (const std::runtime_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "cannot pop from empty ArrayList");
}

/*
 * popFromFront_test
 * pop the first element of an array list
 */
void popFromFront_test() {
    char test[] = {'C','S','1','5'};
    int size = 4;
    CharArrayList list(test, size);
    list.popFromFront();

    assert(list.size() == 3);
    assert(list.first() == 'S');
    assert(list.last () == '5');
}

/*
 * popFromFront_test_shrink
 * pop the first element of an array list several times
 * this should result in a capacity shrink
 */
void popFromFront_test_shrink() {
    CharArrayList list;
    for (int i = 48; i < 54; i++) {
        list.pushAtBack(i);
    }

    // trigger the shrink function
    for (int i = 0; i < 5; i++) {
        list.popFromFront();
    }

    assert(list.size() == 1);
    assert(list.first() == '5');
}

/*
 * popFromBack_empty
 * try to pop the last element of an empty array list
 * this should result in a runtime_error
 */
void popFromBack_empty() {
    bool range_error_thrown = false;
    std::string error_message = "";
    CharArrayList list;

    // try to catch the runtime_error
    try {
        list.popFromBack();
    }
    catch (const std::runtime_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "cannot pop from empty ArrayList");
}

/*
 * popFromBack_test
 * pop the last element of an array list
 */
void popFromBack_test() {
    char test[] = {'C','S','1','5'};
    int size = 4;
    CharArrayList list(test, size);
    list.popFromBack();

    assert(list.size() == 3);
    assert(list.last() == '1');
    assert(list.first() == 'C');
}

/*
 * popFromBack_test_shrink
 * pop the last element of an array list several times
 * this should result in a capacity shrink
 */
void popFromBack_test_shrink() {
    CharArrayList list;
    for (int i = 48; i < 54; i++) {
        list.pushAtBack(i);
    }

    // trigger the shrink function
    for (int i = 0; i < 5; i++) {
        list.popFromBack();
    }

    assert(list.size() == 1);
    assert(list.first() == '0');
}

/*
 * removeAt_empty
 * try to remove an element in an empty array list
 * this should result in a range_error exception
 */
void removeAt_empty() {
    bool range_error_thrown = false;
    std::string error_message = "";
    CharArrayList list;

    try {
        list.removeAt(1);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (1) not in range [0..0)");
}

/*
 * removeAt_front
 * remove the first element in the array list
 */
void removeAt_front() {
    char test[] = {'C','S','1','5'};
    int size = 4;
    CharArrayList list(test, size);

    list.removeAt(0);

    assert(list.size() == 3);
    assert(list.elementAt(0) == 'S');
    assert(list.elementAt(1) == '1');
    assert(list.elementAt(2) == '5');
}

/*
 * removeAt_end
 * remove the last element in the array list
 */
void removeAt_end() {
    char test[] = {'C','S','1','5'};
    int size = 4;
    CharArrayList list(test, size);

    list.removeAt(3);

    assert(list.size() == 3);
    assert(list.elementAt(0) == 'C');
    assert(list.elementAt(1) == 'S');
    assert(list.elementAt(2) == '1');
}

/*
 * removeAt_middle
 * remove the element in the middle of an array list
 */
void removeAt_middle() {
    char test[] = {'C','S','1','5'};
    int size = 4;
    CharArrayList list(test, size);

    list.removeAt(1);

    assert(list.size() == 3);
    assert(list.elementAt(0) == 'C');
    assert(list.elementAt(1) == '1');
    assert(list.elementAt(2) == '5');
}

/*
 * removeAt_shrink_test
 * try to remove many elements of an array list
 * this should trigger the capacity to shrink
 * this also tests if removing many elements is possible
 */
void removeAt_shrink_test() {
    char test[] = {'C','S','1','5','!','?'};
    int size = 6;
    CharArrayList list(test, size);

    list.removeAt(1);
    list.removeAt(4);
    list.removeAt(2);
    list.removeAt(0);
    list.removeAt(1);
    
    assert(list.size() == 1);
    assert(list.elementAt(0) == '1');
}

/*
 * removeAt_error
 * try to remove the element in the index out of range
 * this should result in a range_error excepetion
 */
void removeAt_error() {
    bool range_error_thrown = false;
    std::string error_message = "";
    char test[] = {'C','S','1','5'};
    int size = 4;
    CharArrayList list(test, size);

    // try to catch the runtime_error
    try {
        list.removeAt(4);
    }
    catch (const std::runtime_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (4) not in range [0..4)");
}

/*
 * replaceAt_empty
 * try to replace an element in an empty array list
 * this should result in a range_error exception
 */
void replaceAt_empty() {
    bool range_error_thrown = false;
    std::string error_message = "";
    CharArrayList list;

    try {
        list.replaceAt('c', 1);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (1) not in range [0..0)");
}

/*
 * replaceAt_front
 * replace the first element in the array list
 */
void repalceAt_front() {
    char test[] = {'C','S','1','5'};
    int size = 4;
    CharArrayList list(test, size);

    list.replaceAt('G', 0);

    assert(list.size() == 4);
    assert(list.elementAt(0) == 'G');
    assert(list.elementAt(1) == 'S');
}

/*
 * replace_end
 * replace the last element in the array list
 */
void replaceAt_end() {
    char test[] = {'C','S','1','5'};
    int size = 4;
    CharArrayList list(test, size);

    list.replaceAt('6', 3);

    assert(list.size() == 4);
    assert(list.elementAt(3) == '6');
    assert(list.elementAt(0) == 'C');
}

/*
 * replaceAt_middle
 * replace the element in the middle of an array list
 */
void replaceAt_middle() {
    char test[] = {'C','S','1','5'};
    int size = 4;
    CharArrayList list(test, size);

    list.replaceAt('A', 1);

    assert(list.size() == 4);
    assert(list.elementAt(0) == 'C');
    assert(list.elementAt(1) == 'A');
}

/*
 * replaceAt_many
 * replace many elements of an array list
 */
void replaceAt_many() {
    char test[] = {'C','S','1','5','!','?'};
    int size = 6;
    CharArrayList list(test, size);

    list.replaceAt('6', 2);
    list.replaceAt('1', 3);
    list.replaceAt('!', 5);
    
    assert(list.size() == 6);
    assert(list.elementAt(0) == 'C');
    assert(list.elementAt(2) == '6');
    assert(list.elementAt(3) == '1');
    assert(list.elementAt(5) == '!');
}

/*
 * replaceAt_error
 * try to reokace the element in the index out of range
 * this should result in a range_error excepetion
 */
void replaceAt_error() {
    bool range_error_thrown = false;
    std::string error_message = "";
    char test[] = {'C','S','1','5'};
    int size = 4;
    CharArrayList list(test, size);

    // try to catch the range_error
    try {
        list.replaceAt('!', 4);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (4) not in range [0..4)");
}

/*
 * concatenate_0
 * try to concatenate am empty array list with an empty array list
 * the array list should be still empty
 */
void concatenate_0() {
    CharArrayList list1;
    CharArrayList list2;

    list1.concatenate(&list2);

    assert(list1.isEmpty());
    assert(list2.isEmpty());
}

/*
 * concatenate_nullptr
 * try to concatenate with a null pointer
 * this should make no change to the current array list
 */
void concatenate_nullptr() {
    char test[] = {'C','S','1','5'};
    int size = 4;
    CharArrayList list1(test, size);

    list1.concatenate(nullptr);

    assert(list1.size() == 4);
}

/*
 * concatenate_empty
 * try to concatenate with an empty array list
 * this should make no change to the current array list
 */
void concatenate_empty() {
    char test[] = {'C','S','1','5'};
    int size = 4;
    CharArrayList list1(test, size);
    CharArrayList list2;

    list1.concatenate(&list2);

    assert(list1.size() == 4);
}

/*
 * concatenate_start_empty
 * try to concatenate an empty array list with another array list
 * the array list should not be empty any more
 */
void concatenate_start_empty() {
    CharArrayList list1;
    char test[] = {'C','S','1','5'};
    int size = 4;
    CharArrayList list2(test, size);

    list1.concatenate(&list2);

    assert(list1.size() == 4);
    // check the content of addition
    for (int i = 0; i < size; i++) {
        assert(list1.elementAt(i) == list2.elementAt(i));
    }
}

/*
 * concatenate_test
 * try to concatenate an array list with another array list
 * the other array list should not change
 */
void concatenate_test() {
    char test1[] = {'C','S','1','5'};
    int size = 4;
    CharArrayList list1(test1, size);
    char test2[] = {'~','G','O','!'};
    CharArrayList list2(test2, size);

    list1.concatenate(&list2);

    assert(list1.size() == 8);
    // check the content of addition
    for (int i = size; i < list1.size(); i++) {
        assert(list1.elementAt(i) == list2.elementAt(i - size));
    }

    // check list2 remains unchanged
    assert(list2.size() == 4);
    assert(list2.elementAt(0) == '~');
    assert(list2.elementAt(1) == 'G');
    assert(list2.elementAt(2) == 'O');
    assert(list2.elementAt(3) == '!');
}

/*
 *  unit_tests.h
 *  Akpevwe Akpoigbe
 *  2 - 1 - 2023
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  FILE PURPOSE HERE
 *
 */
#include "CharLinkedList.h"
#include <cassert>
#include <iostream>
#include <stdexcept>
using namespace std;


/*test that constructor was created*/
void default_constructor(){
    CharLinkedList list;
}

/*tests that constructor is empty*/
void default_constructor_0(){
    CharLinkedList list;
    assert(list.size() == 0);
}

/*tests that single character was psuhed back onto list*/
void One_constructor(){
    CharLinkedList list('b');
    assert(list.size() == 1);
}

/*tests that list was created properly*/
void listConstructor(){
    char arr[3] = {'b', 'y', 'e'};
    CharLinkedList list(arr, 3);
    assert(list.toString() == "[CharLinkedList of size 3 <<bye>>]");
}

/*tests that other List class was properly copied*/
void copy_constructor(){
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList list_one(arr, 3);
    CharLinkedList list_two(list_one);
    list_two = list_one;
    assert(list_one.toString() == "[CharLinkedList of size 3 <<abc>>]");
}

/*tests that deep copy was properly made*/
void assignment_operator(){
    CharLinkedList list_one;
    list_one.pushAtBack('b');
    list_one.pushAtBack('o');
    list_one.pushAtBack('y');
    std::cout << list_one.toString() << endl;
    CharLinkedList list_two;
    list_two.pushAtBack('g');
    list_two.pushAtBack('i');
    list_two.pushAtBack('r');
    list_two.pushAtBack('l');
    std::cout << list_two.toString() << endl;
    list_one = list_two;
    std::cout << list_one.toString() << endl;
    assert(list_one.toString() == "[CharLinkedList of size 4 <<girl>>]");
}

/*tests that list is empty*/
void isEmpty_true(){
    CharLinkedList list;
    assert(list.isEmpty());
}

/*tests that isEmpty returns false*/
void isEmpty_false(){
    CharLinkedList list('c');
    assert(not list.isEmpty());
}

/*tests that list was proprerly cleared*/
void clear_works(){
    CharLinkedList list('c');
    list.clear();
    assert(list.isEmpty());
}

/*tests that characters are pushed to front of empty list*/
void pushFront_emptyList(){
    CharLinkedList list;
    list.pushAtFront('g');
    list.pushAtFront('o');
    list.pushAtFront('d');
    assert(list.toString() == "[CharLinkedList of size 3 <<dog>>]");
}

/*tests that charcters are added properly to front of full list*/
void pushFront_FullList(){
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList list(arr, 3);
    list.pushAtFront('d');
    list.pushAtFront('e');
    list.pushAtFront('f');
    assert(list.toString() == "[CharLinkedList of size 6 <<fedabc>>]");
}

/*tests that characters are pushed to back of empty list*/
void pushBack_emptyList(){
    CharLinkedList list;
    list.pushAtBack('c');
    list.pushAtBack('a');
    list.pushAtBack('t');
    assert(list.toString() == "[CharLinkedList of size 3 <<cat>>]");
}

/*tests that charcters are added properly to back of full list*/
void pushBack_FullList(){
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList list(arr, 3);
    list.pushAtBack('d');
    list.pushAtBack('e');
    list.pushAtBack('f');
    assert(list.toString() == "[CharLinkedList of size 6 <<abcdef>>]");
}

/*tests that size returns the corret value*/
void size_works(){
    CharLinkedList list;
    list.pushAtBack('c');
    list.pushAtBack('a');
    list.pushAtBack('t');
    assert(list.size() == 3);
}

/*tests that size works on an empty list*/
void size_emptyList(){
    CharLinkedList list;
    assert(list.size() == 0);
}

/*tests that the first character in a list is returned properly*/
void first_true(){
    CharLinkedList list;
    list.pushAtBack('b');
    list.pushAtBack('o');
    list.pushAtBack('y');
    assert(list.first() == 'b');
}

/*tests that in an empty list the error is thrown trying to get first*/
void first_false(){
    CharLinkedList list;
    bool runtime_error_thrown = false;
    string error_message = "";
    try {
        list.first();
    }
    catch(std::runtime_error error){
        runtime_error_thrown = true;
        error_message = error.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "cannot get first of empty LinkedList");
}

/*tests that last character in list is returned properly*/
void last_true(){
    CharLinkedList list;
    list.pushAtBack('b');
    list.pushAtBack('o');
    list.pushAtBack('y');
    assert(list.last() == 'y');
}

/*tests that in an empty list the error is thrown trying to get last character*/
void last_false(){
    CharLinkedList list;
    bool runtime_error_thrown = false;
    string error_message = "";
    try {
        list.last();
    }
    catch(std::runtime_error error){
        runtime_error_thrown = true;
        error_message = error.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "cannot get last of empty LinkedList");
}

/*tests that a reverse string is properly printed*/
void reverseString_FullList(){
    CharLinkedList list;
    list.pushAtBack('b');
    list.pushAtBack('o');
    list.pushAtBack('y');
    assert(list.toReverseString() == "[CharLinkedList of size 3 <<yob>>]");
}

/*tests that reverse string cannot be printed in empty list*/
void reverseString_emptyList(){
    CharLinkedList list;
    assert(list.toReverseString() == "[CharLinkedList of size 0 <<>>]");
}

/*tests that error is thrown when trying to access element at incorrect index*/
void elementAt_empty(){
    CharLinkedList list;
    bool range_error_thrown = false;
    string error_message = "";
    try{
        list.elementAt(24);
    }
    catch(std::range_error error){
        range_error_thrown = true;
        error_message = error.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (24) not in range [0..0)");
}

/*tests that currect element is returned*/
void elementAt(){
    CharLinkedList list;
    list.pushAtBack('t');
    list.pushAtBack('o');
    list.pushAtBack('y');
    assert(list.elementAt(1) == 'o');
}

/*tests that correct element is returned in full list*/
void elementAt_FullList(){
    char arr[6] = {'a', 'b', 'c', 'd', 'e', 'f'};
    CharLinkedList list(arr, 6);
    assert(list.elementAt(2) == 'c');
}

/*tests that error is thrown when trying to replace out of index*/
void replaceAt_empty(){
    CharLinkedList list;
    bool range_error_thrown = false;
    string error_message = "";
    try{
        list.replaceAt('c', 15);
    }
    catch(std::range_error error){
        range_error_thrown = true;
        error_message = error.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (15) not in range [0..0)");
}

/*tests that correct charceter at specified index is replaced in list*/
void replaceAt(){
    CharLinkedList list;
    list.pushAtBack('t');
    list.pushAtBack('o');
    list.pushAtBack('y');
    list.replaceAt('k', 2);
    assert(list.toString() == "[CharLinkedList of size 3 <<tok>>]");
}

/*tests that correct character at specified index is replaced in full list*/
void replaceAt_FullList(){
    char arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList list(arr, 8);
    list.replaceAt('x', 3);
    assert(list.toString() == "[CharLinkedList of size 8 <<abcxefgh>>]");
}

/*tests that error is thrown when trying to remove at out of range index*/
void removeAt_empty(){
    CharLinkedList list;
    bool range_error_thrown = false;
    string error_message = "";
    try{
        list.removeAt(72);
    }
    catch(std::range_error error){
        range_error_thrown = true;
        error_message = error.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (72) not in range [0..0)");
}

//tests removing charater at negative index
void removeAt_negative(){
    char arr[6] = {'a', 'b', 'c', 'd', 'e', 'f'};
    CharLinkedList list(arr, 6);
    bool range_error_thrown = false;
    string error_message = "";
    try{
        list.removeAt(-1);
    }
    catch(std::range_error error){
        range_error_thrown = true;
        error_message = error.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (-1) not in range [0..6)");
}

// /*tests that correct character is removed from specified index*/
void removeAt(){
    CharLinkedList list;
    list.pushAtBack('t');
    list.pushAtBack('o');
    list.pushAtBack('y');
    list.removeAt(1);
    assert(list.toString() == "[CharLinkedList of size 2 <<ty>>]");
}

// /*tests that correct charcter in removed from specified index in full list*/
void removeAt_FullList(){
    char arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList list(arr, 8);
    list.removeAt(3);
    assert(list.toString() == "[CharLinkedList of size 7 <<abcefgh>>]");
}

// /*tests that the first node is removed from the list*/
void popFromFront(){
    CharLinkedList list;
    list.pushAtBack('t');
    list.pushAtBack('o');
    list.pushAtBack('y');
    list.popFromFront();
    assert(list.toString() == "[CharLinkedList of size 2 <<oy>>]");
}

/*tests that error thrown when popping from empty list*/
void popFromFront_empty(){
    CharLinkedList list;
    bool runtime_error_thrown = false;
    string error_message = "";
    try {
        list.popFromFront();
    }
    catch(std::runtime_error error){
        runtime_error_thrown = true;
        error_message = error.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}
// /*tests that last node is removed from the list*/
void popFromBack(){
    CharLinkedList list;
    list.pushAtBack('t');
    list.pushAtBack('o');
    list.pushAtBack('y');
    list.popFromBack();
    assert(list.toString() == "[CharLinkedList of size 2 <<to>>]");
}

/*tests that error thrown when popping from empty list*/
void popFromBack_empty(){
    CharLinkedList list;
    bool runtime_error_thrown = false;
    string error_message = "";
    try {
        list.popFromBack();
    }
    catch(std::runtime_error error){
        runtime_error_thrown = true;
        error_message = error.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

/*tests that element can be indersted into a full list*/
void insertAt_fullList(){
    CharLinkedList list;
    list.insertAt('f', 0);
    assert(list.size() == 1);
    assert(list.toString() == "[CharLinkedList of size 1 <<f>>]");
}

/*tests that error is thrown when trying to insert into full list*/
void insertAt_EmptyList(){
    CharLinkedList list;
    bool range_error_thrown = false;
    string error_message = "";
    try{
        list.insertAt('a', 30);
    }
    catch(std::range_error error){
        range_error_thrown = true;
        error_message = error.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (30) not in range [0..0]");
}

/*tests that element can be inserted into the front of list*/
void insertAt_front(){
    CharLinkedList list('c');
    list.insertAt('b', 0);
    assert(list.size() == 2);
    assert(list.toString() == "[CharLinkedList of size 2 <<bc>>]");
}

/*tests that character can be inserted into back of list*/
void insertAt_back(){
    CharLinkedList list('c');
    list.insertAt('b', 1);
    assert(list.size() == 2);
    assert(list.toString() == "[CharLinkedList of size 2 <<cb>>]");
}

/*tests that multiple charcaters can be inserted into a list*/
void insertAt_many(){
    CharLinkedList list;

    for(int i = 0; i < 1000; i++){
        list.insertAt('a', i);
    }
    assert(list.size() == 1000);

    for(int i = 0; i < 1000; i++){
        assert(list.elementAt(i) == 'a');
    }
}

/*tests that character can be inserted into front of large list*/
void insert_front_largeList(){
    char arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList list(arr, 8);
    list.insertAt('z', 0);
    assert(list.size() == 9);
    assert(list.elementAt(0) == 'z');
    assert(list.toString() == "[CharLinkedList of size 9 <<zabcdefgh>>]");
}

/*tests that character can be inserted into back of large list*/
void insert_back_largeList(){
    char arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList list(arr, 8);
    list.insertAt('z', 8);
    assert(list.size() == 9);
    assert(list.elementAt(8) == 'z');
    assert(list.toString() == "[CharLinkedList of size 9 <<abcdefghz>>]");
}

/*tests tah charcter can be inserted into middle of large list*/
void insertAt_middleLargeList(){
    char arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList list(arr, 8);
    list.insertAt('p', 4);
    assert(list.size() == 9);
    assert(list.elementAt(4) == 'p');
    assert(list.toString() == "[CharLinkedList of size 9 <<abcdpefgh>>]");
}

/*tests that error is thrown when trying to insert out of range in full list*/
void insertAt_fullList_incorrect(){
    char arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList list(arr, 8);
    bool range_error_thrown = false;
    string error_message = "";
    try{
        list.insertAt('a', 30);
    }
    catch(std::range_error error){
        range_error_thrown = true;
        error_message = error.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (30) not in range [0..8]");
}

/*tests that chracter is inserted in correctly to back of full list*/
void insertINOrder_end_ofFullList(){
    CharLinkedList list;
    list.pushAtBack('a');
    list.pushAtBack('b');
    list.pushAtBack('c');
    list.pushAtBack('d');
    list.insertInOrder('e');
    assert(list.toString() == "[CharLinkedList of size 5 <<abcde>>]");
}

/*tests that chracter is inserted in correct order into middle of list*/
void insertInOrder_inMiddle(){
    CharLinkedList list;
    list.pushAtBack('a');
    list.pushAtBack('b');
    list.pushAtBack('d');
    list.pushAtBack('e');
    list.insertInOrder('c');
    std::cout << list.toString() << endl;
    assert(list.toString() == "[CharLinkedList of size 5 <<abcde>>]");
}

/*tests that two full list can be concatenated*/
void concatenate_twoFullList(){
    CharLinkedList list;
    CharLinkedList toy;
    list.pushAtBack('d');
    list.pushAtBack('o');
    list.pushAtBack('g');
    toy.pushAtBack('t');
    toy.pushAtBack('o');
    toy.pushAtBack('y');
    list.concatenate(&toy);
    assert(list.toString() == "[CharLinkedList of size 6 <<dogtoy>>]");
}

/*tests that and empty first list can concatenate with full second list*/
void concatenate_firstEmpty_secondFull(){
    CharLinkedList list;
    CharLinkedList toy;
    toy.pushAtBack('t');
    toy.pushAtBack('o');
    toy.pushAtBack('y');
    list.concatenate(&toy);
    assert(list.toString() == "[CharLinkedList of size 3 <<toy>>]");
}

/*tests that empty second list can concateneate with full first list*/
void concatenate_SecondEmpty_FirstFull(){
    CharLinkedList list;
    CharLinkedList toy;
    list.pushAtBack('d');
    list.pushAtBack('o');
    list.pushAtBack('g');
    list.concatenate(&toy);
    assert(list.toString() == "[CharLinkedList of size 3 <<dog>>]");
}

/*tests that the same list can concatenate itself*/
void concatenate_itself(){
    CharLinkedList list;
    list.pushAtBack('d');
    list.pushAtBack('o');
    list.pushAtBack('g');
    list.concatenate(&list);
    assert(list.toString() == "[CharLinkedList of size 6 <<dogdog>>]");
}

/*tests that two empty list concatenate*/
void concatenate_bothEmpty(){
    CharLinkedList list;
    CharLinkedList toy;
    std::cout << list.toString() << endl;
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}



/*
 *  CharLinkedList.cpp
 *  Akpevwe Akpoigbe
 *  2 - 1 - 2023
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Purpose: to create a doubly linkedlists that accomplishes many tasks
 *
 */

#include "CharLinkedList.h"
#include "iostream"
#include "sstream"
#include "string"
#include <stdexcept>

/*CharLinkedList
* Argument: none
* Description: creates an empty array list
* Return value: none
* Effects: sets pointers to nullptr*/
CharLinkedList::CharLinkedList(){
    front = nullptr;
    back = nullptr;
    Lsize = 0;
}

/*CharLinkedList
* Argument: a character
* Description: creates a single character linked list
* Return value: none
* Effects: none*/
CharLinkedList::CharLinkedList(char c){
    Lsize = 1;
    Node *data = new Node;
    front = data;
    back = data;
    data->next = nullptr;
    data->before = nullptr;
    data->name = c;
}

/*CharLinkedList
* Argument: a character array and a size
* Description: creates a linked list with a given size
* Return value: none
* Effects: using pushAtBack to add nodes to the list*/
CharLinkedList::CharLinkedList(char arr[], int size){
    Lsize = 0;
    front = nullptr;
    back = nullptr;
    for(int i = 0; i < size; i++){
        pushAtBack(arr[i]);
    }
}

/*CharLinkedList
* Argument: a reference to another CharLinkedList
* Description: makes a copy of a CharLinkedList
* Return value: none
* Effects: using pushAtBack to add nodes to the list*/
CharLinkedList::CharLinkedList(const CharLinkedList &other){
    Lsize = 0;
    front = nullptr;
    back = nullptr;
    for(int i = 0; i < other.Lsize; i++){
        pushAtBack(other.elementAt(i));
    }
}

/*CharLinkedList
* Arguement: an instance of a class
* Description: makes a deep copy of the instance passed in
* Return value: none
* Effects: using pushAtBack to add nodes to the list*/
CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other){
    /*clearing original list*/
    clear();
    for(int i = 0; i < other.Lsize; i++){
        pushAtBack(other.elementAt(i));
    }
    return *this;
}

/*isEmpty
* Argument: none
* Description: determines whether the list is empty or not
* Return value: true or false based on whether the list is empty or not
* Effects: it is a constant function*/
bool CharLinkedList::isEmpty() const {
    /*checks if list is empty*/
    if(front == nullptr and back == nullptr){
        return true;
    }
    else{
        return false;
    }
}

/*size
* Arguement: none
* Description: determines the size of the array
* Return value: the size of the array
* Effects: does not change the size*/
int CharLinkedList::size(){
    return Lsize;
}

/*clear
* Argument: none
* Description: clear all of the nodes from the linked list
* Return value: none
* Effects: calls on a recursive function*/
void CharLinkedList::clear(){
    /*recuresive call*/
    deallocate(front);
    front = nullptr;
    back = nullptr;
    Lsize = 0;
}

/*pushAtBack
* Argument: a single character
* Description: adds an individual character to the back of the list
* Return value: none
* Effects: incrases list size*/
void CharLinkedList::pushAtBack(char c){
    /*creates new node of originally empty*/
    if(Lsize == 0){
        Node *data = new Node{c, nullptr, nullptr};
        front = data;
        back = data;
    }else{
        Node *data = new Node;
        data->name = c;
        data->next = nullptr;
        data->before = back;
        back->next = data;
        back = data;
    }
    Lsize++;
}

/*pushAtFront
* Argument: a single character
* Description: adds a character to the front of the list
* Return value: none
* Effects: increases size of list*/
void CharLinkedList::pushAtFront(char c){
   /*adds new node to front in originally empty list*/
   if(Lsize == 0){
        Node *data = new Node{c, nullptr, nullptr};
        front = data;
        back = data;
    }else{
        Node *data = new Node;
        data->name = c;
        data->next = front;
        data->before = nullptr;
        front = data;
    }
    Lsize++;
}

/*first
* Argument: none
* Description: finds the first charater of the linked list
* Return value: the first character in the list
* Effects: throws an error if list is empty*/
char CharLinkedList::first() const{
    std::stringstream ss;
    ss << "cannot get first of empty LinkedList";
    if(Lsize == 0){
        throw std::runtime_error(ss.str());
    }
    return front->name;
}

/*last
* Argument: none
* Description: finds the last character of the linked list
* Return value: the last character in the list
* Effects: throws an error if list is empty*/
char CharLinkedList::last() const{
    std::stringstream ss;
    ss << "cannot get last of empty LinkedList";
    if(Lsize == 0){
        throw std::runtime_error(ss.str());
    }
    return back->name;
}

/*toString
* Argument: none
* Description: creates a string of all the cahracters in the linked list
* Return value: a string with all the words
* Effects: if list is empty returns a string saying this*/
std::string CharLinkedList::toString() const{
    std::string word;
    Node *curr = front;

    //case where it is empty list
    if(Lsize == 0){
        return "[CharLinkedList of size 0 <<>>]";
    }

    while(curr != nullptr){
        word += curr->name;
        curr = curr->next;
    }
    return "[CharLinkedList of size " + std::to_string(Lsize) + " <<" + word 
    + ">>]";
}

/*toReverseString
* Argument: none
* Description: traverses through a list backwards and prints the characters
* Return value: a string that is in reverse
* Effects: if list is empty returns a string saying this*/
std::string CharLinkedList::toReverseString() const{
    std::string word;
    Node *last = back;

    //empty list
    if(Lsize == 0){
        return "[CharLinkedList of size 0 <<>>]";
    }

    while(last != nullptr){
        word += last->name;
        last = last->before;
    }

    return "[CharLinkedList of size " + std::to_string(Lsize) + " <<" + word 
    + ">>]";
}

/*insertAt
* Argument: a single character and an index
* Description: inserts a single charcter at a given index
* Return value: none
* Effects: throws an error if index is out of range and calls pushAtBack
and pushAtFront*/
void CharLinkedList::insertAt(char c, int index){
    std::stringstream ss;
    ss << "index (" << index << ") " << "not in range [0.." << Lsize << "]";
    if(index > Lsize){
        throw std::range_error(ss.str());
    }

    //empty list
    if(Lsize == 0){
        Node *data = new Node{c, nullptr, nullptr};
        front = data;
        back = data;
        Lsize++;
    }
    //user inserts at first index
    else if(index == 0){
        pushAtFront(c);
    }
    //user inserts at back
    else if(index == Lsize){
        pushAtBack(c);
    }
    else{
        int count = 0;
        Node *curr = front;
        while(count < index - 1){
            curr = curr->next;
            count++;
        }
        Node *data = new Node{c, nullptr, nullptr};
        data->next = curr->next;
        curr->next = data;
        data->before = curr;
        data->next->before = data;
        Lsize++;
    }
}

/*insertInOrder
* Argument: a character the user passes into the function
* Description: inserts a character in increasing ASCII value number into list
* Return value: none
* Effects: call on insertAt*/
void CharLinkedList::insertInOrder(char c){
    int index = 0;
    Node *curr = front;
    //finds correct numerical index to be inserted at
    while(index < Lsize and curr->name < c){
        curr = curr->next;
        index++; 
    }
    insertAt(c, index);
}

/*removeAt
* Argument: an index
* Description: removes a node from a specified index
* Return value: none
* Effects: calls on popFromFront and popFromBack*/
void CharLinkedList::removeAt(int index){
    std::stringstream ss;
    ss << "index (" << index << ") " << "not in range [0.." << Lsize << ")";
    if(index >= Lsize or index < 0){
        throw std::range_error(ss.str());
    }
    Node *curr = front;
    int count = 0;
    if(index == 0){
        popFromFront();
    }
    else if(index == Lsize - 1){
        popFromBack();
    }
    //moves pointers around to point to next node and previous node
    else{
        while(count < index - 1){
            curr = curr->next;
            count++;
        }
        Node *temp = curr->next; 
        temp->next->before = curr;
        curr->next = temp->next;
        delete temp;
        Lsize--;
    }
}

/*elementAt
* Argument: an index
* Description: finds the node at a given index
* Return value: the character at the given index
* Effects: using a recursive funtion to find correct node*/
char CharLinkedList::elementAt(int index) const{
    std::stringstream ss;
    ss << "index (" << index << ") " << "not in range [0.." << Lsize << ")";
    if(index >= Lsize or index < 0){
        throw std::range_error(ss.str());
    }
    Node *curr = front;
    int curr_index = 0;
    //base cases
    if(index == 0){
        return first();
    }
    else if(index == Lsize - 1){
        return last();
    }
    //recursive case
    else{
        return finding_element(curr, curr_index, index);
    }
}

/*next_node
* Argument: a pointer to a node, the current index, and the index the user 
passed in
* Description: gets the next node in the list and keeps track of the count
* Return value: a count of how many nodes I have looked at
* Effects: recurses*/
char CharLinkedList::finding_element(Node *curr, int curr_index, int index)const
{
    curr = curr->next;
    curr_index++;
    //base case
    if(curr_index == index){
        return curr->name;
    }
    //recursive case
    return finding_element(curr, curr_index, index);
}

/*replaceAt
* Argument: a single character and an index
* Description: replaces a node at a specified index with another character
* Return value: none
* Effects: usses a recursive helper function*/
void CharLinkedList::replaceAt(char c, int index){
    std::stringstream ss;
    ss << "index (" << index << ") " << "not in range [0.." << Lsize << ")";
    if(index >= Lsize or index < 0){
        throw std::range_error(ss.str());
    }
    int curr_index = 0;
    Node *curr = front;
    Node *last = back;
    //base cases
    if(index == 0){
        curr->name = c;
    }
    else if(index == Lsize - 1){
        last->name = c;
    }
    //recursive case
    else{
        getting_node(curr, curr_index, index, c);
    }
}

/*replace_node
* Argument: a pointer to a node, the current index, a specified index, and 
  a single charcter
* Description: finds a node to replace in the list
* Return value: a node
* Effects: recursive function*/
CharLinkedList::Node *CharLinkedList::getting_node(Node *curr, int curr_index, 
                                                int index, char c){
    //base case
    if(curr_index == index){
        curr->name = c;
        return curr;
    }
    curr_index++;
    //recursive case
    return getting_node(curr->next, curr_index, index, c);
}

/*popFromFront
* Argument: none
* Description: removes the first element in a linked list
* Return value: none
* Effects: reduces size of list*/
void CharLinkedList::popFromFront(){
    std::stringstream ss;
    ss << "cannot pop from empty LinkedList";
    //checks if list is empty
    if(Lsize == 0){
        throw std::runtime_error(ss.str());
    }
    else if(Lsize == 0){
        back = nullptr;
    }
    else{
        front->before = nullptr;
    }
    Node *curr = front->next;
    delete front;    
    front = curr;
    Lsize--;
}

/*popFromBack
* Argument: none
* Description: removes the last element in a linked list
* Return value: none
* Effects: reduces size of list*/
void CharLinkedList::popFromBack(){
    std::stringstream ss;
    ss << "cannot pop from empty LinkedList";
    
    if(Lsize == 0){
        throw std::runtime_error(ss.str());
    }
    if(Lsize == 0){
        front = nullptr;
    }
    else{
        //removes last node
        Node *curr = back->before;
        delete back;
        back = curr;
        back->next = nullptr;
        Lsize--;
    }
}

/*concatenate
* Argument: a reference to another linked list
* Description: adds another linked list to the back of an existing one
* Return value: none
* Effects: uses the pushAtBack function*/
void CharLinkedList::concatenate(CharLinkedList *other){
    int range = other->Lsize;
    //adds other linked list to current one
    for(int i = 0; i < range; i++){
        pushAtBack(other->elementAt(i));
    }
    
}

/*deallocate
* Argument: a pointer to a node
* Description: deletes nodes from a list
* Return value: none
* Effects:: is recursive*/
void CharLinkedList::deallocate(Node *curr){
    //base case
    if(curr == nullptr){
        return;
    }
    //recursive case
    else{
        deallocate(curr->next);
        delete curr;
    }
}

/*~CharLinkedList
* Argument: none
* Description: deletes nodes from the list
* Return value: none
* Effects: none*/
CharLinkedList::~CharLinkedList(){
    deallocate(front);
}

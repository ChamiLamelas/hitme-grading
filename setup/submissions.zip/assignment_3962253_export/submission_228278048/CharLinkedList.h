/*
 *  CharLinkedList.h
 *  Akpevwe Akpoigbe
 *  2 - 1 - 2023
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Purpose: to define the methods that will be use in CharLinkedList.cpp
 *
 */

#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H
#include <string>
using namespace std;

class CharLinkedList {
public:
    CharLinkedList();
    CharLinkedList(char c);
    CharLinkedList(char arr[], int size);
    CharLinkedList(const CharLinkedList &other);
    CharLinkedList &operator=(const CharLinkedList &other);
    ~CharLinkedList();
    bool isEmpty() const;
    int size();
    void clear();
    void pushAtBack(char c);
    void pushAtFront(char c);
    char first() const;
    char last() const;
    string toString() const;
    string toReverseString() const;
    void insertAt(char c, int index);
    void insertInOrder(char c);
    char elementAt(int index) const;
    void replaceAt(char c, int index);
    void removeAt(int index);
    void popFromFront();
    void popFromBack();
    void concatenate(CharLinkedList *other);


private:
    struct Node {
        char name;
        Node *next;
        Node *before;
    };

    Node *front;
    Node *back;
    int Lsize;
    void deallocate(Node *curr);
    char finding_element(Node *curr, int curr_index, int index) const;
    Node *getting_node(Node *curr, int curr_index, int index, char c);
};

#endif

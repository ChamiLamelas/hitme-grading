/*
 *  CharLinkedList.cpp
 *  Heidi Rono
 *  1/31/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 * Implements a Chararcer Linked List ADT, with the capabilities of adding, 
 * removing, inserting, and many other functions. 
 *
 */

#include "CharLinkedList.h"
#include <stdexcept>

/*
 * name: CharLinkedList
 * purpose: creates a blank object of the CharLinkedList class 
 * arguments: none
 * returns: none
 * effects: creates an empty instance of currSize, and a null frot, and back
 */
CharLinkedList::CharLinkedList() {
    currSize = 0;
    front = nullptr;
    back = nullptr;
}

/*
 * name: CharLinkedList
 * purpose: creates a linked list of size 1 containing char c
 * arguments: char c
 * returns: none
 * effects: sets the front and back pointer to the node including c, previous 
 * and next pointers within the node are null
 */
CharLinkedList::CharLinkedList(char c) {
    //using newNode helper function 
    front = newNode(c, nullptr, nullptr);

    back = front; 
    currSize = 1;
}

/*
 * name: CharLinkedList
 * purpose: creates a linked list containing the given array
 * arguments: char arr, int size
 * returns: none
 * effects: sets the front and back pointer of the linked list, populates the 
 * rest of the list with the values contained in the array, each connected by
 * a next and previous pointer
 */
CharLinkedList::CharLinkedList(char arr[], int size) {
    currSize = size;
    front = newNode(arr[0], nullptr, nullptr);
    Node *curr = front;
    for(int i = 1; i < currSize; i++) {
        curr->next = newNode(arr[i], nullptr, curr);
        curr = curr->next;
    }
    back = curr;
}

/*
 * name: CharArrayList(const CharArrayList &other)
 * purpose: creates a deep copy of the linked list
 * arguments: const CharLinkedList &other
 * returns: none
 * effects: prevents double free when trying to copy the linked list
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other) {
    if(other.isEmpty()) {
        currSize = 0;
        front = nullptr;
        back = nullptr;

        return;
    }
    //setting currSize to the values of other
    this->currSize = other.size();

    //creating a new node for the front of our copy, making sure it has the 
    //same data as the old one 
    this->front = newNode(other.elementAt(0), nullptr, nullptr);
    //setting holder variables to traverse through the linked lists
    Node *curr = this->front;
    
    //copying the data over to the new linked list
    for(int i = 1; i < currSize; i++) {
        curr->next = newNode(other.elementAt(i), nullptr, curr);
        curr = curr->next;
    }
    this->back = curr;

}

/*
 * name: CharArrayList(const CharArrayList &other)
 * purpose: creates a deep copy of the data ArrayList when two are compared 
 * with '='
 * arguments: const CharLInkedList &other
 * returns: none
 * effects: prevents double free when setting two CharLinkedLists equal to 
 * eachother 
 */
CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other) {
    //checking to see if rhs and lhs are equal
    if (this == &other) {
        return *this;
    }

    //deallocate memory for old lhs
    clear();

    //allocate memory for lhs
    currSize = other.size();

    //creating a new node for the front of our copy, making sure it has the 
    //same data as the old one 
    front = newNode(other.elementAt(0), nullptr, nullptr);
    //setting holder variables to traverse through the linked lists
    Node *curr = front;
    
    //copying the data over to the new linked list
    for(int i = 1; i < currSize; i++) {
        curr->next = newNode(other.elementAt(i), nullptr, curr);
        curr = curr->next;
    }
    back = curr;

    return *this;
}

/*
 * name: ~CharLinkedList
 * purpose: deletes data used by CharLinkedList off of the heap
 * arguments: none
 * returns: none
 * effects: recycles data off of the heap so that it can be used again by 
 * calling a recursive helper function 
 */
CharLinkedList::~CharLinkedList(){
    deleteRecursive(front);
}

/*
 * name: deleteRecursive
 * purpose: recursively deletes CharLinkedList data off of the heap 
 * arguments: Node *curr
 * returns: none
 * effects: recursively runs through the linked list until all nodes are 
 * deleted, uses Node *curr to keep track
 */
void CharLinkedList::deleteRecursive(Node *curr) {
    //base case
    if(curr == nullptr) {
        return;

        //recursive case
    } else {
        //deleting current node and moving to next
        deleteRecursive(curr->next);
        delete curr;
    }
}

/*
 * name: size
 * purpose: returns the private variable currSize
 * arguments: none
 * returns: int currSize
 * effects: allows users outside of the CharLinkedList class to access but 
 * not change currSize
 */
int CharLinkedList::size() const {
    return currSize;
}

/*
 * name: first
 * purpose: returns the char in the first node of the linked list 
 * arguments: none
 * returns: the first character in the class
 * effects: throws an error if called on an empty array, allows for the access
 * of contents within the private Node class
 */
char CharLinkedList::first() const {
    if(currSize == 0) {
        std::string error = "cannot get first of empty LinkedList";
        throw std::runtime_error(error);
    } else {
         return front->data;
    }
}

/*
 * name: last
 * purpose: returns the last character in the CharLinkedList
 * arguments: none
 * returns: the last character in the linked list
 * effects: throws an error if this is called on an empty array, otherwise
 * returns the correct value
 */
char CharLinkedList::last() const {
    if(currSize == 0) {
        std::string error = "cannot get last of empty LinkedList";
        throw std::runtime_error(error);
    } else {
        return back->data;
    }
}

/*
 * name: elementAt
 * purpose: returns the character at the index given
 * arguments: int index
 * returns: the charcter at int index
 * effects: throws an error if this if index is out of range, otherwise 
 * returns the correct value
 */
char CharLinkedList::elementAt(int index) const {
    //returning the correct index if it's in range
    if(index < currSize and index >= 0 and currSize > 0) {
        //calling on recursive helper function
        Node *elem = findNode(index, 0, front);
        return elem->data;
    //otherwise, throwing range error
    } else {
        std::string error1 = "index (" + std::to_string(index) + ") "; 
        std::string error2 = "not in range [0..";
        std::string error3 = std::to_string(currSize) + ")";

        throw std::range_error(error1 + error2 + error3);
    }
}

/*
 * name: isEmpty
 * purpose: determines whether or not the linked list is empty
 * arguments: none
 * returns: bool true if the list is empty, false if not
 * effects: allows for user to determine whether linked list is empty
 */
bool CharLinkedList::isEmpty() const {
    return currSize == 0;
}

/*
 * name: clear
 * purpose: clears all of the elements in the LinkedList
 * arguments: none
 * returns: none
 * effects: effectively clears all of the elements in the linked list, 
 * recycling the data on the heap and resetting size and front & back 
 * pointers
 */
void CharLinkedList::clear() {
    //calling the helper function that recycles data
    deleteRecursive(front);
    
    //resetting size and pointers
    currSize = 0;
    front = nullptr;
    back = nullptr;
}


/*
 * name: toString()
 * purpose: creates a string with the correct message  
 * arguments: none
 * returns: a string holding the message specified in the spec
 * effects: allows user to use the return in order to test many other 
 * functions within the CharLinkedList class, very helpful for testing
 */
std::string CharLinkedList::toString() const {

    //creating an object of std::stringstream to return
    std::stringstream message;

    message << "[CharLinkedList of size " << currSize << " <<";

    //populating message with the chars in linked list
    Node *curr = front;
    while(curr != nullptr) {
        message << curr->data;
        curr = curr->next;
    }

    message << ">>]";

    //returning the full string message
    return message.str();
}

/*
 * name: toReverseString()
 * purpose: creates a reverse ordered string of the linked list
 * arguments: none
 * returns: a string holding the message specified in the spec
 * effects: allows user to use the return in order to test many other 
 * functions within the CharLinkedList class, as well as reverse the list
 */
std::string CharLinkedList::toReverseString() const {
    //creating an object reverse
    std::stringstream reverse;

    //adding the size and beginning of the message to string
    reverse << "[CharLinkedList of size " << currSize << " <<";

    //populating reverse with the chars in linked list
    Node *curr = back;
    while(curr != nullptr) {
        reverse << curr->data;
        curr = curr->previous;
    }

    reverse << ">>]";

    //returning the full reverse string
    return reverse.str(); 
} 

/*
 * name: pushAtFront
 * purpose: adds a character to the front of the list
 * arguments: char c
 * returns: none
 * effects: changes the first element in the list, also changes front pointer
 */
void CharLinkedList::pushAtFront(char c) {
    //when size is 0, making back and front equal to the new node
    if(currSize == 0) {
       front = newNode(c, front, nullptr);
       back = front;

    //otherwise inserting node to front 
    } else {
        front = newNode(c, front, nullptr);
        //changing the second node's pointers to correspond with new front
        Node *second = front->next;
        second->previous = front;
    }

    currSize++;
}

/*
 * name: pushAtBack
 * purpose: adds a character to the back of the linked list
 * arguments: char c
 * returns: none
 * effects: changes the last element in the list and the back pointer
 */
void CharLinkedList::pushAtBack(char c) {
    //if size is 0, call pushAtFront (has code written for when size == 0)
    if(currSize == 0) {
        pushAtFront(c);

    //otherwise adding to back of existing list
    } else {
        back = newNode(c, nullptr, back);
        
        //changing the surrounding nodes to correspond with the new back
        Node *last = back->previous;
        last->next = back;

        currSize++;
    }
}

/*
 * name: insertAt
 * purpose: inserts an element at the given index of the linked list 
 * arguments: char c, int index
 * returns: none
 * effects: can insert an element anywhere, changing the subsequent pointers, 
 * throws an error when index is out of range
 */
void CharLinkedList::insertAt(char c, int index) {
    if(index >= 0 and index <= currSize) {
        //checking for if inserting at front/back and calling those functions
        if(index == 0) {
            pushAtFront(c);
            return;
        }
        if(index == currSize) {
            pushAtBack(c);
            return;
        }
        //holder variables to keep spot while traversing through list
        Node *curr = front;
        int count = 0;
        //moves down list until index-1, or spot where node will be inserted
        while(count < index - 1) {
            curr = curr->next;
            count++;
        }
        //inserting the new node
        curr->next = newNode(c, curr->next, curr);
        currSize++;
    //throwing error when index is out of range
    } else {
        std::string error1 = "index (" + std::to_string(index) + ") "; 
        std::string error2 = "not in range [0..";
        std::string error3 = std::to_string(currSize) + ")";
        throw std::range_error(error1 + error2 + error3);
    }
}

/*
 * name: popFromFront
 * purpose: deletes the first element of the linked list
 * arguments: none
 * returns: none
 * effects: deletes the first node of the linked list off the heap, makes the
 * second element the new front
 */
void CharLinkedList::popFromFront() {
    if(currSize > 1) {
        //temp variable to hold the first node
        Node *old_front = front;

        //making front the second variable
        front = front->next;
        front->previous = nullptr;

        //deleting original front off the heap
        delete old_front;

        currSize--;

    //throwing error if empty list
    } else if(currSize == 1) {
        clear();
    } else {
        throw std::runtime_error("cannot pop from empty LinkedList");
    }
}

/*
 * name: popFromBack
 * purpose: deletes the last element of the linked list
 * arguments: none
 * returns: none
 * effects: deletes the last node of the linked list off the heap, makes the
 * second to last element the new back
 */
void CharLinkedList::popFromBack() {
    if(currSize > 1) {
        //temp variable 
        Node *old_back = back;
        //making new back pointer to 2nd to last node
        back = back->previous;
        back->next = nullptr;

        delete old_back;

        currSize--;

    } else if(currSize == 1) {
        clear();
    } else {
        throw std::runtime_error("cannot pop from empty LinkedList");
    }
}

/*
 * name: insertInOrder
 * purpose: inserts a character in alphabetical order to the list
 * arguments: char c
 * returns: none
 * effects: finds where the lette should be placed, calls the insert at 
 * function with found index
 */
void CharLinkedList::insertInOrder(char c) {
    int count = 0;
    Node *curr = front;
    
    //when inserting at an empty array, push at front
    if(currSize == 0) {
        pushAtFront(c);
        return;
    }

    //going through linked list to find alphabetically where c goes 
    while(count < currSize and c > curr->data) {
        count++;
        curr = curr->next;
    }

    //count will be where the data is supposed to go 
    insertAt(c, count);
}

/*
 * name: removeAt
 * purpose: removes the character at the given index from the list
 * arguments: int index
 * returns: none
 * effects: uses a recursive helper function to find the node that needs to be
 * removed, reassigns the correct pointers 
 */
void CharLinkedList::removeAt(int index) {
    //when the index of the needed function isn't on the edges
    if(index < currSize - 1 and index > 0) {
        //creating holder nodes in order to reassign the pre and next pointers
        Node *old = findNode(index, 0, front);
        Node *pre = old->previous;
        Node *nex = old->next;

        //reassigning
        pre->next = nex;
        nex->previous = pre;

        //recycling data off heap and decreasing size
        delete old;
        currSize--;

    //when index is on the edge, calling the correct functions
    } else if(index == 0) {
        popFromFront();
    } else if (index == currSize - 1) {
        popFromBack();

    //throwing error if out of range
    } else {
        std::string error1 = "index (" + std::to_string(index) + ") "; 
        std::string error2 = "not in range [0..";
        std::string error3 = std::to_string(currSize) + ")";
        throw std::range_error(error1 + error2 + error3);
    }
}

/*
 * name: replaceAt
 * purpose: changes the character at the given index from the list
 * arguments: char c, int index
 * returns: none
 * effects: uses a recursive helper function to find the node that needs to be
 * replaced, reassigns the data at the node 
 */
void CharLinkedList::replaceAt(char c, int index) {
    if(index < currSize and index >= 0 and currSize > 0) {

        //calling recursive helper function
        Node *replace = findNode(index, 0, front);
        //changing the character within the found node
        replace->data = c;

    //throwing an error if out of range
    } else {
        std::string error1 = "index (" + std::to_string(index) + ") "; 
        std::string error2 = "not in range [0..";
        std::string error3 = std::to_string(currSize) + ")";
        throw std::range_error(error1 + error2 + error3);
    }
}

/*
 * name: Concatenate
 * purpose: copys one CharLinkedList and adds it onto the end of this
 * CharLinkedList
 * arguments: CharLinkedList *other
 * returns: none
 * effects: copys in information from one list onto the end of another
 */
void CharLinkedList::concatenate(CharLinkedList *other) {
    if(other->isEmpty()) {
        return;
    } else {
        int sizeO = other->size();
        for(int i = 0; i < sizeO; i++) {
            pushAtBack(other->elementAt(i));
    }
    }
}

/*
 * name: CharLinkedList::newNode
 * purpose: creates a new node on the heap and assigns next and previous 
 * pointers
 * arguments: char NewData, Node *n, Node *p
 * returns: Node *new_node
 * effects: other functions can call on this and create a new node, can insert
 * anywhere on the linked list
 */
CharLinkedList::Node *CharLinkedList::newNode(char newData, Node *n, Node *p) 
{
    Node *new_node = new Node;
    new_node->data = newData;
    new_node->next = n;
    new_node->previous = p;

    return new_node;
}

/*
 * name: findNode
 * purpose: finds a node at the given index within the linked list
 * arguments: char NewData, Node *n, Node *p
 * returns: Node *curr
 * effects:recursively moves through the linked list, finding the node at index
 */
CharLinkedList::Node *CharLinkedList::
findNode(int index, int count, Node *curr) const {
    if(count == index) {
        return curr;
    } else {
        curr = curr->next;
        count++;
        return findNode(index, count, curr);
    }
}




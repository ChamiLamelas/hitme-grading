/*
 *  unit_tests.h
 *  Heidi Rono
 *  1/31/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  Tests each function of CharLinkedList.cpp and ensure that it is 
 * functioning correctly. 
 *
 */

 

#include <cassert>
#include "CharLinkedList.h"
#include <string>

//Test main constructor
 // creating a new instance of the class and making sure that the size returns
 // 0
void constructorTestEmpty() {
    CharLinkedList test;
    assert(test.size() == 0);
}

//test constructor that takes in a single character
//sending in h, making sure size is one and the node data is h
void constructorTestChar(){
    CharLinkedList test2('h');
    assert(test2.size() == 1);
    assert(test2.first() == 'h');
}

//testing constructor that takes in an array and size
// sending in array, then testing that the size and elements 
// correspond
void constructorTestArray(){
    char array[5] = {'h', 'e', 'i', 'd', 'i'};
    CharLinkedList test3(array, 5);
    assert(test3.size() == 5);
    assert(test3.first() == 'h');
    assert(test3.last() == 'i');
    assert(test3.toString() == "[CharLinkedList of size 5 <<heidi>>]");
}

//testing to make sure that first throws the correct error
//creating an empty list then calling first
void firstTestError(){
    CharLinkedList front;
    bool runtime_error_thrown = false;
    std::string error_message = "";

    try {
        front.first();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "cannot get first of empty LinkedList");
}

//testing to make sure that the last throws out the correct errors
// giving the last function an incorrect value
void lastTestError(){
    CharLinkedList last;
    bool runtime_error_thrown = false;
    std::string error_message = "";

    try {
        last.last();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "cannot get last of empty LinkedList");
}

//testing toString when given a small array
void toStringtest(){
    char array[3] = {'l', 'o', 'l'};
    CharLinkedList string(array, 3);
    assert(string.toString() == "[CharLinkedList of size 3 <<lol>>]");
}
//testing to make sure toString works for a size of 0
void toStringtest0(){
    CharLinkedList zero;
    assert(zero.toString()== "[CharLinkedList of size 0 <<>>]");
}

//testing toReverseString, sending in a word and ensuring it is 
// reversed
void toReverseStringT(){
    char array[4] = {'l', 'a', 'w', 'n'};
    CharLinkedList reverse(array, 4);
    assert(reverse.toReverseString() == "[CharLinkedList of size 4 <<nwal>>]");
}

//testing whether a string of size 0 works with toReverseString:
//should end up with an empty string
void toReverseStringT0(){
    CharLinkedList zero;
    assert(zero.toReverseString()== "[CharLinkedList of size 0 <<>>]");
}

//testing the front test, making sure it correctly shifts elements
//first element should be h
void frontTestNormal(){
    char array[3] = {'l', 'l', 'o'};
    CharLinkedList front(array, 3);
    front.pushAtFront('e');
    front.pushAtFront('h');
    assert(front.first() == 'h');
    assert(front.toReverseString() == "[CharLinkedList of size 5 <<olleh>>]");

}
//testing to make sure pushAtFront works when adding to a blank array
//should end up with rad
void frontTestReverse(){
    CharLinkedList front; 
    front.pushAtFront('d');
    assert(front.first() == 'd');
    assert(front.size() == 1);
    front.pushAtFront('a');
    front.pushAtFront('r');
    assert(front.size() == 3);
    assert(front.toReverseString() == "[CharLinkedList of size 3 <<dar>>]");
}

//testing to make sure that the pushAtFront works with an empty array
void frontTestEmpty() {
    CharLinkedList test;
    test.pushAtFront('z');
    assert(test.toString() == "[CharLinkedList of size 1 <<z>>]");
    assert(test.toReverseString() == "[CharLinkedList of size 1 <<z>>]");
}

//testing to make sure front works with a large array 
void frontTestLarge(){
    char array[10] = {'a','b','c','d','e','f','g','h','i','j'};
    CharLinkedList test(array, 10);
    test.pushAtFront('z');
    assert(test.first() == 'z');
    assert(test.toString() == "[CharLinkedList of size 11 <<zabcdefghij>>]");
}

//testing to make sure pushAtBack puts the char in the correct place
void backTest(){
    char array[4] = {'o', 'o', 'p', 's'};
    CharLinkedList test(array, 4);
    test.pushAtBack('y');
    assert(test.last() == 'y');
    assert(test.toReverseString() == "[CharLinkedList of size 5 <<yspoo>>]");
    assert(test.toString() == "[CharLinkedList of size 5 <<oopsy>>]");
}

//testing when adding an element to an empty array
// should have size equal to 1 and just q in the array
void backTestEmpty(){
    CharLinkedList backTest;
    backTest.pushAtBack('q');
    assert(backTest.last() == 'q');
    assert(backTest.toString() == "[CharLinkedList of size 1 <<q>>]");
}

//testing to make sure back works on a large array
void backTestLarge(){
    char array[10] = {'a','b','c','d','e','f','g','h','i','j'};
    CharLinkedList test(array, 10);
    test.pushAtBack('z');
    assert(test.last() == 'z');
    assert(test.toString() == "[CharLinkedList of size 11 <<abcdefghijz>>]");
}

// Tests correct insertion into an empty AL.
// Afterwards, size should be 1 and element at index 0
// should be the element we inserted.
void insertAt_empty_correct() { 

    CharLinkedList test_list;
    test_list.insertAt('a', 0);
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');

}

// Tests incorrect insertion into an empty AL.
// Attempts to call insertAt for index larger than 0.
// This should result in an std::range_error being raised.
void insertAt_empty_incorrect() {

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    // insertAt for out-of-range index
    test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
    // if insertAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    range_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0)");
    
}

// Tests correct insertAt for front of 1-element list.
void insertAt_front_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at front
    test_list.insertAt('b', 0);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'a');
    
}

// Tests correct insertAt for back of 1-element list.
void insertAt_back_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at back
    test_list.insertAt('b', 1);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    
}

// Tests calling insertAt for a large number of elements.
// Not only does this test insertAt, it also checks that
// array expansion works correctly.
void insertAt_many_elements() {
    
    CharLinkedList test_list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.insertAt('a', i);
    }

    assert(test_list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
    
}

// Tests insertion into front of a larger list
void insertAt_front_large_list() {
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    test_list.insertAt('y', 0);

    assert(test_list.size() == 10);
    assert(test_list.elementAt(0) == 'y');
    assert(test_list.toString() =="[CharLinkedList of size 10 <<yabczdefgh>>]");

}

// Tests insertion into the back of a larger list
void insertAt_back_large_list() {

    char test_arr[10] = { 'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 10);  

    test_list.insertAt('x', 10);

    assert(test_list.size() == 11);
    assert(test_list.elementAt(10) == 'x');
    assert(test_list.toString() == 
    "[CharLinkedList of size 11 <<yabczdefghx>>]"); 

}

// Tests insertion into the middle of a larger list
void insertAt_middle_large_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.insertAt('z', 3);

    assert(test_list.size() == 9);
    assert(test_list.elementAt(3) == 'z');
    assert(test_list.toString() == "[CharLinkedList of size 9 <<abczdefgh>>]");

}

// Tests out-of-range insertion for a non-empty list.
void insertAt_nonempty_incorrect() {
   
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8)");
    
}
//testing to make sure insert changes size 
void insertAt_size(){
    char array[3] = {'b', 'o', 't'};
    CharLinkedList test(array, 3);
    assert(test.size() == 3);
    test.insertAt('a', 2);
    assert(test.toString() == "[CharLinkedList of size 4 <<boat>>]");
}

//testing to make sure that insert works with the previous pointers
void insertAt_pointer() {
    char array[3] = {'r', 'a', 't'};
    CharLinkedList test(array, 3);
    test.insertAt('b', 0);
    assert(test.toReverseString() == "[CharLinkedList of size 4 <<tarb>>]");
}

//testing whether elementAt throws the correct errors
// giving it incorrect indexes (larger than size, less than 0)
// ensuring it throws errors for this 
void elementAtTestError(){
    bool range_error_thrown = false;
    std::string error_message = "";

    CharLinkedList test;
    try {
        test.elementAt(0);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (0) not in range [0..0)");
}

//testing to make sure elementAt throws the correct errors 
// giving it an index outside of range
void elementAtTestError2(){
    bool range_error_thrown = false;
    std::string error_message = "";

    char array[3] = {'h', 'o', 't'};
    CharLinkedList test(array, 3);
    try {
        test.elementAt(3);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (3) not in range [0..3)");
}

//testing to make sure elementAt retrievees the correct char
void elementAtTestFirst(){
    char array[3] = {'h', 'o', 't'};
    CharLinkedList test(array, 3);
    assert(test.elementAt(0) == 'h');
}

//testing elementAT with a large array 
void elementAtTestLarge() {
    char array[10] = {'a','b','c','d','e','f','g','h','i','j'};
    CharLinkedList test(array, 10);
    assert(test.elementAt(5) == 'f');
}

//testing isEmpty is correct
//size should be 0, and isEmpty should be true
void isEmptyTest(){
    CharLinkedList empty;
    assert(empty.isEmpty());
}

//testing clear function 
void testClear(){
    CharLinkedList test;
    test.pushAtFront('a');
    test.pushAtBack('b');
    test.clear();
    assert(test.isEmpty());
}

//testing popFromFront removes the correct element
//should change size and contents of array
void popFromFrontNormal() {
    char array[3] = {'a', 'b', 'y'};
    CharLinkedList test(array, 3);
    test.popFromFront();
    assert(test.toReverseString() == "[CharLinkedList of size 2 <<yb>>]");
}

//testing popFromFront gives the correct errors
//creating an empty list and then calling pop from front, should throw 
// an error
void popFromFrontError() {
    CharLinkedList test;
    bool runtime_error_thrown = false;
    std::string error_message = "";

    try {
        test.popFromFront();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

//testing popping from a list of size 1 
//should create a list of size 0
void popFromFrontEmpty() {
    CharLinkedList test('r');
    test.popFromFront();
    assert(test.isEmpty());
}

//testing to make sure popFromBack correctly deletes the last element
//ensuring size and contents of list are correct - deleting y, so that the 
// list is "ab"
void popFromBackNormal(){
    char array[3] = {'a', 'b', 'y'};
    CharLinkedList test(array, 3);
    test.popFromBack();
    assert(test.elementAt(0) == 'a');
    assert(test.size() == 2);
    assert(test.toString() == "[CharLinkedList of size 2 <<ab>>]");
}

//testing to make sure PopFromBack correctly throws an error
//creating an empty list, should throw an error
void popFromBackError(){
    CharLinkedList test;
    bool runtime_error_thrown = false;
    std::string error_message = "";

    try {
        test.popFromBack();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");    
}

//testing popping from a list of size 1
//should create an empty list 
void popFromBackEmpty() {
    CharLinkedList test('r');
    test.popFromBack();
    assert(test.isEmpty());
}

//testing normal function of insert in order
//should change size and correctly place d in the 4th slot 
void insertOrderNormal(){
    char array[5] = {'a', 'b', 'c', 'e', 'f'};
    CharLinkedList test(array, 5);
    test.insertInOrder('d');
    assert(test.toString() == "[CharLinkedList of size 6 <<abcdef>>]");
}

//testing insertInOrder to an empty array 
//should just place the letter in the front
void insertOrderEmpty(){
    CharLinkedList test;
    test.insertInOrder('d');
    assert(test.toString() == "[CharLinkedList of size 1 <<d>>]");
}

//testing when adding an InsertInOrder to the end of the array
//should place y at the end of the array
void insertOrderEnd(){
    char array[3] = {'a', 'b', 'y'};
    CharLinkedList test(array, 3);
    test.insertInOrder('z');
    assert(test.toString() == "[CharLinkedList of size 4 <<abyz>>]");
}

//testing insert in order for a large list
//should insert b at the end of the list 
void insertOrderLarge() {
    CharLinkedList test;
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test.insertAt('a', i);
    }
    test.insertInOrder('b');
    assert(test.elementAt(1000) == 'b');
}
//testing adding to the front
//should start off by adding the element to the front
void insertOrderFront(){
    CharLinkedList test;
    test.pushAtFront('z');
    test.insertInOrder('a');
    assert(test.elementAt(0) == 'a');
}

//testing to make sure removeAt works normally
//removing a value from a small array
void removeNormal(){
    char array[3] = {'a', 'b', 'y'};
    CharLinkedList test(array, 3);
    test.removeAt(1);
    assert(test.toString() == "[CharLinkedList of size 2 <<ay>>]");
    assert(test.toReverseString() == "[CharLinkedList of size 2 <<ya>>]");
}

//testing to make sure removeAt works when removing the first element
void removeNormal2(){
    char array[3] = {'a', 'b', 'y'};
    CharLinkedList test(array, 3);
    test.removeAt(0);
    assert(test.toString() == "[CharLinkedList of size 2 <<by>>]");
    assert(test.toReverseString() == "[CharLinkedList of size 2 <<yb>>]");
}

//testing to make sure that removeAt works when removing the last element
void removeLast(){
    char array[3] = {'a', 'b', 'y'};
    CharLinkedList test(array, 3);
    test.removeAt(2);
    assert(test.toString() == "[CharLinkedList of size 2 <<ab>>]");
}

//testing to make sure that removeAt throws the correct error
// when putting a value outside of index
void removeErrorRange(){
    bool range_error_thrown = false;
    std::string error_message = "";

    char array[3] = {'h', 'o', 't'};
    CharLinkedList test(array, 3);
    try {
        test.removeAt(3);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (3) not in range [0..3)");
}

//testing to make sure that removeAt throws the correct error
// when putting a value outside of index
void removeErrorEmpty(){
    bool range_error_thrown = false;
    std::string error_message = "";

    char array[3] = {'h', 'o', 't'};
    CharLinkedList test(array, 3);
    try {
        test.removeAt(-1);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (-1) not in range [0..3)");
}

//testing when the array is size one that removeAt works properly
void removeToEmpty() {
    CharLinkedList test('a');
    test.removeAt(0);
    assert(test.toString() == "[CharLinkedList of size 0 <<>>]");
}

//testing to make sure the replaceAt function does the correct job,
//when given the correct inputs - should change lane to lake
void replaceAtNormal(){
    char array[4] = {'l', 'a', 'n', 'e'};
    CharLinkedList test(array, 4);
    test.replaceAt('k', 2);
    assert(test.toString() == "[CharLinkedList of size 4 <<lake>>]");
}

//testing to make sure the correct errors are thrown
//will give an index larger than size, should catch a range error
void replaceAtError(){
    CharLinkedList test('a');
    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
    test.replaceAt('a', 1);
    }
    catch (const std::range_error &e) {
    // if insertAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    range_error_thrown = true;
    error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (1) not in range [0..1)");

}
//test to see if replaceAt will throw an error with a neg index
void replaceAtNegative(){
    CharLinkedList test;
    bool range_error_thrown = false;
    std::string error_message = "";

    try {
        test.replaceAt('a', -1);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (-1) not in range [0..0)");
}

//testing to make sure the replaceAt function works with a list of size 1
void replaceAtSmall() {
    CharLinkedList test('a');
    test.replaceAt('b', 0);
    assert(test.toString() == "[CharLinkedList of size 1 <<b>>]");
}

//testing copy constructor to make sure a deep copy is made 
//using the copy constructor and then making changes to copy to make 
// sure original doesn't change
void copyTest(){
    char array[5] = {'h', 'e', 'i', 'd', 'i'};
    CharLinkedList test1(array, 5);
    CharLinkedList test2(test1);
    assert(test2.toString() == "[CharLinkedList of size 5 <<heidi>>]");
    test2.pushAtBack('r');
    assert(test2.toString() == "[CharLinkedList of size 6 <<heidir>>]");
    assert(test1.toString() == "[CharLinkedList of size 5 <<heidi>>]");
    test1.popFromBack();
    assert(test2.toString() == "[CharLinkedList of size 6 <<heidir>>]");
    assert(test1.toString() == "[CharLinkedList of size 4 <<heid>>]");
}

//testing the copy constructor on an empty list 
void copyTestEmpty() {
    CharLinkedList test1;
    CharLinkedList test2(test1);
    assert(test2.size() == 0);
    test2.pushAtBack('c');
    assert(test2.elementAt(0) == 'c');
    assert(test1.size() == 0);
}

//testing assignment operator 
//setting one arraylist equal to a new one, then changing second one 
//making sure the first array is unchanged, and the second one is 
void assignmentTest() {
    char array[5] = {'h', 'e', 'i', 'd', 'i'};
    CharLinkedList test1(array, 5);
    CharLinkedList test2 = test1;
    assert(test2.toString() == "[CharLinkedList of size 5 <<heidi>>]");
    test2.pushAtBack('r');
    assert(test2.toString() == "[CharLinkedList of size 6 <<heidir>>]");
    assert(test1.toString() == "[CharLinkedList of size 5 <<heidi>>]");
}

//testing to make sure concatenate works 
//making an array to send into concatenate, then checking
void concatentateNormal(){
    char array[3] = {'c', 'a', 't'};
    char arr[3] = {'d', 'o', 'g'};
    CharLinkedList test1(array, 3);
    CharLinkedList test2(arr, 3);
    test1.concatenate(&test2);
    assert(test1.toString() == "[CharLinkedList of size 6 <<catdog>>]");
    assert(test1.toReverseString() == "[CharLinkedList of size 6 <<godtac>>]");

}

//testing that concatenate works when concatenating itself
void concatenateItself(){
    char array[3] = {'c', 'a', 't'};
    CharLinkedList test(array, 3);
    test.concatenate(&test);
    assert(test.toString() == "[CharLinkedList of size 6 <<catcat>>]");
}

//testing that concatenate works when the first ArrayList is empty
// should just add the second ArrayList to the first
void concatentateOnEmpty(){
    char array[3] = {'c', 'a', 't'};
    CharLinkedList test1(array, 3);
    CharLinkedList test2;
    test2.concatenate(&test1);
    assert(test2.toString() == "[CharLinkedList of size 3 <<cat>>]");
}

//testing adding an empty arraylist to concatenate - array should 
//stay the same 
void concatentateEmpty(){
    char array[3] = {'c', 'a', 't'};
    CharLinkedList test1(array, 3);
    CharLinkedList test2;
    test1.concatenate(&test2);
    assert(test1.toString() == "[CharLinkedList of size 3 <<cat>>]");
}



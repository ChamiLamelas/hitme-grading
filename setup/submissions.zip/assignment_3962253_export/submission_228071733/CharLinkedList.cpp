/*
 *  CharLinkedList.cpp
 *  Name: Sophia Gerogiannis (sgerog02)
 *  Date Created: 1/30/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  File Purpose: The purpose of this file is to implement the functions 
 *                outlined in the CharLinkedList.h file containing the 
 *                interface for the CharLinkedList class. This implementation
 *                uses a linked list design with Nodes that hold data and 
 *                pointers to other nodes in the list. 
 */

#include "CharLinkedList.h"

/*
 * name:      Default CharLinkedList Constructor
 * purpose:   to serve as a linked list constructor
 * arguments: none
 * returns:   none
 * effects:   creates an empty linked list
 */
CharLinkedList::CharLinkedList() 
{
    front = nullptr;
    back = nullptr;
    curr_size = 0;
}

/*
 * name:      newNode
 * purpose:   to create a new node given specific input
 * arguments: a character representing the data that the node will store, as 
 *            well as two node pointers to serve as the new node's next and
 *            prev pointers
 * returns:   none
 * effects:   creates a new node
 */
CharLinkedList::Node *CharLinkedList::newNode(char newData, 
Node *next, Node *prev)
{
    Node *new_node = new Node;
    new_node->data = newData;
    new_node->next = next;
    new_node->prev = prev;
    return new_node;
}

// /*
//  * name:      editNodeNext
//  * purpose:   to edit the next member of a particular node
//  * arguments: a pointer to the current node and a pointer to the node
//  *            that should now be stored in curr's next member
//  * returns:   the updated current node
//  * effects:   overwrites the next in the node struct prior to the calling
//  *            of this function
//  */
CharLinkedList::Node *CharLinkedList::editNodeNext(Node *curr, Node *next)
{
    curr->next = next;
    return curr;
}

// /*
//  * name:      editNodePrev
//  * purpose:   to edit the prev member of a particular node
//  * arguments: a pointer to the current node and a pointer to the node
//  *            that should now be stored in curr's prev member
//  * returns:   the updated current node
//  * effects:   overwrites the prev in the node struct prior to the calling
//  *            of this function
//  */
CharLinkedList::Node *CharLinkedList::editNodePrev(Node *curr, Node *prev)
{
    curr->prev = prev;
    return curr;
}

// /*
//  * name:      editNodeData
//  * purpose:   to edit the data member of a particular node
//  * arguments: a pointer to the current node and a char representing the 
//  *            the new data to be stored in that Node struct
//  * returns:   the updated current node
//  * effects:   overwrites the data in the node struct prior to the calling
//  *            of this function
//  */
CharLinkedList::Node *CharLinkedList::editNodeData(Node *curr, char newData)
{
    curr->data = newData;
    return curr;
}

/*
 * name:      Single Char CharLinkedList Constructor
 * purpose:   to serve as a linked list constructor
 * arguments: a character to be stored in the data member of the struct
 * returns:   none
 * effects:   creates a new node element in the list
 */
CharLinkedList::CharLinkedList(char c) 
{
    front = newNode(c, nullptr, nullptr);
    back = front;
    curr_size = 1;
}

/*
 * name:      CharLinkedList array constructor
 * purpose:   to create a linked list using a pre-existing array with char
 *            elements
 * arguments: a character array and an int representing the size of the array
 * returns:   none
 * effects:   creates a new linked list with a variable number of elements,
 *            calls the pushAtBack function
 */
CharLinkedList::CharLinkedList(char arr[], int size)
{
    for(int i = 0; i < size; i++){
        if (i == 0){
            front = newNode(arr[0], nullptr, nullptr);
            back = front;
            curr_size = 1;
        } else {
            // calling the pushAtBack function to add later elements to the 
            // back of the list
            pushAtBack(arr[i]);
        }
    }
}

/*
 * name:      CharLinkedList copy constructor
 * purpose:   serve as a CharLinkedList copy constructor that makes the list
 *            a copy of the list passed in as a parameter
 * arguments: the address of another CharLinkedList
 * returns:   none
 * effects:   allows CharLinkedLists to have deep copies of themselves be made
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other)
{
    curr_size = 0;
    front = nullptr;
    back = nullptr;
    for(int i = 0; i < other.size(); i++){
        pushAtBack(other.elementAt(i));
    }
}

/*
 * name:      CharLinkedList assignment operator
 * purpose:   to serve as the overloaded assignment operator for 
 *            CharLinkedLists
 * arguments: a pointer to another CharLinkedList
 * returns:   a pointer to the copied CharLinkedList
 * effects:   creates a deep copy of the CharLinkedList that was passed in as 
 *            an argument 
 */
CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other)
{
    if (this == &other){
        return *this;
    }
    //frees memory associated with previous list
    if (front != nullptr){
        recycleRecursive(front);
    }
    curr_size = 0;
    // initializes data in list being created
    if (other.size() > 0){
        front = newNode(other.front->data, nullptr, nullptr);
        back = front;
        Node *curr = front;
        for(int i = 1; i < other.size(); i++){
            pushAtBack(other.elementAt(i));
        }
    } else {
        front = nullptr;
        back = front;
    }
    curr_size = other.size();

    return *this;
}

/*
 * name:      CharLinkedList Destructor
 * purpose:   to serve as a CharLinkedList destructor
 * arguments: none
 * returns:   none
 * effects:   frees the memory associated with the linked list
 */
CharLinkedList::~CharLinkedList()
{
    if (front != nullptr){
        recycleRecursive(front);
    } 
}

/*
 * name:      recycleRecursive
 * purpose:   to delete the nodes in the lsit recursively
 * arguments: a pointer to the current node
 * returns:   none
 * effects:   frees heap-allocated memory
 */
void CharLinkedList::recycleRecursive(Node *curr)
{
    if (curr->next == nullptr){
        delete curr;
    } else if (curr->next != nullptr){
        Node *next = curr->next;
        delete curr;
        recycleRecursive(next);
    }
}

/*
 * name:      isEmpty
 * purpose:   to return a boolean stating whether the list is empty or not
 * arguments: none
 * returns:   a boolean stating whether the list is empty or not
 * effects:   none
 */
bool CharLinkedList::isEmpty() const
{
    if (curr_size == 0){
        return true;
    } else {
        return false;
    }
}

/*
 * name:      clear
 * purpose:   to clear the list
 * arguments: none
 * returns:   none
 * effects:   calls the recycleRecursive function to clear the memory 
 *            associated with the list
 */
void CharLinkedList::clear()
{
    curr_size = 0;
    if (front != nullptr){
        recycleRecursive(front);
    }
    front = nullptr;
    back = nullptr;
}

/*
 * name:      size
 * purpose:   to return the size of the linked list
 * arguments: none
 * returns:   an integer representing the size of the linked list
 * effects:   none
 */
int CharLinkedList::size() const
{
    return curr_size;
}

/*
 * name:      first
 * purpose:   to return the first element in the list
 * arguments: none
 * returns:   a char stating the data of the first element
 * effects:   none
 */
char CharLinkedList::first() const 
{
    if (curr_size > 0){
        return front->data;
    } else {
        throw std::runtime_error("cannot get first of empty LinkedList");
    }
}

/*
 * name:      last 
 * purpose:   to return the last element in the list
 * arguments: none
 * returns:   a char stating the data stored in the first element of the list
 * effects:   none
 */
char CharLinkedList::last() const 
{
    if (curr_size > 0){
        return back->data;
    } else {
        throw std::runtime_error("cannot get last of empty LinkedList");
    }
}

/*
 * name:      elementAt
 * purpose:   to return a char representing the data a particular index of 
 *            the list
 * arguments: an integer representing the index of the char to be retrieved
 * returns:   a char representing the data stored at a particular index of
 *            the list
 * effects:   calls the private iterateRecursive function, throws a range
 *            error when an invalid index is enterred
 */
char CharLinkedList::elementAt(int index) const
{
    if (index >= 0 and index < curr_size){
        if (index <= 0.5*curr_size){
            Node *curr = iterateRecursiveFront(front, index, 0);
            return curr->data;
        } else {
            Node *curr = iterateRecursiveBack(back, index, curr_size - 1);
            return curr->data;
        }
    } else {
        // throw range error and create string for final message
        string s_index = to_string(index);
        string size = to_string(curr_size);
        string syntax_p1 = "index (";
        string syntax_p2 = ") not in range [0..";
        string syntax_p3 = ")";
        string total = syntax_p1 + s_index + syntax_p2 + size + syntax_p3;
        throw std::range_error(total);
    }

}

/*
 * name:      iterateRecursiveFront
 * purpose:   to find the node at a particular index in a list from the front
 * arguments: a Node pointer to the current node, an integer representing the 
 *            index of the list, and an integer representing an index counter
 *            as the function recurses through the list
 * returns:   a Node pointer to the node at the inputted index
 * effects:   none
 */
CharLinkedList::Node *CharLinkedList::iterateRecursiveFront(
    Node *curr, int index, int index_counter) const
{
    if (index == 0){
        return front;
    } else if (index_counter == index){
        return curr;
    } else {
        Node *next = curr->next;
        index_counter++;
        return iterateRecursiveFront(next, index, index_counter);
    }
}

/*
 * name:      iterateRecursiveBack
 * purpose:   to find the node at a particular index in a list from the back
 * arguments: a Node pointer to the current node, an integer representing the 
 *            index of the list, and an integer representing an index counter
 *            as the function recurses through the list
 * returns:   a Node pointer to the node at the inputted index
 * effects:   none
 */
CharLinkedList::Node *CharLinkedList::iterateRecursiveBack(
    Node *curr, int index, int index_counter) const
{
    if (curr->prev == nullptr){
        return curr;
    } else if (index_counter == index){
        return curr;
    } else {
        Node *prev = curr->prev;
        index_counter--;
        return iterateRecursiveBack(prev, index, index_counter);
    }
}

/*
 * name:      toString
 * purpose:   to convert the elements in the list to a string
 * arguments: none
 * returns:   a string holding the size and the elements of the list
 * effects:   returns an associated message with the elements of the list
 */
std::string CharLinkedList::toString() const
{
    string list = "";
    string size = to_string(curr_size);
    string syntax1 = "[CharLinkedList of size ";
    string syntax2 = " <<";
    string syntax3 = ">>]";

    Node *curr = front;
    int index_counter = 0;
    if (curr_size > 0){
        list = listRecursiveFront(curr, index_counter, list);
        string total = syntax1 + size + syntax2 + list + syntax3;
        return total;
    } else {
        string total = syntax1 + size + syntax2 + syntax3;
        return total;
    }
}

/*
 * name:      listRecursiveFront
 * purpose:   to add each node in the list to a string
 * arguments: a Node pointer to the current node, an integer representing 
 *            an index counter as the function recurses through the list, and
 *            the string holding the string version of the list
 * returns:   a Node pointer to the node at the inputted index
 * effects:   none
 */
std::string CharLinkedList::listRecursiveFront(
    Node *curr, int index_counter, string list) const
{
    if (curr_size == 0){
        list += curr->data;
        return list;
    } else if (index_counter == curr_size - 1){
        list += curr->data;
        return list;
    } else {
        list += curr->data;
        Node *next = curr->next;
        index_counter++;
        return listRecursiveFront(next, index_counter, list);
    }
}

/*
 * name:      listRecursiveBack
 * purpose:   to add each node in the list to a string backwards
 * arguments: a Node pointer to the current node, an integer representing 
 *            an index counter as the function recurses through the list, and
 *            the string holding the string version of the list
 * returns:   a Node pointer to the node at the inputted index
 * effects:   none
 */
std::string CharLinkedList::listRecursiveBack(
    Node *curr, int index_counter, string list) const
{
    if (curr_size == 0){
        list += curr->data;
        return list;
    } else if (index_counter == 0){
        list += curr->data;
        return list;
    } else {
        list += curr->data;
        Node *prev = curr->prev;
        index_counter--;
        return listRecursiveBack(prev, index_counter, list);
    }
}

/*
 * name:      toReverseString
 * purpose:   to convert the elements in the list to a string backwards
 * arguments: none
 * returns:   a string holding the size and the elements of the list
 * effects:   returns an associated message with the elements of the list
 */
std::string CharLinkedList::toReverseString() const
{
    string list = "";
    string size = to_string(curr_size);
    string syntax1 = "[CharLinkedList of size ";
    string syntax2 = " <<";
    string syntax3 = ">>]";

    Node *curr = back;
    int index_counter = curr_size - 1;
    if (curr_size > 0){
        list = listRecursiveBack(curr, index_counter, list);
        string total = syntax1 + size + syntax2 + list + syntax3;
        return total;
    } else {
        string total = syntax1 + size + syntax2 + syntax3;
        return total;
    }

}

/*
 * name:      pushAtBack
 * purpose:   to add another element to the back of a list
 * arguments: a char c to be stored as the data of that element
 * returns:   none
 * effects:   creates a new node
 */
void CharLinkedList::pushAtBack(char c)
{
    if (curr_size == 0){
        Node *temp = newNode(c, nullptr, temp);
        front = temp;
        back = front;
        curr_size++;
    } else {
        Node *temp = newNode(c, nullptr, back);
        editNodeNext(back, temp);
        back = temp;
        curr_size++;
    }
}

/*
 * name:      pushAtFront
 * purpose:   to add another element to the front of a list
 * arguments: a char c to be stored as the data of that element
 * returns:   none
 * effects:   creates a new node
 */
void CharLinkedList::pushAtFront(char c)
{
    if (curr_size == 0){
        Node *temp = newNode(c, front, nullptr);
        front = temp;
        back = front;
        curr_size++;
    } else {
        Node *temp = newNode(c, front, nullptr);
        editNodePrev(front, temp);
        front = temp;
        curr_size++;
    }
}

/*
 * name:      popFromBack
 * purpose:   to remove an element in the list from the back of the list
 * arguments: none
 * returns:   none
 * effects:   size of the list decreases, node gets deleted, throws runtime
 *            error if the list is empty
 */
void CharLinkedList::popFromBack() 
{
    Node *curr = back;
    if (front == nullptr){
        throw std::runtime_error("cannot pop from empty LinkedList");
    } else {
        if (curr_size == 1){
            recycleRecursive(back);
            front = nullptr;
            curr_size--;
        } else {
            Node *temp = back->prev;
            delete back;
            editNodeNext(temp, nullptr);
            back = temp; 
            curr_size--;
        }
    }
}


/*
 * name:      popFromFront
 * purpose:   to remove an element in the list from the front of the list
 * arguments: none
 * returns:   none
 * effects:   size of the list decreases, node gets deleted, throws runtime
 *            error if the list is empty
 */
void CharLinkedList::popFromFront()
{
    Node *curr = front;
    if (curr_size == 0){
        throw std::runtime_error("cannot pop from empty LinkedList");
    } else {
        if (curr_size == 1){
            recycleRecursive(front);
            front = nullptr;
        } else {
            Node *temp = front->next;
            delete front;
            editNodePrev(temp, nullptr);
            front = temp;
        }
    }
    curr_size--;
}

/*
 * name:      insertAt
 * purpose:   to insert an element into the LinkedList
 * arguments: a char representing the char to be inserted, and an int 
 *            representing the index at which the char should be inserted
 * returns:   none
 * effects:   changes some of the prev and next pointers of other nodes to 
 *            change the order of the list
 */
void CharLinkedList::insertAt(char c, int index)
{
    if (index >= 0 and index <= curr_size){
        if (index <= 0.5 * curr_size){
            if (index == 0){
                pushAtFront(c);
            } else {
                Node *curr = iterateRecursiveFront(front, index, 0);
                Node *temp = newNode(c, curr, curr->prev);
                editNodeNext(curr->prev, temp);
                editNodePrev(curr, temp);
                curr_size++;
            }
        } else {
            if (index == curr_size){
                pushAtBack(c);
            } else {
                Node *curr = iterateRecursiveBack(back, index, curr_size);
                Node *temp = newNode(c, curr->next, curr);
                editNodeNext(temp->prev, temp);
                editNodePrev(temp->next, temp);
                curr_size++;
            }
        }
    } else {
        string s_index = to_string(index);
        string size = to_string(curr_size);
        string syntax_p1 = "index (";
        string syntax_p2 = ") not in range [0.."; 
        string syntax_p3 = "]";
        string total = syntax_p1 + s_index + syntax_p2 + size + syntax_p3;
        throw std::range_error(total);
    }
}

/*
 * name:      insertInOrder
 * purpose:   to insert a given character into the list in order
 * arguments: a character to be inputted into the list
 * returns:   none
 * effects:   curr_size increases by 1, calls the orderRecursive function
 */
void CharLinkedList::insertInOrder(char c)
{
    Node *curr = front;
    if (curr_size == 0){
        Node *temp = newNode(c, nullptr, nullptr);
        front = temp;
        back = front;
        curr_size++;
        return;
    } else {
        // calling order recursive function to find the node at which to 
        // insert the element based on ASCII numbers
        curr = orderRecursive(curr, c);
        if (curr == nullptr){
            Node *temp = newNode(c, front, nullptr);
            editNodePrev(front, temp);
            front = temp;
        } else if (curr == back){
            Node *temp = newNode(c, nullptr, curr->prev);
            editNodeNext(curr, temp);
            back = temp;
        } else {
            Node *temp = newNode(c, curr->next, curr);
            editNodeNext(curr, temp);
            editNodePrev(temp->next, temp);
        }   
        curr_size++;
    }
}

/*
 * name:      orderRecursive
 * purpose:   to find the node where the char will be inputted in order
 * arguments: a Node pointer to the current node and a char holding the
 *            inputted character
 * returns:   a Node pointer to the node for the inputted character
 * effects:   none
 */
CharLinkedList::Node *CharLinkedList::orderRecursive(Node *curr, char c) const
{
    if (curr_size == 0){
        return nullptr;
    } else if (c <= curr->data){
        return curr->prev;
    } else if (curr->next == nullptr){
        return curr;
    } else {
        Node *next = curr->next;
        return orderRecursive(next, c);
    }
}

/*
 * name:      removeAt
 * purpose:   to remove a specific element of a list
 * arguments: integer representing the index to be removed from the list
 * returns:   none
 * effects:   curr_size decreases by 1, throws range error if invalid index
 *            is entered
 */
void CharLinkedList::removeAt(int index) //negative and out of bounds
{
    if (index >= 0 and index < curr_size){
        if (index <= 0.5 * curr_size){
            Node *curr = iterateRecursiveFront(front, index, 0);
            if (curr == front){
                popFromFront();
            } else {
                editNodePrev(curr->next, curr->prev);
                editNodeNext(curr->prev, curr->next);
                delete curr;
                curr_size--;
            }
        } else {
            Node *curr = iterateRecursiveBack(back, index, curr_size - 1);
            if (curr == back){
                popFromBack();
            } else {
                editNodePrev(curr->next, curr->prev);
                editNodeNext(curr->prev, curr->next);
                delete curr;
                curr_size--;
            }
        }
    } else { // throw range error and create string for final message
        string s_index = to_string(index);
        string size = to_string(curr_size);
        string syntax_p1 = "index (";
        string syntax_p2 = ") not in range [0..";
        string syntax_p3 = ")";
        string total = syntax_p1 + s_index + syntax_p2 + size + syntax_p3;
        throw std::range_error(total);
    }
}

/*
 * name:      replaceAt
 * purpose:   to replace the char at a particular index with an inputted char
 * arguments: a char representing the character to replace the character at a
 *            specific index of the list and an int representing the index of
 *            the list at which the char should be replaced
 * returns:   none
 * effects:   calls the private iterateRecursive function, throws range error
 *            when invalid index is entered
 */
void CharLinkedList::replaceAt(char c, int index)
{
    if (index >= 0 and index < curr_size){
        if (index <= 0.5*curr_size){
            Node *curr = iterateRecursiveFront(front, index, 0);
            editNodeData(curr, c);
        } else {
            Node *curr = iterateRecursiveBack(back, index, curr_size - 1);
            editNodeData(curr, c);
        }
    } else {
        // throw range error and create string for final message
        string s_index = to_string(index);
        string size = to_string(curr_size);
        string syntax_p1 = "index (";
        string syntax_p2 = ") not in range [0..";
        string syntax_p3 = ")";
        string total = syntax_p1 + s_index + syntax_p2 + size + syntax_p3;
        throw std::range_error(total);
    }
}

/*
 * name:      concatenate
 * purpose:   tto add the elements of another CharLinkedList to the back of an
 *            existing one
 * arguments: a pointer to another CharLinkedList
 * returns:   none
 * effects:   curr_size increases by the size of the other CharLinkedList
 */
void CharLinkedList::concatenate(CharLinkedList *other)
{
    int size1 = curr_size;
    int size2 = other->size();

    // pushAtBack called for each element of the other list
    for(int i = size1; i < size1 + size2; i++){
        pushAtBack(other->elementAt(i - size1));
    }
}
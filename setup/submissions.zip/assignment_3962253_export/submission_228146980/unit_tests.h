/*
 *  unit_tests.h
 *  Jacob Pettigrew
 *  2/6/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  Written to test the implementation of CharLinkedList.cpp/.h
 *
 */
#include "CharLinkedList.h"
#include <cassert>
using namespace std;

//Just test the basic constructor nothin much else
void basic_constructor_test() {
    CharLinkedList list;
    assert(list.size() == 0);
}
//tests if constructor with argument of character works
void char_constructor_test() {
    CharLinkedList list('c');
    assert(list.first() == 'c');
}
//tests if constructor with char array argument works
void chararr_constructor_test() {
    char array [5];
    for (int i = 0; i < 5; i++){
        array[i] = 'a';
    }
    CharLinkedList list(array, 5);
    assert(list.toString() == "[CharLinkedList of size 5 <<aaaaa>>]");
}
// tests isempty functionality
void isempty_test() {
    CharLinkedList list('c');
    list.clear();
    assert(list.isEmpty());
    assert(list.size() == 0);
}
//checks that empty returns false if not empty
void isempty_test2() {
    CharLinkedList list('x');

    assert(not list.isEmpty());
}
//tests size method functionality on empty list
void size_test() {
    CharLinkedList list;
    assert(list.size() == 0);
}
//tests  size method func on populated list
void size_test2() {
    CharLinkedList list2('c');
    assert(list2.size() == 1);
}
//tests if clear (and isempty) methods work
void clear_test() {
    CharLinkedList list('c');
    list.clear();
    assert(list.isEmpty());
}
//tests first and last methods
void first_last_test() {
    CharLinkedList list('c');
    assert(list.first() == 'c');
    assert(list.last() == 'c');
}
//tests first and last on full lists
void first_last_test2() {
    char test_arr[7] = { 'a', 'b', 'c', 'e', 'f', 'g', 'h' };
    CharLinkedList list(test_arr, 7);

    assert(list.first() == 'a');
    assert(list.last() == 'h');
}

//tests first and last methods errors
void firstlast_error_test() {
    CharLinkedList list;
    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
    cout << list.first();
    }
    catch (const std::runtime_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "cannot get first of empty LinkedList");
    
    try {
    cout << list.last();
    }
    catch (const std::runtime_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "cannot get last of empty LinkedList");
}

//tests that elementAt throws the proper error
void elementAt_error_test() {
    CharLinkedList list('c');
    
    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
    cout << list.elementAt(1);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (1) not in range [0..1)");
}
//tests that elementAt returns properly
void elementAt_test() {
    CharLinkedList list('c');
    assert(list.elementAt(0) == 'c');
}
//tests that elementAt returns properly using an array constructor
void elementAt_test2() {
    char test_arr[7] = { 'a', 'b', 'c', 'e', 'f', 'g', 'h' };
    CharLinkedList list(test_arr, 7);
    assert(list.elementAt(2) == 'c');
}

//tests that an array of strings can be properly output as strings
void toString_test() {
    char array [5];
    for (int i = 0; i < 5; i++) {
        array[i] = 'a' + i;
    }

    CharLinkedList list(array, 5);
    cout << list.toString();
    assert(list.toString() == "[CharLinkedList of size 5 <<abcde>>]");
}
//tests toString on empty
void toString_test2() {
    CharLinkedList list;

    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}
//tests toReverseString method
void toReverseString_test() {
    char array [5];
    for (int i = 0; i < 5; i++) {
        array[i] = 'a' + i;
    }

    CharLinkedList list(array, 5);

    //output edcba
    assert(list.toReverseString() == "[CharLinkedList of size 5 <<edcba>>]");
}
//tests toReverseString on empty
void toReverseString_test2() {
    CharLinkedList list;

    assert(list.toReverseString() == "[CharLinkedList of size 0 <<>>]");
}
//tests pushAtFront method (tests pushing on empty and full list)
void pushAtFront_test() {
    CharLinkedList list;
    list.pushAtFront('c');
    cout << list.toString() << endl;
    list.pushAtFront('a');
    cout << list.toString() << endl;
    list.pushAtFront('r');
    cout << list.toString() << endl;
    assert(list.toString() == "[CharLinkedList of size 3 <<rac>>]");
}

//tests pushAtBack method (tests pushing on empty and full list)
void pushAtBack_test() {
    CharLinkedList list;
    list.pushAtBack('c');
    cout << list.toString() << endl;
    list.pushAtBack('a');
    cout << list.toString() << endl;
    list.pushAtBack('r');
    cout << list.toString() << endl;
    assert(list.toString() == "[CharLinkedList of size 3 <<car>>]");
}

// Tests correct insertion into an empty AL.
// Afterwards, size should be 1 and element at index 0
// should be the element we inserted.
void insertAt_empty_correct() { 
    CharLinkedList test_list;
    test_list.insertAt('a', 0);
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');

}

// Tests incorrect insertion into an empty AL.
// Attempts to call insertAt for index larger than 0.
// This should result in an std::range_error being raised.
void insertAt_empty_incorrect() {

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    // insertAt for out-of-range index
    test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
    // if insertAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    range_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    cout << error_message;
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0]");
    
}

// Tests correct insertAt for front of 1-element list.
void insertAt_front_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at front
    test_list.insertAt('b', 0);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'a');
    
}

// Tests correct insertAt for back of 1-element list.
void insertAt_back_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at back
    test_list.insertAt('b', 1);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    
}

// Tests calling insertAt for a large number of elements.
// Not only does this test insertAt, it also checks that
// array expansion works correctly.
void insertAt_many_elements() {
    
    CharLinkedList test_list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.insertAt('a', i);
    }

    assert(test_list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
    
}

// Tests insertion into front of a larger list
void insertAt_front_large_list() {
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    test_list.insertAt('y', 0);

    assert(test_list.size() == 10);
    assert(test_list.elementAt(0) == 'y');
    assert(test_list.toString() == 
    "[CharLinkedList of size 10 <<yabczdefgh>>]");

}

// Tests insertion into the back of a larger list
void insertAt_back_large_list() {

    char test_arr[10] = { 'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 10);  

    test_list.insertAt('x', 10);

    assert(test_list.size() == 11);
    assert(test_list.elementAt(10) == 'x');
    assert(test_list.toString() == 
    "[CharLinkedList of size 11 <<yabczdefghx>>]"); 

}

// Tests insertion into the middle of a larger list
void insertAt_middle_large_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.insertAt('z', 3);

    assert(test_list.size() == 9);
    assert(test_list.elementAt(3) == 'z');
    assert(test_list.toString() == "[CharLinkedList of size 9 <<abczdefgh>>]");

}

// Tests out-of-range insertion for a non-empty list.
void insertAt_nonempty_incorrect() {
   
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8]");
    
}
// tests insertinorder method implementation
void insertInOrder_test()  {
    char test_arr[7] = { 'a', 'b', 'c', 'e', 'f', 'g', 'h' };
    CharLinkedList list(test_arr, 7);

    list.insertInOrder('d');
    assert(list.toString() == "[CharLinkedList of size 8 <<abcdefgh>>]");
}

// tests insertinorder method implementation 2nd test
void insertInOrder_test2()  {
    char test_arr[3] = { 'z', 'e', 'd' };
    CharLinkedList list(test_arr, 3);

    list.insertInOrder('a');
    assert(list.toString() == "[CharLinkedList of size 4 <<azed>>]");
}
//tests insert in order on empty list
void insertInOrder_test3()  {
    CharLinkedList list;

    list.insertInOrder('a');
    assert(list.toString() == "[CharLinkedList of size 1 <<a>>]");
}
//tests pop from front functionality
void popFromFront_test() {
    char test_arr[7] = { 'a', 'b', 'c', 'e', 'f', 'g', 'h' };
    CharLinkedList list(test_arr, 7);

    list.popFromFront(); //expect bcefgh
    assert(list.toString() == "[CharLinkedList of size 6 <<bcefgh>>]");
}
//tests pop from front "single" functionality
void popFromFront_test2() {
    CharLinkedList list('c');

    list.popFromFront(); //expect bcefgh
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}
//test popFromBack "normal" functionality
void popFromBack_test() {
    char test_arr[7] = { 'a', 'b', 'c', 'e', 'f', 'g', 'h' };
    CharLinkedList list(test_arr, 7);

    list.popFromBack(); //expect abcefg
    assert(list.toString() == "[CharLinkedList of size 6 <<abcefg>>]");
}
//test popFromBack "single array" functionality
void popFromBack_test2() {
    CharLinkedList list('c');

    list.popFromBack();
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
    assert(list.isEmpty());
}
//test popFromBack "double" functionality
void popFromBack_test3() {
    CharLinkedList list('c');
    list.pushAtBack('a');

    list.popFromBack();
    assert(list.toString() == "[CharLinkedList of size 1 <<c>>]");
}
//tests removeAt functionality
void removeAt_test() {
    char test_arr[7] = { 'a', 'b', 'c', 'e', 'f', 'g', 'h' };
    CharLinkedList list(test_arr, 7);

    list.removeAt(2); //expect "abefgh"
    list.removeAt(0); //expect "befgh"
    list.removeAt(4); //expect "befg"
    assert(list.toString() == "[CharLinkedList of size 4 <<befg>>]");
}
//tests removeAt "single" functionality
void removeAt_test2() {
    CharLinkedList list('c');

    list.removeAt(0); 
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
    // assert(list.isEmpty());
}
//tests popFromFront error
void popFromFront_error_test() {
    CharLinkedList test_list;

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.popFromFront();
    }
    catch (const std::runtime_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
} 
// tests popFromBack error
void popFromBack_error_test() {
    CharLinkedList test_list;

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.popFromBack();
    }
    catch (const std::runtime_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
} 
// tests removeAt error
void removeAt_error_test() {
    char test_arr[7] = { 'a', 'b', 'c', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 7);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.removeAt(8);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (8) not in range [0..7)");
} 
void replaceAt_error_test() {
    char test_arr[7] = { 'a', 'b', 'c', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 7);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.replaceAt('c', 8);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (8) not in range [0..7)");
} 
//replaceAt test with full array
void replaceAt_test() {
    char test_arr[7] = { 'a', 'b', 'c', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 7);


    test_list.replaceAt('d', 3);

    assert(test_list.toString() == "[CharLinkedList of size 7 <<abcdfgh>>]");
} 
//replace At test with single array
void replaceAt_test2() {
    CharLinkedList test_list('c');


    test_list.replaceAt('d', 0);

    assert(test_list.toString() == "[CharLinkedList of size 1 <<d>>]");
}

//Tests overlaoded operator with one full one empty list
void overloaded_operator_test() {
    char test_arr[7] = { 'a', 'b', 'c', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 7);
    CharLinkedList list;

    list = test_list;
    cout << &list << endl << &test_list << endl;
    cout << list.toString();
    assert(&list != &test_list);
}
//tests overloaded operator with two full lists
void overloaded_operator_test2() {
    char test_arr[7] = { 'a', 'b', 'c', 'e', 'f', 'g', 'h' };
    char arr[7] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g' };
    CharLinkedList test_list(test_arr, 7);
    CharLinkedList list(arr, 7);

    list = test_list;
    cout << &list << endl << &test_list << endl;
    cout << list.toString();
    assert(&list != &test_list);
}
//concatenate two full lists
void concatenate_test() {
    char test_arr[7] = { 'a', 'b', 'c', 'e', 'f', 'g', 'h' };
    char arr[7] = { 'z', 'y', 'x', 'w', 'v', 'u', 't' };
    CharLinkedList test_list(test_arr, 7);
    CharLinkedList list(arr, 7);

    test_list.concatenate(&list);

    cout << test_list.toString();
    assert(test_list.toString() == 
    "[CharLinkedList of size 14 <<abcefghzyxwvut>>]");
}
//tests concatenation with empty array and full array
void concatenate_test2() {
    char test_arr[7] = { 'a', 'b', 'c', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 7);
    CharLinkedList list;

    list.concatenate(&test_list);

    cout << test_list.toString();
    assert(test_list.toString() == "[CharLinkedList of size 7 <<abcefgh>>]");
}
//tests concatenation with itself
void concatenate_test3() {
    char test_arr[7] = { 'a', 'b', 'c', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 7);


    test_list.concatenate(&test_list);

    cout << test_list.toString();
    assert(test_list.toString() ==
    "[CharLinkedList of size 14 <<abcefghabcefgh>>]");
}

//copy constructor test
void copy_constructor_test() {
    char test_arr[7] = { 'a', 'b', 'c', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 7);
    CharLinkedList test_list_2(test_list);
    test_list.clear();

    assert(test_list_2.toString() == "[CharLinkedList of size 7 <<abcefgh>>]");
    assert(test_list.isEmpty());
    assert(not test_list_2.isEmpty());
    assert(&test_list_2 != &test_list);
}
//copy constructor test with empty list
void copy_constructor_test2() {
    CharLinkedList test_list;
    CharLinkedList test_list_2(test_list);
    test_list.clear();

    assert(test_list_2.toString() == "[CharLinkedList of size 0 <<>>]");
    assert(test_list.isEmpty());
    assert(test_list_2.isEmpty());
    assert(&test_list_2 != &test_list);
}

void stress_test() {
    char test_arr[7] = { 'a', 'b', 'c', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 7);
    CharLinkedList test_list_2(test_list);
    
    assert(test_list_2.elementAt(2) == 'c');

    test_list_2.popFromBack();
    test_list_2.popFromFront();
    test_list = test_list_2;

    assert(test_list.toString() == "[CharLinkedList of size 5 <<bcefg>>]");

    test_list.concatenate(&test_list);
    test_list.concatenate(&test_list_2);
    
    assert(test_list.size() == 15);

    test_list_2.insertAt('c', 2);
    assert(test_list_2.elementAt(2) == 'c');
}
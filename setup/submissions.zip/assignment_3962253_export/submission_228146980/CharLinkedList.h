/*
 *  CharLinkedList.h
 *  Jacob Pettigrew
 *  2/6/2024
 *  Linked List List
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up
 *
*   CharLinkedList is a class that represents an ordered list
 *  of chars. This class is best if you need to create a variable list
 *  of characters and don't know how long it will be until runtime.
 *  It's current implementation uses a linked list so modifying the front and
 *  back takes O(1) time complexity but anything that addresses the middle of
 *  the list takes O(n) time (worst case). Some key features include insertion
 *  and removal at front, back and middle, sorted alphabetical insertion,
 *  and the various speciality functionalities like concatenate and 
 *  toReverseString (which concatenate and print the array in reverse order)
 *  respectively. There is also deep copy = operand functionality and 
 *  constructors for a variety of use cases.
 *
 */

#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H
#include <string>
using namespace std;

class CharLinkedList {
    public:
    CharLinkedList();
    CharLinkedList(char c);
    CharLinkedList(char arr[], int size);
    CharLinkedList(const CharLinkedList &other);
    ~CharLinkedList();
    CharLinkedList &operator=(const CharLinkedList &other);
    
    bool isEmpty() const;
    int size() const;
    void clear();
    char first() const;
    char last() const;
    char elementAt(int index) const;
    std::string toString() const;
    std::string toReverseString() const;
    void pushAtFront(char c);
    void pushAtBack(char c);
    void insertAt(char c, int index);
    void insertInOrder(char c);
    void popFromFront();
    void popFromBack();
    void removeAt(int index);
    void replaceAt(char c, int index);
    void concatenate(CharLinkedList *other);

private:
    struct Node {
        char info;
        Node *next;
        Node *previous;
    };

    void cleanup(Node *curr_node);
    void replace(Node *curr_node, char c, int index);
    char At(Node *curr_node, int index) const;

    Node *front;
    Node *back;
    int a_size;

};

#endif

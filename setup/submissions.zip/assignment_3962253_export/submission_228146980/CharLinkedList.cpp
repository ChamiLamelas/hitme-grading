/*
 *  CharLinkedList.cpp
 *  Jacob Pettigrew (jpetti01)
 *  2/6/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up
 *
 *  Implementation of CharLinkedList. No known bugs.
 *
 */

#include "CharLinkedList.h"
#include <stdexcept>
#include <iostream>
using namespace std;

// Name: CharLinkedList constructor (default)
// Input: N/A
// Purpose: A basic constructor that initializes the necessary variables
// Output : outputs new CharLinkedList that is empty
CharLinkedList::CharLinkedList() {
    a_size = 0;
    front = nullptr;
    back = nullptr;
}
// Name: CharLinkedList constructor (single char)
// Input: single char to put in
// Purpose: A constructor that initializes the array list with one character
// Output: creates a CharLinkedList populated with single character
// effects: creates a new array on the heap for the LinkedList
CharLinkedList::CharLinkedList(char c) {
    a_size = 1;
    Node *new_node = new Node;
    new_node->info = c;
    new_node->next = nullptr;
    new_node->previous = nullptr;
    front = new_node;
    back = new_node;
}
// Name: CharLinkedList constructor (array)
// Input: single array of characters and integer size of array
// Purpose: A constructor that initializes the LinkedList with static char array
// Output: creates a CharLinkedList populated with contents of array
// effects: creates a new array on the heap for the LinkedList
CharLinkedList::CharLinkedList(char arr [], int size) {
    a_size = size;
    if (a_size > 0) {
        front = new Node{arr[0], nullptr, nullptr};
        Node *curr_node = front;

        for (int i = 1; i < a_size; i++) {
            curr_node->next = new Node {arr[i], nullptr, curr_node};
            curr_node = curr_node->next;
        }

        back = curr_node;
    } else {
        front = nullptr;
        back = nullptr;
    }
}
// Name: CharrLinkedList constructor (copy)
// Input: Address of another CharLinkedList
// Purpose: A constructor that makes a deep copy of a user inputted LinkedList
// Output: a deep copy CharLinkedList of parameter
// effects: creates a new array on the heap for the LinkedList
CharLinkedList::CharLinkedList(const CharLinkedList &other) {
    a_size = other.a_size;
    if (a_size > 0) {
        front = new Node {other.front->info, other.front->next, nullptr};
        Node *curr_node = front;
        Node *copy_node = other.front->next;

        for (int i = 1; i < a_size; i++) {
            curr_node->next = new Node {copy_node->info, nullptr, curr_node};
            copy_node = copy_node->next;
            curr_node = curr_node->next;
        }

        back = curr_node;
    } else {    
        front = nullptr;
        back = nullptr;
    }
}
// Name: CharLinkedList destructor
// Input: N/A
// Purpose: Deconstructor that deletes the array (pass valgrind!)
// Output: N/A
// effects: calls recursive function cleanup to delete
CharLinkedList::~CharLinkedList(){
    cleanup(front);
}

// Name: overloaded operator (= reassignment)
// Input: address of another CharLinkedList
// Purpose: modifies the functionality of the equals operator to allow for
//          deep copies of CharLinkedLists to be made
// Output: a pointer to this CharLinkedList
// Other: manages memory in edge cases of nullptr in RHS LinkedList and creates
//        array in case of "this" object being a nullptr
CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other) {
    if (this != &other) {  // check for self-assignment
        clear();

        if (other.size() > 0) {
            Node *o_curr_node = other.front;
            front = new Node{o_curr_node->info, nullptr, nullptr};
            Node *curr_node = front;
            Node *temp_next = nullptr;

            while ((o_curr_node = o_curr_node->next) != nullptr) {
                temp_next = new Node{o_curr_node->info, nullptr, curr_node};
                curr_node->next = temp_next;
                curr_node = temp_next;
            }

            back = curr_node;
        }

        a_size = other.a_size;
    }

    return *this;
}    
// Name: isEmpty
// Input: N/A
// Purpose: returns a boolean for whether or not LinkedList is empty
// Output: Boolean Operator for whether array is empty 
bool CharLinkedList::isEmpty() const {
    if (a_size == 0 or (front == nullptr and back == nullptr)) {
        return true;
    }
    return false;
}
// Name: size
// Input: N/A
// Purpose: returns the size of the array (a_size variable)
// Output: integer representing size of array
int CharLinkedList::size() const {
    return a_size;
}
// Name: clear
// Input: N/A
// Purpose: deletes the LinkedList and resets the private variables
// Output: N/A
// Other: manages memory to delete LinkedList
void CharLinkedList::clear() {
    cleanup(front);
    front = nullptr;
    back = nullptr;
    a_size = 0;
}
// Name: first
// Input: N/A
// Purpose: returns the first value of the LinkedList
// Output: char from first position in LinkedList
// effects: throws error in case of bad call
char CharLinkedList::first() const {
    if ((front == nullptr) and (back == nullptr)) { //tests if invalid call
        throw std::runtime_error("cannot get first of empty LinkedList");
    }
    return front->info;
}
// Name: last
// Input: N/A
// Purpose: returns the last value of the LinkedList
// Output: char from last position in LinkedList
// effects: throws error in case of bad call
char CharLinkedList::last() const {
    if ((front == nullptr) and (back == nullptr)) { //tests if invalid call
        throw std::runtime_error("cannot get last of empty LinkedList");
    }
    return back->info;
}
// Name: elementAt
// Input: user inputted integer index
// Purpose: returns the value of the linkedlist at a specified index
// Output: char from user indicated position in linkedlist
// effects: throws error in case of bad index
char CharLinkedList::elementAt(int index) const {
    if ((index >= a_size) or (index < 0)) { //tests if invalid index
        string message = "index (" + to_string(index) + 
        ") not in range [0.." + to_string(a_size) + ")";
        throw range_error(message);
    }
    else {
        return At(front, index);
    }
}
// Name: toString
// Input: N/A
// Purpose: converts the linked list into a string in ascending order
// Output: a string containing the elements of the linkedlist
std::string CharLinkedList::toString() const {
    Node *curr_node = front;
    string cc_string = "[CharLinkedList of size " + to_string(a_size) + " <<";
    for (int i = 0; i < a_size; i++){
        cc_string += curr_node->info;
        curr_node = curr_node->next;
    }
    cc_string += ">>]";
    return cc_string;
}
// Name: toReverseString
// Input: N/A
// Purpose: converts the LinkedList into a string in descending order
// Output: a string containing the elements of the LinkedList
std::string CharLinkedList::toReverseString() const {
    Node *curr_node = back;
    char array [a_size];
    string cc_string = "[CharLinkedList of size " + to_string(a_size) + " <<";
    for (int i = 0; i < a_size; i++){
        cc_string += curr_node->info;
        curr_node = curr_node->previous;
    }

    cc_string += ">>]";
    return cc_string;
}
// Name: pushAtFront
// Input: char to insert
// Purpose: adds a user inputted char to the front of the LinkedList
// Output: n/a
void CharLinkedList::pushAtFront(char c) {
    Node *new_front = new Node {c, front, nullptr};
    if (front != nullptr) {
        front->previous = new_front;
    }
    front = new_front;
    a_size++;
}
// Name: pushAtBack
// Input: char to insert
// Purpose: adds a user inputted char to the back of the LinkedList
// Output: n/a
void CharLinkedList::pushAtBack(char c) {
    Node *new_back = new Node {c, nullptr, back};
    
    if ((front == nullptr) and (back == nullptr)) {
        back = new_back;
        front = new_back;
        new_back->previous = nullptr;
    }
    else {
        back->next = new_back;
        back = new_back;
    }
    a_size++;
}
// Name: insertAt
// Input: char to insert
// Purpose: adds a user inputted char to the specified index of the LinkedList
// Output: n/a
// effects: throws error in case of bad index
void CharLinkedList::insertAt(char c, int index) {
    if ((index > a_size) or (index < 0)) { //tests if invalid index
        string message = "index (" + to_string(index) + 
        ") not in range [0.." + to_string(a_size) + "]";
        throw range_error(message);
    }

    if ((front == nullptr) and (back == nullptr)) {
        Node *new_node = new Node{c, nullptr, nullptr};
        back = new_node;
        front = new_node;
        a_size++;
    } else if (index == 0) {
        pushAtFront(c);
    } else if (index == a_size - 1) {
        pushAtBack(c);
    }else {
        Node *new_node = new Node{c, nullptr, nullptr};
        Node *curr_node = front;
        Node *temp_next;
        for (int i = 0; i < (index - 1); i++) {
            curr_node = curr_node->next;
        }
        temp_next = curr_node->next;
        curr_node->next = new_node;
        new_node->next = temp_next;
        new_node->previous = curr_node;
        curr_node->next->previous = new_node;
        a_size++;
    }
}
// Name: insertInOrder
// Input: char to insert
// Purpose: adds a user inputted char to the LinkedList (alphabetically ordered)
// Output: n/a
void CharLinkedList::insertInOrder(char c) {
    bool inserted = false;
    Node *new_node = new Node{c, nullptr, nullptr};
    Node *curr_node = front;
    Node *temp_next;
    if ((front == nullptr) and (back == nullptr)) {
        back = new_node;
        front = new_node;
    } 
    else if (curr_node->info >= c) {
        new_node->next = curr_node;
        front = new_node;
    } 
    else {
        for (int i = 0; i < a_size and not inserted; i++) {
            if(curr_node->next->info >= c) {
                temp_next = curr_node->next;
                curr_node->next = new_node;
                new_node->next = temp_next;
                new_node->previous = curr_node;
                if (curr_node->next != nullptr) {
                    curr_node->next->previous = new_node;
                }
                inserted = true;
            }
            curr_node = curr_node->next;
        }
    }
    a_size++;
}

// Name: popFromFront
// Input: n/a
// Purpose: removes the first element of the LinkedList
// Output: n/a
void CharLinkedList::popFromFront() {
    if (a_size == 0){  //tests if invalid call
        throw runtime_error("cannot pop from empty LinkedList");
    }
    if (a_size == 1) {
        delete front;
    }    
    else {
        Node *deleted_node = front;
        front = front->next;
        front->previous = nullptr;
        delete deleted_node;

    }
    a_size--;
    
    if (a_size == 0) {
        front = nullptr;
        back = nullptr;
    }
}
// Name: popFromBack
// Input: n/a
// Purpose: removes the last element of the LinkedList
//          (by making it inaccessible)
// Output: n/a
// effects: throws error in case of bad call
void CharLinkedList::popFromBack() {
    if (a_size == 0){  //tests if invalid call
        throw runtime_error("cannot pop from empty LinkedList");
    }

    Node *curr_node = front;
    Node *delete_node = back;

    if (a_size == 1) {
        delete back;
        front = nullptr;
        back = nullptr;
    }
    else {
        delete_node = back;
        back = back->previous;
        back->next = nullptr;
        delete delete_node;
    }
    a_size--;

    if (a_size == 0) {
        front = nullptr;
        back = nullptr;
    }
}
// Name: removeAt
// Input: user inputted integer index
// Purpose: removes the user specified element of the LinkedList
// Output: n/a
// effects: throws error in case of bad index
void CharLinkedList::removeAt(int index) {
    if ((index < 0) or (index >= a_size)){  //tests if invalid call
        string message = "index (" + to_string(index) + 
        ") not in range [0.." + to_string(a_size) + ")";
        throw range_error(message);
    }
    Node *curr_node = front;
    Node *temp_node;
    Node *delete_node;
    if (index == 0) {
        popFromFront();
    } else if (index == a_size - 1) {
        popFromBack();
    } else {
        for (int i = 0; i < (index - 1); i++) {
            curr_node = curr_node->next;
        }
        delete_node = curr_node->next;
        temp_node = delete_node->next;
        curr_node->next = temp_node;
        temp_node->previous = curr_node;
        delete delete_node;
        a_size--;
    }
    if (a_size == 0) {
        front = nullptr;
        back = nullptr;
    }
}
// Name: replaceAt
// Input: char to insert and integer index
// Purpose: replaces the character at the user specified index with char c
// Output: n/a
// effects: throws error in case of bad index
void CharLinkedList::replaceAt(char c, int index) {
    if ((index < 0) or (index >= a_size)){  //tests if invalid call
        string message = "index (" + to_string(index) + 
        ") not in range [0.." + to_string(a_size) + ")";
        throw range_error(message);
    }

    replace(front, c, index);
}
// Name: concatenate
// Input: other CharLinkedList pointer
// Purpose: concatenates the contents of the other CharLinkedList to the end
//          of this CharLinkedList
// Output: n/a
// Other: Adds size of other CharArray to size of array
void CharLinkedList::concatenate(CharLinkedList *other) {
    if ((other == nullptr) or other->isEmpty()) {
        return;
    }
    CharLinkedList other_copy(*other);
     
    if (isEmpty()) {
        front = new Node{other_copy.front->info, nullptr, nullptr};
        Node *curr_node = front;
        Node *o_curr_node = other_copy.front->next;

        while (o_curr_node != nullptr) {
            curr_node->next = new Node{o_curr_node->info, nullptr, curr_node};
            curr_node = curr_node->next;
            o_curr_node = o_curr_node->next;
        }
    }
    else {
        Node *curr_node = other_copy.front;

        while (curr_node != nullptr) {
            pushAtBack(curr_node->info);
            curr_node = curr_node->next;
        }
    }
}
// Name: cleanup
// Input: node (in this case the initial node is front)
// Purpose: a helper function that recursively deletes the linked list
// Output: n/a
// Other: manages memory by deleting each node
void CharLinkedList::cleanup(CharLinkedList::Node *cn){
    if (cn == nullptr) {
        return;
    }
    else {
        Node *next_node = cn->next;
        delete cn;
        cleanup(next_node);
        
    }
}
// Name: replace
// Input: node to iterate, char to replace value at node, index of replacement
// Purpose: recursively moves to a node to replace the value at given index
// Output: n/a
void CharLinkedList::replace(Node *curr_node, char c, int index) {
    if (index == 0) {
        curr_node->info = c;
    }
    else {
        replace(curr_node->next, c, index - 1);
    }
}
// Name: At
// Input: node to iterate, index of position in linked list
// Purpose: recursively moves to a node to find the value at given index
// Output: character
char CharLinkedList::At(Node *curr_node, int index) const {
    if (index == 0) {
        return curr_node->info;
    }
    else {
        return At(curr_node->next, index - 1);
    }
}
/*
 *  unit_tests.h
 *  Sophie Zhou (szhou13)
 *  February 5th, 2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  Uses Matt Russell's unit_test framework to test the CharLinkedList class.
 *  Each unit_test specifically targets a function defined in the 
 *  CharLinkedList class.
 *
 */

#include "CharLinkedList.h"
#include <cassert>
#include <iostream>
#include <string>

using namespace std;

// Checks if the program compiles correctly 
// Also checks if the default constructor is working correctly
void test_default_constructor() {
    CharLinkedList myList;
}

// Checks if the second constructor is functioning properly
// Should return a size of 1, isEmpty should return false, and correct message 
// should be printed.
// NOTE: this test also relies on the accuracy of the isEmpty(), size(),
// and toString() functions. Also tests the destructor.
void test_second_constructor() {
    CharLinkedList myList('d');
    assert(not(myList.isEmpty()));
    assert(myList.size() == 1);
    assert(myList.toString() == "[CharLinkedList of size 1 <<d>>]");
}

// Checks the third constructor with a non empty list
// Should create a list with the correct elements and the size should be 8
// NOTE: this test also relies on the accuracy of the toString() and size() 
// functions
void test_third_constructor_nonEmptyList() {
    char testArr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList myList(testArr, 8);
    assert(myList.size() == 8);
    assert(myList.toString() == "[CharLinkedList of size 8 <<abcdefgh>>]");
}

// Checks the third constructor with an empty list
// Should result in an empty list
// NOTE: this test relies on size(), isEmpty(), and toString
void test_third_contructor_emptyList() {
    char testArr[0];
    CharLinkedList myList(testArr, 0);
    assert(myList.size() == 0);
    assert(myList.isEmpty());
    assert(myList.toString() == "[CharLinkedList of size 0 <<>>]");
}


// Checks the copy constructor, copying a one-element list
// the newList should be the same as the originalList
// NOTE: This test also uses toString(), which was written/tested before 
void test_copyConstructor_smallList() {
    CharLinkedList originalList('b');
    assert(originalList.toString() == "[CharLinkedList of size 1 <<b>>]");

    // calls the copy constructor
    CharLinkedList newList = originalList;
    assert(newList.toString() == "[CharLinkedList of size 1 <<b>>]");

    // makes sure that the newList is the same as the originalList
    assert(newList.toString() == originalList.toString());
}

// Checks the copy constructor on an empty list
// The newList should be also be an empty list
void test_copyConstructor_emptyList() {
    CharLinkedList originalList;

    CharLinkedList newList = originalList;
    assert(newList.toString() == "[CharLinkedList of size 0 <<>>]");
}

// Checks the copy constructor on a larger list
// The newList should be the same as the originalList
// NOTE: toString() written/tested later
void test_copyConstructor_largerList() {
    char testArr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList originalList(testArr, 8);

    CharLinkedList newList = originalList;
    assert(newList.toString() == originalList.toString());
}

// Checks the functionality of the assignment operator
// list2 should be the same as list1
// NOTE: uses toString() and size(), written/tested later
void test_assignmentOperator() {
    char arr1[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    char arr2[3] = {'a', 'b', 'c'};

    CharLinkedList list1(arr1, 8);
    CharLinkedList list2(arr2, 3);

    // calls the assignment operator
    list1 = list2;

    assert(list2.toString() == "[CharLinkedList of size 3 <<abc>>]");
    assert(list1.size() == 3);
    assert(list1.toString() == "[CharLinkedList of size 3 <<abc>>]");
    assert(list1.toString() == list2.toString());
}

// Checks the isEmpty() function with an empty list
// isEmpty should return true
// NOTE: this test was written in conjuction with the default constructor
void test_isEmpty_emptyList() {
    CharLinkedList myList;
    assert(myList.isEmpty());
}

// Checks the isEmpty() function with a list of one element
// isEmpty should return false
void test_isEmpty_singleElement() {
    CharLinkedList myList('z');
    assert(not(myList.isEmpty()));
}

// Checks the isEmpty() function with a large list
// isEmpty should return false
void test_isEmpty_largeList() {
    char arr1[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList myList(arr1, 8);
    assert(not(myList.isEmpty()));
}

// Checks the isEmpty() function after the clear function
// should return true
// NOTE: this test was written after the clear() function was written/tested
void test_isEmpty_clear() {
    char arr1[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList myList(arr1, 8);
    myList.clear();
    assert(myList.isEmpty());
}

// Checks the size() function with an empty list
// size should return 0
// NOTE: this test was written in conjuction with the default constructor
void test_size_emptyList(){
    CharLinkedList myList;
    assert(myList.size() == 0);
}

// Checks the size() function with a list of one element
// size() should return 1
void test_size_singleElement() {
    CharLinkedList myList('z');
    assert(myList.size() == 1);
}

// Checks size() function with a larger list
// size() should return 8
void test_size_largerList() {
    char arr1[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList myList(arr1, 8);
    assert(myList.size() == 8);
}

// Checks size() function with a huge list
// size() should return 100
// NOTE: this test was written after the pushAtBack function was written/tested
void test_size_hugeList() {
    CharLinkedList myList;
    for (int i = 0; i < 100; i++) {
        myList.pushAtBack('z');
    }
    assert(myList.size() == 100);
}

// Checks size() on a non-empty array that has been cleared
// Also tests the clear() function (we have already tested clear() we can 
// assume that it works
// The isEmpty() function is also used here (which we have previously tested)
void test_size_clearedList() {
    char myArr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList myList(myArr, 8);

    myList.clear();

    assert(myList.isEmpty());
    assert(myList.size() == 0);
}


// Checks the toString() function with an empty list
// Should return the correct message with a size 0, and no characters
// NOTE: this test was written in conjuction with the default constructor
void test_toString_emptyList() {
    CharLinkedList myList;
    assert(myList.toString() == "[CharLinkedList of size 0 <<>>]");
}

// Checks the toString() function with a list of one character
// Should return the correct message with a size 1, and one character
void test_toString_singleElement() {
    CharLinkedList myList('z');
    assert(myList.toString() == "[CharLinkedList of size 1 <<z>>]");
}

// Checks toString() on a list after it has been cleared
// the final toString should be a message including a size of 0 and <<>>
// NOTE: the clear() function is also used (it has been previously tested)
void test_toString_clearedList() {
    CharLinkedList myList('a');
    myList.clear();
    assert(myList.toString() == "[CharLinkedList of size 0 <<>>]");
}

// Checks toString on a larger list
// the final toString should be a message including a size of 8 and letters
// a-h
void test_toString_largerList() {
    char arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList myList(arr, 8);

    assert(myList.toString() == "[CharLinkedList of size 8 <<abcdefgh>>]");
}

// Checks toReverseString() on a larger list
// final toReverseString should be a message including a size of 4 and the 
// characters d-a
void test_toReverseString_largerList() {
    char arr[4] = { 'a', 'b', 'c', 'd' };
    CharLinkedList myList(arr, 4);
    assert(myList.toReverseString() == "[CharLinkedList of size 4 <<dcba>>]");
}

// Checks the toReverseString() function with an empty list
// Should return the correct message with a size 0, and no characters
// NOTE: this test was written in conjuction with the default constructor
void test_toReverseString_emptyList() {
    CharLinkedList myList;
    assert(myList.toReverseString() == "[CharLinkedList of size 0 <<>>]");
}
// Checks the toReverseString() function with a list of one character
// Should return the correct message with a size 1, and one character
void test_toReverseString_singleElement() {
    CharLinkedList myList('z');
    assert(myList.toReverseString() == "[CharLinkedList of size 1 <<z>>]");
}

// Checks pushAtBack() with an empty list
// Should return the correct message with size 1, and the character 'a'
void test_pushAtBack_emptyList() {
    CharLinkedList myList;
    myList.pushAtBack('a');
    assert(myList.toString() == "[CharLinkedList of size 1 <<a>>]");
}

// Checks pushAtBack() with a single element list
// Should return correct message with size 3, and characters 'def'
void test_pushAtBack_singleElement() {
    CharLinkedList myList('d');
    myList.pushAtBack('e');
    myList.pushAtBack('f');
    assert(myList.toString() == "[CharLinkedList of size 3 <<def>>]");
}

// Checks pushAtBack() with a larger list
// should return the correct character and incrememented size
// Note: test also uses toString()
void test_pushAtBack_largeList() {
    char arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList myList(arr, 8);

    myList.pushAtBack('z');
    myList.pushAtBack('z');

    assert(myList.toString() == "[CharLinkedList of size 10 <<abcdefghzz>>]");
}

// Checks pushAtBack() from a-z
// the final result should be an array list with characters from a-z and a size 
// of 26
// NOTE: This test was added later, it uses the elementAt function which was
// written/tested after
void test_pushAtBack_many1() {
    // add characters a-z
    CharLinkedList emptyList; 
    for (char c = 'a'; c <= 'z'; c++){
        emptyList.pushAtBack(c);
    }

    assert(emptyList.size() == 26);
    for (int i = 0; i < 26; i++){
        assert(emptyList.elementAt(i) == 'a' + i);
    }
}

// Checks pushAtBack() with 100 pushes
// the final result should be an array list with 100 characters 'b'
// NOTE: This test was added later, it uses the elementAt function which was
// written/tested after
void test_pushAtBack_many2() {
    // add b 100 times
    CharLinkedList emptyList2;
    for (int i = 0; i < 100; i++){
        emptyList2.pushAtBack('b');
    }

    assert(emptyList2.size() == 100);
    for (int i = 0; i < 100; i++){
       assert(emptyList2.elementAt(i) == 'b');
    }
}

// Checks pushAtFront() with an empty list
// Should return the correct message with size 1, and the character 'g'
void test_pushAtFront_emptyList() {
    CharLinkedList myList;
    myList.pushAtFront('g');
    assert(myList.toString() == "[CharLinkedList of size 1 <<g>>]");
}

// Checks pushAtFront() with a single element list
// Should return correct message with size 3, and characters 'fop'
void test_pushAtFront_singleElement() {
    CharLinkedList myList('p');
    myList.pushAtFront('o');
    myList.pushAtFront('f');
    assert(myList.toString() == "[CharLinkedList of size 3 <<fop>>]");
}

// Checks pushAtFront() with a larger list
// should return the correct characters and incrememented size
// Note: test also uses toString()
void test_pushAtFront_largeList() {
    char arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList myList(arr, 8);

    myList.pushAtFront('z');
    myList.pushAtFront('z');

    assert(myList.toString() == "[CharLinkedList of size 10 <<zzabcdefgh>>]");
}

// Checks pushAtFront() with with many pushes
// the result should be a list from z-a
// NOTE: this test was added later, it uses the elementAt() function which was
// written/tested after
void test_pushAtFront_many() {
    CharLinkedList myList;

    // pushes the characters a-z
    for (char c = 'a'; c <= 'z'; c++){
        myList.pushAtFront(c);
    }

    assert(myList.size() == 26);
    for (int i = 0; i < 26; i++){
        assert(myList.elementAt(i) == 'z' - i);
    }
}

// Check pushAtFront() and pushAtBack() together
// should return correct message and size of 8
// NOTE: this also uses the toString function
void test_pushAtFront_pushAtBack() {
    CharLinkedList myList;
    myList.pushAtFront('a');
    myList.pushAtBack('e');
    for (int i = 0; i < 3; i++) {
        myList.pushAtFront('z');
    }
    for (int i = 0; i < 3; i++) {
        myList.pushAtBack('z');
    }
    assert(myList.toString() == "[CharLinkedList of size 8 <<zzzaezzz>>]");
}

// Check insertAt() with an index in between 0 and size
// Should return the correct message of size 4 and list 'abzc'
// NOTE: this also tests the pushAtBack function (written/tested previously)
// and the toString function
void test_insertAt_validIndex() {
    CharLinkedList myList('a');
    myList.pushAtBack('b');
    myList.pushAtBack('c');

    myList.insertAt('z', 1);
    assert(myList.toString() == "[CharLinkedList of size 4 <<azbc>>]");
}

// Checks insertAt() with multiple inserts
// Should return the correct message of size 9 and correct list of characters
// NOTE: this test relies on the pushAtBack function functioning properly
void test_insertAt_multipleInserts() {
    CharLinkedList myList('z');
    myList.pushAtBack('b');
    myList.pushAtBack('c');

    myList.insertAt('g', 2);

    for(int i = 0; i < 5; i++) {
        myList.insertAt('d', 1);
    }
    assert(myList.toString() == "[CharLinkedList of size 9 <<zdddddbgc>>]");
}

// Check insertAt() with index of 0
// Should return the correct message with size 4 and 'hzbc'
// Note: relies on the accuracy of pushAtBack()
void test_insertAt_zeroIndex() {
    CharLinkedList myList('z');
    myList.pushAtBack('b');
    myList.pushAtBack('c');

    myList.insertAt('h', 0);
    assert(myList.toString() == "[CharLinkedList of size 4 <<hzbc>>]");
}

// Checks insertAt() with index equal to size
// Should return the correct message with size 4 and string 'zbcz'
void test_insertAt_sizeIndex() {
    CharLinkedList myList('z');
    myList.pushAtBack('b');
    myList.pushAtBack('c');

    myList.insertAt('z', 3);
    assert(myList.toString() == "[CharLinkedList of size 4 <<zbcz>>]");
}

// Checks insertAt() with negative index
// this should raise and std::range_error
void test_insertAt_negativeIndex() {
    bool range_error_thrown = false;
    std::string error_message = "";

    CharLinkedList myList('a');
    try {
        myList.insertAt('b', -4);
    } 
    catch (const std::range_error &e) {
        range_error_thrown = true;
        string error_message = e.what(); 
    }
    assert(myList.size() == 1);
    assert(range_error_thrown);
    assert("index (-4) not in range [0..1]");
}

// Checks insertAt() with an index larger than size
// this should raise and std::range_error
void test_insertAt_tooLargeIndex() {
    bool range_error_thrown = false;
    std::string error_message = "";

    CharLinkedList myList('a');
    try {
        myList.insertAt('b', 2);
    } 
    catch (const std::range_error &e) {
        range_error_thrown = true;
        string error_message = e.what(); 
    }
    assert(myList.size() == 1);
    assert(range_error_thrown);
    assert("index (2) not in range [0..1]");
}

// Checks insertAt() with an empty list
// should return the correct string message
void test_insertAt_emptyList() {
    CharLinkedList myList;
   
    myList.insertAt('c', 0);
    assert(myList.toString() == "[CharLinkedList of size 1 <<c>>]");
}

// Checks insertAt() with a single element list, and index equal to size
// should return the correct message with size 2 and string 'dc'
void test_insertAt_singleElement() {
    CharLinkedList myList('d');
   
    myList.insertAt('c', 1);
    assert(myList.size() == 2 );
    assert(myList.toString() == "[CharLinkedList of size 2 <<dc>>]");
}

// Checks insertAt() with a single element, and index 0
// should return the correct message with size 2 and string 'cd'
void test_insertAt_singleElement2() {
    CharLinkedList myList('d');
   
    myList.insertAt('c', 0);
    assert(myList.toString() == "[CharLinkedList of size 2 <<cd>>]");
}


// Checks clear() on an empty list
// The list should be empty (checks isEmpty in conjunction with clear)
// NOTE: since isEmpty has already been tested, we can assume it works 
void test_clear_emptyList() {
    CharLinkedList emptyList;
    emptyList.clear();
    assert(emptyList.isEmpty());
}

// Check clear() on a non-empty list
// The list should be empty
// NOTE: uses function isEmpty() that was previoulsy written/tested
void test_clear_nonEmptyList() {
    CharLinkedList myList('a');
    myList.clear();
    assert(myList.isEmpty());
}

// Check clear() on a larger list
// The list should be empty
// NOTE: uses function isEmpty() that was previoulsy written/tested
void test_clear_largerList() {
    char myArr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList myList(myArr, 8);

    myList.clear();
    assert(myList.isEmpty());
}

// Check clear() on a huge list
// The list should be empty
// NOTE: this test was written after the other clear tests, it uses the 
// pushAtBack function, which was written/tested later
void test_clear_hugeList() {
    CharLinkedList myList;
    for (int i = 0; i < 100; i++) {
        myList.pushAtBack('c');
    }

    myList.clear();
    assert(myList.isEmpty());
}

// Checks first() on a non-empty list
// Should return 'e'
void test_first_nonEmptyList() {
    char arr[8] = {'e', 'h', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList myList(arr, 8);
    
    assert(myList.first() == 'e');
}

// Checks first() on an empty list
// This should result in an std::runtime_error being raised
void test_first_emptyList(){
    bool runtime_error_thrown = false;
    std::string error_message = "";

    CharLinkedList emptyList;
    try {
        // use first() on an empty list
        emptyList.first();
    }
    catch (const std::runtime_error &e){
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot get first of empty LinkedList");
}

// Checks last() on a non-empty list
// This should return 'i'
void test_last_nonEmptyList() {
    char arr[8] = {'e', 'h', 'c', 'd', 'e', 'f', 'g', 'i'};
    CharLinkedList myList(arr, 8);
    
    assert(myList.last() == 'i');
}

// Checks last() on an empty list
// This should result in an std::runtime_error being raised
void test_last_emptyList(){
    bool runtime_error_thrown = false;
    std::string error_message = "";

    CharLinkedList emptyList;
    try {
        // use last() on an empty list
        emptyList.last();
    }
    catch (const std::runtime_error &e){
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot get last of empty LinkedList");
}

// Check popFromFront() with a non-empty list
// This should result in size decreasing by one, and a list of <<bcdefgh>>
void test_popFromFront_nonEmptyList () {
    char arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList myList(arr, 8);

    myList.popFromFront();
    assert(myList.size() == 7);
    assert(myList.toString() == "[CharLinkedList of size 7 <<bcdefgh>>]");
}

// Check popFromFront() with an empty list
// This should result in a std::runtime_error being raised
void test_popFromFront_emptyList() {
    bool runtime_error_thrown = false;
    std::string error_message = "";

    CharLinkedList emptyList;
    try {
        // attempt to remove from an empty list
        emptyList.popFromFront();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

// test popFromFront() with a one-element list
// this should result in an empty list
void test_popFromFront_singleElement() {
    CharLinkedList myList('d');
    myList.popFromFront();

    assert(myList.isEmpty());
    assert(myList.toString() == "[CharLinkedList of size 0 <<>>]");
}

// test popFromFront() with many pops
// this should result in a list with a size of 4 and the characters <<efgh>>
void test_popFromFront_many() {
    char arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList myList(arr, 8);
    
    //popFromFront is called 4 times
    for (int i = 0; i < 4; i++) {
        myList.popFromFront();
    } 
    assert(myList.toString() == "[CharLinkedList of size 4 <<efgh>>]");
}

// test popFromFront() with too many pops
// this should result in a std::runtime_error being raised
void test_popFromFront_tooMany() {
    bool runtime_error_thrown = false;
    std::string error_message = "";

    char arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList myList(arr, 8);
    try {
        // call popFromFront too many times
        for (int i = 0; i < 100; i++) {
            myList.popFromFront();
        } 
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

// Check popFromBack() with a non-empty list
// The size should decrease by one and the list should be <<abcdefg>>
void test_popFromBack_nonEmptyList () {
    char arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList myList(arr, 8);

    myList.popFromBack();
    assert(myList.toString() == "[CharLinkedList of size 7 <<abcdefg>>]");
}

// Check popFromBack() with an empty list
// This should result in a std::runtime_error being raised
void test_popFromBack_emptyList() {
    bool runtime_error_thrown = false;
    std::string error_message = "";

    CharLinkedList emptyList;
    try {
        // attempt to remove from an empty list
        emptyList.popFromBack();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

// Check popFromBack() with a one-element list
// This should result in an empty list
void test_popFromBack_oneElement() {
    CharLinkedList myList('d');
    myList.popFromBack();

    assert(myList.isEmpty());
    assert(myList.toString() == "[CharLinkedList of size 0 <<>>]");
}

// Check popFromBack() with many pops
// This should result in a list with a size of 2 and characters <<ab>>
void test_popFromBack_many() {
    char arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList myList(arr, 8);
    
    //popFromBack is called 6 times
    for (int i = 0; i < 6; i++) {
        myList.popFromBack();
    } 
    assert(myList.toString() == "[CharLinkedList of size 2 <<ab>>]");
}

// Check popFromBack() with too many pops
// This should result in a std::runtime_error being raised
void test_popFromBack_tooMany() {
    bool runtime_error_thrown = false;
    std::string error_message = "";

    char arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList myList(arr, 8);
    try {
        // call popFromBack too many times
        for (int i = 0; i < 50; i++) {
            myList.popFromBack();
        } 
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

// Tests insertInOrder with a lowercase list
void test_insertInOrder_lowercase() {
    char myArr[7] = { 'a', 'b', 'c', 'e', 'f', 'g', 'h' };
    CharLinkedList myList(myArr, 7);

    myList.insertInOrder('d');
    assert(myList.size() == 8);

    assert(myList.toString() == "[CharLinkedList of size 8 <<abcdefgh>>]");
}

// Tests insertInOrder with a capitalized list
void test_insertInOrder_capital() {
    char myArr[7] = { 'G', 'H', 'I', 'J', 'K', 'M', 'N' };
    CharLinkedList myList(myArr, 7);

    myList.insertInOrder('L');

    assert(myList.toString() == "[CharLinkedList of size 8 <<GHIJKLMN>>]");
}

// Tests insertInOrder at the front of the list
void test_insertInOrder_front() {
    char myArr[5] = { 'c', 'e', 'f', 'g', 'h' };
    CharLinkedList myList(myArr, 5);

    myList.insertInOrder('a');

    assert(myList.toString() == "[CharLinkedList of size 6 <<acefgh>>]");
}

// Tests insertInOrder with non-letter characters
void test_insertInOrder_nonLetter() {
    char myArr[5] = { '!', '#', '%', '(', ',' };
    CharLinkedList myList(myArr, 5);

    myList.insertInOrder('*');

    assert(myList.toString() == "[CharLinkedList of size 6 <<!#%(*,>>]");
}

// Test insertInOrder with mixed characters
void test_insertInOrder_mixed() {
    char myArr[6] = { 'A', 'B', 'C', 'D', 'f', 'g'};
    CharLinkedList myList(myArr, 6);

    myList.insertInOrder('e');

    assert(myList.toString() == "[CharLinkedList of size 7 <<ABCDefg>>]");
}


// Tests insertInOrder with repeated characters
void test_insertInOrder_repeat() {
    char myArr[5] = { 'c', 'd', 'd', 'e', 'e' };
    CharLinkedList myList(myArr, 5);

    myList.insertInOrder('d');

    assert(myList.toString() == "[CharLinkedList of size 6 <<cdddee>>]");
}

// Tests insertInOrder with repeated characters at the end
void test_insertInOrder_repeatEnd() {
    char myArr[7] = { 'h', 'j', 'l', 'l', 'm', 'm', 'm'};
    CharLinkedList myList(myArr, 7);

    myList.insertInOrder('n');

    assert(myList.toString() == "[CharLinkedList of size 8 <<hjllmmmn>>]");
}

// Tests insertInOrder with an empty list
void test_insertInOrder_emptyList() {
    CharLinkedList emptyList;

    emptyList.insertInOrder('t');

    assert(emptyList.toString() == "[CharLinkedList of size 1 <<t>>]");
}

// test the removeAt() function with a middle index
// this should result in a size of 7 and a list of <<abcdfgh>>
void test_removeAt_middle() {
    char arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList myList(arr, 8);

    myList.removeAt(4);
    assert(myList.toString() == "[CharLinkedList of size 7 <<abcdfgh>>]");
}

// test the removeAt() function at the front
// this should result in a size of 7 and a list of <<bcdefgh>>
void test_removeAt_front() {
    char arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList myList(arr, 8);

    myList.removeAt(0);
    assert(myList.toString() == "[CharLinkedList of size 7 <<bcdefgh>>]");
}

// test the removeAt() function at the back
// this should result in a size of 7 and a list of <<abcdefg>>
void test_removeAt_back() {
    char arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList myList(arr, 8);

    myList.removeAt(7);
    assert(myList.toString() == "[CharLinkedList of size 7 <<abcdefg>>]");
}

// test the removeAt() function many times
// this should result in an empty list
// NOTE: the isEmpty() function is also tested here
void test_removeAt_many() {
    char arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList myList(arr, 8);

    // remove the first element 8 times
    for (int i = 0; i < 8; i++){
        myList.removeAt(0);
    }
    assert(myList.isEmpty());
}

// test the removeAt() function with a negative index
// This should raise a std::range_error
void test_removeAt_negativeIndex() {
    bool range_error_thrown = false;
    std::string error_message = "";
    
    char arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList myList(arr, 8);

    try {
        // attempt to use a negative index
        myList.removeAt(-1);  
    } 
    catch (const std::range_error &e) {
        range_error_thrown = true;
        string error_message = e.what();
    }
    assert(range_error_thrown);
    assert("index (-1) not in range [0..8)");
}

// test the removeAt() function with an index equal to size
// this should raise a std::range_error
void test_removeAt_invalidSizeIndex() {
    bool range_error_thrown = false;
    std::string error_message = "";
    
    char arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList myList(arr, 8);

    try {
        // attempt to access an out of bounds index
        myList.removeAt(8);  
    } 
    catch (const std::range_error &e) {
        range_error_thrown = true;
        string error_message = e.what();
    }
    assert(range_error_thrown);
    assert("index (8) not in range [0..8)");
}

// test the removeAt() function with an index that is too large
// this should raise a std::range_error
void test_removeAt_invalidLargeIndex() {
    bool range_error_thrown = false;
    std::string error_message = "";
    
    char arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList myList(arr, 8);

    try {
        // attempt to access an out of bounds index
        myList.removeAt(15);  
    } 
    catch (const std::range_error &e) {
        range_error_thrown = true;
        string error_message = e.what();
    }
    assert(range_error_thrown);
    assert("index (15) not in range [0..8)");
}

// test the removeAt() function with an empty list
// this should raise a std::range_error
void test_removeAt_emptyList() {
    bool range_error_thrown = false;
    std::string error_message = "";
    
    CharLinkedList emptyList;

    try {
        // attempt to access an out of bounds index
        emptyList.removeAt(0);  
    } 
    catch (const std::range_error &e) {
        range_error_thrown = true;
        string error_message = e.what();
    }
    assert(range_error_thrown);
    assert("index (0) not in range [0..0)");
}

// Checks elementAt() with a valid index
// Should return 'd'
void test_elementAt_validIndex() {
    char arr[8] = {'e', 'h', 'c', 'd', 'e', 'f', 'g', 'i'};
    CharLinkedList myList(arr, 8);

    assert(myList.elementAt(3) == 'd');
    assert(myList.elementAt(5) == 'f');
}

// Checks elementAt() with the index at the beginning
// Should return 'e'
void test_elementAt_validIndex_beginning() {
    char arr[8] = {'e', 'h', 'c', 'd', 'e', 'f', 'g', 'i'};
    CharLinkedList myList(arr, 8);

    assert(myList.elementAt(0) == 'e');
}

// Checks elementAt() with the index at the end
// Should return 'i'
void test_elementAt_validIndex_end() {
    char arr[8] = {'e', 'h', 'c', 'd', 'e', 'f', 'g', 'i'};
    CharLinkedList myList(arr, 8);

    assert(myList.elementAt(7) == 'i');
}

// Checks elementAt() with an invalid index
// This should result in a std::range_error being raised
void test_elementAt_invalidIndex() {
    bool range_error_thrown = false;
    std::string error_message = "";

    char arr[8] = {'e', 'h', 'c', 'd', 'e', 'f', 'g', 'i'};
    CharLinkedList myList(arr, 8);
    try {
        // try to access an invalid index
        myList.elementAt(15);
    }
    catch (const std::range_error &e){
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (15) not in range [0..8)");
}

// Check elementAt() with an empty array list
// This should result in a std:range_error being raised
void test_elementAt_emptyList() {
    bool range_error_thrown = false;
    std::string error_message = "";

    CharLinkedList emptyList;
    try {
        // try to access an invalid index
       emptyList.elementAt(0);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (0) not in range [0..0)");
}

// Tests replaceAt() with an index in the middle of the list
// This should have no change to the size, but a list of <<abcdzfgh>>
void test_replaceAt_middle() {
    char arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList myList(arr, 8);

    myList.replaceAt('z', 4);
    assert(myList.toString() == "[CharLinkedList of size 8 <<abcdzfgh>>]");
}

// Tests replaceAt() with an index in the front of the list
// This should have no change to the size, but a list of <<zbcdefgh>>
void test_replaceAt_front() {
    char arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList myList(arr, 8);

    myList.replaceAt('z', 0);
    assert(myList.toString() == "[CharLinkedList of size 8 <<zbcdefgh>>]");
}

// Tests replaceAt() with an index in the back of the list
// This should have no change to the size, but a list of <<abcdefgz>>
void test_replaceAt_back() {
    char arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList myList(arr, 8);

    myList.replaceAt('z', 7);
    assert(myList.toString() == "[CharLinkedList of size 8 <<abcdefgz>>]");
}

// Tests the replaceAt() function many times
// This should have no change to the size, but a list of <<zzzzzzzz>>
void test_replaceAt_many() {
    char arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList myList(arr, 8);

    // replace the first element with 'z' 8 times
    for (int i = 0; i < 8; i++){
        myList.replaceAt('z', i);
    }
    assert(myList.toString() == "[CharLinkedList of size 8 <<zzzzzzzz>>]");
}

// Tests replaceAt() with an empty list
// This should raise a std::range_error
void test_replaceAt_emptyList() {
    bool range_error_thrown = false;
    std::string error_message = "";
    
    CharLinkedList emptyList;

    try {
        // attempt to access an out of bounds index
        emptyList.replaceAt('c', 0);  
    } 
    catch (const std::range_error &e) {
        range_error_thrown = true;
        string error_message = e.what();
    }
    assert(range_error_thrown);
    assert("index (0) not in range [0..0)");
}

// Tests replaceAt() with a negative index
// This should raise a std::range_error
void test_replaceAt_negativeIndex() {
    bool range_error_thrown = false;
    std::string error_message = "";
    
    char arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList myList(arr, 8);

    try {
        // attempt to access an out of bounds index
        myList.replaceAt('a', -2);  
    } 
    catch (const std::range_error &e) {
        range_error_thrown = true;
        string error_message = e.what();
    }
    assert(range_error_thrown);
    assert("index (-2) not in range [0..8)");
}

// Tests replaceAt() with an out of range index
// This should raise a std::range_error
void test_replaceAt_invalidLargeIndex() {
    bool range_error_thrown = false;
    std::string error_message = "";
    
    char arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList myList(arr, 8);

    try {
        // attempt to access an out of bounds index
        myList.replaceAt('c', 21);  
    } 
    catch (const std::range_error &e) {
        range_error_thrown = true;
        string error_message = e.what();
    }
    assert(range_error_thrown);
    assert("index (21) not in range [0..8)");
}

// Test replaceAt() with an index equal to size
// This should raise a std::range_error
void test_replaceAt_invalidSizeIndex() {
    bool range_error_thrown = false;
    std::string error_message = "";
    
    char arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList myList(arr, 8);

    try {
        // attempt to access an out of bounds index
        myList.replaceAt('d', 8);  
    } 
    catch (const std::range_error &e) {
        range_error_thrown = true;
        string error_message = e.what();
    }
    assert(range_error_thrown);
    assert("index (8) not in range [0..8)");
}

// Tests concatenate() with two array lists
void test_concatenate() {
    char arr1[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList list1(arr1, 8);

    char arr2[3] = { 'D', 'A', 'D' };
    CharLinkedList list2(arr2, 3);

    list1.concatenate(&list2);
    assert(list1.toString() == "[CharLinkedList of size 11 <<abcdefghDAD>>]");  
}

// Test concatenate() with two small lists
void test_concatenate_small() {
    CharLinkedList list1('c');
    CharLinkedList list2('e');

    list1.concatenate(&list2);
    assert(list1.toString() == "[CharLinkedList of size 2 <<ce>>]");  
    assert(list2.toString() == "[CharLinkedList of size 1 <<e>>]");
}

// Test concatenate() with two large lists
// in conjuction with pushBack, size, and element At
void test_concatenate_big() {
    CharLinkedList list1;
    CharLinkedList list2;
    
    for (int i = 0; i < 100; i++){
        list1.pushAtBack('a');
        list2.pushAtBack('z');
    }

    list1.concatenate(&list2);
    assert(list1.size() == 200);
    assert(list1.elementAt(100) == 'z');
    assert(list1.elementAt(99) == 'a');
    assert(list1.elementAt(199) == 'z');
}

// Test concatenate() on an empty list
void test_concatenate_onEmpty() {
    CharLinkedList list1;

    char arr2[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList list2(arr2, 8);

    list1.concatenate(&list2);
    assert(list1.toString() == list2.toString());
    assert(list1.toString() == "[CharLinkedList of size 8 <<abcdefgh>>]");
}

// Test concatenate() with an empty list
void test_concatenate_withEmpty() {
    char arr1[6] = { 'A', 'p', 'p', 'l', 'e', 's' };
    CharLinkedList list1(arr1, 6);
    assert(list1.toString() == "[CharLinkedList of size 6 <<Apples>>]");

    CharLinkedList list2;

    list1.concatenate(&list2);
    assert(list1.toString() == "[CharLinkedList of size 6 <<Apples>>]");
}

// Test concatenate() with itself
void test_concatenate_withItself() {
    char arr1[3] = { 'R', 'a', 'd' };
    CharLinkedList list1(arr1, 3);

    list1.concatenate(&list1);
    assert(list1.toString() == "[CharLinkedList of size 6 <<RadRad>>]");
}

// test empty on empty
void test_concatenate_bothEmpty() {
    CharLinkedList list1;
    CharLinkedList list2;

    list1.concatenate(&list2);
    assert(list1.toString() == "[CharLinkedList of size 0 <<>>]");
}

// test concatenate() and pointers
void test_concatenate_pointers() {
    CharLinkedList list1('A');
    CharLinkedList list2('B');

    list1.concatenate(&list2);

    // modify list2 after concatenation
    list2.pushAtBack('C');

    // make sure that a change to list2 does not change the list1 
    assert(list1.toString() == "[CharLinkedList of size 2 <<AB>>]");
}

// test concatentate() twice
void test_concatenate_twice() {
    CharLinkedList list1('A');
    CharLinkedList list2('B');
    CharLinkedList list3('D');

    list1.concatenate(&list2);
    list1.concatenate(&list3);

    assert(list1.toString() == "[CharLinkedList of size 3 <<ABD>>]");
}

// Checks correct insertion into an empty array list
// Afterwards, size should be 1 and element at index 0
// should be the element we inserted.
void insertAt_empty_correct() { 

    CharLinkedList test_list;
    test_list.insertAt('a', 0);
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');

}

// Tests incorrect insertion into an empty list.
// Attempts to call insertAt for index larger than 0.
// This should result in an std::range_error being raised.
void insertAt_empty_incorrect() {
    bool range_error_thrown = false;
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    // insertAt for out-of-range index
    test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0]");
    
}

// Tests correct insertAt for front of 1-element list.
void insertAt_front_singleton_list() {
    CharLinkedList test_list('a');

    // insert at front
    test_list.insertAt('b', 0);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'a');
    
}

// Tests correct insertAt for back of 1-element list.
void insertAt_back_singleton_list() {
    CharLinkedList test_list('a');

    // insert at back
    test_list.insertAt('b', 1);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    
}

// Tests calling insertAt for a large number of elements.
// Not only does this test insertAt, it also checks that
// array expansion works correctly.
void insertAt_many_elements() { 
    CharLinkedList test_list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.insertAt('a', i);
    }

    assert(test_list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
    
}

// Tests insertion into front of a larger list
void insertAt_front_large_list() {
    char test_arr[5] = { 'a', 'b', 'c', 'z', 'd'};
    CharLinkedList test_list(test_arr, 5);

    test_list.insertAt('y', 0);

    assert(test_list.toString() == "[CharLinkedList of size 6 <<yabczd>>]");

}

// Tests insertion into the back of a larger list
void insertAt_back_large_list() {

    char test_arr[10] = { 'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 10);  

    test_list.insertAt('x', 10);

    assert(test_list.size() == 11);
    assert(test_list.elementAt(10) == 'x');
    assert(test_list.toString() == 
    "[CharLinkedList of size 11 <<yabczdefghx>>]"); 

}

// Tests insertion into the middle of a larger list
void insertAt_middle_large_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.insertAt('z', 3);

    assert(test_list.size() == 9);
    assert(test_list.elementAt(3) == 'z');
    assert(test_list.toString() == "[CharLinkedList of size 9 <<abczdefgh>>]");

}

// Tests out-of-range insertion for a non-empty list.
void insertAt_nonempty_incorrect() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    bool range_error_thrown = false;
    std::string error_message = "";

    try {
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8]");
}


// NOTE: THE FOLLOWING TESTS ARE FOR PRIVATE HELPER FUNCTIONS. To uses these
// tests, all variable and functions were made public in CharLinkedList.h
// temporarily. Then, these tests were commented out. 

// Tests private function elementAtHelper()
// void test_elementAtHelper() {
//     char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
//     CharLinkedList myList(test_arr, 8);
    
//     assert(myList.elementAtHelper(myList.front, 4) == 'e');
    
// }

// Tests private function replaceAtHelper()
// void test_replaceAtHelper() {
//     char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
//     CharLinkedList myList(test_arr, 8);

//     myList.replaceAtHelper(myList.front, 'z', 2);
//     assert(myList.toString() == "[CharLinkedList of size 8 <<abzdefgh>>]");
// }


// tests private helper function lastNode() with a non-empty list
// Should return z
// void test_lastNode_nonEmpty() {
//     char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
//     CharLinkedList myList(test_arr, 8);

//     CharLinkedList::Node *last_node = myList.lastNode(myList.front);
//     assert(last_node->character == 'h');
// }

// tests private helper function lastNode() with an empty list
// void test_lastNode_Empty() {
//     CharLinkedList myList;
//     assert(myList.lastNode(myList.front) == nullptr);
// }

// tests private helper function lastNode() with a single character list
// void test_lastNode_singleList() {
//     CharLinkedList myList('a');

//     CharLinkedList::Node *last_node = myList.lastNode(myList.front);
//     assert(last_node->character == 'a');
// }

// tests private helper function newNode(), where next and back are nullptr
// void test_newNode_bothNull() {
//     CharLinkedList myList;
//     CharLinkedList::Node *myNode = myList.newNode('a', nullptr, nullptr);
//     assert(myNode->next == nullptr);
//     assert(myNode->back == nullptr);
//     assert(myNode->character == 'a');
// }

// test private helper function newNode(), where next is nullptr
// void test_newNode_nextNull() {
//     CharLinkedList myList;

//     CharLinkedList::Node *node = myList.newNode('a', nullptr, myList.front);
//     assert(node->next == nullptr);
//     assert(node->back == myList.front);
//     assert(node->character == 'a');
// }

// test private helper function newNode(), where back is nullptr
// void test_newNode_backNull() {
//     CharLinkedList myList;

//     CharLinkedList::Node *node = myList.newNode('a', myList.front, nullptr);
//     assert(node->next == myList.front);
//     assert(node->back == nullptr);
//     assert(node->character == 'a');
// }

// test private helper function copy(), with an empty list
// void test_copy_emptyList() {
//     CharLinkedList myList;
//     CharLinkedList copiedList;
//     copiedList.copy(myList);

//     assert(copiedList.isEmpty());
//     assert(myList.isEmpty());
//     assert(copiedList.toString() == myList.toString());
// }

// test private helper function copy(), with an non-empty list
// void test_copy_nonEmpty() {
//     char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
//     CharLinkedList myList(test_arr, 8);

//     CharLinkedList copiedList;
//     copiedList.copy(myList);

//     assert(copiedList.toString() == myList.toString());
// }

// test private helper function copy(), with a single element list
// void test_copy_singleElement() {
//     CharLinkedList myList('d');

//     CharLinkedList copiedList;
//     copiedList.copy(myList);

//     assert(copiedList.toString() == myList.toString());
// }


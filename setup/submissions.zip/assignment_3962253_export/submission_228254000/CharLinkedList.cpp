/*
 *  CharLinkedList.cpp
 *  Sophie Zhou (szhou13)
 *  February 1st, 2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Purpose: This file contains an implementation of the CharArrayList class
 *
 */

#include "CharLinkedList.h"

#include <sstream>
#include <stdexcept>

using namespace std;

/*
 * name: initialize
 * purpose: helper function that initializes an empty array list
 */
void CharLinkedList::initialize() {
    front = nullptr;
    numItems = 0;
};

/*
 * name: newNode
 * purpose: helper function that creates a new node
 * arguments: a character that the node holds, a pointer to the the next node,
 *            and a pointer to the node before it
 * returns: a pointer to the new node
 */
CharLinkedList::Node *CharLinkedList::newNode(char c, Node *next, Node *back) {
    Node *new_node = new Node;
    new_node->character = c;
    new_node->next = next;
    new_node-> back = back;

    return new_node;
};

/*
 * name: default constructor
 * purpose: initializes an empty array list, taking no parameters
 */
CharLinkedList::CharLinkedList() {
    initialize();
};

/*
 * name: second constructor
 * purpose: creates a one element array list 
 * arguments: a character c that will be the one character in the list
 */
CharLinkedList::CharLinkedList(char c){ 
    initialize();
    front = newNode(c, nullptr, nullptr);
    numItems = 1;
};

/*
 * name: third constructor
 * purpose: creates a list containing the characters in the provided 
 *          array
 * arguments: an array of characters that will make up the list and the integer
 *            size representing the length of the list
 */
CharLinkedList::CharLinkedList(char arr[], int size) {
    initialize(); 
    for (int i = 0; i < size; i++) {
        pushAtBack(arr[i]);
    } 
};

/*
 * name: copy
 * purpose: helper function that makes a deep copy of a given instance of the
 *          class
 * arguments: a reference to the CharLinkedList instance to be deep copied
 */
void CharLinkedList::copy(const CharLinkedList &other) {
    Node *curr_node = other.front;
    
    while (not (curr_node == nullptr)) {
        pushAtBack(curr_node->character);
        curr_node = curr_node->next;
    }
    numItems = other.numItems;
};


/*
 * name: copy constructor 
 * purpose: makes a deep copy of a given instance of the class
 * arguments: a reference to the CharLinkedList instance to be deep copied
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other) {
    initialize();  
    // performs a deep copy
    copy(other);
};

/*
 * name: destructor
 * purpose: recycles all heap-allocated data in the current list
 * effects: deletes all nodes, preventing memory leaks
 */
CharLinkedList::~CharLinkedList() {
    destructorHelper(front);
};

/*
 * name: destructorHelper
 * purpose: private recursive helper function for the destructor (which is a
 * public function)
 * effects: deletes all nodes, preventing memory leaks
 */
void CharLinkedList::destructorHelper(Node *current){
    if (current == nullptr) {
        return;
    } else {
        Node *next = current->next;
        delete current;
        destructorHelper(next);
    }
};

/*
 * name: assignment operator 
 * purpose: makes a deep copy 
 * arguments: makes a deep copy of the instance of CharLinkedList on the right 
 *            hand side into the instance on the left hand side 
 * effects: recycles the storage associated with the instance on the left of 
 *          the assignment
 */
CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other) {
    // checks for self-assignment
    if (this == &other) {
        return *this;
    }
    
    // deallocates existing memory
    clear();
   
    // performs a deep copy
    copy(other);
    return *this;
};


/*
 * name: isEmpty
 * purpose: identifies if the list is empty 
 * returns: a boolean value that is true if the list is empty 
 */
bool CharLinkedList::isEmpty() const {
    return numItems == 0;
};

/*
 * name: clear
 * purpose: clears all items in the list
 * effects: recycles heap-allocated memory, resets front and numItems
 */
void CharLinkedList::clear() {
    destructorHelper(front);

    // resets the numItems and front pointer 
    initialize();
};


/*
 * name: size
 * purpose: identifies the size of the list
 * returns: an integer value that represents the number of characters in the 
 *          list
 */
int CharLinkedList::size() const {
    return numItems;
};

/*
 * name: first
 * purpose: identifies the first character in the list
 * returns: the first character in the list
 * effects: throws a runtime error exception if the function is called on an 
 *          empty list
 */
char CharLinkedList::first() const {
    if (isEmpty()) {
        throw std::runtime_error("cannot get first of empty LinkedList");
    } else {
        return front->character;
    }
};

/*
 * name: lastNode
 * purpose: helper function taht finds the the last node in the list
 * returns: a Node pointer to the last node in the list
 */
CharLinkedList::Node *CharLinkedList::lastNode(Node *curr) const {
    Node *last_node = nullptr;
    while (not(curr == nullptr)) {
        last_node = curr;
        curr = curr->next;
    }
    return last_node;
};

/*
 * name: last
 * purpose: identifies the last character in the list
 * returns: the last character in the list
 * effects: throws a runtime error exception if the function is called on an 
 *          empty list
 */
char CharLinkedList::last() const {
    if (isEmpty()) {
        throw std::runtime_error("cannot get last of empty LinkedList");
    } else {
        Node *last_node = lastNode(front);
        return last_node->character;
    } 
};

/*
 * name: elementAt
 * purpose: identifies the element at a given index
 * arguments: an integer index representing the index of the list the client 
 *            wants to get a character from (starting from 0)
 * returns: the character in the list at the provided index
 */
char CharLinkedList::elementAt(int index) const {
     if (index < 0 or index > numItems - 1){
        throw std::range_error("index (" + std::to_string(index) +
        ") not in range [0.." + std::to_string(numItems) + ")");  
    } else {
        char c = elementAtHelper(front, index);
        return c;
    } 
};

/*
 * name: elementAtHelper
 * purpose: a private function that recursively retrieves the element at 
 *          the given index
 * arguments: the node to start at and the index of the list the client wants
 *            to get a character from
 * returns: the character in the list at the provided index
 */
char CharLinkedList::elementAtHelper(Node *curr, int index) const {
    if (index == 0) {
        return curr->character;
    } else {
        return elementAtHelper(curr->next, index - 1);
    }
};

/*
 * name: toString
 * purpose: returns a message containing the size of the list and the 
 *          characters in it
 * returns: a string containing a message showing the size and contents of the 
 *          list
 */
std::string CharLinkedList::toString() const {
   std::stringstream message;
    message << "[CharLinkedList of size " << numItems << " <<";

    Node *curr_node = front;
    while (not (curr_node == nullptr)){
        message << curr_node->character;
        curr_node = curr_node->next;
    }

    message << ">>]";

    return message.str();
};

/*
 * name: toReverseString
 * purpose: returns a message containing the size of the list and its contents
 *          in reverse
 * returns: a string containing a message showing the size and contents of the 
 *          list in reverse
 */
std::string CharLinkedList::toReverseString() const {
    std::stringstream message;
    message << "[CharLinkedList of size " << numItems << " <<";

    Node *curr_node = front;
    if (not(isEmpty())) {
        // locate the last node in the list
        while (not(curr_node->next == nullptr)) {
            curr_node = curr_node->next;
        }
        // print out the character, going from the back to the front
        while (not (curr_node == nullptr)) {
            message << curr_node->character;
            curr_node = curr_node->back;
        }
    }
    message << ">>]";
    return message.str();
};

/*
 * name: pushAtBack
 * purpose: inserts a character at the end of the list
 * arguments: a character c that will be added to the end of the list
 * effects: the variable numItems increases by one
 */
void CharLinkedList::pushAtBack(char c) {
    Node *new_node = newNode(c, nullptr, nullptr);

    if (isEmpty()) {
        front = new_node;
    } else {
        Node *last_node = lastNode(front);
        last_node->next = new_node;
        new_node->back = last_node;
    }
    numItems++;
};

/*
 * name: pushAtFront
 * purpose: inserts a character at the front of the list
 * arguments: a character c that will be added to the front of the list
 * effects: increases the numItems by one
 */
void CharLinkedList::pushAtFront(char c) {
   Node *new_node = newNode(c, nullptr, nullptr);
   
   if (not(isEmpty())) {
        front->back = new_node;
        new_node->next = front;
    }
    front = new_node;
    numItems++;
};

/*
 * name: insertAt
 * purpose: inserts an element at the provided index of the list
 * arguments: a character to be inserted and an integer representing a 
 *            CharLinkedList index
 * effects: raises an error if index is out of bounds of the CharLinkedList,
 *          otherwise, it adds the character and the provided index and 
 *          increments numItems by one
 */
void CharLinkedList::insertAt(char c, int index) {
    if (index < 0 or index > numItems){
        throw std::range_error("index (" + std::to_string(index) +
        ") not in range [0.." + std::to_string(numItems) + "]");  
    } else {
        if (isEmpty() or index == 0) {
            pushAtFront(c);
        } else if (index == numItems) {
            pushAtBack(c);
        } else {
            Node *new_node = newNode(c, nullptr, nullptr);
            Node *curr_node = front;
            // find the node we want to insert the new node after
            for (int i = 0; i < index - 1; i++) {
                curr_node = curr_node->next;
            }   
            new_node->next = curr_node->next;
            new_node->back = curr_node;
           
            // update curr_node's "next" pointer to our new node
            curr_node->next = new_node;
            numItems++;
        }
    }
};

/*
 * name: insertInOrder
 * purpose: inserts a character into the list in ascending ASCII order 
 *          (assuming the list is sorted in ascending order)
 * arguments: a character c to be inserted
 * effects: inserts the character at the appropriate index, and increments
 *          numItems by one.
 */
void CharLinkedList::insertInOrder(char c) {
    if (isEmpty() or front->character > c) {
        insertAt(c, 0);
    } else {
        Node *curr_node = front;
        int index = 0;
        // walk through the list, updating index if the existing character is 
        // lower on the ASCII table
        while (not (curr_node == nullptr)) {
            if (curr_node->character <= c) {
                index++;
            }
            curr_node = curr_node->next;
        }
        insertAt(c, index);
    }
};

/*
 * name: popFromFront
 * purpose: removes the first element from the list
 * effects: raises an error if called on an empty list. otherwise, it decreases
 *          numItems by one.
 */
void CharLinkedList::popFromFront() {
    if (isEmpty()){
        throw std::runtime_error("cannot pop from empty LinkedList");
    } else {
        Node *curr_node = front; 
        if (numItems == 1) {
            clear();
        } else {
            // handle pointers
            front = curr_node->next;
            front->back = nullptr; 

            numItems--;
            delete curr_node;
        }
    }
};

/*
 * name: popFromBack
 * purpose: removes the last element from the list
 * effects: raises an error if called on an empty list. otherwise, it decreases
 *          numItems by one.
 */
void CharLinkedList::popFromBack() {
    if (isEmpty()) {
        throw std::runtime_error("cannot pop from empty LinkedList");
    } else {
        if (numItems == 1) {
            clear();
        } else {
            Node *last_node = lastNode(front);

            // handle pointers
            Node *new_last = last_node->back;
            new_last->next = nullptr;

            delete last_node;
            numItems--;
        }
    }
};

/*
 * name: removeAt
 * purpose: removes an element at a specified index
 * arguments: an integer representing the index where a character should be
 *            removed
 * effects: raises an error if the index is out of bounds. otherwise, the 
 *          numItems is decreased by one
 */
void CharLinkedList::removeAt(int index) {
    if (index < 0 or index > numItems - 1){
        throw std::range_error("index (" + std::to_string(index) +
        ") not in range [0.." + std::to_string(numItems) + ")");  
    }  
    if (index == 0) {
        popFromFront();
    } else if (index == numItems - 1) {
        popFromBack();
    } else {
        // find the node to remove
        Node *curr_node = front;
        for (int i = 0; i < index; i++) {
            curr_node = curr_node->next;
        }
        // handle pointers
        curr_node->back->next = curr_node->next;
        curr_node->next->back = curr_node->back;
        
        delete curr_node;
        numItems--;
    }
};

/*
 * name: replaceAt
 * purpose: replaces the character at a specified index with another 
 *          character
 * arguments: a character representing the character to be inserted, and an
 *            integer representing the index where the replacement will occur
 * effects: raises an error if index is out of bonds. otherwise, the element
 *           at the given index with be replaced with the provided character
 */
void CharLinkedList::replaceAt(char c, int index) {
    if (index < 0 or index > numItems - 1){
        throw std::range_error("index (" + std::to_string(index) +
        ") not in range [0.." + std::to_string(numItems) + ")");  
    } else {
        replaceAtHelper(front, c, index);
    }
};

/*
 * name: replaceAtHelper
 * purpose: private function that replaces the character at a specified index 
 *          with another character 
 * arguments: a Node pointer to the current node, a character representing the 
 *            element to be inserted, and an integer representing the index
 *            where the replacement will occur
 */
void CharLinkedList::replaceAtHelper(Node *curr, char c, int index) {
    if (index == 0) {
        curr->character = c;
        return;
    } else {
        replaceAtHelper(curr->next, c, index - 1);
    }
};

/*
 * name: concatenate
 * purpose: adds a copy of an array list to the current array list
 * arguments: a pointer to another CharLinkedList
 * effects: adds a copy of the given CharLinkedList to the LinkedList that the
 *          function was called on. Updates the size accordingly
 */
void CharLinkedList::concatenate(CharLinkedList *other){
    int other_size = other->numItems;
        
    // traverse through the "other" list, adding each character to the back
    // of the current list
    Node *curr_node = other->front;
    for (int i = 0; i < other_size; i++) {
        if (not (curr_node == nullptr)) {
            pushAtBack(curr_node->character);
            curr_node = curr_node->next;
        }
    }
};
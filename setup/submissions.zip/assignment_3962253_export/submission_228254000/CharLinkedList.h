/*
 *  CharLinkedList.h
 *  Sophie Zhou (szhou13)
 *  February 1st, 2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  CharLinkedList is a class that represents a ListADT holding characters 
 *  by using a linked list. Clients can create an empty list, a list holding
 *  one character, or a larger list holding multiple characters. Clients can 
 *  also perform actions on the list such as accessing characters in the list 
 *  inserting/removing characters and concatenating a list with another list.
 *
 */

#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H

#include <string>

class CharLinkedList {
  public:
    CharLinkedList();
    CharLinkedList(char c);
    CharLinkedList(char arr[], int size);
    CharLinkedList(const CharLinkedList &other);
    ~CharLinkedList();
    CharLinkedList &operator=(const CharLinkedList &other);
    bool isEmpty() const;
    void clear();
    int size() const;
    char first() const;
    char last() const;
    char elementAt(int index) const;
    std::string toString() const;
    std::string toReverseString() const;
    void pushAtBack(char c);
    void pushAtFront(char c);
    void insertAt(char c, int index);
    void insertInOrder(char c);
    void popFromFront();
    void popFromBack();
    void removeAt(int index);
    void replaceAt(char c, int index);
    void concatenate(CharLinkedList *other);

  private:
    struct Node {
        char character;
        Node *next;
        Node *back;
    };

    Node *front;
    int numItems;

    // recursive helper function for the public destructor
    void destructorHelper(Node *current);
    // recursive helper function for the public function elementAt
    char elementAtHelper(Node *curr, int index) const;
    // recursive helper function for the public function replaceAt
    void replaceAtHelper(Node *curr, char c, int index);
    // initializes an empty list
    void initialize();
    // creates a new node
    Node *newNode(char c, Node *next, Node *back);
    // makes a copy of a node
    void copy(const CharLinkedList &other);
    // finds the last node in the list
    Node *lastNode(Node *curr) const;
};

#endif

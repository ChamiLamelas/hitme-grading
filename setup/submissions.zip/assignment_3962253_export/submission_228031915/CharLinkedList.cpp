/*
 *  CharLinkedList.cpp
 *  Angela Huynh (ahuynh02)
 *  1/30/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Implementation/function definitions for CharLinkedList class
 *  Some functions may throw range or runtime errors if index is out
 *  of range or list is empty. 
 *
 */

#include "CharLinkedList.h"

/*
 * name:      CharLinkedList default constructor
 * purpose:   initialize an empty linked list
 * arguments: none
 * returns:   none
 * effects:   initializes member variables of the class
 */
CharLinkedList::CharLinkedList() {
    head = nullptr;
    tail = nullptr;
    numItems  = 0;
}

/*
 * name:      CharLinkedList single char constructor
 * purpose:   initialize a CharLinkedList with one element
 * arguments: a char
 * returns:   none
 * effects:   creates CharArrayList with one char 
 */
CharLinkedList::CharLinkedList(char c) {
    Node* newChar = new Node(c, nullptr, nullptr);
    numItems = 1;
    head = newChar;
    tail = newChar; 
}

/*
 * name:      CharLinkedList mulitple char constructor
 * purpose:   initialize a list with multiple elements
 * arguments: an array of chars and the number of elements in 
 *            that array
 * returns:   none
 * effects:   creates linked list with multiple chars 
 */
CharLinkedList::CharLinkedList(char arr[], int size) {
    numItems = size;
    Node* current = new Node(arr[0], nullptr, nullptr);
    head = tail = current;
    for(int i = 1; i < size; i++){
        Node* nextNode = new Node(arr[i], nullptr, nullptr);
        tail->next = nextNode;
        nextNode->prev = tail; 
        tail = nextNode;
    } 
}

/*
 * name:      CharLinkedList copy constructor 
 * purpose:   makes a deep copy of another CharLinkedList
 * arguments: an address of another list
 * returns:   a deep copy of the original list
 * effects:   creates a copy of an a list
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other){
    numItems = 0;
    Node* current = other.head;
    while(current != nullptr){
        pushAtBack(current->info);
        current = current->next;
    }
}

/*
 * name:      CharLinkedList assignment operator 
 * purpose:   deep copy of the another list
 * arguments: an address of another list 
 * returns:   a deep copy of another list
 * effects:   adds values from other list to its own list
 */
CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other){
    if (this == &other) {
        return *this;
    }
    
    clear();
    Node* current = other.head;
    while (current) {
        pushAtBack(current->info);
        current = current->next;
    }
   
    return *this; 
}


/*
 * name:      CharLinkedList destructor
 * purpose:   destructor of CharLinkedList 
 * arguments: none
 * returns:   none
 * effects:   frees memory 
 */
CharLinkedList::~CharLinkedList() {
    removeAll(head);
    numItems = 0;
    head = nullptr;
    tail = nullptr;
}


/*
 * name:      size
 * purpose:   return the number of elements in the linked list
 * arguments: none
 * returns:   an int of the number of elements 
 * effects:   none
 */
int CharLinkedList::size() const {
    return numItems; 
}

/*
 * name:      first
 * purpose:   finds first element of linked list
 * arguments: none
 * returns:   a char at the first index of the list
 * effects:   could throw an error message if list is empty
 */
char CharLinkedList::first() const {
    if(isEmpty()){
        throw std::runtime_error("cannot get first of empty LinkedList");
    }
    return head->info; 
}

/*
 * name:      last
 * purpose:   finds last element of linked list
 * arguments: none
 * returns:   a char at the last index of the list
 * effects:   could throw an error message if list is empty
 */
char CharLinkedList::last() const {
    if(isEmpty()){
        throw std::runtime_error("cannot get last of empty LinkedList");
    }
    return tail->info; 
}

/*
 * name:      clear
 * purpose:   removes all elements from the list
 * arguments: none
 * returns:   none
 * effects:   tail and head become null 
 */
void CharLinkedList::clear() {
    if(isEmpty()){
        return;
    }
    removeAll(head);
    numItems = 0;
    head = nullptr;
    tail = nullptr;
}

/*
 * name:      isEmpty
 * purpose:   determines if the list is empty or not
 * arguments: none
 * returns:   true if list contains no elements, false otherwise
 * effects:   none
 */
bool CharLinkedList::isEmpty() const {
    return numItems == 0; 
}

/*
 * name:      toString
 * purpose:   turns the array into a string, and returns it
 * arguments: none
 * returns:   a string representation of the array
 * effects:   none
 */
std::string CharLinkedList::toString() const {
    std::stringstream ss;
    ss << "[CharLinkedList of size " << numItems << " <<";
    if(isEmpty()){
        ss << "";
    } else {
        Node *current = head;
        for(int i = 0; i < numItems; i++){
            ss << current->info;
            current = current->next;
        }
    }
    
    ss << ">>]";
    return ss.str();
}

/*
 * name:      toReverseString
 * purpose:   turns the chars in list into a reverse string
 * arguments: none
 * returns:   a backwards string of the chars in list
 * effects:   none
 */
std::string CharLinkedList::toReverseString() const {
    std::stringstream ss;
    ss << "[CharLinkedList of size " << numItems << " <<";
    if(isEmpty()){
        ss << "";
    } else {
        Node *current = tail;
        for(int i = 0; i < numItems; i++){
            ss << current->info;
            current = current->prev;
        }
    }
    
    ss << ">>]";
    return ss.str();
}

/*
 * name:      elementAt
 * purpose:   finds the element at a given index 
 * arguments: an int that tells us which index to find 
 * returns:   the element of the array at the given index
 * effects:   could print out error message if index is out of range
*/
char CharLinkedList::elementAt(int index) const {
    if (index < 0 or index >= numItems) {
        std::stringstream ss;
        ss << "index (" << index << ") not in range [0.." << numItems;
        ss << ")";
        throw std::range_error(ss.str());
    }
    Node* current = getNode(index, head);
    return current->info;
}


/*
 * name:      insertAt
 * purpose:   adds a new element to linked list
 * arguments: a char to be inserted and an index of where
 * returns:   none
 * effects:   a new element in the list, size increases by 1
 */
void CharLinkedList::insertAt(char c, int index) {
    if (index < 0 or index > numItems) {
        std::stringstream ss;
        ss << "index (" << index << ") not in range [0.." << numItems;
        ss << "]";
        throw std::range_error(ss.str());
    }

    Node* current = getNode(index, head);
    Node* newChar = new Node(c, nullptr, nullptr);
    if(isEmpty()){
        head = tail = newChar;
    } else if (index == 0) { //check if inserting at front
        newChar->next = head;
        head->prev = newChar;
        head = newChar;
    } else if (index == numItems) { //check if inserting at tail
        newChar->prev = tail;
        tail->next = newChar;
        tail = newChar;
    } else { //inserting in the middle
        current = current->prev;
        newChar->prev = current;
        newChar->next = current->next;
        current->next = newChar;
        newChar->next->prev = newChar; 
    }
    numItems++;
}


/*
 * name:      removeAt
 * purpose:   removes element from an element in the array
 * arguments: an index to erase an element from 
 * returns:   none
 * effects:   removes an element from list, decrease numItems
 */
void CharLinkedList::removeAt(int index) {
    if (index < 0 or index >= numItems) {
        std::stringstream ss;
        ss << "index (" << index << ") not in range [0.." << numItems;
        ss << ")";
        throw std::range_error(ss.str());
    }

    Node* current = getNode(index, head);
    if(index == 0){ //removing from beginning
        head = head->next;
        if(head != nullptr){
            head->prev = nullptr;
        }
    } else if(current == tail) { //removing from end 
        tail = tail->prev;
        tail->next = nullptr;
    } else { 
        //removing from middle
        current->prev->next = current->next;
        current->next->prev = current->prev;
    } 
    delete current;
    numItems--;
}

/*
 * name:      pushAtBack
 * purpose:   adds a new element to end of the list
 * arguments: a char
 * returns:   none
 * effects:   a new element at the end of the list
 */
void CharLinkedList::pushAtBack(char c) {
    insertAt(c, numItems);
}

/*
 * name:      pushAtFront
 * purpose:   adds a new element to front of the list
 * arguments: a char to add
 * returns:   none
 * effects:   a new element at the front of the list 
 */
void CharLinkedList::pushAtFront(char c) {
    insertAt(c,0);
}

/*
 * name:      insertInOrder
 * purpose:   adds a new element to arraylist in ascii order
 * arguments: a char to be inserted
 * returns:   none
 * effects:   a new element in the arrayList at correct index, 
 */
void CharLinkedList::insertInOrder(char c) {
    if(isEmpty()){
        pushAtFront(c);
        return;
    }
    if(c >= tail->info){
        pushAtBack(c);
        return;
    }
    Node *current = head; 
    int index = 0;
    while(current->next != nullptr and c > current->info){
        current = current->next;
        index++;
    }
    insertAt(c, index);
}

/*
 * name:      popFromBack
 * purpose:   removes element from end of list
 * arguments: none
 * returns:   none
 * effects:   may throw an error message on an empty List
 */

void CharLinkedList::popFromBack() {
    if(isEmpty()){
        throw std::runtime_error("cannot pop from empty LinkedList");
    }
    removeAt(numItems - 1);
}

/*
 * name:      popFromFront
 * purpose:   removes element from front of list
 * arguments: none
 * returns:   none
 * effects:   may throw an error message on an empty list
 */
void CharLinkedList::popFromFront() {
    if(isEmpty()){
        throw std::runtime_error("cannot pop from empty LinkedList");
    }
  
    removeAt(0);
}

/*
 * name:      replaceAt
 * purpose:   replaces an element in list at given index
 * arguments: a char to replace with and an index of where
 * returns:   none
 * effects:   a replaced element in the list at given index, 
 *            may throw an error message if index is out of range
 */
void CharLinkedList::replaceAt(char c, int index) {
    if (index < 0 or index >= numItems) {
        std::stringstream ss;
        ss << "index (" << index << ") not in range [0.." << numItems;
        ss << ")";
        throw std::range_error(ss.str());
    }
    Node* current = getNode(index, head);
    current->info = c;
}

/*
 * name:      concatenate 
 * purpose:   adds a copy of a list to another list
 * arguments: a pointer to an list to copy
 * returns:   none
 * effects:   a list that has both arrays combined 
 */
void CharLinkedList::concatenate(CharLinkedList *other) {
    if(other->isEmpty()){
        return;
    }
    int otherNumItems = other->size();
    for(int i = 0; i < otherNumItems; i++){
       pushAtBack(other->elementAt(i));
    }
}


/*
 * name:      getNode
 * purpose:   finds a node at a given index
 * arguments: an index of which node to find 
 * returns:   A node at the given index 
 * effects:   none
 */
CharLinkedList::Node* CharLinkedList::getNode(int index, Node* current) const{
    if (index == numItems - 1) {
        return tail;
    }
    if (index == 0) {
        return current;
    }
    return getNode(index - 1, current->next); 
}

/*
 * name:      removeAll
 * purpose:   fremoves all nodes after a given node
 * arguments: a node of where ot start
 * returns:   none
 * effects:   none
 */
void CharLinkedList::removeAll(Node* current) const{
    if(current != nullptr){
        removeAll(current->next);
        delete current;
    }
}
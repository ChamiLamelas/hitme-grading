/*
 *  unit_tests.h
 *  Angela Huynh (ahuynh02)
 *  2/1/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  Unit testing file for CharLinkedList objects, run using unit_test
 *  in terminal to check for validity of class functions
 *
 */
#include "CharLinkedList.h"
#include <cassert>



/*
 * default constructor test 0
 * Make sure no fatal errors/memory leaks in the default constructor
 */
void default_constructor_test_0() {
    CharLinkedList list;
}

/*
 * default constructor test 1
 * Make sure no items exist in the list upon construction
 */
void default_constructor_test_1() {
    CharLinkedList list; 
    assert(list.size() == 0);
}

/*
 * single char constructor test 0
 * Make sure no fatal errors/memory leaks 
 */
void single_char_constructor_test_0() {
    CharLinkedList list = CharLinkedList('a');
    assert(list.size() == 1);
}

/*
 * single char constructor test 1
 * Make sure numItems is equal to 1 and the correct char is stored
 */
void single_char_constructor_test_1() {
    CharLinkedList list = CharLinkedList('a');
    assert(list.size() == 1 and list.first() == 'a');
}

/*
 * array constructor test 0
 * Make sure no fatal errors/memory leaks in the default constructor
 */
void array_constructor_test_0() {
    char c[5] = {'a','b','c','d','e'};
    CharLinkedList list = CharLinkedList(c,5);
}

/*
 * array constructor test 1
 * Make sure numItems is equal to given size of array
 * and the correct values are stored in the list
 */
void array_constructor_test_1() {
    char c[5] = {'a','b','c','d','e'};
    CharLinkedList list = CharLinkedList(c,5);
    assert(list.size() == 5);
    for (int i = 0; i < 5; i++){
        assert(list.elementAt(i) == c[i]);
    }
}

/*
* copy constructor test 0
*
*/
void copy_constructor_0() {
    char arr1[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList list = CharLinkedList(arr1, 8); 
    CharLinkedList list2 = CharLinkedList(list);

    list.clear();
    assert(list.size() == 0);

    assert(list2.size() == 8);
    assert(list2.toString() ==  
    "[CharLinkedList of size 8 <<abcdefgh>>]");

}

/*
* assignment operator test 0
* ensures assignment operator is working 
*/
void assignment_operator_test_0() {
    char test_arr1[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list1(test_arr1, 8);
    char test_arr2[7] = { 'q', 'r', 's', 't', 'u', 'v', 'w' };
    CharLinkedList test_list2(test_arr2, 7);

    test_list1 = test_list2;
    test_list2.clear();

    assert(test_list1.size() == 7);
    assert(test_list1.toString() ==    
    "[CharLinkedList of size 7 <<qrstuvw>>]");

}

/*
 * isEmpty test 0 
 * Make sure no items exist in the list upon construction
 */
void isEmpty_test_0() {
    CharLinkedList list; 
    assert(list.isEmpty());
}

/* 
 * first test 0;
 * Make sure first returns the correct char
 */
void first_test_0() {
   char c[5] = {'a','b','c','d','e'};
   CharLinkedList list = CharLinkedList(c,5);
   assert(list.first()  == 'a');
}

/* 
 * first test 1;
 * Make sure first doesn't try to access empty list
 */
void first_test_1() {
    CharLinkedList list;
    bool runtime_error_thrown = false;
    std::string error_message = "";

    try { 
        list.first();
    } 
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot get first of empty LinkedList");
   
}

/* 
 * last test 0;
 * Make sure first returns the correct char
 */
void last_test_0() {
   char c[5] = {'a','b','c','d','e'};
   CharLinkedList list = CharLinkedList(c,5);
   assert(list.last()  == 'e');
}

/* 
 * last test 1;
 * Make sure last doesn't try to access empty list
 */
void last_test_1() {
    CharLinkedList list;
    bool runtime_error_thrown = false;
    std::string error_message = "";

    try { 
        list.last();
    } 
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot get last of empty LinkedList");
}

/* 
 * elementAt test 0;
 * Make sure elementAt returns the correct char
 */
void elementAt_test_0() {
   char c[5] = {'a','b','c','d','e'};
   CharLinkedList list = CharLinkedList(c,5);
   assert(list.elementAt(3)  == 'd');
}

/* 
 * elementAt test 1;
 * Make sure elementAt does not try to access an index 
 * that is out of range
 */
void elementAt_test_1() {
    char c[5] = {'a','b','c','d','e'};
    CharLinkedList list = CharLinkedList(c,5);
    bool range_error_thrown = false;
    std::string error_message = "";
    try { 
        list.elementAt(10);
    } 
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (10) not in range [0..5)");

}

/* 
 * isEmpty test 1
 * Make sure a non-empty list is not reported as empty
 */
void isEmpty_test_1() {
    CharLinkedList list = CharLinkedList('a');
    assert(not list.isEmpty());
}

/* 
 * clear test 0;
 * Make sure clear removes all elements from a non-empty list
 */
void clear_test_0() {
    CharLinkedList list = CharLinkedList('a');
    list.clear();
    assert(list.isEmpty());
}

/* 
 * clear test 1
 * Make sure clear doesn't try to remove elements from an 
 * already empty list
 */
void clear_test_1() {
    CharLinkedList list;
    list.clear();
    assert(list.isEmpty());
}

/* 
 * clear test 2 
 *  clearing from a list with many items 
 */
void clear_test_2() {
    
    CharLinkedList list;
    for (int i = 0; i < 1000; i++) {
        list.insertAt('a', i);
    }
    assert(list.size() == 1000);

    list.clear();

    assert(list.size() == 0);
    
}

/* 
 * string test 0;
 * Make sure toString returns correct value 
 */
void string_test_0() {
   char c[5] = {'A','l','i','c','e'};
   CharLinkedList list = CharLinkedList(c,5);
   assert(list.toString()  == "[CharLinkedList of size 5 <<Alice>>]");
}

/* 
 * string test 1;
 * Make sure toString returns correct empty string
 */
void string_test_1() {
   CharLinkedList list;
   assert(list.toString()  == "[CharLinkedList of size 0 <<>>]");
}

/* 
 * reverse string test 0;
 * Make sure toReverseString returns correct value 
 */
void reverse_string_test_0() {
   char c[5] = {'A','l','i','c','e'};
   CharLinkedList list = CharLinkedList(c,5);
   assert(list.toReverseString() == "[CharLinkedList of size 5 <<ecilA>>]");
}

/* 
 * reverse string test 1;
 * Make sure toString returns correct empty string
 */
void reverse_string_test_1() {
   CharLinkedList list;
   assert(list.toReverseString() == "[CharLinkedList of size 0 <<>>]");
}

/* 
 * inserting into empty list
 * size should be 1 and element at index 0, make sure value is corrent
 */
void insertAt_test_0() { 
    CharLinkedList list;
    list.insertAt('a', 0);
    assert(list.size() == 1);
    assert(list.first() == 'a');

}

/* 
 * inserting into empty list with an out of range index 
 */
void insertAt_test_1() { 
    bool range_error_thrown = false;
    std::string error_message = "";
    CharLinkedList list;
    try { 
        list.insertAt('a', 42);
    } 
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0]");

}

/* 
 * inserting into the front of a list with 1 element 
 */
void insertAt_test_2() { 
    CharLinkedList list('a');

    list.insertAt('b', 0);

    assert(list.size() == 2);
    assert(list.elementAt(0) == 'b');
    assert(list.elementAt(1) == 'a');

}

/* 
 * inserting into the back of a list with 1 element 
 */
void insertAt_test_3() { 
    CharLinkedList list('a');

    list.insertAt('b', 1);

    assert(list.size() == 2);
    assert(list.elementAt(0) == 'a');
    assert(list.elementAt(1) == 'b');

}

/* 
 * inserting into the back of a list with 1 element
 */
void insertAt_test_4() {
    
    CharLinkedList list;
    for (int i = 0; i < 1000; i++) {
        // insert at the back of the list
        list.insertAt('a', i);
    }

    assert(list.size() == 1000);
    for (int i = 0; i < 1000; i++) {
        assert(list.elementAt(i) == 'a');
    }
    
}

/* 
 * inserting into the front of a list with many elements 
 */
void insertAt_test_5() {
    char arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList list(arr, 9);

    list.insertAt('y', 0);

    assert(list.size() == 10);
    assert(list.elementAt(0) == 'y');
    assert(list.toString() ==     
    "[CharLinkedList of size 10 <<yabczdefgh>>]");
}

/* 
 * inserting into the back of a list with many elements 
 */
void insertAt_test_6() {
    char arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList list(arr, 9);

    list.insertAt('y', 9);

    assert(list.size() == 10);
    assert(list.elementAt(9) == 'y');
    assert(list.toString() ==     
    "[CharLinkedList of size 10 <<abczdefghy>>]");
}

/* 
 * inserting into the middle of a list with many elements 
 */
void insertAt_test_7() {
    char arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList list(arr, 8);

    list.insertAt('z', 3);

    assert(list.size() == 9);
    assert(list.elementAt(3) == 'z');
    assert(list.toString() == "[CharLinkedList of size 9 <<abczdefgh>>]");
}

/* 
 * inserting at out of range on a list with many elements 
 */
void insertAt_test_8() {
   
    char arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList list(arr, 8);

    bool range_error_thrown = false;
    std::string error_message = "";

    try {
        list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8]");
}

/* 
 * removeAt test 0 
 * Make sure we can't remove on an empty list
 */
void removeAt_test_0() { 
    bool range_error_thrown = false;
    std::string error_message = "";
    CharLinkedList list;
    try { 
        list.removeAt(0);
    } 
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (0) not in range [0..0)");
}

/* 
 * removing from empty list with an out of range index
 * should result in an std::range_error being raised.
 */
void removeAt_test_1() {

    bool range_error = false;

    std::string error_message = "";

    CharLinkedList list;
    try {
        list.removeAt(42);
    }
    catch (const std::range_error &e) {
        range_error = true;
        error_message = e.what();
    }
    assert(range_error);
    assert(error_message == "index (42) not in range [0..0)");
    
}

/* 
 * removing from a list with 1 element
 */
void removeAt_test_2() {  
    CharLinkedList list('a');
    list.removeAt(0);

    assert(list.size() == 0);
}


/* 
 * removing from the back of a list withmany elements 
 */
void removeAt_test_3() {
    
    CharLinkedList list;
    for (int i = 0; i < 1000; i++) {
        // insert at the back of the list
        list.insertAt('a', i);
    }
    assert(list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        list.removeAt(999 - i);
    }

    assert(list.size() == 0);
    
}

/* 
 * removing from the front of a list with many elements 
 */
void removeAt_test_4() {
    char arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList list(arr, 9);

    list.removeAt(0);

    assert(list.size() == 8);
    assert(list.elementAt(0) == 'b');
    assert(list.toString() ==     
    "[CharLinkedList of size 8 <<bczdefgh>>]");
}

/* 
 * removing from the back of a list with many elements 
 */
void removeAt_test_5() {
    char arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList list(arr, 9);

    list.removeAt(8);

    assert(list.size() == 8);
    assert(list.last() == 'g');
    assert(list.toString() ==     
    "[CharLinkedList of size 8 <<abczdefg>>]");
}

/* 
 * removing from the middle of a list with many elements 
 */
void removeAt_test_6() {
    char arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList list(arr, 8);

    list.removeAt(3);

    assert(list.size() == 7);
    assert(list.elementAt(3) == 'e');
    assert(list.toString() == "[CharLinkedList of size 7 <<abcefgh>>]");
}

/* 
 * removing from out of range on a list with many elements 
 */
void removeAt_test_7() {
   
    char arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList list(arr, 8);

    bool range_error_thrown = false;
    std::string error_message = "";

    try {
        list.removeAt(42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8)");
}

/* 
 * removing from the front of a list with many elements
 */
void removeAt_test_8() {
    
    CharLinkedList list;
    for (int i = 0; i < 1000; i++) {
        // insert at the back of the list
        list.insertAt('a', i);
    }
    assert(list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        list.removeAt(0);
    }

    assert(list.size() == 0);
    
}

/* 
 * push at back test 0;
 * Make sure pushAtBack can place an element at the end
 * of an empty list and a list with more than one element
 */
void push_at_back_test_0() {
   CharLinkedList list;
   list.pushAtBack('a');
   assert(list.last() == 'a');
   assert(list.size() == 1);
   list.pushAtBack('b');
   assert(list.last() == 'b' and list.first() == 'a');
   assert(list.size() == 2);
}

/* 
 * push at back test 1;
 * Make sure pushAtBack canpush many elements 
 */
void push_at_back_test_1() {
   CharLinkedList list;
   for (int i = 0; i < 1000; i++) {
        list.pushAtBack('a');
    }

    assert(list.size() == 1000);
    for (int i = 0; i < 1000; i++) {
        assert(list.elementAt(i) == 'a');
    }
    list.pushAtBack('c');
    assert(list.elementAt(1000) == 'c');
}

/* 
 * push at front test 0;
 * Make sure pushAtFront can place an element at the front of
 * a list correctly of an empty list and a list with more 
 * than one element
 */
void push_at_front_test_0() {
   CharLinkedList list;
   list.pushAtFront('a');
   assert(list.first() == 'a');
   assert(list.size() == 1);
   list.pushAtFront('b');
   assert(list.first() == 'b' and list.last() == 'a');
   assert(list.size() == 2);
}

/* 
 * push at front test 1;
 * Make sure pushAtFront can push many elements 
 */
void push_at_front_test_1() {
   CharLinkedList list;
   for (int i = 0; i < 1000; i++) {
        list.pushAtFront('a');
    }

    assert(list.size() == 1000);
    for (int i = 0; i < 1000; i++) {
        assert(list.elementAt(i) == 'a');
    }
    list.pushAtFront('c');
    assert(list.elementAt(0) == 'c');
}

/* 
 * insertInOrder empty test
 * Make sure insertInOrder can correctly insert a char into 
 * an empty list 
 */
void insertInOrder_test_0() { 
    CharLinkedList list;
    list.insertInOrder('a');
    assert(list.size() == 1);
    assert(list.elementAt(0) == 'a');
}

/* 
 * insertInOrder single char list
 * Make sure insertInOrder can correctly insert a char into 
 * a list with one char 
 */
void insertInOrder_test_1() {
    CharLinkedList list('a');
    list.insertInOrder('b');

    assert(list.size() == 2);
    assert(list.elementAt(1) == 'b');
    assert(list.elementAt(0) == 'a');
}

/* 
 * insertInOrder first
 * Make sure insertInOrder can correctly insert a char into 
 * the beginning of a list 
 */
void insertInOrder_test_2() {
    char c[4] = {'b','c','d','e'};
    CharLinkedList list = CharLinkedList(c,4);

    list.insertInOrder('a');

    assert(list.size() == 5);
    assert(list.toString() == "[CharLinkedList of size 5 <<abcde>>]");
    
}

/* 
 * insertInOrder middle
 * Make sure insertInOrder can correctly insert a char into 
 * the middle of list
 */
void insertInOrder_test_3() {
    char c[4] = {'a','b','d','e'};
    CharLinkedList list = CharLinkedList(c,4);

    list.insertInOrder('c');

    assert(list.size() == 5);
    assert(list.toString() == "[CharLinkedList of size 5 <<abcde>>]");
    
}

/* 
 * insertInOrder middle repeat
 * Make sure insertInOrder can correctly insert a char into 
 * the middle of list with a char of the same value already in list
 */
void insertInOrder_test_4() {
    char c[5] = {'a','b','c','d','e'};
    CharLinkedList list = CharLinkedList(c,5);

    list.insertInOrder('c');

    assert(list.size() == 6);
    assert(list.toString() == "[CharLinkedList of size 6 <<abccde>>]");
    
}

/* 
 * insertInOrder last
 * Make sure insertInOrder can correctly insert a char into 
 * the end of list
 */
void insertInOrder_test_5() {
    char c[4] = {'a','b','c','d'};
    CharLinkedList list = CharLinkedList(c,4);

    list.insertInOrder('e');

    assert(list.size() == 5);
    assert(list.toString() == "[CharLinkedList of size 5 <<abcde>>]");
    
}

/* 
 * insertInOrder last repeat
 * Make sure insertInOrder can correctly insert a char into 
 * the end of list with a char of the same value already in list
 */
void insertInOrder_test_6() {
    char c[5] = {'a','b','c','d','e'};
    CharLinkedList list = CharLinkedList(c,5);

    list.insertInOrder('e');

    assert(list.size() == 6);
    assert(list.toString() == "[CharLinkedList of size 6 <<abcdee>>]");
    
}

/* 
 * popFromBack test 0;
 * Make sure the list decrements by one element
 */
void popFromBack_test_0() {
   char c[5] = {'a','b','c','d','e'};
   CharLinkedList list = CharLinkedList(c,5);
   list.popFromBack();
   assert(list.size() == 4);
   assert(list.toString() == "[CharLinkedList of size 4 <<abcd>>]");
}

/* 
 * popFromBack test 1;
 * Make sure we can't pop on an access empty list
 */
void popFromBack_test_1() {
    CharLinkedList list;
    bool runtime_error_thrown = false;
    std::string error_message = "";

    try { 
        list.popFromBack();
    } 
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
   
}

/* 
 * popFromFront test 0;
 * Make sure the list decrements by one element
 */
void popFromFront_test_0() {
   char c[5] = {'a','b','c','d','e'};
   CharLinkedList list = CharLinkedList(c,5);
   list.popFromFront();
   assert(list.size() == 4);
   assert(list.toString() == "[CharLinkedList of size 4 <<bcde>>]");
}

/* 
 * popFromFront test 1;
 * Make sure we can't pop on an access empty list
 */
void popFromFront_test_1() {
    CharLinkedList list;
    bool runtime_error_thrown = false;
    std::string error_message = "";

    try { 
        list.popFromFront();
    } 
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
   
}

/* 
 * replaceAt test 0 
 * Make sure we can't replace on an empty list
 */
void replaceAt_test_0() { 
    bool range_error_thrown = false;
    std::string error_message = "";
    CharLinkedList list;
    try { 
        list.replaceAt('x', 0);
    } 
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (0) not in range [0..0)");
}

/* 
 * replacing from empty list with an out of range index
 * should result in an std::range_error being raised.
 */
void replaceAt_test_1() {

    bool range_error = false;

    std::string error_message = "";

    CharLinkedList list;
    try {
        list.replaceAt( 'x', 42);
    }
    catch (const std::range_error &e) {
        range_error = true;
        error_message = e.what();
    }
    assert(range_error);
    assert(error_message == "index (42) not in range [0..0)");
    
}

/* 
 * replacing from a list with 1 element
 */
void replaceAt_test_2() {  
    CharLinkedList list('a');
    list.replaceAt('b',0);

    assert(list.size() == 1);
    assert(list.elementAt(0) == 'b');
}


/* 
 * replacing many elements
 */
void replaceAt_test_3() {
    
    CharLinkedList list;
    for (int i = 0; i < 1000; i++) {
        // insert at the back of the list
        list.insertAt('a', i);
    }
    assert(list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        list.replaceAt('b', i);
    }

    assert(list.size() == 1000);
    for (int i = 0; i < 1000; i++) {
        assert(list.elementAt(i) == 'b');
    }
    
}

/* 
 * replacing at the front of a list with many elements 
 */
void replaceAt_test_4() {
    char arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList list(arr, 9);

    list.replaceAt('x', 0);

    assert(list.size() == 9);
    assert(list.toString() ==     
    "[CharLinkedList of size 9 <<xbczdefgh>>]");
}

/* 
 * replacing from the back of a list with many elements 
 */
void replaceAt_test_5() {
    char arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList list(arr, 9);

    list.replaceAt('x', 8);

    assert(list.size() == 9);
    assert(list.toString() ==     
    "[CharLinkedList of size 9 <<abczdefgx>>]");
}

/* 
 * replacing at the middle of a list with many elements 
 */
void replaceAt_test_6() {
    char arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList list(arr, 8);

    list.replaceAt('x', 3);

    assert(list.size() == 8);
    assert(list.toString() == "[CharLinkedList of size 8 <<abcxefgh>>]");
}

/* 
 * replacing at out of range on a list with many elements 
 */
void replaceAt_test_7() {
   
    char arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList list(arr, 8);

    bool range_error_thrown = false;
    std::string error_message = "";

    try {
        list.replaceAt('x', 42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8)");
}

/* 
 * replacing at the end of a list with many elements
 */
void replaceAt_test_8() {
    
    CharLinkedList list;
    for (int i = 0; i < 1000; i++) {
        list.insertAt('a', i);
    }
    assert(list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        list.replaceAt('b', 999 - i);
    }

    assert(list.size() == 1000);
    for (int i = 0; i < 1000; i++) {
        assert(list.elementAt(i) == 'b');
    }
    
}

/*
 * concatenate test 0
 * Make sure the function knows how to concatenate an empty lists 
 */
void contatenate_test_0() {
    CharLinkedList list1;
    CharLinkedList list2; 

    list1.concatenate(&list2);

    assert(list1.size() == 0);
    assert(list1.toString()  == "[CharLinkedList of size 0 <<>>]");

}

/*
 * concatenate test 1
 * Make sure the function concatenates two lists correctly 
 */
void contatenate_test_1() {
    char arr1[3] = {'c','a','t'};
    char arr2[5] = {'k', 'i', 't', 't', 'y'};
    CharLinkedList list1 = CharLinkedList(arr1, 3);
    CharLinkedList list2 = CharLinkedList(arr2, 5);

    list1.concatenate(&list2);

    assert(list1.size() == 8);
    assert(list1.toString()  == 
    "[CharLinkedList of size 8 <<catkitty>>]");
}

/*
 * concatenate test 2
 * Make sure the function concatenates two lists correctly 
 */
void contatenate_test_2() {
    char arr1[3] = {'c','a','t'};
    CharLinkedList list1 = CharLinkedList(arr1, 3);

    list1.concatenate(&list1);


    assert(list1.size() == 6);
    assert(list1.toString()  == 
    "[CharLinkedList of size 6 <<catcat>>]");

}

/*
 * concatenate test 3
 * Make sure the function concatenates an empty list
 * correctly onto a non empty list
 */
void contatenate_test_3() {
    char arr1[3] = {'c','a','t'};
    CharLinkedList list1 = CharLinkedList(arr1, 3);
    CharLinkedList list2; 

    list1.concatenate(&list2);


    assert(list1.size() == 3);
    assert(list1.toString()  == 
    "[CharLinkedList of size 3 <<cat>>]");

}

/*
 * concatenate test 4
 * Make sure the function concatenates a non empty list 
 * correctly onto an empty list 
 */
void contatenate_test_4() {
    char arr1[3] = {'c','a','t'};
    CharLinkedList list1 = CharLinkedList(arr1, 3);
    CharLinkedList list2; 

    list2.concatenate(&list1);


    assert(list2.size() == 3);
    assert(list2.toString()  == 
    "[CharLinkedList of size 3 <<cat>>]");

}



 
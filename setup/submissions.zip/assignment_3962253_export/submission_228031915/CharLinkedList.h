/*
 *  CharLinkedList.h
 *  Angela Huynh (ahuynh02)
 *  1/30/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Interface/header file for CharLinkedList a class which contains 
 *  declarations of basic functions for a list with chars as elements. 
 *  Clients can create an empty list, a list from a single char, a list 
 *  from an array with its size, and a list fron another CharLinkedList.
 *  Contains basic functions of lists including 
 *  finding/removing/inserting/replacing an element at an index, pop/pushing
 *  elements at front and back, clearing, and stringing the list. 
 *  Clients can also get a string of the reverse list, and concatenate two 
 *  lists together. 
 *
 */

#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H

#include <string>
#include <sstream>
#include <iostream>
#include <stdexcept>

class CharLinkedList {
    public: 
    CharLinkedList();
    CharLinkedList(char c);
    CharLinkedList(char arr[], int size);
    CharLinkedList(const CharLinkedList &other);
    ~CharLinkedList();
    CharLinkedList &operator=(const CharLinkedList &other);

    bool isEmpty() const;
    void clear();
    int size() const;
    char first() const;
    char last() const;
    char elementAt(int index) const;
    std::string toString() const;
    std::string toReverseString() const;
    void pushAtBack(char c);
    void pushAtFront(char c);
    void insertAt(char c, int index);
    void insertInOrder(char c);
    void popFromFront();
    void popFromBack();
    void removeAt(int index);
    void replaceAt(char c, int index);
    void concatenate(CharLinkedList *other);

    private:

    struct Node {
        char info;
        Node* next;
        Node* prev;

        Node(char c, Node* nextNode, Node* prevNode){
            info = c;
            next = nextNode;
            prev = prevNode;
        }
    };

    int numItems;
    Node* head;
    Node* tail;

    void removeAll(Node* current) const;
    Node* getNode(int index, Node* current) const;


};

#endif

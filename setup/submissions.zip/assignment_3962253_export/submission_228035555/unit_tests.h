/*
 *  unit_tests.h
 *  Anand Jaureguilorda
 *  2/1/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  Test the implementation of CharLinkedList.
 *
 */

#include "CharLinkedList.h"
#include <cassert>

void dummyTest() {}

void constructorTest() {
    CharLinkedList list;
}

void constructor2Test() {
    CharLinkedList list('a');
    assert(list.size() == 1);
}

void constructor3Test() {
    char test_array[3] = { 'a', 'b', 'c' };
    CharLinkedList list(test_array, 3);

    assert(list.size() == 3);
    assert(list.elementAt(0) == 'a');
    assert(list.elementAt(1) == 'b');
    assert(list.elementAt(2) == 'c');
}

// Test the functionality of isEmpty
void isEmpty_test() {
    CharLinkedList list;
    assert(list.isEmpty());
}

// Test the functionality of clear
void clear_test() {
    char test_array[3] = { 'a', 'b', 'c' };
    CharLinkedList list(test_array, 3);

    list.clear();
    assert(list.isEmpty());
}

// Test clearing an empty list
void clear_test2() {
    CharLinkedList list;
    list.clear();

    assert(list.isEmpty());
}

// Test the functionality of size
void size_test() {
    char test_array[3] = { 'a', 'b', 'c' };
    CharLinkedList list(test_array, 3);
    
    assert(list.size() == 3); 
}

// Test the functionality of first
void first_test() {
    char test_array[3] = { 'a', 'b', 'c' };
    CharLinkedList list(test_array, 3);
    assert(list.first() == 'a');

    // Test that a runtime_error is thrown for an empty list
    CharLinkedList list2;
    try {
        char e = list2.first();
    } catch (const std::runtime_error &o) {
        std::string error_message = o.what();
        assert(error_message == "cannot get first of empty LinkedList");
    }
}

// Test the functionality of last
void last_test() {
    char test_array[3] = { 'a', 'b', 'c' };
    CharLinkedList list(test_array, 3);
    assert(list.last() == 'c');

    // Test that a runtime_error is thrown for an empty list
    CharLinkedList list2;
    try {
        char e = list2.last();
    } catch (const std::runtime_error &o) {
        std::string error_message = o.what();
        assert(error_message == "cannot get last of empty LinkedList");
    }
}

// Test the functionality of elementAt
void elementAt_test() {
    CharLinkedList list('a');
    assert(list.elementAt(0) == 'a');

    char test_arr[6] = "ATZBC";
    CharLinkedList list2(test_arr, 5);
    assert(list2.elementAt(2) == 'Z');
}

// Test that a range_error is thrown at index == size
void elementAt_test2() {
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList list(test_arr, 9);

    try {
        char e = list.elementAt(9); 
    } catch (const std::range_error &o) {
        std::string error_message = o.what();
        assert(error_message == "index (9) not in range [0..9)");
    }
}

// Test the functionality of toString
void toString_test() {
    char test_array[3] = { 'a', 'b', 'c' };
    CharLinkedList list(test_array, 3);
    assert(list.toString() == "[CharLinkedList of size 3 <<abc>>]");

    // Test printing an empty list
    CharLinkedList list2;
    assert(list2.toString() == "[CharLinkedList of size 0 <<>>]");
}

// Test the functionality of toReverseString
void toReverseString_test() {
    char test_array[3] = { 'a', 'b', 'c' };
    CharLinkedList list(test_array, 3);
    assert(list.toReverseString() == "[CharLinkedList of size 3 <<cba>>]");

    // Test reverse printing an empty list
    CharLinkedList list2;
    assert(list2.toReverseString() == "[CharLinkedList of size 0 <<>>]");
}

// Test the functionality of pushAtBack
void pushAtBack_test() {
    char test_array[3] = { 'a', 'b', 'c' };
    CharLinkedList list(test_array, 3);
    list.pushAtBack('d');
    assert(list.last() == 'd');
    assert(list.size() == 4);
    assert(list.toString() == "[CharLinkedList of size 4 <<abcd>>]");

    // Test pushing at back an empty list
    CharLinkedList list2;
    list2.pushAtBack('a');
    assert(list2.size() == 1);
    assert(list2.first() == 'a');
}

// Test the functionality of pushAtFront
void pushAtFront_test() {
    char test_array[3] = { 'a', 'b', 'c' };
    CharLinkedList list(test_array, 3);
    list.pushAtFront('d');
    assert(list.first() == 'd');
    assert(list.size() == 4);
    assert(list.toString() == "[CharLinkedList of size 4 <<dabc>>]");

    // Test pushing at front an empty list
    CharLinkedList list2;
    list2.pushAtFront('a');
    assert(list2.size() == 1);
    assert(list2.first() == 'a');
}

// Test the functionality of insertAt
void insertAt_test() {
    char test_array[3] = { 'a', 'b', 'c' };
    CharLinkedList list(test_array, 3);

    list.insertAt('x', 0);
    assert(list.toString() == "[CharLinkedList of size 4 <<xabc>>]");
    list.insertAt('z', 4);
    assert(list.toString() == "[CharLinkedList of size 5 <<xabcz>>]");
    list.insertAt('k', 2);
    assert(list.toString() == "[CharLinkedList of size 6 <<xakbcz>>]");
}

// Test that range_error is thrown at index of (size + 1)
void insertAt_test2() {
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList list(test_arr, 9);

    try {
        list.insertAt('p', 10);
    } catch (const std::range_error &o) {
        std::string error_message = o.what();
        assert(error_message == "index (10) not in range [0..9]");
    }
}

// Test insertAt with an empty list
void insertAt_test3() {
    CharLinkedList list;

    list.insertAt('x', 0);
    assert(list.first() == 'x');
    assert(list.last() == 'x');
    assert(list.size() == 1);
}

// Test the functionality of insertInOrder
void insertInOrder_test() {
    char test_arr[5] = "ABCD";
    CharLinkedList list(test_arr, 4);

    list.insertInOrder('C');
    assert(list.toString() == "[CharLinkedList of size 5 <<ABCCD>>]");

    char test2_arr[6] = "ATZBC";
    CharLinkedList list2(test2_arr, 5);

    list2.insertInOrder('V');
    assert(list2.toString() == "[CharLinkedList of size 6 <<ATVZBC>>]");
}

// Test if insert in order works correctly
void insertInOrder_test2() {
    char test_arr[5] = "ABCD";
    CharLinkedList list(test_arr, 4);

    list.insertInOrder('X');
    assert(list.toString() == "[CharLinkedList of size 5 <<ABCDX>>]");

    char test2_arr[6] = "ATZBC";
    CharLinkedList list2(test2_arr, 5);

    list2.insertInOrder('A');
    assert(list2.toString() == "[CharLinkedList of size 6 <<AATZBC>>]");
}

// Test inserting an order with a number and other letters
void insertInOrder_test3() {
    char test_arr[3] = { '6', 'a', 'z' };
    CharLinkedList list(test_arr, 3);

    list.insertInOrder('B');
    assert(list.toString() == "[CharLinkedList of size 4 <<6Baz>>]");
}

// Test the functionality of popFromFront
void popFromFront_test() {
    char test_array[3] = { 'a', 'b', 'c' };
    CharLinkedList list(test_array, 3);
    
    list.popFromFront();
    assert(list.toString() == "[CharLinkedList of size 2 <<bc>>]");    

    // Test with empty list
    CharLinkedList list2;
    try {
        list2.popFromFront();
    } catch (const std::runtime_error &o) {
        std::string error_message = o.what();
        assert(error_message == "cannot pop from empty LinkedList");
    }
}

// Test the functionality of popFromBack
void popFromBack_test() {
    char test_array[3] = { 'a', 'b', 'c' };
    CharLinkedList list(test_array, 3);
    
    list.popFromBack();
    assert(list.toString() == "[CharLinkedList of size 2 <<ab>>]");

    // Test with empty list
    CharLinkedList list2;
    try {
        list2.popFromBack();
    } catch (const std::runtime_error &o) {
        std::string error_message = o.what();
        assert(error_message == "cannot pop from empty LinkedList");
    }
}

// Test the correct element is removed and the other elements shift correctly
void removeAt_test() {
    char test_arr[6] = "ATZBC";
    CharLinkedList list(test_arr, 5);

    list.removeAt(2);
    assert(list.toString() == "[CharLinkedList of size 4 <<ATBC>>]");

    // Test that a range_error is correctly thrown if index is out of bounds
    CharLinkedList list2;
    try {
        list2.removeAt(0);    
    } catch (const std::range_error &o) {
        std::string error_message = o.what();
        assert(error_message == "index (0) not in range [0..0)");
    }
}

// Test if the correct elements are replaced and with the correct value
void replaceAt_test() {
    char test_arr[6] = "ATZBC";
    CharLinkedList list(test_arr, 5);

    list.replaceAt('a', 0);
    assert(list.toString() == "[CharLinkedList of size 5 <<aTZBC>>]");
}

// Test concatenate with two filled CharLinkedList
void concatenate_test() {
    char test_arr[5] = "ABCD";
    char test2_arr[6] = "ATZBC";
    CharLinkedList list(test_arr, 4);
    CharLinkedList list2(test2_arr, 5);

    list.concatenate(&list2);

    assert(list.toString() == "[CharLinkedList of size 9 <<ABCDATZBC>>]");
}

// Test concatenate on an empty CharLinkedList
void concatenate_test2() {
    CharLinkedList list;
    CharLinkedList list2('a');

    list.concatenate(&list2);

    assert(list.toString() == "[CharLinkedList of size 1 <<a>>]");
}

// Test concatenate with itself
void concatenate_test3() {
    char test_arr[2] = { 'a', 'b'};
    CharLinkedList list(test_arr, 2);

    assert(list.size() == 2);
    list.concatenate(&list);

    assert(list.toString() == "[CharLinkedList of size 4 <<abab>>]");
}

// Test that a CharLinkedList has the same contents from what it was copied from
void copyConstructor_test() {
    char test_arr[5] = "ABCD";
    CharLinkedList list(test_arr, 4);
    CharLinkedList list2(list);              // calls copy constructor

    assert(list2.toString() == "[CharLinkedList of size 4 <<ABCD>>]");
    assert(list2.size() == 4);              
}

// Test if list2 correctly is reassigned to list's values
void assignmentOperator_test() {
    char test_arr[5] = "ABCD";
    char test2_arr[6] = "ATZBC";
    CharLinkedList list(test_arr, 4);
    CharLinkedList list2(test2_arr, 5);

    list2 = list;

    assert(list2.toString() == "[CharLinkedList of size 4 <<ABCD>>]");
}

// Test assignment operator on an empty list
void assignmentOperator_test2() {
    CharLinkedList list;
    CharLinkedList list2('a');

    list2 = list;
    assert(list.isEmpty());
    assert(list2.isEmpty());
}
/*
 *  CharLinkedList.h
 *  Anand Jaureguilorda
 *  2/1/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  CharLinkedList is a class that represents a dynamically created list of 
 *  linked struct objects with included methods to manipulate the stored data
 *
 */

#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H

#include <string>

class CharLinkedList {
public:

    // constructors and destructor
    CharLinkedList();
    CharLinkedList(char c);
    CharLinkedList(char arr[], int size);
    CharLinkedList(const CharLinkedList &other);
    ~CharLinkedList();

    // assignment operator
    CharLinkedList &operator=(const CharLinkedList &other);

    // public methods
    bool isEmpty() const;
    void clear();
    int size() const;
    char first() const;
    char last() const;
    char elementAt(int index) const;
    std::string toString() const;
    std::string toReverseString() const;
    void pushAtBack(char c);
    void pushAtFront(char c);
    void insertAt(char c, int index);
    void insertInOrder(char c);
    void popFromFront();
    void popFromBack();
    void removeAt(int index);
    void replaceAt(char c, int index);
    void concatenate(CharLinkedList *other);

private:

    // each element in the list is a struct
    struct Node {
        char element;
        Node *next;
        Node *behind;
    };

    int Lsize;

    // pointers to first and last elements
    Node *front;
    Node *back;

    // private helper methods
    char elementAtHelper(int index, Node *curr) const;
    void insertAtHelper(Node *curr, char c);
    void removeAtHelper(Node *curr);
    Node *nodeFinder(int index, Node *curr);
    void destructorHelper(Node *curr);
};

#endif

/*
 *  CharLinkedList.cpp
 *  Anand Jaureguilorda
 *  2/1/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  This file contains an implementation of the CharLinkedList class.
 *
 */

#include "CharLinkedList.h"
#include <iostream>
#include <string>
#include <sstream>

using namespace std;

/*
 * name:      CharLinkedList default constructor
 * purpose:   initialize an empty CharLinkedList
 * arguments: none
 * returns:   none
 * effects:   size to 0, front and back pointers assigned to nullptr
 */
CharLinkedList::CharLinkedList() {
    Lsize = 0;
    front = nullptr;
    back = nullptr;
}

/*
 * name:      CharLinkedList one-element constructor
 * purpose:   initialize a one-element CharLinkedList
 * arguments: the element being added to CharLinkedList
 * returns:   none
 * effects:   size to 1, front and back pointers assigned to Node on the heap
 */
CharLinkedList::CharLinkedList(char c) {
    Node *newNode = new Node;
    newNode->element = c;
    newNode->next = nullptr;
    newNode->behind = nullptr;

    front = newNode;
    back = newNode;

    Lsize = 1;
}

/*
 * name:      CharLinkedList array constuctor
 * purpose:   initialize a CharLinkedList array with a mulitple-element array
 * arguments: the character array being initialized and the size of the array
 * returns:   none
 * effects:   size defined, front & back pointers assinged to Nodes on the heap
 */
CharLinkedList::CharLinkedList(char arr[], int size) {
    Lsize = size;

    Node *newNode = new Node;
    newNode->element = arr[0];
    newNode->next = nullptr;
    newNode->behind = nullptr;
    front = newNode;
    back = newNode;

    if (size > 1) {
        for (int i = 1; i < size; i++) {
            Node *newestNode = new Node;
            newestNode->element = arr[i];
            newestNode->next = nullptr;
            newestNode->behind = newNode;
            newNode->next = newestNode;
            back = newestNode;
            newNode = newestNode;
        }
    }
}

/*
 * name:      CharLinkedList copy constructor
 * purpose:   initialize a copied CharLinkedList
 * arguments: an object of the CharLinkedList class
 * returns:   none
 * effects:   size defined, front & back pointers assinged to Nodes on the heap
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other) {
    Lsize = other.size();

    Node *newNode = new Node;
    newNode->element = other.first();
    newNode->next = nullptr;
    newNode->behind = nullptr;
    front = newNode;
    back = newNode;

    if (Lsize > 1) {
        for (int i = 1; i < Lsize; i++) {
            Node *newestNode = new Node;
            newestNode->element = other.elementAt(i);
            newestNode->next = nullptr;
            newestNode->behind = newNode;
            newNode->next = newestNode;
            back = newestNode;
            newNode = newestNode;
        }
    }
}

/*
 * name:      CharLinkedList destructor
 * purpose:   delete the memory that was allocated on the heap for the Nodes
 * arguments: none
 * returns:   none
 * effects:   cleans up the memory associated with an object of CharLinkedList
 */
CharLinkedList::~CharLinkedList() {
    destructorHelper(front);
}

/*
 * name:      Assignment Operator
 * purpose:   Copies one object's contents into this object
 * arguments: another object of CharLinkedList
 * returns:   the address of an object of a CharLinkedList
 * effects:   Updated size of list and new Nodes in the list
 */
CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other) {
    destructorHelper(front);
    Lsize = other.size();

    if (Lsize != 0) {
        Node *newNode = new Node;
        newNode->element = other.first();
        newNode->next = nullptr;
        newNode->behind = nullptr;
        front = newNode;
        back = newNode;

        if (Lsize > 1) {
            for (int i = 1; i < Lsize; i++) {
                Node *newestNode = new Node;
                newestNode->element = other.elementAt(i);
                newestNode->next = nullptr;
                newestNode->behind = newNode;
                newNode->next = newestNode;
                back = newestNode;
                newNode = newestNode;
            }
        }
    } else {
        front = nullptr;
        back = nullptr;
    }

    return *this;
}

/*
 * name:      isEmpty
 * purpose:   determines whether the list is empty or not
 * arguments: none
 * returns:   a true or false statement 
 * effects:   none
 */
bool CharLinkedList::isEmpty() const {
    return Lsize == 0;
}

/*
 * name:      clear
 * purpose:   clears the elements in the list
 * arguments: none
 * returns:   none
 * effects:   sets size equal to zero
 */
void CharLinkedList::clear() {
    Lsize = 0;
}

/*
 * name:      size
 * purpose:   find and return the size of the list
 * arguments: none
 * returns:   the size of the list
 * effects:   none
 */
int CharLinkedList::size() const {
    return Lsize;
}

/*
 * name:      first
 * purpose:   find and return the first element in the list
 * arguments: none
 * returns:   the first element in the list
 * effects:   none
 */
char CharLinkedList::first() const {
    if (isEmpty()) {
        throw runtime_error("cannot get first of empty LinkedList");
    }
    
    return front->element;
}

/*
 * name:      last
 * purpose:   find and return the last element in the list
 * arguments: none
 * returns:   the last element in the list
 * effects:   none
 */
char CharLinkedList::last() const {
    if (isEmpty()) {
        throw runtime_error("cannot get last of empty LinkedList");
    }

    return back->element;
}

/*
 * name:      elementAt
 * purpose:   retreive an element in the list
 * arguments: the index of the element being retreived
 * returns:   the element at the list
 * effects:   none
 */
char CharLinkedList::elementAt(int index) const {
    if (index < 0 or index >= Lsize) {
        throw range_error("index (" + std::to_string(index) + 
        ") not in range [0.." + std::to_string(Lsize) + ")");
    }
    
    return elementAtHelper(index, front);
}

/*
 * name:      toString
 * purpose:   print out the contents of the list
 * arguments: none
 * returns:   a string statement with the size and contents of the list
 * effects:   none
 */
std::string CharLinkedList::toString() const {
    std::stringstream ss;

    ss << "[CharLinkedList of size " << Lsize << " <<";
    
    Node *curr = front;
    if (Lsize != 0) {
        for (int i = 0; i < Lsize; i++) {
            ss << curr->element;
            curr = curr->next;
        }
    }

    ss << ">>]";

    return ss.str();
}

/*
 * name:      toReverseString
 * purpose:   print out the contents of the list in reverse
 * arguments: none
 * returns:   a string with the size and contents of the list in reverse
 * effects:   none
 */
std::string CharLinkedList::toReverseString() const {
    std::stringstream ss;

    ss << "[CharLinkedList of size " << Lsize << " <<";
    
    Node *curr = back;
    if (Lsize != 0) {
        for (int i = 0; i < Lsize; i++) {
            ss << curr->element;
            curr = curr->behind;
        }
    }

    ss << ">>]";

    return ss.str();
}

/*
 * name:      pushAtBack
 * purpose:   add an element to the end of the list
 * arguments: the element being added to CharLinkedist
 * returns:   none
 * effects:   increase the size of the list and add an element as a new Node
 */
void CharLinkedList::pushAtBack(char c) {
    Node *newNode = new Node;
    newNode->element = c;
    newNode->next = nullptr;
    
    // if list is empty, initialize front pointer
    if (Lsize == 0) {
        newNode->behind = nullptr;
        front = newNode;
    } else {
        newNode->behind = back;
        back->next = newNode;
    }

    back = newNode;
    Lsize++;
}

/*
 * name:      pushAtFront
 * purpose:   add an element to the front of an list
 * arguments: the element being added to CharLinkedList
 * returns:   none
 * effects:   increase the size of the list and add an element as a new Node
 */
void CharLinkedList::pushAtFront(char c) {
    Node *newNode = new Node;
    newNode->element = c;
    newNode->behind = nullptr;

    // if list is empty, initialize back pointer
    if (Lsize == 0) {
        newNode->next = nullptr;
        back = newNode;
    } else {
        newNode->next = front;
        front->behind = newNode;
    }

    front = newNode;
    Lsize++;
}

/*
 * name:      insertAt
 * purpose:   add an element to the list at a given index
 * arguments: the element being added to CharLinkedList and its new index 
 * returns:   none
 * effects:   increase the size of the list and add an element as a new Node
 */
void CharLinkedList::insertAt(char c, int index) {
    if (index < 0 or index > Lsize) {
        throw range_error("index (" + std::to_string(index) + 
        ") not in range [0.." + std::to_string(Lsize) + "]");
    }

    if (index == 0) {
        pushAtFront(c);
    } else if (index == Lsize) {
        pushAtBack(c);
    } else {
        Node *curr = nodeFinder(index, front);
        insertAtHelper(curr, c);
    }
}

/*
 * name:      insertInOrder
 * purpose:   insert an element into the list in order according to ASCII
 * arguments: the element being added to CharLinkedList
 * returns:   none
 * effects:   increase the size of the list and add an element as a new Node
 */
void CharLinkedList::insertInOrder(char c) {
    Node *curr = front;

    int i = 0;
    while (i < Lsize and c > curr->element) {
        curr = curr->next;
        i++;
    }
    int index = i;

    insertAt(c, index);
}

/*
 * name:      popFromFront
 * purpose:   remove the first element in the list
 * arguments: none
 * returns:   none
 * effects:   decreases size by 1
 */
void CharLinkedList::popFromFront() {
    if (isEmpty()) {
        throw runtime_error("cannot pop from empty LinkedList");
    }

    // if removing the only element, reset the list to an empty list
    if (Lsize == 1) {
        delete front;
        front = nullptr;
        back = nullptr;
    } else {
        front->next->behind = nullptr;
        Node *temp = front;
        front = front->next;
        delete temp;
    }

    Lsize--;
}

/*
 * name:      popFromBack
 * purpose:   remove the last element in the list
 * arguments: none
 * returns:   none
 * effects:   decreases size by 1
 */
void CharLinkedList::popFromBack() {
    if (isEmpty()) {
        throw runtime_error("cannot pop from empty LinkedList");
    }

    // if removing the only element, reset the list to an empty list
    if (Lsize == 1) {
        delete front;
        front = nullptr;
        back = nullptr;
    } else {
        back->behind->next = nullptr;
        Node *temp = back;
        back = back->behind;
        delete temp;
    }

    Lsize--;
}

/*
 * name:      removeAt
 * purpose:   removes an element in the list at a given index
 * arguments: the index of the element being removed from CharLinkedList
 * returns:   none
 * effects:   decreases size by 1 and shifts elements to the left
 */
void CharLinkedList::removeAt(int index) {
    if (index < 0 or index >= Lsize) {
        throw range_error("index (" + std::to_string(index) + 
        ") not in range [0.." + std::to_string(Lsize) + ")");
    }

    if (index == 0) {
        popFromFront();
    } else if (index == Lsize - 1) {
        popFromBack();
    } else {
        Node *curr = nodeFinder(index, front);
        removeAtHelper(curr);
    }
}

/*
 * name:      replaceAt
 * purpose:   replace an element at a given index with another element
 * arguments: the element being added to CharLinkedList and its new index
 * returns:   none
 * effects:   changes the value of one of the elements in the list
 */
void CharLinkedList::replaceAt(char c, int index) {
    if (index < 0 or index >= Lsize) {
        throw range_error("index (" + std::to_string(index) + 
        ") not in range [0.." + std::to_string(Lsize) + ")");
    }

    if (index == 0) {
        popFromFront();
        pushAtFront(c);
    } else if (index == Lsize - 1) {
        popFromBack();
        pushAtBack(c);
    } else {
        Node *curr = nodeFinder(index, front);
        removeAtHelper(curr);
    
        Node *temp = nodeFinder(index, front);
        insertAtHelper(temp, c);
    }
}

/*
 * name:      concatenate
 * purpose:   adds the elements of one CharLinkedList to the end of another
 * arguments: a pointer to an object in the CharLinkedList
 * returns:   none
 * effects:   increases the size of the list
 */
void CharLinkedList::concatenate(CharLinkedList *other) {
    int Osize = other->size();
     
    for (int i = 0; i < Osize; i++) {
        pushAtBack(other->elementAt(i));
    }
}

/*
 * name:      insertAtHelper
 * purpose:   adds an element into the list and shifts other elements right
 * arguments: a pointer to a Node within an object of CharLinkedList and the
 *            element being inserted
 * returns:   none
 * effects:   increase the size of the list and add an element as a new Node
 */
void CharLinkedList::insertAtHelper(Node *curr, char c) {
    Node *newNode = new Node;
    newNode->element = c;
    newNode->next = curr;
    newNode->behind = curr->behind;
    curr->behind->next = newNode;
    curr->behind = newNode;
    Lsize++;
}

/*
 * name:      removeAtHelper
 * purpose:   removes an element from the list and shifts other elements left
 * arguments: a pointer to a Node within an object of CharLinkedList 
 * returns:   none
 * effects:   decrease the size of the list
 */
void CharLinkedList::removeAtHelper(Node *curr) {
    curr->behind->next = curr->next;
    curr->next->behind = curr->behind;
    delete curr;
    Lsize--;
}

/*
 * name:      nodeFinder
 * purpose:   recursively identifies the Node at a given index 
 * arguments: the index of a desired Node and a pointer to the first Node 
 *            within an object in CharLinkedList 
 * returns:   a pointer to a Node within an object of CharLinkedList
 * effects:   none
 */
CharLinkedList::Node *CharLinkedList::nodeFinder(int index, Node *curr) {
    if (index == 0) {
        return curr;
    } else {
        return nodeFinder(index - 1, curr->next);
    }
}

/*
 * name:      elementAtHelper
 * purpose:   recursively identifies the element of a Node at a given index 
 * arguments: the index of a desired Node and a pointer to the first Node 
 *            within an object in CharLinkedList 
 * returns:   the element of a Node within an object of CharLinkedList
 * effects:   none
 */
char CharLinkedList::elementAtHelper(int index, Node *curr) const {
    if (index == 0) {  
        return curr->element;
    } else {
        return elementAtHelper(index - 1, curr->next);
    }
}

/*
 * name:      destructorHelper
 * purpose:   recursively deletes the Nodes of an object of CharLinkedList
 * arguments: a pointer to the first Node within an object in CharLinkedList 
 * returns:   none
 * effects:   deletes all memory allocated for the Nodes within an object
 */
void CharLinkedList::destructorHelper(Node *curr) {
    if (curr == nullptr) {
        return;
    } else {
        Node *next = curr->next;
        delete curr;
        destructorHelper(next);
    }
}

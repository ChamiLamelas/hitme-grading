/*
 *  unit_tests.h
 *  Sam Lev
 *  2/5/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  Purpose: implement unit tests to tet individual functions of the
 *           CharLinkedList class as it is being implemented for HW 2
 *
 */

 #include "CharLinkedList.h"
 #include <cassert>
 #include <iostream>

 using namespace std;

//make sure default constructor works at a basic level and is syntactically
//correct
void defaultConstructor() {
   CharLinkedList list;
}

//make sure default constructor initializes list to correct size and that
//size function works
void defaultConstructor_size() {
  CharLinkedList list;
  assert(list.size() == 0);
}

//make sure isEmpty() works on a new, empty list
void isEmpty() {
   CharLinkedList list;
   assert(list.isEmpty());
}

//test single-parameter constructor and newNode are syntactically correct.
//this also serves as the first test of the destructor. This test should pass
//valgrind.
void oneParameterConstructor_basic() {
    CharLinkedList list('v');
}

//check that single-parameter constructor works properly and that the elementAt
//function works in this simple case of accessing the only element of
//a non-empty LL. Testing elementAt also tests the helper function findNode.
//Also check that isEmpty returns false on a non-empty LL
void oneParameterConstructor_elementAt_isEmptyFalse() {
   CharLinkedList list('d');
   assert(list.size() == 1);
   assert(not list.isEmpty());
   assert(list.elementAt(0) == 'd');
}

//attempt to access one element past the end of the list
void elementAtTooHigh() {
   //variale to track errors thrown and error messages
   bool rangeErrorThrown = false;
   string errorMessage = "";

   CharLinkedList list('d');
   try {
      list.elementAt(1);
   }
   catch (const range_error &e) {
      rangeErrorThrown = true;
      errorMessage = e.what();
   }

   assert(rangeErrorThrown);
   assert(errorMessage == "index (1) not in range [0..1)");

}

//attempt to access a negative index
void elementAtTooLow() {
   bool rangeErrorThrown = false;
   string errorMessage = "";

   CharLinkedList list('d');
   try {
      list.elementAt(-1);
   }
   catch(const range_error &e) {
      rangeErrorThrown = true;
      errorMessage = e.what();
   }

   assert(rangeErrorThrown);
   assert(errorMessage == "index (-1) not in range [0..1)");
}

//attempt to access an element of an empty lsit
void elementAtEmptyPositive() {
   bool rangeErrorThrown = false;
   string errorMessage = "";

   CharLinkedList list;
   try {
      list.elementAt(1);
   }
   catch(const range_error &e) {
      rangeErrorThrown = true;
      errorMessage = e.what();
   }

   assert(rangeErrorThrown);
   assert(errorMessage == "index (1) not in range [0..0)");
}

//attempt to access a negative index of an empty list
void elementAtEmptyNegative() {
   bool rangeErrorThrown = false;
   string errorMessage = "";

   CharLinkedList list;
   try {
      list.elementAt(-1);
   }
   catch(const range_error &e) {
      rangeErrorThrown = true;
      errorMessage = e.what();
   }

   assert(rangeErrorThrown);
   assert(errorMessage == "index (-1) not in range [0..0)");
}

//attempt to access index 0 of an empty list
void elementAtEmptyZero() {
   bool rangeErrorThrown = false;
   string errorMessage = "";

   CharLinkedList list;
   try {
      list.elementAt(0);
   }
   catch(const range_error &e) {
      rangeErrorThrown = true;
      errorMessage = e.what();
   }

   assert(rangeErrorThrown);
   assert(errorMessage == "index (0) not in range [0..0)");
}

//check toString() on an empty list
void emptyToString() {
   CharLinkedList list;
   assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}

//test toString() on a one-element list
void oneElementToString() {
   CharLinkedList list('d');
   assert(list.toString() == "[CharLinkedList of size 1 <<d>>]");
}

//test toString on a larger list
void toString_large() {
   char arr[5] = {'A', 'l', 'i', 'c', 'e'};
   CharLinkedList list(arr, 5);

   assert(list.toString() == "[CharLinkedList of size 5 <<Alice>>]");
}

// Tests correct insertion into an empty LL.
// Afterwards, size should be 1 and element at index 0
// should be the element we inserted.
void insertAt_empty_correct() { 
   CharLinkedList list;
   list.insertAt('a', 0);
   assert(list.size() == 1);
   assert(list.elementAt(0) == 'a');
}

// Tests incorrect insertion into an empty LL.
// Attempts to call insertAt for index larger than 0.
// This should result in an std::range_error being raised.
void insertAt_empty_incorrect() {
   // var to track whether range_error is thrown
   bool range_error_thrown = false;

   // var to track any error messages raised
   string error_message = "";

   CharLinkedList list;
   try {
   // insertAt for out-of-range index
      list.insertAt('a', 42);
   }
   catch (const range_error &e) {
      // if insertAt is correctly implemented, a range_error will be thrown,
      // and we will end up here
      range_error_thrown = true;
      error_message = e.what();
   }

   // out here, we make our assertions
   assert(range_error_thrown);
   assert(error_message == "index (42) not in range [0..0]"); 
}

// Tests correct insertAt for front of 1-element list.
void insertAt_front_singleton_list() {
   // initialize 1-element list
   CharLinkedList test_list('a');

   // insert at front
   test_list.insertAt('b', 0);
   assert(test_list.size() == 2);
   assert(test_list.elementAt(0) == 'b');
   assert(test_list.elementAt(1) == 'a');  
}

// Tests correct insertAt for back of 1-element list.
void insertAt_back_singleton_list() {
   // initialize 1-element list
   CharLinkedList test_list('a');

   // insert at back
   test_list.insertAt('b', 1);

   assert(test_list.size() == 2);
   assert(test_list.elementAt(0) == 'a');
   assert(test_list.elementAt(1) == 'b');  
}

// Tests calling insertAt for a large number of elements.
void insertAt_many_elements() {
   CharLinkedList test_list;

   // insert 1000 elements
   for (int i = 0; i < 1000; i++) {
      // always insert at the back of the list
      test_list.insertAt('a', i);
   }

   assert(test_list.size() == 1000);

   for (int i = 0; i < 1000; i++) {
      assert(test_list.elementAt(i) == 'a');
   }
}

//push at back of an empty list
void pushAtBack_empty() {
   CharLinkedList list;
   list.pushAtBack('b');
   assert(list.toString() == "[CharLinkedList of size 1 <<b>>]");
}

//push at back of a one-element list
void pushAtBack_singleton() {
   CharLinkedList list('a');
   list.pushAtBack('b');
   assert(list.toString() == "[CharLinkedList of size 2 <<ab>>]");
}

//push at back of a larger list
void pushAtBack_large() {
    char arr[7] = {'a', 'b', 'g', 'j', 'e', 'r', 't'};
    CharLinkedList list(arr, 7);
    list.pushAtBack('h');
    assert(list.toString() == "[CharLinkedList of size 8 <<abgjerth>>]");
}

//make sure two-parameter constructor is syntactically correct
void twoParameterConstructorBasic() {
    char arr[2] = {'a', 'b'};
    CharLinkedList list(arr, 2);
}

//test the two-parameter constructor with a one-element list
void twoParameterConstructor_singleton() {
    char arr[1] = {'g'};
    CharLinkedList list(arr, 1);
    assert(list.toString() == "[CharLinkedList of size 1 <<g>>]");
}

//test the two-parameter construction with a larger list
void twoParameterConstructor_large() {
    char arr[7] = {'a', 'b', 'c', 's', 'x', 'y', 'z'};
    CharLinkedList list(arr, 7);
    assert(list.size() == 7);
    assert(list.toString() == "[CharLinkedList of size 7 <<abcsxyz>>]");
    
}

//test the two-parameter construction when given an empty list
void twoParameterConstructorEmpty() {
   char arr[0] = {};
   CharLinkedList list(arr, 0);
   assert(list.isEmpty());
}

// Tests insertion into front of a larger list
//also tests toString on a larger list
void insertAt_front_large_list() {
   char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
   CharLinkedList test_list(test_arr, 9);

   test_list.insertAt('y', 0);

   assert(test_list.size() == 10);
   assert(test_list.elementAt(0) == 'y');
   assert(test_list.toString() == "[CharLinkedList of size 10 <<yabczdefgh>>]");

}

// Tests insertion into the back of a larger list
void insertAt_back_large_list() {
   char test_arr[10] = { 'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
   CharLinkedList test_list(test_arr, 10);  

   test_list.insertAt('x', 10);

   assert(test_list.size() == 11);
   assert(test_list.elementAt(10) == 'x');
   assert(test_list.toString() == 
   "[CharLinkedList of size 11 <<yabczdefghx>>]"); 

}

// Tests insertion into the middle of a larger list
void insertAt_middle_large_list() {
   char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
   CharLinkedList test_list(test_arr, 8);

   test_list.insertAt('z', 3);

   assert(test_list.size() == 9);
   assert(test_list.elementAt(3) == 'z');
   assert(test_list.toString() == "[CharLinkedList of size 9 <<abczdefgh>>]");
}

// Tests out-of-range insertion for a non-empty list.
void insertAt_nonempty_incorrect() {
   
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    string error_message = "";

    try {
        test_list.insertAt('a', 42);
    }
    catch (const range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8]");
    
}

//push at front of an empty list
void pushAtFront_empty() {
   CharLinkedList list;
   list.pushAtFront('a');
   assert(list.toString() == "[CharLinkedList of size 1 <<a>>]");
}

//push at front of a one-element list
void pushAtFront_singleton() {
   CharLinkedList list('b');
   list.pushAtFront('a');
   assert(list.toString() == "[CharLinkedList of size 2 <<ab>>]");
}

//push at front of a larger list
void pushAtFront_large() {
    char arr[7] = {'a', 'b', 'g', 'j', 'e', 'r', 't'};
    CharLinkedList list(arr, 7);
    list.pushAtFront('h');
    assert(list.toString() == "[CharLinkedList of size 8 <<habgjert>>]");
}

// Tests attempted deletion from an empty LL at index 0.
// A range_error should be thrown
void removeAt_empty_zero() { 
   bool rangeErrorThrown = false;
   string errorMessage = "";

   CharLinkedList list;
   try {
      list.removeAt(0);
   }
   catch (const range_error &e) {
      rangeErrorThrown = true;
      errorMessage = e.what();
   }

   assert(rangeErrorThrown);
   assert(errorMessage == "index (0) not in range [0..0)");
}

// Tests attempted removal from an empty LL.
// Attempts to call removeAt for index larger than 0.
// This should result in an std::range_error being raised.
void removeAt_empty_nonzero() {
   // var to track whether range_error is thrown
   bool rangeErrorThrown = false;

   // var to track any error messages raised
   string errorMessage = "";

   CharLinkedList list;
   try {
     // removeAt for out-of-range index
     list.removeAt(42);
   }
   catch (const range_error &e) {
     // if removeAt is correctly implemented, a range_error will be thrown,
     // and we will end up here
     rangeErrorThrown = true;
     errorMessage = e.what();
   }

   // out here, we make our assertions
   assert(rangeErrorThrown);
   assert(errorMessage == "index (42) not in range [0..0)");    
}

// Tests correct removeAt for 1-element list.
void removeAt_singleton_list() {
   // initialize 1-element list
   CharLinkedList list('a');

   // remove element
   list.removeAt(0);

   assert(list.isEmpty()); 
}

// Tests calling removeAt for a large number of elements.
void removeAt_many_elements() {
   //declare an LL with many elements
   char arr[1000];
   for(int i = 0; i < 1000; i++) {
     arr[i] = 'c';
   }
   CharLinkedList list(arr, 1000);

   // remove most elements
   for (int i = 0; i < 998; i++) {
      // always remove from front of list
      list.removeAt(0);
   }

   assert(list.size() == 2);
   assert(list.elementAt(0) == 'c');
   assert(list.elementAt(1) == 'c');
    
}

// Tests removal from front of a larger list
void removeAt_front_large_list() {
   char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
   CharLinkedList list(test_arr, 9);

   list.removeAt(0);

   assert(list.size() == 8);
   assert(list.elementAt(0) == 'b');
   assert(list.toString() == "[CharLinkedList of size 8 <<bczdefgh>>]");
}

// Tests removal from the back of a larger list
void removeAt_back_large_list() {
   char arr[10] = { 'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
   CharLinkedList list(arr, 10);  
   list.removeAt(9);

   assert(list.size() == 9);
   assert(list.elementAt(8) == 'g');
   assert(list.toString() == "[CharLinkedList of size 9 <<yabczdefg>>]"); 
}

// Tests removal from the middle of a larger list
void removeAt_middle_large_list() {
   char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
   CharLinkedList list(test_arr, 8);

   list.removeAt(3);

   assert(list.size() == 7);
   assert(list.elementAt(3) == 'e');
   assert(list.toString() == "[CharLinkedList of size 7 <<abcefgh>>]");
}

// Tests out-of-range removal from a non-empty list.
void removeAt_nonempty_incorrect() {
   char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
   CharLinkedList list(test_arr, 8);

   // var to track whether range_error is thrown
   bool range_error_thrown = false;

   // var to track any error messages raised
   string error_message = "";

   try {
     list.removeAt(42);
   }
   catch (const range_error &e) {
      range_error_thrown = true;
      error_message = e.what();
   }

   assert(range_error_thrown);
   assert(error_message == "index (42) not in range [0..8)");
}

// tests clear function on an already empty LL
void clear_empty() {
   CharLinkedList list;
   list.clear();
   assert(list.isEmpty());
}

// test clear function on a non-empty LL
// in addition to the list being empty, it is important that we pass valgrind
void clear_nonempty() {
   char arr[7] = {'a', 'b', 'c', 'd', 'e', 'f', 'g'};
   CharLinkedList list(arr, 7);
   list.clear();
   assert(list.isEmpty());
}

//test copy constructor by using it to make a second list, edit the new list
//and ensure the original list has not changed
//if this runs without errors, it will also mean that calling the destructor
//does not cause any double free errors
void copy_constructor() {
   char arr[7] = {'a', 'b', 'd', 'h', 'e', 'b', 'i'};
   CharLinkedList list1(arr, 7);
   CharLinkedList list2(list1);
   list2.removeAt(4);
   assert(list1.toString() == "[CharLinkedList of size 7 <<abdhebi>>]");
   assert(list2.toString() == "[CharLinkedList of size 6 <<abdhbi>>]");
}

//test copy constructor with an empty list, and then adding to the new list
void copyConstructor_empty() {
    CharLinkedList list1;
    CharLinkedList list2(list1);
    list2.pushAtBack('d');
    assert(list1.toString() == "[CharLinkedList of size 0 <<>>]");
    assert(list2.toString() == "[CharLinkedList of size 1 <<d>>]");
}

//test the assignment operator by assigning one list to another, editing one,
//and making sure the original has not changed
//if this runs without errors, it will also mean that calling the destructor
//dos not cause any double free errors
void assignment_operator_different() {
   char arr[7] = {'a', 'b', 'd', 'h', 'e', 'b', 'i'};
   CharLinkedList list1(arr, 7);
   CharLinkedList list2('b');
   list2 = list1;
   cout << list2.size() << endl;
   list2.pushAtFront('z');
   list2.removeAt(4);
   assert(list1.toString() == "[CharLinkedList of size 7 <<abdhebi>>]");
   assert(list2.toString() == "[CharLinkedList of size 7 <<zabdebi>>]");
}

//test the assignment operator with setting a list equal to itself
void assignment_operator_selfAssign() {
   char arr[7] = {'a', 'b', 'd', 'h', 'e', 'b', 'i'};
   CharLinkedList list1(arr, 7);
   list1 = list1;
   assert(list1.toString() == "[CharLinkedList of size 7 <<abdhebi>>]");
}

//test the assignment operter when assigning a list to a distinct, but
//identical list, editing one, and making sure the other hasn't changed
void assignment_operator_identical() {
   char arr[7] = {'a', 'b', 'd', 'h', 'e', 'b', 'i'};
   CharLinkedList list1(arr, 7);
   CharLinkedList list2(arr, 7);
   list1 = list2;
   list2.pushAtFront('z');
   list2.removeAt(4);
   assert(list1.toString() == "[CharLinkedList of size 7 <<abdhebi>>]");
   assert(list2.toString() == "[CharLinkedList of size 7 <<zabdebi>>]");
}

//test first on an empty LL
void first_empty() {
   bool runtimeErrorThrown = false;
   string errorMessage = "";

   CharLinkedList list;
   try {
      list.first();
   }
   catch (runtime_error &e) {
      runtimeErrorThrown = true;
      errorMessage = e.what();
   }

   assert(runtimeErrorThrown);
   assert(errorMessage == "cannot get first of empty LinkedList");
}

//test first on a one-element list
void first_singleton() {
   CharLinkedList list('c');
   assert(list.first() == 'c');
}

//test first on a larger list
void first_large() {
   char arr[5] = {'s', 'b', 'd', 'e', 'f'};
   CharLinkedList list(arr, 5);
   assert(list.first() == 's');
}

//test last on an empty LL
void last_empty() {
   bool runtimeErrorThrown = false;
   string errorMessage = "";

   CharLinkedList list;
   try {
      list.last();
   }
   catch (runtime_error &e) {
      runtimeErrorThrown = true;
      errorMessage = e.what();
   }

   assert(runtimeErrorThrown);
   assert(errorMessage == "cannot get last of empty LinkedList");

}

//test last on a one-element list
void last_singleton() {
   CharLinkedList list('c');
   assert(list.last() == 'c');
}

//test first on a larger list
void last_large() {
   char arr[5] = {'s', 'b', 'd', 'e', 'h'};
   CharLinkedList list(arr, 5);
   assert(list.last() == 'h');
}

//test toReverseString on an empty list
void toReverseString_empty() {
   CharLinkedList list;
   assert(list.toReverseString() == "[CharLinkedList of size 0 <<>>]");
}

//test toReverseString on a single-element list
void toReverseString_singleton() {
   CharLinkedList list('v');
   assert(list.toReverseString() == "[CharLinkedList of size 1 <<v>>]");
}

//test toReverseString on a larger list
void toReverseString_large() {
   char arr[5] = {'A', 'l', 'i', 'c', 'e'};
   CharLinkedList list(arr, 5);
   assert(list.toReverseString() == "[CharLinkedList of size 5 <<ecilA>>]");
}

//try to pop from front of an empty list
//should throw runtime error
void popFromFront_empty() {
   bool runtimeErrorThrown = false;
   string errorMessage = "";

   CharLinkedList list;
   try {
      list.popFromFront();
   }
   catch (runtime_error &e) {
      runtimeErrorThrown = true;
      errorMessage = e.what();
   }

   assert(runtimeErrorThrown);
   assert(errorMessage == "cannot pop from empty LinkedList");
}

//pop from front of a one-element list
//list should be empty
void popFromFront_singleton() {
   CharLinkedList list('g');
   list.popFromFront();
   assert(list.isEmpty());
}

//pop from front of a larger list
void popFromFront_large() {
   char arr[7] = {'a', 'b', 'c', 'g', 'i', 'k', 'x'};
   CharLinkedList list(arr, 7);
   list.popFromFront();
   assert(list.toString() == "[CharLinkedList of size 6 <<bcgikx>>]");
}

//try to pop from back of empty list
//should throw runtime error
void popFromBack_empty() {
   bool runtimeErrorThrown = false;
   string errorMessage = "";

   CharLinkedList list;
   try {
      list.popFromBack();
   }
   catch (runtime_error &e) {
      runtimeErrorThrown = true;
      errorMessage = e.what();
   }

   assert(runtimeErrorThrown);
   assert(errorMessage == "cannot pop from empty LinkedList");
}

//pop from back of one-element list
//list should be empty
void popFromBack_singleton() {
   CharLinkedList list('c');
   list.popFromBack();
   assert(list.isEmpty());
}

//pop from back of a larger list
void popFromBack_large() {
   char arr[7] = {'a', 'b', 'c', 'g', 'i', 'k', 'x'};
   CharLinkedList list(arr, 7);

   list.popFromBack();
   assert(list.toString() == "[CharLinkedList of size 6 <<abcgik>>]");
}

//test replaceAt with index zero on an empty LL. Should throw a range error
void replaceAt_empty_zero() {
   bool rangeErrorThrown = false;
   string errorMessage = "";

   CharLinkedList list;
   try{
      list.replaceAt('g', 0);
   }
   catch (range_error &e) {
      rangeErrorThrown = true;
      errorMessage = e.what();
   }

   assert(rangeErrorThrown);
   assert(errorMessage == "index (0) not in range [0..0)");
}

//test replaceAt with a negative index. Should throw a range error
void replaceAt_negative() {
   bool rangeErrorThrown = false;
   string errorMessage = "";

   char arr[7] = {'a', 'b', 'c', 'g', 'i', 'k', 'x'};
   CharLinkedList list(arr, 7);
   try{
      list.replaceAt('q', -1);
   }
   catch (range_error &e) {
      rangeErrorThrown = true;
      errorMessage = e.what();
   }

   assert(rangeErrorThrown);
   assert(errorMessage == "index (-1) not in range [0..7)");
}

//test replaceAt on a one-element LinkedList
void replaceAt_singleton() {
   CharLinkedList list('g');
   list.replaceAt('q', 0);
   assert(list.toString() == "[CharLinkedList of size 1 <<q>>]");
}

//test replacing the first element of a list
void replaceAt_front() {
   char arr[7] = {'a', 'b', 'c', 'g', 'i', 'k', 'x'};
   CharLinkedList list(arr, 7);
   list.replaceAt('z', 0);
   assert(list.toString() == "[CharLinkedList of size 7 <<zbcgikx>>]");
}

//test replacing the last element of a list
void replaceAt_back() {
   char arr[7] = {'a', 'b', 'c', 'g', 'i', 'k', 'x'};
   CharLinkedList list(arr, 7);
   list.replaceAt('r', 6);
   assert(list.toString() == "[CharLinkedList of size 7 <<abcgikr>>]");
}

//test replacing at one element too high
//should throw a range error
void replaceAt_tooLarge() {
   bool rangeErrorThrown = false;
   string errorMessage = "";

   char arr[7] = {'a', 'b', 'c', 'g', 'i', 'k', 'x'};
   CharLinkedList list(arr, 7);
   try {
      list.replaceAt('v', 7);
   }
   catch (range_error &e) {
      rangeErrorThrown = true;
      errorMessage = e.what();
   }

   assert(rangeErrorThrown);
   assert(errorMessage == "index (7) not in range [0..7)");
}

//test replacing in the middle of a list
void replaceAt_middle() {
   char arr[7] = {'a', 'b', 'c', 'g', 'i', 'k', 'x'};
   CharLinkedList list(arr, 7);
   list.replaceAt('y', 3);
   assert(list.toString() == "[CharLinkedList of size 7 <<abcyikx>>]");
}

//insert in order to an empty list
void insertInOrder_empty() {
   CharLinkedList list;
   list.insertInOrder('g');
   assert(list.toString() == "[CharLinkedList of size 1 <<g>>]");
}

//insert in order to the front of a list
void insertInOrder_front() {
   char arr[3] = {'Z', 'E', 'D'};
   CharLinkedList list(arr, 3);
   list.insertInOrder('A');
   assert(list.toString() == "[CharLinkedList of size 4 <<AZED>>]");
}

//insert in order to the middle of a list
void insertInOrder_middle() {
   char arr[5] = {'a', 'b', 'd', 'e', 'f'};
   CharLinkedList list(arr, 5);
   list.insertInOrder('c');
   assert(list.toString() == "[CharLinkedList of size 6 <<abcdef>>]");
}

//insert in order to the end of a list
void insertInOrder_end() {
   char arr[5] = {'u', 'v', 'w', 'x', 'y'};
   CharLinkedList list(arr, 5);
   list.insertInOrder('z');
   assert(list.toString() == "[CharLinkedList of size 6 <<uvwxyz>>]");
}

//concatenate two nonempty lists
void concatenate_nonempty() {
   char arr1[3] = {'c', 'a', 't'};
   char arr2[8] = {'C', 'H', 'E', 'S', 'H', 'I', 'R', 'E'};
   CharLinkedList list1(arr1, 3);
   CharLinkedList list2(arr2, 8);
   list1.concatenate(&list2);
   assert(list1.toString() == "[CharLinkedList of size 11 <<catCHESHIRE>>]");
   assert(list2.toString() == "[CharLinkedList of size 8 <<CHESHIRE>>]");
}

//concatenate to an empty list
void concatenate_first_empty() {
   char arr[3] = {'c', 'a', 't'};
   CharLinkedList list1;
   CharLinkedList list2(arr, 3);
   list1.concatenate(&list2);
   assert(list1.toString() == "[CharLinkedList of size 3 <<cat>>]");
   assert(list2.toString() == "[CharLinkedList of size 3 <<cat>>]");
}

//concatenate with an empty list
void concatenate_second_empty() {
   char arr[3] {'c', 'a', 't'};
   CharLinkedList list1(arr, 3);
   CharLinkedList list2;
   list1.concatenate(&list2);
   assert(list1.toString() =="[CharLinkedList of size 3 <<cat>>]");
   assert(list2.isEmpty());
}

//concatenate two empty lists
void concatenate_both_empty() {
   CharLinkedList list1;
   CharLinkedList list2;
   list1.concatenate(&list2);
   assert(list1.isEmpty());
   assert(list2.isEmpty());
}

//concatenate a nonempety list with itself
void concatenate_self() {
   char arr[4] = {'A', 'd', 'G', 'e'};
   CharLinkedList list(arr, 4);
   list.concatenate(&list);
   cout << list.toString() << endl;
   assert(list.toString() == "[CharLinkedList of size 8 <<AdGeAdGe>>]");
}

//concatenate an empty list with itself
void concatenate_self_empty() {
   CharLinkedList list;
   list.concatenate(&list);
   assert(list.isEmpty());
}
/*
 *  CharLinkedList.cpp
 *  By: Sam Lev
 *  2/5/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Purpose: Implements the CharLinkedList class
 *
 */

#include "CharLinkedList.h"
#include <stdexcept>

using namespace std;

/*
 * default constructor
 * Purpose: creates an empty CharLinkedList
 * parameters: none
 * returns: none
 * effects: none
 */
CharLinkedList::CharLinkedList() {
    listSize = 0;
    front = nullptr;
    back = nullptr;
}

/*
 * parameterized constructor
 * purpose: creates a one-element CharLinkedList containing the char c
 * parameters: a character c that is the element of the new list
 * returns: none
 * effects: none
 */
CharLinkedList::CharLinkedList(char c) {
   listSize = 1;
   front = newNode(c, nullptr, nullptr);
   back = front;
}

/*
 * paramterized constructor
 * purpose: creates a CharLinkedList containing elements from a given array
 * parameters: a character array arr whose elements are to be contained in the
 *             new list, and an int size representing the size of the array
 * returns: none
 * effects: none
 */
CharLinkedList::CharLinkedList(char arr[], int size) {
    listSize = size;
    //check for an empty list
    if (isEmpty()) {
        front = nullptr;
        back = nullptr;
    } else {
        //create a node for the first element
        Node *currNode = newNode(arr[0], nullptr, nullptr);
        front = currNode;
        back = currNode;
        Node *prevNode = currNode;
        //add nodes for subsequent elements
        for (int i = 1; i < size; i++) {
            currNode = newNode(arr[i], prevNode, nullptr);
            prevNode->next = currNode;
            prevNode = currNode;
        }
        back = prevNode;
    }
}

/*
 * copy constructor
 * purpose: creates a CharLinkedList that is a deep copy of another
 * parameters: a reference to the CharLinkedList other to be copied
 * returns: none
 * effects: none
 * 
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other) {
    //check for an empty list
    if (other.isEmpty()) {
        front = nullptr;
        back = nullptr;
    } else {
        //create a node for the first element
        Node *currNode = newNode(other.elementAt(0), nullptr, nullptr);
        front = currNode;
        back = currNode;
        Node *prevNode = currNode;
        //add nodes for subsequenet elements
        for (int i = 1; i < other.size(); i++) {
            currNode = newNode(other.elementAt(i), prevNode, nullptr);
            prevNode->next = currNode;
            prevNode = currNode;
        }
        back = prevNode;
    }
    listSize = other.size();
}

/*
 * destructor
 * purpose: frees memory associated with the CharLinkedList
 * parameters: none
 * returns: none
 * effects: deletes each Node
 */
CharLinkedList::~CharLinkedList() {
    free(front);
}

/*
 * overloaded assignment operator
 * purpose: creates a deep copy of a CharLinkedList
 * parameters: a reference to the CharLinkedList other that is to be copied
 * returns: none
 * effects: makes the LL on the left of the = operator a deep copy of the LL on
 *          the right 
 */
CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other) {
    //check if they are the same object
    if (this == &other) {
        return *this;
    }
    
    clear();
    //copy elements over
    for (int i = 0; i < other.size(); i++) {
        pushAtBack(other.elementAt(i));
    }
    return *this;
}


/*
 * name: size
 * purpose: accesses the size of the CharLinkedList
 * parameters: none
 * returns: an integer representing the number of elements in the list
 * effects: none
 */
int CharLinkedList::size() const {
    return listSize;
}

/*
 * name: isEmpty
 * purpose: identifies whether the CharLinkedList contains is empty
 * parameters: none
 * returns: true if the list is empty, false if it contains at least one element
 * effects: none
 */
bool CharLinkedList::isEmpty() const {
    return listSize == 0;
}

/*
 * name: elementAt
 * purpose: accesses the value of an element at a given index
 * parameters: an integer index that represents the index of the value to be
 *             accessed
 * returns: the character at the given index of the list
 * effects: none
 */
char CharLinkedList::elementAt(int index) const {
    if (index < 0 or index >= listSize) {
        throw range_error("index (" + to_string(index) + ") not in range [0.." +
                          to_string(listSize) + ")");
    } else {
        return findNode(index)->data;
    }
}

/*
 * name: toString
 * purpose: summarizes the data in the CharLinkedList
 * parameters: none
 * returns: a string containing the size and contents of the list
 * effects: none
 */
string CharLinkedList::toString() const {
    string str = "[CharLinkedList of size " + to_string(listSize) + " <<";
    //concatentate each element to the string
    for (int i = 0; i < listSize; i++) {
        str += elementAt(i);
    }
    str += ">>]";
    return str;
}

/*
 * name: toReverseString
 * purpose: summarizes the data in the CharLinkedList, but displays the elements
 *          in reverse order
 * parameters: none
 * returns: a string containing the size of the list and its contents in reverse
 *          order
 * effects: none
 */
string CharLinkedList::toReverseString() const {
    string str = "[CharLinkedList of size ";
    str += to_string(listSize);
    str += " <<";
    //concatentate each element to the string in reverse order
    for (int i = listSize - 1; i >= 0; i--) {
        str += elementAt(i);
    }
    str += ">>]";
    return str;
}

/*
 * name: insertAt
 * purpose: adds an element to the CharLinkedList at a given index
 * parameters: a character c to be added to the list and an int index that
 *             represents the index at which the character is to be added
 * returns: none
 * effects: inserts the given character at the given index, shifts all further
 *          elements, increases list size by 1
 */
void CharLinkedList::insertAt(char c, int index) {
    //range check
    if (index < 0 or index > listSize) {
        throw range_error("index (" + to_string(index) + ") not in range [0.." +
                          to_string(listSize) + "]");
    }
    //if the list is empty, create a new node to be the only element
    if (isEmpty()) {
        front = newNode(c, nullptr, nullptr);
        back = front;
    } else {
        //find and store the nodes that will be before and after the inserted
        //node in the list
        Node *before = findNode(index - 1);
        Node *after = findNode(index);
        Node *insertedNode = newNode(c, before, after);
        if (index == 0) {
            front = insertedNode;
        } else {
            before->next = insertedNode;
        }
        if (index == listSize) {
            back = insertedNode;
        } else {
            after->previous = insertedNode;
        }
    }
    listSize++;
}

/*
 * name: pushAtBack
 * purpose: adds an element to the back of the list
 * parameters: a character c to be added to the back of the list
 * returns: none
 * effects: adds the given character to the end of the list, increases list size
 *          by 1
 */
void CharLinkedList::pushAtBack(char c) {
    insertAt(c, listSize);
}

/*
 * name: pushAtFront
 * purpose: adds an element to the front of the list
 * parameters: a character c to be added to the front of the list
 * returns: none
 * effects: inserts the given character at the front of the list, shifts all
 *          other elements, increases list size by 1
 */
void CharLinkedList::pushAtFront(char c) {
    insertAt(c, 0);
}

/*
 * name: removeAt
 * purpose: removes the element at a specified index from the list
 * parameters: an int index that represents the index of the element to be
 *             removed
 * returns: none
 * effects: removes the element at the given index, shifts all further elements
 *          forward, list size decreases by 1
 */
void CharLinkedList::removeAt(int index) {
    //range check
    if (index < 0 or index >= listSize) {
        throw range_error("index (" + to_string(index) + ") not in range [0.." +
                          to_string(listSize) + ")");
    } else {
        Node *removedNode = findNode(index);
        //handle edge case of one-element list
        if (listSize == 1) {
            clear();
        //handle edge case if first element is removed
        } else if (index == 0) {
            front = removedNode->next;
            front->previous = nullptr;
        //handle edge case if last element is removed
        } else if (index == listSize - 1) {
            back = removedNode->previous;
            back->next = nullptr;
        //all other cases
        } else {
            removedNode->previous->next = removedNode->next;
            removedNode->next->previous = removedNode->previous;
        }
        if (not isEmpty()) {
            delete removedNode;
            listSize--;
        }
    }
}

/*
 * name: first
 * purpose: access the first value of the list
 * parameters: none
 * returns: the character at the front of the list
 * effects: none
 */
char CharLinkedList::first() const {
    //check for exception
    if (isEmpty()) {
        throw runtime_error("cannot get first of empty LinkedList");
    } else {
        return elementAt(0);
    }
}

/*
 * name: last
 * purpose: accesses the last value of the list
 * parameters: none
 * returns: the character at the back of the list
 * effects: none
 */
char CharLinkedList::last() const {
    //check for exception
    if (isEmpty()) {
        throw runtime_error("cannot get last of empty LinkedList");
    } else {
        return elementAt(listSize - 1);
    }
}

/*
 * name: popFromFront
 * purpose: remove the first element of the list
 * parameters: none
 * returns: none
 * effects: removes the first element from the list, shifts all other elements
 *          forward, list size decreases by 1
 */
void CharLinkedList::popFromFront() {
    //check for exception
    if (isEmpty()) {
        throw runtime_error("cannot pop from empty LinkedList");
    }
    removeAt(0);
}

/*
 * name: popFromBack
 * purpose: removes the last element from the list
 * parameters: none
 * returns: none
 * effects: removes the last element from the list, list size decreases by 1
 */
void CharLinkedList::popFromBack() {
    //check for exception
    if (isEmpty()) {
        throw runtime_error("cannot pop from empty LinkedList");
    }
    removeAt(listSize - 1);
}

/*
 * name: replaceAt
 * purpose: replaces the element at a given index with a specified character
 * parameters: a character c with which to replace the old element and an
 *             integer index representing the index of the element to be
 *             replaced
 * returns: none
 * effects: replaces the element at the given index with the given character
 */
void CharLinkedList::replaceAt(char c, int index) {
    //range check
    if (index < 0 or index >= listSize) {
        throw range_error("index (" + to_string(index) + ") not in range [0.." +
                          to_string(listSize) + ")");
    }

    findNode(index)->data = c;
}

/* 
 * name: insertInOrder
 * purpose: inserts a given character before the first existing element it comes
 *          before alphabetically (by ASCII value)
 * parameters: a character c to be inserted
 * returns: none
 * effects: inserts the given character into the CharLinkedList just prior to
 *          the first element in the list which has a greater ASCII value
 */
void CharLinkedList::insertInOrder(char c) {
    for (int i = 0; i < listSize; i++) {
        if (c <= elementAt(i)) {
            insertAt(c, i);
            return;
        }
    }
    pushAtBack(c);
}

/* 
 * name: concatenate
 * purpose: concatenates two CharLinkedLists
 * parameters: a reference to another CharLinkedList other
 * returns: none
 * effects: adds the elements of the other CharLinkedList to the end of the
 *          CharLinkedList the function is called on
 */
void CharLinkedList::concatenate(CharLinkedList *other) {
    //declare a constant size variable to avoid an infinite loop if a list
    //is concatenated with itself
    const int size = other->size();
    for (int i = 0; i < size; i++) {
        pushAtBack(other->elementAt(i));
    }
}

/*
 * name: clear
 * purpose: make a list empty
 * parameters: none
 * returns: none
 * effects: removes all elements from the list
 */
void CharLinkedList::clear() {
    free(front);
    front = nullptr;
    back = nullptr;
    listSize = 0;
}

/*
 * name: accessRecFront
 * purpose: recurssively access a node at a given index, starting from the front
 *          of the list and moving forwards
 * parameters: a pointer to the current or starting Node, currNode, an int
 *             currIndex that contains the index of currNode, and an int
 *             targetIndex that contains the index of the Node we are looking
 *             for
 * returns: a pointer to the node at the target index
 * effects: none
 */
CharLinkedList::Node *CharLinkedList::accessRecFront(Node *currNode,
                                                     int currIndex,
                                                     int targetIndex) const {
    if (currIndex == targetIndex) {
        return currNode;
    } else {
        return accessRecFront(currNode->next, currIndex + 1, targetIndex);
    }
}

/*
 * name: accessRecBack
 * purpose: recurssively access a node at a given index, starting from the back
 *          of the list and moving backwards
 * parameters: a pointer to the current or starting Node, currNode, an int
 *             currIndex that contains the index of currNode, and an int
 *             targetIndex that contains the index of the Node we are looking
 *             for
 * returns: a pointer to the node at the target index
 * effects: none
 */
CharLinkedList::Node *CharLinkedList::accessRecBack(Node *currNode,
                                                    int currIndex,
                                                    int targetIndex) const {
    if (currIndex == targetIndex) {
        return currNode;
    } else {
        return accessRecBack(currNode->previous, currIndex - 1, targetIndex);
    }
}

/*
 * name: free
 * purpose: recursively free memory allocated by a linked list
 * parameters: a pointer to the current or starting Node, currNode
 * returns: none
 * effects: deletes and deallocates all Nodes from currNode to the end of the
 *          linked list
 */
void CharLinkedList::free(Node *currNode) {
    if (currNode == nullptr) {
        return;
    } else {
        free(currNode->next);
        delete currNode;
    }
}

/*
 * name: findNode
 * purpose: access a Node in the list from the most efficient direction
 * parameters: an int representing the index of the Node to be accessed
 * returns: a pointer to the Node at the specified index, or nullptr if the
 *          index is out of bounds
 * effects: none
 */
CharLinkedList::Node *CharLinkedList::findNode(int index) const {
    if (index < 0 or index >= listSize) {
        return nullptr;
    } else if (index < listSize / 2) {
        return accessRecFront(front, 0, index);
    } else {
        return accessRecBack(back, listSize - 1, index);
    }
}

/*
 * name: newNode
 * purpose: creates a new Node to represent a new list element, and inserts it
 *          into the list between two specified Nodes
 * parameters: a char data, containing the character element the new Node should
 *             represent, a pointer to the Node that comes just before the new
 *             Node, and a pointer to the Node that comes just after.
 * returns: a pointer to the newly-allocated Node
 * effects: allocates and inserts a new Node into the linked list
 */
CharLinkedList::Node *CharLinkedList::newNode(char data, Node *previous,
                                                      Node *next) {
    Node *newNode = new Node;
    newNode->data = data;
    newNode->next = next;
    newNode->previous = previous;
    return newNode;
}
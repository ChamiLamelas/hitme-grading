/*
 *  CharLinkedList.h
 *  By: Sam Lev
 *  2/5/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Purpose: CharLinkedList is a class that represents a list ADT for lists of
 *           characters. Functions of the class allow for easy access within,
 *           insertion to, and removal from the list. The list is implemented
 *           with a doubly-linked list, allowing for quick operations near
 *           either end of the list, but less efficient operations near the
 *           middle.
 *
 */

#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H

#include <string>

class CharLinkedList {
    public:
        //constructors
        CharLinkedList();
        CharLinkedList(char c);
        CharLinkedList(char arr[], int size);
        CharLinkedList(const CharLinkedList &other);

        //destructor
        ~CharLinkedList();

        //overloaded assignment operator
        CharLinkedList &operator=(const CharLinkedList &other);

        //public methods
        bool isEmpty() const;
        void clear();
        int size() const;
        char first() const;
        char last() const;
        char elementAt(int index) const;
        std::string toString() const;
        std::string toReverseString() const;
        void pushAtBack(char c);
        void pushAtFront(char c);
        void insertAt(char c, int index);
        void insertInOrder(char c);
        void popFromFront();
        void popFromBack();
        void removeAt(int index);
        void replaceAt(char c, int index);
        void concatenate(CharLinkedList *other);

    private:
        struct Node {
            char data;
            Node *next;
            Node *previous;
        };

        int listSize;
        Node *front;
        Node *back;

        Node *newNode(char data, Node *next, Node *previous);
        Node *accessRecFront(Node *currNode, int currIndex, int targetIndex)
                                                                      const;
        Node *accessRecBack(Node *currNode, int currIndex, int targetIndex)
                                                                     const;
        void free(Node *currNode);
        Node*findNode(int index) const;
};

#endif

/*
 *  CharLinkedList.cpp
 *  Ella Han
 *  02/04/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  This file contains the detailed implementation of the CharLinkedList class,
 *  which provides functionality for managing a linked list of characters.
 *  It includes definitions for constructors, destructor, and member functions
 *  to manipulate the linked list, such as insertion, deletion, and traversal.
 *  Additionally, this file implements methods for concatenating two 
 *  CharLinkedList objects and other operations related to character 
 *  manipulation within the list.
 *  
 */

#include "CharLinkedList.h"

using namespace std;

/*
 * Name: CharrLinkedList
 * Purpose: Construct an empty CharLinkedList.
 * Argument: N/A
 * Return: N/A
 * Effect: Initialize currSize and capacity to 0 and set data to nullptr.
 */
CharLinkedList::CharLinkedList() {
    front = nullptr;
    currSize = 0;
}

/*
 * Name: newNode
 * Purpose: Create a new node for CharLinkedList.
 * Argument: The character data to be stored in the new node, a pointer to 
 *           the next node, and a pointer to the previous node. 
 * Return: A pointer to the new node. 
 * Effect: Allocate memory for a new node, set the data, next, and prev 
 *         members of the new node, and return the pointer to the new 
 *         node. 
 */
CharLinkedList::Node *CharLinkedList::newNode(
    char Newdata, Node *next, Node *prev
) {
    Node *new_node = new Node;
    new_node->data = Newdata;
    new_node->next = next;
    new_node->prev = prev;
    return new_node;
}

/*
 * Name: CharrLinkedList
 * Purpose: Construct an empty CharLinkedList with a single character.
 * Argument: Character c.
 * Return: N/A
 * Effect: Allocate memory for a single character node
 *         and set currSize and pointer associated with that node
 *         as well as the front pointer. 
 */
CharLinkedList::CharLinkedList(char c) {
    front = newNode(c, nullptr, nullptr);
    currSize = 1;
}

/*
 * Name: CharrLinkedList
 * Purpose: Construct a CharLinkedList from an array of characters.
 * Argument: An array of characters and its size.
 * Return: N/A
 * Effect: Iterate through the array and add each character to the front
 *         of the linked list. 
 */
CharLinkedList::CharLinkedList(char arr[], int size) {
    front = newNode(arr[0], nullptr, nullptr);
    Node *curr = front;
    for (int i = 1; i < size; i++) {
        Node *newNodePtr = newNode(arr[i], nullptr, curr);
        curr->next = newNodePtr;
        curr = newNodePtr;
    }
    currSize = size;
}

/*
 * Name: ~CharrLinkedList
 * Purpose: Destructor for CharLinkedList
 * Argument: N/A
 * Return: N/A
 * Effect: Deallocate heap memory occupied by nodes. 
 */
CharLinkedList::~CharLinkedList() {
    recycleRecursive(front);
}

/*
 * Name: recycleRecursive
 * Purpose: Recursively delete nodes in the CharLinkedList.
 * Argument: A pointer to the current node (curr). 
 * Return: N/A
 * Effect: Deallocate heap memory occupied by each node in the linked list. 
 */
void CharLinkedList::recycleRecursive(Node *curr) {
    if (curr == nullptr) {
        return;
    } else {
        Node *nextNode = curr->next;
        delete curr;
        recycleRecursive(nextNode);
    }
}

/*
 * Name: traversing 
 * Purpose: Traverse another CharLinkedList and 
 *          create a deep copy in the current CharLinkedList.
 * Argument: A constant reference to another CharLinkedList. 
 * Return: N/A
 * Effect: Iterate through the nodes of the other CharLinkedList 
 *         and create new nodes with the same data in the form of a deep copy. 
 */
void CharLinkedList::traversing(const CharLinkedList &other) {
    if (other.isEmpty()) {
        front = nullptr;
        return;
    }

    Node *other_curr = other.front;
    front = newNode(other_curr->data, nullptr, nullptr);
    Node *curr = front;
    while (other_curr->next != nullptr) {
        other_curr = other_curr->next;
        curr = newNode(other_curr->data, nullptr, curr);
        curr->prev->next = curr;
    }
    currSize = other.currSize;
    return;
}

/*
 * Name: CharrLinkedList
 * Purpose: Copy constructor for CharLinkedList.
 * Argument: Another CharLinkedList to copy from.
 * Return: N/A
 * Effect: Allocate memory for a new CharLinkedList and copy the content 
 *         of other CharLinkedList into the new one. 
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other) {
    traversing(other);
}

/*
 * Name: operator=
 * Purpose: Assignment operator for CharLinkedList.
 * Argument: Another CharLinkedList for assignment.
 * Return: Reference to the modified CharLinkedList.
 * Effect: Assign the content of other CharLinkedList to the current instance, 
 *         create a deep copy of the provided CharLinkedList,
 *         and update the current one accordingly.
 */
CharLinkedList& CharLinkedList::operator=(const CharLinkedList &other) {
    if (this == &other) {
        return *this; 
    }
    clear();
    traversing(other);
    return *this;
}

/*
 * Name: clear
 * Purpose: Clear all elements from the CharLinkedList.
 * Argument: N/A
 * Return: N/A
 * Effect: Clean up all heap-memory nodes in the current list,
           and set currSize to 0 and front pointing to null. 
 */
void CharLinkedList::clear() {
    this->~CharLinkedList();
    front = nullptr;
    currSize = 0;
}

/*
 * Name: isEmpty
 * Purpose: Check if the CharLinkedList is empty.
 * Argument: N/A
 * Return: True if the CharLinkedList is empty and false otherwise.
 * Effect: N/A
 */
bool CharLinkedList::isEmpty() const {
    if(currSize == 0) {
        return true;
    } else {
        return false; 
    }
}

/*
 * Name: size
 * Purpose: Return the number of elements in the CharLinkedList.
 * Argument: N/A
 * Return: The number of elements in the CharLinkedList.
 * Effect: N/A
 */
int CharLinkedList::size() const {
    return currSize;
}

/*
 * Name: RecgetNodeAt
 * Purpose: Recursive helper function to get the node at a specific index.
 * Argument: Pointer to the current node, 
 *           the target index of the node to retrieve,
 *           and the current count of nodes traversed. 
 * Return: Pointer to the node at the specified index, or nullptr. 
 * Effect: Recursively traverse the linked list nodes
 *         and return the node at the specified index when found, 
 *         or nullptr otherwise.
 */
CharLinkedList::Node *CharLinkedList::RecgetNodeAt(
    Node *curr, int index, int count) const {
    if (curr == nullptr) {
        return nullptr;
    }
    if (count == index) {
        return curr;
    }
    return RecgetNodeAt(curr->next, index, count + 1);
}

/*
 * Name: getNodeAt
 * Purpose: Retrieve the node at a specific index in the linked list.
 * Argument: Index of the node.
 * Return: Pointer to the node at the index, or nullptr if not found.
 * Effect: Recursively traverse the linked list to find and return the node 
 *         at the specified index.
 */
CharLinkedList::Node *CharLinkedList::getNodeAt(int index) const {
    return RecgetNodeAt(front, index, 0);
}

/*
 * Name: first
 * Purpose: Return the first element of the CharLinkedList.
 * Argument: N/A
 * Return: The first character. 
 * Effect: Throw a std::runtime_error if the CharLinkedList is empty.
 */
char CharLinkedList::first() const {
    if (isEmpty()) {
        throw std::runtime_error("cannot get first of empty LinkedList");
    }
    return front->data;
}

/*
 * Name: last
 * Purpose: Return the last element of the CharLinkedList.
 * Argument: N/A
 * Return: The last character. 
 * Effect: Throw a std::runtime_error if the CharLinkedList is empty.
 */
char CharLinkedList::last() const {
    if (isEmpty()) {
        throw std::runtime_error("cannot get last of empty LinkedList");
    }
    Node *find = getNodeAt(currSize - 1);
    return find->data;
}

/*
 * Name: elementAt
 * Purpose: Return the element at the specified index.
 * Argument: The index of the element in the linked list. 
 * Return: The character at that specific index.
 * Effect: Throw a std::range_error if the index is out of bounds.
 */
char CharLinkedList::elementAt(int index) const {
    if (index < 0 or index >= currSize) {
        throw std::range_error("index (" + std::to_string(index) + 
        ") not in range [0.." + std::to_string(currSize) + ")");
    }
    Node *find = getNodeAt(index);
    return find->data;
}

/*
 * Name: toString
 * Purpose: Return a string representing the CharLinkedyList.
 * Argument: N/A
 * Return: A string representation of the CharLinkedList.
 * Effect: N/A
 */
std::string CharLinkedList::toString() const {
    std::stringstream ss;
    ss << "[CharLinkedList of size " << currSize << " <<";
    Node *curr = front;
    while (curr != nullptr) {
        ss << curr->data;
        curr = curr->next;
    }
    ss << ">>]";
    return ss.str();
}

/*
 * Name: toReverseString
 * Purpose: Return a string representing the CharLinkedList 
 *          in reverse order.
 * Argument: N/A
 * Return: A string representation of the CharLinkedList in reverse order.
 * Effect: N/A
 */
std::string CharLinkedList::toReverseString() const {
    std::stringstream ss;
    ss << "[CharLinkedList of size " << currSize << " <<";
    Node *curr = getNodeAt(currSize - 1);
    while (curr != nullptr) {
        ss << curr->data;
        curr = curr->prev;
    }
    ss << ">>]";
    return ss.str();
}

/*
 * Name: insertAt
 * Purpose: Insert a character at the specified index.
 * Argument: The character to be inserted and the index to insert it. 
 * Return: N/A
 * Effect: Insert the character at the specified index in the CharLinkedList.
 *         Throw a std::range_error if the index is out of bounds.
 */
void CharLinkedList::insertAt(char c, int index) {
    if (index < 0 or index > currSize + 1) {
        throw std::range_error("index (" + std::to_string(index) + 
        ") not in range [0.." + std::to_string(currSize) + "]");
    }
    if (index == 0) {
        front = newNode(c, front, nullptr);
        if (not isEmpty()) {
            front->next->prev = front; 
        }
    } else if (index == currSize) {
        Node *curr = front;
        int curr_index = 0;
        while (curr_index < index - 1) {
            curr = curr->next;
            curr_index++;
        }
        curr->next = newNode(c, nullptr, curr);
    } else {
        Node *curr = front;
        int curr_index = 0;
        while (curr_index < index - 1) {
            curr = curr->next;
            curr_index++;
        }
        curr->next = newNode(c, curr->next, curr);
        curr->next->next->prev = curr->next;
    }
    currSize++;
    return;
}

/*
 * Name: pushAtFront
 * Purpose: Add a character to the front of the CharLinkedList.
 * Argument: The character c to be added. 
 * Return: N/A
 * Effect: Call insertAt method. 
 *         Create a new node with data 'c', pointing to the current front 
 *         as its next node, and set the new node as the 
 *         front of the CharLinkedList.
 */
void CharLinkedList::pushAtFront(char c) {
    insertAt(c, 0);
}

/*
 * Name: pushAtBack
 * Purpose: Add a character to the end of the CharLinkedList.
 * Argument: The character c to be added. 
 * Return: N/A
 * Effect: Call insertAt method. 
 *         If the list is empty, add the character to the front.
 *         Otherwise, add the character to the end of the list.
 */
void CharLinkedList::pushAtBack(char c) {
    insertAt(c, currSize);
}

/*
 * Name: insertInOrder
 * Purpose: Insert a character into the CharLinkedList 
 *          while maintaining ascending alphabetical order.
 * Argument: The character c to be inserted. 
 * Return: N/A
 * Effect: Insert the character into the list in alphabetical order.
 */
void CharLinkedList::insertInOrder(char c) {
    int curr_index = 0;
    Node *curr = front;
    if(isEmpty()) {
        insertAt(c, 0);
        return;
    }
    while (curr != nullptr) {
        if (curr->next == nullptr) {
            if (c > curr->data) {
                insertAt(c, currSize);
            } else {
                insertAt(c, 0);
            }
            return;
        } else if (c <= curr->data){
            insertAt(c, curr_index);
            return;
        } else {
            curr = curr->next; 
            curr_index++;
        }
    }
    currSize++;
}

/*
 * Name: removeAt
 * Purpose: Remove the element at the specified index.
 * Argument: The index of the element to be removed. 
 * Return: N/A
 * Effect: Remove the element at the specified index in the linked list. 
 *         Adjust size of the list accordingly. 
 */
void CharLinkedList::removeAt(int index) {
    if (isEmpty()) {
        throw std::runtime_error("cannot pop from empty LinkedList");
    } 
    if (index < 0 or index >= currSize) {
        throw std::range_error("index (" + std::to_string(index) + 
        ") not in range [0.." + std::to_string(currSize) + ")");
    } 
    Node *curr = getNodeAt(index);
    if (index == 0) {
        if (curr->next != nullptr){
            front = curr->next;
            curr->next->prev = nullptr;
        } else {
            front = nullptr;
        }
    } else if (index == currSize - 1) {
        curr->prev->next = nullptr;
    } else {
        curr->prev->next = curr->next;
        curr->next->prev = curr->prev;
    }
    delete curr;
    currSize--;
    return;
}

/*
 * Name: popFromFront
 * Purpose: Remove the element from the front of the CharLinkedList.
 * Argument: N/A
 * Return: N/A
 * Effect: Call removeAt method to remove the first element. 
 */
void CharLinkedList::popFromFront() {
    removeAt(0);
}

/*
 * Name: popFromBack
 * Purpose: Remove the element from the back of the CharLinkedList.
 * Argument: N/A
 * Return: N/A
 * Effect: Call removeAt method to remove the last element. 
 */
void CharLinkedList::popFromBack() {
    removeAt(currSize - 1);
}

/*
 * Name: RecReplaceAt
 * Purpose: Recursively replace the character at a specified index.
 * Argument: Pointer to the current node, the new character, 
 *           the index, and the count of nodes traversed.
 * Return: N/A
 * Effect: Replace the character at the specified index recursively.
 */
void CharLinkedList::RecReplaceAt(
    Node *curr, char c, int index, int count) const {
    if (index == count) {
        curr->data = c;
        return;
    }
    RecReplaceAt(curr->next, c, index, count + 1);
}

/*
 * Name: replaceAt
 * Purpose: Replace the character at the specified index on the linked list 
 *          with the given character.
 * Argument: The character c for replacement and the index 
 *           for replacement. 
 * Return: N/A
 * Effect: Throw a std::range_error if the index 
 *         is out of the valid range [0..currSize).
 *         Call RecReplaceAt method to replace the character at 
 *         a specified index. 
 */
void CharLinkedList::replaceAt(char c, int index) {
    if (index < 0 or index >= currSize) {
        throw std::range_error("index (" + std::to_string(index) + 
        ") not in range [0.." + std::to_string(currSize) + ")");
    }
    RecReplaceAt(front, c, index, 0);
}

/*
 * Name: concatenate
 * Purpose: Concatenate the characters from the other CharLinkedList object 
 *          to the end of the current CharLinkedList. 
 * Argument: Pointer to the other LinkedList object to concatenate.
 * Return: N/A
 * Effect: Append the characters from the other CharLinkedList object 
 *         to the end of the current CharLinkedList by calling 
 *         pushAtBack method. 
 *         If the current list is empty, call traversing method to create 
 *         new nodes with the other's data in the form of a deep copy. 
 */
void CharLinkedList::concatenate(CharLinkedList *other) {
    if (this == other) {
        int originalSize = currSize; 
        for (int i = 0; i < originalSize; i++) {
            pushAtBack(getNodeAt(i)->data);
        }
        return;
    }
    if (isEmpty()) {
        if (other->currSize == 0) {
            front = nullptr;
            currSize = 0;
        } else {
            traversing(*other); 
        }
        return;
    } else {
        if (other->currSize == 0) {
            return;
        } else {
            for (int i = 0; i < other->currSize; i++) {
                pushAtBack(other->getNodeAt(i)->data);
            }
        }
    }
}



















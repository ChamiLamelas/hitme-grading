/*
 *  unit_tests.h
 *  Ella Han
 *  02/04/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  Uses Matt Russell's unit_test framework to test the CharLinkedList class.
 *  
 */

#include "CharLinkedList.h"
#include <cassert>
#include <iostream>

using namespace std;

// Test for initializing an empty list 
void constructor_empty() {
    CharLinkedList test_list;
    assert(test_list.size() == 0);
    assert(test_list.isEmpty());
}

// Test for initializing a single element list
void constructor_single() {
    CharLinkedList test_list('a');
    assert(test_list.size() == 1);
}

// Test for initializing a list from an array of characters
void constructor_array() {
    char test_array[3] = {'a', 'b', 'c'};
    CharLinkedList test_list(test_array, 3);
    assert(test_list.size() == 3);
    assert(test_list.elementAt(1) == 'b');

    char test_array1[0] = {};
    CharLinkedList test_list1(test_array1, 0);
    assert(test_list1.size() == 0);
}

// Tests correct insertion into an empty LL.
// Afterwards, size should be 1 and element at index 0
// should be the element we inserted.
void insertAt_empty_correct() {
    CharLinkedList test_list;
    test_list.insertAt('a', 0);
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');
}

// Tests incorrect insertion into an empty LL.
// Attempts to call insertAt for index larger than 0.
// This should result in an std::range_error being raised.
void insertAt_empty_incorrect() {
    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
        // insertAt for out-of-range index
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        // if insertAt is correctly implemented, a range_error will be thrown,
        // and we will end up here
        range_error_thrown = true;
        error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0]");
}

// Tests correct insertAt for front of 1-element list.
void insertAt_front_singleton_list() {
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at front
    test_list.insertAt('b', 0);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'a');
}

// Tests correct insertAt for back of 1-element list.
void insertAt_back_singleton_list() {
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at back
    test_list.insertAt('b', 1);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
}

// Test insert in the middle
void insertAt_middle_list() {
    char test_arr[2] = { 'a', 'c' };
    CharLinkedList test_list(test_arr, 2);

    test_list.insertAt('b',1);

    assert(test_list.size() == 3);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    assert(test_list.elementAt(2) == 'c');
}

// Tests calling insertAt for a large number of elements.
// Not only does this test insertAt, it also checks that
// array expansion works correctly.
void insertAt_many_elements() {
    CharLinkedList test_list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.insertAt('a', i);
    }

    assert(test_list.size() == 1000);


    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
}

// Tests insertion into front of a larger list
void insertAt_front_large_list() {
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    test_list.insertAt('y', 0);

    assert(test_list.size() == 10);
    assert(test_list.elementAt(0) == 'y');
    assert(test_list.toString() == 
    "[CharLinkedList of size 10 <<yabczdefgh>>]");
}

// Tests insertion into the back of a larger list
void insertAt_back_large_list() {

    char test_arr[10] = { 'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 10);  

    test_list.insertAt('x', 10);

    assert(test_list.size() == 11);
    assert(test_list.elementAt(10) == 'x');
    assert(test_list.toString() == 
    "[CharLinkedList of size 11 <<yabczdefghx>>]"); 
}

// Tests insertion into the middle of a larger list
void insertAt_middle_large_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.insertAt('z', 3);

    assert(test_list.size() == 9);
    assert(test_list.elementAt(3) == 'z');
    assert(test_list.toString() == 
    "[CharLinkedList of size 9 <<abczdefgh>>]");
}

// Tests out-of-range insertion for a non-empty list.
void insertAt_nonempty_incorrect() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8]");
}

// Test for incorrect retrival of elements on empty list (front)
void empty_list_retrieval_front() {
    CharLinkedList test_list;
    bool runtime_error_thrown = false;
    std::string error_message = "";

    try {
        test_list.first();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot get first of empty LinkedList");
}

// Test for incorrect retrival of elements on empty list (back)
void empty_list_retrieval_back() {
    CharLinkedList test_list;
    bool runtime_error_thrown = false;
    std::string error_message = "";

    try {
        test_list.last();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot get last of empty LinkedList");
}

// Test for copy constructor
void test_for_cc() {
    char originalArr[3] = {'x', 'y', 'z'};
    CharLinkedList test_list(originalArr, 3);
    CharLinkedList copied_list(test_list);
    
    assert(copied_list.size() == 3);
    assert(copied_list.elementAt(0) =='x');
    assert(copied_list.elementAt(1) == 'y');
    assert(copied_list.elementAt(2) =='z');
}

// Test for destructor
void test_destructor() {
    char test_other[9] = {'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(test_other, 9);
    CharLinkedList *test = new CharLinkedList(test_other, 9);
    delete test;
    test = nullptr; 
}

// Test for assignment operator
void test_assignment() {
    char test_data1[5] = {'a', 'b', 'c', 'd', 'e'};
    char test_data2[3] = {'x', 'y', 'z'};
    CharLinkedList test_list1(test_data1, 5);
    CharLinkedList test_list2(test_data2, 3);

    test_list1 = test_list2;

    assert(test_list1.size() == 3);
    assert(test_list2.size() == 3);
    assert(test_list1.first() == 'x');
    assert(test_list2.first() == 'x');
    assert(test_list2.last() == 'z');
    assert(test_list1.last() == 'z');
    assert(test_list1.elementAt(1) == 'y');
    assert(test_list2.elementAt(1) == 'y');
}

// Test for assigning empty to a non-empty linked list
void test_empty_assignment() {
    CharLinkedList test_list1;
    char test_data2[3] = {'x', 'y', 'z'};
    CharLinkedList test_list2(test_data2, 3);

    test_list2 = test_list1;
    assert(test_list1.size() == 0);
    assert(test_list2.size() == 0);

    bool runtime_error_thrown = false;
    std::string error_message = "";

    try {
        test_list2.first();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot get first of empty LinkedList");
}

// Test for assigning a non-empty to an empty linked list
void test_nonempty_assignment() {
    CharLinkedList test_list1;
    char test_data2[3] = {'x', 'y', 'z'};
    CharLinkedList test_list2(test_data2, 3);

    test_list1 = test_list2;
    assert(test_list1.size() == 3);
    assert(test_list2.size() == 3);

    assert(test_list1.first() == 'x');
    assert(test_list2.first() == 'x');
    assert(test_list1.last() == 'z');
    assert(test_list2.last() == 'z');
    assert(test_list1.elementAt(1) == 'y');
    assert(test_list2.elementAt(1) == 'y');
}

// Test for isEmpty method
void test_isEmpty() {
    CharLinkedList test_list;
    assert(test_list.isEmpty());

    char test_data2[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList test_list2(test_data2, 5);
    assert(not test_list2.isEmpty());
    std::cerr << test_list2.isEmpty() << std::endl;
}

// Test for clear
void test_clear() {
    CharLinkedList test_list;
    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.insertAt('a', i);
    }

    test_list.clear();
    assert(test_list.size() == 0);
    assert(test_list.isEmpty());
}

// Test for elementAt (index provided way bigger than actual size)
void test_elementAt_biggerIndex() {
    CharLinkedList test_list;
    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.insertAt('a', i);
    }

    bool range_error_thrown = false;
    std::string error_message = "";

    try {
        test_list.elementAt(100000);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (100000) not in range [0..1000)");
}

// Test for elementAt (index provided way smaller than actual size)
void test_elementAt_smallerIndex() {
    CharLinkedList test_list;
    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.insertAt('a', i);
    }

    bool range_error_thrown = false;
    std::string error_message = "";

    try {
        test_list.elementAt(-9);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (-9) not in range [0..1000)");
}

//  Test case for toString() when the CharLinkedList is empty 
//  or has one or some elements in the list
void test_toString() {
    CharLinkedList test_list;
    assert(test_list.toString() == "[CharLinkedList of size 0 <<>>]");

    char test_data[1] = {'a'};
    CharLinkedList test_list2(test_data, 1);
    assert(test_list2.toString() == "[CharLinkedList of size 1 <<a>>]");

    char test_data3[9] = {'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list3(test_data3, 9);
    assert(test_list3.toString() == 
    "[CharLinkedList of size 9 <<abczdefgh>>]");
}

// Test toString when linked list has non-ASCII inputs or Uppercase Letters
void test_toString_invalid() {
    char test_data[5] = {'a', 'F', 'c', 'd', 'e'};
    CharLinkedList test_list(test_data, 5);
    assert(test_list.toString() == "[CharLinkedList of size 5 <<aFcde>>]");

    char test_data2[5] = {'&', '*', '#', 'd', 'e'};
    CharLinkedList test_list2(test_data2, 5);
    assert(test_list2.toString() == "[CharLinkedList of size 5 <<&*#de>>]");
}

//  Test case for toReverseString() when the CharLinkedList is empty 
//  or has one or some elements in the list
void test_toReverseString() {
    CharLinkedList test_list;
    assert(test_list.toReverseString() == "[CharLinkedList of size 0 <<>>]");

    char test_data[1] = {'a'};
    CharLinkedList test_list2(test_data, 1);
    assert(test_list2.toReverseString() == "[CharLinkedList of size 1 <<a>>]");

    char test_data3[9] = {'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list3(test_data3, 9);
    assert(test_list3.toReverseString() == 
    "[CharLinkedList of size 9 <<hgfedzcba>>]");
}

// Test toReverseString when linked list has non-ASCII 
// inputs or Uppercase Letters
void test_toReverseString_invalid() {
    char test_data[5] = {'a', 'F', 'c', 'd', 'e'};
    CharLinkedList test_list(test_data, 5);
    assert(test_list.toReverseString() == 
    "[CharLinkedList of size 5 <<edcFa>>]");

    char test_data2[5] = {'&', '*', '#', 'd', 'e'};
    CharLinkedList test_list2(test_data2, 5);
    assert(test_list2.toReverseString() == 
    "[CharLinkedList of size 5 <<ed#*&>>]");
}

// Test for pushAtBack
void pushAtBack_empty_correct() { 
    CharLinkedList test_list;
    test_list.pushAtBack('a');
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');
}

// Tests pushAtBack for front of 1-element list
void pushAtBack_singleton_list() {
    CharLinkedList test_list('a');
    test_list.pushAtBack('b');

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
}

// Tests pushAtBack for many-element list
void pushAtBack_many_elements() {
    CharLinkedList test_list;
    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.pushAtBack('a');
    }

    assert(test_list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
}

// Test pushAtBack for large list
void pushAtBack_large_list() {
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    test_list.pushAtBack('y');

    assert(test_list.size() == 10);
    assert(test_list.elementAt(9) == 'y');
    assert(test_list.toString() == 
    "[CharLinkedList of size 10 <<abczdefghy>>]");
}

// Test pushAtFront for empty list
void pushAtFront_empty_correct() { 
    CharLinkedList test_list;
    test_list.pushAtFront('a');
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');
}

// Test pushAtFront for one-element list.
void pushAtFront_singleton_list() {
    CharLinkedList test_list('a');
    test_list.pushAtFront('b');

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'a');
}

// Test pushAtFront for many-element list
void pushAtFront_many_elements() {
    CharLinkedList test_list;
    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.pushAtFront('a');
    }

    assert(test_list.size() == 1000);


    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    } 
}

// Test pushAtFront for large list
void pushAtFront_large_list() {
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    test_list.pushAtFront('y');

    assert(test_list.size() == 10);
    assert(test_list.elementAt(0) == 'y');
    assert(test_list.toString() == 
    "[CharLinkedList of size 10 <<yabczdefgh>>]");
}


// Test insertInOrder for empty list 
void insertInOrder_empty_correct() { 
    CharLinkedList test_list;
    test_list.insertInOrder('a');

    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');
}

// Test insertInOrder for one-element list
void insertInOrder_singleton_list() {
    CharLinkedList test_list('a');
    test_list.insertInOrder('b');

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
}

// Test insertInOrder for one-element list (swapping order)
void insertInOrder_singleton_list2() {
    CharLinkedList test_list('b');
    test_list.insertInOrder('a');

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
}


// Test inserInOrder for many-element list
void insertInOrder_many_elements() {
    CharLinkedList test_list;
    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.insertAt('a', i);
    }

    test_list.insertInOrder('b');
    assert(test_list.size() == 1001);

    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
    assert(test_list.elementAt(1000) == 'b');
}


// Test insertInOrder for many-element list (swapping order)
void insertInOrder_many_elements2() {
    CharLinkedList test_list;
    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.insertAt('b', i);
    }

    test_list.insertInOrder('a');
    assert(test_list.size() == 1001);

    for (int i = 1; i < 1001; i++) {
        assert(test_list.elementAt(i) == 'b');
    }
    assert(test_list.elementAt(0) == 'a'); 
}

// Test for insertInOrder for large list
void insertInOrder_large_list() {
    char test_arr[9] = { 'a', 'b', 'c', 'd', 'e', 'g', 'h' ,'z'};
    CharLinkedList test_list(test_arr, 8);

    test_list.insertInOrder('f');

    assert(test_list.size() == 9);
    assert(test_list.elementAt(5) == 'f');
    assert(test_list.toString() == "[CharLinkedList of size 9 <<abcdefghz>>]");
}

// Test insertInOrder for inserting many elements (include duplicates)
void insertInOrder_manyElement_list() {
    char test_arr[5] = { 'a', 'b', 'e', 'h', 'z'};
    CharLinkedList test_list(test_arr, 5);

    test_list.insertInOrder('f');
    test_list.insertInOrder('g');
    test_list.insertInOrder('a');
    test_list.insertInOrder('d');
    test_list.insertInOrder('h');

    assert(test_list.size() == 10);
    assert(test_list.elementAt(5) == 'f');
    assert(test_list.toString() == 
    "[CharLinkedList of size 10 <<aabdefghhz>>]");
}

// Test popFromFront for one-element list 
void popFromFront_empty_correct() {
    CharLinkedList test_list;
    test_list.insertInOrder('a');
    test_list.popFromFront();
    assert(test_list.size() == 0);
}

// Test popFromFront for one-element list (with insertInOrder)
void popFromFront_singleton_list() {
    CharLinkedList test_list('a');
    test_list.insertInOrder('b');
    test_list.popFromFront();

    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'b');
}

// Test popFromFront for one-element list 
// (swapping order with pushAtBack)
void popFromFront_singleton_list2() {
    CharLinkedList test_list('b');
    test_list.pushAtBack('a');
    test_list.popFromFront();

    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');
}

// Test popFromFront for many-elemnt list
void popFromFront_many_elements() {
    CharLinkedList test_list;
    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.insertAt('a', i);
    }

    test_list.popFromFront();
    assert(test_list.size() == 999);


    for (int i = 0; i < 999; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
}

// Test popFromFront for large list 
void popFromFront_large_list() {
    char test_arr[9] = { 'a', 'b', 'c', 'd', 'e', 'g', 'h' ,'z','h'};
    CharLinkedList test_list(test_arr, 9);

    test_list.popFromFront();

    assert(test_list.size() == 8);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.toString() == 
    "[CharLinkedList of size 8 <<bcdeghzh>>]");
}

// Test popFromBack for empty list
void popFromBack_empty_correct() {
    CharLinkedList test_list;
    test_list.insertInOrder('a');
    test_list.popFromBack();
    assert(test_list.size() == 0);
}

// Test popFromBack for one-element list (with inserInOrder)
void popFromBack_singleton_list() {
    CharLinkedList test_list('a');
    test_list.insertInOrder('b');
    test_list.popFromBack();

    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');
}

// Test popFromBack for one-element list 
// (swapping order with pushAtBack)
void popFromBack_singleton_list2() {
    CharLinkedList test_list('b');
    test_list.pushAtBack('a');
    test_list.popFromBack();

    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'b');
}

// Test popFromBack for many-element list 
void popFromBack_many_elements() {
    CharLinkedList test_list;
    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.insertAt('a', i);
    }

    test_list.popFromBack();
    assert(test_list.size() == 999);


    for (int i = 0; i < 999; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
}

// Test popFromBack for large list
void popFromBack_large_list() {
    char test_arr[9] = { 'a', 'b', 'c', 'd', 'e', 'g', 'h' ,'z','h'};
    CharLinkedList test_list(test_arr, 9);

    test_list.popFromBack();

    assert(test_list.size() == 8);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.toString() == 
    "[CharLinkedList of size 8 <<abcdeghz>>]");
}

// Test removeAt for empty list
void removeAt_empty_incorrect() {
    CharLinkedList test_list;

    bool runtime_error_thrown = false;
    std::string error_message = "";

    try {
        test_list.removeAt(0);
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

// Test removeAt for empty list 
void removeAt_empty_correct() { 
    CharLinkedList test_list;
    test_list.insertInOrder('a');
    test_list.removeAt(0);
    assert(test_list.size() == 0);
}

// Test removeAt for one-element list 
void removeAt_singleton_list() {
    CharLinkedList test_list('a');
    test_list.pushAtBack('b');
    test_list.pushAtBack('c');
    test_list.removeAt(1);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'c');
}

// Test removeAt for many-element list 
void removeAt_many_elements() {
    CharLinkedList test_list;
    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.insertAt('a', i);
    }

    test_list.removeAt(50);
    assert(test_list.size() == 999);


    for (int i = 0; i < 999; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
}


// Test removeAt for large list
void removeAt_large_list() {
    char test_arr[9] = { 'a', 'b', 'c', 'd', 'e', 'g', 'h' ,'z','h'};
    CharLinkedList test_list(test_arr, 9);

    test_list.removeAt(3);

    assert(test_list.size() == 8);
    assert(test_list.elementAt(3) == 'e');
    assert(test_list.toString() == 
    "[CharLinkedList of size 8 <<abceghzh>>]");
}

// Test replaceAt for empty list 
void replaceAt_empty_correct() {
    CharLinkedList test_list;
    test_list.insertInOrder('a');
    test_list.replaceAt('b',0);
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'b');
}

// Test replaceAt for one-element list
void replaceAt_singleton_list() {
    CharLinkedList test_list('a');
    test_list.pushAtBack('b');
    test_list.pushAtBack('c');
    test_list.replaceAt('z',1);

    assert(test_list.size() == 3);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'z');
    assert(test_list.elementAt(2) == 'c');
}

// Test replaceAt for many-element list 
void replaceAt_many_elements() {
    CharLinkedList test_list;
    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.insertAt('a', i);
    }

    test_list.replaceAt('b',50);
    assert(test_list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        if(i == 50){
            assert(test_list.elementAt(i) == 'b');
        }else{
            assert(test_list.elementAt(i) == 'a');
        }
    }
}

// Test replaceAt for large list 
void replaceAt_large_list() {
    char test_arr[9] = { 'a', 'b', 'c', 'd', 'e', 'g', 'h' ,'z','h'};
    CharLinkedList test_list(test_arr, 9);

    test_list.replaceAt('o',3);

    assert(test_list.size() == 9);
    assert(test_list.elementAt(3) == 'o');
    assert(test_list.toString() == 
    "[CharLinkedList of size 9 <<abcoeghzh>>]");
}

// Test concatenate for two empty lists
void concatenate_empty_correct() { 
    CharLinkedList test_list;
    CharLinkedList test_list2;
    test_list.concatenate(&test_list2);
    assert(test_list.size() == 0);
}

// Test concatenate for one empty list on another one-element list
void concatenate_empty_correct2() { 
    CharLinkedList test_list;
    test_list.pushAtBack('b');
    CharLinkedList test_list2;
    test_list.concatenate(&test_list2);
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'b');
}

// Test concatenate for a one-element list on an empty list
void concatenate_empty_correct3() { 
    CharLinkedList test_list;
    CharLinkedList test_list2;
    test_list2.pushAtBack('b');
    test_list.concatenate(&test_list2);

    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'b');
}

// Test concatenate for one-element list on multi-element list
void concatenate_singleton_list() {
    CharLinkedList test_list('a');
    test_list.pushAtBack('b');
    test_list.pushAtBack('c');
    CharLinkedList test_list2;
    test_list2.pushAtBack('b');
    test_list.concatenate(&test_list2);

    assert(test_list.size() == 4);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    assert(test_list.elementAt(2) == 'c');
    assert(test_list.elementAt(3) == 'b');
}

// Test concatenate for one-element list on many-element list
void concatenate_many_elements() {
    CharLinkedList test_list;
    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.insertAt('a', i);
    }
    CharLinkedList test_list2;
    test_list2.pushAtBack('b');
    test_list.concatenate(&test_list2);

    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
    assert(test_list.size() == 1001);
    assert(test_list.elementAt(1000) == 'b');
}

// Test concatenate for multi-element list on large list
void concatenate_large_list() {
    char test_arr[9] = { 'a', 'b', 'c', 'd', 'e', 'g', 'h' ,'z','h'};
    CharLinkedList test_list(test_arr, 9);
    CharLinkedList test_list2;
    test_list2.pushAtBack('b');
    test_list2.pushAtBack('a');
    test_list2.pushAtBack('c');
    test_list.concatenate(&test_list2);

    assert(test_list.size() == 12);
    assert(test_list.toString() == 
    "[CharLinkedList of size 12 <<abcdeghzhbac>>]");
}

// Test concatenate for multi-element list on one-element list
void concatenate_large_list_multi() {
    char test_arr[9] = { 'a', 'b', 'c', 'd', 'e', 'g', 'h' ,'z','h'};
    CharLinkedList test_list(test_arr, 9);
    CharLinkedList test_list2;
    test_list2.pushAtBack('b');
    test_list2.concatenate(&test_list);

    assert(test_list.size() == 10);
    assert(test_list.toString() == 
    "[CharLinkedList of size 10 <<babcdeghzh>>]");
}

// Test concatenate a non-empty linked list with itself
void concatenate_self() {
    char test_arr[9] = { 'a', 'b', 'c', 'd', 'e', 'g', 'h' ,'z','h'};
    CharLinkedList test_list(test_arr, 9);
    test_list.concatenate(&test_list);

    assert(test_list.size() == 18);
    assert(test_list.toString() == 
    "[CharLinkedList of size 18 <<abcdeghzhabcdeghzh>>]");
}







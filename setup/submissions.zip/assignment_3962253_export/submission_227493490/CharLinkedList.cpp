/*
 *  CharLinkedList.cpp
 *  Rowan Cunningham {mcunni01}
 *  {2/1/2024}
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Purpose: A file for the implementation of a CharLinkedList abstract data
 *           type, one that can dynamically change size among other features of
 *           the interface specified in CharLinkedList.h
 *
 */

#include "CharLinkedList.h"
#include <sstream>
#include <stdexcept>

using namespace std;

/*
 * name:      LinkedList default constructor
 * purpose:   initialize an empty LinkedList
 * arguments: none
 * returns:   none
 * effects:   currSize to 0, front and back to nullptr
 */
CharLinkedList::CharLinkedList(){
    front = nullptr;
    back = nullptr;
    currSize = 0;
}

/*
 * name:      LinkedList single character constructor
 * purpose:   initialize a LinkedList with one character
 * arguments: A single character
 * returns:   none
 * effects:   currSize to 1, front and back pointing to new node
 */
CharLinkedList::CharLinkedList(char c){
    front = newNode(c, nullptr, nullptr);
    back = front;
    currSize = 1;
}

/*
 * name:      LinkedList filled array constructor
 * purpose:   initialize a LinkedList with an input array
 * arguments: A character array and the integer size of that array
 * returns:   none
 * effects:   currSize to input size, creating a number of linked nodes with
 *            the input data, and updating front and back
 */
CharLinkedList::CharLinkedList(char arr[], int size){
    //Initialize the list as empty
    front = nullptr;
    back = nullptr;
    currSize = 0;

    //pushAtBack each element of the input array
    for(int i = 0; i < size; i++){
        pushAtBack(arr[i]);
    }
}

/*
 * name:      LinkedList copy constructor
 * purpose:   make a deep copy of a given instance of a list
 * arguments: Another CharLinkedList
 * returns:   none
 * effects:   currSize to size of other LinkedList, creating a number of linked
 *            nodes with the input data, and updating front and back
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other){
    //Initialize the list as empty, if the other list is empty
    if(other.currSize == 0){
        front = nullptr;
        back = nullptr;
        currSize = 0;
        return;
    }

    //Create a one node list
    front = newNode(other.front->data, nullptr, nullptr);
    back = front;
    currSize = 1;

    //Call the recursive function for the rest of the array
    copyConstructorRecursion(other.front->next);
}

/*
 * name:      LinkedList destructor
 * purpose:   free memory associated with the LinkedList
 * arguments: none
 * returns:   none
 * effects:   frees memory allocated by Linkedlist instances
 */
CharLinkedList::~CharLinkedList(){
    //recursively delete the allocated memory
    destructorRecursion(front);
}

/*
 * name:      LinkedList assignment operator
 * purpose:   Assign this CharLinkedList member variables to the same as another
 *            CharLinkedList using a deep copy
 * arguments: The address of another CharlinkedList
 * returns:   This CharLinkedList
 * effects:   Clears the original list and refills it with the elements of the
 *            input list. Also updates currSize, front, and back
 */
CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other){
    //Return if the two arrays are the same
    if(this == &other){
        return *this;
    }

    //Clear the old list
    clear();

    //If the input list is empty, return
    if(other.currSize == 0){
        return *this;
    }

    //Otherwise, create a new node and update front and back
    front = newNode(other.front->data, nullptr, nullptr);
    back = front;
    currSize = 1;

    //The same recursion used in the copy constructor can be used here to fill
    //the rest of the list
    copyConstructorRecursion(other.front->next);

    //Return
    return *this;
}

/*
 * name:      isEmpty
 * purpose:   determines if the LinkedList is empty or not
 * arguments: none
 * returns:   true if LinkedList contains no elements, false otherwise
 * effects:   none
 */
bool CharLinkedList::isEmpty() const{
    return currSize == 0;
}

/*
 * name:      clear
 * purpose:   makes the instance into an empty linked list
 * arguments: none
 * returns:   none
 * effects:   makes the size of the list 0, and front and back nullptr
 */
void CharLinkedList::clear(){
    //The same recursion used in the destructor can be used to free the memory
    //used in the list
    destructorRecursion(front);

    //Update front, back, and currSize to an empty list
    front = nullptr;
    back = nullptr;
    currSize = 0;
}

/*
 * name:      size
 * purpose:   determine the number of items in the LinkedList
 * arguments: none
 * returns:   number of elements currently stored in the LinkedList
 * effects:   none
 */
int CharLinkedList::size() const{
    return currSize;
}

/*
 * name:      first
 * purpose:   gets the first character in the LinkedList
 * arguments: none
 * returns:   the character in the front LinkedList node
 * effects:   throws a runtime error if the LinkedList is empty
 */
char CharLinkedList::first() const{
    if(currSize == 0){
        throw runtime_error("cannot get first of empty LinkedList");
    }
    return front->data;
}

/*
 * name:      last
 * purpose:   gets the last character in the LinkedList
 * arguments: none
 * returns:   the character in the back LinkedList node
 * effects:   throws a runtime error if the LinkedList is empty
 */
char CharLinkedList::last() const{
    if(currSize == 0){
        throw runtime_error("cannot get last of empty LinkedList");
    }
    return back->data;
}

/*
 * name:      elementAt
 * purpose:   gets the character at a provided index in the LinkedList
 * arguments: int of an index in the LinkedList
 * returns:   the character in the LinkedList at the provided index
 * effects:   throws a range error if the index is out of range
 */
char CharLinkedList::elementAt(int index) const{
    //If out of range, construct and throw exception
    if(index < 0 or index >= currSize){
        std::stringstream ss;
        ss << "index (" << index << ") not in range [0.." << currSize << ")";
        throw range_error(ss.str());
    }

    //Call the find index recursive function to find the right node
    Node *tempPtr = findIndexHelper(index);

    //Return the data at that index
    return tempPtr->data;
}

/*
 * name:      toString
 * purpose:   turns the list into a string, and returns it
 * arguments: none
 * returns:   a string representation of the list
 * effects:   none
 */
std::string CharLinkedList::toString() const{
    //Construct string
    std::stringstream ss;
    ss << "[CharLinkedList of size " << currSize << " <<";
    
    //Get the data at each node
    Node *curr = front;
    for(int i = 0; i < currSize; i++){
        ss << curr->data;
        curr = curr->next;
    }
    ss << ">>]";

    //Return string
    return ss.str();
}

/*
 * name:      toReverseString
 * purpose:   turns the list into a string starting from the back, 
 *            and returns it
 * arguments: none
 * returns:   a string representation of the list backwards
 * effects:   none
 */
std::string CharLinkedList::toReverseString() const{
    //Construct reverse string
    std::stringstream ss;
    ss << "[CharLinkedList of size " << currSize << " <<";
    Node *curr = back;

    //Get the data of each node starting at the back
    for(int i = 0; i < currSize; i++){
        ss << curr->data;
        curr = curr->prev;
    }
    ss << ">>]";

    //Return string
    return ss.str();
}

/*
 * name:      pushAtBack
 * purpose:   push the provided character into the back of the LinkedList
 * arguments: a character to add to the back of the list
 * returns:   none
 * effects:   increases num elements of LinkedList by 1,
 *            adds element in a new node to list
 */
void CharLinkedList::pushAtBack(char c){
    //If the list is empty, update it as a single character list
    if(currSize == 0){
        front = newNode(c, nullptr, nullptr);
        back = front;
    
    //Otherwise, create the node and update the back pointer and inner pointers
    }else{
        back = newNode(c, nullptr, back);
        back->prev->next = back;
    }

    //Increase size
    currSize++;
}

/*
 * name:      pushAtFront
 * purpose:   push the provided character into the front of the LinkedList
 * arguments: a character to add to the front of the list
 * returns:   none
 * effects:   increases num elements of LinkedList by 1,
 *            adds element in a new node to list
 */
void CharLinkedList::pushAtFront(char c){
    //If the list is empty, update it as a single character list
    if(currSize == 0){
        front = newNode(c, nullptr, nullptr);
        back = front;

    //Otherwise, create the node and update the front pointer and inner pointers
    }else{
        front = newNode(c, front, nullptr);
        front->next->prev = front;
    }

    //Increase size
    currSize++;
}

/*
 * name:      insertAt
 * purpose:   insert the provided character at the provided index 
 *            into the LinkedList
 * arguments: a character to add into the list, the index where the character
 *            will be inserted
 * returns:   none
 * effects:   increases num elements of LinkedList by 1,
 *            adds element in a new node to list. 
 *            Throws range error if index is out of range
 */
void CharLinkedList::insertAt(char c, int index){
    //If out of range, construct and throw exception
    if(index < 0 or index > currSize){
        std::stringstream ss;
        ss << "index (" << index << ") not in range [0.." << currSize << "]";
        throw range_error(ss.str());
    }

    //If the element is being added at the back, use the pushAtBack function
    if(index == currSize){
        pushAtBack(c);
        return;
    
    //If the element is being added to the front, use the pushAtFront function
    }else if(index == 0){
        pushAtFront(c);
        return;
    }

    //Otherwise, use the find index recursion to find the right node
    Node *tempPtr = findIndexHelper(index);

    //Create the new node with the correct next and prev pointers. Update
    //the surrounding pointers.
    Node *new_node = newNode(c, tempPtr, tempPtr->prev);
    tempPtr->prev->next = new_node;
    tempPtr->prev = new_node;

    currSize++;
}

/*
 * name:      insertInOrder
 * purpose:   insert the provided character into the LinkedList in ASCII order
 * arguments: a character to add into the list
 * returns:   none
 * effects:   increases num elements of LinkedList by 1,
 *            adds element in a new node to list
 */
void CharLinkedList::insertInOrder(char c){
    //If the array is empty, call pushAtFront
    if(currSize == 0){
        pushAtFront(c);
    
    //If the first element is larger than the input element, call pushAtFront
    }else if(front->data > c){
        pushAtFront(c);

    }else{
        //Call the inOrder recursive function to find the right node
        Node *tempPtr = inOrderRecursion(front, c);

        //Create a new node with the proper next and prev pointers
        Node *new_node = newNode(c, tempPtr->next, tempPtr);

        //If the node is at the back, update the back pointer
        if(tempPtr == back){
            back = new_node;

        //Update the surrounding pointers
        }else{
            tempPtr->next->prev = new_node;
        }
        tempPtr->next = new_node;

        //Increase size
        currSize++;
    }
}

/*
 * name:      popFromFront
 * purpose:   remove the first character from the LinkedList
 * arguments: none
 * returns:   none
 * effects:   decreases num elements of LinkedList by 1,
 *            removes element and node from list. Throws runtime error if empty
 */
void CharLinkedList::popFromFront(){
    //If empty, throw error
    if(currSize == 0){
        throw runtime_error("cannot pop from empty LinkedList");

    //If single character list, delete element and update front and back
    }else if(currSize == 1){
        delete front;
        front = nullptr;
        back = nullptr;
    
    //otherwise, update front and surrounding pointers and delete front
    }else{
        Node *tempPtr = front;
        front->next->prev = nullptr;
        front = front->next;
        delete tempPtr;
    }

    //decrease size
    currSize--;
}

/*
 * name:      popFromBack
 * purpose:   remove the last character from the LinkedList
 * arguments: none
 * returns:   none
 * effects:   decreases num elements of LinkedList by 1,
 *            removes element and node from list. Throws runtime error if empty
 */
void CharLinkedList::popFromBack(){
    //If empty, throw error
    if(currSize == 0){
        throw runtime_error("cannot pop from empty LinkedList");

    //If single character list, delete element and update front and back
    }else if(currSize == 1){
        delete back;
        front = nullptr;
        back = nullptr;
    
    //Otherwise, update back and surrounding pointers and delete back
    }else{
        Node *tempPtr = back;
        back->prev->next = nullptr;
        back = back->prev;
        delete tempPtr;
    }

    //decrease size
    currSize--;
}

/*
 * name:      removeAt
 * purpose:   remove the character from the LinkedList at the given index
 * arguments: the index where the character will be removed
 * returns:   none
 * effects:   decreases num elements of LinkedList by 1, removes element and 
 *            node from list. Throws range error if out of range
 */
void CharLinkedList::removeAt(int index){
    //If out of range, construct and throw exception
    if(index < 0 or index >= currSize){
        std::stringstream ss;
        ss << "index (" << index << ") not in range [0.." << currSize << ")";
        throw range_error(ss.str());
    }

    //If single char list, call popFromFront. Else, use find index recursion
    if(currSize == 1){
        popFromFront();
    }else{
        Node *tempPtr = findIndexHelper(index);

        //Update previous and following pointers
        if(tempPtr->prev == nullptr){
            front = tempPtr->next;
        }else{
            tempPtr->prev->next = tempPtr->next;
        }
        if(tempPtr->next == nullptr){
            back = tempPtr->prev;
        }else{
            tempPtr->next->prev = tempPtr->prev;
        }
        //decrease size and delete
        currSize--;
        delete tempPtr;
    }
}

/*
 * name:      replaceAt
 * purpose:   replace the character at the provided index with the provided
 *            character
 * arguments: a character to add into the list, the index where the character
 *            will be inserted
 * returns:   none
 * effects:   replaces one element with another. Throws range error if index
 *            is out of range.
 */
void CharLinkedList::replaceAt(char c, int index){
    //If out of range, construct and throw exception
    if(index < 0 or index >= currSize){
        std::stringstream ss;
        ss << "index (" << index << ") not in range [0.." << currSize << ")";
        throw range_error(ss.str());
    }

    //Find index
    Node *tempPtr = findIndexHelper(index);

    //Create a new node with the pointers of the element at that index
    Node *new_node = newNode(c, tempPtr->next, tempPtr->prev);

    //Adjust previous pointers
    if(tempPtr == front){
        front = new_node;
    }else{
        tempPtr->prev->next = new_node;
    }
    //Adjust following pointers
    if(tempPtr == back){
        back = new_node;
    }else{
        tempPtr->next->prev = new_node;
    }

    //Delete old element at index
    delete tempPtr;
}

/*
 * name:      concatenate
 * purpose:   add the characters of a provided CharLinkedList to the back of
 *            this CharLinkedList
 * arguments: a pointer to another CharLinkedList
 * returns:   none
 * effects:   adds the characters of a provided CharLinkedList to the back of
 *            this CharLinkedList. Updates currSize.
 */
void CharLinkedList::concatenate(CharLinkedList *other){
    //If the list is being concatenated to itself, call a special recursion
    if(other->front == front){
        selfConcatenateRecursion(other->front, currSize);
        return;
    }

    //Otherwise, the copyConstructor recursion works
    copyConstructorRecursion(other->front);
}

/*
 * name:      newNode
 * purpose:   creates and initializes a new Node
 * arguments: a char to store in the Node, a Node pointer to the previous Node,
 *            and a Node pointer to the next Node.
 * returns:   a pointer to the new Node
 * effects:   creates a new node and updates its data, next, and prev
 */
CharLinkedList::Node *CharLinkedList::newNode(char c, Node *next, Node *prev){
    Node *new_node = new Node;
    new_node->data = c;
    new_node->next = next;
    new_node->prev = prev;
    return new_node;
}

/*
 * name:      destructorRecursion
 * purpose:   delete all elements of a list by recursively looping through it
 * arguments: A node pointer to the current node
 * returns:   none
 * effects:   deallocates all memory used by the list's Nodes
 */
void CharLinkedList::destructorRecursion(Node *curr){
    //Base Case
    if(curr == nullptr){
        return;

    //Recursive Case
    }else{
        Node *tempPtr = curr->next;
        delete curr;
        destructorRecursion(tempPtr);
    }
}

/*
 * name:      copyConstructorRecursion
 * purpose:   fill a new list by recursively looping through a second input list
 * arguments: A node pointer to the next node
 * returns:   none
 * effects:   If the list being copied is more than one element, it fills the
 *            rest of the new list. Otherwise, it just returns.
 */
void CharLinkedList::copyConstructorRecursion(Node *nextNode){
    //Base Case
    if(nextNode == nullptr){
        return;
    
    //Recursive Case
    }else{
        pushAtBack(nextNode->data);
        copyConstructorRecursion(nextNode->next);
    }
}

/*
 * name:      selfConcatenateRecursion
 * purpose:   recursively add a list to the back of itself
 * arguments: A node pointer to the next node, an int count of how many
 *            elements are remaining to loop through
 * returns:   none
 * effects:   Recursively adds a list to the back of itself. Size increases.
 */
void CharLinkedList::selfConcatenateRecursion(Node *nextNode, int count){
    //Base Case
    if(nextNode == nullptr or count <= 0){
        return;
    
    //Recursive Case
    }else{
        pushAtBack(nextNode->data);
        count--;
        selfConcatenateRecursion(nextNode->next, count);
    }
}

/*
 * name:      findIndexHelper
 * purpose:   a helper function used to find an index in a LinkedList
 * arguments: An int index that should be located
 * returns:   A pointer to the Node at the correct index
 * effects:   Locates and returns a Node in a LinkedList
 */
CharLinkedList::Node *CharLinkedList::findIndexHelper(int index) const{
    Node *tempPtr = nullptr;

    //If the element is in the front half of the LinkedList, start at front, go
    //forwards, and go an index number of elements
    if(index <= (currSize - 1) / 2){
        tempPtr = findIndexRecursion(front, true, index);

    //If the element is in the back half of the LinkedLIst, start at back, go
    //backwards, and go currSize - 1 - index number of elements 
    }else{
        tempPtr = findIndexRecursion(back, false, (currSize - 1 - index));  
    }

    //Return the Node at the index
    return tempPtr;
}

/*
 * name:      findIndexRecursion
 * purpose:   find an element at a particular index in the list with recursion
 * arguments: A node pointer to the current node, a bool showing which direction
 *            to move (true if forward, false if backward), and an int count
 *            number of elements to move
 * returns:   A pointer to the Node at the correct index
 * effects:   Locates and returns a Node in a LinkedList
 */
CharLinkedList::Node *CharLinkedList::findIndexRecursion(Node *tempPtr, 
                                                    bool dir, int count) const{
    //Safety base case
    if(tempPtr == nullptr){
        return nullptr;

    //Base case. When count is empty, return the Node
    }else if (count <= 0){
        return tempPtr;

    //Recursive Cases
    }else{
        //Decrease count
        count--;

        //If moving forwards, go to the next Node
        if(dir){
            return findIndexRecursion(tempPtr->next, dir, count);

        //If moving backwards, go to the previous Node
        }else{
            return findIndexRecursion(tempPtr->prev, dir, count);
        }
    }
}

/*
 * name:      inOrderRecursion
 * purpose:   Find the index in the list where the provided character fits in 
 *            ASCII order
 * arguments: A node pointer to the current node, the char c being input
 * returns:   A pointer to the Node at the correct index
 * effects:   Finds and returns the index where c will fit in ASCII order
 */
CharLinkedList::Node *CharLinkedList::inOrderRecursion(Node *tempPtr, char c){ 
    //Base case for end of list
    if(tempPtr->next == nullptr){
        return tempPtr;

    //Base case for next element being greater
    }else if(tempPtr->next->data >= c){
        return tempPtr;

    //Recursive case, move on to next element
    }else{
        return inOrderRecursion(tempPtr->next, c);
    }
}
/*
 *  unit_tests.h
 *  Rowan Cunningham {mcunni01}
 *  {2/1/2024}
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  Thoroughly tests the member functions, including edge cases, of a
 *  CharLinkedList ADT.
 *
 */
#include "CharLinkedList.h"
#include <cassert>

/*
 * setUpTest
 * Make sure syntax of files is correct
 */
void setUpTest(){
}

/*
 * basicConstructorTest
 * Make sure no fatal errors/memory leaks in the default constructor
 */
void basicConstructorTest(){
    CharLinkedList list;
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}

/*
 * oneCharConstructorTest
 * Make sure no fatal errors/memory leaks in the one character constructor
 */
void oneCharConstructorTest(){
    CharLinkedList list('r');
    assert(list.toString() == "[CharLinkedList of size 1 <<r>>]");
}

/*
 * arrConstructorTest
 * Make sure no fatal errors/memory leaks in the full array constructor
 */
void arrConstructorTest(){
    char arr[5] = {'R','o','w','a','n'};
    CharLinkedList list(arr, 5);

    assert(list.toString() == "[CharLinkedList of size 5 <<Rowan>>]");
}

/*
 * pushAtBackEmpty
 * Make sure pushAtBack works on an empty list
 */
void pushAtBackEmpty(){
    CharLinkedList list;
    list.pushAtBack('R');

    assert(list.toString() == "[CharLinkedList of size 1 <<R>>]");
}

/*
 * pushAtBackEmptyRepeated
 * Make sure pushAtBack works on an empty list several times
 */
void pushAtBackEmptyRepeated(){
    //Create empty list
    CharLinkedList list;

    //Insert characters
    list.pushAtBack('R');
    list.pushAtBack('o');
    list.pushAtBack('w');
    list.pushAtBack('a');
    list.pushAtBack('n');

    //Test
    assert(list.toString() == "[CharLinkedList of size 5 <<Rowan>>]");
}

/*
 * isEmptyTest
 * Make sure a basic constructor list is empty and a one character constructor
 * list is not
 */
void isEmptyTest(){
    //Create empty list and 1-element list
    CharLinkedList list1;
    CharLinkedList list2('r');

    //Ensure one is empty and the other is not
    assert(list1.isEmpty());
    assert(not(list2.isEmpty()));
}

/*
 * clearTest
 * Make sure a cleared list is empty
 */
void clearTest(){
    CharLinkedList list('r');

    assert(not(list.isEmpty()));
    list.clear();
    assert(list.isEmpty());
}

/*
 * clearThenAdd
 * Make sure a cleared list can be added to
 */
void clearThenAdd(){
    CharLinkedList list('r');

    list.clear();
    assert(list.isEmpty());

    list.pushAtBack('C');
    assert(list.toString() == "[CharLinkedList of size 1 <<C>>]");
}

/*
 * sizeTest
 * Make sure the size is properly reported after all three constructors
 */
void sizeTest(){
    CharLinkedList list1;
    CharLinkedList list2('r');
    char arr[5] = {'R','o','w','a','n'};
    CharLinkedList list3(arr, 5);

    assert(list1.size() == 0);
    assert(list2.size() == 1);
    assert(list3.size() == 5);

    list3.clear();
    assert(list3.size() == 0);
}

/*
 * firstTest
 * Make sure first correctly returns the first character
 */
void firstTest(){
    char arr[5] = {'R','o','w','a','n'};
    CharLinkedList list(arr, 5);

    char c = list.first();
    assert(c == 'R');
}

/*
 * firstTestEmpty
 * Make sure an error is thrown for running first on an empty list
 */
void firstTestEmpty(){
    // var to track whether runtime_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList list;
    try {
        // first for empty linkedlist
        char c = list.first();
    }
    catch (const std::runtime_error &e) {
        // if first is correctly implemented, a runtime_error will be thrown,
        // and we will end up here
        runtime_error_thrown = true;
        error_message = e.what();
    }

    // out here, we make our assertions
    assert(runtime_error_thrown);
    assert(error_message == "cannot get first of empty LinkedList");
}

/*
 * lastTest
 * Make sure last correctly returns the last character
 */
void lastTest(){
    char arr[5] = {'R','o','w','a','n'};
    CharLinkedList list(arr, 5);

    char c = list.last();
    assert(c == 'n');
}

/*
 * lastTestEmpty
 * Make sure an error is thrown for running last on an empty list
 */
void lastTestEmpty(){
    // var to track whether runtime_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList list;
    try {
        // last for empty arraylist
        char c = list.last();
    }
    catch (const std::runtime_error &e) {
        // if last is correctly implemented, a runtime_error will be thrown,
        // and we will end up here
        runtime_error_thrown = true;
        error_message = e.what();
    }

    // out here, we make our assertions
    assert(runtime_error_thrown);
    assert(error_message == "cannot get last of empty LinkedList");
}

/*
 * stringsTests
 * Make sure toString and toReverseString correctly print for empty and not list
 */
void stringsTests(){
    //create lists
    CharLinkedList list1;
    char arr[5] = {'R','o','w','a','n'};
    CharLinkedList list2(arr, 5);

    //test toString
    assert(list1.toString() == "[CharLinkedList of size 0 <<>>]");
    assert(list2.toString() == "[CharLinkedList of size 5 <<Rowan>>]");

    //test toReverseString
    std::string s = list1.toReverseString();
    assert(s == "[CharLinkedList of size 0 <<>>]");
    s = list2.toReverseString();
    assert(s == "[CharLinkedList of size 5 <<nawoR>>]");
}

/*
 * pushAtBackNotEmpty
 * Make sure pushAtBack works on a nonempty list
 */
void pushAtBackNotEmpty(){
    char arr[5] = {'R','o','w','a','n'};
    CharLinkedList list(arr, 5);

    list.pushAtBack('!');
    list.pushAtBack('?');

    assert(list.toString() == "[CharLinkedList of size 7 <<Rowan!?>>]");
    assert(list.toReverseString() == "[CharLinkedList of size 7 <<?!nawoR>>]");
}

/*
 * pushAtFrontEmpty
 * Make sure pushAtFront works on an empty list
 */
void pushAtFrontEmpty(){
    CharLinkedList list;

    list.pushAtFront('R');
    list.pushAtFront('o');
    list.pushAtFront('w');
    list.pushAtFront('a');
    list.pushAtFront('n');

    assert(list.toString() == "[CharLinkedList of size 5 <<nawoR>>]");
    assert(list.toReverseString() == "[CharLinkedList of size 5 <<Rowan>>]");
}

/*
 * pushAtFrontNotEmpty
 * Make sure pushAtFront works on a nonempty list
 */
void pushAtFrontNotEmpty(){
    char arr[5] = {'R','o','w','a','n'};
    CharLinkedList list(arr, 5);

    list.pushAtFront('!');
    list.pushAtFront('?');

    assert(list.toString() == "[CharLinkedList of size 7 <<?!Rowan>>]");
    assert(list.toReverseString() == "[CharLinkedList of size 7 <<nawoR!?>>]");
}


/*
 * popFromFrontEmpty
 * Make sure an error is thrown for running popFromFront on an empty list
 */
void popFromFrontEmpty(){
    // var to track whether runtime_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList list;
    try {
    list.popFromFront();
    }
    catch (const std::runtime_error &e) {
    // if popFromFront is correctly implemented, a runtime_error will be thrown,
    // and we will end up here
    runtime_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

/*
 * popFromFrontOne
 * Make sure popFromFront works on a list with one character
 */
void popFromFrontOne(){
    CharLinkedList list('a');

    list.popFromFront();

    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
    assert(list.toReverseString() == "[CharLinkedList of size 0 <<>>]");
}

/*
 * popFromFrontSeveral
 * Make sure popFromFront works several times on a list
 */
void popFromFrontSeveral(){
    char arr[5] = {'R','o','w','a','n'};
    CharLinkedList list(arr, 5);

    list.popFromFront();
    assert(list.toString() == "[CharLinkedList of size 4 <<owan>>]");
    assert(list.toReverseString() == "[CharLinkedList of size 4 <<nawo>>]");
    
    list.popFromFront();
    assert(list.toString() == "[CharLinkedList of size 3 <<wan>>]");
    assert(list.toReverseString() == "[CharLinkedList of size 3 <<naw>>]");
    
    list.popFromFront();
    assert(list.toString() == "[CharLinkedList of size 2 <<an>>]");
    assert(list.toReverseString() == "[CharLinkedList of size 2 <<na>>]");
    
    list.popFromFront();
    assert(list.toString() == "[CharLinkedList of size 1 <<n>>]");
    assert(list.toReverseString() == "[CharLinkedList of size 1 <<n>>]");
    
    list.popFromFront();
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
    assert(list.toReverseString() == "[CharLinkedList of size 0 <<>>]");
}

/*
 * popFromBackEmpty
 * Make sure an error is thrown for running popFromBack on an empty list
 */
void popFromBackEmpty(){
    // var to track whether runtime_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList list;
    try {
        list.popFromBack();
    }
    catch (const std::runtime_error &e) {
        // if popFromFront is correctly implemented, a runtime_error will be
        // thrown, and we will end up here
        runtime_error_thrown = true;
        error_message = e.what();
    }

    // out here, we make our assertions
    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

/*
 * popFromBackOne
 * Make sure popFromBack works on a list with one character
 */
void popFromBackOne(){
    CharLinkedList list('a');

    list.popFromBack();

    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
    assert(list.toReverseString() == "[CharLinkedList of size 0 <<>>]");

}

/*
 * popFromBackSeveral
 * Make sure popFromBack works several times on a list
 */
void popFromBackSeveral(){
    char arr[5] = {'R','o','w','a','n'};
    CharLinkedList list(arr, 5);

    list.popFromBack();
    assert(list.toString() == "[CharLinkedList of size 4 <<Rowa>>]");
    assert(list.toReverseString() == "[CharLinkedList of size 4 <<awoR>>]");
    
    list.popFromBack();
    assert(list.toString() == "[CharLinkedList of size 3 <<Row>>]");
    assert(list.toReverseString() == "[CharLinkedList of size 3 <<woR>>]");
    
    list.popFromBack();
    assert(list.toString() == "[CharLinkedList of size 2 <<Ro>>]");
    assert(list.toReverseString() == "[CharLinkedList of size 2 <<oR>>]");
    
    list.popFromBack();
    assert(list.toString() == "[CharLinkedList of size 1 <<R>>]");
    assert(list.toReverseString() == "[CharLinkedList of size 1 <<R>>]");
    
    list.popFromBack();
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
    assert(list.toReverseString() == "[CharLinkedList of size 0 <<>>]");
}

/*
 * copyConstructorFiveChar
 * Make sure no fatal errors/memory leaks in the copy constructor
 */
void copyConstructorFiveChar(){
    char arr[5] = {'R','o','w','a','n'};
    CharLinkedList list(arr, 5);
    CharLinkedList list2(list);

    assert(list.toString() == "[CharLinkedList of size 5 <<Rowan>>]");
    assert(list.toReverseString() == "[CharLinkedList of size 5 <<nawoR>>]");
    
    assert(list2.toString() == "[CharLinkedList of size 5 <<Rowan>>]");
    assert(list2.toReverseString() == "[CharLinkedList of size 5 <<nawoR>>]");
}

/*
 * copyConstructorFiveChar
 * Make sure no fatal errors/memory leaks in the copy constructor
 */
void copyConstructorOneChar(){
    CharLinkedList list('a');
    CharLinkedList list2(list);
    
    assert(list.toString() == "[CharLinkedList of size 1 <<a>>]");
    assert(list.toReverseString() == "[CharLinkedList of size 1 <<a>>]");
    
    assert(list2.toString() == "[CharLinkedList of size 1 <<a>>]");
    assert(list2.toReverseString() == "[CharLinkedList of size 1 <<a>>]");
}

/*
 * copyConstructorFiveChar
 * Make sure no fatal errors/memory leaks in the copy constructor
 */
void copyConstructorEmpty(){
    CharLinkedList list;
    CharLinkedList list2(list);
    
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
    assert(list.toReverseString() == "[CharLinkedList of size 0 <<>>]");
    
    assert(list2.toString() == "[CharLinkedList of size 0 <<>>]");
    assert(list2.toReverseString() == "[CharLinkedList of size 0 <<>>]");
}

/*
 * assignmentOperatorSameObject
 * Make sure assignment operator works when the other object is itself
 */
void assignmentOperatorSameObject(){
    char arr[5] = {'R','o','w','a','n'};
    CharLinkedList list1(arr, 5);
    
    list1 = list1;
    
    assert(list1.toString() == "[CharLinkedList of size 5 <<Rowan>>]");
    assert(list1.toReverseString() == "[CharLinkedList of size 5 <<nawoR>>]");
}

/*
 * assignmentOperatorEmpty
 * Make sure assignment operator works when the other object is empty
 */
void assignmentOperatorEmpty(){
    char arr[5] = {'R','o','w','a','n'};
    CharLinkedList list1(arr, 5);
    CharLinkedList list2;
    
    list1 = list2;
    
    assert(list1.toString() == "[CharLinkedList of size 0 <<>>]");
    assert(list1.toReverseString() == "[CharLinkedList of size 0 <<>>]");
    
    assert(list2.toString() == "[CharLinkedList of size 0 <<>>]");
    assert(list2.toReverseString() == "[CharLinkedList of size 0 <<>>]");
}

/*
 * assignmentOperatorIntoEmpty
 * Make sure assignment operator works when this object is empty
 */
void assignmentOperatorIntoEmpty(){
    char arr[5] = {'R','o','w','a','n'};
    CharLinkedList list1(arr, 5);
    CharLinkedList list2;
    
    list2 = list1;
    
    assert(list1.toString() == "[CharLinkedList of size 5 <<Rowan>>]");
    assert(list1.toReverseString() == "[CharLinkedList of size 5 <<nawoR>>]");
    
    assert(list2.toString() == "[CharLinkedList of size 5 <<Rowan>>]");
    assert(list2.toReverseString() == "[CharLinkedList of size 5 <<nawoR>>]");
}

/*
 * assignmentOperatorBigger
 * Make sure assignment operator works when the other object is bigger
 */
void assignmentOperatorBigger(){
    char arr1[5] = {'R','o','w','a','n'};
    CharLinkedList list1(arr1, 5);
    char arr2[6] = {'I','s','C','o','o','l'};
    CharLinkedList list2(arr2, 6);
    
    list1 = list2;
    
    assert(list1.toString() == "[CharLinkedList of size 6 <<IsCool>>]");
    assert(list1.toReverseString() == "[CharLinkedList of size 6 <<looCsI>>]");
    
    assert(list2.toString() == "[CharLinkedList of size 6 <<IsCool>>]");
    assert(list2.toReverseString() == "[CharLinkedList of size 6 <<looCsI>>]");
}

/*
 * assignmentOperatorSmaller
 * Make sure assignment operator works when the other object is smaller
 */
void assignmentOperatorSmaller(){
    char arr1[5] = {'R','o','w','a','n'};
    CharLinkedList list1(arr1, 5);
    char arr2[6] = {'I','s','C','o','o','l'};
    CharLinkedList list2(arr2, 6);
    
    list2 = list1;
    
    assert(list1.toString() == "[CharLinkedList of size 5 <<Rowan>>]");
    assert(list1.toReverseString() == "[CharLinkedList of size 5 <<nawoR>>]");
    
    assert(list2.toString() == "[CharLinkedList of size 5 <<Rowan>>]");
    assert(list2.toReverseString() == "[CharLinkedList of size 5 <<nawoR>>]");
}

/*
 * concatenateEmpty
 * Make sure concatenate works adding an empty list to a filled list
 */
void concatenateEmpty(){
    char arr[5] = {'R','o','w','a','n'};
    CharLinkedList list1(arr, 5);
    CharLinkedList list2;
    
    list1.concatenate(&list2);
    
    assert(list1.toString() == "[CharLinkedList of size 5 <<Rowan>>]");
    assert(list1.toReverseString() == "[CharLinkedList of size 5 <<nawoR>>]");
    
    assert(list2.toString() == "[CharLinkedList of size 0 <<>>]");
    assert(list2.toReverseString() == "[CharLinkedList of size 0 <<>>]");
}

/*
 * concatenateToEmpty
 * Make sure concatenate works adding an filled list to an empty list
 */
void concatenateToEmpty(){
    CharLinkedList list1;
    char arr[5] = {'R','o','w','a','n'};
    CharLinkedList list2(arr, 5);
    
    list1.concatenate(&list2);
    
    assert(list1.toString() == "[CharLinkedList of size 5 <<Rowan>>]");
    assert(list1.toReverseString() == "[CharLinkedList of size 5 <<nawoR>>]");
    
    assert(list2.toString() == "[CharLinkedList of size 5 <<Rowan>>]");
    assert(list2.toReverseString() == "[CharLinkedList of size 5 <<nawoR>>]");
}

/*
 * concatenateTwoEmpty
 * Make sure concatenate works with two empty lists
 */
void concatenateTwoEmpty(){
    CharLinkedList list1;
    CharLinkedList list2;
    
    list1.concatenate(&list2);
    
    assert(list1.toString() == "[CharLinkedList of size 0 <<>>]");
    assert(list1.toReverseString() == "[CharLinkedList of size 0 <<>>]");
    
    assert(list2.toString() == "[CharLinkedList of size 0 <<>>]");
    assert(list2.toReverseString() == "[CharLinkedList of size 0 <<>>]");
}

/*
 * concatenateTwoFull
 * Make sure concatenate works with two filled lists
 */
void concatenateTwoFull(){
    char arr1[3] = {'Y','a','y'};
    CharLinkedList list1(arr1, 3);
    char arr2[4] = {'C','o','o','l'};
    CharLinkedList list2(arr2, 4);
    
    list1.concatenate(&list2);
    
    assert(list1.toString() == "[CharLinkedList of size 7 <<YayCool>>]");
    assert(list1.toReverseString() == "[CharLinkedList of size 7 <<looCyaY>>]");
    
    assert(list2.toString() == "[CharLinkedList of size 4 <<Cool>>]");
    assert(list2.toReverseString() == "[CharLinkedList of size 4 <<looC>>]");
}

/*
 * concatenateSelf
 * Make sure concatenate works with itself
 */
void concatenateSelf(){
    char arr[3] = {'Y','a','y'};
    CharLinkedList list(arr, 3);
    
    list.concatenate(&list);
    
    assert(list.toString() == "[CharLinkedList of size 6 <<YayYay>>]");
    assert(list.toReverseString() == "[CharLinkedList of size 6 <<yaYyaY>>]");
}

/*
 * elementAtTest
 * Make sure elementAt correctly returns at front, back, and middle of the list
 */
void elementAtTest(){
    char arr[5] = {'R','o','w','a','n'};
    CharLinkedList list(arr, 5);
    
    char c = list.elementAt(0);
    assert(c == 'R');
    
    c = list.elementAt(2);
    assert(c =='w');
    
    c = list.elementAt(1);
    assert(c == 'o');
    
    c = list.elementAt(3);
    assert(c == 'a');
    
    c = list.elementAt(4);
    assert(c == 'n');
}

/*
 * elementAtEmpty
 * Make sure an error is thrown for running elementAt on an empty list
 */
void elementAtEmpty(){
    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList list;
    try {
        // elementAt for empty linkedlist
        char c = list.elementAt(0);
    }
    catch (const std::range_error &e) {
        // if elementAt is correctly implemented, a range_error will be thrown,
        // and we will end up here
        range_error_thrown = true;
        error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (0) not in range [0..0)");
}

/*
 * elementAtNegative
 * Make sure an error is thrown for running elementAt at a negative index
 */
void elementAtNegative(){
    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    char arr[5] = {'R','o','w','a','n'};
    CharLinkedList list(arr, 5);
    try {
        char c = list.elementAt(-1);
    }
    catch (const std::range_error &e) {
        // if elementAt is correctly implemented, a range_error will be thrown,
        // and we will end up here
        range_error_thrown = true;
        error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (-1) not in range [0..5)");
}

/*
 * elementAtSize
 * Make sure an error is thrown for running elementAt with an index at currSize
 */
void elementAtSize(){
    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    char arr[5] = {'R','o','w','a','n'};
    CharLinkedList list(arr, 5);
    try {
        char c = list.elementAt(5);
    }
    catch (const std::range_error &e) {
        // if elementAt is correctly implemented, a range_error will be thrown,
        // and we will end up here
        range_error_thrown = true;
        error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (5) not in range [0..5)");
}

/*
 * elementAtOutOfRange
 * Make sure an error is thrown for running elementAt with an index above size
 */
void elementAtOutOfRange(){
    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    char arr[5] = {'R','o','w','a','n'};
    CharLinkedList list(arr, 5);
    try {
        char c = list.elementAt(42);
    }
    catch (const std::range_error &e) {
        // if elementAt is correctly implemented, a range_error will be thrown,
        // and we will end up here
        range_error_thrown = true;
        error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..5)");
}

/*
 * elementAtOneChar
 * Make sure elementAt works on a one char list
 */
void elementAtOneChar(){
    CharLinkedList list('a');
    
    char c = list.elementAt(0);
    assert(c == 'a');
}

// insertAt_empty_correct
// Tests correct insertion into an empty LL.
// Afterwards, size should be 1 and element at index 0
// should be the element we inserted.
void insertAt_empty_correct() { 
    CharLinkedList test_list;
    
    test_list.insertAt('a', 0);
    
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');
}

// insertAt_empty_incorrect
// Tests incorrect insertion into an empty LL.
// Attempts to call insertAt for index larger than 0.
// This should result in an std::range_error being raised.
void insertAt_empty_incorrect() {

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    // insertAt for out-of-range index
    test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
    // if insertAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    range_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0]");
    
}

// insertAt_front_singleton_list
// Tests correct insertAt for front of 1-element list.
void insertAt_front_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at front
    test_list.insertAt('b', 0);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'a');
    
}

// insertAt_back_singleton_list
// Tests correct insertAt for back of 1-element list.
void insertAt_back_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at back
    test_list.insertAt('b', 1);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    
}

// insertAt_many_elements
// Tests calling insertAt for a large number of elements.
void insertAt_many_elements() {
    
    CharLinkedList test_list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.insertAt('a', i);
    }

    assert(test_list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
    
}

// insertAt_front_large_list
// Tests insertion into front of a larger list
void insertAt_front_large_list() {
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList list(test_arr, 9);

    list.insertAt('y', 0);

    assert(list.size() == 10);
    assert(list.elementAt(0) == 'y');
    assert(list.toString() == "[CharLinkedList of size 10 <<yabczdefgh>>]");

}

// insertAt_back_large_list
// Tests insertion into the back of a larger list
void insertAt_back_large_list() {

    char test_arr[10] = { 'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList list(test_arr, 10);  

    list.insertAt('x', 10);

    assert(list.size() == 11);
    assert(list.elementAt(10) == 'x');
    assert(list.toString() == "[CharLinkedList of size 11 <<yabczdefghx>>]"); 

}

// insertAt_middle_large_list
// Tests insertion into the middle of a larger list
void insertAt_middle_large_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.insertAt('z', 3);

    assert(test_list.size() == 9);
    assert(test_list.elementAt(3) == 'z');
    assert(test_list.toString() == "[CharLinkedList of size 9 <<abczdefgh>>]");

}

// insertAt_nonempty_incorrect
// Tests out-of-range insertion for a non-empty list.
void insertAt_nonempty_incorrect() {
   
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8]");
    
}

/*
 * insertAtStringCheck
 * make sure all elements are linked correctly
 */
void insertAtStringCheck(){
    char arr[5] = {'R','o','w','a','n'};
    CharLinkedList list(arr, 5);
    
    list.insertAt('!', 3);
    list.insertAt('?', 5);
    list.insertAt('2', 3);
    
    assert(list.toString() == "[CharLinkedList of size 8 <<Row2!a?n>>]");
    assert(list.toReverseString() == "[CharLinkedList of size 8 <<n?a!2woR>>]");
}

/*
 * insertInOrderEmpty
 * Make sure insertInOder works on an empty list
 */
void insertInOrderEmpty(){
    CharLinkedList list;
    
    list.insertInOrder('R');
    
    assert(list.toString() == "[CharLinkedList of size 1 <<R>>]");
    assert(list.toReverseString() == "[CharLinkedList of size 1 <<R>>]");
}

/*
 * insertInOrderFrontOfOne
 * Make sure insertInOrder works in front of a single character list
 */
void insertInOrderFrontOfOne(){
    CharLinkedList list('b');
    
    list.insertInOrder('a');
    
    assert(list.toString() == "[CharLinkedList of size 2 <<ab>>]");
    assert(list.toReverseString() == "[CharLinkedList of size 2 <<ba>>]");
}

/*
 * insertInOrderBackOfOne
 * Make sure insertInOrder works behind of a single character list
 */
void insertInOrderBackOfOne(){
    CharLinkedList list('b');
    
    list.insertInOrder('c');
    
    assert(list.toString() == "[CharLinkedList of size 2 <<bc>>]");
    assert(list.toReverseString() == "[CharLinkedList of size 2 <<cb>>]");
}

/*
 * insertInOrderLargerList
 * Make sure insertInOrder works on a larger list
 */
void insertInOrderLargerList(){
    char arr[5] = {'R','o','a','w','n'};
    CharLinkedList list(arr, 5);
    
    list.insertInOrder('q');
    
    assert(list.toString() == "[CharLinkedList of size 6 <<Roaqwn>>]");
    assert(list.toReverseString() == "[CharLinkedList of size 6 <<nwqaoR>>]");
}

/*
 * insertInOrderBackOfList
 * Make sure insertInOrder works at the back of a larger list
 */
void insertInOrderBackOfList(){
    char arr[5] = {'R','o','w','a','n'};
    CharLinkedList list(arr, 5);
    
    list.insertInOrder('z');
    
    assert(list.toString() == "[CharLinkedList of size 6 <<Rowanz>>]");
    assert(list.toReverseString() == "[CharLinkedList of size 6 <<znawoR>>]");
}

/*
 * insertInOrderFrontOfList
 * Make sure insertInOrder works at the front of a larger list
 */
void insertInOrderFrontOfList(){
    char arr[5] = {'R','o','w','a','n'};
    CharLinkedList list(arr, 5);
    
    list.insertInOrder('B');
    
    assert(list.toString() == "[CharLinkedList of size 6 <<BRowan>>]");
    assert(list.toReverseString() == "[CharLinkedList of size 6 <<nawoRB>>]");
}

/*
 * insertInOrderDoubleLetter
 * Make sure insertInOrder works when it is the same as one of the letters
 */
void insertInOrderDoubleLetter(){
    char arr[5] = {'R','o','w','a','n'};
    CharLinkedList list(arr, 5);
    
    list.insertInOrder('w');
    
    assert(list.toString() == "[CharLinkedList of size 6 <<Rowwan>>]");
    assert(list.toReverseString() == "[CharLinkedList of size 6 <<nawwoR>>]");
}

/*
 * insertInOrderMany
 * Make sure insertInOrder works in front of, back of, and middle of a list
 */
void insertInOrderMany(){
    char arr[5] = {'R','o','w','a','n'};
    CharLinkedList list(arr, 5);
    
    list.insertInOrder('c');
    list.insertInOrder('B');
    list.insertInOrder('z');
    list.insertInOrder('Z');
    list.insertInOrder('w');
    list.insertInOrder('q');
    list.insertInOrder('p');
    list.insertInOrder('D');
    list.insertInOrder('y');
    
    assert(list.toString() == "[CharLinkedList of size 14 <<BDRZcopqwwanyz>>]");
    std::string s = list.toReverseString();
    assert(s == "[CharLinkedList of size 14 <<zynawwqpocZRDB>>]");
}

/*
 * removeAtEmpty
 * Make sure an error is thrown for running removeAt on an empty list
 */
void removeAtEmpty(){
    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList list;
    try {
        list.removeAt(0);
    }
    catch (const std::range_error &e) {
        // if removeAtEmpty is correctly implemented, a range_error will be
        // thrown, and we will end up here
        range_error_thrown = true;
        error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (0) not in range [0..0)");
}

/*
 * removeAtOne
 * Make sure removeAt works on a single character list
 */
void removeAtOne(){
    CharLinkedList list('a');
    
    list.removeAt(0);
    
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
    assert(list.toReverseString() == "[CharLinkedList of size 0 <<>>]");
}

/*
 * removeAtNegative
 * Make sure an error is thrown for running removeAt with a negative index
 */
void removeAtNegative(){
    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    char arr[5] = {'R','o','w','a','n'};
    CharLinkedList list(arr, 5);
    try {
        list.removeAt(-1);
    }
    catch (const std::range_error &e) {
        // if removeAtEmpty is correctly implemented, a range_error will be
        // thrown, and we will end up here
        range_error_thrown = true;
        error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (-1) not in range [0..5)");
}

/*
 * removeAtOutOfRange
 * Make sure an error is thrown for running removeAt with index more than size
 */
void removeAtOutOfRange(){
    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    char arr[5] = {'R','o','w','a','n'};
    CharLinkedList list(arr, 5);
    try {
        list.removeAt(42);
    }
    catch (const std::range_error &e) {
        // if removeAtEmpty is correctly implemented, a range_error will be
        // thrown, and we will end up here
        range_error_thrown = true;
        error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..5)");
}

/*
 * removeAtSize
 * Make sure an error is thrown for running removeAt with index equal to size
 */
void removeAtSize(){
    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    char arr[5] = {'R','o','w','a','n'};
    CharLinkedList list(arr, 5);
    try {
        list.removeAt(5);
    }
    catch (const std::range_error &e) {
        // if removeAtEmpty is correctly implemented, a range_error will be
        // thrown, and we will end up here
        range_error_thrown = true;
        error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (5) not in range [0..5)");
}

/*
 * removeAtSeveral
 * Make sure removeAt works on a list several times in front, back, and middle
 */
void removeAtSeveral(){
    char arr[5] = {'R','o','w','a','n'};
    CharLinkedList list(arr, 5);

    list.removeAt(4);
    assert(list.toString() == "[CharLinkedList of size 4 <<Rowa>>]");
    assert(list.toReverseString() == "[CharLinkedList of size 4 <<awoR>>]");
    
    list.removeAt(0);
    assert(list.toString() == "[CharLinkedList of size 3 <<owa>>]");
    assert(list.toReverseString() == "[CharLinkedList of size 3 <<awo>>]");
    
    list.removeAt(1);
    assert(list.toString() == "[CharLinkedList of size 2 <<oa>>]");
    assert(list.toReverseString() == "[CharLinkedList of size 2 <<ao>>]");
    
    list.removeAt(1);
    assert(list.toString() == "[CharLinkedList of size 1 <<o>>]");
    assert(list.toReverseString() == "[CharLinkedList of size 1 <<o>>]");
    
    list.removeAt(0);
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
    assert(list.toReverseString() == "[CharLinkedList of size 0 <<>>]");
}

/*
 * replaceAtEmpty
 * Make sure an error is thrown for running replaceAt on an empty list
 */
void replaceAtEmpty(){
    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList list;
    try {
        list.replaceAt('r',0);
    }
    catch (const std::range_error &e) {
        // if replaceAtEmpty is correctly implemented, a range_error will be
        // thrown, and we will end up here
        range_error_thrown = true;
        error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (0) not in range [0..0)");
}

/*
 * replaceAtOne
 * Make sure replaceAt works on a one character list
 */
void replaceAtOne(){
    CharLinkedList list('a');
    
    list.replaceAt('r', 0);
    
    assert(list.toString() == "[CharLinkedList of size 1 <<r>>]");
    assert(list.toReverseString() == "[CharLinkedList of size 1 <<r>>]");
}

/*
 * replaceAt Negatove
 * Make sure an error is thrown for running replaceAt with a negative index
 */
void replaceAtNegative(){
    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    char arr[5] = {'R','o','w','a','n'};
    CharLinkedList list(arr, 5);
    try {
        list.replaceAt('r', -1);
    }
    catch (const std::range_error &e) {
        // if replaceAtEmpty is correctly implemented, a range_error will be
        // thrown, and we will end up here
        range_error_thrown = true;
        error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (-1) not in range [0..5)");
}

/*
 * replaceAtEmpty
 * Make sure an error is thrown for running replaceAt with index more than size
 */
void replaceAtOutOfRange(){
    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    char arr[5] = {'R','o','w','a','n'};
    CharLinkedList list(arr, 5);
    try {
        list.replaceAt('r', 42);
    }
    catch (const std::range_error &e) {
        // if replaceAtEmpty is correctly implemented, a range_error will be
        // thrown, and we will end up here
        range_error_thrown = true;
        error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..5)");
}

/*
 * replaceAtSize
 * Make sure an error is thrown for running replaceAt with index equal to size
 */
void replaceAtSize(){
    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    char arr[5] = {'R','o','w','a','n'};
    CharLinkedList list(arr, 5);
    try {
        list.replaceAt('r', 5);
    }
    catch (const std::range_error &e) {
        // if replaceAtEmpty is correctly implemented, a range_error will be
        // thrown, and we will end up here
        range_error_thrown = true;
        error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (5) not in range [0..5)");
}

/*
 * replaceAtSeveral
 * Make sure replaceAt works several times on a list in front, back, and middle
 */
void replaceAtSeveral(){
    char arr[5] = {'R','o','w','a','n'};
    CharLinkedList list(arr, 5);

    list.replaceAt('r', 4);
    assert(list.toString() == "[CharLinkedList of size 5 <<Rowar>>]");
    assert(list.toReverseString() == "[CharLinkedList of size 5 <<rawoR>>]");
    
    list.replaceAt('P', 0);
    assert(list.toString() == "[CharLinkedList of size 5 <<Powar>>]");
    assert(list.toReverseString() == "[CharLinkedList of size 5 <<rawoP>>]");
    
    list.replaceAt('u', 3);
    assert(list.toString() == "[CharLinkedList of size 5 <<Powur>>]");
    assert(list.toReverseString() == "[CharLinkedList of size 5 <<ruwoP>>]");
    
    list.replaceAt('o', 1);
    assert(list.toString() == "[CharLinkedList of size 5 <<Powur>>]");
    assert(list.toReverseString() == "[CharLinkedList of size 5 <<ruwoP>>]");
    
    list.replaceAt('e', 3);
    assert(list.toString() == "[CharLinkedList of size 5 <<Power>>]");
    assert(list.toReverseString() == "[CharLinkedList of size 5 <<rewoP>>]");
}
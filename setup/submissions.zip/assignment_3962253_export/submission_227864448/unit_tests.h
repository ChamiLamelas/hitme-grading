/*
 *  unit_tests.h
 *  Yifan Cao
 *  2/2/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  Test CharLinkedList class thoroughly by considering different cases
 *
 */
#include "CharLinkedList.h"
#include <cassert>
#include <stdexcept>

#include <iostream>

// Test default constructor
// Make sure no memory leak
// Make sure size is 0;
void default_constructor_test() {
    CharLinkedList list;
    assert(list.size() == 0);
    string temp = list.toString();
    assert(temp == "[CharLinkedList of size 0 <<>>]");
}

// Test constructor1
// Make sure no memory leak
// Make sure size is 1
// Make sure elem is correct
// Make sure special elems can be insert
void constructot1_test() {
    CharLinkedList list('x');
    assert(list.size() == 1);
    assert(list.elementAt(0) == 'x');
    string temp = list.toString();
    assert(temp == "[CharLinkedList of size 1 <<x>>]");

    CharLinkedList list2('\0');
    assert(list2.size() == 1);
    assert(list2.elementAt(0) == '\0');

    CharLinkedList list3('\n');
    assert(list3.size() == 1);
    assert(list3.elementAt(0) == '\n');

    CharLinkedList list4('\\');
    assert(list4.size() == 1);
    assert(list4.elementAt(0) == '\\');
}

// Test constructor2
// Make sure no memory leak
// Make sure size is equal to the size of array passed in
// Make sure the third element is correct;
void constructor2_test() {
    int size = 5;
    char arr[5] = {'t', 'u', 'f', 't', 's'};
    CharLinkedList list(arr, size);
    assert(list.size() == 5);
    assert(list.elementAt(2) == 'f');
    string temp = list.toString();
    assert(temp == "[CharLinkedList of size 5 <<tufts>>]");
}

// Test constructor2 with empty array
void constructor2_empty_test() {
    int size = 0;
    char arr[0];
    CharLinkedList list(arr, size);
    assert(list.size() == 0);
    string temp = list.toString();
    assert(temp == "[CharLinkedList of size 0 <<>>]");
}

// Test constructor2 with singleton array
void constructor2_singleton_test() {
    int size = 1;
    char arr[1] = {'Z'};
    CharLinkedList list(arr, size);
    assert(list.size() == 1);
    string temp = list.toString();
    assert(temp == "[CharLinkedList of size 1 <<Z>>]");
}

// Test constructor_deep_copy
// Make sure no memory leak
// Make sure size is equal to the size of array passed in
// Make sure the fourth element is correct;
void constructor_deep_copy_test() {
    int size = 5;
    char arr[5] = {'t', 'u', 'f', 't', 's'};
    CharLinkedList list_other(arr, size);
    CharLinkedList list_copy(list_other);
    assert(list_copy.size() == 5);
    assert(list_copy.elementAt(3) == 't');
    string temp = list_copy.toString();
    assert(temp == "[CharLinkedList of size 5 <<tufts>>]");
}

// Test constructor_deep_copy with an empty list
void constructor_deep_copy_empty_test() {
    CharLinkedList list_other;
    CharLinkedList list_copy(list_other);
    assert(list_copy.size() == 0);
    string temp = list_copy.toString();
    assert(temp == "[CharLinkedList of size 0 <<>>]");
}

// Test constructor_deep_copy with a singleton list
void constructor_deep_copy_singleton_test() {
    CharLinkedList list_other('G');
    CharLinkedList list_copy(list_other);
    assert(list_copy.size() == 1);
    assert(list_copy.elementAt(0) == 'G');
    string temp = list_copy.toString();
    assert(temp == "[CharLinkedList of size 1 <<G>>]");
}

// Test operator_works
// same size
void operator_sameSize_test() {
    int size = 5;
    char arr1[5] = {'t', 'u', 'f', 't', 's'};
    char arr2[5] = {'u', 'm', 'i', 'c', 'h'};
    CharLinkedList list1(arr1, size);
    CharLinkedList list2(arr2, size);
    string temp1 = list1.toString();
    assert(temp1 == "[CharLinkedList of size 5 <<tufts>>]");

    list1 = list2;

    string temp2 = list1.toString();
    assert(temp2 == "[CharLinkedList of size 5 <<umich>>]");
}

// Test operator_works
// same size but only 1 elements
void operator_sameSize_singleton_test() {
    int size = 1;
    char arr1[1] = {'t'};
    char arr2[1] = {'u'};
    CharLinkedList list1(arr1, size);
    CharLinkedList list2(arr2, size);
    string temp1 = list1.toString();
    assert(temp1 == "[CharLinkedList of size 1 <<t>>]");

    list1 = list2;

    string temp2 = list1.toString();
    assert(temp2 == "[CharLinkedList of size 1 <<u>>]");
}

// Test operator_works
// same list
void operator_samelist_test() {
    int size = 5;
    char arr1[5] = {'t', 'u', 'f', 't', 's'};
    CharLinkedList list1(arr1, size);
    string temp1 = list1.toString();
    assert(temp1 == "[CharLinkedList of size 5 <<tufts>>]");

    list1 = list1;

    string temp2 = list1.toString();
    assert(temp2 == "[CharLinkedList of size 5 <<tufts>>]");
}

// Test operator_works
// same list but empty
void operator_samelist_empty_test() {

    CharLinkedList list1;
    string temp1 = list1.toString();
    assert(temp1 == "[CharLinkedList of size 0 <<>>]");

    list1 = list1;

    string temp2 = list1.toString();
    assert(temp2 == "[CharLinkedList of size 0 <<>>]");
}

// Test operator_works
// different size
void operator_diffSize_test() {
    char arr1[5] = {'t', 'u', 'f', 't', 's'};
    char arr2[7] = {'h', 'a', 'r', 'v', 'a', 'r', 'd'};
    CharLinkedList list1(arr1, 5);
    CharLinkedList list2(arr2, 7);
    string temp1 = list1.toString();
    assert(temp1 == "[CharLinkedList of size 5 <<tufts>>]");

    list1 = list2;
    assert(list1.size() == 7);

    string temp2 = list1.toString();
    assert(temp2 == "[CharLinkedList of size 7 <<harvard>>]");
}

// Test operator_works
// different size and rhs is empty list
void operator_diffSize_empty_test() {
    char arr1[5] = {'t', 'u', 'f', 't', 's'};
    CharLinkedList list1(arr1, 5);
    CharLinkedList list2;
    string temp1 = list1.toString();
    assert(temp1 == "[CharLinkedList of size 5 <<tufts>>]");

    list1 = list2;
    assert(list1.size() == 0);

    string temp2 = list1.toString();
    assert(temp2 == "[CharLinkedList of size 0 <<>>]");
}

// Test isEmpty
void isEmpty_test() {
    CharLinkedList list1;
    assert(list1.isEmpty());
}

// Test clear
void clear_test() {
    int size = 5;
    char arr1[5] = {'t', 'u', 'f', 't', 's'};
    CharLinkedList list1(arr1, size);

    string temp1 = list1.toString();
    assert(temp1 == "[CharLinkedList of size 5 <<tufts>>]");

    list1.clear();

    string temp2 = list1.toString();
    assert(temp2 == "[CharLinkedList of size 0 <<>>]");
}

// Test clear by empty list
void clear_empty_test() {

    CharLinkedList list1;

    list1.clear();

    string temp1 = list1.toString();
    assert(temp1 == "[CharLinkedList of size 0 <<>>]");
}

// Test size()
void size_test() {
    char arr1[5] = {'t', 'u', 'f', 't', 's'};
    CharLinkedList list1(arr1, 5);
    assert(list1.size() == 5);
}

// Test size with an empty list
void size_empty_test() {
    CharLinkedList list1;
    assert(list1.size() == 0 and list1.isEmpty());
}

// Test first
// Make sure if it can get first element
void first_test() {
    int size = 5;
    char arr1[5] = {'t', 'u', 'f', 't', 's'};
    CharLinkedList list1(arr1, size);
    assert(list1.first() == 't');
}

// Test first with a sigleton list
void first_single_test() {
    int size = 1;
    char arr1[1] = {'t'};
    CharLinkedList list1(arr1, size);
    assert(list1.first() == 't');
}

// Test first if list is empty
void first_empty_test() {

    CharLinkedList list1;

    //variable to track whether error is thrown
    bool runtime_error_thorwn = false;

    //var to track any error messages raised
    string error_message = "";

    try {
        list1.first();
    }
    catch (const runtime_error &e) {
        runtime_error_thorwn = true;
        error_message = e.what();
    }

    assert(runtime_error_thorwn);
    assert(error_message == "cannot get first of empty LinkedList");
}

// Test last
// Make sure if it can get last element
void last_test() {
    int size = 5;
    char arr1[5] = {'t', 'u', 'f', 't', 's'};
    CharLinkedList list1(arr1, size);
    assert(list1.last() == 's');
}

// Test last with a singleton list
void last_single_test() {
    int size = 1;
    char arr1[1] = {'s'};
    CharLinkedList list1(arr1, size);
    assert(list1.last() == 's');
}

// Test last if list is empty
void last_empty_test() {

    CharLinkedList list1;

    //variable to track whether error is thrown
    bool runtime_error_thorwn = false;

    //var to track any error messages raised
    string error_message = "";

    try {
        list1.last();
    }
    catch (const runtime_error &e) {
        runtime_error_thorwn = true;
        error_message = e.what();
    }

    assert(runtime_error_thorwn);
    assert(error_message == "cannot get last of empty LinkedList");
}

// Test elementAt() by correct index
void elementAt_correct_test() {
    int size = 5;
    char arr1[5] = {'t', 'u', 'f', 't', 's'};
    CharLinkedList list2(arr1, size);
    assert(list2.elementAt(0) == 't');
    assert(list2.elementAt(3) == 't');
    assert(list2.elementAt(4) == 's');
}

// Test elementAt() by incorrect index
void elementAt_incorrect_test() {
    int size = 1;
    char arr1[1] = {'f'};
    CharLinkedList list2(arr1, size);

    //variable to track whether error is thrown
    bool range_error_thorwn = false;

    //var to track any error messages raised
    string error_message = "";

    try {
        list2.elementAt(1);
    }
    catch (const range_error &e) {
        range_error_thorwn = true;
        error_message = e.what();
    }

    assert(range_error_thorwn);
    assert(error_message == "index (1) not in range [0..1)");
}

// Test elementAt() by incorrect index with empty list
void elementAt_incorrect_empty_test() {

    CharLinkedList list2;

    //variable to track whether error is thrown
    bool range_error_thorwn = false;

    //var to track any error messages raised
    string error_message = "";

    try {
        list2.elementAt(0);
    }
    catch (const range_error &e) {
        range_error_thorwn = true;
        error_message = e.what();
    }

    assert(range_error_thorwn);
    assert(error_message == "index (0) not in range [0..0)");
}

// Test toString
void toString_test() {
    char arr1[5] = {'t', 'u', 'f', 't', 's'};
    CharLinkedList list(arr1, 5);
    string temp = list.toString();
    assert(temp == "[CharLinkedList of size 5 <<tufts>>]");
}

// Test toString with empty list
void toString_empty_test() {
    CharLinkedList list;
    string temp = list.toString();
    assert(temp == "[CharLinkedList of size 0 <<>>]");
}

// Test toReverseString by empty list of an instance
void toReverseString_empty_test() {
    CharLinkedList list;
    string temp = list.toReverseString();
    assert(temp == "[CharLinkedList of size 0 <<>>]");
}

// Test toReverseString by 6-element array
void toReverseString_test() {
    char arr1[5] = {'t', 'u', 'f', 't', 's'};
    CharLinkedList list(arr1, 5);
    string temp = list.toReverseString();
    assert(temp == "[CharLinkedList of size 5 <<stfut>>]");
}

// Test pushAtBack with empty list
// Attemp to insert into an empty list
void pushAtBack_empty_test() {
    CharLinkedList list;
    list.pushAtBack('z');

    string temp = "[CharLinkedList of size 1 <<z>>]";
    assert(list.toString() == temp);
}

// Test pushAtBack with nonempty list
void pushAtBack_test() {
    char arr1[1] = {'G'};
    CharLinkedList list(arr1, 1);

    list.pushAtBack('A');

    string temp = "[CharLinkedList of size 2 <<GA>>]";
    assert(list.toString() == temp);
}

// Test pushAtFront with empty list
// Attemp to insert into an empty list
void pushAtFront_empty_test() {
    CharLinkedList list;
    list.pushAtFront('z');

    string temp = "[CharLinkedList of size 1 <<z>>]";
    assert(list.toString() == temp);
}

// Test pushAtFront with nonempty list
void pushAtFront_test() {
    char arr1[5] = {'t', 'u', 'f', 't', 's'};
    CharLinkedList list(arr1, 5);

    list.pushAtFront('z');

    string temp = "[CharLinkedList of size 6 <<ztufts>>]";
    assert(list.toString() == temp);
}

// Tests correct insertion into an empty LL.
// Afterwards, size should be 1 and element at index 0
// should be the element we inserted.
void insertAt_empty_correct() {
    CharLinkedList test_list;
    test_list.insertAt('a', 0);
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');
}

// Tests incorrect insertion into an empty AL.
// Attempts to call insertAt for index larger than 0.
// This should result in an std::range_error being raised.
void insertAt_empty_incorrect() {

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    // insertAt for out-of-range index
    test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
    // if insertAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    range_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0]");

}

// Tests correct insertAt for front of 1-element list.
void insertAt_front_singleton_list() {

    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at front
    test_list.insertAt('b', 0);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'a');
}

// Tests correct insertAt for back of 1-element list.
void insertAt_back_singleton_list() {

    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at back
    test_list.insertAt('b', 1);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
}

// Tests calling insertAt for a large number of elements..
void insertAt_many_elements() {

    CharLinkedList test_list;

    // insert 1000 elements
    for (int i = 0; i < 100; i++) {
        // always insert at the back of the list
        test_list.insertAt('a', i);
    }

    assert(test_list.size() == 100);

    for (int i = 0; i < 100; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
}

// Tests insertion into front of a larger list
void insertAt_front_large_list() {
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    test_list.insertAt('x', 0);
    test_list.insertAt('y', 0);
    test_list.insertAt('z', 0);

    assert(test_list.size() == 12);
    assert(test_list.elementAt(0) == 'z');
    assert(test_list.toString() ==
    "[CharLinkedList of size 12 <<zyxabczdefgh>>]");
}

// Tests insertion into the middle of a larger list
void insertAt_middle_large_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.insertAt('z', 3);
    test_list.insertAt('z', 5);
    test_list.insertAt('z', 7);
    assert(test_list.toString() ==
    "[CharLinkedList of size 11 <<abczdzezfgh>>]");
}

// Tests out-of-range insertion for a non-empty list.
void insertAt_nonempty_incorrect() {

    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8]");
}

// Tests insert into an empty LL.
// Afterwards, size should be 1 and element at index 0
// should be the element we inserted.
void insertInOrder_empty() {

    CharLinkedList test_list;
    test_list.insertInOrder('a');
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');
}

// Tests insertInOrder for front of 1-element list.
void insertInOrder_front_singleton_list() {

    // initialize 1-element list
    CharLinkedList test_list('b');

    // should insert at front
    test_list.insertInOrder('a');

    assert(test_list.size() == 2);
    assert(test_list.elementAt(1) == 'b');
    assert(test_list.elementAt(0) == 'a');
}

// Tests correct insertAt for back of 1-element list.
void insertInOrder_back_singleton_list() {

    // initialize 1-element list
    CharLinkedList test_list('a');

    // should insert at back
    test_list.insertInOrder('b');

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
}

// Tests insertion into  of a larger list
void insertInOrder_large_list() {
    char test_arr[9] = { 'a', 'b', 'c', 'x', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    test_list.insertInOrder('y');

    assert(test_list.size() == 10);
    assert(test_list.toString() ==
    "[CharLinkedList of size 10 <<abcxdefghy>>]");
}

// Tests repeated insertion into  of a larger list
void insertInOrder_repeat_list() {
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    test_list.insertInOrder('c');

    assert(test_list.toString() ==
    "[CharLinkedList of size 10 <<abcczdefgh>>]");
}

// Tests remove 1st element from an empty LL
void popFromFront_empty_test() {

    // var to track whether range_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    // remove element from empty LL
    test_list.popFromFront();
    }
    catch (const std::runtime_error &e) {
    // if incorrectly implemented, a runtime_error will be thrown,
    // and we will end up here
    runtime_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

// Tests correct implement of popFromFront
void popFromFront_test() {
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    test_list.popFromFront();

    assert(test_list.size() == 8);
    assert(test_list.toString() ==
    "[CharLinkedList of size 8 <<bczdefgh>>]");
}

// Tests correct implement of popFromFront with a singleton list
void popFromFront_single_test() {

    CharLinkedList test_list('5');
    assert(test_list.toString() ==
    "[CharLinkedList of size 1 <<5>>]");

    test_list.popFromFront();

    assert(test_list.toString() ==
    "[CharLinkedList of size 0 <<>>]");
}

// Tests remove last element from an empty LL
void popFromBack_empty_test() {

    // var to track whether range_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    // remove element from empty LL
    test_list.popFromBack();
    }
    catch (const std::runtime_error &e) {
    // if incorrectly implemented, a runtime_error will be thrown,
    // and we will end up here
    runtime_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

// Tests correct implement of popFromBack
void popFromBack_test() {
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    test_list.popFromBack();

    assert(test_list.size() == 8);
    assert(test_list.toString() ==
    "[CharLinkedList of size 8 <<abczdefg>>]");
}

// Tests correct implement of popFromBack with a singleton list
void popFromBack_single_test() {

    CharLinkedList test_list('5');
    assert(test_list.toString() ==
    "[CharLinkedList of size 1 <<5>>]");

    test_list.popFromBack();

    assert(test_list.toString() ==
    "[CharLinkedList of size 0 <<>>]");
}

// Test removeAt by incorrect index
void removeAt_incorrect_test() {
    CharLinkedList list2;

    //variable to track whether error is thrown
    bool range_error_thorwn = false;

    //var to track any error messages raised
    string error_message = "";

    try {
        list2.removeAt(6);
    }
    catch (const range_error &e) {
        range_error_thorwn = true;
        error_message = e.what();
    }

    assert(range_error_thorwn);
    assert(error_message == "index (6) not in range [0..0)");
}

// Test remove last element
void removeAt_last_test() {
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    test_list.removeAt(8);

    assert(test_list.toString() ==
    "[CharLinkedList of size 8 <<abczdefg>>]");
}

// Test remove first element
void removeAt_first_test() {
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    test_list.removeAt(0);

    assert(test_list.toString() ==
    "[CharLinkedList of size 8 <<bczdefgh>>]");
}

// remove middle element
void removeAt_mid_test() {
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    test_list.removeAt(4);

    assert(test_list.size() == 8);
    assert(test_list.toString() ==
    "[CharLinkedList of size 8 <<abczefgh>>]");
}

// Test remove first single element
void removeAt_first_single_test() {

    CharLinkedList test_list('0');
    assert(test_list.toString() ==
    "[CharLinkedList of size 1 <<0>>]");

    test_list.removeAt(0);

    assert(test_list.toString() ==
    "[CharLinkedList of size 0 <<>>]");
}

// Test replaceAt by incorrect index
void replaceAt_incorrect_test() {
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    //variable to track whether error is thrown
    bool range_error_thorwn = false;

    //var to track any error messages raised
    string error_message = "";

    try {
        test_list.replaceAt('x', 9);
    }
    catch (const range_error &e) {
        range_error_thorwn = true;
        error_message = e.what();
    }

    assert(range_error_thorwn);
    assert(error_message == "index (9) not in range [0..9)");
}

// Tests correct implement of replaceAt
void replaceAt_test() {
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    test_list.replaceAt('x', 4);

    assert(test_list.size() == 9);
    // assert(test_list.toString() ==
    // "[CharLinkedList of size 9 <<abczxefgh>>]");
}

// Tests concatenate(general case)
// both LL1 and LL2 are not empty
void concatenate_general_test() {
    char test_arr1[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList list1(test_arr1, 9);
    char test_arr2[4] = { 'L', 'U', 'K', 'E'};
    CharLinkedList list2(test_arr2, 4);

    list1.concatenate(&list2);

    assert(list1.size() == 13);
    assert(list1.toString() ==
    "[CharLinkedList of size 13 <<abczdefghLUKE>>]");
}

// Tests concatenate(1 empty)
// LL1 is empty
void concatenate_LL1_empty_test() {
    CharLinkedList list1;
    char test_arr2[4] = { 'L', 'U', 'K', 'E'};
    CharLinkedList list2(test_arr2, 4);

    list1.concatenate(&list2);

    assert(list1.size() == 4);
    assert(list1.toString() ==
    "[CharLinkedList of size 4 <<LUKE>>]");
}

// Tests concatenate(1 empty)
// LL2 is empty
void concatenate_LL2_empty_test() {
    char test_arr1[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList list1(test_arr1, 9);
    CharLinkedList list2;

    list1.concatenate(&list2);

    assert(list1.size() == 9);
    assert(list1.toString() ==
    "[CharLinkedList of size 9 <<abczdefgh>>]");
}

// Tests concatenate(2 empty)
// both LL1 and LL2 are empty
void concatenate_both_empty_test() {
    CharLinkedList list1;
    CharLinkedList list2;

    list1.concatenate(&list2);

    assert(list1.size() == 0);
    assert(list1.toString() ==
    "[CharLinkedList of size 0 <<>>]");
}
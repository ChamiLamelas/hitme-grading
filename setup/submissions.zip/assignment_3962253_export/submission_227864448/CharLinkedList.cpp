/*
 *  CharLinkedList.cpp
 *  Yifan Cao
 *  2/2/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  This file contains an implementation of the CharLinkedList class.
 *
 */

#include "CharLinkedList.h"
#include <stdexcept>
#include <sstream>

/*
 * name:      CharLinkedList default constructor
 * purpose:   initialize an empty CharLinkedList
 * arguments: none
 * returns:   none
 * effects:   front and back point to nullptr
 *            set arrSize to be 0
 */
CharLinkedList::CharLinkedList() {
    front = nullptr;
    back = nullptr;
    arrSize = 0;
}

/*
 * name:      CharLinkedList constructor1
 * purpose:   initialize an CharLinkedList with 1 element
 * arguments: 1 char element
 * returns:   none
 * effects:   arrSize to 1;
 *            data be valued as argument
 *            create new heap
 *            front points to new heap memory
 *            back equals front
 *            next points to nullptr
 *            prev points to nullptr
 */
CharLinkedList::CharLinkedList(char c) {
    front = newNode(c, nullptr, nullptr);
    back = front;
    arrSize = 1;
}

/*
 * name:      CharLinkedList constructor2
 * purpose:   initialize an CharLinkedList with several elem
 * arguments: a char array
 *            an integer size
 * returns:   none
 * effects:   arrSize to size;
 *            copy each elem in arr to each linked list node
 *            create new heap memory
 *            front points to 1st node
 *            back points to last node
 */
CharLinkedList::CharLinkedList(char arr[], int size) {
    arrSize = 0;
    front = nullptr;
    back = front;
    //if arr is empty array
    if (size == 0) {
        front = nullptr;
        back = front;
    } else {
        //insert remaining elem at back
        for (int i = 0; i < size; i++) {
            pushAtBack(arr[i]);
        }
    }
}

/*
 * name:      CharLinkedList constructor_deep_copy
 * purpose:   initialize an CharLinkedList by copying another instance
 * arguments: reference of a CharLinkedList instance
 * returns:   none
 * effects:   everything is same with the instance passed in
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other) {
    arrSize = 0;
    front = nullptr;
    back = front;
    //other instance is an empty linkedList
    if (other.size() == 0) {
        front = nullptr;
        back = front;
    } else {//other instance is not empty
        for (int i = 0; i < other.size(); i++) {
            pushAtBack(other.elementAt(i));
        }
    }
}

/*
 * name:      operator_equal
 * purpose:   assign right hand side to left side by deep copy
 * arguments: reference of a CharLinkedList instance
 * returns:   return modified CharLinkedList instance
 * effects:   none
 */
CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other) {
    if (this == &other) { return *this; }
    //if lhs's size is equal to rhs's
    if (arrSize == other.arrSize) {
        Node *curr = front;
        Node *o_curr = other.front;
        //copy rhs's value to lhs in sequence
        while (curr != nullptr) {
            curr->data = o_curr->data;
            curr = curr->next;
            o_curr = o_curr->next;
        }
        return *this;
    } else {
        clear();//delete lhs's list
        //if rhs is empty list,return cleared list to lhs
        if (other.front == nullptr) { return *this;}

        //assign elements of rhs to lhs
        Node *o_curr = other.front;

        while (o_curr != nullptr) {
            pushAtBack(o_curr->data);
            o_curr = o_curr->next;
        }
        return *this;
    }
}


/*
 * name:      CharLinkedList destructor
 * purpose:   free memory associated with the CharLinkedList
 * arguments: none
 * returns:   none
 * effects:   frees memory allocated by CharLinkedList instances
 */
CharLinkedList::~CharLinkedList() {
    Node *curr;

    while (front != nullptr) {
        curr = front;
        front = curr->next;
        delete curr;
    }
}

/*
 * name:      clear
 * purpose:   makes the instance into an empty list
 * arguments: none
 * returns:   none
 * effects:   set arrSize to be 0
 *            delete memory on heap
 *            front and back point to nullptr
 */
void CharLinkedList::clear() {
    while (front != nullptr) {
        Node *curr = front;
        front = front->next;
        delete curr;
        curr = nullptr;
    }
    arrSize = 0;
    front = nullptr;
    back = nullptr;
}

/*
 * name:      isEmpty
 * purpose:   determine if list is empty
 * arguments: none
 * returns:   if list is empty, return true;
 *            otherwise, return false.
 * effects:   none
 */
bool CharLinkedList::isEmpty() const {
    return arrSize == 0;
}

/*
 * name:      size
 * purpose:   determine the number of items in the CharLinkedList
 * arguments: none
 * returns:   number of elements currently stored in the CharLinkedList
 * effects:   none
 */
int CharLinkedList::size() const {
    return arrSize;
}

/*
 * name:      first
 * purpose:   return the first character in the list
 * arguments: none
 * returns:   the first character
 * effects:   if list is empty, throw an exception
 */
char CharLinkedList::first() const {
    //if list is empty, throw an runtime_error exception
    if (arrSize == 0) {
        throw runtime_error("cannot get first of empty LinkedList");
    }

    //return first character
    return front->data;
}

/*
 * name:      last
 * purpose:   return the last character in the list
 * arguments: none
 * returns:   the last character
 * effects:   if the is empty, throw an exception
 */
char CharLinkedList::last() const {

    //if list is empty, throw an runtime_error exception
    if (arrSize == 0) {
        throw runtime_error("cannot get last of empty LinkedList");
    }

    //return last character
    return back->data;
}

/*
 * name:      elementAt
 * purpose:   determine specified element
 * arguments: an integer index
 * returns:   the specified element
 * effects:   if index is out of range, throw an exception
 */
char CharLinkedList::elementAt(int index) const {

    //throw exception if out of range
    if (index < 0 or index >= arrSize) {

        //variable to store error message
        stringstream ss;
        ss << "index (";
        ss << index;
        ss << ") not in range [0..";
        ss << arrSize;
        ss << ")";
        throw range_error(ss.str());
    }

    return elemAtHelper(front, index, 0);
}

/*
 * name:      toString
 * purpose:   insert characters of CharLinkedList into a string
 * arguments: none
 * returns:   a string which contains the characters of the CharLinkedList
 * effects:   none
 */
string CharLinkedList::toString() const {
    stringstream ss;
    ss << "[CharLinkedList of size ";
    ss << arrSize;
    ss << " <<";

    Node *curr = front;
    while (curr != nullptr) {
        ss << curr->data;
        curr = curr->next;
    }
    ss << ">>]";

    return ss.str();
}

/*
 * name:      toReverseString
 * purpose:   insert characters of CharLinkedList into a string
 *            in reverse order
 * arguments: none
 * returns:   a string which contains the characters of the CharLinkedList
 * effects:   none
 */
string CharLinkedList::toReverseString() const {
    stringstream ss;
    ss << "[CharLinkedList of size ";
    ss << arrSize;
    ss << " <<";

    Node *curr = back;
    while (curr != nullptr) {
        ss << curr->data;
        curr = curr->prev;
    }

    ss << ">>]";

    return ss.str();
}

/*
 * name:      pushAtBack
 * purpose:   push the provided character into the back of the LinkedList
 * arguments: an character to add to the back of the list
 * returns:   none
 * effects:   increases array Size of ArrayList by 1,
 *            adds element to list
 *            back points to new node
 */
void CharLinkedList::pushAtBack(char c) {
    //if the list is empty
    if (front == nullptr) {
        front = newNode(c, nullptr, nullptr);
        back = front;
        arrSize++;
        return ;
    }

    Node *curr = back;

    back = newNode(c, back, nullptr);

    curr->next = back;

    arrSize++;
}

/*
 * name:      pushAtFront
 * purpose:   push the provided character into the front of the LinkedList
 * arguments: an character to add to the front of the list
 * returns:   none
 * effects:   increases array Size of LinkedList by 1,
 *            adds element to list
 *            front points to new node
 */
void CharLinkedList::pushAtFront(char c) {
    //if the list is empty
    if (front == nullptr) {
        front = newNode(c, nullptr, nullptr);
        back = front;
        arrSize++;
        return ;
    }

    Node *curr = front;

    front = newNode(c, nullptr, front);

    curr->prev = front;

    arrSize++;
}

/*
 * name:      InsertAt
 * purpose:   insert the provided character into
 *            specified slot of the LinkedList
 * arguments: an character to add to the front of the list
 *            an int index which is the inserting position
 * returns:   none
 * effects:   increase arrSize of LinkedList by 1;
 *            add element to list;
 *            if index is out of range, throw an exception
 *
 */
void CharLinkedList::insertAt(char c, int index) {
    //throw exception if out of range
    if (index < 0 or index > arrSize) {
        //variable to store error message
        stringstream ss;
        ss << "index (" << index << ") not in range [0..";
        ss << arrSize << "]";
        throw range_error(ss.str());
    }
    if (index == 0) {//insert at first
        pushAtFront(c);
        return;
    }
    if (index == arrSize) {//insert at back
        pushAtBack(c);
        return;
    }
    //insert at middle
    Node *curr = front;
    int curr_index = 0;
    //find index-1-th position
    while (curr_index < index - 1) {
        curr = curr->next;
        curr_index++;
    }
    Node *new_node = newNode(c, curr, curr->next);
    //the code below must be first(prev of node after curr points to new_node)
    curr->next->prev = new_node;
    //curr's next point to new_node
    curr->next = new_node;
    arrSize++;
}

/*
 * name:      insertInOrder
 * purpose:   insert the provided character into
 *            specified in ASCII order(at the first correct index);
 *            assume the list is correctly sorted in ascending order;
 *            when meeting with same character, insert in front of that one;
 * arguments: an character to add to the list
 * returns:   none
 * effects:   increase array Size of LinkedList by 1;
 *            add element to list;
 */
void CharLinkedList::insertInOrder(char c) {
    //if linkedlist is empty, insert at first position
    if (front == nullptr) {
        pushAtFront(c);
        return;
    }
    Node *curr = front;
    //when c is not bigger than the first element it meets
    //or curr point the nullptr, insert before this element
    //Note: if c is larger than any other elements, curr will
    //      point to nullptr which doesn't have data. We should
    //      add curr != nullptr in condition before comparing
    while (curr != nullptr and c > curr->data) {
        curr = curr->next;
    }
    if (curr == front) {//when c isn't bigger than the first elem
        pushAtFront(c);
        return;
    }
    if (curr == nullptr) {//when c is bigger than any elems
        pushAtBack(c);
        return;
    }
    //neither smaller than 1st elem nor bigger than any elem
    Node *new_node = newNode(c, curr->prev, curr);
    //the code below must be first(next of node before curr points to new_node)
    curr->prev->next = new_node;
    //curr's prev point to new_node
    curr->prev = new_node;
    arrSize++;
}

/*
 * name:      popFromFront
 * purpose:   removes the first element from the linked list
 * arguments: none
 * returns:   none
 * effects:   decrease arrSize by 1;
 *            remove 1 element from list;
 *            if list is empty, throw an exception.
 */
void CharLinkedList::popFromFront() {
    //when linked list is empty
    if (arrSize == 0) {
        throw runtime_error("cannot pop from empty LinkedList");
    }
    //if there is only one element
    if (arrSize == 1) {
        delete front;
        front = nullptr;
        back = nullptr;
        arrSize--;
        return;
    }
    //when number of elements in list is greater than 1
    Node *curr = front;
    front = front->next;
    front->prev = nullptr;
    delete curr;
    curr = nullptr;
    arrSize--;
}

/*
 * name:      popFromBack
 * purpose:   removes the lasr element from the linker list
 * arguments: none
 * returns:   none
 * effects:   decrease arrSize by 1;
 *            remove 1 element from list;
 *            if array is empty, throw an exception.
 */
void CharLinkedList::popFromBack() {
    if (arrSize == 0) {
        throw runtime_error("cannot pop from empty LinkedList");
    }
    //if there is only one element
    if (arrSize == 1) {
        delete back;
        back = nullptr;
        front = nullptr;
        arrSize--;
        return;
    }
    //when number of elements in list is greater than 1
    Node *curr = back;
    back = back->prev;
    back->next = nullptr;
    delete curr;
    curr = nullptr;
    arrSize--;
}

/*
 * name:      removeAt
 * purpose:   removes the element at the specified index
 * arguments: an integer index
 * returns:   none
 * effects:   decrease arrSize of LinkedList by 1;
 *            remove 1 element from list;
 *            if index out of range, throw an exception.
 */
void CharLinkedList::removeAt(int index) {
    if (index < 0 or index >= arrSize) {//throw exception if out of range
        stringstream ss;//variable to store error message
        ss << "index (" << index << ") not in range [0.." << arrSize << ")";
        throw range_error(ss.str());
    }
    if (index == 0 and arrSize == 1) {//if there is only one element
        popFromFront();
        return;
    }
    if (index == 0 and arrSize > 1) {//if remove 1st elem and arrSize > 1
        popFromFront();
        return;
    }
    //if size of list is greater than 1 and remove last elem
    if (index == arrSize -1 and arrSize > 1) {
        popFromBack();
        return;
    }
    //when number of elements in list is greater than 1
    Node *curr = front;
    int curr_count = 0;
    while (curr_count != index) {
        curr = curr->next;
        curr_count++;
    }
    curr->prev->next = curr->next;
    curr->next->prev = curr->prev;
    delete curr;
    curr = nullptr;
    arrSize--;
}

/*
 * name:      replaceAt
 * purpose:   replaces the element at the specified index
 * arguments: an element (char) and an integer index
 * returns:   none
 * effects:
 *            if index is out of range, throw an exception.
 */
void CharLinkedList::replaceAt(char c, int index) {
    //throw exception if out of range
    if (index < 0 or index >= arrSize) {

        //variable to store error message
        stringstream ss;
        ss << "index (" << index << ") not in range [0.." << arrSize << ")";
        throw range_error(ss.str());
    }

    int curr_count = 0;
    Node *curr = front;
    // while (curr_count != index) {
    //     curr = curr->next;
    //     curr_count++;
    // }
    curr = replaceHelper(curr, index, curr_count);
    curr->data = c;

}

/*
 * name:      concatenate
 * purpose:   add another LL to the LL the function was called from
 * arguments: a pointer to another CharLinkedList
 * returns:   none
 * effects:   change the LL the function was called from;
 *            create new heap memory
 */
void CharLinkedList::concatenate(CharLinkedList *other) {
    //if other is an empty linked list
    if (other->arrSize == 0) { return; }

    Node *o_curr = other->front;

    //if this linked list is empty
    if (this->arrSize == 0) {
        pushAtFront(o_curr->data);
        o_curr = o_curr->next;
    }

    while (o_curr != nullptr) {
        //create a new node to take o_curr's value
        Node *new_node = newNode(o_curr->data, this->back, nullptr);
        this->back->next = new_node;//link current back to new_node
        this->back = new_node;//make back point to last node
        this->arrSize++;

        o_curr = o_curr->next;
    }

}

//private function:

/*
 * name:      elemAtHelper
 * purpose:   help elementAt to get the specified char
 * arguments: a Node pointer to current node
 *            an integer index
 *            an integer count
 * returns:   the specified element
 * effects:
 */
char CharLinkedList::elemAtHelper(Node *curr, int index, int count) const {

    if (count == index) {
        return curr->data;
    } else {
        return elemAtHelper(curr->next, index, ++count);
    }
}

/*
 * name:      newNode
 * purpose:   create a new node
 * arguments: a char elem
 *            a Node pointer Prev
 *            a Node pointer Next
 * returns:   newNode pointer
 * effects:
 */
CharLinkedList::Node *CharLinkedList::newNode(
    char newData, Node *newPrev, Node *newNext) {

    Node *new_node = new Node;
    new_node->data = newData;
    new_node->prev = newPrev;
    new_node->next = newNext;

    return new_node;
}

/*
 * name:      replaceHelper
 * purpose:   help replaceAt to get the corresponding pointer
 * arguments: a Node pointer to current node
 *            an integer index
 *            an integer count
 * returns:   the specified pointer
 * effects:
 */
CharLinkedList::Node *CharLinkedList::replaceHelper(
    Node *curr, int index, int count) {
    if (count == index) {
        return curr;
    } else {
        return replaceHelper(curr->next, index, ++count);
    }
}
/*
 *  unit_tests.h
 *  Charlie Fitzpatrick
 *  2/2/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  Purpose: To test the functionality and edge cases of this linked lsit
 *           implementation
 *
 */

#include "CharLinkedList.h"
#include <cassert>
#include <iostream>

using namespace std;

// Tests the default constructor
void default_constructor() {
    CharLinkedList list;
    assert(list.size() == 0);
}

// Tests the second constructor
void constructor_2() {
    CharLinkedList list('a');
    assert(list.size() == 1);
    assert(list.elementAt(0) == 'a');
}

// Tests the third constructor
void constructor_3() {
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList list(arr, 3);
    assert(list.toString() == "[CharLinkedList of size 3 <<abc>>]");
}

// Tests the copy constructor
void copy_constructor() {
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList list0(arr, 3);
    CharLinkedList list(list0);

    assert(list.toString() == "[CharLinkedList of size 3 <<abc>>]");
}

// Tests the assignment operator with an empty left hand side
void assignment_operator_empty() {
    CharLinkedList list;
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList list1(arr, 3);

    list = list1;
    assert(list.toString() == "[CharLinkedList of size 3 <<abc>>]");
}

// Tests the assignment operator with a nonempty left hand side
void assignment_operator_nonempty() {
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList list(arr, 3);
    char arr1[3] = {'d', 'e', 'f'};
    CharLinkedList list1(arr1, 3);

    list = list1;
    assert(list.toString() == "[CharLinkedList of size 3 <<def>>]");
}

// Tests if isEmpty returns true for an empty list
void isEmpty_true() {
    CharLinkedList list;
    assert(list.isEmpty());
}

// Tests if isEmpty returns false for a non empty list
void isEmpty_false() {
    CharLinkedList list('a');
    assert(not list.isEmpty());
}

// Tests clear on an empty list
void clear_empty() {
    CharLinkedList list;
    list.clear();
}

// Tests clear on a full list
void clear_full() {
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList list(arr, 3);
    list.clear();
    assert(list.isEmpty());
}

// Tests if size returns 0 for an empty list
void size_empty() {
    CharLinkedList list;
    assert(list.size() == 0);
}

// Tests if size returns 3 for a 3 element list
void size_full() {
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList list(arr, 3);
    assert(list.size() == 3);
}

// Tests first with an empty list
void first_empty() {
    bool error_thrown = false;
    std::string error_message = "";

    CharLinkedList list;

    try {
        list.first();
    }
    catch (const std::runtime_error &e) {
        error_thrown = true;
        error_message = e.what();
    }
    assert(error_thrown);
    assert(error_message == "cannot get first of empty LinkedList");
}

// Tests first with a full list
void first_full() {
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList list(arr, 3);

    assert(list.first() == 'a');
}

// Tests last with an empty list
void last_empty() {
    bool error_thrown = false;
    std::string error_message = "";

    CharLinkedList list;

    try {
        list.last();
    }
    catch (const std::runtime_error &e) {
        error_thrown = true;
        error_message = e.what();
    }
    assert(error_thrown);
    assert(error_message == "cannot get last of empty LinkedList");
}

// Tests last with a full list
void last_full() {
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList list(arr, 3);

    assert(list.last() == 'c');
}

// Tests elementAt with an empty list
void elementAt_empty() {
    bool error_thrown = false;
    std::string error_message = "";

    CharLinkedList list;

    try {
        list.elementAt(0);
    }
    catch (const std::range_error &e) {
        error_thrown = true;
        error_message = e.what();
    }
    assert(error_thrown);
    assert(error_message == "index (0) not in range [0..0)");
}

// Tests elementAt with a full list and correct indexes
void elementAt_full_correct() {
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList list(arr, 3);

    assert(list.elementAt(0) == 'a' and list.elementAt(1) == 'b' and
           list.elementAt(2) == 'c');
}

// Tests elementAt with a full list and an index below the range
void elementAt_full_incorrect_1() {
    bool error_thrown = false;
    std::string error_message = "";

    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList list(arr, 3);

    try {
        list.elementAt(-1);
    }
    catch (const std::range_error &e) {
        error_thrown = true;
        error_message = e.what();
    }
    assert(error_thrown);
    assert(error_message == "index (-1) not in range [0..3)");
}

// Tests elementAt with a full list and an index above the range
void elementAt_full_incorrect_2() {
    bool error_thrown = false;
    std::string error_message = "";

    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList list(arr, 3);

    try {
        list.elementAt(3);
    }
    catch (const std::range_error &e) {
        error_thrown = true;
        error_message = e.what();
    }
    assert(error_thrown);
    assert(error_message == "index (3) not in range [0..3)");
}

// Tests toString with an empty list
void toString_empty() {
    CharLinkedList list;
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}

// Tests toReverseString with an empty list
void toReverseString_empty() {
    CharLinkedList list;
    assert(list.toReverseString() == "[CharLinkedList of size 0 <<>>]");
}

// Tests toReverseString with a full list
void toReverseString_full() {
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList list(arr, 3);

    assert(list.toReverseString() == "[CharLinkedList of size 3 <<cba>>]");
}

void toReverseString_singleton() {
    CharLinkedList list('a');
    assert(list.toReverseString() == "[CharLinkedList of size 1 <<a>>]");
}

// Tests pushAtBack with an empty list
void pushAtBack_empty() {
    CharLinkedList list;
    list.pushAtBack('a');

    assert(list.toString() == "[CharLinkedList of size 1 <<a>>]");
}

// Tests pushAtBack with a full list
void pushAtBack_full() {
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList list(arr, 3);
    list.pushAtBack('d');

    assert(list.toString() == "[CharLinkedList of size 4 <<abcd>>]");
}

// Tests pushAtFront with an empty list
void pushAtFront_empty() {
    CharLinkedList list;
    list.pushAtFront('a');

    assert(list.toString() == "[CharLinkedList of size 1 <<a>>]");
}

// Tests pushAtFront with a full list
void pushAtFront_full() {
    char arr[3] = {'b', 'c', 'd'};
    CharLinkedList list(arr, 3);
    list.pushAtFront('a');

    assert(list.toString() == "[CharLinkedList of size 4 <<abcd>>]");
}

// Tests insertAt with an empty list
void insertAt_empty() {
    CharLinkedList list;
    list.insertAt('a', 0);

    assert(list.toString() == "[CharLinkedList of size 1 <<a>>]");
}

// Tests insertAt with a middle index
void insertAt_middle() {
    char arr[3] = {'a', 'b', 'd'};
    CharLinkedList list(arr, 3);
    list.insertAt('c', 2);

    assert(list.toString() == "[CharLinkedList of size 4 <<abcd>>]");
}

// Tests insertAt with index 0
void insertAt_front() {
    char arr[3] = {'b', 'c', 'd'};
    CharLinkedList list(arr, 3);
    list.insertAt('a', 0);

    assert(list.toString() == "[CharLinkedList of size 4 <<abcd>>]");
}

// Tests insertAt with index = to size
void insertAt_back() {
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList list(arr, 3);
    list.insertAt('d', 3);

    assert(list.toString() == "[CharLinkedList of size 4 <<abcd>>]");
}

// Tests insertAt front with a single char list
void insertAt_front_singleton() {
    CharLinkedList list('b');
    list.insertAt('a', 0);

    assert(list.toString() == "[CharLinkedList of size 2 <<ab>>]");
}

// Tests insertAt back with a single char list
void insertAt_back_singleton() {
    CharLinkedList list('a');
    list.insertAt('b', 1);

    assert(list.toString() == "[CharLinkedList of size 2 <<ab>>]");
}

// Tests insertAt with an index below the range
void insertAt_incorrect_1() {
    bool error_thrown = false;
    std::string error_message = "";

    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList list(arr, 3);

    try {
        list.insertAt('d', -1);
    }
    catch (const std::range_error &e) {
        error_thrown = true;
        error_message = e.what();
    }
    assert(error_thrown);
    assert(error_message == "index (-1) not in range [0..3]");
}

// Tests insertAt with an index above the range
void insertAt_incorrect_2() {
    bool error_thrown = false;
    std::string error_message = "";

    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList list(arr, 3);

    try {
        list.insertAt('d', 4);
    }
    catch (const std::range_error &e) {
        error_thrown = true;
        error_message = e.what();
    }
    assert(error_thrown);
    assert(error_message == "index (4) not in range [0..3]");
}

// Tests insertInOrder with an empty list
void insertInOrder_empty() {
    CharLinkedList list;

    list.insertInOrder('a');

    assert(list.toString() == "[CharLinkedList of size 1 <<a>>]");
}

// Tests insertInOrder with a char that would have the highest ASCII value
// in the list
void insertInOrder_first() {
    char arr[2] = {'b', 'c'};
    CharLinkedList list(arr, 2);

    list.insertInOrder('a');

    assert(list.toString() == "[CharLinkedList of size 3 <<abc>>]");
}

// Tests insertInOrder with a char that would have a middle ASCII value in
// the list
void insertInOrder_middle() {
    char arr[2] = {'a', 'c'};
    CharLinkedList list(arr, 2);

    list.insertInOrder('b');

    assert(list.toString() == "[CharLinkedList of size 3 <<abc>>]");
}

// Tests insertInOrder with a char that would have the lowest ASCII value
// in the list
void insertInOrder_last() {
    char arr[2] = {'a', 'b'};
    CharLinkedList list(arr, 2);

    list.insertInOrder('c');

    
}

void popFromFront() {
    CharLinkedList list('a');
    list.popFromFront();
}

// Tests popFromFront with an empty list
void popFromFront_empty() {
    bool error_thrown = false;
    std::string error_message = "";

    CharLinkedList list;
    
    try {
        list.popFromFront();
    }
    catch (const std::runtime_error &e) {
        error_thrown = true;
        error_message = e.what();
    }

    assert(error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

// Tests popFromFront with a full list
void popFromFront_full() {
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList list(arr, 3);
    list.popFromFront();

    assert(list.toString() == "[CharLinkedList of size 2 <<bc>>]");
}

// Tests popFromFront with single char list
void popFromFront_singleton() {
    CharLinkedList list('a');
    list.popFromFront();

    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}

// Tests popFromBack with an empty list
void popFromBack_empty() {
    bool error_thrown = false;
    std::string error_message = "";

    CharLinkedList list;
    
    try {
        list.popFromBack();
    }
    catch (const std::runtime_error &e) {
        error_thrown = true;
        error_message = e.what();
    }

    assert(error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

// Tests popFromBack with a full list
void popFromBack_full() {
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList list(arr, 3);
    list.popFromBack();

    assert(list.toString() == "[CharLinkedList of size 2 <<ab>>]");
}

// Tests popFromBack with a single char list
void popFromBack_singleton() {
    CharLinkedList list('a');
    list.popFromBack();

    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}

// Tests removeAt with an empty list
void removeAt_empty() {
    bool error_thrown = false;
    std::string error_message = "";

    CharLinkedList list;

    try {
        list.removeAt(0);
    }
    catch (const std::range_error &e) {
        error_thrown = true;
        error_message = e.what();
    }
    assert(error_thrown);
    assert(error_message == "index (0) not in range [0..0)");
}

// Tests removeAt with a middle index
void removeAt_middle() {
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList list(arr, 3);
    list.removeAt(1);

    assert(list.toString() == "[CharLinkedList of size 2 <<ac>>]");
}

// Tests removeAt with a single char list
void removeAt_singleton() {
    CharLinkedList list('a');
    list.removeAt(0);

    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}

// Tests removeAt with a below range index
void removeAt_incorrect_1() {
    bool error_thrown = false;
    std::string error_message = "";

    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList list(arr, 3);

    try {
        list.removeAt(-1);
    }
    catch (const std::range_error &e) {
        error_thrown = true;
        error_message = e.what();
    }
    assert(error_thrown);
    assert(error_message == "index (-1) not in range [0..3)");
}

// Tests removeAt with an above range index
void removeAt_incorrect_2() {
    bool error_thrown = false;
    std::string error_message = "";

    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList list(arr, 3);

    try {
        list.removeAt(3);
    }
    catch (const std::range_error &e) {
        error_thrown = true;
        error_message = e.what();
    }
    assert(error_thrown);
    assert(error_message == "index (3) not in range [0..3)");
}

// Tests replaceAt with an empty list
void replaceAt_empty() {
    bool error_thrown = false;
    std::string error_message = "";

    CharLinkedList list;

    try {
        list.replaceAt('a', 0);
    }
    catch (const std::range_error &e) {
        error_thrown = true;
        error_message = e.what();
    }
    assert(error_thrown);
    assert(error_message == "index (0) not in range [0..0)");
}

// Tests replaceAt with a single char list
void replaceAt_singleton() {
    CharLinkedList list('b');
    list.replaceAt('a', 0);

    assert(list.toString() == "[CharLinkedList of size 1 <<a>>]");
}

// Tests replaceAt by replacing the first char
void replaceAt_first() {
    char arr[3] = {'z', 'b', 'c'};
    CharLinkedList list(arr, 3);
    list.replaceAt('a', 0);

    assert(list.toString() == "[CharLinkedList of size 3 <<abc>>]");
}

// Tests replaceAt by replacing the last char
void replaceAt_last() {
    char arr[3] = {'a', 'b', 'z'};
    CharLinkedList list(arr, 3);
    list.replaceAt('c', 2);

    assert(list.toString() == "[CharLinkedList of size 3 <<abc>>]");
}

// Tests replaceAt by replacing a middle char
void replaceAt_middle() {
    char arr[3] = {'a', 'z', 'c'};
    CharLinkedList list(arr, 3);
    list.replaceAt('b', 1);

    assert(list.toString() == "[CharLinkedList of size 3 <<abc>>]");
}

// Tests replaceAt with an index below the range
void replaceAt_incorrect_1() {
    bool error_thrown = false;
    std::string error_message = "";

    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList list(arr, 3);

    try {
        list.replaceAt('a', -1);
    }
    catch (const std::range_error &e) {
        error_thrown = true;
        error_message = e.what();
    }
    assert(error_thrown);
    assert(error_message == "index (-1) not in range [0..3)");
}

// Tests replaceAt with an index above the range
void replaceAt_incorrect_2() {
    bool error_thrown = false;
    std::string error_message = "";

    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList list(arr, 3);

    try {
        list.replaceAt('a', 3);
    }
    catch (const std::range_error &e) {
        error_thrown = true;
        error_message = e.what();
    }
    assert(error_thrown);
    assert(error_message == "index (3) not in range [0..3)");
}

//Tests concatenate with two full lists
void concatenate() {
    char arr1[3] = {'a', 'b', 'c'};
    CharLinkedList list1(arr1, 3);
    char arr2[3] = {'d', 'e', 'f'};
    CharLinkedList list2(arr2, 3);

    list1.concatenate(&list2);
    assert(list1.toString() == "[CharLinkedList of size 6 <<abcdef>>]");
}

// Tests concatenate by concatenating an empty list onto a full list
void concatenate_empty_1() {
    char arr1[3] = {'a', 'b', 'c'};
    CharLinkedList list1(arr1, 3);
    CharLinkedList list2;

    list1.concatenate(&list2);
    assert(list1.toString() == "[CharLinkedList of size 3 <<abc>>]");
}

// Tests concatenate by concatenating a full list onto an empty list
void concatenate_empty_2() {
    CharLinkedList list1;
    char arr2[3] = {'d', 'e', 'f'};
    CharLinkedList list2(arr2, 3);

    list1.concatenate(&list2);
    assert(list1.toString() == "[CharLinkedList of size 3 <<def>>]");
}

// Tests concatenate by concatenating two empty lists
void concatenate_empty_3() {
    CharLinkedList list1;
    CharLinkedList list2;

    list1.concatenate(&list2);
    assert(list1.toString() == "[CharLinkedList of size 0 <<>>]");
}


// Tests concatenate by concatenating a list with itself
void concatenate_itself() {
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList list(arr, 3);

    list.concatenate(&list);
    cout << list.toString() << endl;
}

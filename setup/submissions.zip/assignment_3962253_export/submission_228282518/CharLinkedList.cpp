/*
 *  CharLinkedList.cpp
 *  Charlie Fitzpatrick
 *  2/2/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Purpose: To define all of the special functions that this linked list can
 *           perform and the helper functions that this linked list can use
 *
 */

#include "CharLinkedList.h"

// name: default constructor
// purpose: To initialize an empty linked list
// arguments: None
// returns: None
// effects: Creates an instance of a linked list
CharLinkedList::CharLinkedList() {
    front = nullptr;
    numItems = 0;
}

// name: second constructor
// purpose: To create a one char linked list
// arguments: The char that will be added to the list
// returns: None
// effects: The size of the list becomes one
CharLinkedList::CharLinkedList(char c) {
    front = nullptr;
    numItems = 0;
    pushAtBack(c);
}

// name: third constructor
// purpose: To create a linked list with the given array
// arguments: The array of chars that will make up the list and the size of
//            of the array
// returns: None
// effects: The size of the list will become the size argument 
CharLinkedList::CharLinkedList(char arr[], int size) {
    front = nullptr;
    numItems = 0;

    // Pushes each element in arr to back of list
    for (int i = 0; i < size; i++) {
        pushAtBack(arr[i]);
    }
}

// name: copy Constructor
// purpose: To make a deep copy of the instance of the list provided
// arguments: A reference to the instance of the list provided
// returns: None
// effects: Creates an instance of an list with the same attributes as
//          the provided instance
CharLinkedList::CharLinkedList(const CharLinkedList &other) {
    front = nullptr;
    numItems = 0;
    Node *curr = other.front;
    copy(curr);
}

// name: newNode
// purpose: To create a new node in the list
// arguments: The character that will represent that node
// returns: A pointer to the new node
// effects: The size of the list increments by one
CharLinkedList::Node *CharLinkedList::newNode(char c, Node *next,
Node *previous) {
    Node *node = new Node;
    numItems++;
    node->c = c;
    node->next = next;
    node->previous = previous;
    return node;
}

// name: findNode
// purpose: To return the node at the given index
// arguments: A pointer to the current node(starts as front), the index of
//            the current node(starts as 0), and the index of the desired node
// returns: The node at the given index
// effects: None
CharLinkedList::Node *CharLinkedList::findNode(Node *curr, int curr_index,
int index) const {
    // Base case
    if (curr_index == index) return curr;

    // Recursive case
    curr = curr->next;
    curr_index++;
    return findNode(curr, curr_index, index);
}

// name: rangeError
// purpose: To print a range error message
// arguments: The index that was out of range
// returns: None
// effects: Throws a range error
void CharLinkedList::rangeError(int index) const {
    std::stringstream ss;
    ss << "index (" << index << ") not in range [0.." << numItems << ")";
    throw std::range_error(ss.str());
}

// name: copy
// purpose: copies a list starting from curr onto the current instance
// arguments: A pointer to the starting point
// returns: None
// effects: Adds all of the chars in the list to the end of the current
//          instance
void CharLinkedList::copy(Node *curr) {
    while (curr != nullptr) {
        pushAtBack(curr->c);
        curr = curr->next;
    }
}

// name: destructor
// purpose: to delete all heap-allocated data in the current list
// arguments: None
// returns: None
// effects: There will be no memory leaks
CharLinkedList::~CharLinkedList() {
    cleanUp(front);
}

// name: Assignment Operator
// purpose: Recycles the storage associated with the list instance on
//          the left and makes deep copy of the instance on the right into
//          the instance on the left
// arguments: A reference to the instance of the list on the left
// returns: The instance of the list on the left after the right
//          instance is deep copied into it
// effects: Gives a prexisting instance of an list the attributes of
//          another while recycling the other
CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other) {
    if (this == &other) return *this;

    // Clear the LHS
    clear();
    Node *curr = other.front;

    // Copy RHS to LHS
    copy(curr);
    return *this;
}

// name: cleanUp
// purpose: to delete all heap-allocated data in the current ArrayList
//          recursively
// arguments: A pointer to the front of the list
// returns: None
// effects: There will be no memory leaks
void CharLinkedList::cleanUp(Node *curr) {
    if (curr == nullptr) return;
    
    Node *temp = curr;
    curr = curr->next;
    delete temp;
    return cleanUp(curr);
}

// name: isEmpty
// purpose: To determine whether the list is empty or not
// arguments: None
// returns: True if the list is empty and false if it is not
// effects: None
bool CharLinkedList::isEmpty() const {
    if (numItems == 0) return true;
    else return false;
}

// name: clear
// purpose: To make the current list into an empty list
// arguments: None
// returns: None
// effects: Deletes all of the heap allocated data
void CharLinkedList::clear() {
    cleanUp(front);
    front = nullptr;
    numItems = 0;
}

// name: size
// purpose: To give the size of the list
// arguments: None
// returns: An int of the size of the list
// effects: None
int CharLinkedList::size() const {
    return numItems;
}

// name: first
// purpose: To return the first char in the list
// arguments: None
// returns: The first char in the list
// effects: None
char CharLinkedList::first() const {
    if (numItems == 0) {
        throw std::runtime_error("cannot get first of empty LinkedList");
    }
    return front->c;
}

// name: last
// purpose: To return the last char in the list
// arguments: None
// returns: The last char in the list
// effects: None
char CharLinkedList::last() const {
    if (numItems == 0) {
        throw std::runtime_error("cannot get last of empty LinkedList");
    }

    Node *node = findNode(front, 0, numItems - 1);
    return node->c;
}

// name: elementAt
// purpose: To return the element at the given index
// arguments: The index of the desired element
// returns: The element at the index
// effects: None
char CharLinkedList::elementAt(int index) const {
    if (index >= numItems or index < 0) rangeError(index);

    Node *node = findNode(front, 0, index);
    return node->c;
}

// name: toString
// purpose: To print out the size of and the chars in the linked list
// arguments: None
// returns: A formatted string with the size and the chars in the list
// effects: None
std::string CharLinkedList::toString() const {
    std::stringstream ss;

    ss << "[CharLinkedList of size " << numItems << " <<";
    Node *curr = front;
    while (curr != nullptr) {
        ss << curr->c;
        curr = curr->next;
    }
    ss << ">>]";
    return ss.str();
}

// name: toReverseString
// purpose: To print out the size of and the chars in the linked list
//          reversed
// arguments: None
// returns: A formatted string with the size and the chars in the list
//          reversed
// effects: None
std::string CharLinkedList::toReverseString() const {
    std::stringstream ss;

    ss << "[CharLinkedList of size " << numItems << " <<";
    Node *curr;
    if (numItems == 0) curr = front;
    else curr = findNode(front, 0, numItems - 1);
    while (curr != nullptr) {
        ss << curr->c;
        curr = curr->previous;
    }
    ss << ">>]";
    return ss.str();
}

// name: pushAtBack
// purpose: Adds a char to the back of the list
// arguments: The char that will be added to the list
// returns: None
// effects: The size of the list increments by one
void CharLinkedList::pushAtBack(char c) {
    if (front == nullptr) front = newNode(c, nullptr, nullptr);
    else {
        Node *back = findNode(front, 0, numItems - 1);
        back->next = newNode(c, nullptr, back);
    } 
}

// name: pushAtFront
// purpose: Adds a char to the front of the list
// arguments: The char that will be added to the list
// returns: None
// effects: The size of the list increments by one
void CharLinkedList::pushAtFront(char c) {
    if (front == nullptr) front = newNode(c, nullptr, nullptr);
    else {
        Node *node = newNode(c, front, nullptr);
        front->previous = node;
        front = node;
    }
}

// name: insertAt
// purpose: Adds a char to the desired index on the list
// arguments: The char that will be added and the index it will be added at
// returns: None
// effects: The size of the list increments by one
void CharLinkedList::insertAt(char c, int index) {
    // If index is out of range error
    if (index > numItems or index < 0) {
        std::stringstream ss;
        ss << "index (" << index << ") not in range [0.." << numItems << "]";
        throw std::range_error(ss.str());
    }

    // Checks to see if another method would be better
    else if (front == nullptr) front = newNode(c, nullptr, nullptr);
    else if (index == 0) pushAtFront(c);
    else if (index == numItems) pushAtBack(c);

    // Inserts the char at the index
    else {
        Node *curr = findNode(front, 0, index - 1);
        Node *node = newNode(c, curr->next, curr);
        if (curr->next != nullptr) curr->next->previous = node;
        curr->next = node;
    }
}

// name: insertInOrder
// purpose: to insert a char in ASCII order
// arguments: the char that will be inserted
// returns: None
// effects: The size of the list will increment by one
void CharLinkedList::insertInOrder(char c) {
    if (numItems == 0) pushAtFront(c);

    // Compares elements ASCII to char c ASCII
    else {
        Node *curr = front;
        int curr_index = 0;
        while (c >= curr->c and curr_index != numItems) {
            if (curr->next != nullptr) curr = curr->next;
            curr_index++;
        }
        insertAt(c, curr_index);
    }
}

// name: popFromFront
// purpose: To remove the first char from the list
// arguments: None
// returns: None
// effects: The size of the list decreases by one
void CharLinkedList::popFromFront() {
    if (front == nullptr) {
        throw std::runtime_error("cannot pop from empty LinkedList");
    }

    Node *temp = front;
    if (numItems == 1) front = nullptr;
    else {
        front = front->next;
        front->previous = nullptr;
    }
    numItems--;
    delete temp;
}

// name:popFromBack
// purpose: To remove the last char from the list
// arguments: None
// returns: None
// effects: The size of the list decreases by one
void CharLinkedList::popFromBack() {
    if (front == nullptr) {
        throw std::runtime_error("cannot pop from empty LinkedList");
    }

    if (numItems == 1) popFromFront();
    else {
        Node *curr = findNode(front, 0, numItems - 1);
        curr->previous->next = nullptr;
        numItems--;
        delete curr;
    }
}

// name: removeAt
// purpose: To remove the char at the given index from the list 
// arguments: The index of the char that will be removed
// returns: None
// effects: The size of the list decreases by one
void CharLinkedList::removeAt(int index) {
    if (index >= numItems or index < 0) rangeError(index);

    if (index == 0) popFromFront();
    else if (index == numItems - 1) popFromBack();
    else {
        Node *curr = findNode(front, 0, index);
        curr->previous->next = curr->next;
        numItems--;
        delete curr;
    }
}

// name: replaceAt
// purpose: To replace the char at the given index with the given char
// arguments: The desired index of the replacement and the replacement char
// returns: None
// effects: Swaps a char in the list with another char
void CharLinkedList::replaceAt(char c, int index) {
    if (index >= numItems or index < 0) rangeError(index);

    removeAt(index);
    insertAt(c, index);
}

// name: concatenate
// purpose: To add the elements of the given list to the end of the
//          current instance
// arguments: A pointer to the list whose contents will be added
// returns: None
// effects: The number of items increases by the numItems in the given list
void CharLinkedList::concatenate(CharLinkedList *other) {
    if (other->front == nullptr) return;
    Node *curr;
    if (this == other) {
        CharLinkedList list1(*this);
        curr = list1.front;
        copy(curr);

        return;
    }
    curr = other->front;
    copy(curr);
}
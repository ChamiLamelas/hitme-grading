/*
 *  CharLinkedList.h
 *  Charlie Fitzpatrick
 *  2/2/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Purpose: To declare all of the special and helper functions that this
 *           linked list can perform and use. Also to declare the struct that will 
 *           hold the elements, the size of the list, and the pointer to 
 *           the front of the list.
 *
 */

#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H

#include <sstream>
#include <iostream>

class CharLinkedList {
public:
    CharLinkedList();
    CharLinkedList(char c);
    CharLinkedList(char arr[], int size);
    CharLinkedList(const CharLinkedList &other);
    ~CharLinkedList();
    CharLinkedList &operator=(const CharLinkedList &other);
    bool isEmpty() const;
    void clear();
    int size() const;
    char first() const;
    char last() const;
    char elementAt(int index) const;
    std::string toString() const;
    std::string toReverseString() const;
    void pushAtBack(char c);
    void pushAtFront(char c);
    void insertAt(char c, int index);
    void insertInOrder(char c);
    void popFromFront();
    void popFromBack();
    void removeAt(int index);
    void replaceAt(char c, int index);
    void concatenate(CharLinkedList *other);
private:
    struct Node {
        char c;
        Node *previous;
        Node *next;
    };

    // Helper functions
    void rangeError(int index) const;
    Node *findNode(Node *curr, int curr_index, int index) const;
    Node *newNode(char c, Node *next, Node *previous);
    void cleanUp(Node *curr);
    void copy(Node *curr);

    Node *front;
    int numItems;
};

#endif

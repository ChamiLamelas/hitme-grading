/*
 *  unit_tests.h
 *  Weston Starbird
 *  1/31/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  FILE PURPOSE HERE
 *
 */
#include "CharLinkedList.h"
#include <cassert>

/*
* name: defaultConstructor_test
* purpose: Tests that the default constructor correctly
* initializes a test_list
* effects: asserts that the size of the test list = 0 
* and that the test list isEmpty immediately after 
* initialization
*/
void defaultConstructor_test() {
    CharLinkedList test_list;
    assert(test_list.size() == 0);
    assert(test_list.isEmpty());
}

/**
 * name:      singleCharConstructor_test
 * purpose:   Tests the constructor with a single character
 * effects:   Asserts that size is 1, isEmpty returns false, and the first 
 * element is as expected
 */
void singleCharConstructor_test() {
    CharLinkedList test_list('a');
    assert(test_list.size() == 1);
    assert(not test_list.isEmpty());
    assert(test_list.elementAt(0) == 'a');
}

/**
 * name:      charListConstructor_test
 * purpose:   Tests the constructor with a character List
 * effects:   Asserts that size matches the input List and elements 
 * are correctly assigned
 */
void charListConstructor_test() {
    char test_arr[3] = { 'a', 'b', 'c' };
    CharLinkedList test_list(test_arr, 3); //testing 3rd constructor
    assert(test_list.size() == 3);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    assert(test_list.elementAt(2) == 'c');
}

/**
 * name:      charListConstructor_empty_test
 * purpose:   Tests the constructor with an empty character List
 * effects:   Asserts that size is 0 and isEmpty returns true for an empty 
 * List
 */
void charListConstructor_empty_test() {
    char test_arr[0] = {};
    CharLinkedList test_list(test_arr, 0);
    assert(test_list.size() == 0);
    assert(test_list.isEmpty());
}

/**
 * name:      copyConstructor_test
 * purpose:   Tests the copy constructor
 * effects:   Asserts that the copied CharLinkedList matches the original 
 * in size and content
 */
void copyConstructor_test() {
    CharLinkedList original_list('a');
    CharLinkedList copied_list(original_list);

    assert(copied_list.size() == original_list.size());
    assert(copied_list.elementAt(0) == original_list.elementAt(0));
}

/**
 * name:      copyConstructor_empty_test
 * purpose:   Tests the copy constructor with an empty CharLinkedList
 * effects:   Asserts that the copied list is empty
 */
void copyConstructor_empty_test() {
    CharLinkedList original_list;
    CharLinkedList copied_list(original_list);

    assert(copied_list.size() == 0);
    assert(copied_list.isEmpty());
}

/**
 * name:      assignmentOperator_test
 * purpose:   Tests the assignment operator for non-empty CharLinkedLists
 * effects:   Asserts that the assigned CharLinkedList matches the source 
 * in size and content
 */
void assignmentOperator_test() {
    CharLinkedList list1('a');
    CharLinkedList list2;
    list2 = list1;

    assert(list2.size() == 1);
    assert(list2.elementAt(0) == 'a'); // make sure list1 and list2 
    //are the same
}

/**
 * name:      assignmentOperator_empty_test
 * purpose:   Tests the assignment operator with an empty CharLinkedList
 * effects:   Asserts that the assigned list is empty
 */
void assignmentOperator_empty_test() {
    CharLinkedList list1;
    CharLinkedList list2;
    list2 = list1;

    assert(list2.size() == 0);
    assert(list2.isEmpty());
}

/**
 * name:      assignmentOperator_self_test
 * purpose:   Tests the assignment operator for self-assignment
 * effects:   Asserts that the list remains unchanged after self-assignment
 */
void assignmentOperator_self_test() {
    CharLinkedList list1('a');
    CharLinkedList& ref_list1 = list1;
    list1 = ref_list1;

    assert(list1.size() == 1);
    assert(list1.elementAt(0) == 'a');
}

/**
 * name:      isEmpty_empty_test
 * purpose:   Tests isEmpty method on an empty CharLinkedList
 * effects:   Asserts that isEmpty returns true for an empty list
 */
void isEmpty_empty_test() {
    CharLinkedList test_list;
    assert(test_list.isEmpty());
}

/**
 * name:      isEmpty_nonEmpty_test
 * purpose:   Tests isEmpty method on a non-empty CharLinkedList
 * effects:   Asserts that isEmpty returns false for a non-empty list
 */
void isEmpty_nonEmpty_test() {
    CharLinkedList test_list('a');
    assert(not test_list.isEmpty());
}

/**
 * name:      clear_nonEmpty_test
 * purpose:   Tests clear method on a non-empty CharLinkedList
 * effects:   Asserts that the list is empty after clearing
 */
void clear_nonEmpty_test() {
    CharLinkedList test_list('a');
    test_list.clear();
    assert(test_list.size() == 0);
    assert(test_list.isEmpty());
}

/**
 * name:      clear_empty_test
 * purpose:   Tests clear method on an already empty CharLinkedList
 * effects:   Asserts that the list remains empty after clearing
 */
void clear_empty_test() {
    CharLinkedList test_list;
    test_list.clear();
    assert(test_list.size() == 0);
    assert(test_list.isEmpty());
}

/**
 * name:      size_nonEmpty_test
 * purpose:   Tests size method on a non-empty CharLinkedList
 * effects:   Asserts that the size returned matches the expected 
 * number of elements
 */
void size_nonEmpty_test() {
    CharLinkedList test_list('a');
    assert(test_list.size() == 1);
}

/**
 * name:      size_empty_test
 * purpose:   Tests size method on an empty CharLinkedList
 * effects:   Asserts that the size returned is 0
 */
void size_empty_test() {
    CharLinkedList test_list;
    assert(test_list.size() == 0);
}

/**
 * name:      first_nonEmpty_test
 * purpose:   Tests first method on a non-empty CharLinkedList
 * effects:   Asserts that the first element is as expected
 */
void first_nonEmpty_test() {
    CharLinkedList test_list('a');
    assert(test_list.first() == 'a');
}

/**
 * name:      first_empty_test
 * purpose:   Tests first method on an empty CharLinkedList
 * effects:   Asserts that a runtime_error is thrown when trying to access 
 * the first element of an empty list
 */
void first_empty_test() {
    CharLinkedList test_list;
    bool exception_thrown = false;
    try {
        char first = test_list.first();
    } catch (const std::runtime_error& e) {
        exception_thrown = true;
    }
    assert(exception_thrown);
}

/**
 * name:      first_multichar_test
 * purpose:   Tests first method on a CharLinkedList initialized with multiple 
 * characters
 * effects:   Asserts that the first element is as expected
 */
void first_multichar_test() {
    char test_arr[3] = {'a', 'b', 'c'};
    CharLinkedList test_list(test_arr, 3);
    assert(test_list.first() == 'a');
}

/**
 * name:      first_emptyList_error
 * purpose:   Tests first method error handling on an empty CharLinkedList
 * effects:   Asserts that the appropriate runtime_error is thrown with 
 * the correct message
 */
void first_emptyList_error() {
    bool runtime_error_thrown = false;
    std::string error_message = "";

    CharLinkedList test_list;
    try {
        char firstElement = test_list.first();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot get first of empty LinkedList");
}

/**
 * name:      last_nonEmpty_test
 * purpose:   Tests last method on a non-empty CharLinkedList
 * effects:   Asserts that the last element is as expected
 */
void last_nonEmpty_test() {
    CharLinkedList test_list('a');
    assert(test_list.last() == 'a');
}

/**
 * name:      last_empty_test
 * purpose:   Tests last method on an empty CharLinkedList
 * effects:   Asserts that a runtime_error is thrown when trying 
 * to access the last element of an empty list
 */
void last_empty_test() {
    CharLinkedList test_list;
    bool exception_thrown = false;
    try {
        char last = test_list.last();
    } catch (const std::runtime_error& e) {
        exception_thrown = true;
    }
    assert(exception_thrown);
}

/**
 * name:      last_multichar_test
 * purpose:   Tests last method on a CharLinkedList initialized 
 * with multiple characters
 * effects:   Asserts that the last element is as expected
 */
void last_multichar_test() {
    char test_arr[3] = {'a', 'b', 'c'};
    CharLinkedList test_list(test_arr, 3);
    assert(test_list.last() == 'c');
}

/**
 * name:      last_emptyList_error
 * purpose:   Tests last method error handling on an empty CharLinkedList
 * effects:   Asserts that the appropriate runtime_error 
 * is thrown with the correct message
 */
void last_emptyList_error() {
    bool runtime_error_thrown = false;
    std::string error_message = "";

    CharLinkedList test_list;
    try {
        char lastElement = test_list.last();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot get last of empty LinkedList");
}

/**
 * name:      elementAt_valid_test
 * purpose:   Tests elementAt method with a valid index on a CharLinkedList
 * effects:   Asserts that the element at the specified index is as expected
 */
void elementAt_valid_test() {
    char test_arr[3] = {'a', 'b', 'c'};
    CharLinkedList test_list(test_arr, 3);
    assert(test_list.elementAt(1) == 'b');
}

/**
 * name:      elementAt_negativeIndex_test
 * purpose:   Tests elementAt method error handling with a negative index
 * effects:   Asserts that a range_error is thrown for a negative index
 */
void elementAt_negativeIndex_test() {
    CharLinkedList test_list('a');
    bool exception_thrown = false;
    try {
        char element = test_list.elementAt(-1);
    } catch (const std::range_error& e) {
        exception_thrown = true;
    }
    assert(exception_thrown);
}

/**
 * name:      elementAt_outOfRange_test
 * purpose:   Tests elementAt method error handling with an out-of-range index
 * effects:   Asserts that a range_error is thrown 
 * for an index out of the list's range
 */
void elementAt_outOfRange_test() {
    CharLinkedList test_list('a');
    bool exception_thrown = false;
    try {
        char element = test_list.elementAt(1);
    } catch (const std::range_error& e) {
        exception_thrown = true;
    }
    assert(exception_thrown);
}

/**
 * name:      elementAt_outOfRange_error
 * purpose:   Tests elementAt method error message for an out-of-range index
 * effects:   Asserts that the appropriate range_error 
 * is thrown with the correct message
 */
void elementAt_outOfRange_error() {
    bool range_error_thrown = false;
    std::string error_message = "";

    CharLinkedList test_list;
    try {
        char element = test_list.elementAt(42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0)");
}

/**
 * name:      toString_nonEmpty_test
 * purpose:   Tests the toString method on a non-empty CharLinkedList
 * effects:   Asserts that the string representation matches 
 * the expected format with the correct elements
 */
void toString_nonEmpty_test() {
    char test_arr[] = {'a', 'b', 'c'};
    CharLinkedList test_list(test_arr, 3);
    assert(test_list.toString() == "[CharLinkedList of size 3 <<abc>>]");
}

/**
 * name:      toString_empty_test
 * purpose:   Tests the toString method on an empty CharLinkedList
 * effects:   Asserts that the string representation 
 * correctly indicates an empty list
 */
void toString_empty_test() {
    CharLinkedList test_list;
    assert(test_list.toString() == "[CharLinkedList of size 0 <<>>]");
}

/**
 * name:      toReverseString_nonEmpty_test
 * purpose:   Tests the toReverseString method on a non-empty CharLinkedList
 * effects:   Asserts that the reversed string 
 * representation matches the expected format
 */
void toReverseString_nonEmpty_test() {
    char test_arr[] = {'a', 'b', 'c'};
    CharLinkedList test_list(test_arr, 3);
    assert(test_list.toReverseString() == "[CharLinkedList of size 3 <<cba>>]");
}

/**
 * name:      toReverseString_empty_test
 * purpose:   Tests the toReverseString method on an empty CharLinkedList
 * effects:   Asserts that the reversed string 
 * representation correctly indicates an empty list
 */
void toReverseString_empty_test() {
    CharLinkedList test_list;
    assert(test_list.toReverseString() == "[CharLinkedList of size 0 <<>>]");
}

/**
 * name:      pushAtBack_nonEmpty_test
 * purpose:   Tests the pushAtBack method on a non-empty CharLinkedList
 * effects:   Asserts that elements are correctly added at the back of the list
 */
void pushAtBack_nonEmpty_test() {
    CharLinkedList test_list;
    test_list.pushAtBack('a');
    test_list.pushAtBack('b');
    assert(test_list.size() == 2);
    assert(test_list.elementAt(1) == 'b');
}

/**
 * name:      pushAtBack_empty_test
 * purpose:   Tests the pushAtBack method on an empty CharLinkedList
 * effects:   Asserts that an element is correctly added to an empty list
 */
void pushAtBack_empty_test() {
    CharLinkedList test_list;
    test_list.pushAtBack('a');
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');
}


/**
 * name:      pushAtFront_nonEmpty_test
 * purpose:   Tests the pushAtFront method on a non-empty CharLinkedList
 * effects:   Asserts that elements are correctly 
 * added at the front of the list
 */
void pushAtFront_nonEmpty_test() {
    CharLinkedList test_list;
    test_list.pushAtFront('b');
    test_list.pushAtFront('a');
    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
}

/**
 * name:      pushAtFront_empty_test
 * purpose:   Tests the pushAtFront method on an empty CharLinkedList
 * effects:   Asserts that an element is correctly added to an empty list
 */
void pushAtFront_empty_test() {
    CharLinkedList test_list;
    test_list.pushAtFront('a');
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');
}


// Tests correct insertion into an empty AL.
// Afterwards, size should be 1 and element at index 0
// should be the element we inserted.
void insertAt_empty_correct() { 

    CharLinkedList test_list; // creates CharLinkedList object
    test_list.insertAt('a', 0); //call test method in order to test it
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a'); 
    // assert that, after a is insertad at 0, the element at 0 is a
}

// Tests incorrect insertion into an empty AL.
// Attempts to call insertAt for index larger than 0.
// This should result in an std::range_error being raised.
void insertAt_empty_incorrect() {

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    // insertAt for out-of-range index
    test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
    // if insertAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    range_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0]");
    
}

// Tests correct insertAt for front of 1-element list.
void insertAt_front_singleton_list() {
    
    // initialize 1-element list 
    CharLinkedList test_list('a');
    // insert at front
    test_list.insertAt('b', 0);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'a');
    
}

// Tests correct insertAt for back of 1-element list.
void insertAt_back_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at back
    test_list.insertAt('b', 1);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    
}

// Tests calling insertAt for a large number of elements.

void insertAt_many_elements() {
    
    CharLinkedList test_list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.insertAt('a', i);
    }

    assert(test_list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
    
}

// Tests insertion into front of a larger list
void insertAt_front_large_list() {
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    test_list.insertAt('y', 0);

    assert(test_list.size() == 10);
    assert(test_list.elementAt(0) == 'y');
    assert(test_list.toString() == 
            "[CharLinkedList of size 10 <<yabczdefgh>>]");

}

// Tests insertion into the back of a larger list
void insertAt_back_large_list() {

    char test_arr[10] = { 'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 10);  

    test_list.insertAt('x', 10);

    assert(test_list.size() == 11);
    assert(test_list.elementAt(10) == 'x');
    assert(test_list.toString() == 
         "[CharLinkedList of size 11 <<yabczdefghx>>]"); 

}

// Tests insertion into the middle of a larger list
void insertAt_middle_large_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.insertAt('z', 3);

    assert(test_list.size() == 9);
    assert(test_list.elementAt(3) == 'z');
    assert(test_list.toString() == "[CharLinkedList of size 9 <<abczdefgh>>]");

}

// Tests out-of-range insertion for a non-empty list.
void insertAt_nonempty_incorrect() {
   
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8]");
    
}

/**
 * name:      insertInOrder_emptyList
 * purpose:   Tests inserting an element in order into an empty CharLinkedList
 * effects:   Asserts that the element is correctly added to the list
 */
void insertInOrder_emptyList() {
    CharLinkedList test_list;
    test_list.insertInOrder('a');
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');
}

/**
 * name:      insertInOrder_beginning
 * purpose:   Tests inserting an element at the beginning of 
 * CharLinkedList in sorted order
 * effects:   Asserts that the element is correctly placed at the beginning
 */
void insertInOrder_beginning() {
    CharLinkedList test_list;
    test_list.insertInOrder('b');
    test_list.insertInOrder('a'); // 'a' should go before 'b'
    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
}

/**
 * name:      insertInOrder_end
 * purpose:   Tests inserting an element at the end of CharLinkedList 
 * in sorted order
 * effects:   Asserts that the element is correctly placed at the end
 */
void insertInOrder_end() {
    CharLinkedList test_list;
    test_list.insertInOrder('a');
    test_list.insertInOrder('c'); // 'c' should go after 'a'
    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'c');
}

/**
 * name:      insertInOrder_middle
 * purpose:   Tests inserting an element in the middle of 
 * CharLinkedList in sorted order
 * effects:   Asserts that the element is correctly placed in the middle
 */
void insertInOrder_middle() {
    CharLinkedList test_list;
    test_list.insertInOrder('a');
    test_list.insertInOrder('c');
    test_list.insertInOrder('b'); // 'b' should go between 'a' and 'c'
    assert(test_list.size() == 3);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    assert(test_list.elementAt(2) == 'c');
}

/**
 * name:      insertInOrder_duplicate
 * purpose:   Tests inserting a duplicate element in 
 * CharLinkedList in sorted order
 * effects:   Asserts that the duplicate element is correctly added
 */
void insertInOrder_duplicate() {
    CharLinkedList test_list;
    test_list.insertInOrder('a');
    test_list.insertInOrder('a'); // duplicate 'a'
    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'a');
}

/**
 * name:      insertInOrder_multipleElements
 * purpose:   Tests inserting multiple elements in CharLinkedList in 
 * sorted order
 * effects:   Asserts that elements are correctly sorted after insertion
 */
void insertInOrder_multipleElements() {
    CharLinkedList test_list;
    test_list.insertInOrder('d');
    test_list.insertInOrder('b');
    test_list.insertInOrder('c');
    test_list.insertInOrder('a'); // should sort to 'abcd'
    assert(test_list.size() == 4);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    assert(test_list.elementAt(2) == 'c');
    assert(test_list.elementAt(3) == 'd');
}

/**
 * name:      insertInOrder_largeNumber
 * purpose:   Tests inserting a large number of 
 * elements in reverse order in CharLinkedList
 * effects:   Asserts that elements are correctly sorted after insertion
 */
void insertInOrder_largeNumber() {
    CharLinkedList test_list;
    for (char c = 'z'; c >= 'a'; --c) {
        test_list.insertInOrder(c); // inserting in reverse order
    }

    assert(test_list.size() == 26);
    for (int i = 0; i < 26; i++) {
        assert(test_list.elementAt(i) == 'a' + i);
    }
}

/**
 * name:      popFromFront_nonempty
 * purpose:   Tests removing the front element from a non-empty CharLinkedList
 * effects:   Asserts that the first element is correctly removed
 */
void popFromFront_nonempty() {
    CharLinkedList test_list;
    test_list.pushAtBack('a');
    test_list.pushAtBack('b');
    test_list.popFromFront();
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'b');
}

/**
 * name:      popFromFront_singleton
 * purpose:   Tests removing the only element from a 
 * single-element CharLinkedList
 * effects:   Asserts that the list becomes empty
 */
void popFromFront_singleton() {
    CharLinkedList test_list('a');
    test_list.popFromFront();
    assert(test_list.isEmpty());
}

/**
 * name:      popFromFront_empty
 * purpose:   Tests the behavior of popFromFront on an empty CharLinkedList
 * effects:   Asserts that an exception is thrown when 
 * attempting to pop from an empty list
 */
void popFromFront_empty() {
    bool exceptionThrown = false;
    CharLinkedList test_list;
    try {
        test_list.popFromFront();
    } catch (const std::runtime_error& e) {
        exceptionThrown = true;
    }
    assert(exceptionThrown);
}

/**
 * name:      popFromFront_emptyList_error
 * purpose:   Tests the error message of popFromFront when 
 * called on an empty CharLinkedList
 * effects:   Asserts that the correct runtime_error is 
 * thrown with the appropriate message
 */
void popFromFront_emptyList_error() {
    CharLinkedList test_list;

    // Variables to track whether runtime_error is thrown and the error message
    bool runtime_error_thrown = false;
    std::string error_message = "";

    try {
        test_list.popFromFront();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

/**
 * name:      popFromBack_singleElement
 * purpose:   Tests removing the last element 
 * from a single-element CharLinkedList
 * effects:   Asserts that the list becomes empty after removal
 */
void popFromBack_singleElement() {
    CharLinkedList test_list;
    test_list.pushAtBack('a');
    test_list.popFromBack();
    assert(test_list.size() == 0);
    assert(test_list.isEmpty());
}

/**
 * name:      popFromBack_consecutivePops
 * purpose:   Tests consecutive removals from the back of a CharLinkedList
 * effects:   Asserts that elements are correctly removed from the back
 */
void popFromBack_consecutivePops() {
    CharLinkedList test_list;
    for (char c = 'a'; c <= 'c'; ++c) {
        test_list.pushAtBack(c);
    }
    // Remove elements one by one
    test_list.popFromBack();
    test_list.popFromBack();
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');
}

/**
 * name:      popFromBack_emptyList_error
 * purpose:   Tests the error message of popFromBack 
 * when called on an empty CharLinkedList
 * effects:   Asserts that the correct runtime_error 
 * is thrown with the appropriate message
 */
void popFromBack_emptyList_error() {
    CharLinkedList test_list;

    bool runtime_error_thrown = false;
    std::string error_message = "";

    try {
        test_list.popFromBack();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

/**
 * name:      removeAt_firstElement
 * purpose:   Tests removing the first element from a CharLinkedList
 * effects:   Asserts that the first element is correctly removed
 */
void removeAt_firstElement() {
    CharLinkedList test_list;
    test_list.pushAtBack('a');
    test_list.pushAtBack('b');
    test_list.removeAt(0);
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'b');
}

/**
 * name:      removeAt_lastElement
 * purpose:   Tests removing the last element from a CharLinkedList
 * effects:   Asserts that the last element is correctly removed
 */
void removeAt_lastElement() {
    CharLinkedList test_list;
    test_list.pushAtBack('a');
    test_list.pushAtBack('b');
    test_list.removeAt(1);
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');
}

/**
 * name:      removeAt_outOfRange_error
 * purpose:   Tests the error message of 
 * removeAt when called with an out-of-range index
 * effects:   Asserts that the correct range_error 
 * is thrown with the appropriate message
 */
void removeAt_outOfRange_error() {
    CharLinkedList test_list;
    test_list.pushAtBack('a'); // Ensure list is not empty

    bool range_error_thrown = false;
    std::string error_message = "";

    try {
        test_list.removeAt(1); // Index 1 is out of range for a 1-element list
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (1) not in range [0..1)");
}

/**
 * name:      replaceAt_firstElement
 * purpose:   Tests replacing the first element in a CharLinkedList
 * effects:   Asserts that the first element is correctly replaced
 */
void replaceAt_firstElement() {
    CharLinkedList test_list;
    test_list.pushAtBack('a');
    test_list.pushAtBack('b');
    test_list.replaceAt('z', 0);
    assert(test_list.elementAt(0) == 'z');
    assert(test_list.elementAt(1) == 'b');
}

/**
 * name:      replaceAt_lastElement
 * purpose:   Tests replacing the last element in a CharLinkedList
 * effects:   Asserts that the last element is correctly replaced
 */
void replaceAt_lastElement() {
    CharLinkedList test_list;
    test_list.pushAtBack('a');
    test_list.pushAtBack('b');
    test_list.replaceAt('z', 1);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'z');
}

/**
 * name:      replaceAt_outOfRange_error
 * purpose:   Tests the error message of replaceAt 
 * when called with an out-of-range index
 * effects:   Asserts that the correct range_error 
 * is thrown with the appropriate message
 */
void replaceAt_outOfRange_error() {
    CharLinkedList test_list;
    test_list.pushAtBack('a'); // Ensure list is not empty

    bool range_error_thrown = false;
    std::string error_message = "";

    try {
        test_list.replaceAt('b', 1); 
        // Index 1 is out of range for a 1-element list
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (1) not in range [0..1)");
}

/**
 * name:      concatenate_smallerToLarger
 * purpose:   Tests concatenating a smaller 
 * list onto a larger CharLinkedList
 * effects:   Asserts that the smaller list is correctly
 *  appended to the larger list
 */
void concatenate_smallerToLarger() {
    CharLinkedList test_list1;
    CharLinkedList test_list2;
    for (char c = 'a'; c <= 'c'; ++c) {
        test_list1.pushAtBack(c);
    }
    test_list2.pushAtBack('d');
    test_list1.concatenate(&test_list2);
    assert(test_list1.size() == 4);
    assert(test_list1.elementAt(3) == 'd');
}

/**
 * name:      concatenate_largerToSmaller
 * purpose:   Tests concatenating a larger list onto a smaller CharLinkedList
 * effects:   Asserts that the larger list is 
 * correctly appended to the smaller list
 */
void concatenate_largerToSmaller() {
    CharLinkedList test_list1;
    CharLinkedList test_list2;
    test_list1.pushAtBack('a');
    for (char c = 'b'; c <= 'd'; ++c) {
        test_list2.pushAtBack(c);
    }
    test_list1.concatenate(&test_list2);
    assert(test_list1.size() == 4);
    assert(test_list1.elementAt(3) == 'd');
}

/**
 * name:      concatenate_nullOrEmptyList
 * purpose:   Tests the behavior of concatenate 
 * when the other list is null or empty
 * effects:   Asserts that no change occurs to the 
 * CharLinkedList when concatenating a null or empty list
 */
void concatenate_nullOrEmptyList() {
    CharLinkedList test_list;
    test_list.pushAtBack('a');

    CharLinkedList *null_list = nullptr;
    CharLinkedList empty_list;

    test_list.concatenate(null_list); // should have no effect
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');

    test_list.concatenate(&empty_list); // should also have no effect
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');
}

//method to test the deepCopy helper function
void test_deepCopy_nonEmpty() {
    CharLinkedList original;
    original.pushAtBack('a');
    original.pushAtBack('b');
    original.pushAtBack('c');

    CharLinkedList copy = original; // Assuming deepCopy is used in the 
    //copy constructor or assignment operator

    // Check sizes match
    assert(original.size() == copy.size());

    // Modify original and ensure copy remains unchanged
    original.pushAtBack('d');
    assert(copy.size() == 3);
    assert(original.size() == 4);
    assert(copy.elementAt(0) == 'a');
    assert(copy.elementAt(1) == 'b');
    assert(copy.elementAt(2) == 'c');
}

//method to test the clearHelper helper function
void test_clear() {
    CharLinkedList list;
    list.pushAtBack('a');
    list.pushAtBack('b');
    list.clear(); // Assuming clear uses clearHelper

    // Verify list is empty
    assert(list.size() == 0);
}

//method to test the elementAt helper function
void test_elementAt() {
    CharLinkedList list;
    list.pushAtBack('x');
    list.pushAtBack('y');
    list.pushAtBack('z');

    // Test valid indices
    assert(list.elementAt(0) == 'x');
    assert(list.elementAt(1) == 'y');
    assert(list.elementAt(2) == 'z');

    // Test invalid index - this should throw an exception 
    //or be handled as per your implementation
    bool exceptionThrown = false;
    try {
        list.elementAt(3);
    } catch (const std::range_error& e) {
        exceptionThrown = true;
    }
    assert(exceptionThrown);
}

//method to test toReverseString helper function
void test_toReverseString() {
    CharLinkedList list;
    list.pushAtBack('1');
    list.pushAtBack('2');
    list.pushAtBack('3');

    std::string reversed = list.toReverseString();
    assert(reversed == "[CharLinkedList of size 3 <<321>>]");
}


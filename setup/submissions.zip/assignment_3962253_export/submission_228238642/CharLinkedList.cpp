/*
 *  CharLinkedList.cpp
 *  Weston Starbird
 *  1/31/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *   The purpose of this file is to program for each of the methods of an
 * interface for a LinkedList ADT as outlined by the header file
 * "CharLinkedList.h"
 *
 */

#include "CharLinkedList.h"

#include <stdexcept>
#include <cstring>
#include <iostream>
#include <sstream>

/**
 * name:      CharLinkedList (Default Constructor)
 * purpose:   Initializes an empty CharLinkedList
 * arguments: none
 * returns:   nothing
 * effects:   Creates a CharLinkedList with no elements
 */
CharLinkedList::CharLinkedList(){
    head = nullptr;
    tail = nullptr;
    listSize = 0;
}

/**
 * name:      CharLinkedList (Single Element Constructor)
 * purpose:   Initializes a CharLinkedList with a single element
 * arguments: char c - the character to initialize the list with
 * returns:   nothing
 * effects:   Creates a CharLinkedList with one element
 */
CharLinkedList::CharLinkedList(char c){
    head = new Node(c);
    tail = head;
    listSize = 1;
}

/**
 * name:      CharLinkedList (Array Constructor)
 * purpose:   Initializes a CharLinkedList from an array of characters
 * arguments: char arr[] - array of characters, int size - number of 
 * elements in arr
 * returns:   nothing
 * effects:   Creates a CharLinkedList containing the characters from the array
 */
CharLinkedList::CharLinkedList(char arr[], int size) {
    head = nullptr;
    tail = nullptr;
    listSize = 0;
    for (int i = 0; i < size; ++i) {
        pushAtBack(arr[i]);
    }
}

/**
 * name:      CharLinkedList (Copy Constructor)
 * purpose:   Initializes a CharLinkedList as a deep copy of another
 * arguments: const CharLinkedList &other - the list to copy
 * returns:   nothing
 * effects:   Creates a new list that is a deep copy of 'other'
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other) {
    head = nullptr;
    tail = nullptr;
    listSize = 0;
    deepCopy(other);
}

/**
 * name:      ~CharLinkedList (Destructor)
 * purpose:   Destroys the CharLinkedList, freeing memory
 * arguments: none
 * returns:   nothing
 * effects:   Deallocates all nodes in the list
 */
CharLinkedList::~CharLinkedList() {
    clear();
}

/**
 * name:      operator=
 * purpose:   Assigns one CharLinkedList to another, using deep copy
 * arguments: const CharLinkedList &other - the list to assign from
 * returns:   CharLinkedList& - a reference to the assigned list
 * effects:   Clears the current list and replaces it with a deep copy of 
 * 'other'
 */
CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other) {
    if (this != &other) {
        clear();
        deepCopy(other);
    }
    return *this;
}

/**
 * name:      isEmpty
 * purpose:   Checks if the list is empty
 * arguments: none
 * returns:   bool - true if the list is empty, false otherwise
 * effects:   none
 */
bool CharLinkedList::isEmpty() const {
    return head == nullptr;
}

/**
 * name:      clear
 * purpose:   Clears the list of all elements
 * arguments: none
 * returns:   nothing
 * effects:   Resets the list to an empty state
 */
void CharLinkedList::clear() {
    clearHelper(head);
    head = tail = nullptr;
    listSize = 0;
}

/**
 * name:      size
 * purpose:   Gets the number of elements in the list
 * arguments: none
 * returns:   int - the number of elements
 * effects:   none
 */
int CharLinkedList::size() const {
    return listSize;
}

/**
 * name:      first
 * purpose:   Gets the first element of the list
 * arguments: none
 * returns:   char - the first character in the list
 * effects:   Throws std::runtime_error if the list is empty
 */
char CharLinkedList::first() const {
    if (isEmpty()) 
        throw std::runtime_error("cannot get first of empty LinkedList");
    return head->data;
}

/**
 * name:      last
 * purpose:   Gets the last element of the list
 * arguments: none
 * returns:   char - the last character in the list
 * effects:   Throws std::runtime_error if the list is empty
 */
char CharLinkedList::last() const {
    if (isEmpty()) 
        throw std::runtime_error("cannot get last of empty LinkedList");
    return tail->data;
}

/**
 * name:      elementAt
 * purpose:   Gets the character at the specified index
 * arguments: int index - the index of the character
 * returns:   char - the character at the specified index
 * effects:   Throws std::range_error if the index is out of range
 */
char CharLinkedList::elementAt(int index) const {
    if (index < 0 or index >= size()) {
        std::string message = "index (" + std::to_string(index) 
                            + ") not in range [0.." 
                              + std::to_string(size()) + ")";
        throw std::range_error(message);
    }
    return elementAtHelper(head, index);
}


/**
 * name:      toString
 * purpose:   Generates a string representation of the list
 * arguments: none
 * returns:   std::string - the string representation
 * effects:   none
 */
std::string CharLinkedList::toString() const {
    std::string result = "[CharLinkedList of size " + 
                            std::to_string(listSize) + " <<";
    Node* current = head;
    while (current != nullptr) {
        result += current->data;
        if (current->next != nullptr) result += "";
        current = current->next;
    }
    result += ">>]";
    return result;
}

/**
 * name:      toReverseString
 * purpose:   Generates a string representation of the list in reverse order
 * arguments: none
 * returns:   std::string - the reverse string representation
 * effects:   none
 */
std::string CharLinkedList::toReverseString() const {
    std::string result = "[CharLinkedList of size " + std::to_string(listSize)
                                                     + " <<";
    if (tail != nullptr) {
        result += toReverseStringHelper(tail);
    }
    result += ">>]";
    return result;
}

/**
 * name:      pushAtBack
 * purpose:   Adds a character to the end of the list
 * arguments: char c - the character to add
 * returns:   nothing
 * effects:   Increases the size of the list by one
 */
void CharLinkedList::pushAtBack(char c) {
    Node* newNode = new Node(c);
    if (isEmpty()) {
        head = tail = newNode;
    } else {
        tail->next = newNode;
        newNode->prev = tail;
        tail = newNode;
    }
    listSize++;
}

/**
 * name:      pushAtFront
 * purpose:   Adds a character to the beginning of the list
 * arguments: char c - the character to add
 * returns:   nothing
 * effects:   Increases the size of the list by one
 */
void CharLinkedList::pushAtFront(char c) {
    Node* newNode = new Node(c);
    if (isEmpty()) {
        head = tail = newNode;
    } else {
        newNode->next = head;
        head->prev = newNode;
        head = newNode;
    }
    listSize++;
}

/**
 * name:      insertAt
 * purpose:   Inserts a character at the specified index
 * arguments: char c - the character to insert, int index - 
 * the position to insert at
 * returns:   nothing
 * effects:   Increases the size of the list by one, throws 
 * std::range_error if the index is out of range
 */
void CharLinkedList::insertAt(char c, int index) {
    if (index < 0 or index > size()) {
        std::ostringstream message;
        message << "index (" << index << ") not in range [0.." << size() << "]";
        throw std::range_error(message.str());
    }
    if (index == 0) {
        pushAtFront(c);
        return;
    }
    if (index == size()) {
        pushAtBack(c);
        return;
    }
    Node* current = head;
    for (int i = 0; i < index - 1; ++i) {
        current = current->next;
    }
    Node* newNode = new Node(c, current, current->next);
    current->next->prev = newNode;
    current->next = newNode;
    listSize++;
}

/**
 * name:      insertInOrder
 * purpose:   Inserts a character into the list in sorted order
 * arguments: char c - the character to insert
 * returns:   nothing
 * effects:   Increases the size of the list by one and maintains sorted order
 */
void CharLinkedList::insertInOrder(char c) {
    if (isEmpty() or c <= head->data) {
        pushAtFront(c);
        return;
    }
    Node* current = head;
    while (current->next != nullptr and current->next->data < c) {
        current = current->next;
    }
    Node* newNode = new Node(c, current, current->next);
    if (current->next != nullptr) {
        current->next->prev = newNode;
    } else {
        tail = newNode;
    }
    current->next = newNode;
    listSize++;
}

/**
 * name:      popFromFront
 * purpose:   Removes and deletes the first character from the list
 * arguments: none
 * returns:   nothing
 * effects:   Decreases the size of the list by one, throws 
 * std::runtime_error if the list is empty
 */
void CharLinkedList::popFromFront() {
    if (isEmpty()) {
        throw std::runtime_error("cannot pop from empty LinkedList");
    }
    Node* toDelete = head;
    head = head->next;
    if (head != nullptr) {
        head->prev = nullptr;
    } else {
        tail = nullptr; // List became empty
    }
    delete toDelete;
    listSize--;
}

/**
 * name:      popFromBack
 * purpose:   Removes and deletes the last character from the list
 * arguments: none
 * returns:   nothing
 * effects:   Decreases the size of the list by one,
 *  throws std::runtime_error if the list is empty
 */
void CharLinkedList::popFromBack() {
    if (isEmpty()) {
        throw std::runtime_error("cannot pop from empty LinkedList");
    }
    Node* toDelete = tail;
    tail = tail->prev;
    if (tail != nullptr) {
        tail->next = nullptr;
    } else {
        head = nullptr; // List became empty
    }
    delete toDelete;
    listSize--;
}

/**
 * name:      removeAt
 * purpose:   Removes and deletes the character at the specified index
 * arguments: int index - the index of the character to remove
 * returns:   nothing
 * effects:   Decreases the size of the list by one, 
 * throws std::range_error if the index is out of range
 */
void CharLinkedList::removeAt(int index) {
    if (index < 0 or index >= size()) {
        std::ostringstream message;
        message << "index (" << index << ") not in range [0.." << size() << ")";
        throw std::range_error(message.str());
    }
    if (index == 0) {
        popFromFront();
        return;
    }
    if (index == size() - 1) {
        popFromBack();
        return;
    }
    Node* current = head;
    for (int i = 0; i < index; ++i) {
        current = current->next;
    }
    current->prev->next = current->next;
    current->next->prev = current->prev;
    delete current;
    listSize--;
}

/**
 * name:      replaceAt
 * purpose:   Replaces the character at the specified 
 * index with a new character
 * arguments: char c - the new character, int index - 
 * the index of the character to replace
 * returns:   nothing
 * effects:   Modifies the character at the specified index, 
 * throws std::range_error if the index is out of range
 */
void CharLinkedList::replaceAt(char c, int index) {
    if (index < 0 or index >= size()) {
        std::ostringstream message;
        message << "index (" << index << ") not in range [0.." << size() << ")";
        throw std::range_error(message.str());
    }
    Node* current = head;
    for (int i = 0; i < index; ++i) {
        current = current->next;
    }
    current->data = c;
}

/**
 * name:      concatenate
 * purpose:   Appends all characters from another 
 * CharLinkedList to the end of this list
 * arguments: CharLinkedList *other - the list to append
 * returns:   nothing
 * effects:   Increases the size of the list by the size of 'other'
 */
void CharLinkedList::concatenate(CharLinkedList *other) {
    if (other == nullptr or other->isEmpty()) {
        return; // Nothing to concatenate
    }
    Node* current = other->head;
    while (current != nullptr) {
        pushAtBack(current->data); // Deep copy each element
        current = current->next;
    }
}

//private methods below:

/**
 * name:      deepCopy
 * purpose:   Creates a deep copy of another CharLinkedList
 * arguments: const CharLinkedList &source - the list to be copied
 * returns:   nothing
 * effects:   Copies all elements from 'source' into this list, 
 * ensuring no shared memory between the two lists
 */
void CharLinkedList::deepCopy(const CharLinkedList &source) {
    Node* currentNode = source.head;
    while (currentNode != nullptr) {
        pushAtBack(currentNode->data);
        currentNode = currentNode->next;
    }
}

/**
 * name:      clearHelper
 * purpose:   Recursively clears the list starting from a given node
 * arguments: Node* node - the starting node for clearing the list
 * returns:   nothing
 * effects:   Deletes all nodes from 'node' to the end of the list, 
 * effectively clearing the list when called with the head node
 */
void CharLinkedList::clearHelper(Node* node) {
    if (node == nullptr) return;
    clearHelper(node->next);
    delete node;
}

/**
 * name:      elementAtHelper
 * purpose:   Recursively retrieves the character at a specified index
 * arguments: Node* node - the starting node for the search, int index - 
 * the index of the character to retrieve
 * returns:   char - the character at the specified index
 * effects:   Traverses the list recursively to find and 
 * return the character at 'index'
 */
char CharLinkedList::elementAtHelper(Node* node, int index) const {
    if (index == 0) {
        return node->data;
    } else {
        return elementAtHelper(node->next, index - 1);
    }
}

/**
 * name:      toReverseStringHelper
 * purpose:   Recursively generates a reverse string representation of the 
 * list starting from a given node
 * arguments: Node* node - the starting node for creating the reverse string
 * returns:   std::string - the reverse string representation of the list from 
 * 'node' to the beginning
 * effects:   Builds a string of characters in reverse order by traversing 
 * the list backwards, starting from 'node'
 */
std::string CharLinkedList::toReverseStringHelper(Node* node) const {
    std::string result;
    if (node == nullptr) {
        return result;
    }
    if (node != tail) {
        result += "";
    }
    result += node->data + toReverseStringHelper(node->prev);
    return result;
}



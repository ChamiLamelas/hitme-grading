/*
 *  unit_tests.h
 *  Elliot Rutherford
 *  2/1/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  file purpose: tests all of the functions in CharLinkedList
 *
 */

#include "CharLinkedList.h"
#include <cassert>
#include <iostream>

void default_constructor_test_1(){
    CharLinkedList list;
    assert(list.size() == 0);
    assert(list.isEmpty());
}

void second_constructor_test_(){
    CharLinkedList list('a');
    assert(list.size() == 1);
    assert(not list.isEmpty());

}

void array_constructor_test(){
    char arr[] = {'a','b','c','d','e'};
    CharLinkedList list(arr, 5);
    assert(list.size() == 5);
    assert(list.toString() == "[CharLinkedList of size 5 <<abcde>>]");
}

//test for push at back
//tests pushing at back with an empty list pushing at back with a populated
//list
void pushAtBack_test1(){
    CharLinkedList list;
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]" );
    assert(list.isEmpty());
    list.pushAtBack('a');
    assert(list.toString() == "[CharLinkedList of size 1 <<a>>]" );
    list.pushAtBack('b');
    assert(list.toString() == "[CharLinkedList of size 2 <<ab>>]");
}


/* tests pushing onto an empty List
tests pushing onto a list with elements already on it
tests that the list is keeping track of the front properly
tests that the list is keeping front of the last properly
*/
void pushAtFront_test(){
    CharLinkedList list;
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]" );
    assert(list.isEmpty());
    list.pushAtFront('b');
    assert(list.toString() == "[CharLinkedList of size 1 <<b>>]" );
    assert(list.size() == 1);
    list.pushAtFront('a');
    assert(list.toString() == "[CharLinkedList of size 2 <<ab>>]" );
    assert(list.first() == 'a');
    assert(list.last() == 'b');
}

//tests getting first from an empty list
void first_test_1(){
    CharLinkedList list;
    std::string error_message = "";
    bool runtime_error_thrown = false;
    try{
        char c = list.first();
    } catch(std::runtime_error &e){
        error_message = e.what();
        runtime_error_thrown = true;
    }
    assert(runtime_error_thrown);
    assert(error_message == "cannot get first of empty LinkedList");
}

//tests getting front from a list with elements in it
void front_test_2(){
    char arr[] = {'a','b','c','d'};
    CharLinkedList list(arr, 4);
    assert(list.first() == 'a');
}

//tests getting last from an empty list
void last_test_1(){
    CharLinkedList list;
    std::string error_message = "";
    bool runtime_error_thrown = false;
    try{
        char c = list.last();
    } catch(std::runtime_error &e){
        error_message = e.what();
        runtime_error_thrown = true;
    }
    assert(runtime_error_thrown);
    assert(error_message == "cannot get last of empty LinkedList");
}


// tests getting last from a populated list
void last_test2(){
    char arr[] = {'a','b','c','d'};
    CharLinkedList list(arr, 4);
    assert(list.last() == 'd');
    assert(list.size() == 4);
}

void elementAt_test(){
    CharLinkedList list;
    list.pushAtBack('a');
    list.pushAtBack('b');
    list.pushAtBack('c');
    list.pushAtBack('d');
    assert(list.size() == 4);
    assert(list.elementAt(0) == 'a');
    assert(list.elementAt(3) == 'd');
    assert(list.elementAt(2) == 'c');

}

void elementAtTest_2(){
    CharLinkedList list;
    bool range_error_thrown;
    std::string error_message = "";
    
    //tests throwing exceptoin when list is empty and index is out of range
    try{
        list.elementAt(1);
    } catch(std::range_error &e){
        error_message = e.what();
        range_error_thrown = true;
    }

    assert(range_error_thrown);
    assert(error_message == "index (1) not in range [0..0)");
    
    //tests throwing exception when list is empty and index is 0
    try{
        list.elementAt(0);
    } catch(std::range_error &e){
        error_message = e.what();
        range_error_thrown = true;
    }

    assert(range_error_thrown);
    assert(error_message == "index (0) not in range [0..0)");
    list.pushAtFront('a');
    
    //tests throwing exception when list is not epmty but index is out of 
      //range
    try{
        list.elementAt(1);
    } catch(std::range_error &e){
        error_message = e.what();
        range_error_thrown = true;
    }

    assert(range_error_thrown);
    assert(error_message == "index (1) not in range [0..1)");
    
}

//tests toReverse string
void toReverseString_test(){
    char arr[] = {'E','l','l','i','o','t'};
    CharLinkedList list(arr, 6);
    std::cout << list.toReverseString() << std::endl;
    assert(list.toReverseString()=="[CharLinkedList of size 6 <<toillE>>]");

}

//tests insert at with a populated list 
//tests adding to the front of a populated list
//tests adding to the back of a populated list
//makes sure all of the pointers are good using toString and 
//toReverseString
void insertAt_test1(){
    char arr[] = {'a','b','c'};
    CharLinkedList list(arr, 3);
    list.insertAt('z', 1);
    assert(list.toString() == "[CharLinkedList of size 4 <<azbc>>]");
    list.insertAt('g',0);
    assert(list.toString() == "[CharLinkedList of size 5 <<gazbc>>]");
    list.insertAt('p',5);
    assert(list.toString() == "[CharLinkedList of size 6 <<gazbcp>>]");
    assert(list.toReverseString()=="[CharLinkedList of size 6 <<pcbzag>>]");
}

void insertAt_test2(){
    char arr[] = {'a','b','c'};
    CharLinkedList list(arr, 3);  
    std::string error_message = "";
    bool range_error_thrown = false;    
    try{
        list.insertAt('v',41);
    } catch(std::range_error &e){
        range_error_thrown = true;
        error_message = e.what();
    }      
    assert(range_error_thrown);
    assert(error_message == "index (41) not in range [0..3]");
}


// tests replacing at the begenning of the list
// at the end of the list,
// in the middle of the list,
// and makes sure error is thrown if index is ob
void replaceAt_test(){
    char arr[] = {'a','b','c'};
    CharLinkedList list(arr, 3);
    list.replaceAt('x', 0);
    assert(list.toString() == "[CharLinkedList of size 3 <<xbc>>]");
    list.replaceAt('y', 1);
    assert(list.toString() == "[CharLinkedList of size 3 <<xyc>>]");
    list.replaceAt('z',2);
    assert(list.toString() == "[CharLinkedList of size 3 <<xyz>>]");
    
    std::string error_message = "";
    bool range_error_thrown = false;
    try{
        list.replaceAt('a',3);
    } catch(std::range_error &e){
        error_message = e.what();
        range_error_thrown = true;
    }
    assert(range_error_thrown);
    assert(error_message == "index (3) not in range [0..3)");
}

void popFromBack_test1(){
    char arr[] = {'a','b','c'};
    CharLinkedList list(arr, 3);
    assert(list.toString() == "[CharLinkedList of size 3 <<abc>>]");
    list.popFromBack();
    assert(list.size() == 2);
    assert(list.toString() == "[CharLinkedList of size 2 <<ab>>]");
}

void popFromBack_test2(){
    CharLinkedList list;
    bool runtime_error_thrown = false;
    std::string error_message = "";
    try{
        list.popFromBack();
    } catch(std::runtime_error &e){
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

void popFromFront_test1(){
    char arr[] = {'a','b','c','d'};
    CharLinkedList list(arr, 4);
    list.popFromFront();
    assert(list.size() == 3);
    assert(list.toString() == "[CharLinkedList of size 3 <<bcd>>]");

}

void popFromFront_test2(){
    CharLinkedList list;
    bool runtime_error_trown = false;
    std::string error_message = "";
    try{
        list.popFromFront();
    } catch(std::runtime_error &e){
        runtime_error_trown = true;
        error_message = e.what();
    }
    assert(runtime_error_trown = true);
    assert(error_message == "cannot pop from empty LinkedList");
}

//tests clear
void clear_test(){
    char arr[] = {'a', 'b', 'c'};
    CharLinkedList list(arr, 3);
    list.clear();
    assert(list.isEmpty());

}

void insertInOrder_test(){
    char arr[] = {'a','b','d'};
    CharLinkedList list(arr, 3);
    list.insertInOrder('c');
    assert(list.toString() == "[CharLinkedList of size 4 <<abcd>>]");
    list.insertInOrder('a');
    assert(list.toString() == "[CharLinkedList of size 5 <<aabcd>>]");
    list.insertInOrder('z');
    assert(list.toString() == "[CharLinkedList of size 6 <<aabcdz>>]");
}

//tests:
/*removing at the front
removing in the middle
removing at the end
removing the only element in the list
removing from an empty list
*/
void removeAtTest(){
    char arr[] = {'a','b','c','d'};
    CharLinkedList list(arr, 4);
    list.removeAt(0);
    assert(list.toString() == "[CharLinkedList of size 3 <<bcd>>]");
    list.removeAt(1);
    assert(list.toString() == "[CharLinkedList of size 2 <<bd>>]");
    list.removeAt(1);
    assert(list.toString() == "[CharLinkedList of size 1 <<b>>]");
    list.removeAt(0);
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
    
    std::string error_message = "";
    bool range_error_thrown = false;
    try{
        list.removeAt(0);
    } catch(std::range_error &e){
         range_error_thrown = true;
         error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (0) not in range [0..0)");
}

// tests with a larger list and also makes sure all of the pointers are in
//order using toString and toReverseString
void removeAt_test2(){
    char arr[] = {'a','b','c','d','e','f','g','h'};
    CharLinkedList list(arr, 8);
    list.removeAt(4);
    assert(list.toString() == "[CharLinkedList of size 7 <<abcdfgh>>]");
    assert(list.toReverseString()== "[CharLinkedList of size 7 <<hgfdcba>>]");
}

void concatenate_test1(){
    char arr1[] = {'a','b','c'};
    CharLinkedList list(arr1, 3);
    char arr2[] = {'d','e','f','g'};
    CharLinkedList other(arr2,4);
    list.concatenate(&other);
    assert(list.toString() == "[CharLinkedList of size 7 <<abcdefg>>]");
}

void concatenate_test2(){
    char arr1[] = {'a','b','c'};
    CharLinkedList l(arr1, 3);
    l.concatenate(&l);
    assert(l.toString() == "[CharLinkedList of size 6 <<abcabc>>]");
}

void concatenate_test3(){
    char arr1[] = {'a','b','c'};
    CharLinkedList list1(arr1, 3);
    CharLinkedList list;
    list.concatenate(&list1);
    assert(list.toString() == "[CharLinkedList of size 3 <<abc>>]");
}


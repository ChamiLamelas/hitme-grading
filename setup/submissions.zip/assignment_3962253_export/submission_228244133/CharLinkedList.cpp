/*
 *  CharLinkedList.cpp
 *  Elliot Rutherford
 *  2/1/2023
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  implemtation for a list (abstract data type) using a linked list as the
 * underlying data structure
 *
 */

#include "CharLinkedList.h"
#include <iostream>
#include <string>
#include <sstream>

using namespace std;

/* default constructor for CharLinkedList
purpose: initializes an empty CharLinkedList
argumnts: none
returns: none
effects: initializes numChars and dynamically allocates a new array on the heap
*/
CharLinkedList::CharLinkedList(){
    numChars = 0;
    front = nullptr;
    back = front;
}


/* constructor for CharLinkedList that takes a char as an arguement 
purpose: initalizes an LinkedList with the specefied character as the first 
         item
arguments: char c: the char to be added to the list after creation
returns: none
effects: none
*/
CharLinkedList::CharLinkedList(char c){
    numChars = 1;
    Node *newNode = new Node;
    newNode->next = nullptr;
    newNode->prev = nullptr;
    newNode->data = c;
    front = newNode;
    back = newNode;
}

/* make Node
purpose: private helper method to make a node
arguements: char c - the data to be stored in the new node
            Node *p - a pointer to a node that will be stored in prev 
                      of the new node
            Node *n - a pointer to a node that will be stored in next 
                      of the new node
returns: CharLinkedList::Node * - a pointer to the new node
effects: none
*/
CharLinkedList::Node *CharLinkedList::makeNode(char c, Node *p, Node *n){
    Node *newNode = new Node;
    newNode->data = c;
    newNode->prev = p;
    newNode->next = n;
    return newNode;
}


/* constructor for CharLinkedList that copies a given char[]
purpose: initializes a new LL and copies a specefied array onto it
arguments: char arr[] - the char array to be copied onto the LL, int size - 
            the size of arr.
returns: none
effects: none
*/
CharLinkedList::CharLinkedList(char arr[], int size){
    front = makeNode(arr[0], nullptr, nullptr); // makes a new node and sets
                                                // front to point to it
    Node *curr = front;
    for(int i = 1; i < size; i ++){
        curr->next = makeNode(arr[i], curr, nullptr);
        curr = curr->next;
    }
    back = curr; 
    numChars = size;
}

/* size
purpose: retuns the size of the LL (the number of chars in it)
arguments: none\
returns: the size of the LL
effects: none (const)
*/
int CharLinkedList::size() const {
    return numChars;
}

/* is empty
purpose: a function to tell wheather or not the LL is empty
arguments: none
returns: true if LL has no items in it, false otherwise
effects: none
*/
bool CharLinkedList::isEmpty() const{
    if(numChars == 0){
        return true;
    }
    return false;
}

/* destructor
purpose: deallocate memory on the heap
arguments: none
returns: none
effects: none
*/
CharLinkedList::~CharLinkedList(){
    recursiveDestructorHelper(front);
}

/* private recursive destructor helper
purpose: deallocate memory on the heap using recursion
arguments: Node *n: a pointer to the node to start on (should be first)
returns: none
effects: none
*/
void CharLinkedList::recursiveDestructorHelper(Node *n){
    if(n == nullptr){
        return;
    }
    else{
        recursiveDestructorHelper(n->next);
        delete n;
    }
}

/* toString
purpose: returns the size and contents of the LL
arguments: none
returns: a string with the size and contents of the LL
        in the format: "[CharLinkedList of size [SIZE] <<[LL CONTENTS]>>]"
effects: none - const method
*/
string CharLinkedList::toString() const{
    std::stringstream ss;
    ss << "[CharLinkedList of size " << numChars << " <<";
    Node *curr = front;
    for(int i = 0; i < numChars; i++){
        ss << curr->data;
        curr = curr->next;
    }
    ss << ">>]";
    return ss.str();
}

//copy constructor 
CharLinkedList::CharLinkedList(const CharLinkedList &other){
    if(other.numChars == 0){
        this->front = nullptr;
        this->back = nullptr;
        this->numChars = 0;
    } else{
        this->front = makeNode(other.front->data, nullptr, nullptr);
        Node *thisCurr = this->front;
        Node *thatCur = other.front;
        for(int i = 0; i < other.numChars; i++){
            thisCurr->next = makeNode(thatCur->next->data, thisCurr, nullptr);
            // makes the current node point to a new node with the other currs
            // data and makes that new node point back to thisCurr
            thisCurr = thisCurr->next;
            thatCur = thatCur->next;
        }
        this->back = thisCurr;
    }
}

/* push at back
purpose: adds a char to the end of LL
arguments: char c: the char to be added
returns: none
effects: none
*/
void CharLinkedList::pushAtBack(char c){
    if(numChars == 0){
        front = makeNode(c, nullptr, nullptr);
        back = front;
        numChars++;
        return;
    }
    back->next = makeNode(c, back, nullptr);
    back = back->next;
    numChars++;
}


/*push at front
purpose: add an element to the front of LL
arguments: char c: the element to be added
returns: none
effects: adds an element to the front of the list and incrememnts size
*/
void CharLinkedList::pushAtFront(char c){
    if(numChars == 0){
        front = makeNode(c, nullptr, nullptr);
        back = front;
        numChars++;
        return;
    }
    front->prev = makeNode(c, nullptr, front);
    front = front->prev;
    numChars++;
}


/* first
purpose: returns the first element in the list
arguments: none
returns: char first char in the list 
effects: none -- const method
throws: std::runtime_error if list is empty
*/
char CharLinkedList::first() const {
    if(numChars == 0){
        throw std::runtime_error("cannot get first of empty LinkedList");
    }
    else{
        return front->data;
    }
}

/* last
purpose: retreives the last element in list
arguments: none
returns: the last char in the list
effects: none
*/
char CharLinkedList::last() const{
    if(numChars == 0){
        throw std::runtime_error("cannot get last of empty LinkedList");
    }
    else{
        return back->data;
    }
}

/* element at
purpose: get the element at the given index
arguments: int index: the index to retreive the element at
returns: the char at that index
effects: throws std::range_error if index is out of range
*/
char CharLinkedList::elementAt(int index) const{
    if(numChars == 0 or index >= numChars or index < 0){
        stringstream ss;
        ss << "index (" << index << ") not in range [0.." << numChars << ")";
        throw std::range_error(ss.str());
    }
    char c = elementAtHelper(front, 0, index);
    return c;
}

/*element at helper
purpose: a recursive helper method for element at
arguemnts: Node *n = the current node
           int idx: an int to keep track of the current position in list
           int target: the target index
*/
char CharLinkedList::elementAtHelper(Node *n, int idx, int target) const {
    if(idx == target){
        return n->data;
    } else{
        return elementAtHelper(n->next, idx + 1, target);
    }
}

/*insert at
purpose: insert an element to a specefied index
arguments: char c: the element to be added. int index: the index
            that the element should be added into
returns: none
effects: throws std::range error if index is not in range
*/
void CharLinkedList::insertAt(char c, int index){
   if(index == 0){
    pushAtFront(c);
    return;
   }
   if(numChars == 0 or index > numChars or index < 0){
        stringstream ss;
        ss << "index (" << index << ") not in range [0.." << numChars << "]";
        throw std::range_error(ss.str());
   }
   if(index == numChars){
    pushAtBack(c);
    return;
   }
    Node *curr = front;
    for(int i = 0; i < index -1; i++){
        curr = curr->next;
    }
    Node *currNext = curr->next;
    curr->next = makeNode(c, curr, curr->next);
    curr = curr->next;
    currNext->prev = curr;
    numChars++;
}

/*to reverse string
purpose: prints out the contents and size of the list in reverse order
arguments: none
returns: a string with the contents and size of the list in reverse order
effects: none
*/
string CharLinkedList::toReverseString() const{
    stringstream ss;
    ss << "[CharLinkedList of size " << numChars << " <<";
    
    Node *curr = back;
    while(curr not_eq nullptr){
        ss << curr->data;
        curr = curr->prev;
    } 
    ss << ">>]";
    return ss.str();
}

/* replace at
purpose: replaces the char at the given index with the given char
arguments: char c: the char to replace
           int index: the index of the char to replace
returns: none
effects: the char at the given index will be replaced
throws: std::range_error if index is out of bounds
*/
void CharLinkedList::replaceAt(char c, int index){
    if(isEmpty() or index >= numChars or index < 0){
        stringstream ss;
        ss << "index (" << index << ") not in range [0.." << numChars << ")";
        throw std::range_error(ss.str());
    }
    replaceAtHelper(front, 0, index, c);
}


/* replace at helper
purpose: recursive helper for replace at
arguements: 
    Node *n = a pointer to the current node
    int idx = an int to keep track of the number of times this function has 
              been called
    int target = an int that is is the target index
    char c = the char that is replacing 
returns: none
effects: none
*/
void CharLinkedList::replaceAtHelper(Node *n, int idx, int target, char c){
    if(idx == target){
        n->data = c;
    }
    else {
        replaceAtHelper(n->next, idx + 1, target, c);
    }
}

/* popFromBack
purpose: remove the last element of the list
arguments: none
returns: none
effects: throws std::runtime_error if list is empty
*/
void CharLinkedList::popFromBack(){
    if(isEmpty()){
        throw std::runtime_error("cannot pop from empty LinkedList");
    }
    Node *curr = back->prev;
    delete back;
    curr->next = nullptr;
    back = curr;
    numChars--;
}

/* pop from front
purpose: deletes the first element of the list
arguments: none
returns: none
effects: throws std::runtime_error if list is empty
*/
void CharLinkedList::popFromFront(){
    if(isEmpty()){
        throw std::runtime_error("cannot pop from empty LinkedList");
    }
    if(numChars == 1){
        clear();
        return;
    }
    Node *curr = front->next;
    delete front;
    curr->prev = nullptr;
    front = curr;
    numChars--;
}

/*clear
purpose: wipes the list so the size is zero
arguments: none
returns: none
effects: the previous list will be deleted
*/
void CharLinkedList::clear(){
    recursiveDestructorHelper(front);
    front = nullptr;
    back = nullptr;
    numChars = 0;
}

/* insert in order
purpose: inserts a char in sorted order (assuming the list is sorted)
arguments: char c: the char to be inserted in order
returns: none
effects: none 
*/
void CharLinkedList::insertInOrder(char c){
    if(isEmpty()){
        pushAtFront(c);
        return;
    }
    int index = 0;
    Node *curr = front;
    while(curr not_eq nullptr){
        if(c <= curr->data){
            insertAt(c, index);
            return;
        }
        else{
            curr = curr->next;
            index++;
        }
    }
    pushAtBack(c);
}

/*remove at
purpose: remove a char from the list at the specefied index
arguments: int index -- the index to remove at 
returns: none
effects: throws std::range_error if index is out of bounds
*/ 
void CharLinkedList::removeAt(int index){
    if(isEmpty() or index >= numChars or index < 0){
        stringstream ss;
        ss << "index (" << index << ") not in range [0.." << numChars << ")";
        throw std::range_error(ss.str());
    }
    if(index == 0){
        popFromFront();
        return;
    }
    if(index == numChars - 1){
        popFromBack();
        return;
    }

    Node *curr = front;
    for(int i = 0; i < index -1; i++){ // goes one before the index
        curr = curr->next;
    }
    
    Node *temp = curr->next->next;
    delete curr->next;
    curr->next = temp;
    if(temp == nullptr){ // if it 
        numChars--;
        back = curr->next;
        return;
    }
    temp->prev = curr;
    numChars--;
    
}

/* concatenate
purpose: concatenates another list onto the end of this list
arguments: charLinkedList *other -- a pointer to the list you would like
           to concatenate on to the end of this list
returns: none
effects: none
*/
void CharLinkedList::concatenate( CharLinkedList *other){

    if(other->numChars == 0){
        return;
    }
    Node *curr = other->front;
    cout << "made it here" << endl;
    int otherSize = other->numChars;
    for(int i = 0; i < otherSize; i++){
        pushAtBack(curr->data);
        curr = curr->next;
    }
}

/*overloaded assignment operator
*/
CharLinkedList & CharLinkedList::operator=(const CharLinkedList &other){
    if(other.isEmpty()){
        this->numChars = 0;
        this->back = nullptr;
        this->front = nullptr;
    }
    else{
        this->front = makeNode(other.front->data, nullptr, nullptr);
        Node *otherCurr = other.front->next;
        Node *thisCurr = this->front;
        while(otherCurr not_eq nullptr){
            thisCurr->next = makeNode(otherCurr->data, thisCurr, nullptr);
            thisCurr = thisCurr->next;
            otherCurr = otherCurr->next;
        }
        this->back = thisCurr;
    }
    return *this;
}

/*
 *  CharLinkedList.h
 *  Patrick Hennessey
 *  2/6/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  CharLinkedList is a class that represents an ordered list of characters. 
 *  Clients can add or remove characters from the list. The list is implemented
 *  via a doubly linked list and allows for fast access, insertion and removal
 *  from characters at the beginning and the end of the list.
 *
 */

#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H
#include <string>

class CharLinkedList {
    
    public: 
        CharLinkedList();
        CharLinkedList(char c);
        CharLinkedList(char arr[], int size);
        CharLinkedList(const CharLinkedList &other);
        ~CharLinkedList();

        std::string toString() const;
        std::string toReverseString() const;

        int size() const;
        bool isEmpty() const;
        void clear();
        char elementAt(int index) const;
        char first() const;
        char last() const;
        void popFromFront();
        void popFromBack();
        void removeAt(int index);
        void replaceAt(char c, int index);
        void insertAt(char c, int index);
        void pushAtBack(char c);
        void pushAtFront(char c);
        void insertInOrder(char c);
        void concatenate(CharLinkedList *other);
        CharLinkedList &operator=(const CharLinkedList &other);
        
    
    private:

        struct Node {
            char data; // Character stored
            Node* next; // Pointer to the next node in the list
            Node* prev; // Pointer to the previous node in the list
        };

        int num_item; // Number of items in list
        Node* front; // First node in list
        Node* back; // Last node in list

        // Helper functions for recursion
        void deconstructorHelper(Node *curr);
        std::string toReverseStringHelper(Node *curr) const;
        std::string toStringHelper(Node *curr) const;
        CharLinkedList::Node *getAtHelper(Node *curr, int index) const;
        int inOrderHelper(Node *curr, int index, char c);
        void copyOverHelper(Node *curr);
        void concatenateItselfHelper(Node *curr, int index);
};

#endif

/*
 *  unit_tests.h
 *  Patrick Hennessey
 *  2/6/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  Implement tests for the CharLinkedList class to test all public functions.
 *  Uses Matt Russell's unit_test framework.
 *
 */
#include "CharLinkedList.h"
#include <cassert>
#include <iostream>

//tests the default constructor should be size of 0
void def_constructor() {
    CharLinkedList test_list;
    assert(test_list.toString() == "[CharLinkedList of size 0 <<>>]");
}

//test the constructor that takes in one character
void one_char_constructor() {
    CharLinkedList test_list('a');
    assert(test_list.toString() == "[CharLinkedList of size 1 <<a>>]");
}

//test the constructor that takes in an array
void arr_constructor() {
    char in_arr[3] = {'p', 'a', 't'};
    CharLinkedList test_list(in_arr, 3);
    assert(test_list.toString() == "[CharLinkedList of size 3 <<pat>>]");
}

//tests toString with an empty CharLinkedList
void toString_empty() {
    CharLinkedList test_list;
    assert(test_list.toString() == "[CharLinkedList of size 0 <<>>]");
}

//tests toReverseString with an empty CharLinkedList
void toReverseString_empty() {
    CharLinkedList test_list;
    assert(test_list.toString() == "[CharLinkedList of size 0 <<>>]");
}

//tests toString with a filled CharLinkedList
void toString() {
    char in_arr[5] = {'T', 'r', 'i', 'c', 'k'};
    CharLinkedList test_list(in_arr, 5);
    assert(test_list.toString() == "[CharLinkedList of size 5 <<Trick>>]");
}

//Tests incorrect usage of elementAt with an out of bounds index
void elementAt_out_range() {
    bool range_error_thrown = false; //track if error is thrown
    std::string error_message = ""; //store message thrown by error

    CharLinkedList test_list('a');
    // check for range_error and capture the message 
    try{
        test_list.elementAt(2);
    } catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (2) not in range [0..1)");
}

//Tests elementAt with for the first element 
void elementAt_first() {
    CharLinkedList test_list('a');
    test_list.elementAt(0);
    assert(test_list.elementAt(0) == 'a');
}

//Tests elementAt with for an element in the middle
void elementAt_middle() {
    char in_arr[3] = {'p', 'a', 't'};
    CharLinkedList test_list(in_arr, 3);
    assert(test_list.elementAt(1) == 'a');
}

//Tests inccorect usage of elementAt with an empty CharArrayList
void elementAt_empty() {
    bool range_error_thrown = false; //track if error is thrown
    std::string error_message = ""; //store message thrown by error

    CharLinkedList test_list;
    // check for range_error and capture the message 
    try{
        test_list.elementAt(0);
    } catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (0) not in range [0..0)");
}

//Test pushAtBack with an empty CharLinkedList
void pushAtBack_empty() {
    CharLinkedList test_list;

    test_list.pushAtBack('a');
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');
}

//Test pushAtBack with an empty CharLinkedList by adding 3 characters
void pushAtBack_empty_multi() {
    CharLinkedList test_list;

    test_list.pushAtBack('a');
    test_list.pushAtBack('b');
    test_list.pushAtBack('c');
    assert(test_list.toString()  == "[CharLinkedList of size 3 <<abc>>]");
}

//Test pushAtFront with an empty CharLinkedList
void pushAtFront_empty() {
    CharLinkedList test_list;

    test_list.pushAtFront('a');
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');
}

//Test pushAtFront with a large CharLinkedList
void pushAtFront_large() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.pushAtFront('i');
    assert(test_list.toString() == "[CharLinkedList of size 9 <<iabcdefgh>>]");
}

//Test pushAtFront multiple times on a single CharLinkedList 
void pushAtFront_multi() {
    char test_arr[6] = { 'a', 'b', 'c', 'd', 'e', 'f'};
    CharLinkedList test_list(test_arr, 6);
    
    test_list.pushAtFront('i');
    test_list.pushAtFront('j');
    assert(test_list.toString() == "[CharLinkedList of size 8 <<jiabcdef>>]");
}

//Test pushAtBack on a large CharLinkedList
void pushAtBack_large() {
    char in_arr[3] = {'p', 'a', 't'};
    CharLinkedList test_list(in_arr, 3);

    test_list.pushAtBack('r');
    assert(test_list.toString()  == "[CharLinkedList of size 4 <<patr>>]");
}

//Tests size with an empty CharArrayList
void size_empty() {
    CharLinkedList test_list;
    assert(test_list.size() == 0);
}

//Tests size with a filled CharArrayList
void size_full_cap() {
    char in_arr[3] = {'p', 'a', 't'};
    CharLinkedList test_list(in_arr, 3);
    assert(test_list.size() == 3);
}

//tests isEmpty on an empty list which has a size of 0
void isEmpty_empty() {
    CharLinkedList test_list;
    assert(test_list.isEmpty());
}

//tests isEmpty on a list with one char
void isEmpty_one_char() {
    CharLinkedList test_list('a');
    assert(not test_list.isEmpty());
}

//tests isEmpty on a list with many chars
void isEmpty_many() {
    char in_arr[3] = {'p', 'a', 't'};
    CharLinkedList test_list(in_arr, 3);
    assert(not test_list.isEmpty());
}


//Tests first with a one char CharLinkedList
void first_correct_one_char() {
    CharLinkedList test_list('a');
    assert(test_list.first() == 'a');
}

//Tests last with a one char CharLinkedList
void last_correct_one_char() {
    CharLinkedList test_list('a');
    assert(test_list.last() == 'a');
}

//Tests first with a long CharLinkedList
void first_correct_long() {
    char in_arr[3] = {'p', 'a', 't'};
    CharLinkedList test_list(in_arr, 3);
    assert(test_list.first() == 'p');
}

//Tests last with a long CharLinkedList
void last_correct_long() {
    char in_arr[3] = {'p', 'a', 't'};
    CharLinkedList test_list(in_arr, 3);
    assert(test_list.last() == 't');
}

//Tests inccorect usage of first with an empty CharLinkedList
void first_empty() {
    bool runtime_error_thrown = false; //track if error is thrown
    std::string error_message = ""; //store message thrown by error

    CharLinkedList test_list;
    // check for runtime_error and capture the message 
    try{
        test_list.first();
    } catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "cannot get first of empty LinkedList");
}

//Tests inccorect usage of last with an empty CharLinkedList
void last_empty() {
    bool runtime_error_thrown = false; //track if error is thrown
    std::string error_message = ""; //store message thrown by error

    CharLinkedList test_list;
    // check for runtime_error and capture the message 
    try{
        test_list.last();
    } catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "cannot get last of empty LinkedList");
}

//Tests popFromFront with a large CharLinkedList
void popFromFront_large() {
    char in_arr[5] = {'T', 'r', 'i', 'c', 'k'};
    CharLinkedList test_list(in_arr, 5);
    test_list.popFromFront();

    assert(test_list.toString() == "[CharLinkedList of size 4 <<rick>>]");
}

//Tests popFromFront with an one char CharLinkedList
void popFromFront_one_char() {
    CharLinkedList test_list('a');
    test_list.popFromFront();
    assert(test_list.isEmpty());
}

//Tests inccorect usage of popFromFront with an empty CharLinkedList
void popFromFront_empty() {
    bool runtime_error_thrown = false; //track if error is thrown
    std::string error_message = ""; //store message thrown by error

    CharLinkedList test_list;
    // check for runtime_error and capture the message 
    try{
        test_list.popFromFront();
    } catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

//Tests popFromBack with a large CharLinkedList
void popFromBack_large() {
    char in_arr[5] = {'T', 'r', 'i', 'c', 'k'};
    CharLinkedList test_list(in_arr, 5);
    test_list.popFromBack();
    std::cout << test_list.toString();
    assert(test_list.toString() == "[CharLinkedList of size 4 <<Tric>>]");
}

//Tests popFromBack with an one char CharLinkedList
void popFromBack_one_char() {
    CharLinkedList test_list('a');
    test_list.popFromBack();
    assert(test_list.isEmpty());
}

//Tests inccorect usage of popFromBack with an empty CharLinkedList
void popFromBack_empty() {
    bool runtime_error_thrown = false; //track if error is thrown
    std::string error_message = ""; //store message thrown by error

    CharLinkedList test_list;
    // check for runtime_error and capture the message 
    try{
        test_list.popFromBack();
    } catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}


//Tests removeAt by removing a character from the middle of a CharLinkedList
void removeAt_middle() {
    char in_arr[5] = {'T', 'r', 'i', 'c', 'k'};
    CharLinkedList test_list(in_arr, 5);

    test_list.removeAt(2);
    assert(test_list.toString() == "[CharLinkedList of size 4 <<Trck>>]");
}

//Tests removeAt by removing a character from the front of a CharLinkedList
void removeAt_front() {
    char in_arr[5] = {'T', 'r', 'i', 'c', 'k'};
    CharLinkedList test_list(in_arr, 5);

    test_list.removeAt(0);
    assert(test_list.toString() == "[CharLinkedList of size 4 <<rick>>]");
}

//Tests removeAt by removing a character from the end of a CharLinkedList
void removeAt_end() {
    char in_arr[5] = {'T', 'r', 'i', 'c', 'k'};
    CharLinkedList test_list(in_arr, 5);

    test_list.removeAt(4);
    assert(test_list.toString() == "[CharLinkedList of size 4 <<Tric>>]");
}

//Tests removeAt by removing a character from an one char CharLinkedList
void removeAt_one_char() {
    CharLinkedList test_list('a');

    test_list.removeAt(0);
    assert(test_list.toString() == "[CharLinkedList of size 0 <<>>]");
}

//Tests inccorect usage of removeAt by removing a character from an empty 
//CharLinkedList
void removeAt_empty() {
    bool range_error_thrown = false; //track if error is thrown
    std::string error_message = ""; //store message thrown by error

    CharLinkedList test_list;
    // check for range_error and capture the message 
    try{
        test_list.removeAt(0);
    } catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (0) not in range [0..0)");
}

//Tests inccorect usage of removeAt by removing a character from an out of 
//bounds index
void removeAt_incorrect_index() {
    bool range_error_thrown = false; //track if error is thrown
    std::string error_message = ""; //store message thrown by error

    char in_arr[5] = {'T', 'r', 'i', 'c', 'k'};
    CharLinkedList test_list(in_arr, 5);    
    // check for range_error and capture the message 
    try{
        test_list.removeAt(5);
    } catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (5) not in range [0..5)");
}

//Tests removeAt by replacing a character from the middle of a CharLinkedList
void replaceAt_middle() {
    char in_arr[5] = {'T', 'r', 'i', 'c', 'k'};
    CharLinkedList test_list(in_arr, 5);

    test_list.replaceAt('a', 2);
    assert(test_list.toString() == "[CharLinkedList of size 5 <<Track>>]");
}

//Tests removeAt by replacing a character from the front of a CharLinkedList
void replaceAt_front() {
    char in_arr[5] = {'T', 'r', 'i', 'c', 'k'};
    CharLinkedList test_list(in_arr, 5);

    test_list.replaceAt('a', 0);
    assert(test_list.toString() == "[CharLinkedList of size 5 <<arick>>]");
}

//Tests removeAt by replacing a character from the end of a CharLinkedList
void replaceAt_end() {
    char in_arr[5] = {'T', 'r', 'i', 'c', 'k'};
    CharLinkedList test_list(in_arr, 5);

    test_list.replaceAt('a', 4);
    assert(test_list.toString() == "[CharLinkedList of size 5 <<Trica>>]");
}

//Tests removeAt by replacing a character from an one char CharLinkedList
void replaceAt_one_char() {
    CharLinkedList test_list('a');

    test_list.replaceAt('b', 0);
    assert(test_list.toString() == "[CharLinkedList of size 1 <<b>>]");
}

//Tests inccorect usage of replaceAt by removing a character from an empty 
//CharLinkedList
void replaceAt_empty() {
    bool range_error_thrown = false; //track if error is thrown
    std::string error_message = ""; //store message thrown by error

    CharLinkedList test_list;
    // check for range_error and capture the message 
    try{
        test_list.replaceAt('a', 0);
    } catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (0) not in range [0..0)");
}

//Tests inccorect usage of replaceAt by removing a character from an out of 
//bounds index
void replaceAt_incorrect_index() {
    bool range_error_thrown = false; //track if error is thrown
    std::string error_message = ""; //store message thrown by error

    char in_arr[5] = {'T', 'r', 'i', 'c', 'k'};
    CharLinkedList test_list(in_arr, 5);  
    // check for range_error and capture the message   
    try{
        test_list.replaceAt('a', 5);
    } catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (5) not in range [0..5)");
}


// Tests correct insertion into an empty AL.
// Afterwards, size should be 1 and element at index 0
// should be the element we inserted.
void insertAt_empty_correct() { 

    CharLinkedList test_list;
    test_list.insertAt('a', 0);
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');

}

// Tests incorrect insertion into an empty AL.
// Attempts to call insertAt for index larger than 0.
// This should result in an std::range_error being raised.
void insertAt_empty_incorrect() {

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    // check for range_error and capture the message 
    try {
        // insertAt for out-of-range index
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        // if insertAt is correctly implemented, a range_error will be thrown,
        // and we will end up here
        range_error_thrown = true;
        error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0]");
    
}

// Tests correct insertAt for front of 1-element list.
void insertAt_front_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at front
    test_list.insertAt('b', 0);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'a');
    
}

// Tests correct insertAt for back of 1-element list.
void insertAt_back_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at back
    test_list.insertAt('b', 1);
    std::cout << test_list.toString();
    // assert(test_list.size() == 2);
    // assert(test_list.elementAt(0) == 'a');
    // assert(test_list.elementAt(1) == 'b');
    
}

// Tests calling insertAt for a large number of elements.
void insertAt_many_elements() {
    
    CharLinkedList test_list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.insertAt('a', i);
    }

    assert(test_list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
    
}

// Tests insertion into front of a larger list
void insertAt_front_large_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g'};
    CharLinkedList test_list(test_arr, 8);

    test_list.insertAt('y', 0);

    assert(test_list.size() == 9);
    assert(test_list.elementAt(0) == 'y');
    assert(test_list.toString() == "[CharLinkedList of size 9 <<yabczdefg>>]");

}

// Tests insertion into the back of a larger list
void insertAt_back_large_list() {

    char test_arr[10] = { 'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 10);  

    test_list.insertAt('x', 10);

    assert(test_list.size() == 11);
    assert(test_list.elementAt(10) == 'x');
    assert(test_list.toString() == 
    "[CharLinkedList of size 11 <<yabczdefghx>>]"); 

}

// Tests insertion into the middle of a larger list
void insertAt_middle_large_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.insertAt('z', 3);

    assert(test_list.size() == 9);
    assert(test_list.elementAt(3) == 'z');
    assert(test_list.toString() == "[CharLinkedList of size 9 <<abczdefgh>>]");

}

// Tests out-of-range insertion for a non-empty list.
void insertAt_nonempty_incorrect() {
   
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8]"); 
}

//Tests clear with a large CharLinkedList
void clear_large() {
    char in_arr[5] = {'T', 'r', 'i', 'c', 'k'};
    CharLinkedList test_list(in_arr, 5);
    test_list.clear();

    assert(test_list.isEmpty());
}

//Tests clear with an one char CharLinkedList
void clear_one_char() {
    CharLinkedList test_list('a');
    test_list.clear();

    assert(test_list.isEmpty());
}

//Tests clear with an empty CharLinkedList
void clear_empty() {
    CharLinkedList test_list;
    test_list.clear();

    assert(test_list.isEmpty());
}

//Test clear then pushAt functions on the empty list
void clear_pushAtFront() {
    CharLinkedList test_list;
    test_list.clear();
    test_list.pushAtFront('a');
    test_list.pushAtBack('b');

    assert(test_list.toString() == "[CharLinkedList of size 2 <<ab>>]");
}

//Tests insertInOrder by inserting into the middle of a CharLinkedList
void insertInOrder_middle() {
    char test_arr[4] = { 'a', 'b', 'd', 'e'};
    CharLinkedList test_list(test_arr, 4);

    test_list.insertInOrder('c');
    assert(test_list.toString() == "[CharLinkedList of size 5 <<abcde>>]");
}

//Tests insertInOrder by inserting into the front of a CharLinkedList
void insertInOrder_front() {
    char test_arr[4] = { 'b', 'b', 'd', 'e'};
    CharLinkedList test_list(test_arr, 4);

    test_list.insertInOrder('a');
    std::cout << test_list.toString();
    assert(test_list.toString() == "[CharLinkedList of size 5 <<abbde>>]");
}

//Tests insertInOrder by inserting into the end of a CharArrayList
void insertInOrder_end() {
    char test_arr[4] = { 'a', 'b', 'd', 'e'};
    CharLinkedList test_list(test_arr, 4);

    test_list.insertInOrder('f');
    assert(test_list.toString() == "[CharLinkedList of size 5 <<abdef>>]");
}

//Tests insertInOrder by inserting into an empty CharLinkedList
void insertInOrder_empty() {
    CharLinkedList test_list;

    test_list.insertInOrder('a');
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');
}

//Tests insertInOrder by inserting into a CharLinkedList that has rolled over 
//order
void insertInOrder_Z_first() {
    char test_arr[4] = { 'z', 'b', 'c', 'e'};
    CharLinkedList test_list(test_arr, 4);

    test_list.insertInOrder('a');
    assert(test_list.toString() == "[CharLinkedList of size 5 <<azbce>>]");
}

//tests concatenate with a filled other CharLinkedList with different size
void concatenate_normal() {
    char test_arr[3] = { 'p', 'a', 't'};
    CharLinkedList test_list(test_arr, 3);

    char test_arr_other[4] = { 'r', 'i', 'c', 'k'};
    CharLinkedList test_list_other(test_arr_other, 4);

    test_list.concatenate(&test_list_other);
    assert(test_list.toString() == "[CharLinkedList of size 7 <<patrick>>]");
}

//tests concatenate with an empty other CharLinkedList
void concatenate_other_empty() {
    char test_arr[3] = { 'p', 'a', 't'};
    CharLinkedList test_list(test_arr, 3);

    CharLinkedList test_list_other;

    test_list.concatenate(&test_list_other);
    assert(test_list.toString() == "[CharLinkedList of size 3 <<pat>>]");
}

//tests concatenate on an empty CharLinkedList with a filled CharLinkedList
void concatenate_this_empty() {
    CharLinkedList test_list;

    char test_arr_other[4] = { 'r', 'i', 'c', 'k'};
    CharLinkedList test_list_other(test_arr_other, 4);

    test_list.concatenate(&test_list_other);
    assert(test_list.toString() == "[CharLinkedList of size 4 <<rick>>]");
}

//Tests concatenate with the same list it was called on
void concatenate_itself() {
    char test_arr[3] = { 'p', 'a', 't'};
    CharLinkedList test_list(test_arr, 3);

    test_list.concatenate(&test_list);
    std::cout << test_list.toString();
    //assert(test_list.toString() == "[CharLinkedList of size 6 <<patpat>>]");
}

//test the copy constructor when copying a CharLinkedList with size 3
void copy_constructor_normal() {
    char in_arr[3] = {'p', 'a', 't'};
    CharLinkedList test_list_other(in_arr, 3);

    CharLinkedList test_list(test_list_other);
    assert(test_list.toString() == "[CharLinkedList of size 3 <<pat>>]");
}

//test the copy constructor when copying an empty CharLinkedList
void copy_constructor_empty() {
    CharLinkedList test_list_other;

    CharLinkedList test_list(test_list_other);
    assert(test_list.toString() == "[CharLinkedList of size 0 <<>>]");
}

//test the overriden assignment operator between two CharLinkedList
void assignmentOperator_diff_content() {
    char in_arr_other[3] = {'p', 'a', 't'};
    CharLinkedList test_list_other(in_arr_other, 3);

    char in_arr[3] = {'h', 'o', 'p'};
    CharLinkedList test_list(in_arr, 3);

    test_list = test_list_other;
    assert(test_list.toString() == "[CharLinkedList of size 3 <<pat>>]");
}

//test the overriden assignment operator between two CharLinkedList of different
//size
void assignmentOperator_diff_size() {
    char in_arr_other[4] = {'p', 'a', 't', 'b'};
    CharLinkedList test_list_other(in_arr_other, 4);

    char in_arr[3] = {'h', 'o', 'p'};
    CharLinkedList test_list(in_arr, 3);

    test_list = test_list_other;
    assert(test_list.toString() == "[CharLinkedList of size 4 <<patb>>]");
}
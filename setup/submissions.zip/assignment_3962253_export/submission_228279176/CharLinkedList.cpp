/*
 *  CharLinkedList.cpp
 *  Patrick Hennessey
 *  2/6/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  This file contains an implementation of the CharLinkedList class
 *
 */

#include "CharLinkedList.h"
#include <string>
#include <iostream>
#include <stdexcept>

/*
 * name:      CharLinkedList
 * purpose:   Creates a new instance of the CharLinkedList class with an empty
 *            list.
 * arguments: None 
 * returns:   None
 * effects:   None
 */
CharLinkedList::CharLinkedList() {
    num_item = 0;
    front = nullptr;
    back = nullptr;
}

/*
 * name:      CharLinkedList
 * purpose:   Creates a new instance of the CharLinkedList class with a size of 
 *            1 containing a specified character
 * arguments: character to be added to the list
 * returns:   None
 * effects:   None
 */
CharLinkedList::CharLinkedList(char c) {
    Node *new_node = new Node{c, nullptr, nullptr};
    // update list size
    num_item = 1; 
    // add new_node to list by assigning it as the front and back
    front = new_node; 
    back = new_node;
}

/*
 * name:      CharLinkedList
 * purpose:   Creates a new instance of the CharLinkedList class with a 
 *            specified size and containing specified characters in the order 
 *            in which they are specified in an array.
 * arguments: Array containing characters to be added to the list
 * returns:   None
 * effects:   None
 */
CharLinkedList::CharLinkedList(char arr[], int size) {
    // Intialize list size
    num_item = 0;

    for(int i = 0; i < size; i++) {
        pushAtBack(arr[i]);
    }
}

/*
 * name:      CharLinkedList
 * purpose:   Creates a new instance of the CharLinkedList class by making a 
 *            deep copy of an already exisiting instance of the CharLinkedList 
 *            class
 * arguments: A pointer to the other instance that is to be copied
 * returns:   None
 * effects:   None
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other) {
    // Intialize private members for an empty list
    num_item = 0;
    front = nullptr;
    back = nullptr;
    // Add characters
    copyOverHelper(other.front);
}

/*
 * name:      ~CharLinkedList
 * purpose:   Deconstructor for the CharLinkedList class
 * arguments: None
 * returns:   None
 * effects:   Frees allocated memory when instance goes out of scope.
 *            Calls deconstructorHelper.
 */
CharLinkedList::~CharLinkedList() {
    deconstructorHelper(front);
}

/*
 * name:      deconstructorHelper
 * purpose:   Recursive helper function for the CharLinkedList deconstructor
 * arguments: A pointer to a Node in CharLinkedList. When called by 
 *            deconstructor, the front node should be passed. 
 * returns:   None
 * effects:   Frees allocated memory when deconstructor is called. 
 */
void CharLinkedList::deconstructorHelper(Node *curr) {
    Node* temp;
    if (curr == nullptr) {
        return; // Base case: reached the end of the list
    }
    temp = curr->next;
    delete curr; // Delete the current node
    deconstructorHelper(temp);
}

/*
 * name:      toString
 * purpose:   Converts the CharLinkedList to a string representation which
 *            includes the size and character content of the list
 * arguments: None 
 * returns:   A string representing the CharLinkedList
 * effects:   None
 */
std::string CharLinkedList::toString() const {
    std::string s = "[CharLinkedList of size ";
    s += std::to_string(num_item);
    s += " <<";
    s += toStringHelper(front);
    s += ">>]";
    return s;
}

/*
 * name:      toStringHelper
 * purpose:   Recursive helper function for the CharLinkedList toString function
 *            that returns the character in each node in the order it is stored
 *            in the list.
 * arguments: A pointer to a Node in CharLinkedList. When called by 
 *            toString, the front node should be passed. 
 * returns:   A string containing the characters in the CharLinkedList
 * effects:   None
 */
std::string CharLinkedList::toStringHelper(Node *curr) const{
    // Recursive case: return character at each node
    while(curr != nullptr) {
        return curr->data + toStringHelper(curr->next);
    }
    // Base Case: return and empty string when end of list is reached
    return "";
    
}

/*
 * name:      size
 * purpose:   Gets the number of characters in the CharLinkedList
 * arguments: None 
 * returns:   An int of the number of characters
 * effects:   None
 */
int CharLinkedList::size() const {
    return num_item;
}

/*
 * name:      toReverseString
 * purpose:   Converts the CharLinkedList to a string representation which
 *            includes the size and character content shown in reverse order to 
 *            how it is stored in the CharLinkedList
 * arguments: None 
 * returns:   A string representing the CharLinkedList
 * effects:   None
 */
std::string CharLinkedList::toReverseString() const {
    std::string s = "[CharLinkedList of size ";
    s += std::to_string(num_item);
    s += " <<";
    s += toStringHelper(back);
    s += ">>]";
    return s;
}

/*
 * name:      toReverseStringHelper
 * purpose:   Recursive helper function for the CharLinkedList toReverseString 
 *            function that returns the character in each node in the reverse 
 *            order it is stored in the list.
 * arguments: A pointer to a Node in CharLinkedList. When called by 
 *            toString, the back node should be passed. 
 * returns:   A string containing the characters in the CharLinkedList
 * effects:   None
 */
std::string CharLinkedList::toReverseStringHelper(Node *curr) const {
    // Recursive case: return character at each node
    while(curr != nullptr) {
        return curr->data + toStringHelper(curr->prev);
    }
    // Base Case: return and empty string when end of list is reached
    return "";
    
}

/*
 * name:      isEmpty
 * purpose:   Checks if the CharLinkedList is empty (contains no characters)
 * arguments: None 
 * returns:   True if the CharLinkedList is empty, false otherwise
 * effects:   None
 */
bool CharLinkedList::isEmpty() const {
    if(num_item == 0) {
        return true; // empty
    } else {
        return false;
    }
}

/*
 * name:      first
 * purpose:   Gets the first character in a CharLinkedList
 * arguments: None
 * returns:   The first character in the CharLinkedList
 * effects:   Raises a runtime error if the CharLinkedList is empty
 */
char CharLinkedList::first() const {
    // Check if list is empty
    if(num_item == 0) {
        throw std::runtime_error("cannot get first of empty LinkedList");
    } else {
        return front->data;
    }
}

/*
 * name:      last
 * purpose:   Gets the last character in a CharLinkedList
 * arguments: None
 * returns:   The last character in the CharLinkedList
 * effects:   Raises a runtime error if the CharLinkedList is empty
 */
char CharLinkedList::last() const {
    // Check if list is empty
    if(num_item == 0) {
        throw std::runtime_error("cannot get last of empty LinkedList");
    } else {
        return back->data;
    }
}

/*
 * name:      elementAt
 * purpose:   Gets the character at a given index
 * arguments: The index of the character to retrieve 
 * returns:   The character at the specified index
 * effects:   Raises a range_error if the index is out of bounds of the 
 *            CharLinkedList
 */
char CharLinkedList::elementAt(int index) const {
    // Check if index is out of range 
    if(index < 0 or index >= num_item) {
        throw std::range_error("index (" + std::to_string(index) + 
        ") not in range [0.." + std::to_string(num_item) + ")");
    } else {
        return getAtHelper(front, index)->data;
    }
}

/*
 * name:      getAtHelper
 * purpose:   Recursive helper function for the CharLinkedList which locates
 *            a Node in a CharLinkedList at a specified index. 
 * arguments: A pointer to a Node in CharLinkedList, when called by wrapper 
 *            function the front node should be passed. An int that keeps track
 *            of what index the recursive algorthim is at, when called by 
 *            wrapper function the index wanted should be passed. 
 * returns:   A pointer to the node at the specified index. 
 * effects:   None
 */
CharLinkedList::Node *CharLinkedList::getAtHelper(Node *curr, int index) const {
    if(index == 0) { // Base case: has iterated through to the specified number
        return curr; 
    }
    // Recursive case: recall on next node and decrement index counter by 1
    return getAtHelper(curr->next, index - 1);
}

/*
 * name:      popFromBack
 * purpose:   Removes the last character of a CharLinkedList 
 * arguments: None
 * returns:   None
 * effects:   The CharLinkedList will decrease in size by one.
 *            Raises a runtime error if the CharLinkedList is empty.
 *            Reassigns back pointer to previous second to last node.
 */
void CharLinkedList::popFromBack() {
    if(num_item == 0) {
        throw std::runtime_error("cannot pop from empty LinkedList");
    } else {
        // List only contains one item
        if(num_item == 1) {
            delete back;
            // List is now empty
            front = nullptr;
            back = nullptr;
        } else {
            // Get address of second to end node
            Node *temp = back->prev;
            // Set new back node link to nullptr
            temp->next = nullptr;
            delete back;
            // Reassign back to the old second to back
            back = temp; 
        }
        // Decrement size of list
        num_item -= 1;
    }
}

/*
 * name:      popFromFront
 * purpose:   Removes the first character of a CharLinkedList 
 * arguments: None
 * returns:   None
 * effects:   The CharLinkedList will decrease in size by one.
 *            Raises a runtime error if the CharLinkedList is empty
 *            Reassigns front pointer to previous second node.
 */
void CharLinkedList::popFromFront() {
    // Check for empty list
    if(num_item == 0) {
        throw std::runtime_error("cannot pop from empty LinkedList");
    } else {
        // List only contains one item
        if(num_item == 1) {
            delete front;
            // List is now empty
            front = nullptr;
            back = nullptr;
        } else {
            // Get address of second node
            Node *temp = front->next;
            // Set new front node link to nullptr
            temp->prev = nullptr;
            delete front;
            // Reassign front to the old second node
            front = temp; 
        }
        // decrement size of list
        num_item -= 1;
    }
}

/*
 * name:      pushAtBack
 * purpose:   Adds a specified character at the end of the CharLinkedList
 * arguments: The character to add
 * returns:   None
 * effects:   The CharLinkedList will increase in size by 1. 
 *            Reassigns back pointer to new node. 
 */
void CharLinkedList::pushAtBack(char c) {
    Node *new_node = new Node{c, nullptr, nullptr};
    
    if(num_item > 0) {
        // Reassign link between the original last node and new last node
        back->next = new_node;
        new_node->prev = back;
        // Set the new node as the back
        back = new_node;
    } else {
        // If list is empty new node becomes the front and back
        front = new_node;
        back = new_node;
    }

    // increment size of list
    num_item += 1;
}

/*
 * name:      pushAtFront
 * purpose:   Adds a specified character at the beginning of the CharLinkedList
 * arguments: The character to add
 * returns:   None
 * effects:   The CharLinkedList will increase in size by 1.
 *            Reassigns front pointer to new node. 
 */
void CharLinkedList::pushAtFront(char c) {
    Node *new_node = new Node{c, nullptr, nullptr};
    if(num_item > 0) {
        // Reassign link for the original first node and new first node
        front->prev = new_node;
        new_node->next = front;
        // Set the new node as the front
        front = new_node;
    } else {
        // If list is empty new node becomes the front and back
        front = new_node;
        back = new_node;
    }
    // increment size of list
    num_item += 1;
    
}

/*
 * name:      insertAt
 * purpose:   Inserts the supplied character of a CharLinkedList at the 
 *            specified index
 * arguments: The character to insert, and the index of where to insert at
 * returns:   None
 * effects:   The CharLinkedList will increase in size by 1.  
 *            May reassign front and back list pointers if added to beginning or
 *            end. 
 *            Raises a range error if the index is outside the bounds of the
 *            CharLinkedList
 */
void CharLinkedList::insertAt(char c, int index) {
    // Check if index is out of range 
    if(index < 0 or index > num_item) {
        throw std::range_error("index (" + std::to_string(index) + 
        ") not in range [0.." + std::to_string(num_item) + "]");
    } else {
        // Empty List
        if(num_item == 0) {
            Node *new_node = new Node{c, nullptr, nullptr};
            // New node now makes up front and back of list
            front = new_node;
            back = new_node;
            // increment size of list
            num_item += 1;
        } else if(index == 0) {// Inserting at front
            pushAtFront(c);
        } else if (index == num_item){ // Inserting at back
            pushAtBack(c);
        } else { // Inserting into the middle of a list
            // Create a new node of specified char
            // link pointers will be assigned later
            Node *new_node = new Node{c, nullptr, nullptr};

            // The node currently at the specified index
            Node *node_at_ind = getAtHelper(front, index);
            // Reassign prev links
            new_node->prev = node_at_ind->prev; // new gets index - 1 as prev
            node_at_ind->prev = new_node;
            // Reassign next links
            new_node->prev->next = new_node; // index - 1 gets new node as next
            new_node->next = node_at_ind; 
            
            // increment size of list
            num_item += 1;
        }
    }
}

/*
 * name:      replaceAt
 * purpose:   Replaces the character of a CharLinkedList at the specified index 
 *            with the character supplied
 * arguments: The character to replace with, and the index of the character to 
 *            remove
 * returns:   None
 * effects:   Raises a range error if the index is outside the bounds of the
 *            CharLinkedList
 */
void CharLinkedList::replaceAt(char c, int index) {
    // Check if index is out of range 
    if(index < 0 or index >= num_item) {
        throw std::range_error("index (" + std::to_string(index) + 
        ") not in range [0.." + std::to_string(num_item) + ")");
    } else {
        // The node currently at the specified index
        Node *node_at_ind = getAtHelper(front, index);
        // Reassign character to specified
        node_at_ind->data = c;
    }
}

/*
 * name:      removeAt
 * purpose:   Removes the character of a CharLinkedList at the specified index
 * arguments: The index of the character to remove
 * returns:   None
 * effects:   The CharLinkedList will decrease in size by 1
 *            May reassign front and back list pointers if removed at beginning
 *            or end. 
 *            Raises a range error if the index is outside the bounds of the
 *            CharLinkedList
 */
void CharLinkedList::removeAt(int index) {
    // Check if index is out of range 
    if(index < 0 or index >= num_item) {
        throw std::range_error("index (" + std::to_string(index) + 
        ") not in range [0.." + std::to_string(num_item) + ")");
    } else {
        // Removing from front
        if(index == 0) {
            popFromFront();
        } else if (index == (num_item - 1)){ // Removing from back
            popFromBack();
        } else {
            // The node currently at the specified index
            Node *node_at_ind = getAtHelper(front, index);
            // Reassign next link of node at index - 1 to node at index + 1
            node_at_ind->prev->next = node_at_ind->next;
            // Reassign prev link of node at index + 1 to node at index - 1
            node_at_ind->next->prev = node_at_ind->prev;

            delete node_at_ind;
            // Decrement size of list
            num_item -= 1;
        }
    }
}

/*
 * name:      clear
 * purpose:   removes all of the items from the CharLinkedList 
 * arguments: None
 * returns:   None
 * effects:   Reduces the size of the list to 0. Deallocates all allocated 
 *            memory.
 * 
 */
void CharLinkedList::clear() {
    // Deallocate all allocated memory
    deconstructorHelper(front);
    // Reassign CharLinkedList members to default
    front = nullptr;
    back = nullptr;
    num_item = 0;
}

/*
 * name:      insertInOrder
 * purpose:   Adds a specified character in order relative to ASCII values 
 *            (lowest to highest)
 * arguments: The character to add
 * returns:   None
 * effects:   The CharLinkedList will increase in size by 1.
 *            May reassign front and back list pointers if inserted in beginning
 *            or end. 
 *            Assumes the CharLinkedList is already in sorted order.
 */
void CharLinkedList::insertInOrder(char c) {
    // Check if empty list
    if(num_item == 0) {
        pushAtFront(c);
    } else {
        int index = inOrderHelper(front, 0, c);
        insertAt(c, index);
    }
}

/*
 * name:      inOrderHelper
 * purpose:   Recursive helper function for the CharLinkedList insertInOrder
 *            function that locates the position a specified character should
 *            be inserted in an ascii sorted CharLinkedList.
 * arguments: A pointer to a Node in CharLinkedList, when called by wrapper 
 *            function the front node should be passed. An int that keeps track
 *            of what index the recursive algorthim is at, when called by 
 *            wrapper function the index wanted should be passed. The char
 *            specified to be inserted.
 * returns:   An int of the index at which the specified char should be inserted
 *            to maintain ASCII order.
 * effects:   None
 */
int CharLinkedList::inOrderHelper(Node *curr, int index, char c) {
    if(curr->data >= c) { // Base Case: found index for ASCII order
        return index;
    } else if (index >= num_item - 1){ // Checked all nodes; insert at end;
        return index + 1;
    }
    // Recursive case: check next node and keep track of index
    return inOrderHelper(curr->next, (index + 1), c); 
}

/*
 * name:      concatenate
 * purpose:   Adds the characters from another CharLinkedList onto the end of 
 *            CharLinkedList it is called on
 * arguments: A pointer to the other CharLinkedList 
 * returns:   None
 * effects:   The CharLinkedList will increase in size by the size of the other
 *            CharLinkedList. Update back pointer to end of other 
 *            CharLinkedList.
 */
void CharLinkedList::concatenate(CharLinkedList *other) {
    // Concatenate on itself
    if(this == other) {
        concatenateItselfHelper(other->front, 0);
    } else { 
        copyOverHelper(other->front);
    }
}

/*
 * name:      copyOverHelper
 * purpose:   Recursive helper function for the CharLinkedList class
 *            that deep copies the nodes from an other CharLinkedList onto
 *            the end of called upon CharLinkedList.
 * arguments: A pointer to a Node in the other CharLinkedList, when called by 
 *            wrapper function the front node of the other CharLinkedList should
 *            be passed.
 * returns:   None
 * effects:   Increments the size of the list by the number of nodes in the
 *            other CharLinkedList. Calls pushAtBack.
 */
void CharLinkedList::copyOverHelper(Node *curr) {
    // Recursive Case: node of other list to be added to this list
    if(curr != nullptr) { 
        pushAtBack(curr->data);
        copyOverHelper(curr->next);
    }
}

/*
 * name:      concatenateItselfHelper
 * purpose:   Recursive helper function for the CharLinkedList concatenate 
 *            function for the specific case where the concatenate function
 *            is called upon itself.
 * arguments: A pointer to a Node in the other CharLinkedList, when called by 
 *            wrapper function the front node of the other CharLinkedList should
 *            be passed. An int that keeps track of the number of items added,
 *            when called by the wrapper function 0 should be passed. 
 * returns:   None
 * effects:   Increments the size of the list by the number of nodes in the
 *            other CharLinkedList. Calls pushAtBack.
 */
void CharLinkedList::concatenateItselfHelper(Node *curr, int index) {
    // Stop Recursion when it has iterated through the number of original nodes
    if(index == num_item - index) { 
        pushAtBack(curr->data);
        concatenateItselfHelper(curr->next, index + 1);
    }
}

/*
 * name:      operator=
 * purpose:   Override the default assignment operator for the CharLinkedList
 *            which makes a deep copy of the rightside to the leftside. 
 * arguments: the CharLinkedList instance on the rightside of the assignment
 * returns:   the new CharLinkedList instance which has recieved a deep copy
 * effects:   None
 */
CharLinkedList& CharLinkedList::operator=(const CharLinkedList &other) {
    // check if the an instance is being assigned to itself
    if (this == &other) {
        return *this;
    }
    // Empty original CharLinkedList
    this->clear();
    // Deep copy over nodes from other 
    copyOverHelper(other.front);
    // Return pointer to updated original CharLinkedList
    return *this;
}
/*
 *  CharLinkedList.cpp
 *  Ada Wu (awu15)
 *  2/5/23
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  This file contains the implementation for the CharLinkedList class.
 *
 */

#include "CharLinkedList.h"
#include <sstream>
#include <stdexcept>
#include <string>
#include <iostream> // REMOVE this later!!

/*
 * name:      CharLinkedList default constructor
 * purpose:   initialize an empty CharLinkedList
 * arguments: none
 * returns:   none
 * effects:   
 */
CharLinkedList::CharLinkedList() {
    front = nullptr;
    back = nullptr;
    list_size = 0;
}

CharLinkedList::Node *CharLinkedList::newNode(char newData, Node *previous,
                                            Node *next){
    Node *new_node = new Node;
    new_node->data = newData;
    new_node->previous = previous;
    new_node->next = next;

    return new_node;
}

/*
 * name:      One-element CharLinkedList constructor
 * purpose:   initialize a CharLinkedList with one element
 * arguments: char c to put inside Linked
 * returns:   none
 * effects:   
 */
CharLinkedList::CharLinkedList(char c) {
    Node *new_node = newNode(c, nullptr, nullptr);
    front = new_node;
    back = new_node;    
    list_size = 1;
}

/*
 * name:      CharLinkedList copy constructor of array
 * purpose:   initialize a CharLinkedList containing given characters in array
 * arguments: array of characters and int size of the array of characters
 * returns:   none
 * effects:   
 */
CharLinkedList::CharLinkedList(char arr[], int size) {

    if (size > 0) {
        front = newNode(arr[0], nullptr, nullptr);
        Node *previous_node = front;
        list_size = 1;

        if (size > 1) {
            Node *curr_node;

            for (int i = 1; i < size; i++) {
                curr_node = newNode(arr[i], previous_node, nullptr);
                previous_node->next = curr_node;
                previous_node = curr_node;
                list_size++;
            }

            back = curr_node;
        }
    } 
}


/*
 * name:      CharLinkedList deep copy constructor of CharLinkedList
 * purpose:   Creates a deep copy of a given instance
 * arguments: Pointer to another CharLinkedList
 * returns:   none
 * effects:   
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other) {
    if (not(other.isEmpty())) {
        front = newNode(other.front->data, nullptr, nullptr);
        Node *previous_node = front;
        list_size = 1;

        Node *curr_node;
        Node *other_node = (other.front)->next;
        
        for (int i = 1; i < other.size(); i++) {
            curr_node = newNode(other_node->data, previous_node, nullptr);
            previous_node->next = curr_node;

            previous_node = curr_node;
            other_node = other_node->next;
            list_size++;
        }

        back = curr_node;

        if (other.size() == 1) {
            back = front;
        }

    } 
}

/*
 * name:      CharLinkedList destructor
 * purpose:   free memory associated with the CharLinkedList
 * arguments: none
 * returns:   none
 * effects:   frees memory allocated by CharLinkedlist instances
 */
CharLinkedList::~CharLinkedList() {
    destructorRecHelper(front);
}

// /*
//  * name:      destructorRecHelper
//  * purpose:   Recycle each node in the list beginning at curr
//  * arguments: Pointer to current node
//  * returns:   none
//  * effects:   
//  */
void CharLinkedList::destructorRecHelper(Node *curr){
    if (front!=nullptr) {
        if (curr == nullptr) {
            return;
        } else {
            Node *next = curr->next;
            delete curr;
            destructorRecHelper(next);
        }
    }
}

/*
 * name: Equals Operator
 * purpose:   assigns the deep copy of the right side of '=' to the left side
 * arguments: address of the array list 
 * returns:   none
 * effects:   left side of '=' will contain deepy copy of right side
 */


CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other) {
    if (this == &other) {
        return *this;
    }

    if (not(other.isEmpty())) {
        front = newNode(other.front->data, nullptr, nullptr);
        Node *previous_node = front;
        list_size = 1;

        Node *curr_node;
        Node *other_node = (other.front)->next;
        
        for (int i = 1; i < other.size(); i++) {
            curr_node = newNode(other_node->data, previous_node, nullptr);
            previous_node->next = curr_node;

            previous_node = curr_node;
            other_node = other_node->next;
            list_size++;
        }

        back = curr_node;

        if (other.size() == 1) {
            back = front;
        }

    } else {
        this->clear();
    }

    return *this;
}

/*
 * name: Empty List Boolean      
 * purpose:   determine if the LL is empty
 * arguments: none
 * returns:   returns true if LL is empty, false if otherwise
 * effects:   none
 */
bool CharLinkedList::isEmpty() const {
    return (list_size == 0);
}

/*
 * name: Clear Function      
 * purpose:   makes instance into an empty Linked List
 * arguments: none
 * returns:   none
 * effects:   makes Linked List empty
 */
void CharLinkedList::clear() {
    destructorRecHelper(front);
    front = nullptr;
    back = nullptr;
    list_size = 0;
}

/*
 * name: Size Function      
 * purpose:   determine the size of the array list
 * arguments: none
 * returns:   returns int of the size of array list
 * effects:   none
 */

int CharLinkedList::size() const{
    return list_size;
}

/*
 * name: First Char     
 * purpose:   return the first character in the LL
 * arguments: none
 * returns:   returns first char of LL
 * effects:   none
 */
char CharLinkedList::first() const{
    if (list_size <= 0) {
        throw std::runtime_error("cannot get first of empty LinkedList");
    }
    
    return front->data;
}

/*
 * name: Last Char Function     
 * purpose:   return the last character in the LL
 * arguments: none
 * returns:   returns last char of LL
 * effects:   none
 */
char CharLinkedList::last() const{
    if (list_size <= 0) {
        throw std::runtime_error("cannot get last of empty LinkedList");
    }
    
    return(back->data);
}

/*
 * name: LL Element Finder
 * purpose:   return the char element in the LL at a given index
 * arguments: an int index
 * returns:   returns the char element in the LL at that index
 * effects:   none
 */
char CharLinkedList::elementAt(int index) const{
    if ((index < 0) or (index >= list_size)) {
        throw std::range_error("index (" + std::to_string(index) +
        ") not in range [0.." + std::to_string(list_size) + ")");
    }

    Node *curr_node = front;
    
    return (recElementAtHelper(0, index, curr_node));
}

/*
 * name:        Helper Recursive Function for CLL Element Finder
 * purpose:     Help elementAt locate the char at given index
 * arguments:   Count for position of node, index for position we want,
                Node to start indexing from
 * returns:     Char at the given index 
 * effects:     None
 */
char CharLinkedList::recElementAtHelper(int count, int index,
                                        Node *curr_node) const{
    if (count == index) {
        return curr_node->data;
    } else {
        curr_node = curr_node->next;
        count++;
        return(recElementAtHelper(count, index, curr_node));
    }
}

/*
 * name:      CAL To String Converter
 * purpose:  finds characters of CharArrayList and returns them as strings
 * arguments: none
 * returns:   returns the size and charactesr of CAL in specific format
 * effects:   none
 */
std::string CharLinkedList::toString() const{
    std::stringstream ss;
    Node *curr = front;
    ss << "[CharLinkedList of size " << std::to_string(list_size) << " <<";
    for (int i = 0; i < list_size; i++) {
        ss << curr->data;
        curr = curr->next;
    }
    ss << ">>]";

    return ss.str();

}

/*
 * name:      Reverse CLL To String Converter 
 * purpose:   find characters of CharLinkedList & returns them in reverse string
 * arguments: none
 * returns:   returns the size and charactesr of CLL in specific reverse format
 * effects:   none
 */
std::string CharLinkedList::toReverseString() const{
    std::stringstream ss;
    Node *curr = back;
    ss << "[CharLinkedList of size " << std::to_string(list_size) << " <<";
    for (int i = list_size-1; i >= 0; i--) {
        ss << curr->data;
        curr = curr->previous;
    }
    ss << ">>]";

    return ss.str();
}

/*
 * name:      pushAtBack
 * purpose:   inserts the given new element after the end of the linked list
 * arguments: char to be added after the last element of the list
 * returns:   none
 * effects:   adds a char after the last element of the list
 */
void CharLinkedList::pushAtBack(char c){
    Node *new_back;

    if (this->isEmpty()) {
        new_back = newNode(c, nullptr, nullptr);
        front = new_back;
    } else {
        new_back = newNode(c, back, nullptr);
        back->next = new_back;
    }

    back = new_back;
    list_size++;

}
/*
 * name: pushAtFront
 * purpose:   inserts the given new element before the first
 *            element of the linked list
 * arguments: char to be added before the first element of the list
 * returns:   none
 * effects:   adds a char before the first element of the list
 */
void CharLinkedList::pushAtFront(char c){
    Node *new_front;
    
    if (this->isEmpty()) {
        new_front = newNode(c, nullptr, nullptr);
        back = new_front;
    } else {
        Node *old_front = front;
        new_front = newNode(c, nullptr, front);
        old_front->previous = front; 
    }
    
    front = new_front;
    list_size++;
}

/*
 * name: CharLinkedList InsertionAt
 * arguments: char c to insert into list, int index for insertion position
 * returns:   none
 * effects:   list_size increases
 */
void CharLinkedList::insertAt(char c, int index){
    if ((index < 0) or (index > list_size)) {
        throw std::range_error("index (" + std::to_string(index) +
        ") not in range [0.." + std::to_string(list_size) + "]");
    }

    // Index = 0
    if (index == 0) {
        this->pushAtFront(c);
    } 
    else if (index == list_size) {
        this->pushAtBack(c);
    }
    else {
        list_size++;
        Node *curr_node = front;
        int curr_index = 0;
        while (curr_index < index - 1) {
            curr_node = curr_node->next;
            curr_index++;
        }

        curr_node->next = newNode(c, curr_node, curr_node->next);
        curr_node = curr_node->next; // Now curr node is our new node
        curr_node->next->previous = curr_node;
        curr_node->previous->next = curr_node;
    }
    
}

/*
 * name: insertInOrder      
 * purpose:   determine if the provided integer is within the LinkedList
 * arguments: an integer to find
 * returns:   returns true if x is in the LinkedList, false otherwise
 * effects:   none
 */
void CharLinkedList::insertInOrder(char c) {

    int ascii = c;
    int index = 0;


    if (list_size == 0) {
        pushAtFront(c);
    } else {
        Node *curr = front;
        int curr_ascii = curr->data;
        while((curr->next != nullptr) and (curr_ascii < ascii)){

            curr = curr->next;

            if (curr->next != nullptr) {
                curr_ascii = curr->data;
            }

            index++;
        }
        int back_ascii = back->data;
        if ((curr_ascii < ascii) and
            ((list_size == 1) or (back_ascii < ascii))) {
            this->insertAt(c, index+1);
        } else {
            this->insertAt(c, index);
        }
    } 

}

/*
 * name: popFromFront      
 * purpose:   removes the first element from the array list
 * arguments: none
 * returns:   none
 * effects:   list_size decreases by 1
 */
void CharLinkedList::popFromFront() {
    if (list_size == 0) {
        throw std::runtime_error("cannot pop from empty LinkedList");
    } else {
        if (list_size != 1) {
            Node *old_front = front;
            front = front->next;
            front->previous = nullptr;
            delete old_front;
        } else {
            delete front;
        }

    }
    list_size--;
}


/*
 * name:      popFromBack      
 * purpose:   removes the last element from the list
 * arguments: none
 * returns:   none
 * effects:   list_size decreases by 1
 */
void CharLinkedList::popFromBack() {
    if (list_size == 0) {
        throw std::runtime_error("cannot pop from empty LinkedList");
    } else {
        if (list_size != 1) {
            Node *old_back = back;
            back = back->previous;
            back->next = nullptr;
            delete old_back;
        }
    }
    list_size--;
}

/*
 * name:      removeAt
 * purpose:   removes element at given index
 * arguments: int index that corresponds with the element that will be removed
 * returns:   none
 * effects:   decreased list_size by 1
 */
//Not done
void CharLinkedList::removeAt(int index) {
    if ((index < 0) or (index >= list_size)) {
        throw std::range_error("index (" + std::to_string(index) +
        ") not in range [0.." + std::to_string(list_size) + ")");
    }

    if (index == 0) {
        this->popFromFront();
    } 
    else if (index == list_size-1) {
        this->popFromBack();
    }
    else {
        Node *curr_node = front;
        int curr_index = 0;
        while (curr_index < index) {
            curr_node = curr_node->next;
            curr_index++;
        }

        Node *old_curr = curr_node;
        curr_node->next->previous = curr_node->previous;
        curr_node = curr_node->next; // Now our curr node is next node
        list_size--;
        if (index != list_size - 1) {
            curr_node->next->previous = curr_node;
        }

        if (index != 0) {
            curr_node->previous->next = curr_node;
        }
        delete old_curr;
    }

}

/*
 * name: replaceAt     
 * purpose:   replace the element at given index with provided char
 * arguments: int index, char c to replace element at index
 * returns:   none
 * effects:   replaces an element within array list
 */
void CharLinkedList::replaceAt(char c, int index) {
    if ((index < 0) or (index >= list_size)) {
        throw std::range_error("index (" + std::to_string(index) +
        ") not in range [0.." + std::to_string(list_size) + ")");
    }
    
    int count = 0;
    Node *curr_node = front;
    curr_node = recReplaceAtHelper(count, index, curr_node);
    curr_node->data = c;
}

/*
 * name:        Recursive Helper Function for CLL ReplaceAt
 * purpose:     Help elementAt iterate through to the given index
 * arguments:   Int for counting current position, int for index we want,
                pointer to the starting node
 * returns:      Node whose data needs to be changed
 * effects:     None
 */
CharLinkedList::Node *CharLinkedList::recReplaceAtHelper(int count,
                            int index, Node *curr_node) const{
    if (count == index) {
        return curr_node;
    } else {
        curr_node = curr_node->next;
        count++;
        return(recReplaceAtHelper(count, index, curr_node));
    }
}

/*
 * name:      concatenate
 * purpose:   adds a CharLinkedList (CLL) to the end of current CLL
 * arguments: pointer to a CLL to add onto the end of existing CLL
 * returns:   none
 * effects:   expands current CLL by adding a new CLL to the end
 */
void CharLinkedList::concatenate(CharLinkedList *other) {
    int new_size = list_size + other->size();

    if (other->size() > 0) {

        Node *copy_curr = other->front;

        for (int i = list_size; i < new_size; i++) {

            pushAtBack(copy_curr->data);
            copy_curr = copy_curr->next;

        }
    }
}

/*
 * name:      printRecursive
 * purpose:   Prints out each node in list
 * arguments: Pointer to current node
 * returns:   none
 * effects:   
 */
void CharLinkedList::printRecursive() {
    printRecHelper(front);
}


/*
 * name:      printRecHelper
 * purpose:   Prints out each node in list
 * arguments: Pointer to current node
 * returns:   none
 * effects:   
 */
void CharLinkedList::printRecHelper(Node *curr) {
    if (curr == nullptr) {
        std::cout << "\n";
    } else {
        std::cout << curr->data << " ";
        printRecHelper(curr->next);
    }
}
/*
 *  unit_tests.h
 *  Ada Wu
 *  2/5/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  Test various situations, edge cases, and exceptions for the functions
 *  in CharLinkedList. Each test function tests one aspect of the below.
 *  Including but not limited to singleton, large array, front, back, empty.
 *
 */

#include "CharLinkedList.h"
#include <cassert>
#include <iostream>
#include <stdexcept>

// ***************** Dummy Test ************************
// Checks if class definition is correct. Does nothing.
void dummy_test() {}

// ***************** Default Constructor Tests ************************
// Tests initialization of default constructor. There should be no
// compiling error
void test_default_constructor() {
    CharLinkedList test_list;
    assert(test_list.size() == 0);
}

// ***************** One-Element CharLinkedList Constructor Tests ***********
// Tests initialization of one-element constructor. There should be no
// compiling error
void test_one_element_constructor() {
    CharLinkedList test_list('a');
    assert(test_list.size() == 1);
}


// ***************** Copy Constructor of Array Tests ***********
// Tests initialization of copy constructor that takes in large array.
// There should be no compiling error
void test_copy_constructor_large() {
    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList test_list(arr, 5);
    test_list.printRecursive();
    std::cout << test_list.size();
    assert(test_list.size() == 5);
}

// Tests initialization of copy constructor that takes in 1-element array.
void test_copy_constructor_singleton() {
    char arr[1] = {'a'};
    CharLinkedList test_list(arr, 1);
    test_list.printRecursive();
    std::cout << test_list.size();
    assert(test_list.size() == 1);
}

// Tests initialization of copy constructor that takes in 2-element array.
void test_copy_constructor_two() {
    char arr[2] = {'a', 'b'};
    CharLinkedList test_list(arr, 2);
    test_list.printRecursive();
    std::cout << test_list.size();
    assert(test_list.size() == 2);
}


// ***************** Deep Copy Constructor of CharLinkedList (CLL) Tests ****
// Tests initialization of deep copy constructor that takes in 1 elemt CLL
// There should be no compiling error
void test_deep_CAL_copy_constructor_singleton() {
    CharLinkedList test_list1('a');
    CharLinkedList test_list2(test_list1);
    assert(test_list2.size() == test_list1.size());
}

// Tests initialization of deep copy constructor that takes in 2-element CLL
void test_deep_CAL_copy_constructor_two() {
    char arr[5] = {'a', 'b'};
    CharLinkedList test_list1(arr, 2);
    CharLinkedList test_list2(test_list1);
    assert(test_list2.size() == test_list1.size());
}

// Tests initialization of deep copy constructor that takes in large CLL
void test_deep_CAL_copy_constructor_large() {
    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList test_list1(arr, 5);
    CharLinkedList test_list2(test_list1);
    assert(test_list2.size() == test_list1.size());
}

// ***************** Equals Operator Tests ***********
// Tests initialization of equals operator constructor. 
void test_equal_operator_singleton() {
    CharLinkedList example('a');

    CharLinkedList test_list;
    test_list = example;

    assert(test_list.size() == example.size());
    assert(test_list.first() == example.first());
    assert(test_list.last() == example.last());
}

void test_equal_operator_many() {
    char arr[4] = {'b', 'c', 'd', 'e'};
    CharLinkedList example(arr, 4);
    CharLinkedList test_list;

    test_list = example;

    assert(test_list.size() == example.size());
    assert(test_list.first() == example.first());
    assert(test_list.last() == example.last());
}

//***************** isEmpty Function Tests ***************************
// Tests if the output of isEmpty is successfully empty for empty array list
void test_isEmpty() {
    CharLinkedList test_list;
    assert(test_list.isEmpty());
}

// Tests if the output of isEmpty is successfully not empty for 1-element array
void test_notEmpty_one_element() {
    CharLinkedList test_list2('a');
    assert(not(test_list2.isEmpty()));
}

// Tests if the output of isEmpty is successfully not empty for large array
void test_notEmpty_many_elements() {
    char arr[4] = {'b', 'c', 'd', 'e'};
    CharLinkedList test_list2(arr, 4);
    assert(not(test_list2.isEmpty()));
}

//***************** Clear Function Tests ***************************
// Tests if the AL is successfully cleared for empty char array list
void test_clear_empty() {
    CharLinkedList test_list;
    test_list.clear();

    assert(test_list.isEmpty());
}

// Tests if the AL is successfully cleared for one element char array list
void test_clear_singleton() {
    CharLinkedList test_list('a');

    assert(not(test_list.isEmpty()));

    test_list.clear();

    assert(test_list.isEmpty());
}

// Tests if the AL is successfully cleared for large char array list
void test_clear_many() {
    char arr[4] = {'b', 'c', 'd', 'e'};
    CharLinkedList test_list(arr, 4);

    assert(not(test_list.isEmpty()));

    test_list.clear();

    assert(test_list.isEmpty());
}

//***************** Size Function Tests ***************************
// Tests if the output is truly the size of the array for empty array
void test_size_zero() {
    CharLinkedList test_list;
    assert(test_list.size() == 0);
}
//Tests if the output is truly the size of the array for one-element array
void test_size_not_zero() {
    CharLinkedList test_list('a');
    assert(test_list.size() == 1);
}

//Tests if the output is truly the size of the array for large array
void test_size_many() {
    char arr[4] = {'b', 'c', 'd', 'e'};
    CharLinkedList test_list(arr, 4);

    assert(test_list.size() == 4);
}

//***************** First Char Function Tests ***************************
//Tests if the first element is returned for one-element CLL
void test_first_func_singleton() {
    CharLinkedList test_list('a');
    assert(test_list.size() == 1);
    assert(test_list.first() == 'a');
}

//Tests if the first element is returned for large CLL
void test_first_func_many() {
    char arr[4] = {'b', 'c', 'd', 'e'};
    CharLinkedList test_list2(arr, 4);
    assert(test_list2.size() == 4);
    assert(test_list2.first() == 'b');
}

//Tests if the first element is returned for large repeating CLL
void test_first_func_many_repeating() {
    char arr[4] = {'b', 'b', 'b', 'b'};
    CharLinkedList test_list2(arr, 4);
    assert(test_list2.size() == 4);
    assert(test_list2.first() == 'b');
}

//Tests if the range error is corrctly thrown for out of bound (empty)
void test_first_range_error() {
    CharLinkedList test_list;
    assert(test_list.size() == 0);

    bool runtime_error_thrown = false;

    std::string error_message = "";

    try {
        test_list.first();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot get first of empty LinkedList");

}

//***************** Last Char Function Tests ***************************
//Tests if the last element is returned for a singleton CLL
void test_last_func_singleton() {
    CharLinkedList test_list('a');
    assert(test_list.size() == 1);
    assert(test_list.last() == 'a');
}

//Tests if the last element is returned for a large CLL
void test_last_func_many() {
    char arr[5] = {'b', 'c', 'd', 'e'};
    CharLinkedList test_list2(arr, 4);
    assert(test_list2.size() == 4);
    assert(test_list2.last() == 'e');
}

//Tests if the last element is returned for large repeating CLL
void test_last_func_many_repeating() {
    char arr[4] = {'b', 'b', 'b', 'b'};
    CharLinkedList test_list2(arr, 4);
    assert(test_list2.size() == 4);
    assert(test_list2.last() == 'b');
}

//Tests if out-of-range error is thrown for an empty list
void test_last_range_error() {
    CharLinkedList test_list;
    assert(test_list.size() == 0);

    // var to track whether runtime_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.last();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot get last of empty LinkedList");
}


//***************** LL Element Finder Tests ***************************
//Given the position in LL, tests if the correct char is printed
void test_elementAt_singleton() {
    CharLinkedList test_list('e');

    assert(test_list.elementAt(0) == 'e');
}

// Given a random middle index, tests if the correct char is printed
void test_elementAt() {
    char arr[3] = {'y', 'e', 's'};
    CharLinkedList test_list(arr, 3);

    assert(test_list.elementAt(1) == 'e');
}

//Given the first index, tests if the correct char is printed
void test_elementAt_front() {
    char arr[3] = {'y', 'e', 's'};
    CharLinkedList test_list(arr, 3);

    assert(test_list.elementAt(0) == 'y');
}

//Given the last index, tests if the correct char is printed
void test_elementAt_back() {
    char arr[3] = {'y', 'e', 's'};
    CharLinkedList test_list(arr, 3);

    assert(test_list.elementAt(2) == 's');
}

//Given an out-of-bounds index, tests if the correct char is printed
void test_elementAt_range_error() {
    char arr[3] = {'y', 'e', 's'};
    CharLinkedList test_list(arr, 3);

    bool range_error_thrown = false;

    std::string error_message = "";

    try {
        test_list.elementAt(22);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (22) not in range [0..3)");
}

//Given an empty CharLinkedList, tests if the error is correclty thrown
void test_elementAt_empty() {
    CharLinkedList test_list;

    bool range_error_thrown = false;

    std::string error_message = "";

    try {
        test_list.elementAt(22);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (22) not in range [0..0)");
}

//***************** CAL To String Converter Function Tests ****************
//Tests if the function prints out in correct format
void test_toString_many() {
    char arr[10] = {'y', 'e', 's', ' ', 'm', 'o', 't', 'h', 'e', 'r'};
    CharLinkedList test_list(arr, 10);

    assert(test_list.toString() == 
        "[CharLinkedList of size 10 <<yes mother>>]");
}

//Tests the toString function with a singleton CharLinkedList
void test_toString_singleton() {
    CharLinkedList test_list('a');

    assert(test_list.toString() == 
        "[CharLinkedList of size 1 <<a>>]");
}

//Tests the toString function with an empty CharLinkedList
void test_toString_empty() {
    CharLinkedList test_list;

    assert(test_list.toString() == 
        "[CharLinkedList of size 0 <<>>]");
}

//***************** Reverse CAL To String Converter Function Tests *******
//Tests if the function prints out in correct format in reverse
void test_toReverseString_many() {
    char arr[10] = {'y', 'e', 's', ' ', 'm', 'o', 't', 'h', 'e', 'r'};
    CharLinkedList test_list(arr, 10);

    assert(test_list.toReverseString() == 
        "[CharLinkedList of size 10 <<rehtom sey>>]");
}

//Tests the ReversetoString function with an one-element CharLinkedList
void test_toReverseString_singleton() {
    CharLinkedList test_list('a');

    assert(test_list.toReverseString() == 
        "[CharLinkedList of size 1 <<a>>]");
}

//Tests the ReversetoString function with an empty CharLinkedList
void test_toReverseString_empty() {
    CharLinkedList test_list;

    assert(test_list.toReverseString() == 
        "[CharLinkedList of size 0 <<>>]");
}

//***************** Pushes Character At Back ***************************
// Tests if a character is successfully added to the back of the array
// for large array
void test_pushAtBack_many_elements() {
    char arr[3] = {'y', 'e', 's'};
    CharLinkedList test_list(arr, 3);
    test_list.printRecursive();
    test_list.pushAtBack('h');

    assert(test_list.last() == 'h');
}

// Tests pushAtBack for an one-element AL
void test_pushAtBack_singleton() {
    CharLinkedList test_list('a');
    test_list.printRecursive();
    test_list.pushAtBack('h');

    assert(test_list.last() == 'h');
}

// Tests pushAtBack for an empty AL
void test_pushAtBack_empty() {
    CharLinkedList test_list;
    test_list.printRecursive();

    test_list.pushAtBack('h');

    assert(test_list.last() == 'h');
}


//***************** Pushes Character At Front ***************************
//Tests if a character is successfully added to the front of the array
void test_pushAtFront_many_elements() {
    char arr[3] = {'y', 'e', 's'};
    CharLinkedList test_list(arr, 3);
    test_list.printRecursive();

    test_list.pushAtFront('h');

    assert(test_list.first() == 'h');
}

// Tests pushAtFront for an one-element AL
void test_pushAtFront_singleton() {
    CharLinkedList test_list('a');
    test_list.printRecursive();

    test_list.pushAtFront('h');

    assert(test_list.first() == 'h');
}

// Tests pushAtFront for an empty AL
void test_pushAtFront_empty() {
    CharLinkedList test_list;
    std::cout << "empty: " << std::endl;
    test_list.printRecursive();

    test_list.pushAtFront('h');

    assert(test_list.first() == 'h');
}

//***************** insertAt Function Tests ************************
// Tests correct insertion into an empty AL.
// Afterwards, size should be 1 and element at index 0
// should be the element we inserted.
void insertAt_empty_correct() { 

    CharLinkedList test_list;
    test_list.insertAt('a', 0);
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');

}

// Tests incorrect insertion into an empty AL.
// Attempts to call insertAt for index larger than 0.
// This should result in an std::range_error being raised.
void insertAt_empty_incorrect() {

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    // insertAt for out-of-range index
         test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
    // if insertAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    range_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0]");
    
}

// Tests correct insertAt for front of 1-element list.
void insertAt_front_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at front
    test_list.insertAt('b', 0);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'a');
    
}

// Tests correct insertAt for back of 1-element list.
void insertAt_back_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at back
    test_list.insertAt('b', 1);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    
}

// Tests calling insertAt for a large number of elements.
// Not only does this test insertAt, it also checks that
// array expansion works correctly.
void insertAt_many_elements() {
    
    CharLinkedList test_list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.insertAt('a', i);
    }

    assert(test_list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
    
}

// Tests insertion into front of a larger list
void insertAt_front_large_list() {
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    test_list.insertAt('y', 0);

    assert(test_list.size() == 10);
    assert(test_list.elementAt(0) == 'y');
    assert(test_list.toString() ==
         "[CharLinkedList of size 10 <<yabczdefgh>>]");

}

// Tests insertion into the back of a larger list
void insertAt_back_large_list() {

    char test_arr[10] = {'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(test_arr, 10);  

    test_list.insertAt('x', 10);

    assert(test_list.size() == 11);
    assert(test_list.elementAt(10) == 'x');
    assert(test_list.toString() == 
    "[CharLinkedList of size 11 <<yabczdefghx>>]"); 

}

// Tests insertion into the middle of a larger list
void insertAt_middle_large_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.insertAt('z', 3);

    assert(test_list.size() == 9);
    assert(test_list.elementAt(3) == 'z');
    assert(test_list.toString() ==     
         "[CharLinkedList of size 9 <<abczdefgh>>]");

}

// Tests out-of-range insertion for a non-empty list.
void insertAt_nonempty_incorrect() {
   
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8]");
    
}

//***************** insertInOrder Function Tests ************************
// Tests correct insertion into an empty AL.
// Afterwards, size should be 1 and element at index 0
// should be the element we inserted.
void insertInOrder_empty_correct() { 

    CharLinkedList test_list;
    test_list.insertInOrder('a');
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');

}

// Tests correct insertInOrder for front of 1-element list.
void insertInOrder_front_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('b');

    // insert at front
    test_list.insertInOrder('a');

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    
}

// Tests correct insertInOrder for back of 1-element list.
void insertInOrder_back_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at back
    test_list.insertInOrder('b');

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    
}

// Tests calling insertInOrder for a large number of elements.
// Not only does this test insertInOrder, it also checks that
// array expansion works correctly.
void insertInOrder_many_elements() {
    
    CharLinkedList test_list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.insertInOrder('a');
    }

    assert(test_list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
    
}

// Tests in-order-insertion of many elements for different inserts
void insertInOrder_many_elements_2() {
    char test_arr[7] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g' };
    CharLinkedList test_list(test_arr, 7);

    for (int i = 0; i < 5; i++) {
        test_list.insertInOrder(test_arr[i]);
    }

    assert(test_list.size() == 12);
    assert(test_list.elementAt(4) == 'c');
    assert(test_list.toString() ==
         "[CharLinkedList of size 12 <<aabbccddeefg>>]");
}

// Tests in-order-insertion into front of a larger list
void insertInOrder_front_large_list() {
    char test_arr[7] = { 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 7);

    test_list.insertInOrder('a');

    assert(test_list.size() == 8);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.toString() ==
         "[CharLinkedList of size 8 <<abcdefgh>>]");

}

// Tests in-order-insertion into the back of a larger list
void insertInOrder_back_large_list() {
    char test_arr[7] = { 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 7);

    test_list.insertInOrder('i');

    assert(test_list.size() == 8);
    assert(test_list.elementAt(7) == 'i');
    assert(test_list.toString() == 
         "[CharLinkedList of size 8 <<bcdefghi>>]");

}

// Tests in-order-insertion into the middle of a larger list
void insertInOrder_middle_large_list() {
    char test_arr[7] = { 'a', 'b', 'c', 'd', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 7);

    test_list.insertInOrder('e');

    assert(test_list.size() == 8);
    assert(test_list.elementAt(4) == 'e');
    assert(test_list.toString() ==
         "[CharLinkedList of size 8 <<abcdefgh>>]");
}

//***************** PopFromFront Tests *********************************
//Tests if a character is successfully popped at the front of the array
void test_popFromFront() {
    char arr[3] = {'y', 'e', 's'};
    CharLinkedList test_list(arr, 3);

    test_list.popFromFront();
    assert(test_list.toString() == "[CharLinkedList of size 2 <<es>>]");
}

void test_empty_popFromFront() {
    bool runtime_error_thrown = false;

    std::string error_message = "";

    CharLinkedList test_list;
    try {
        test_list.popFromFront();
    }
    catch (const std::runtime_error &e) {

    runtime_error_thrown = true;
    error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");

}

//***************** PopFromBack Tests ***************************
//Tests if a character is successfully popped at the back of the array
void test_popFromBack() {
    char arr[3] = {'y', 'e', 's'};
    CharLinkedList test_list(arr, 3);

    test_list.popFromBack();
    assert(test_list.toString() == "[CharLinkedList of size 2 <<ye>>]");
}

void test_empty_popFromBack() {
    bool runtime_error_thrown = false;

    std::string error_message = "";

    CharLinkedList test_list;
    try {
        test_list.popFromBack();
    }
    catch (const std::runtime_error &e) {

    runtime_error_thrown = true;
    error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");

}

//***************** removeAt Function Tests ************************
// Tests correct output for attempted removal within an empty AL.
// Attempts to call removeAt for index smaller than 1.
// This should result in an std::range_error being raised.
void removeAt_empty_correct() {

    bool range_error_thrown = false;

    std::string error_message = "";

    CharLinkedList test_list;
    try {
         test_list.removeAt(1);
    }
    catch (const std::range_error &e) {

    range_error_thrown = true;
    error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (1) not in range [0..0)");
    
}

// Tests correct removeAt for 1-element list.
void removeAt_singleton_list() {
    
    CharLinkedList test_list('a');

    test_list.popFromBack();

    assert(test_list.size() == 0);
}

// Tests calling removeAt for a large number of elements.
void removeAt_many_elements() {
    
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    // remove 5 elements
    for (int i = 0; i < 5; i++) {
        test_list.removeAt(0);
    }

    std::cout << test_list.toString();

    assert(test_list.size() == 4);
}

// Tests removeAt for front of a larger list
void removeAt_front_large_list() {
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    test_list.removeAt(0);

    assert(test_list.size() == 8);
    assert(test_list.first() == 'b');
    assert(test_list.toString() == 
         "[CharLinkedList of size 8 <<bczdefgh>>]");

}

// Tests removeAt into the back of a larger list
void removeAt_back_large_list() {

    char test_arr[9] = {'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);  

    test_list.removeAt(8);

    assert(test_list.size() == 8);
    assert(test_list.last() == 'g');
    assert(test_list.toString() == 
         "[CharLinkedList of size 8 <<abczdefg>>]"); 

}

// Tests removeAt into the middle of a larger list
void removeAt_middle_large_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.removeAt(3);

    assert(test_list.size() == 7);
    assert(test_list.elementAt(3) == 'e');
    assert(test_list.toString() == 
         "[CharLinkedList of size 7 <<abcefgh>>]");

}

// Tests out-of-range removal for a non-empty list.
void removeAt_nonempty_incorrect() {
   
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.removeAt(42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8)");
    
}

//***************** replaceAt Function Tests ************************
// Tests correct output for attempted replacement within an empty AL.
// Attempts to call replaceAt for index smaller than 1.
// This should result in an std::range_error being raised.
void replaceAt_empty_correct() {

    bool range_error_thrown = false;

    std::string error_message = "";

    CharLinkedList test_list;
    try {
        test_list.replaceAt('c', 1);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (1) not in range [0..0)");
    
}

// Tests correct replaceAt for 1-element list.
void replaceAt_singleton_list() {
    
    CharLinkedList test_list('a');

    test_list.replaceAt('c', 0);

    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'c');

}

// Tests calling removeAt for a large number of elements.
void replaceAt_many_elements() {
    
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    // replaces 9 elements
    for (int i = 0; i < 9; i++) {
        // always insert at the back of the list
        test_list.replaceAt('a', i);
    }

    assert(test_list.size() == 9);
    for (int i = 0; i < 9; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
}

// Tests removeAt for front of a larger list
void replaceAt_front_large_list() {
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    test_list.replaceAt('z', 0);

    assert(test_list.size() == 9);
    assert(test_list.first() == 'z');
    assert(test_list.toString() == 
         "[CharLinkedList of size 9 <<zbczdefgh>>]");

}

// Tests removeAt into the back of a larger list
void replaceAt_back_large_list() {

    char test_arr[9] = {'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);  

    test_list.replaceAt('z', 8);

    assert(test_list.size() == 9);
    assert(test_list.last() == 'z');
    assert(test_list.toString() == 
    "[CharLinkedList of size 9 <<abczdefgz>>]"); 

}

// Tests removeAt into the middle of a larger list
void replaceAt_middle_large_list() {
    char test_arr[9] = { 'a', 'b', 'c', 'y', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    test_list.replaceAt('z', 3);

    assert(test_list.size() == 9);
    assert(test_list.elementAt(3) == 'z');
    assert(test_list.toString() == 
         "[CharLinkedList of size 9 <<abczdefgh>>]");

}

// Tests out-of-range replacement for a non-empty list.
void replaceAt_nonempty_incorrect() {
   
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.replaceAt('q', 42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8)");
    
}

//***************** concatenate Function Tests ************************
// Tests default concatenate func with both arrays being non-empty
void test_concatenate() {
    CharLinkedList test_list1('a');
    char test_arr[2] = {'d', 'a'};
    CharLinkedList test_list2(test_arr, 2);

    int test_list1_size_old = test_list1.size();

    test_list1.concatenate(&test_list2);

     assert(std::to_string(test_list1.size())
         == std::to_string(test_list1_size_old + test_list2.size()));
    
    assert(test_list1.elementAt(0) == 'a');
    assert(test_list1.elementAt(1) == 'd');
    assert(test_list1.elementAt(2) == 'a');

}

// Tests concatenation of a CAL by itself
void concatenate_itself() {
    char test_arr[2] = {'d', 'a'};
    CharLinkedList test_list(test_arr, 2);

    test_list.concatenate(&test_list);
    
    assert(test_list.elementAt(0) == 'd');
    assert(test_list.elementAt(1) == 'a');
    assert(test_list.elementAt(2) == 'd');
    assert(test_list.elementAt(3) == 'a');
}

// Tests correct output for concatenation by an empty string
void concatenated_by_empty_AL() {
    CharLinkedList test_list1('a');
    CharLinkedList test_list2;

    int test_list1_size_old = test_list1.size();
    std::cout << "sz: " << test_list2.size() << std::endl;
    //std::cout << test_list2.size() << std::endl;
    test_list1.concatenate(&test_list2);
    assert(std::to_string(test_list1.size())
        == std::to_string(test_list1_size_old + test_list2.size()));
}

// Tests correct output for concatenation of an empty string
void empty_AL_being_concatenated() {
    CharLinkedList test_list1;
    CharLinkedList test_list2('a');

    int test_list1_size_old = test_list1.size();
    test_list1.concatenate(&test_list2);
    // assert(std::to_string(test_list1.size())
    //     == std::to_string(test_list1_size_old + test_list2.size()));
}

/*
 *  unit_tests.h
 *  Alex Dai
 *  Feb. 7, 2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 * Purpose:
 *   This C++ unit test file is dedicated to thoroughly testing each method
 *   in the CharLinkedList class. The primary objective is to ensure the 
 *   correctness and reliability of the class implementation, covering edge 
 *   cases and expected behavior for all methods. It serves as an essential 
 *   component of the development process, allowing developers to verify the 
 *   robustness of the CharLinkedList class.
 *
 * Functionality:
 *   1. Validate the behavior of the display method for correct output of the
 *      linked list.
 *   2. Thoroughly test edge cases, such as empty lists, single-node lists, 
 *      and boundary indices.
 *   3. Ensure proper memory management by testing memory allocation and 
 *      deallocation.
 *
 */

#include <cassert>
#include <iostream>
#include <string>
#include <stdexcept>

#include "CharLinkedList.h"

//test the empty list initialization
void constructor_empty_test()
{
    CharLinkedList linkedlist;
    assert(linkedlist.size() == 0);
}

// test the single elem list initialization
void constructor_singleton_test()
{
    CharLinkedList test_list('a');
    assert(test_list.size() == 1);
    assert(test_list.first() == 'a');
    assert(test_list.last() == 'a');
}

// test many elem list initilaization
void constructor_many_test()
{
    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList test_list(arr, 5);

    assert(test_list.size() == 5);
    assert(test_list.first() == 'a');
    assert(test_list.elementAt(3) == 'd');
    assert(test_list.last() == 'e');
}

// test single element list that is copied to form another list
void copy_constructor_singleton_test()
{
    CharLinkedList test_list1('a');
    CharLinkedList test_list2(test_list1);

    assert(test_list2.size() == test_list1.size());
    assert(test_list2.first() == 'a');
}

// test copying many elem list to make a nnew list
void copy_constructor_many_test()
{
    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList test_list1(arr, 5);
    CharLinkedList test_list2(test_list1);

    assert(test_list2.size() == test_list1.size());
    assert(test_list2.elementAt(3) == 'd');
    assert(test_list2.elementAt(4) == 'e');
}

// test assigning a single element list to initialize
// a new list
void assignment_operator_singleton_test()
{
    CharLinkedList test_list1('a');
    CharLinkedList test_list2 = test_list1;

    assert(test_list2.size() == test_list1.size());
    assert(test_list2.first() == 'a');
}

// test assigning many elem list to initilize a new list
void assignment_operator_many_test()
{
    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList test_list1(arr, 5);
    CharLinkedList test_list2 = test_list1;

    assert(test_list2.size() == test_list1.size());
    assert(test_list2.elementAt(3) == 'd');
    assert(test_list2.elementAt(4) == 'e');
    assert(test_list2.toString() == "[CharLinkedList of size 5 <<abcde>>]");
}


//see if it passes the valgrind to prevent the double free errors
void clear_empty_test()
{
    CharLinkedList test_list1;
    test_list1.clear();

    assert(test_list1.size() == 0);
}

//see if it passes the valgrind to prevent the double free errors
void clear_many_test()
{
    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList test_list1(arr, 5);
    test_list1.clear();

    assert(test_list1.size() == 0);
    assert(test_list1.toString() == "[CharLinkedList of size 0 <<>>]");
}

// test if first produce the correct error message
void first_wrong_test()
{
    std::string error_message = "";
    bool runtime_error = false;
    CharLinkedList test_list;
    try{
        test_list.first();
    }
    catch (const std::runtime_error &e){
        runtime_error = true;
        error_message = e.what();
    }

    assert(runtime_error);
    assert(error_message == "cannot get first of empty LinkedList");
}

// test if last prodcue the correct error message
void last_wrong_test()
{
    std::string error_message = "";
    bool runtime_error = false;
    CharLinkedList test_list;
    try{
        test_list.last();
    }
    catch (const std::runtime_error &e){
        runtime_error = true;
        error_message = e.what();
    }

    assert(runtime_error);
    assert(error_message == "cannot get last of empty LinkedList");
}

// test if elem at produce the correct error messgae
void elementAt_wrong_test()
{
    bool range_error_thrown = false;
    std::string error_message = "";
    char arr[3] = {'b','a','c'};
    CharLinkedList list(arr, 3);

    try{
        list.elementAt(8);
    }
    catch (const std::range_error &e){
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (8) not in range [0..3)");
}

// test if push at back a elem at an empty list works
void pushAtBack_empty_test(){
    CharLinkedList test_list;
    test_list.pushAtBack('a');

    assert(test_list.first() == 'a');
    assert(test_list.toString() == "[CharLinkedList of size 1 <<a>>]");
}

// test adding element at back to a single elem list
void pushAtBack_singleton_test(){
    CharLinkedList test_list('b');
    test_list.pushAtBack('a');

    assert(test_list.elementAt(1) == 'a');
    assert(test_list.toString() == "[CharLinkedList of size 2 <<ba>>]");
}

// test adding elem to a many elem list
void pushAtBack_many_test(){
    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList test_list1(arr, 5);

    test_list1.pushAtBack('a');
    test_list1.pushAtBack('b');
    test_list1.pushAtBack('z');

    assert(test_list1.size() == 8);
    assert(test_list1.elementAt(6) == 'b');
    assert(test_list1.elementAt(7) == 'z');
    assert(test_list1.toString() == "[CharLinkedList of size 8 <<abcdeabz>>]");
}

// test adding elem to front of a empty list
void pushAtFront_empty_test(){
    CharLinkedList test_list;
    test_list.pushAtFront('a');

    assert(test_list.first() == 'a');
    assert(test_list.toString() == "[CharLinkedList of size 1 <<a>>]");
}

// test adding elem to fronr of a single elem list
void pushAtFront_singleton_test(){
    CharLinkedList test_list('b');
    test_list.pushAtFront('a');

    assert(test_list.elementAt(1) == 'b');
    assert(test_list.toString() == "[CharLinkedList of size 2 <<ab>>]");
}

// test adding elem to fornt of a many elem list
void pushAtFront_many_test(){
    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList test_list1(arr, 5);

    test_list1.pushAtFront('a');
    test_list1.pushAtFront('b');
    test_list1.pushAtFront('z');

    assert(test_list1.size() == 8);
    assert(test_list1.elementAt(1) == 'b');
    assert(test_list1.elementAt(0) == 'z');
    assert(test_list1.toString() == "[CharLinkedList of size 8 <<zbaabcde>>]");
}

// test if inserting at function produce the correct error message
void insertAt_wrong_test()
{
    bool range_error_thrown = false;
    std::string error_message = "";
    char arr[3] = {'b','a','c'};
    CharLinkedList list(arr, 3);

    try{
        list.insertAt('c', 8);
    }
    catch (const std::range_error &e){
        range_error_thrown = true;
        error_message = e.what();
    }
    
    assert(range_error_thrown);
    assert(error_message == "index (8) not in range [0..3]");
}

// test iserting a elem to the index of a empty list
void insertAt_empty_test(){
    CharLinkedList test_list;
    test_list.insertAt('a', 0);

    assert(test_list.first() == 'a');
    assert(test_list.toString() == "[CharLinkedList of size 1 <<a>>]");
}

// test inserting a elem at index of a single elem list
void insertAt_singleton_test(){
    CharLinkedList test_list('b');
    test_list.insertAt('a', 1);
    test_list.insertAt('c', 0);

    assert(test_list.elementAt(2) == 'a');
    assert(test_list.elementAt(0) == 'c');
    assert(test_list.toString() == "[CharLinkedList of size 3 <<cba>>]");
}

// test inseting elem to the index of a many elem list
void insertAt_many_test(){
    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList test_list1(arr, 5);

    test_list1.insertAt('a', 3);
    test_list1.insertAt('b', 5);
    test_list1.insertAt('z', 0);

    assert(test_list1.size() == 8);
    assert(test_list1.elementAt(7) == 'e');
    assert(test_list1.elementAt(6) == 'b');
    assert(test_list1.elementAt(0) == 'z');
    assert(test_list1.toString() == "[CharLinkedList of size 8 <<zabcadbe>>]");
}

// test removing elem from front of a list
void popFromFront_singleton_test(){
    CharLinkedList test_list('b');
    test_list.popFromFront();

    assert(test_list.size() == 0);
    assert(test_list.toString() == "[CharLinkedList of size 0 <<>>]");
}

// test removing elem from a many elem list
void popFromFront_many_test(){
    char arr[7] = {'a', 'b', 'c', 'd', 'e','f','g'};
    CharLinkedList test_list1(arr, 7);
    test_list1.popFromFront();
    test_list1.popFromFront();

    assert(test_list1.size() == 5);
    assert(test_list1.elementAt(1) == 'd');
    assert(test_list1.elementAt(2) == 'e');
    assert(test_list1.elementAt(3) == 'f');
    assert(test_list1.toString() == "[CharLinkedList of size 5 <<cdefg>>]");
}

// test removing elem from the back of a single elem list
void popFromBack_singleton_test(){
    CharLinkedList test_list('b');
    assert(test_list.toString() == "[CharLinkedList of size 1 <<b>>]");
    test_list.popFromBack();

    assert(test_list.size() == 0);
    assert(test_list.toString() == "[CharLinkedList of size 0 <<>>]");
}
//test removing elem from back of a many elem list
void popFromBack_many_test(){
    char arr[7] = {'a', 'b', 'c', 'd', 'e','f','g'};
    CharLinkedList test_list1(arr, 7);
    test_list1.popFromBack();
    test_list1.popFromBack();

    assert(test_list1.size() == 5);
    assert(test_list1.elementAt(1) == 'b');
    assert(test_list1.elementAt(4) == 'e');
    assert(test_list1.elementAt(3) == 'd');
    assert(test_list1.toString() == "[CharLinkedList of size 5 <<abcde>>]");
}

//test if the index is out of range the funtion prodcue the correct error
void removeAt_wrong_test()
{
    bool range_error_thrown = false;
    std::string error_message = "";
    char arr[3] = {'b','a','c'};
    CharLinkedList list(arr, 3);

    try{
        list.removeAt(8);
    }
    catch (const std::range_error &e){
        range_error_thrown = true;
        error_message = e.what();
    }
    
    assert(range_error_thrown);
    assert(error_message == "index (8) not in range [0..3)");
}

// test remove at index of a single elem list
void removeAt_singleton_test(){
    CharLinkedList test_list('b');
    test_list.removeAt(0);

    assert(test_list.size() == 0);
    assert(test_list.toString() == "[CharLinkedList of size 0 <<>>]");
}

// test remove at index of a many elem list
void removeAt_many_test(){
    char arr[7] = {'a', 'b', 'c', 'd', 'e','f','g'};
    CharLinkedList test_list1(arr, 7);
    test_list1.removeAt(4);
    test_list1.removeAt(5);
    test_list1.removeAt(2);

    assert(test_list1.size() == 4);
    assert(test_list1.elementAt(1) == 'b');
    assert(test_list1.elementAt(2) == 'd');
    assert(test_list1.elementAt(3) == 'f');
    assert(test_list1.toString() == "[CharLinkedList of size 4 <<abdf>>]");
}

// test replacing elem at a wrong index and producee the error
void replaceAt_wrong_test()
{
    bool range_error_thrown = false;
    std::string error_message = "";
    char arr[3] = {'b','a','c'};
    CharLinkedList list(arr, 3);

    try{
        list.replaceAt('c', 8);
    }
    catch (const std::range_error &e){
        range_error_thrown = true;
        error_message = e.what();
    }
    
    assert(range_error_thrown);
    assert(error_message == "index (8) not in range [0..3)");
}

// test replace elem at a index of a single elem list
void replaceAt_singleton_test(){
    CharLinkedList test_list('b');
    test_list.replaceAt('c', 0);

    assert(test_list.first() == 'c');
}

// test replacing elem at a many elem list
void replaceAt_many_test(){
    char arr[7] = {'a', 'b', 'c', 'd', 'e','f','g'};
    CharLinkedList test_list1(arr, 7);
    test_list1.replaceAt('b', 4);
    test_list1.replaceAt('z', 5);
    test_list1.replaceAt('k', 6);

    assert(test_list1.size() == 7);
    assert(test_list1.elementAt(4) == 'b');
    assert(test_list1.elementAt(5) == 'z');
    assert(test_list1.elementAt(6) == 'k');
    assert(test_list1.toString() == "[CharLinkedList of size 7 <<abcdbzk>>]");
}

// test concatenating two single elem list
void concatenate_singleton_test(){
    CharLinkedList test_list1('b');
    CharLinkedList test_list2('z');
    
    test_list1.concatenate(&test_list2);
    assert(test_list1.size() == 2);
    assert(test_list1.elementAt(1) == 'z');
    assert(test_list1.toString() == "[CharLinkedList of size 2 <<bz>>]");
}
//test concatenating two many elem list
void concatenate_many_test(){
    char arr[3] = {'a', 'b', 'c'};
    char arr1[2] = {'a', 'b'};
    CharLinkedList test_list1(arr, 3);
    CharLinkedList test_list2(arr1, 2);

    test_list1.concatenate(&test_list2);
    assert(test_list1.toString() == "[CharLinkedList of size 5 <<abcab>>]");
}

// test concatenating two empty lists
void concatenate_empty_test(){
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList test_list1(arr, 3);
    CharLinkedList test_list2;

    test_list1.concatenate(&test_list2);
    assert(test_list1.toString() == "[CharLinkedList of size 3 <<abc>>]");
}

// test concatnating two smae list
void concatenate_same_test(){
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList test_list1(arr, 3);
    CharLinkedList test_list2(arr, 3);

    test_list1.concatenate(&test_list2);
    assert(test_list1.toString() == "[CharLinkedList of size 6 <<abcabc>>]");
}

// test in sert inorder of a single elem list
void insertInOrder_singleton_test(){
    CharLinkedList test_list1('b');

    test_list1.insertInOrder('d');
    test_list1.insertInOrder('c');
    assert(test_list1.toString() == "[CharLinkedList of size 3 <<bcd>>]");
}

// test insert in order of a many elem list
void insertInOrder_many_test(){
    char arr[6] = {'b', 'c', 'e', 'g', 'm','r'};
    CharLinkedList test_list(arr, 6);

    test_list.insertInOrder('a');
    test_list.insertInOrder('x');
    assert(test_list.toString() == "[CharLinkedList of size 8 <<abcegmrx>>]");
}

// test inserting at a empty list
void insertInOrder_empty_test(){
    CharLinkedList test_list1;

    test_list1.insertInOrder('d');
    test_list1.insertInOrder('c');
    assert(test_list1.toString() == "[CharLinkedList of size 2 <<cd>>]");
}

// test insertinng at a many elem list
void insertInOrder_many_test_2(){
    char arr[6] = {'b', 'c', 'e', 'g', 'm','r'};
    CharLinkedList test_list(arr, 6);

    test_list.insertInOrder('a');
    test_list.insertInOrder('x');
    assert(test_list.toString() == "[CharLinkedList of size 8 <<abcegmrx>>]");
}

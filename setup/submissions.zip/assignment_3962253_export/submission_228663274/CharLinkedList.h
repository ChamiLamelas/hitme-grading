/*
 *  CharLinkedList.h
 *  Alex Dai
 *  Feburary 7, 2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 * Purpose:
 *   This header file declares the CharLinkedList class, which represents a
 *   doubly-linked list of characters. The class provides methods for 
 *   inserting elements at the front, at the back, and at a specific index.
 *   It also includes methods for removing elements, accessing elements at a
 *   given index, and displaying the contents of the list.
 *   The class follows a linked list structure with nodes containing character 
 *   data, a pointer to the next node, and a pointer to the previous node.
 *   Memory management is handled through dynamic allocation and deallocation.
 *
 * Usage:
 *   1. Include this header file in the source code where the CharLinkedList 
 *      class is needed.
 *   2. Create an instance of CharLinkedList to manage a linked list of 
 *      characters.
 *   3. Use the provided methods to manipulate and interact with the linked 
 *      list.
 *
 */

#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H

#include <iostream>
#include <string>
#include <stdexcept>

class CharLinkedList {
public:
    CharLinkedList();
    CharLinkedList(char c);
    CharLinkedList(char *arr, int size);
    CharLinkedList(const CharLinkedList &other);
    ~CharLinkedList();

    CharLinkedList &operator=(const CharLinkedList &other);
    bool isEmpty() const;
    void clear();
    int size() const;
    char first() const;
    char last() const;
    char elementAt(int index) const;
    std::string toString() const;
    std::string toReverseString() const;
    void pushAtBack(char c);
    void pushAtFront(char c);
    void insertAt(char c, int index);
    void insertInOrder(char c);
    void popFromFront();
    void popFromBack();
    void removeAt(int index);
    void replaceAt(char c, int index);
    void concatenate(CharLinkedList *other);

private:
    struct Node{
        char info;
        Node *previous;
        Node *next;
    };

    Node *front = nullptr;
    Node *back = nullptr;
    int lSize;

    Node *newNode(char c, Node *next);
    void recycleRecursive(Node *curr);
    char find_index(Node *curr, int index) const;
};

#endif

/*
 *  CharLinkedList.cpp
 *  Alex Dai
 *  Feb. 7, 2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 * Purpose:
 *  This file implements the CharLinkedList class, a doubly-linked list for
 *  characters. It provides methods for inserting at the front, back, and a
 *  specific index. Removal, element access, and display are supported. Memory
 *  is managed dynamically. To use, include this file with CharLinkedList.h
 *  and compile both with the source file. The example in the main function
 *  demonstrates fundamental operations on the CharLinkedList class.
 *
 */

#include "CharLinkedList.h"
#include <iostream>
#include <string>
#include <stdexcept>


// Input: None.
// Description: Initializes an empty doubly-linked list.
// Output: None.
CharLinkedList::CharLinkedList()
{
    front = nullptr;
    back = nullptr;
    lSize = 0;
}

// Input: A character c.
// Description: Initializes a doubly-linked list with a single character.
// Output: None.
CharLinkedList::CharLinkedList(char c)
{
    front = newNode(c, front);
    back = front;
    lSize = 1;
}

// Input: A character array arr of size size.
// Description: Initializes a doubly-linked list with characters from an
// array.
// Output: None.
CharLinkedList::CharLinkedList(char *arr, int size)
{
    lSize = size;
    front = newNode(arr[lSize - 1], front);
    for(int i = size - 2; i >= 0; i--){
        front = newNode(arr[i], front);
    }
}

// Input: Another doubly-linked list other.
// Description: Creates a new doubly-linked list by copying the elements
// from another list.
// Output: None.
CharLinkedList::CharLinkedList(const CharLinkedList &other)
{
    lSize = other.lSize;
    char arr[lSize];
    for(int i = 0; i < lSize; i++){
        arr[i] = other.elementAt(i);
    }
    front = newNode(arr[lSize - 1], front);
    for(int i = lSize - 2; i >= 0; i--){
        front = newNode(arr[i], front);
    }
}

// Input: None.
// Description: Destroys the doubly-linked list, freeing all allocated memory.
// Output: None.
CharLinkedList::~CharLinkedList()
{
    if(lSize != 0){
        recycleRecursive(front);
    }
}

// Input: Another doubly-linked list other.
// Description: Assigns the contents of another doubly-linked list to
// the current list.
// Output: Reference to the current list.
CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other)
{
    if(this != &other){
        clear();
        Node* otherCurrent = other.front;
        while(otherCurrent != nullptr) {
            pushAtBack(otherCurrent->info);
            otherCurrent = otherCurrent->next;
        }
    }
    return *this;
}

// Input: None.
// Description: Checks if the doubly-linked list is empty.
// Output: true if the list is empty; false otherwise.
bool CharLinkedList::isEmpty() const
{
    if(lSize == 0){
        return true;
    }
    return false;
}

// Input: None.
// Description: Clears all elements from the doubly-linked list.
// Output: None.
void CharLinkedList::clear()
{
    lSize = 0;
    recycleRecursive(front);
}

// Input: None.
// Description: Returns the number of elements in the doubly-linked list.
// Output: The current size of the list.
int CharLinkedList::size() const
{
    return lSize;
}

// Input: None.
// Description: Returns the first element in the doubly-linked list.
// Output: The first element of the list.
char CharLinkedList::first() const
{
    if(lSize == 0){
        throw std::runtime_error("cannot get first of empty LinkedList");
    }
    return front->info;
}

// Input: None.
// Description: Returns the last element in the doubly-linked list.
// Output: The last element of the list.
char CharLinkedList::last() const
{
    if(lSize == 0){
        throw std::runtime_error("cannot get last of empty LinkedList");
    }
    return back->info;
}

// Input: An integer index.
// Description: Returns the element at the specified index in the
// doubly-linked list.
// Output: The element at the specified index.
char CharLinkedList::elementAt(int index) const
{
    if(index < 0 or index > lSize - 1){
        std::string error_message = "index (" + std::to_string(index) +
        ") not in range [0.." + std::to_string(lSize) + ")";

        throw std::range_error(error_message);
    }
    if(index == 0){
        return front->info;
    }
    else{
        Node *curr = front;
        int curr_index = 0;
        while( curr != nullptr and curr_index < index){
            curr = curr->next;
            curr_index ++;
        }
        return curr->info;
    }
}


// Input: None.
// Description: Converts the doubly-linked list to a string representation.
// Output: A string representing the contents of the list.
std::string CharLinkedList::toString() const
{
    std::string s = "";
    for(int i = 0; i < lSize; i ++){
        s = s + elementAt(i);
    }
    std::string str = "[CharLinkedList of size " + std::to_string(lSize) +
    " <<" + s + ">>" + "]";

    return str;
}

// Input: None.
// Description: Converts the doubly-linked list to a reversed string
// representation.
// Output: A string representing the reversed contents of the list.
std::string CharLinkedList::toReverseString() const
{
    std::string s = "";
    for(int i = 1; i <= lSize; i++){
        s = s + elementAt(lSize - i);
    }
    std::string str = "[CharLinkedList of size " + std::to_string(lSize) +
    " <<" + s + ">>" + "]";

    return str;
}

// Input: A character c.
// Description: Adds a new element with the specified character to the back
// of the doubly-linked list.
// Output: None.
void CharLinkedList::pushAtBack(char c)
{
    Node *new_node = new Node();
    new_node->info = c;

    if(back == nullptr){
        front = back = new_node;
    }
    else{
        new_node->previous = back;
        back->next = new_node;
        back = new_node;
    }
    lSize ++;
}

// Input: A character c.
// Description: Adds a new element with the specified character to the
// front of the doubly-linked list.
// Output: None.
void CharLinkedList::pushAtFront(char c)
{
    front = newNode(c, front);
    lSize ++;
}

// Input:
// A character c.
// An integer index.
// Description: Inserts a new element with the specified character at the
// given index in the doubly-linked list.
// Output: None.
void CharLinkedList::insertAt(char c, int index)
{
    if(index < 0 or index > lSize){
        std::string error_message = "index (" + std::to_string(index) +
        ") not in range [0.." + std::to_string(lSize) + "]";

        throw std::range_error(error_message);
    }
    if(index == 0){
        pushAtFront(c);
    }
    else{
        int count = 0;
        Node *curr = front;
        while(curr != nullptr and count < index - 1){
            curr = curr->next;
            count ++;
        }
        if(curr != nullptr){
            if(curr->next != nullptr){
                curr->next = newNode(c, curr->next);
                lSize ++;
            }
            if(curr->next == nullptr){
                pushAtBack(c);
            }
        }
    }
}

// Input: A character c.
// Description: Inserts a new element with the specified character in 
// ascending order in the doubly-linked list.
// Output: None.
void CharLinkedList::insertInOrder(char c)
{
    int index = 0;
    if(lSize == 0){
        pushAtFront(c);
    }
    else{
        for(int i = 0; i < lSize; i++){
            if(elementAt(i) < c){
                index = i+1;
            }
        }
        insertAt(c, index);
    }
}

// Input: None.
// Description: Removes the element from the front of the doubly-linked list.
// Output: None.
void CharLinkedList::popFromFront()
{
    Node *temp = front;
    if(lSize == 0){
        throw std::runtime_error("cannot pop from empty LinkedList");
    }
    if(front->next == nullptr){
        back = nullptr;
    }
    else{
        front = front->next;
        front->previous = nullptr;
    }
    delete temp;
    lSize --;
}

// Input: None.
// Description: Removes the element from the back of the doubly-linked list.
// Output: None.
void CharLinkedList::popFromBack()
{
    Node *temp = back;
    if(lSize == 0){
        throw std::runtime_error("cannot pop from empty LinkedList");
    }
    if(back->previous == nullptr){
        front = nullptr;
    }
    else{
        back = back->previous;
        back->next = nullptr;
    }
    delete temp;
    lSize --;
}

// Input: An integer index.
// Description: Removes the element at the specified index from the
// doubly-linked list.
// Output: None.
void CharLinkedList::removeAt(int index)
{ 
    if(index < 0 or index > lSize - 1){
        std::string error_message = "index (" + std::to_string(index) +
        ") not in range [0.." + std::to_string(lSize) + ")";

        throw std::range_error(error_message);
    }
    if(index == 0){
        popFromFront();
    }
    else{
        int count = 0;
        Node *curr = front;
        while(curr != nullptr and count < index - 1){
            curr = curr->next;
            count ++;
        }
        if(curr->next != nullptr){
            Node *nodeToRemove = curr->next;
            curr->next = nodeToRemove->next;
            if(nodeToRemove->next == nullptr){
                back = curr;
            }
            else{
                nodeToRemove->next->previous = curr;
            }
            delete nodeToRemove;
            lSize --;
        }
    }
}


// Input:
// A character c.
// An integer index.
// Description: Replaces the element at the specified index with the given
// character in the doubly-linked list.
// Output: None
void CharLinkedList::replaceAt(char c, int index)
{
    if(index < 0 or index > lSize - 1){
        std::string error_message = "index (" + std::to_string(index) +
        ") not in range [0.." + std::to_string(lSize) + ")";

        throw std::range_error(error_message);
    }
    insertAt(c, index);
    removeAt(index + 1);
}

// Input: Another CharLinkedList pointer other.
// Description: Concatenates the elements of another doubly-linked list at the
// end of the current list.
// Output: None.
void CharLinkedList::concatenate(CharLinkedList *other)
{
    if(other->isEmpty()){
        return;
    }
    else{
        CharLinkedList new_list = *other;
        for(int i = 0; i < other->lSize; i++){
            pushAtBack(new_list.elementAt(i));
        }
    }
}

// Input:
// A character c.
// A pointer to the next node next.
// Description: Creates a new node with the specified character and next node
// in the doubly-linked list.
// Output: A pointer to the newly created node.
CharLinkedList::Node *CharLinkedList::newNode(char c, Node *next)
{
    Node *new_node = new Node();
    new_node->info = c;

    if(next == nullptr){
        front = back = new_node;
        return new_node;
    }
    else{
        new_node->next = next;
        next->previous = new_node;
        return new_node;
    }
}

// Input: A pointer to the current node curr.
// Description: Recursively deallocates memory for all nodes starting from 
// the given node.
// Output: None.
void CharLinkedList::recycleRecursive(Node *curr)
{
    if(curr == nullptr){
        return;
    }
    else{
        Node *next = curr->next;
        delete curr;
        recycleRecursive(next);
    }
}

/*
 *  unit_tests.h
 *  Allison Zhang
 *  2/1/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  Various Unit Tests for the functions and general functionality of 
 *  CharLinkedList
 *
 */


#include "CharLinkedList.h"
#include <cassert>
#include <iostream>

using namespace std;

void ll_constructor_test0() {
    CharLinkedList list;
    assert(list.size() == 0);
    assert(list.isEmpty());
}

void ll_pushAtFront_0() {
    CharLinkedList list;
    list.pushAtFront('a');
    assert(list.size() == 1);
    assert(list.first() == 'a');
    assert(list.last() == 'a');
}

void ll_pushAtFront_1() {
    CharLinkedList list;
    list.pushAtFront('a');
    list.pushAtFront('b');
    assert(list.size() == 2);
    assert(list.first() == 'b');
    assert(list.last() == 'a');
}

void ll_pushAtFront_long() {
    CharLinkedList list;
    for (int i = 0; i < 1000; i++) {
        list.pushAtFront('a');
    }
    assert(list.size() == 1000);
    assert(list.first() == 'a');
    assert(list.last() == 'a');
}


void ll_elementAt_1() {
    CharLinkedList list;
    list.pushAtFront('a');
    list.pushAtFront('b');
    assert(list.size() == 2);
    assert(list.elementAt(0) == 'b');
    assert(list.elementAt(1) == 'a');
}

void ll_elementAt_2() {
    CharLinkedList list;
    for (int i = 0; i < 1000; i++) {
        list.pushAtFront('a');
    }
    assert(list.size() == 1000);
    assert(list.elementAt(0) == 'a');
    assert(list.elementAt(890) == 'a');
    assert(list.elementAt(999) == 'a');
}

void ll_elementAt_incorrect() {
    CharLinkedList test_list;

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.elementAt(1);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (1) not in range [0..0)");
}

void copy_constructor_emptylist() {
    CharLinkedList list;
    CharLinkedList list2(list);
    // list.pushAtFront('a');
    // list.pushAtFront('b');
    // list.pushAtFront('c');
}

void ll_constructor_test_empty() {
    char test_arr[0] = {};
    CharLinkedList list(test_arr, 0);
    assert(list.isEmpty());
}

void ll_constructor_test_largeList() {
    char test_arr[10] = { 'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList list(test_arr, 10);
    assert(not list.isEmpty());
    assert(list.elementAt(1) == 'a');
    assert(list.elementAt(2) == 'b');
    assert(list.elementAt(0) == 'y');
    assert(list.elementAt(9) == 'h');
}

void insert_at_test_empty() {
    CharLinkedList list;
    list.insertAt('a', 0);
    assert(list.first() == 'a');
    assert(list.last() == 'a');
}

void insert_at_test_1() {
    char test_arr[10] = { 'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList list(test_arr, 10);
    list.insertAt('x', 1); 
    assert(list.elementAt(1) == 'x');
    assert(list.size() == 11);
}

void insert_at_test_2() {
    char test_arr[10] = { 'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList list(test_arr, 10);
    list.insertAt('x', 10); 
    assert(list.elementAt(10) == 'x');
    assert(list.last() == 'x');
    assert(list.size() == 11);
}

void equalOp_4_test1() {
    CharLinkedList list('a');
    CharLinkedList list2;
    list2 = list;
    assert(list2.elementAt(0) == 'a');
}

void is_empty_test1() {
    CharLinkedList list('a');
    assert(not list.isEmpty());
}

void is_empty_test2() {
    CharLinkedList list;
    assert(list.isEmpty());
}

void clear_test1() {
    CharLinkedList test_list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.insertAt('a', i);
    }

    test_list.clear();

    assert(test_list.isEmpty());
}

void first_correct_1() {
   CharLinkedList list;
   list.pushAtBack('a');
   list.pushAtBack('b');
    assert(list.first() == 'a');
}

void first_incorrect_1() {
    bool run_error_thrown = false;

    std::string error_message = "";

    CharLinkedList test_list;
    try {
    test_list.first();
    }
    catch (const std::runtime_error &e) {
    run_error_thrown = true;
    error_message = e.what();
    }

    assert(run_error_thrown);
    assert(error_message == "cannot get first of empty LinkedList");
}

void last_correct_1() {
    CharLinkedList list;
    list.pushAtBack('a');
    list.pushAtBack('b');
    assert(list.last() == 'b');
}

void last_incorrect_1() {
    bool run_error_thrown = false;

    std::string error_message = "";

    CharLinkedList test_list;
    try {
    test_list.last();
    }
    catch (const std::runtime_error &e) {
    run_error_thrown = true;
    error_message = e.what();
    }

    assert(run_error_thrown);
    assert(error_message == "cannot get last of empty LinkedList");
}

void element_at_correct_test1() {
    CharLinkedList list;
    for (int i = 0; i < 26; i++) {
        list.pushAtBack('a' + i);
    }
    assert(list.elementAt(3) == 'd');
}

void element_at_incorrect_test1() {
    bool range_error_thrown = false;

    std::string error_message = "";

    CharLinkedList test_list;
    try {
    test_list.elementAt(42);
    }
    catch (const std::range_error &e) {
    range_error_thrown = true;
    error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0)");
}

void string_empty() {
    CharLinkedList list;
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}

void reverse_string_empty() {
    CharLinkedList list;
    assert(list.toReverseString() == "[CharLinkedList of size 0 <<>>]");
}

void reverse_to_test1() {
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    test_list.insertAt('y', 0);

    assert(test_list.size() == 10);
    assert(test_list.elementAt(0) == 'y');
    assert(test_list.toReverseString() == 
    "[CharLinkedList of size 10 <<hgfedzcbay>>]");
}

void push_back_test1() {
    CharLinkedList list;
    for (int i = 0; i < 26; i++) {
        list.pushAtBack('a' + i);
    }
    assert(list.toString() == 
    "[CharLinkedList of size 26 <<abcdefghijklmnopqrstuvwxyz>>]");
}

void push_front_test1() {
    CharLinkedList list;
    for (int i = 0; i < 26; i++) {
        list.pushAtFront('a' + i);
    }
    assert(list.toString() == 
    "[CharLinkedList of size 26 <<zyxwvutsrqponmlkjihgfedcba>>]");
}



void insertAt_empty_correct() { 

    CharLinkedList test_list;
    test_list.insertAt('a', 0);
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');

}

void insertAt_empty_incorrect() {

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    // insertAt for out-of-range index
    test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
    // if insertAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    range_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0]");
    
}

// Tests correct insertAt for front of 1-element list.
void insertAt_front_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at front
    test_list.insertAt('b', 0);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'a');
    
}

// Tests correct insertAt for back of 1-element list.
void insertAt_back_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at back
    test_list.insertAt('b', 1);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    
}


void insertAt_many_elements() {
    
    CharLinkedList test_list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.insertAt('a', i);
    }

    assert(test_list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
    
}

// Tests insertion into front of a larger list
void insertAt_front_large_list() {
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    test_list.insertAt('y', 0);

    assert(test_list.size() == 10);
    assert(test_list.elementAt(0) == 'y');
    assert(test_list.toString() ==
    "[CharLinkedList of size 10 <<yabczdefgh>>]");

}

// Tests insertion into the back of a larger list
void insertAt_back_large_list() {

    char test_arr[10] = { 'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 10);  

    test_list.insertAt('x', 10);

    assert(test_list.size() == 11);
    assert(test_list.elementAt(10) == 'x');
    assert(test_list.toString() == 
    "[CharLinkedList of size 11 <<yabczdefghx>>]"); 

}

// Tests insertion into the middle of a larger list
void insertAt_middle_large_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.insertAt('z', 3);

    assert(test_list.size() == 9);
    assert(test_list.elementAt(3) == 'z');
    assert(test_list.toString() =="[CharLinkedList of size 9 <<abczdefgh>>]");

}

// Tests out-of-range insertion for a non-empty list.
void insertAt_nonempty_incorrect() {
   
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8]");
    
}



void insertOrder_front_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at front
    test_list.insertInOrder('b');

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');

}


void insertOrder_empty_list() {
    
    // initialize 1-element list
    CharLinkedList test_list;

    // insert at front
    test_list.insertInOrder('b');

    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'b');
}


void insertOrder_back_large_list() {
    char test_arr[8] = { 'y', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.insertInOrder('a');

    assert(test_list.size() == 9);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.toString() == "[CharLinkedList of size 9 <<aybcdefgh>>]");

}

void insertOrder_middle_large_list() {

    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);  

    test_list.insertInOrder('y');
    cout << test_list.toString() << endl;

    assert(test_list.size() == 10);
    assert(test_list.elementAt(3) == 'y');
    assert(test_list.toString() == 
    "[CharLinkedList of size 10 <<abcyzdefgh>>]"); 

}

void pop_front_correct() { 

    CharLinkedList test_list;
    test_list.insertAt('a', 0);
    test_list.insertAt('b', 1);
    test_list.popFromFront();
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'b');

}


void pop_front_incorrect() {

    bool run_error_thrown = false;

    std::string error_message = "";

    CharLinkedList test_list;
    try {
    test_list.popFromFront();
    }
    catch (const std::runtime_error &e) {
    run_error_thrown = true;
    error_message = e.what();
    }

    assert(run_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
    
}

void pop_back_correct() { 

    CharLinkedList test_list;
    test_list.insertAt('b', 0);
    test_list.insertAt('a', 1);
    test_list.insertAt('c', 1);
    test_list.insertAt('a', 1);
    test_list.popFromBack();
    assert(test_list.size() == 3);
    assert(test_list.elementAt(2) == 'c');

}

void pop_back_incorrect() {

    bool run_error_thrown = false;

    std::string error_message = "";

    CharLinkedList test_list;
    try {

    test_list.popFromBack();
    }
    catch (const std::runtime_error &e) {
    run_error_thrown = true;
    error_message = e.what();
    }

    assert(run_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

void remove_front() {
    CharLinkedList list;
    for (int i = 0; i < 26; i++) {
        list.pushAtBack('a' + i);
    }
    list.removeAt(0);
    assert(list.size() == 25);
    assert(list.toString() == 
    "[CharLinkedList of size 25 <<bcdefghijklmnopqrstuvwxyz>>]");
}

void remove_back() {
    CharLinkedList list;
    for (int i = 0; i < 26; i++) {
        list.pushAtBack('a' + i);
    }
    list.removeAt(25);
    assert(list.size() == 25);
    assert(list.toString() == 
    "[CharLinkedList of size 25 <<abcdefghijklmnopqrstuvwxy>>]");
}

void remove_middle() {
    CharLinkedList list;
    for (int i = 0; i < 26; i++) {
        list.pushAtBack('a' + i);
    }
    list.removeAt(10);
    assert(list.size() == 25);
    assert(list.toString() == 
    "[CharLinkedList of size 25 <<abcdefghijlmnopqrstuvwxyz>>]");
}

void remove_one() {
    CharLinkedList list('a');
    list.removeAt(0);
    assert(list.size() == 0);
    assert(list.isEmpty());
    assert(list.toString() == 
    "[CharLinkedList of size 0 <<>>]");
}

void remove_empty() {
    bool range_error_thrown = false;

    std::string error_message = "";

    CharLinkedList test_list;
    try {

    test_list.removeAt(0);
    }
    catch (const std::range_error &e) {
    range_error_thrown = true;
    error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (0) not in range [0..0)");
}

void remove_at_correct() { 

    CharLinkedList test_list;
    test_list.insertAt('b', 0);
    test_list.insertAt('a', 1);
    test_list.insertAt('c', 1);
    test_list.insertAt('a', 1);
    test_list.removeAt(2);
    assert(test_list.size() == 3);
    assert(test_list.elementAt(2) == 'a');

}

void remove_at_incorrect() {

    bool range_error_thrown = false;

    std::string error_message = "";

    CharLinkedList test_list;
    try {

    test_list.removeAt(42);
    }
    catch (const std::range_error &e) {
    range_error_thrown = true;
    error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0)");
}


void replaceAt_singleton_correct() { 

    CharLinkedList test_list('b');
    test_list.replaceAt('a', 0);
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');

}


void replaceAt_empty_incorrect() {

    bool range_error_thrown = false;

    std::string error_message = "";

    CharLinkedList test_list;
    try {
    test_list.replaceAt('a', 42);
    }
    catch (const std::range_error &e) {
    range_error_thrown = true;
    error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0)");
    
}



void replaceAt_many_elements() {
    
    CharLinkedList test_list;

    for (int i = 0; i < 1000; i++) {
        test_list.insertAt('a', i);
    }

    assert(test_list.size() == 1000);
    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }

    for (int i = 0; i < 1000; i++) {
        test_list.replaceAt('b', i);
    }

    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'b');
    }
    
}

void replaceAt_front_large_list() {
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    test_list.replaceAt('y', 0);

    assert(test_list.size() == 9);
    assert(test_list.elementAt(0) == 'y');
    assert(test_list.toString() == "[CharLinkedList of size 9 <<ybczdefgh>>]");

}

void replaceAt_back_large_list() {

    char test_arr[10] = { 'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 10);  

    test_list.replaceAt('x', 9);

    assert(test_list.size() == 10);
    assert(test_list.elementAt(9) == 'x');
    assert(test_list.toString() == 
    "[CharLinkedList of size 10 <<yabczdefgx>>]"); 

}

void replaceAt_middle_large_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.replaceAt('z', 3);

    assert(test_list.size() == 8);
    assert(test_list.elementAt(3) == 'z');
    assert(test_list.toString() =="[CharLinkedList of size 8 <<abczefgh>>]");

}

void replaceAt_nonempty_incorrect() {
   
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    bool range_error_thrown = false;

    std::string error_message = "";

    try {
        test_list.replaceAt('a', 42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8)");
    
}

void concatenate_test1() {
    CharLinkedList list;
    CharLinkedList list2;
    for (int i = 0; i < 26; i++) {
        list.pushAtBack('a' + i);
    }
    for (int i = 0; i < 26; i++) {
        list2.pushAtBack('A' + i);
    }
    list.concatenate(&list2);
    assert(list.size() == 52);
    assert(list.toString() == 
    "[CharLinkedList of size 52" 
    " <<abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ>>]");
}

void concatenate_test2() {
    CharLinkedList list;
    CharLinkedList list2;
    for (int i = 0; i < 26; i++) {
        list.pushAtBack('a' + i);
    }
    for (int i = 0; i < 26; i++) {
        list2.pushAtBack('A' + i);
    }
    list2.concatenate(&list);
    assert(list2.size() == 52);
    assert(list2.toString() ==
     "[CharLinkedList of size 52" 
     " <<ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz>>]");
}

void concatenate_test_empty1() {
    CharLinkedList list;
    CharLinkedList list2;
    for (int i = 0; i < 26; i++) {
        list.pushAtBack('a' + i);
    }
    list2.concatenate(&list);
    assert(list2.size() == 26);
    assert(list2.toString() ==
    "[CharLinkedList of size 26 <<abcdefghijklmnopqrstuvwxyz>>]");
}

void concatenate_test_empty2() {
    CharLinkedList list;
    CharLinkedList list2;
    for (int i = 0; i < 26; i++) {
        list2.pushAtBack('a' + i);
    }
    list.concatenate(&list2);
    assert(list.size() == 26);
    assert(list.toString() == 
    "[CharLinkedList of size 26 <<abcdefghijklmnopqrstuvwxyz>>]");
}

void concatenate_test_empty3() {
    CharLinkedList list;
    CharLinkedList list2;
    for (int i = 0; i < 26; i++) {
        list2.pushAtBack('a' + i);
    }
    list2.concatenate(&list);
    assert(list2.size() == 26);
    assert(list2.toString() == 
    "[CharLinkedList of size 26 <<abcdefghijklmnopqrstuvwxyz>>]");
}

void concatenate_test_empty4() {
    CharLinkedList list;
    CharLinkedList list2;

    list2.concatenate(&list);
    assert(list2.size() == 0);
    assert(list2.toString() == "[CharLinkedList of size 0 <<>>]");
}

void concatenate_test_itself() {
    CharLinkedList list;
    for (int i = 0; i < 26; i++) {
        list.pushAtBack('a' + i);
    }
    list.concatenate(&list);
    assert(list.size() == 52);
    assert(list.toString() == 
    "[CharLinkedList of size 52 " 
    "<<abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyz>>]");
}

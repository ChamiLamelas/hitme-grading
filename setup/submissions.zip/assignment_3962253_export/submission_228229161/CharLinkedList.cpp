/*
 *  CharLinkedList.cpp
 *  Allison Zhang
 *  2/1/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Implementation for a doubly linked list of chars 
 *
 */

#include "CharLinkedList.h"

#include <sstream>
#include <iostream>
#include <stdexcept>
#include <stdlib.h>

using namespace std;

/*
 * name: CharLinkedList
 * purpose: Constructor
 * arguments: N/A
 * returns: N/A
 * effects: Makes a LinkedList with 0 nodes
 */
CharLinkedList::CharLinkedList() {
}

/*
 * name: CharLinkedList
 * purpose: Constructor
 * arguments: One char c
 * returns: N/A
 * effects: Makes a LinkedList with 1 node that contains c
 */
CharLinkedList::CharLinkedList(char c) {    
    Node *newNode = new Node();
    newNode->c = c;
    numNodes = 1;
    head = newNode;
    tail = newNode;
}

/*
 * name: CharLinkedList      
 * purpose: Constructor
 * arguments: One array of chars, and one int that represents the size
 * returns: N/A
 * effects: Makes a LinkedList with the elements of the given array as the 
 *          elements of the LinkedList. The size of the array is used as the 
 *          number of nodes of the LinkedList.
 */
CharLinkedList::CharLinkedList(char arr[], int size) {
    for (int i = 0; i < size; i++) {
        pushAtBack(arr[i]);
    }
}

/*
 * name: CharLinkedList        
 * purpose: Constructor  
 * arguments: One CharLinkedList object
 * returns: N/A
 * effects: Makes a deep copy of the given CharLinkedList  
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other) {
    copyList(other);
}

/*
 * name: ~CharLinkedList       
 * purpose: Destructor
 * arguments: N/A
 * returns: N/A  
 * effects: Deletes the CharLinkedList by freeing up associated memory   
 */
CharLinkedList::~CharLinkedList() {
    deleteList(head);
}

/*
 * name: &operator=      
 * purpose: Makes a deep copy when the "=" operator is used when initializing
 *          a new LinkedList
 * arguments: One CharLinkedList object
 * returns: The deep copy of the given CharLinkedList
 * effects: Makes a deep copy, unless the indicated LinkedList is itself.
 */
CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other) {
    if (this == &other) {
        return *this;
    } else {
        copyList(other);
        return *this;
    }
}

/*
 * name: isEmpty    
 * purpose: Determines if the LinkedList is empty  
 * arguments: N/A
 * returns: If the LinkedList is empty
 * effects: N/A
 */
bool CharLinkedList::isEmpty() const {
    return head == nullptr;
}

/*
 * name: clear     
 * purpose: Clears a LinkedList  
 * arguments: N/A
 * returns: N/A
 * effects: Sets numNodes to 0 and sets the head and tail pointers to nullptr.
 */
void CharLinkedList::clear() {
    deleteList(head);
    head = nullptr;
    tail = nullptr;
    numNodes = 0;
}

/*
 * name: size     
 * purpose: Determines size of a LinkedList  
 * arguments: N/A
 * returns: numNodes of LinkedList
 * effects: N/A
 */
int CharLinkedList::size() const {
    return numNodes;
}

/*
 * name: first     
 * purpose: Determines the first element of a Non-Empty LinkedList  
 * arguments: N/A
 * returns: The first element of the LinkedList
 * effects: If the LinkedList is empty, an error is thrown
 */
char CharLinkedList::first() const {
    if (isEmpty()) {
        error("emptyFir");
    }
    return head->c;
}

/*
 * name: last    
 * purpose: Determines the last element of a Non-Empty LinkedList  
 * arguments: N/A
 * returns: The last element of the LinkedList
 * effects: If the LinkedList is empty, an error is thrown
 */
char CharLinkedList::last() const {
     if (isEmpty()) {
        error("emptyLa");
    }
    return tail->c;
}

/*
 * name: elementAt     
 * purpose: Determines the element at the given index  
 * arguments: An int representing the desired index 
 * returns: The element at the index(if its valid)   
 * effects: If the index is not valid, an error is thrown
 */
char CharLinkedList::elementAt(int index) const {
    if (index < 0 or index >= numNodes) 
        error("excl", index);
    Node *element = findNode(index, head);
    return element->c;
}

/*
 * name: toString     
 * purpose: Prints out the LinkedList in string form  
 * arguments: N/A
 * returns: The LinkedList in string form and the number of nodes
 * effects: N/A
 */
std::string CharLinkedList::toString() const {
    Node *curr = head;
    string res = "";
    while (curr != nullptr) {
        res = res + curr->c;
        curr = curr->next;
    }
    return "[CharLinkedList of size " + to_string(numNodes) 
            + " <<" + res + ">>]";
}

/*
 * name: toReverseString      
 * purpose: Prints out the LinkedList in string form but reverse order
 * arguments: N/A
 * returns: The LinkedList in string form in reverse order and the number of 
 *          nodes
 * effects: N/A
 */
std::string CharLinkedList::toReverseString() const {
    Node *curr = tail;
    string res = "";
    while (curr != nullptr) {
        res = res + curr->c;
        curr = curr->prev;
    }
    return "[CharLinkedList of size " + to_string(numNodes) 
            + " <<" + res + ">>]";
}

/*
 * name: pushAtBack   
 * purpose: Inserts a char at the tail of the LinkedList 
 * arguments: One char representing the desired element
 * returns: N/A
 * effects: The number of nodes is increased by 1  
 */
void CharLinkedList::pushAtBack(char c) {
    Node *newNode = new Node();
    newNode->c = c;
    
    /* Add first node */
    if (head == nullptr) {
        head = newNode;
        tail = newNode;
    } else {
        /* Add every other node to the head */
        tail->next = newNode;
        newNode->prev = tail;
        tail = newNode;
    }

    numNodes++;
}


/*
 * name: pushAtFront    
 * purpose: Inserts a char at the head of the LinkedList 
 * arguments: One char representing the desired element
 * returns: N/A
 * effects: The number of nodes is increased by 1  
 */
void CharLinkedList::pushAtFront(char c) {
    Node *newNode = new Node();
    newNode->c = c;
    
    /* Add first node */
    if (head == nullptr) {
        head = newNode;
        tail = newNode;
    } else {
        /* Add every other node to the head */
        head->prev = newNode;
        newNode->next = head;
        head = newNode;
    }

    numNodes++;
}

/*
 * name: insertAt      
 * purpose: Inserts a char at a desired index(has to be valid)
 * arguments: One char representing the desired element and an int as the index
 * returns: N/A
 * effects: The number of nodes is increased by 1 and an error is thrown if 
 *          the index isn't valid. 
 */
void CharLinkedList::insertAt(char c, int index) {
    // If from the front or back, use pushAtFront/Back functions
    if (index < 0 or index > numNodes) {
        error("incl", index);
    } else if (index == 0) {
        pushAtFront(c);
    } else if (index == numNodes) {
        pushAtBack(c);
    } else {
        Node *newNode = new Node();
        newNode->c = c;
        Node *prev;
        Node *curr = head; 
        for (int i = 1; i <= index; i++) {
            curr = curr->next;
        }
        prev = curr->prev;
        newNode->next = curr;
        newNode->prev = prev;
        curr->prev = newNode;
        prev->next = newNode;
        numNodes++;
    }
}

/*
 * name: insertInOrder     
 * purpose: Inserts a char at the first ordered spot
 * arguments: One char representing the desired element
 * returns: N/A
 * effects: The number of nodes is increased by 1 and the element is placed 
 *          where it is greater than the element before it, and smaller than 
 *          the element after it
 */
void CharLinkedList::insertInOrder(char c) {
    Node *curr = head;
    int index = 0;
    while (curr != nullptr and c > curr->c) {
       curr = curr->next;
       index++; 
    }
    insertAt(c, index);
}

/*
 * name: popFromhead      
 * purpose: Removes an element from the head of the LinkedList  
 * arguments: N/A
 * returns: N/A   
 * effects: Removes an element from the head of the LinkedList, the number of 
 *          nodes decreased by 1, and an error is thrown if the LinkedList is 
 *          empty   
 */
void CharLinkedList::popFromFront() {
    if (isEmpty()) {
        error("pop");
    } else if (size() == 1) {
        delete head;
        head = nullptr;
        tail = nullptr;
        numNodes--;
    } else {
        Node *temp = head->next;
        temp->prev = nullptr;
        delete head;
        head = temp;
        numNodes--;
    }
}

/*
 * name: popFromtail     
 * purpose: Removes an element from the tail of the LinkedList  
 * arguments: N/A
 * returns: N/A   
 * effects: Removes an element from the tail of the LinkedList, the number of 
 *          nodes is decreased by 1, and an error is thrown if the LinkedList 
 *          is empty   
 */
void CharLinkedList::popFromBack() {
    if (isEmpty()) {
        error("pop");
    } else if (size() == 1) {
        delete head;
        head = nullptr;
        tail = nullptr;
        numNodes--;
    } else {
        Node *temp = tail->prev;
        temp->next = nullptr;
        delete tail;
        tail = temp;
        numNodes--;
    }
}

/*
 * name: removeAt     
 * purpose: Removes an element from an indicated index
 * arguments: An int as the index
 * returns: N/A   
 * effects: Removes an element from index, the number of nodes is decreased by
 *          1, and an error is thrown if the index is invalid  
 */
void CharLinkedList::removeAt(int index) {
    // If from the front or back, use popFromFront/Back functions
    if (index < 0 or index >= numNodes) {
        error("excl", index);
    } else if (index == 0) {
        popFromFront();
    } else if (index == numNodes - 1) {
        popFromBack();
    } else {
        Node *prev;
        Node *curr = head; 
        Node *next;
        for (int i = 1; i <= index; i++) {
            curr = curr->next;
        }
        prev = curr->prev;
        next = curr->next;
        prev->next = next;
        next->prev = prev;
        delete curr;
        numNodes--;
    }
}

/*
 * name: replaceAt      
 * purpose: Replaces an element at the index with an indicated char 
 * arguments: One char and an int as the index
 * returns: N/A  
 * effects: Replaces an element at the index with an indicated char, if the 
 *          index is invalid, an error is thrown, numNodes is increased by 1
 */
void CharLinkedList::replaceAt(char c, int index) {
    if (index >= 0 and index < numNodes) {
        Node *replace = findNode(index, head);
        replace->c = c;
    } else {
        error("excl", index);
    }

}

/*
 * name: concatenate     
 * purpose: Concatenates an LinkedList onto another.  
 * arguments: One CharLinkedList object
 * returns: N/A
 * effects: Appends the given LinkedList onto the end of the current LinkedList
 */
void CharLinkedList::concatenate(CharLinkedList *other) {
     if (other == this) {
        int temp = numNodes;
        for (int i = 0; i < temp; i++) {
            pushAtBack(elementAt(i));
        }
    } else {
        for (int i = 0; i < other->size(); i++) {
            pushAtBack(other->elementAt(i)); 
        }
    }
}

/*
 * name: findNode   
 * purpose: Finds a node recursively by an indicated index
 * arguments: One int representing index, and a pointer to the starting node
 * returns: A pointer to the desired node
 * effects: N/A
 */
CharLinkedList::Node *CharLinkedList::findNode(int index, Node *head) const {
    if (index == 0 or head == nullptr) {
        return head;
    } else {
        return findNode(index - 1, head->next);
    }
} 


/*
 * name: copyList    
 * purpose: Makes a deep copy of an indicated CharLinkedList
 * arguments: One CharLinkedList object
 * returns: N/A
 * effects: Empties memory before copying.
 */
void CharLinkedList::copyList(const CharLinkedList &other) {
    //  Delete, then check if other is empty, if non-empty copy using multiple
    //  pointers
    deleteList(head);
    if (other.isEmpty()) { 
        head = nullptr; 
        tail = nullptr;
        numNodes = 0;
    } else {
        Node *prevNew = nullptr;
        Node *currOrig = other.head;
        numNodes = other.numNodes;
        while (currOrig != nullptr) {
            Node *newNode = new Node();
            newNode->c = currOrig->c;
            if (prevNew == nullptr) {
                prevNew = newNode;
                head = newNode;
            } else {
                newNode->prev = prevNew;
                prevNew->next = newNode;
                prevNew = newNode;
            }
            currOrig = currOrig->next;
        }
        tail = prevNew;
    }
}


/*
 * name: deleteList
 * purpose: Deletes the list
 * arguments: One pointer to a node
 * returns: N/A
 * effects: Deletes all the nodes of the LinkedList
 */
void CharLinkedList::deleteList(Node *curr) {
    if (curr == nullptr) {
        return;
    }

    deleteList(curr->next);

    delete curr;
}

/*
 * name: error
 * purpose: run errors with specific flags
 * arguments: one string that represents the flag, and one int(optional) that
 *            represents the index
 * returns: N/A
 * effects: Exits program with indicated error
 */
void CharLinkedList::error(string flag, int index) const {
    if (flag == "pop") 
        throw runtime_error("cannot pop from empty LinkedList");

    if (flag == "incl") {
        throw range_error("index (" + to_string(index) + ") not in range [0.."
        + to_string(numNodes) + "]");
    }
    if (flag == "excl") {
        throw range_error("index (" + to_string(index) + ") not in range [0.." 
        + to_string(numNodes) + ")");
    }
    if (flag == "emptyFir") 
        throw runtime_error("cannot get first of empty LinkedList");
    
    if (flag == "emptyLa")
        throw runtime_error("cannot get last of empty LinkedList");

    throw runtime_error("Unknown Error");
}


  

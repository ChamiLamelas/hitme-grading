/*
 *  CharLinkedList.h
 *  Allison Zhang
 *  2/1/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Header file for a doubly linked list of chars
 *
 */

#ifndef CHAR_LINKED_LIST_H
#include <string>
#include <sstream>
#include <iostream>
#include <stdexcept>
#include <stdlib.h>
#define CHAR_LINKED_LIST_H

using namespace std;

class CharLinkedList {
     public:
        CharLinkedList();
        CharLinkedList(char c);
        CharLinkedList(char arr[], int size);
        CharLinkedList(const CharLinkedList &other);
        ~CharLinkedList();   
        CharLinkedList &operator=(const CharLinkedList &other);

        
        bool isEmpty() const;
        void clear();
        int size() const;
        char first() const;
        char last() const;
        char elementAt(int index) const;
        std::string toString() const;
        std::string toReverseString() const;
        void pushAtBack(char c);
        void pushAtFront(char c);
        void insertAt(char c, int index);
        void insertInOrder(char c);
        void popFromFront();
        void popFromBack();
        void removeAt(int index);
        void replaceAt(char c, int index);
        void concatenate(CharLinkedList *other);



    private:
        struct Node {
            char c;
            Node *next = nullptr;
            Node *prev = nullptr;
        };
        Node *head = nullptr;
        Node *tail = nullptr;
        Node *findNode(int index, Node *curr) const;
        void copyList(const CharLinkedList &other);
        void deleteList(Node *curr);
        int numNodes = 0;
        void error(string flag, int index = 1) const;   
};

#endif

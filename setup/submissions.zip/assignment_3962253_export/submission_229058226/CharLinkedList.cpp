/*
 *  CharLinkedList.cpp
 *  Shivani Parekh
 *  2/3/24
 *
 *  CS 15 HW 2 LinkedLists
 *
 *  Function definitions for the CharLinkedList class
 *
 */

#include "CharLinkedList.h"
#include <sstream>
#include <iostream>

using namespace std;

/*
 * name:      CharLinkedList default constructor
 * purpose:   initialize an empty CharLinkedList
 * arguments: none
 * returns:   none
 * effects:   front and back pointer are nullptrs, numItems = 0
 */
 CharLinkedList::CharLinkedList() {
    front = nullptr;
    back = nullptr;
    numItems = 0;
 }

 /*
 * name:      CharArrayList second constructor
 * purpose:   initialize a CharLinkedList with 1 element
 * arguments: character
 * returns:   none
 * effects:   numItems = 1, front and back pointers are updated to node
 */
CharLinkedList::CharLinkedList(char c) {
    Node *newNode = new Node;
    newNode->data = c;
    newNode->prev = nullptr;
    newNode->next = nullptr;
    front = newNode;
    back = newNode;
    numItems = 1;
}

 /*
 * name:      CharArrayList third constructor
 * purpose:   initialize a CharLinkedList with the characters in a given array
 * arguments: character array, size of array
 * returns:   none
 * effects:   numItems = number of characters in given array, front, back, prev
 *            pointers are updated
 */
CharLinkedList::CharLinkedList(char arr[], int size) {
    front = nullptr;
    back = nullptr;
    numItems = 0;
    for (int i = 0; i < size; i++) {
        pushAtBack(arr[i]);
    }
}

/*
 * name:      CharLinkedList destructor
 * purpose:   free memory associated with the CharLinkedList
 * arguments: none
 * returns:   none
 * effects:   frees memory allocated by CharLinkedList instances
 */
CharLinkedList::~CharLinkedList() {
    destructorHelper(front);
}

void CharLinkedList::destructorHelper(Node *curr) {
    if (curr == nullptr) { //if list is empty
        return;
    }
    if (curr->next == nullptr) { //if Node is only element in list
        delete curr;
    }
    else { //otherwise recursively delete Nodes
        if (curr->next != nullptr) {
            destructorHelper(curr->next);
        }
        delete curr;
    }
}

/*
 * name:      isEmpty
 * purpose:   determine if the CharLinkedList has no elements
 * arguments: none
 * returns:   true if empty, false otherwise
 * effects:   none
 */
bool CharLinkedList::isEmpty() const {
    if (numItems == 0) {
        return true;
    }
    return false;
}

/*
 * name:      size
 * purpose:   determine the number of items in the CharLinkedList
 * arguments: none
 * returns:   number of elements currently stored in the CharLinkedList
 * effects:   none
 */
int CharLinkedList::size() const {
    return numItems;
}

/*
 * name:      first
 * purpose:   determine the first element in the CharLinkedList
 * arguments: none
 * returns:   first element in the CharLinkedList
 * effects:   none
 */
char CharLinkedList::first() const {
    if (isEmpty()) {
        throw runtime_error("cannot get first of empty LinkedList");
    }
    return front->data;
}

/*
 * name:      last
 * purpose:   determine the last element in the CharLinkedList
 * arguments: none
 * returns:   last element in the CharLinkedList
 * effects:   none
 */
char CharLinkedList::last() const {
    if (isEmpty()) {
        throw runtime_error("cannot get last of empty LinkedList");
    }
    return back->data;
}

/*
 * name:      elementAt
 * purpose:   find the character at a given index
 * arguments: the index to find the character at
 * returns:   the character at that index
 * effects:   none
 */
char CharLinkedList::elementAt(int index) const {
    
}

/*
 * name:      pushAtBack
 * purpose:   insert a given element to the back of the CharLinkedList
 * arguments: a character to add to the back of the CharLinkedList
 * returns:   none
 * effects:   increases CharLinkedList num characters by 1, updates last element
 */
void CharLinkedList::pushAtBack(char c) {
    Node *newNode = new Node;
    if (isEmpty()) { //if there are no Nodes, intialize element for a new one
        front = newNode;
        newNode->prev = nullptr;
        newNode->next = nullptr;
    }
    else {
        back->next = newNode;
    }
    numItems++;
    newNode->data = c;
    newNode->prev = back;
    newNode->next = nullptr;
    back = newNode;
}
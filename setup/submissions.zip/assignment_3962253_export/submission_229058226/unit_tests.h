/*
 *  unit_tests.h
 *  Shivani Parekh
 *  2/3/24
 *
 *  CS 15 HW 2 LinkedLists
 *  
 *  Testing file for the CharLinkedList class that uses the unit_test framework
 *
 */

#include "CharLinkedList.h"
#include <cassert>
#include <iostream>
#include <string>

using namespace std;

// constructor test 0
// Make sure default constructor is created
void constructor_test_0() {
    CharLinkedList list;
}

// constructor test 1
// Make sure default constructor has 0 elements upon construction
void constructor_test_1() {
    CharLinkedList list;
    assert(list.size() == 0);
}

// constructor test 2
// Make sure second constructor has 1 element upon construction
void constructor_test_2() {
    CharLinkedList list('a');
    assert(list.size() == 1);
}

// constructor test 3
// Make sure third constructor has given # of elements upon construction
void constructor_test_3() {
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList list(arr, 3);
    assert(list.size() == 3);
}

// push at back test 0
// Make sure element is pushed at back for empty list
void pushAtBack_test_0() {
    CharLinkedList list;
    list.pushAtBack('a');
    assert(list.size() == 1);
}

// push at back test 1
// Make sure element is pushed at back for non empty list
void pushAtBack_test_1() {
    CharLinkedList list('a');
    list.pushAtBack('b');
    assert(list.size() == 2);
}

// is empty test 0
// Make sure list is reported as empty accurately
void isEmpty_test_0() {
    CharLinkedList list;
    assert(list.isEmpty() == true);
}

// is empty test 1
// Make sure list is reported as empty accurately
void isEmpty_test_1() {
    CharLinkedList list('a');
    assert(list.isEmpty() == false);
}

// first test 0
// Make sure first item in list is reported accurately
void first_test_0() {
    CharLinkedList list('a');
    assert(list.first() == 'a');
}

// first test 1
// Make sure first item in list is reported accurately
void first_test_1() {
    bool runtime_error_thrown = false;
    std::string error_message = "";
    CharLinkedList list;
    try {
        list.first();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "cannot get first of empty LinkedList");
}

// last test 0
// Make sure last item in list is reported accurately
void last_test_0() {
    CharLinkedList list('a');
    assert(list.last() == 'a');
}

// last test 1
// Make sure last item in list is reported accurately
void last_test_1() {
    bool runtime_error_thrown = false;
    std::string error_message = "";
    CharLinkedList list;
    try {
        list.last();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "cannot get last of empty LinkedList");
}
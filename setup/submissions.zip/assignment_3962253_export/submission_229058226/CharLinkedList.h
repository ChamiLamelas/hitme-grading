/*
 *  CharLinkedList.h
 *  Shivani Parekh
 *  2/3/24
 *
 *  CS 15 HW 2 LinkedLists
 *
 *  Class declaration for a CharLinkedList
 *
 */

#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H

#include <string>

class CharLinkedList {
public:
    CharLinkedList();
    CharLinkedList(char c);
    CharLinkedList(char arr[], int size);
    ~CharLinkedList();

    bool isEmpty() const;
    int size() const;
    char first() const;
    char last() const;
    char elementAt(int index) const;
    void pushAtBack(char c);

private:
    struct Node {
        char data;
        Node *prev;
        Node *next;
    };

    Node *front;
    Node *back;
    int numItems;

    void destructorHelper(Node *curr);
};

#endif

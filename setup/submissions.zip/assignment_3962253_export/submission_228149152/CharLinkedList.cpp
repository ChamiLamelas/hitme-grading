/*
 *  CharLinkedList.cpp
 *  Rebecca Lee
 *  02/02/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Purpose: Implements the CharLinkedList class
 *
 */

#include "CharLinkedList.h"
#include <string>
#include <stdexcept>
#include <iostream>

using namespace std;

//constructor methods

//CharLinkedList (default constructor)
//Purpose: constructs a new empty CharLinkedList
//Parameters: none
//Return value: none
//Other: sets front and end to nullptr and listSize to 0
CharLinkedList::CharLinkedList() {
    //initialize linked list variables
    front = nullptr;
    end = nullptr;
    listSize = 0;
}

//CharLinkedList (one-char constructor)
//Purpose: constructs a new CharLinkedList with one char in it
//Parameters: char to be put into the new CharLinkedList
//Return value: none
//Other: creates Node to hold char and sets it as front and end, sets listSize 0
CharLinkedList::CharLinkedList(char c) {
    //create new node
    Node *newNode = new Node{c, nullptr, nullptr};

    //initialize linked list variables
    front = newNode;
    end = newNode;
    listSize = 1;
}

//CharLinkedList (array constructor)
//Purpose: constructs a new linked list with values from an array and a size
//         equal to the length of that array
//Parameters: an array of chars to be put into the linked list, an int size of
//            that array
//Return value: none
//Other: listSize is added to by the pushAtBack function to be equal to the size
//       of the array being added from, elements from arr are copied into list
CharLinkedList::CharLinkedList(char arr[], int size) {
    //initialize linked list variable
    listSize = 0;

    //create new nodes
    for (int i = 0; i < size; i++) {
        pushAtBack(arr[i]);
    }
}

//CharLinkedList (copy constructor)
//Purpose: constructs a new linked list with values from another linked list
//Parameters: address of other linked list whose values will be copied to
//            create a new linked list
//Return value: none
//Other: listSize is added to by the pushAtBack function to be equal to the size
//       of the array being added from, elements from other list are copied
CharLinkedList::CharLinkedList(const CharLinkedList &other) {
    //initialize linked list variable
    listSize = 0;

    //create new nodes
    for (int i = 0; i < other.size(); i++) {
        pushAtBack(other.elementAt(i));
    }
}

//destructor methods

//deleteNodes
//Purpose: deletes nodes to free allocated memory
//Parameters: pointer to starter node that starts deletion chain
//Return value: none
//Other: deletes nodes recursively
void CharLinkedList::deleteNodes(Node *f) {
    if (f == nullptr) {
        return;
    }
    else {
        deleteNodes(f->next);
        delete f;
        listSize--;
    }
}

//~CharLinkedList
//Purpose: calls the deleteNodes function when a list is no longer used
//Parameters: none
//Return value: none
//Other: deletes a linked list
CharLinkedList::~CharLinkedList() {
    if (listSize > 0) {
        deleteNodes(front);
    }
}

//manipulation methods

//operator=
//Purpose: overloads the = operator to use it to copy linked lists from one
//         to another
//Parameters: address of a linked list to copy
//Return value: a linked list with the attributes of the inputted other
//              linked list
//Other: listSize changes to equal the other linked list's and elemenets from
//       other linked list are copied to linked list
CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other) {
    if (this == &other) {
        return *this;
    }
    else {
        this->clear();
        for (int i = 0; i < other.size(); i++) {
            pushAtBack(other.elementAt(i));
        }
        return *this;
    }
}

//clear
//Purpose: to remove all elements from a linked list
//Parameters: none
//Return value: none
//Other: deletes nodes from list and sets front and end to nullptr
void CharLinkedList::clear() {
    if (listSize > 0) {
        deleteNodes(front);
    }
    front = nullptr;
    end = nullptr;
}

//pushAtBack
//Purpose: adds the inputted character to the end of a linked list
//Parameters: char c character to be inputted into linked list
//Return value: none
//Other: increases listSize to hold extra char, adds that char to end of list
void CharLinkedList::pushAtBack(char c) {
    
    //set new node variables
    if (listSize == 0) {
        Node *newNode = new Node{c, nullptr, nullptr};
        front = newNode;
        end = newNode;
    }
    else {
        Node *newNode = new Node{c, nullptr, end};
        end->next = newNode;
        end = newNode;
    }
    listSize++;
}

//pushAtFront
//Purpose: adds the inputted character to the front of a linked list
//Parameters: char c character to be inputted into linked list
//Return value: none
//Other: increases listSize to hold extra char, adds that char to front of list
void CharLinkedList::pushAtFront(char c) {
    if (listSize == 0) {
        Node *newNode = new Node{c, nullptr, nullptr};
        front = newNode;
        end = newNode;
    }
    else {
        Node *newNode = new Node{c, front, nullptr};
        front->prev = newNode;
        front = newNode;
        
    }
    listSize++;
}

//insertAt
//Purpose: inserts inputted char c at inputted index index in linked list
//Parameters: none
//Return value: none
//Other: changes link pointers of adjacent nodes to point to new node, increases
//       listSize, may throw range error if index is not in bounds
void CharLinkedList::insertAt(char c, int index) {
    if (index > listSize or index < 0) {
        throw range_error("index (" + std::to_string(index) + 
            ") not in range [0.." + std::to_string(listSize) + ']');
    }
    else {
        Node *curr = front;
        if (listSize == 0 or index == 0) {
            pushAtFront(c);
        }
        else if (index == listSize) {
            pushAtBack(c);            
        }
        else {
            for (int i = 0; i < index - 1; i++) {
                curr = curr->next;
            }
            Node *before = curr;
            Node *after = curr->next;
            Node *newNode = new Node{c, after, before};
            before->next = newNode;
            after->prev = newNode;
            listSize++;
        } 
    }
}

//insertInOrder
//Purpose: inserts inputted char c in order of ASCII code in ascending list
//Parameters: char c to be inserted into ascending sorted list
//Return value: none
//Other: changes link pointers of adjacent nodes to point to new node, increases
//       listSize, may throw range error if index is not in bounds
void CharLinkedList::insertInOrder(char c) {
    bool inserted = false;
    Node *curr = front;
    for (int i = 0; i < listSize; i++) {
        if (c <= curr->data) {
            insertAt(c, i);
            inserted = true;
            return;
        }
        else {
            curr = curr->next;
        }
    }
    if (not(inserted)) {
        insertAt(c, listSize);
    }
}

//popFromFront
//Purpose: removes char element from front of linked list
//Parameters: none
//Return value: none
//Other: decreases listSize, may throw runtime_error if popping from empty list,
//       changes front pointer to the new front node
void CharLinkedList::popFromFront() {
    if (listSize == 0) {
        throw runtime_error("cannot pop from empty LinkedList");
    }
    else if (listSize == 1) {
        delete front;
    }
    else {
        Node *curr = front->next;
        curr->prev = nullptr;
        delete front;
        front = curr;
    }
    listSize--;
}

//popFromBack
//Purpose: removes char element from back of linked list
//Parameters: none
//Return value: none
//Other: decreases listSize, may throw runtime_error if popping from empty list,
//       changes end pointer to the new end node
void CharLinkedList::popFromBack() {
    if (listSize == 0) {
        throw runtime_error("cannot pop from empty LinkedList");
    }
    else if (listSize == 1) {
        delete end;
    }
    else {
        Node *curr = end->prev;
        curr->next = nullptr;
        delete end;
        end = curr;
    }
    listSize--;
}

//removeAt
//Purpose: removes element at inputted index in linked list
//Parameters: int index to remove element from
//Return value: none
//Other: decreases listSize and changes link pointers of adjacent nodes
void CharLinkedList::removeAt(int index) {
    if (listSize == 0 or index > listSize - 1 or index < 0) {
       throw range_error("index (" + std::to_string(index) +
        ") not in range [0.." + std::to_string(listSize) + ')'); 
    }
    else {
        Node *curr = front;
        if (listSize == 1 or index == 0) {
            popFromFront();
        }
        else if (index == listSize - 1) {
            popFromBack();         
        }
        else {
            for (int i = 0; i < index; i++) {
                curr = curr->next;
            }
            Node *before = curr->prev;
            Node *after = curr->next;
            before->next = after;
            after->prev = before;
            delete curr;
            listSize--; 
        } 
    }
    
}

//replaceAtHelper
//Purpose: replaces the element of a linked list at the inputted index
//Parameters: Node pointer f representing the starting Node to start replacement
//           , char c representing the element the user wants to replace the 
//            current element with, int index of requested element
//Return value: none
//Other: replaces the element of a linked list at the inputted index with the
//       inputted char; may throw range_error if the index outside range
void CharLinkedList::replaceAtHelper(Node *f, char c, int index) {
    if (f == nullptr or index > listSize - 1 or index < 0) {
       throw range_error("index (" + std::to_string(index) + ") not in range" +
        " [0.." + std::to_string(listSize) + ')'); 
    }
    if (index == 0 or listSize == 1) {
        f->data = c;
    }
    else {
        return replaceAtHelper(f->next, c, index - 1);
    }
}

//replaceAt
//Purpose: calls the replaceAtHelper method to replace a node
//Parameters: char c representing the element the user wants to replace the 
//            current element with, int index of requested element
//Return value: none
//Other: replaces the element of a linked list at the inputted index with the
//       inputted char; may throw range_error if the index outside range
void CharLinkedList::replaceAt(char c, int index) {
    return replaceAtHelper(front, c, index);
}

//concatenate
//Purpose: adds elements from other linked list to the end of linked list
//Parameters: pointer to other linked list with elements to copy from
//Return value: none
//Other: pushes all chars from other linked list to first linked list
void CharLinkedList::concatenate(CharLinkedList *other) {
    if (other == nullptr) {
        return;
    }
    int loopSize = other->size();
    for (int i = 0; i < loopSize; i++) {
        pushAtBack(other->elementAt(i));
    }
}

//return methods

//isEmpty
//Purpose: returns whether a list is empty or not
//Parameters: none
//Return value: boolean showing whether list is empty or not
//Other: none
bool CharLinkedList::isEmpty() const {
    if (listSize == 0) {
        return true;
    }
    return false;
}

//size
//Purpose: returns the listSize variable of linked list
//Parameters: none
//Return value: integer listSize (size of linked list)
//Other: none
int CharLinkedList::size() const {
    return listSize;
}

//first
//Purpose: returns the first element in a linked list
//Parameters: none
//Return value: char first char in a linked list
//Other: may throw a runtime_error if linked list is empty
char CharLinkedList::first() const {
    if (listSize == 0) {
        throw runtime_error("cannot get first of empty LinkedList");
    }
    return front->data;
}

//last
//Purpose: returns the last element in a linked list
//Parameters: none
//Return value: char last char in a linked list
//Other: may throw a runtime_error if linked list is empty
char CharLinkedList::last() const {
    if (listSize == 0) {
        throw runtime_error("cannot get last of empty LinkedList");
    }
    return end->data;
}

//elementAtHelper
//Purpose: returns the element of a linked list at the inputted index
//Parameters: Node pointer f, representing the starting node, 
//            int index of requested element
//Return value: char element that is at the inputted index
//Other: may throw range_error if the requested index is not within range
char CharLinkedList::elementAtHelper(Node *f, int index) const {
    if (f == nullptr or index > listSize - 1 or index < 0) {
       throw range_error("index (" + std::to_string(index) + ") not in range" +
        " [0.." + std::to_string(listSize) + ')'); 
    }
    if (index == 0 or listSize == 1) {
        return f->data;
    }
    else {
        return elementAtHelper(f->next, index - 1);
    }
}

//elementAt
//Purpose: calls the elementAtHelper function to find the element at index
//Parameters: int index of requested element
//Return value: char element that is at the inputted index
//Other:
char CharLinkedList::elementAt(int index) const {
    return elementAtHelper(front, index);
}

//toString
//Purpose: returns a string showing the size of the linked list and the
//         elements inside the linked list
//Parameters: none
//Return value: string of linked list size and elements
//Other: none
std::string CharLinkedList::toString() const {
    Node *curr = front;
    std::string listString = "";
    if (listSize > 0) {
        for (int i = 0; i < listSize; i++) {
        listString += curr->data;
        curr = curr->next;
        }
    }
    
    std::string listToString = ("[CharLinkedList of size " + 
    std::to_string(listSize) + " <<" + listString + ">>]");
    return listToString;
}

//toReverseString
//Purpose: returns a string showing the size of the linked list and the
//         reversed elements inside the linked list
//Parameters: none
//Return value: string of linked list size and reversed elements
//Other: none
std::string CharLinkedList::toReverseString() const {
    Node *curr = end;
    std::string listString = "";
    if (listSize > 0) {
        for (int i = 0; i < listSize; i++) {
        listString += curr->data;
        curr = curr->prev;
        }
    }
    std::string listToString = ("[CharLinkedList of size " + 
    std::to_string(listSize) + " <<" + listString + ">>]");
    return listToString;
}

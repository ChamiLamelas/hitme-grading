
/*
 *  unit_tests.h
 *  Rebecca Lee
 *  02/02/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  Purpose: to test the functions of the CharLinkedList class
 *
 */

#include "CharLinkedList.h"
#include <cassert>
#include <string>
#include <stdexcept>
#include <iostream>

using namespace std;

/********************************************************************\
*                       CHAR LINKED LIST TESTS                        *
\********************************************************************/

/* To give an example of thorough testing, we are providing
 * the unit tests below which test the insertAt function. Notice: we have
 * tried to consider all of the different cases insertAt may be
 * called in, and we test insertAt in conjunction with other functions!
 *
 * You should emulate this approach for all functions you define.
 */

/*
 * constructor test 0
 * Make sure no fatal errors/memory leaks in the default constructor
 */
void defaultConstructorTest0() {
    CharLinkedList list;
}

/*
 * constructor test 1
 * Make sure no items exist in the list upon construction
 * Note: given the provided code, this test should fail. Fix it!
 */
void defaultConstructorTest1() {
    CharLinkedList list; // One way to invoke the default constructor.
    assert(list.size() == 0);
}

//charConstructorTest0
//tests that constructor with char parameter has size 1 and correct char element
void charConstructorTest0() {
    CharLinkedList list('a');
    assert(list.size() == 1);
    assert(list.elementAt(0) == 'a');
}

//arrConstructorTest0
//tests that constructor with array and size parameters are constructed
void arrConstructorTest0() {
    char array[] = {'P', 'e', 'p', 's', 'i'};
    CharLinkedList list(array, 5);
    assert(list.first() == 'P');
    assert(list.last() == 'i');
}

//arrConstructorTest1
//tests that elements in new list are the same as array it was inputted from
void arrConstructorTest1() {
    char array[] = {'P', 'e', 'p', 's', 'i'};
    CharLinkedList list(array, 5);
    for (int i = 0; i < 5; i++) {
        assert(array[i] == list.elementAt(i));
    }
}

//copyConstructorTest0
//tests that elements in new list are the same as list it was copied from
void copyConstructorTest0() {
    char array[] = {'P', 'e', 'p', 's', 'i'};
    CharLinkedList list(array, 5);
    CharLinkedList newList(list);
    for (int i = 0; i < 5; i++) {
        assert(newList.elementAt(i) == list.elementAt(i));
    }
}

//copyConstructorTest1
//tests that elements in new list are deep copies, not shallow copies by
//changing elements in original list and asserting that new list does not change
void copyConstructorTest1() {
    char array[] = {'P', 'e', 'p', 's', 'i'};
    CharLinkedList list(array, 5);
    CharLinkedList newList(list);
    for (int i = 0; i < 5; i++) {
        assert(newList.elementAt(i) == list.elementAt(i));
    }
    list.replaceAt('s', 4);
    assert(newList.elementAt(4) == 'i');
}

//copyConstructorTest2
//tests that newList is empty if created by copying an empty list
void copyConstructorTest2() {
    CharLinkedList list;
    CharLinkedList newList(list);
    assert(newList.isEmpty());
}

//isEmptyTest0
//asserts that a list with one char in it is not empty
void isEmptyTest0() {
    CharLinkedList list('a');
    assert(not(list.isEmpty()));
}

//isEmptyTest1
//asserts that a list with no chars in it is empty
void isEmptyTest1() {
    CharLinkedList list;
    assert(list.isEmpty());
}

//isEmptyTest2()
//asserts that a list with several chars in it is not empty
void isEmptyTest2() {
    char array[] = {'P', 'e', 'p', 's', 'i'};
    CharLinkedList list(array, 5);
    assert(not(list.isEmpty()));
}

//sizeTest0
//asserts that an empty list has size 0
void sizeTest0() {
    CharLinkedList list;
    assert(list.size() == 0);
}

//sizeTest1
//asserts that a list with 5 chars in it would have size 5
void sizeTest1() {
    char array[] = {'P', 'e', 'p', 's', 'i'};
    CharLinkedList list(array, 5);
    assert(list.size() == 5);
}

//elementAtTest0
//tests that the elementAt function returns the element initialized from char
//constructor
void elementAtTest0() {
    CharLinkedList list('a');
    assert(list.elementAt(0) == 'a');
}

//elementAtTest1
//tests that elementAt will throw a range_error if trying to access an element
//out of bounds
void elementAtTest1() {
    
    bool range_error_thrown = false;

    std::string error_message = "";

    CharLinkedList list('a');
    try {
    list.elementAt(3);
    }
    catch (const std::range_error &e) {
    range_error_thrown = true;
    error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (3) not in range [0..1)");
}

//elementAtTest2
//tests that elementAt will throw a range_error if trying to access an element
//in an empty CharLinkedList
void elementAtTest2() {
    
    bool range_error_thrown = false;

    std::string error_message = "";

    CharLinkedList list;
    try {
    list.elementAt(1);
    }
    catch (const std::range_error &e) {

    range_error_thrown = true;
    error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (1) not in range [0..0)");
}

//elementAtTest3
//tests that elementAt will throw a range_error if trying to access the first
//element of an empty CharLinkedList
void elementAtTest3() {
    
    bool range_error_thrown = false;

    std::string error_message = "";

    CharLinkedList list;
    try {
    list.elementAt(0);
    }
    catch (const std::range_error &e) {

    range_error_thrown = true;
    error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (0) not in range [0..0)");
}

//elementAtTest4
//tests that elementAt will throw a range_error if trying to access a negative
//index
void elementAtTest4() {
    
    bool range_error_thrown = false;

    std::string error_message = "";

    CharLinkedList list('a');
    try {
    list.elementAt(-1);
    }
    catch (const std::range_error &e) {

    range_error_thrown = true;
    error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (-1) not in range [0..1)");
}

//elementAtTest5
//tests that elementAt correctly identifies the first index in a list of size 5
void elementAtTest5() {
    char array[] = {'P', 'e', 'p', 's', 'i'};
    CharLinkedList list(array, 5);
    assert(list.elementAt(0) == 'P');
}

//elementAtTest6
//tests that elementAt correctly identifies the last index in a list of size 5
void elementAtTest6() {
    char array[] = {'P', 'e', 'p', 's', 'i'};
    CharLinkedList list(array, 5);
    assert(list.elementAt(4) == 'i');
}

//elementAtTest7
//tests that elementAt correctly identifies a middle index in a list of size 5
void elementAtTest7() {
    char array[] = {'P', 'e', 'p', 's', 'i'};
    CharLinkedList list(array, 5);
    assert(list.elementAt(2) == 'p');
}

//replaceAtTest0
//tests that replaceAt correctly replaces 'a' with 'b'
void replaceAtTest0() {
    CharLinkedList list('a');
    assert(list.elementAt(0) == 'a');
    list.replaceAt('b', 0);
    assert(list.elementAt(0) == 'b');
}

//replaceAtTest1
//tests that replaceAt correctly replaces an element at the end of a list
void replaceAtTest1() {
    CharLinkedList list('a');
    list.pushAtBack('b');
    list.elementAt(0);
    list.elementAt(1);
    //assert(list.elementAt(0) == 'a');
    list.replaceAt('c', 1);
    list.elementAt(1);
    //assert(list.last() == 'c');
}

//replaceAtTest2
//tests that replaceAt throws an error when trying to replace a char at an index
//out of bounds
void replaceAtTest2() {
    bool range_error_thrown = false;

    std::string error_message = "";

    CharLinkedList list;
    try {
    list.replaceAt('c', 1);
    }
    catch (const std::range_error &e) {
    range_error_thrown = true;
    error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (1) not in range [0..0)");
}

//replaceAtTest3
//tests that replaceAt throws an error when trying to replace a char in an
//empty list
void replaceAtTest3() {
    bool range_error_thrown = false;

    std::string error_message = "";

    CharLinkedList list;
    try {
    list.replaceAt('c', 0);
    }
    catch (const std::range_error &e) {
    range_error_thrown = true;
    error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (0) not in range [0..0)");
}

//replaceAtTest4
//tests that replaceAt throws an error when trying to replace a char in a
//negative index
void replaceAtTest4() {
    bool range_error_thrown = false;

    std::string error_message = "";

    CharLinkedList list;
    try {
    list.replaceAt('c', -1);
    }
    catch (const std::range_error &e) {
    range_error_thrown = true;
    error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (-1) not in range [0..0)");
}

//toStringTest0
//tests that the toString function outputs the correct size and element string
void toStringTest0() {
    char array[] = {'P', 'e', 'p', 's', 'i'};
    CharLinkedList list(array, 5);
    list.toString();
    //assert(list.toString() == "[CharLinkedList of size 5 <<Pepsi>>]");
}

//toStringTest1
//tests that the toString function outputs the correct size and elements of an
//empty list
void toStringTest1() {
    CharLinkedList list;
    list.toString();
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}

//toStringTest2
//tests that the toString function outputs the correct size and elements of a
//list of size 1
void toStringTest2() {
    CharLinkedList list('a');
    list.toString();
    assert(list.toString() == "[CharLinkedList of size 1 <<a>>]");
}

//toReverseStringTest0
//tests that the toReverseString function outputs the correct size and
//reversed element string
void toReverseStringTest0() {
    char array[] = {'P', 'e', 'p', 's', 'i'};
    CharLinkedList list(array, 5);
    list.toReverseString();
    assert(list.size() == 5);
    assert(list.elementAt(0) == 'P');
    assert(list.toReverseString() == "[CharLinkedList of size 5 <<ispeP>>]");
}

//toReverseStringTest1
//tests that the toReverseString function outputs the correct size and
//elements of an empty list
void toReverseStringTest1() {
    CharLinkedList list;
    list.toReverseString();
    assert(list.toReverseString() == "[CharLinkedList of size 0 <<>>]");
}

//toReverseStringTest2
//tests that the toReverseString function outputs the correct size and
//elements of a list of size 1
void toReverseStringTest2() {
    CharLinkedList list('a');
    list.toReverseString();
    assert(list.toReverseString() == "[CharLinkedList of size 1 <<a>>]");
}

//copyOperatorTest0
//tests that the copyOperator correctly copies elements from other list
void copyOperatorTest0() {
    char array[] = {'P', 'e', 'p', 's', 'i'};
    CharLinkedList list(array, 5);
    CharLinkedList newList = list;
    for (int i = 0; i < 5; i++) {
        assert(newList.elementAt(i) == list.elementAt(i));
    }
}

//copyOperatorTest1
//tests that the copyOperator creates deep copies of elements from other list
//by changing other list's elements and asserting that newList does not change
void copyOperatorTest1() {
    char array[] = {'P', 'e', 'p', 's', 'i'};
    CharLinkedList list(array, 5);
    CharLinkedList newList = list;
    for (int i = 0; i < 5; i++) {
        assert(newList.elementAt(i) == list.elementAt(i));
    }
    list.replaceAt('s', 4);
    assert(newList.elementAt(4) == 'i');
}

//copyOperatorTest2
//tests that the copyOperator copies correctly from an empty list
void copyOperatorTest2() {
    CharLinkedList list;
    CharLinkedList newList = list;
    assert(newList.isEmpty());
}

//clearTest0
//tests that clear yields empty list
void clearTest0() {
    char array[] = {'P', 'e', 'p', 's', 'i'};
    CharLinkedList list(array, 5);
    list.clear();
    assert(list.isEmpty());
}

//clearTest1
//tests that clear yields empty list when used on empty list
void clearTest1() {
    CharLinkedList list;
    list.clear();
    assert(list.isEmpty());
}

//clearTest2
//tests that clear yields empty list when used on list of a lot of many chars
void clearTest2() {
    char array[] = {'a','b', 'c', 'd', 'e', 'f', 'g', 'h', 'j', 'k', 'l', 'f', 
    'g', 'h', 'j', 'k','l','m','n','o','p','q','r','s','t','u','v','w','x','y'};
    CharLinkedList list(array, 25);
    list.clear();
    assert(list.isEmpty());
}

//clearTest3
//tests that clear yields empty list when used on a 1-char list
void clearTest3() {
    CharLinkedList list('a');
    list.clear();
    assert(list.isEmpty());
}

//firstTest0
//tests that first yields the correct first element of a list
void firstTest0() {
    char array[] = {'P', 'e', 'p', 's', 'i'};
    CharLinkedList list(array, 5);
    assert(list.first() == 'P');
}

//firstTest1
//tests that first throws an error message when attempting to retrieve first
//char of an empty list
void firstTest1() {
    bool runtime_error_thrown = false;

    std::string error_message = "";

    CharLinkedList list;
    try {
    list.first();
    }
    catch (const std::runtime_error &e) {
    runtime_error_thrown = true;
    error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot get first of empty LinkedList");
}

//firstTest2
//tests that last yields the correct last element of a list with one char
void firstTest2() {
    CharLinkedList list('a');
    assert(list.first() == 'a');
}

//lastTest0
//tests that last yields the correct last element of a list
void lastTest0() {
    char array[] = {'P', 'e', 'p', 's', 'i'};
    CharLinkedList list(array, 5);
    assert(list.last() == 'i');
}

//lastTest1
//tests that last throws an error message when attempting to retrieve last char
//of an empty list
void lastTest1() {
    bool runtime_error_thrown = false;

    std::string error_message = "";

    CharLinkedList list;
    try {
    list.last();
    }
    catch (const std::runtime_error &e) {
    runtime_error_thrown = true;
    error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot get last of empty LinkedList");
}

//lastTest2
//tests that last yields the correct last element of a list with one char
void lastTest2() {
    CharLinkedList list('a');
    assert(list.last() == 'a');
}

//pushAtBackTest0
//tests that pushAtBack pushes the correct char to the back of CharLinkedList
void pushAtBackTest0() {
    char array[] = {'P', 'e', 'p', 's', 'i'};
    CharLinkedList list(array, 5);
    list.pushAtBack('s');
    assert(list.last() == 's');
}

//pushAtBackTest1
//tests that pushAtBack pushes the correct char to the back of empty list
void pushAtBackTest1() {
    CharLinkedList list;
    list.pushAtBack('L');
    assert(list.last() == 'L');
}

//pushAtBackTest2
//tests that pushAtBack pushes the correct char to the back of a 1-char list
void pushAtBackTest2() {
    CharLinkedList list('a');
    list.pushAtBack('L');
    assert(list.last() == 'L');
    assert(list.first() == 'a');
    assert(list.elementAt(1) == 'L');
}

//pushAtFrontTest0
//tests that pushAtFront pushes correct char to front of list
void pushAtFrontTest0() {
    char array[] = {'P', 'e', 'p', 's', 'i'};
    CharLinkedList list(array, 5);
    list.pushAtFront('B');
    assert(list.first() == 'B');
    assert(list.elementAt(1) == 'P');
    assert(list.last() == 'i');
}

//pushAtFrontTest1
//tests that pushAtFront pushes correct char to front of empty list
void pushAtFrontTest1() {
    CharLinkedList list;
    list.pushAtFront('B');
    assert(list.first() == 'B');
    assert(list.last() == 'B');
}

//pushAtFrontTest2
//tests that pushAtFront pushes correct char to front of a 1-char list
void pushAtFrontTest2() {
    CharLinkedList list('a');
    list.pushAtFront('B');
    assert(list.first() == 'B');
    assert(list.last() == 'a');
}

//popFromFrontTest0
//tests that popFromFront pops char from correct position and moves elements
//to correct places
void popFromFrontTest0() {
    char array[] = {'P', 'e', 'p', 's', 'i'};
    CharLinkedList list(array, 5);
    list.popFromFront();
    assert(list.first() == 'e');
    assert(list.last() == 'i');
}

//popFromFrontTest1
//tests that popFromFront pops char from correct position and returns empty list
//when only element has been popped
void popFromFrontTest1() {
    CharLinkedList list('a');
    list.popFromFront();
    assert(list.isEmpty());
}

//popFromFrontTest2
//tests that popFromFront throws runtime_error when attempting to pop from
//empty list
void popFromFrontTest2() {
    bool runtime_error_thrown = false;

    std::string error_message = "";

    CharLinkedList list;
    try {
    list.popFromFront();
    }
    catch (const std::runtime_error &e) {
    runtime_error_thrown = true;
    error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

//popFromBackTest0
//tests that popFromBack pops char from correct position and decreases size
void popFromBackTest0() {
    char array[] = {'P', 'e', 'p', 's', 'i'};
    CharLinkedList list(array, 5);
    list.popFromBack();
    assert(list.first() == 'P');
    assert(list.last() == 's');
}

//popFromBackTest1
//tests that popFromBack throws runtime_error when attempting to pop from empty
//list
void popFromBackTest1() {
    bool runtime_error_thrown = false;

    std::string error_message = "";

    CharLinkedList list;
    try {
    list.popFromBack();
    }
    catch (const std::runtime_error &e) {
    runtime_error_thrown = true;
    error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

//popFromBackTest2
//tests that popFromFront pops char from correct position and returns empty list
//when only element has been popped
void popFromBackTest2() {
    CharLinkedList list('a');
    list.popFromBack();
    assert(list.isEmpty());
}

// Tests correct insertion into an empty AL.
// Afterwards, size should be 1 and element at index 0
// should be the element we inserted.
void insertAt_empty_correct() { 

    CharLinkedList test_list;
    assert(test_list.size() == 0);
    test_list.insertAt('a', 0);
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');

}

// Tests incorrect insertion into an empty AL.
// Attempts to call insertAt for index larger than 0.
// This should result in an std::range_error being raised.
void insertAt_empty_incorrect() {

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    // insertAt for out-of-range index
    test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
    // if insertAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    range_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0]");
}

// Tests correct insertAt for front of 1-element list.
void insertAt_front_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at front
    test_list.insertAt('b', 0);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'a');
    
}

// Tests correct insertAt for back of 1-element list.
void insertAt_back_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at back
    test_list.insertAt('b', 1);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    
}

// Tests calling insertAt for a large number of elements.
// Not only does this test insertAt, it also checks that
// array expansion works correctly.
void insertAt_many_elements() {
    
    CharLinkedList test_list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.insertAt('a', i);
    }

    assert(test_list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
    
}

// Tests insertion into front of a larger list
void insertAt_front_large_list() {
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    test_list.insertAt('y', 0);

    assert(test_list.size() == 10);
    assert(test_list.elementAt(0) == 'y');
    assert(test_list.toString() ==
    "[CharLinkedList of size 10 <<yabczdefgh>>]");

}

// Tests insertion into the back of a larger list
void insertAt_back_large_list() {

    char test_arr[10] = { 'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 10);  

    test_list.insertAt('x', 10);

    assert(test_list.size() == 11);
    assert(test_list.elementAt(10) == 'x');
    assert(test_list.toString() == 
    "[CharLinkedList of size 11 <<yabczdefghx>>]"); 

}

// Tests insertion into the middle of a larger list
void insertAt_middle_large_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.insertAt('z', 3);

    assert(test_list.size() == 9);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    assert(test_list.elementAt(2) == 'c');
    assert(test_list.elementAt(3) == 'z');
    assert(test_list.elementAt(4) == 'd');
    assert(test_list.toString() == "[CharLinkedList of size 9 <<abczdefgh>>]");

}

// Tests out-of-range insertion for a non-empty list.
void insertAt_nonempty_incorrect() {
   
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8]");
    
}

//insertInOrderTest0
//tests that insertInOrder inserts correctly to first index
void insertInOrderTest0() {
    char array[] = {'b', 'b', 'c'};
    CharLinkedList list(array, 3);
    list.insertInOrder('a');
    assert(list.first() == 'a');
    assert(list.last() == 'c');
}

//insertInOrderTest1
//tests that insertInOrder inserts correctly to a middle index
void insertInOrderTest1() {
    char array[] = {'a', 'b', 'c', 'd'};
    CharLinkedList list(array, 4);
    list.insertInOrder('b');
    assert(list.first() == 'a');
    assert(list.elementAt(1) == 'b');
    assert(list.elementAt(2) == 'b');
    assert(list.elementAt(3) == 'c');
    assert(list.last() == 'd');
}

//insertInOrderTest2
//tests that insertInOrder inserts correctly to a middle index in a long list
void insertInOrderTest2() {
    char array[] = {'a','b', 'c', 'd', 'e', 'f', 'g', 'h', 'j', 'k', 'l', 'f', 
    'g', 'h', 'j', 'k','l','m','n','o','p','q','r','s','t','u','v','w','x','y'};
    CharLinkedList list(array, 25);
    list.insertInOrder('j');
    assert(list.elementAt(8) == 'j');
    assert(list.elementAt(9) == 'j');
}

//insertInOrderTest3
//tests that insertInOrder inserts correctly to first index of non-ascending
//order
void insertInOrderTest3() {
    char array[] = {'z', 'e','d'};
    CharLinkedList list(array, 3);
    list.insertInOrder('a');
    assert(list.elementAt(0) == 'a');
}

//insertInOrderTest4
//tests that insertInOrder inserts correctly to last index
void insertInOrderTest4() {
    char array[] = {'a', 'b', 'c', 'd'};
    CharLinkedList list(array, 4);
    list.insertInOrder('z');
    assert(list.first() == 'a');
    assert(list.elementAt(1) == 'b');
    assert(list.elementAt(2) == 'c');
    assert(list.last() == 'z');
}

//insertInOrderTest5
//tests that insertInOrder inserts correctly in non-ascending order
void insertInOrderTest5() {
    char array[] = {'z', 'e','d'};
    CharLinkedList list(array, 3);
    list.insertInOrder('j');
    assert(list.elementAt(0) == 'j');
    list.insertInOrder('b');
    assert(list.elementAt(0) == 'b');
}

//insertInOrderTest6
//tests that insertInOrder inserts correctly to empty list
void insertInOrderTest6() {
    CharLinkedList list;
    list.insertInOrder('j');
    assert(list.elementAt(0) == 'j');
}

//insertInOrderTest7
//tests that insertInOrder inserts correctly to first element in one-element
//list
void insertInOrderTest7() {
    CharLinkedList list('c');
    list.insertInOrder('a');
    assert(list.first() == 'a');
}

//insertInOrderTest8
//tests that insertInOrder inserts correctly to last element in one-element
//list
void insertInOrderTest8() {
    CharLinkedList list('c');
    list.insertInOrder('z');
    assert(list.last() == 'z');
}

//removeAtTest0
//tests that removeAt correctly removes middle index element and shifts other
//remaining chars to correct indexes
void removeAtTest0() {
    char array[] = {'P', 'e', 'p', 's', 'i'};
    CharLinkedList list(array, 5);
    list.removeAt(1);
    assert(list.first() == 'P');
    assert(list.last() == 'i');
    assert(list.elementAt(2) == 's');
    assert(list.elementAt(1) == 'p');
}

//removeAtTest1
//tests that removeAt correctly removes first index element and shifts other
//remaining chars to correct indexes
void removeAtTest1() {
    char array[] = {'P', 'e', 'p', 's', 'i'};
    CharLinkedList list(array, 5);
    list.removeAt(0);
    assert(list.first() == 'e');
    assert(list.last() == 'i');
    assert(list.elementAt(2) == 's');
    assert(list.elementAt(1) == 'p');
}

//removeAtTest2
//tests that removeAt correctly removes last index element and shifts other
//remaining chars to correct indexes
void removeAtTest2() {
    char array[] = {'P', 'e', 'p', 's', 'i'};
    CharLinkedList list(array, 5);
    list.removeAt(4);
    assert(list.first() == 'P');
    assert(list.last() == 's');
    assert(list.elementAt(2) == 'p');
    assert(list.elementAt(1) == 'e');
}

//removeAtTest3
//tests that removeAt throws range_error when attempting to remove char from
//empty list
void removeAtTest3() {
    CharLinkedList list;
    bool range_error_thrown = false;

    std::string error_message = "";

    try {
    list.removeAt(0);
    }
    catch (const std::range_error &e) {

    range_error_thrown = true;
    error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (0) not in range [0..0)");
}

//removeAtTest4
//tests that removeAt throws range_error when attempting to remove char from
//out of bounds index
void removeAtTest4() {
    CharLinkedList list;
    
    bool range_error_thrown = false;

    std::string error_message = "";

    try {
    list.removeAt(3);
    }
    catch (const std::range_error &e) {
    range_error_thrown = true;
    error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (3) not in range [0..0)");
}

//removeAtTest5
//tests that removeAt returns empty list when removing the only char from a
//1-char list
void removeAtTest5() {
    CharLinkedList list('a');
    list.removeAt(0);
    assert(list.isEmpty());
}

//concatenateTest0
//tests that concatenate correctly pushes chars from second list to array in
//first list
void concatenateTest0() {
    char array[] = {'P', 'e', 'p', 's', 'i'};
    CharLinkedList list(array, 5);
    char array2[] = {'P', 'e', 'n', 'g', 'u', 'i', 'n'};
    CharLinkedList list2(array2, 7);
    list.concatenate(&list2);
    assert(list.first() == 'P');
    assert(list.last() == 'n');
}

//concatenateTest1
//tests that concatenate correctly pushes chars from second list to array in
//first list when first and second list are the same lists
void concatenateTest1() {
    char array[] = {'P', 'e', 'p', 's', 'i'};
    CharLinkedList list(array, 5);
    list.concatenate(&list);
    assert(list.first() == 'P');
    assert(list.elementAt(5) == 'P');
    assert(list.last() == 'i');
}

//concatenateTest2
//tests that concatenate correctly produces an empty list when attempting to
//concatenate an empty list to an empty list
void concatenateTest2() {
    CharLinkedList list;
    CharLinkedList list2;
    list.concatenate(&list2);
    assert(list.isEmpty());
}

//concatenateTest3
//tests that concatenate creates deep copies of the elements of list2 into list1
void concatenateTest3() {
    CharLinkedList list1;
    char array[] = {'P', 'e', 'p', 's', 'i'};
    CharLinkedList list2(array, 5);
    list1.concatenate(&list2);
    assert(list1.first() == 'P');
    list2.popFromFront();
    assert(list2.first() == 'e');
    assert(list1.first() == 'P');
}
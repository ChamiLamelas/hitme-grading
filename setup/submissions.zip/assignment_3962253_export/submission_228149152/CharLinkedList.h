/*
 *  CharLinkedList.h
 *  Rebecca Lee
 *  02/02/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Purpose: To create a list which can hold characters that can then be
 *  changed (added to or removed from) and viewed and accessed (from the front,
 *  back, or somewhere in the middle). This is implemented through a linked
 *  list where characters are stored by individual Node structs.
 *
 */

#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H

#include <string>


class CharLinkedList {

    private:

        //Node struct;
        struct Node {
            char data;
            Node *next;
            Node *prev;
        };
        
        Node *front;
        Node *end;
        int listSize;
        
        //private recursive helper methods
        void deleteNodes(Node *f);
        void replaceAtHelper(Node *f, char c, int index);
        char elementAtHelper(Node *f, int index) const;

    public:

        //constructors
        CharLinkedList();
        CharLinkedList(char c);
        CharLinkedList(char arr[], int size);
        CharLinkedList(const CharLinkedList &other);

        //destructor method
        ~CharLinkedList();

        //manipulation methods
        CharLinkedList &operator=(const CharLinkedList &other);
        void clear();
        void pushAtBack(char c);
        void pushAtFront(char c);
        void insertAt(char c, int index);
        void insertInOrder(char c);
        void popFromFront();
        void popFromBack();
        void removeAt(int index);
        void replaceAt(char c, int index);
        void concatenate(CharLinkedList *other);

        //return methods
        bool isEmpty() const;
        int size() const;
        char first() const;
        char last() const;

        char elementAt(int index) const;
        std::string toString() const;
        std::string toReverseString() const;
        

    



};

#endif

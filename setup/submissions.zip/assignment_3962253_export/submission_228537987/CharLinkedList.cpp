/*
 *  CharLinkedList.cpp
 *  Tom Jamieson
 *  02/04/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Implementation of CharLinkedList
 *
 */

#include "CharLinkedList.h"
#include <string>
#include <sstream>
#include <iostream> 
using namespace std;


// name: CharLinkedList
// purpose: Default Constructor
// arguments: n/a
// returns: initializes empty CharLinkedList
// effects: n/a
CharLinkedList::CharLinkedList(){
    firstnode = nullptr;
    lastnode = nullptr;
}

// name: ~CharLinkedList
// purpose: Destructor; Delete all nodes of CharLinkedList Recursively
// arguments: n/a
// returns: n/a; freed up memory
// effects: n/a
CharLinkedList::~CharLinkedList(){
    node *current = firstnode;
    recursivedelete(current);
}

// name: Recursive Delete
// purpose: Destructor helper; Deletes all nodes of LinkedList
// arguments: pointer to first node
// returns: n/a; freed up memory
// effects: n/a
void CharLinkedList::recursivedelete(node *current){
    if(current == nullptr){
        return;
    }
    node *nextnode = current->next;
    delete current;
    recursivedelete(nextnode);
}

// name: CharLinkedList(char c)
// purpose: Make a size one ArrayList w given char
// arguments: char, will fill node's data
// returns: Initialized CharLinkedList
// effects: n/a
CharLinkedList::CharLinkedList(char c){
    node* newnode = new node;
    newnode->data = c;
    newnode->next = nullptr;
    newnode->previous = nullptr;
    firstnode = newnode;
    lastnode = newnode;
    count = 1;
}


// name: CharLinkedList(char arr[], int arrsize)
// purpose: Constructor - Creates LinkedList based on given array & size
// arguments: Array to be converted to linkedlist & size
// returns: Initialized CharLinkedList
// effects: n/a
CharLinkedList::CharLinkedList(char arr[], int arrsize){
    node* newnode = new node;
    newnode->data = arr[0];
    newnode->next = nullptr;
    newnode->previous = nullptr;
    firstnode = newnode;
    lastnode = newnode;
    count = 1;
    for(int i = 1; i < arrsize; i++){
        this->pushAtBack(arr[i]);
    }
}

// name: First
// purpose: Returns data at first node in list
// arguments: n/a - operates on instance of class
// returns: Char contained by first node
// effects: Raises an error for empty list
char CharLinkedList::first(){
    if(firstnode == nullptr){
        throw std::runtime_error("cannot get first of empty LinkedList");
    }
    return firstnode->data;
}

// name: Last
// purpose: Returns data at last node in LinkedList
// arguments: n/a - operates on instance of class
// returns: Char contained by last node
// effects: Raises an error for empty list
char CharLinkedList::last(){
    if(firstnode == nullptr){
        throw std::runtime_error("cannot get last of empty LinkedList");
    }
    return lastnode->data;
}

// name: size
// purpose: Returns size of LinkedList 
// arguments: n/a - operates on instance of class
// returns: member variable containing size
// effects: n/a
int CharLinkedList::size(){
    return count;
}

// name: pushAtBack
// purpose: Creates new node at the end of given linkedlist
// arguments: char - contained in new node
// returns: Updated data structure
// effects: can be used on empty data structure, updates count, updates relevant
// pointers (last, the next of the previous node)
void CharLinkedList::pushAtBack(char c){
    node* newnode = new node;
    newnode->data = c;
    newnode->next = nullptr;
    if(isEmpty() == true){
        firstnode = newnode;
        lastnode = newnode;
    }
    newnode->previous = lastnode;
    lastnode->next = newnode;
    lastnode = newnode;
    count++;
}

// name: pushAtFront
// purpose: Creates new node at the beginning of given linkedlist
// arguments: char - contained in new node
// returns: Updated data structure
// effects: can be used on empty data structure, updates count, updates relevant
// pointers (last, the next of the previous node)
void CharLinkedList::pushAtFront(char c){
    node* newnode = new node;
    newnode->data = c;
    newnode->next = firstnode;
    newnode->previous = nullptr;
    if(firstnode != nullptr){
        firstnode->previous = newnode;
    }
    firstnode = newnode;
    if(lastnode == nullptr){
        lastnode = newnode;
    }
    count++;
}

// name: toString
// purpose: assemble linkedlist into a string / meet specifications
// arguments: n/a - works on linkedlist
// returns: string "[CharLinkedList of size (SIZE) <<(chars in order of 
// appearance)>>
// effects: Works on empty LinkedList
std::string CharLinkedList::toString() const{
    // Assemble stringstream
    stringstream ss;
    string word;
    node *current = firstnode;
    ss << "[CharLinkedList of size " << count << " <<";
    // Collect chars
    while(current != nullptr){
        ss << current->data;
        current = current->next;
    }
    ss << ">>]";
    return ss.str();
}

// name: toReverseString
// purpose: assemble linkedlist into a reversed string / meet specifications
// arguments: n/a - works on linkedlist
// returns: string "[CharLinkedList of size (SIZE) <<(chars in revsers order of 
// appearance)>>
// effects: Works on empty LinkedList
std::string CharLinkedList::toReverseString() const{
    // Assemble stringstream
    stringstream ss;
    string word;
    node *current = lastnode;
    ss << "[CharLinkedList of size " << count << " <<";
    // Collect chars
    while(current != nullptr){
        ss << current->data;
        current = current->previous;
    }
    ss << ">>]";
    return ss.str();
}

// name: isEmpty
// purpose: Return true if list is empty (no chars), false otherwisse
// arguments: n/a - works on linkedlist
// returns: "[CharLinkedList of size (SIZE) <<(chars in order of appearance)>>
// effects: returns true/false depending on input
bool CharLinkedList::isEmpty() const{
    if(count == 0){
        return true;
    }else{
        return false;
    }
}

// name: Clear
// purpose: turns CharlinkedList empty
// arguments: n/a - works on linkedlist
// returns: modified–empty–list
// effects: deletes nodes, decrease size
void CharLinkedList::clear(){
    node *current = firstnode;
    while(current != nullptr){
        node *nextnode = current->next;
        delete current;
        current = nextnode;
    }
    firstnode = nullptr;
    lastnode = nullptr;
    count = 0;
}

// name: elementAt
// purpose: Return char at given index of Linkedlist
// arguments: index of element of interest
// returns: element at index
// effects: throws error for out of scope inputs, works recursively
char CharLinkedList::elementAt(int index) const{
    if(index < 0 or index > count){
        std:stringstream message;
        message << "index (" << index << ") not in range [0.." << count;
        message << ")";
        throw std::range_error(message.str());
    }
    return elementAtHelper(firstnode, index);
}

// name: elementAtHelper
// purpose: handle recursive search for elementAt
// arguments: node pointer current (first node), index
// returns: element at index
// effects: updates currpointer & index while searching
char CharLinkedList::elementAtHelper(node *current, int index) const{
    if(index == 0){
        return current->data;
    }else{
        return elementAtHelper(current->next, index - 1);
    }
}

// name: Assignment operator
// purpose: Modifys = meaning for CharLinkedLists. Using = on 2 charLinkedLists
// Creates a deep copy (modifying node chars) of right side of = into left side.
// arguments: Linked list to copy, operates on linkedlist to the left of =.
// returns: updated CharLinkedList to left 
// effects: uses other member functions
CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other){
    clear();
    firstnode = other.firstnode;
    for(int i = 0; i < other.count; i++){
        pushAtBack(other.elementAt(i));
    }
    return *this;
}

// name: insertAt
// purpose: Insert a node into given CharLinkedList
// arguments: char to be inputted, desired index
// returns: updated LinkedList
// effects: throws error for out of scope inputs, updates size
void CharLinkedList::insertAt(char c, int index){
    // error check
    if(index < 0 or index > count){
        std:stringstream message;
        message << "index (" << index << ") not in range [0.." << count;
        message << ")";
        throw std::range_error(message.str());
    }
    // Using push for modularity
    if(index == 0){
        pushAtFront(c);
        return;
    }
    if(index == count){
        pushAtBack(c);
        return;
    }
    // Search for index
    node *newnode = new node;
    newnode->data = c;
    node *current = firstnode;
    for(int i = 0; i < index; i++){
        current = current->next;
    }
    // Updating relevant pointers
    newnode->next = current->next;
    newnode->previous = current;
    current->next = newnode;
    if(newnode->next != nullptr){
        newnode->next->previous = newnode;
    }
    // Increment size
    count++;
}

// name: insertInOrder
// purpose: Insert desired char into correct ASCII order in List
// arguments: desired char input
// returns: updated data structure
// effects: updates size
void CharLinkedList::insertInOrder(char c){
    node *current = firstnode;
    if(isEmpty() == true or c <= firstnode->data){
        pushAtFront(c);
        return;
    }
    int i = 0;
    while(current->next != nullptr && c > current->next->data){
        current = current->next;
        i++;
    }
    insertAt(c, i);
}

// name: popFromFront
// purpose: remove first list node
// arguments: n/a, uses given CharLinkedList
// returns: updated data structure
// effects: decreases size, updates pointers, checks for empty list
void CharLinkedList::popFromFront(){
    // Error checl
    if(isEmpty() == true){
        throw std::runtime_error("cannot pop from empty LinkedList");
    }
    // Updata pointers accordingly
    node *tempnode = firstnode;
    firstnode = firstnode->next;
    if(firstnode != nullptr){
        firstnode->previous = nullptr;
    }else{
        lastnode = nullptr;
    }
    // deletion, deincrementation
    delete tempnode;
    count--;
}

// name: popFromBack
// purpose: remove last list node
// arguments: n/a, uses given CharLinkedList
// returns: updated data structure
// effects: decreases size, updates pointers, checks for empty list
void CharLinkedList::popFromBack(){
    // Empty check
    if(isEmpty() == true){
        throw std::runtime_error("cannot pop from empty LinkedList");
    }
    // Updates pointer accordingly
    node *tempnode = lastnode;
    lastnode = lastnode->previous;
    if(lastnode != nullptr){
        lastnode->next = nullptr;
    }else{
        firstnode = nullptr;
    }
    // Deletion, deincrementation
    delete tempnode;
    count--;
}

// name: removeAt
// purpose: remove at given index
// arguments: uses given CharLinkedList, desired index for removal
// returns: updated data structure
// effects: decreases size, updates pointers, checks for scope error
void CharLinkedList::removeAt(int index){
    // Scope error
    if(index < 0 or index > count){
        std:stringstream message;
        message << "index (" << index << ") not in range [0.." << count;
        message << ")";
        throw std::range_error(message.str());
    }
    // Using pops, modularity
    if(index == 0){
        popFromFront();
        return;
    }
    if(index == count - 1){
        popFromBack();
        return;
    }
    // Searching for index
    node* current = firstnode;
    for(int i = 0; i < index; i++){
        current = current->next;
    }
    // Update pointers, deletion, deincrementation
    current->previous->next = current->next;
    current->next->previous = current->previous;
    delete current;
    count--;
}

// name: replaceAt
// purpose: replace at desired index with char input
// arguments: uses given CharLinkedList, desired char for input, desired input
// returns: updated data structure
// effects: updates pointers, checks for scope error, recursive
void CharLinkedList::replaceAt(char c, int index){
    // eror check
    if(index < 0 or index > count){
        std:stringstream message;
        message << "index (" << index << ") not in range [0.." << count;
        message << ")";
        throw std::range_error(message.str());
    }
    node* current = firstnode;
    replaceAthelper(current, index, c);
}

// name: replaceAtHelper
// purpose: handle recursive search and replacement for replaceAt
// arguments: current pointer (first node), desired index, desired char for 
// input
// returns: updated data structure
// effects: updates pointers
void CharLinkedList::replaceAthelper(node *current, int index, char c) const{
    if(index == 0){
        current->data = c;
        return;
    }else{
        replaceAthelper(current->next, index - 1, c);
    }
}

// name: Concatenate
// purpose: add inputted Charlinkedlist chars in order to back of linkedlist
// called on
// arguments: charlinkedlist to be added onto back
// returns: updated data structure
// effects: Creates more nodes for 
void CharLinkedList::concatenate(CharLinkedList *other){
    node *current = other->firstnode;    
    while(current != nullptr){
        pushAtBack(current->data);
        current = current->next;
    }
}
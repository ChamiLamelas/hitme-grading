/*
 *  CharLinkedList.h
 *  Tom Jamieson
 *  2/4/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Contains class CharLinkedList member defenitions. Class enables creation of 
 *  a linked list of chars, a dynamic, modable data structure linking nodes with
 *  pointers. Clients can modify CharLinkedlist and ascertain info about it 
 *  using public functions.
 *
 */

#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H

#include <string>


class CharLinkedList{
private:
    struct node{
        char data;
        node *next;
        node *previous;
    };
    node *firstnode;
    node *lastnode;
    int count = 0;
public:
    CharLinkedList();
    CharLinkedList(char c);
    CharLinkedList(char arr[], int arrsize);
    ~CharLinkedList();
    void recursivedelete(node *current);
    void pushAtBack(char c);
    void pushAtFront(char c);
    char getlastdata();
    int size();
    std::string toString() const;
    std::string toReverseString() const;
    bool isEmpty() const;
    void clear();
    char first();
    char last();
    char elementAt(int index) const;
    char elementAtHelper(node *current, int index) const;
    void insertAt(char c, int index);
    void popFromFront();
    void popFromBack();
    void removeAt(int index);
    void replaceAt(char c, int index);
    void replaceAthelper(node *current, int index, char c) const;
    void concatenate(CharLinkedList *other);
    void insertInOrder(char c);
    CharLinkedList &operator=(const CharLinkedList &other);
};

#endif

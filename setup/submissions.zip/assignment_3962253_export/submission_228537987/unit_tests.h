/*
 *  unit_tests.h
 *  Tom Jamieson
 *  2/4/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  Unit tests for class CharLinkedList, test members under varying 
 *  circumstances to ensure proper implementation
 *
 */
#include "CharLinkedList.h"
#include <cassert>
using namespace std;

void dummy_test(){
    assert(1 + 1 == 2);
}

void second_constructor(){
    CharLinkedList list('f');
    cout << list.size() << endl;
    assert(list.first() == 'f');
}

void third_constructor(){
    char arr[] = {'a', 'b', 'c', 'd'};
    CharLinkedList list(arr, 4);
    cout << "here" << endl;
    assert(list.size() == 4);
    assert(list.first() == 'a');
}

void backtest(){
    CharLinkedList list('f');
    list.pushAtBack('g');
    cout << list.last() << endl;;
    cout << list.size() << endl;
}

void toStringtest(){
    char arr[] = {'a', 'b', 'c', 'd'};
    CharLinkedList list(arr, 4);
    cout << list.toString() << endl;
}

void emptytoStringtest(){
    CharLinkedList list;
    cout << list.toString() << endl;
}

void toreverseStringtest(){
    char arr[] = {'a', 'b', 'c', 'd'};
    CharLinkedList list(arr, 4);
    cout << list.toReverseString() << endl;
}

void pushfronttest(){
    char arr[] = {'a', 'b', 'c', 'd'};
    CharLinkedList list(arr, 4);
    list.pushAtFront('z');
    cout << list.toString() << endl;
}

void firsttesterror(){
    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;

    try{
        test_list.first();
    }
    catch (const std::runtime_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == ("cannot get first of empty LinkedList"));
}

void lasttesteror(){
    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;

    try {
        test_list.last();
    }
    catch (const std::runtime_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == ("cannot get last of empty LinkedList"));
}

void firstlasttest(){
    char arr[] = {'a', 'b', 'c', 'd'};
    CharLinkedList list(arr, 4);
    assert(list.first() == 'a');
    assert(list.last() == 'd');
}

void emptytest(){
    char arr[] = {'a', 'b', 'c', 'd'};
    CharLinkedList list(arr, 4);
    CharLinkedList list2;
    assert(list.isEmpty() == false);
    assert(list2.isEmpty() == true);
}

void cleartest(){
    char arr[] = {'a', 'b', 'c', 'd'};
    CharLinkedList list(arr, 4);
    list.clear();
    assert(list.isEmpty() == true);
}

void sizetest(){
    CharLinkedList list;
    assert(list.isEmpty() == true);
    assert(list.size() == 0);
}

void elementAttest(){
    char arr[] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i'};
    CharLinkedList list(arr, 9);
    assert(list.elementAt(4) == 'e');
}

void insertattest(){
    char arr[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(arr, 5);
    list.insertAt('z', 4);
    cout << list.toString() << endl;
    assert(list.elementAt(5) == 'z');
}

void insertattest2(){
    char arr[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(arr, 5);
    list.insertAt('z', 3);
    cout << list.toString() << endl;
    assert(list.elementAt(4) == 'z');
}

void insertattest3(){
    char arr[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(arr, 5);
    list.insertAt('z', 0);
    cout << list.toString() << endl;
    assert(list.elementAt(0) == 'z');
}

void popfronttest(){
    char arr[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(arr, 5);
    list.popFromFront();
    cout << list.toString() << endl;
    cout << list.elementAt(0) << endl;
    assert(list.elementAt(0) == 'b');
}

void popbacktest(){
    char arr[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(arr, 5);
    list.popFromBack();
    cout << list.toString() << endl;
    assert(list.elementAt(3) == 'd');
}

void removeAttest1(){
    char arr[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(arr, 5);
    list.removeAt(3);
    cout << list.toString() << endl;
    assert(list.elementAt(3) == 'e');
}

void removeAttest2(){
    char arr[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(arr, 5);
    list.removeAt(0);
    cout << list.toString() << endl;
    assert(list.elementAt(0) == 'b');
}

void removeAttest3(){
    char arr[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(arr, 5);
    list.removeAt(4);
    cout << list.toString() << endl;
    assert(list.elementAt(3) == 'd');
}

void replaceAttest1(){
    char arr[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(arr, 5);
    list.replaceAt('z', 2);
    cout << list.toString() << endl;
    assert(list.elementAt(2) == 'z');
}

void replaceAttest2(){
    char arr[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(arr, 5);
    list.replaceAt('z', 4);
    cout << list.toString() << endl;
    assert(list.elementAt(4) == 'z');
}

void replaceAttest3(){
    char arr[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(arr, 5);
    list.replaceAt('z', 0);
    cout << list.toString() << endl;
    // assert(list.elementAt(0) == 'z');
}

void replaceerror(){
    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    char arr[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList test_list(arr, 5);

    try{
        test_list.replaceAt('z', 12);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == ("index (12) not in range [0..5)"));
}

void concattest(){
    char arr[] = {'j', 'a', 'h'};
    CharLinkedList test_list(arr, 3);
    char arr2[] = {'m', 'o', 'r', 'a', 'n', 't'};
    CharLinkedList test_list2(arr2, 6);
    test_list.concatenate(&test_list2);
    cout << test_list.toString() << endl;
}

void insertordertest(){
    char arr[] = {'a', 'c', 'e', 'g', 'i'};
    CharLinkedList list(arr, 5);
    list.insertInOrder('d');
    cout << list.toString() << endl;
    assert(list.elementAt(2) == 'd');
}

void operatortest(){
    char arr[] = {'j', 'a', 'h'};
    CharLinkedList test_list(arr, 3);
    char arr2[] = {'m', 'o', 'r', 'a', 'n', 't'};
    CharLinkedList test_list2(arr2, 6);
    test_list = test_list2;
    cout << test_list.toString() << endl;
}

void elementAterror(){
    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    char arr[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList test_list(arr, 5);

    try{
        test_list.elementAt(12);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == ("index (12) not in range [0..5)"));
}

void popfronterror(){
    // var to track whether range_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;

    try{
        test_list.popFromFront();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == ("cannot pop from empty LinkedList"));
}

void popbackerror(){
    // var to track whether range_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;

    try{
        test_list.popFromBack();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == ("cannot pop from empty LinkedList"));
}
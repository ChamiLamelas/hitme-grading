/*
 *  unit_tests.h
 *  Jasmine Schaber
 *  02/04/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  Thorough testing of CharLinkedList implementation
 *
*/
#include "CharLinkedList.h"
#include <cassert>
using namespace std;

// void emptyConstructorTest(){
//     CharLinkedList list();
// }

// void oneCharConstructorTest(){
//     CharLinkedList list('b');
// }

// void charArrayConstructor(){
//     char arr[3] = {'a', 'b','c'};
//     CharLinkedList list(arr, 3);
// }

// void charArrayConstructorSizeOne(){
//     char arr[1] = {'a'};
//     CharLinkedList list(arr, 1);
// }

// void charArrayConstructorLarger(){
//     char arr[10] = {'a', 'b', 'c', 'c', 'c','c', 'c', 'c','c', 'c'};
//     CharLinkedList list(arr, 10);
//     assert (list.elementAt(9) == 'c');
// }

// void copyConstructorFull(){
//     char arr[3] = {'a', 'b','c'};
//     CharLinkedList list(arr, 3);
//     CharLinkedList list1(list);
// }

// void copyConstructorEmpty() {
//     CharLinkedList list;
//     CharLinkedList copy(list);
//     assert(copy.isEmpty() == true);
// }

// void assignmentOperatorTestEmpty(){
//     char arr[3] = {'a', 'b','c'};
//     CharLinkedList list(arr, 3);
//     CharLinkedList list1;
//     list = list1;
//     assert(list.isEmpty());
// }

// void assignmentOperatorTestOne(){
//     CharLinkedList list('a');
//     CharLinkedList list1;
//     list1 = list;
//     assert(list1.elementAt(0) == 'a');
// }

// void assignmentOperatorTestFull(){
//     char arr[3] = {'a', 'b','c'};
//     CharLinkedList list(arr, 3);
//     CharLinkedList list1;
//     list1 = list;
//     assert(list1.elementAt(1) == 'b');
// 

// void assignmentOperatorTestErases(){
//     char arr[3] = {'a', 'b','c'};
//     CharLinkedList list(arr, 3);
//     CharLinkedList list1;
//     list = list1;
//     assert(list1.isEmpty() == true);
// }

// void isEmptyEmptyTest(){
//     CharLinkedList list;
//     assert(list.isEmpty() == true);  
// }

// void isEmptyFullTest(){
//     char arr[3] = {'a', 'b','c'};
//     CharLinkedList list(arr, 3);
//     assert(list.isEmpty() == false);  
// }

// void isEmptyTestFalseOneElem(){
//     char test = 'b';
//     CharLinkedList list(test);
//     assert (list.isEmpty() == false);
// }

// void clearFullTest(){
//     char arr[3] = {'a', 'b','c'};
//     CharLinkedList list(arr, 3);
//     list.clear();
//     assert(list.isEmpty());  
// }

// void clearOneElemTest(){
//     char arr[1] = {'a'};
//     CharLinkedList list(arr, 1);
//     list.clear();
//     assert(list.isEmpty());  
// }

// void clearEmptyTest(){
//     CharLinkedList list;
//     list.clear();
//     assert(list.isEmpty());  
// }

// void sizeBasicTest(){
//     char arr[3] = {'a', 'b','c'};
//     CharLinkedList list(arr, 3);
//     assert(list.size() == 3); 
// }

// void sizeEmptyTest(){
//     CharLinkedList list;
//     assert(list.size() == 0); 
// }


// void firstBasicTest(){
//     char arr[3] = {'a', 'b','c'};
//     CharLinkedList list(arr, 3);   
//     assert(list.first() == 'a'); 
// }

// void firstOneElemTest(){
//     char arr[1] = {'a'};
//     CharLinkedList list(arr, 1);
//     assert(list.first() == 'a'); 
// }

// void giveFirstCharTestError(){
//     CharLinkedList list;
//     bool test = false;
//     std::string error_message = "";
//     try {
//         list.first();
//     } catch (const std::runtime_error& e) {
//         test = true;
//         error_message = e.what();   
//     }
//     assert (test == true);
//     assert (error_message == "cannot get first of empty LinkedList");
// }

// void lastBasicTest(){
//     char arr[3] = {'a', 'b','c'};
//     CharLinkedList list(arr, 3);   
//     assert(list.last() == 'c'); 
// }

// void backOneElemTest(){
//     char arr[1] = {'a'};
//     CharLinkedList list(arr, 1);
//     assert(list.last() == 'a'); 
// }

// void giveBackCharTestError(){
//     CharLinkedList list;
//     bool test = false;
//     std::string error_message = "";
//     try {
//         list.last();
//     } catch (const std::runtime_error& e) {
//         test = true;
//         error_message = e.what();   
//     }
//     assert (test == true);
//     assert (error_message == "cannot get last of empty LinkedList");
// }


// void elementAtBasicTest(){
//     char arr[3] = {'a', 'b','c'};
//     CharLinkedList list(arr, 3);
//     assert(list.elementAt(1) == 'b'); 
// }

// void elementAtOneElemTest(){
//     char arr[1] = {'a'};
//     CharLinkedList list(arr, 1);
//     assert(list.elementAt(0) == 'a'); 
// }

// void elementAtEmptyError(){
//     bool test = false;
//     std::string error_message = "";
//     CharLinkedList list;
//     try {
//         list.elementAt(0);
//     } catch (const std::range_error& e) {
//         test = true;
//         error_message = e.what();   
//     }
//     assert (test == true);
//     assert (error_message == "index (0) not in range [0..0)");
// }

// void elementAtOutOfRangeHigh(){
//     bool test = false;
//     std::string error_message = "";
//     char arr[3] = {'a', 'b','c'};
//     CharLinkedList list(arr, 3);
//     try {
//         list.elementAt(10);
//     } catch (const std::range_error& e) {
//         test = true;
//         error_message = e.what();   
//     }
//     assert (test == true);
//     assert (error_message == "index (10) not in range [0..3)");
// }

// void elementAtOutOfRangeSize(){
//     bool test = false;
//     std::string error_message = "";
//     char arr[3] = {'a', 'b','c'};
//     CharLinkedList list(arr, 3);
//     try {
//         list.elementAt(3);
//     } catch (const std::range_error& e) {
//         test = true;
//         error_message = e.what();   
//     }
//     assert (test == true);
//     assert (error_message == "index (3) not in range [0..3)");
// }

// void elementAtOutOfRangeNeg(){
//     bool test = false;
//     std::string error_message = "";
//     char arr[3] = {'a', 'b','c'};
//     CharLinkedList list(arr, 3);
//     try {
//         list.elementAt(-1);
//     } catch (const std::range_error& e) {
//         test = true;
//         error_message = e.what();   
//     }
//     assert (test == true);
//     assert (error_message == "index (-1) not in range [0..3)");
// }

// void toStringBasicTest(){
//     char arr[3] = {'a', 'b','c'};
//     CharLinkedList list(arr, 3);
//     assert(list.toString() == "[CharLinkedList of size 3 <<abc>>]"); 
// }

// void toStringTestOneElem() {
//     char b = 'a';
//     CharLinkedList list(b);
//     assert (list.toString() == "[CharLinkedList of size 1 <<a>>]");
// }

// void toStringTestEmpty() {
//     CharLinkedList list;
//     assert (list.toString() == "[CharLinkedList of size 0 <<>>]");
// }


// void toReverseStringBasicTest(){
//     char arr[3] = {'a', 'b','c'};
//     CharLinkedList list(arr, 3);
//     assert(list.toReverseString() == "[CharLinkedList of size 3 <<cba>>]"); 
// }

// void toReverseStringTestOneElem() {
//     char b = 'a';
//     CharLinkedList list(b);
//     assert (list.toReverseString() == "[CharLinkedList of size 1 <<a>>]");
// }

// void toReverseStringTestEmpty() {
//     CharLinkedList list;
//     assert (list.toReverseString() == "[CharLinkedList of size 0 <<>>]");
// }

// void pushAtBackBasic(){
//     char arr[3] = {'a', 'b','c'};
//     CharLinkedList list(arr, 3);   
//     list.pushAtBack('e');
//     assert(list.elementAt(3) == 'e');
// }

// void pushAtBackEmpty(){
//     CharLinkedList list; 
//     list.pushAtBack('d');
//     assert (list.toString() == "[CharLinkedList of size 1 <<d>>]");  
// }

// void pushAtBackOneElem(){
//     char b = 'a';
//     CharLinkedList list(b);
//     list.pushAtBack('d');
//     assert (list.toString() == "[CharLinkedList of size 2 <<ad>>]");  
// }

// void pushAtFrontBasic(){
//     char arr[3] = {'a', 'b','c'};
//     CharLinkedList list(arr, 3);   
//     list.pushAtFront('e');
//     assert(list.first() == 'e');
// }

// void pushAtFrontEmpty(){
//     CharLinkedList list; 
//     list.pushAtFront('d');
//     assert (list.toString() == "[CharLinkedList of size 1 <<d>>]");  
// }

// void pushAtFrontOneElem(){
//     char b = 'a';
//     CharLinkedList list(b);
//     list.pushAtFront('d');
//     assert (list.toString() == "[CharLinkedList of size 2 <<da>>]");  
// }

// void insertAtBasicTest(){
//     char arr[3] = {'a', 'b','c'};
//     CharLinkedList list(arr, 3);   
//     list.insertAt('e', 2);
//     assert(list.elementAt(2) == 'e');
// }

// void insertAt_empty_incorrect() {
//     bool range_error_thrown = false;
//     std::string error_message = "";

//     CharLinkedList list;
//     try {
//         list.insertAt('a', 20);
//     }
//     catch (const std::range_error &e) {
//         range_error_thrown = true;
//         error_message = e.what();
//     }
//     assert(range_error_thrown);
//     assert(error_message == "index (20) not in range [0..0]");
    
// }

// void insertAt_full_incorrect() {
//     bool range_error_thrown = false;
//     std::string error_message = "";

//     char arr[3] = {'a', 'b','c'};
//     CharLinkedList list(arr, 3); 
//     try {
//         list.insertAt('a', 20);
//     }
//     catch (const std::range_error &e) {
//         range_error_thrown = true;
//         error_message = e.what();
//     }
//     assert(range_error_thrown);
//     assert(error_message == "index (20) not in range [0..3]");
    
// }

// void insertAtBackTest(){
//     char arr[3] = {'a', 'b','c'};
//     CharLinkedList list(arr, 3);   
//     list.insertAt('e', 3);
//     assert(list.elementAt(3) == 'e');
// }

// void insertAtFrontTest(){
//     char arr[3] = {'a', 'b','c'};
//     CharLinkedList list(arr, 3);   
//     list.insertAt('e', 0);
//     assert(list.elementAt(0) == 'e');
// }

// void insertInOrderBasicTest(){
//     char arr[3] = {'a', 'b','f'};
//     CharLinkedList list(arr, 3);   
//     list.insertInOrder('e');
//     assert(list.elementAt(2) == 'e');
// }

// void insertInOrderFrontTest(){
//     char arr[3] = {'b', 'c','f'};
//     CharLinkedList list(arr, 3);   
//     list.insertInOrder('a');
//     assert(list.elementAt(0) == 'a');
// }

// void insertInOrderBackTest(){
//     char arr[3] = {'a', 'b','f'};
//     CharLinkedList list(arr, 3);   
//     list.insertInOrder('x');
//     assert(list.elementAt(3) == 'x');
// }

// void insertInOrderAllCapsTest(){
//     char arr[3] = {'d', 'f','g'};
//     CharLinkedList list(arr, 3);   
//     list.insertInOrder('E');
//     assert(list.elementAt(1) == 'e');
// }

// void insertInOrderMixedCapsTest(){
//     char arr[3] = {'d', 'f','g'};
//     CharLinkedList list(arr, 3);   
//     list.insertInOrder('E');
//     assert(list.elementAt(1) == 'e');
// }

// void inOrderMiddleWithEqualTest(){
//     char arr[7] = {'b', 'b', 'd', 'e', 'f', 'g', 'h' };
//     CharLinkedList list(arr, 7);
//     list.insertInOrder('c');
//     assert (list.elementAt(2) == 'c');
// }

// void inOrderMiddleAndEqualTest(){
//     char arr[7] = {'b', 'b', 'd', 'e', 'f', 'g', 'h' };
//     CharLinkedList list(arr, 7);
//     list.insertInOrder('d');
//     assert (list.elementAt(3) == 'd');
// }


// void popFromFrontBasicTest(){
//     char arr[3] = {'a', 'b','f'};
//     CharLinkedList list(arr, 3);   
//     list.popFromFront();
//     assert(list.elementAt(0) == 'b');
// }

// void popFromFrontTestOneElem(){
//     char b = 'b';
//     CharLinkedList list(b);
//     list.popFromFront();
//     assert (list.isEmpty() == true);
// }

// void popFromFrontTestEmptyError(){
//     CharLinkedList list;
//     bool test = false;
//     std::string error_message = "";
//     try {
//         list.popFromFront();
//     } catch (const std::runtime_error& e) {
//         test = true;
//         error_message = e.what();   
//     }
//     assert (test == true);
//     assert (error_message == "cannot pop from empty LinkedList");
// }


// void popFromBackBasicTest(){
//     char arr[3] = {'a', 'b','f'};
//     CharLinkedList list(arr, 3);   
//     list.popFromBack();
//     assert(list.elementAt(1) == 'b');
// }

// void popFromBackTestOneElem(){
//     char b = 'b';
//     CharLinkedList list(b);
//     list.popFromBack();
//     assert (list.isEmpty() == true);
// }

// void popFromBackTestEmptyError(){
//     CharLinkedList list;
//     bool test = false;
//     std::string error_message = "";
//     try {
//         list.popFromBack();
//     } catch (const std::runtime_error& e) {
//         test = true;
//         error_message = e.what();   
//     }
//     assert (test == true);
//     assert (error_message == "cannot pop from empty LinkedList");
// }

// void removeAtBasicTest(){
//     char arr[3] = {'a', 'b','f'};
//     CharLinkedList list(arr, 3);   
//     list.removeAt(1);
//     assert(list.toString() == "[CharLinkedList of size 2 <<af>>]");
// }

// void removeAtTestRangeErrorOneElem(){
//     char b = 'b';
//     CharLinkedList list(b);
//     bool test = false;
//     std::string error_message = "";
//     try {
//         list.removeAt(10);
//     } catch (const std::range_error& e) {
//         test = true;
//         error_message = e.what();   
//     }
//     assert (test == true);
//     assert (error_message == "index (10) not in range [0..1)");
// }

// void removeAtTestRangeErrorEmpty(){
//     CharLinkedList list;
//     bool test = false;
//     std::string error_message = "";
//     try {
//         list.removeAt(10);
//     } catch (const std::range_error& e) {
//         test = true;
//         error_message = e.what();   
//     }
//     assert (test == true);
//     assert (error_message == "index (10) not in range [0..0)");
// }

// void removeAtTestOneElem(){
//     char b = 'b';
//     CharLinkedList list(b);
//     list.removeAt(0);
//     assert (list.isEmpty() == true);
// }

// void removeAtTestFront(){
//     char arr[3] = {'a', 'b','f'};
//     CharLinkedList list(arr, 3);  
//     list.removeAt(0);
//     assert (list.elementAt(0) == 'b');
// }

// void removeAtTestBack(){
//     char arr[3] = {'a', 'b','f'};
//     CharLinkedList list(arr, 3);  
//     list.removeAt(2);
//     assert (list.elementAt(1) == 'b');
// }

// void replaceAtTest(){
//     char arr[3] = {'a', 'b','c'};
//     CharLinkedList list(arr, 3);
//     list.replaceAt('e',2);
//     assert(list.toString() == "[CharLinkedList of size 3 <<abe>>]");
// }

// void replaceAtTestEmptyError(){
//     CharLinkedList list;
//     bool test = false;
//     std::string error_message = "";
//     try {
//         list.replaceAt('d', 10);
//     } catch (const std::range_error& e) {
//         test = true;
//         error_message = e.what();   
//     }
//     assert (test == true);
//     assert (error_message == "index (10) not in range [0..0)");
// }


// void replaceAtTestOutOfRangeError1(){
//     char arr[3] = {'a', 'b','c'};
//     CharLinkedList list(arr, 3);
//     bool test = false;
//     std::string error_message = "";
//     try {
//         list.replaceAt('d', 10);
//     } catch (const std::range_error& e) {
//         test = true;
//         error_message = e.what();   
//     }
//     assert (test == true);
//     assert (error_message == "index (10) not in range [0..3)");
// }

// void replaceAtTestOutOfRangeError2(){
//     char arr[3] = {'a', 'b','c'};
//     CharLinkedList list(arr, 3);
//     bool test = false;
//     std::string error_message = "";
//     try {
//         list.replaceAt('d', 3);
//     } catch (const std::range_error& e) {
//         test = true;
//         error_message = e.what();   
//     }
//     assert (test == true);
//     assert (error_message == "index (3) not in range [0..3)");
// }


// void concatenateTest(){
//     char arr[3] = {'a', 'b','c'};
//     CharLinkedList list(arr, 3); 
//     char newArr[3] = {'d', 'e','f'}; 
//     CharLinkedList list2(newArr, 3); 
//     list.concatenate(&list2);
//     assert(list.elementAt(3) == 'd');
//     assert (list.toString() == "[CharLinkedList of size 6 <<abcdef>>]");
// }

// void concatenateItselfTest(){
//     char arr[3] = {'a', 'b','c'};
//     CharLinkedList list(arr, 3); 
//     list.concatenate(&list);
//     assert (list.toString() == "[CharLinkedList of size 6 <<abcabc>>]");
// }

// void concatenateAddEmptyTest(){
//     char arr[3] = {'a', 'b','c'};
//     CharLinkedList list(arr, 3); 
//     CharLinkedList list2; 
//     list.concatenate(&list2);
//     assert (list.toString() == "[CharLinkedList of size 3 <<abc>>]");
// }

// void concatenateStartEmptyTest(){
//     CharLinkedList list; 
//     char newArr[3] = {'d', 'e','f'}; 
//     CharLinkedList list2(newArr, 3); 
//     list2.concatenate(&list);
//     assert (list2.toString() == "[CharLinkedList of size 3 <<def>>]");
// }




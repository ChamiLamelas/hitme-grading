/*
 *  CharLinkedList.cpp
 *  Jasmine Schaber
 *  02/04/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  This code contains an implementation of a CharLinkedList class.
 *
 */

#include "CharLinkedList.h"
#include <sstream>
#include <stdexcept>
using namespace std;

/*
 * name:      CharLinkedList
 * purpose:   constructor for an empty CharLinkedList
 * arguments: none
 * returns:   none
 * effects:   creation of empty list 
 */
CharLinkedList::CharLinkedList(){
    front = nullptr;
    back = nullptr;
    listSize = 0;
}

/*
 * name:      CharLinkedList
 * purpose:   constructor for a CharLinkedList with one node
 * arguments: a char c, representing the data of the node that will be made 
 * returns:   none
 * effects:   creation of CharLinkedList with one node
 */
CharLinkedList::CharLinkedList(char c){    
    front = newNode(c, nullptr, nullptr);
    back = front;
    listSize++;
}

/*
 * name:      CharLinkedList
 * purpose:   constructor for a CharLinkedList given a multi-elem array
 * arguments: an array arr[] of type char, representing a given static array of
 *            characters, and an integer size that gives the size of the array
 * returns:   none
 * effects:   creation of CharLinkedList that is essentially a copy of given
 *            array
 */
CharLinkedList::CharLinkedList(char arr[], int size){
    front = newNode(arr[size - 1], nullptr, nullptr);
    listSize++; back = front; 
    if (size == 1){
        return;
    } 
    for (int i = size - 2; i >= 0; i--){
        pushAtFront(arr[i]);
    }
}

/*
 * name:      CharLinkedList
 * purpose:   a copy constructor
 * arguments: a reference to another CharLinkedList
 * returns:   none
 * effects:   a deep copy of the CharLinkedList that was inputted
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other) {
    if (other.listSize == 0){
        front = nullptr; back = nullptr; listSize = 0;
        return; 
    }
    front = newNode(other.back->data, nullptr, nullptr);
    back = front; listSize++;
    Node *iteration = other.back->previous;
    if (other.listSize == 1){
        return;
    } 
    while (iteration != nullptr){
        pushAtFront(iteration->data);
        iteration = iteration->previous;
    }
}

/*
 * name:      ~CharLinkedList
 * purpose:   destructor for CharLinkedList
 * arguments: none
 * returns:   none
 * effects:   deletion of the CharLinkedList
 */
CharLinkedList::~CharLinkedList(){
    privateDestructor(front);
}

/*
 * name:      &CharLinkedList
 * purpose:   copy constructor that deletes the old CharLinkedList and keeps  
 *            the copy
 * arguments: a reference to another CharLinkedList
 * returns:   a pointer to the new CharLinkedList
 * effects:   deletion of the pre-existing CharLinkedList, creation of the deep
 *            copy
 */
CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other){
    if (this != &other){
        clear();
        if (other.listSize == 0) {
            return *this;
        }
        front = newNode(other.back->data, nullptr, nullptr);
        back = front; listSize++;
        Node *iteration = other.back->previous;
        if (other.listSize == 1){
            return *this;
        } 
        while (iteration != nullptr){
            pushAtFront(iteration->data);
            iteration = iteration->previous;
        }
    } else if (other.front == nullptr){
        clear();
    }
    return *this;
}

/*
 * name:      isEmpty
 * purpose:   check if the CharLinkedList is empty or not
 * arguments: none
 * returns:   boolean value depending on whether the CharLinkedList is empty 
 *            or not
 * effects:   none
 */
bool CharLinkedList::isEmpty(){
    if (listSize == 0){
        return true;
    } else {
        return false; 
    }
}

/*
 * name:      clear
 * purpose:   clear out the CharLinkedList and set it to empty
 * arguments: none
 * returns:   none
 * effects:   CharLinkedList is cleared out
 */
void CharLinkedList::clear(){
    if (front == nullptr){
        return;
    } else {
        privateDestructor(front);
        front = nullptr; back = nullptr; listSize = 0;
    }
}

/*
 * name:      size
 * purpose:   check the size of the CharLinkedList
 * arguments: none
 * returns:   integer value depending on the size of the list
 * effects:   none
 */
int CharLinkedList::size() const {
    return listSize;
}

/*
 * name:      first
 * purpose:   check what the data of the first node of the CharLinkedList is
 * arguments: none
 * returns:   char depending on the data of the first node
 * effects:   throws a runtime error if the list is empty
 */
char CharLinkedList::first()const {
    if (listSize != 0){
        return front->data;
    } 
    throw std::runtime_error("cannot get first of empty LinkedList");
}

/*
 * name:      first
 * purpose:   check what the data of the last node of CharLinkedList
 * arguments: none
 * returns:   char depending on the data of the last node
 * effects:   throws a runtime error if the list is empty
 */
char CharLinkedList::last()const {
    if (listSize != 0){
        return back->data;
    } 
    throw std::runtime_error("cannot get last of empty LinkedList");
}

/*
 * name:      elementAt
 * purpose:   check what the char is at a given index in the CharLinkedList
 * arguments: an integer index, representing the index of the node that the
 *            user wants to see
 * returns:   char depending on the data of the given node
 * effects:   throws a runtime error if the CharLinkedList is empty or the  
 *            given index is not in range
 */
char CharLinkedList:: elementAt(int index) const {
    if (listSize == 1 or (index == 0 and listSize > 0)){
        return front->data;
    } else if (index < listSize and index > 0){
        Node *elem = elementAtRecur(front, index);
        return elem->data;
    } else {
        std::stringstream error;
        error << "index (" << index << ") not in range [0.." << listSize << ")";
        throw std::range_error(error.str());            
    }
}

/*
 * name:      toString
 * purpose:   output the CharLinkedList as a string through sstream
 * arguments: none
 * returns:   a string through sstream
 * effects:   CharLinkedList as a string through sstream
 */
std::string CharLinkedList::toString() const {
    std::stringstream ss;
    ss << "[CharLinkedList of size " << listSize <<" <<";
    if (listSize != 0){
        for (int i = 0; i < listSize; i++){
            Node *hold = elementAtRecur(front, i);
            ss << hold->data;
        }
    }
    ss << ">>]";
    return ss.str();
}

/*
 * name:      toReverseString
 * purpose:   output the CharLinkedList as a reversed string through sstream
 * arguments: none
 * returns:   a reversed string through sstream
 * effects:   CharLinkedList as a reversed string through sstream
 */
std::string CharLinkedList::toReverseString() const {
    std::stringstream ss;
    ss << "[CharLinkedList of size " << listSize <<" <<";
    Node *hold = back;
    while (hold != nullptr){
        ss << hold->data;
        hold = hold->previous;
    }
    ss << ">>]";
    return ss.str();
}

/*
 * name:      pushAtBack
 * purpose:   add a node to the end of the list
 * arguments: char c that represents the element the user would like to add
 * returns:   none
 * effects:   new back node
 */
void CharLinkedList::pushAtBack(char c){
    if (listSize == 0){
        front = newNode(c, nullptr, nullptr);
        back = front; listSize++;
        return;
    }
    Node *hold = newNode(c, back, nullptr);
    back->next = hold;
    back = hold;
    listSize++;
}

/*
 * name:      pushAtFront
 * purpose:   add an element to the front of the lsit
 * arguments: char c that represents the element the user would like to add
 * returns:   none
 * effects:   new front node 
 */
void CharLinkedList::pushAtFront(char c){
    if (listSize == 0){
        front = newNode(c, nullptr, nullptr);
        back = front; listSize++;
        return;
    }
    Node *hold = newNode(c, nullptr, front);
    front->previous = hold;
    front = hold;
    listSize++;
}

/*
 * name:      insertAt
 * purpose:   add a node where the user indicates
 * arguments: char c that represents the element the user would like to add,
 *            and integer index that represents where the user will add it
 * returns:   none
 * effects:   new node where the user indicates,
 *            throws an error if the given index is not within range
 */
void CharLinkedList::insertAt(char c, int index){
    if (index == listSize){
        pushAtBack(c);
    } else if(index == 0){
        pushAtFront(c);
    } else if (index < listSize and index > 0){
        Node *holdFront = elementAtRecur(front, index - 1);
        Node *holdBack = holdFront->next;
        Node *created = newNode(c, holdFront, holdBack);
        holdFront->next = created;
        holdBack->previous = created;
        listSize++;
    } else {
        std::stringstream error;
        error << "index (" << index << ") not in range [0.." << listSize << "]";
        throw std::range_error(error.str());   
    }
}

/*
 * name:      insertInOrder
 * purpose:   add an element in a position determined by alphabetical order
 * arguments: char c that represents the element the user would like to add,
 * returns:   none
 * effects:   new node in the correct location (alphabetical)
 */
void CharLinkedList::insertInOrder(char c){
    if (c >= 'A' and c <= 'Z'){
        c += 32;
    }
    if ((listSize == 0) or (front->data >= c)){
        pushAtFront(c);
        return;
    } else if (back->data <= c){
        pushAtBack(c);
        return;
    } else {
        Node *holdFront = inOrderRecur(front, c);
        Node *holdBack = holdFront->next;
        Node *created = newNode(c, holdFront, holdBack);
        holdFront->next = created;
        holdBack->previous = created;
        listSize++;
    }
}

/*
 * name:      popFromFront
 * purpose:   gets rid of the first element in the CharLinkedList
 * arguments: none
 * returns:   none
 * effects:   deletion of former front node
 */
void CharLinkedList::popFromFront(){
    if (listSize == 0){
        throw std::runtime_error("cannot pop from empty LinkedList");
    } else if (listSize == 1){
        clear();
    } else {
        Node *hold = front;
        front = front->next;
        front->previous = nullptr;
        delete hold;
        listSize--;
    }
}

/*
 * name:      popFromBack
 * purpose:   gets rid of the last element in the CharLinkedList
 * arguments: none
 * returns:   none
 * effects:   deletion of former back node 
 */
void CharLinkedList::popFromBack(){
    if (listSize == 0){
        throw std::runtime_error("cannot pop from empty LinkedList");
    } else if (listSize == 1){
        clear();
    } else {
        Node *hold = back;
        back = back->previous;
        back->next = nullptr;
        delete hold;
        listSize--;
    }
}

/*
 * name:      removeAt
 * purpose:   gets rid of an element at a given index
 * arguments: integer index representing the location of the element the user
 *            wants to have removed
 * returns:   none
 * effects:   deletion of node where user indicates,
 *            throws an error if the index is not in range or if the list is 
 *            empty
 */
void CharLinkedList::removeAt(int index){
    if ((index >= (listSize) or index < 0) or (listSize == 0)){
        std::stringstream error;
        error << "index (" << index << ") not in range [0.." << listSize << ")";
        throw std::range_error(error.str()); 
    } else if (index == 0) { 
        popFromFront();    
    } else if (index == listSize - 1){
        popFromBack();
    } else {
        Node *hold = elementAtRecur(front, index);
        Node *holdFront = hold->previous;
        Node *holdBack = hold->next;
        holdFront->next = holdBack;
        holdBack->previous = holdFront;
        delete hold; listSize--;
    }
}

/*
 * name:      replaceAt
 * purpose:   replaces an element at a given index
 * arguments: integer index representing the location of the element the user
 *            wants to have replaced, char c representing the new element the 
 *            user is replacing the old one with
 * returns:   none
 * effects:   updated data for node at indicated location,
 *            throws an error if the index is not in range or if the 
 *            list is empty
 */
void CharLinkedList::replaceAt(char c, int index){
    if ((index > (listSize - 1) or index < 0) or (listSize == 0)){
        std::stringstream error;
        error << "index (" << index << ") not in range [0.." << listSize << ")";
        throw std::range_error(error.str()); 
        return;           
    }
    if (index == 0){
        front->data = c;
    } else if (index == listSize - 1){
        back->data = c;
    } else {
        Node *hold = elementAtRecur(front, index);
        hold->data = c;
    }
}

/*
 * name:      concatenate
 * purpose:   edits the current list by adding a given list to the end of it
 * arguments: pointer to CharLinkedList other, representing a given
 *            CharLinkedList
 * returns:   none
 * effects:   updated CharLinkedList
 */
void CharLinkedList::concatenate(CharLinkedList *other){
    if (other->listSize == 0){
        return;
    //if you're adding the array to itself (ie. cat becomes catcat)
    } else if (this == other) {
        CharLinkedList temp(*this);  
        for (int i = 0; i < temp.listSize; i++) {
            Node *hold = temp.elementAtRecur(temp.front, i);
            pushAtBack(hold->data);
        }
    } else {
        for (int i = 0; i < other->listSize; i++) {
            Node *hold = other->elementAtRecur(other->front, i);
            pushAtBack(hold->data);
        }
    }
}

 /* name:      newNode
 * purpose:   creates a new node based off of user input
 * arguments: character c for data of the node, Node pointer prev pointing to 
 *            the node before it, and NOde pointer next pointing to the node
 *            after it
 * returns:   pointer to the newly created node
 * effects:   new node 
 */
CharLinkedList::Node* CharLinkedList::newNode(char c, Node *prev, Node *next){
    Node *created = new Node;
    created->data = c;
    created->next = next;
    created->previous = prev;
    return created;
}

 /* name:     privateDestructor
 * purpose:   recursive function that deletes every node in the list
 * arguments: Node pointer curr, which must point to the front of the list, 
 *            because it deletes everything after that  
 * returns:   none
 * effects:   list deleted
 */
void CharLinkedList:: privateDestructor(Node *curr){
    if (curr == nullptr){
        return;
    } else {
        Node *next = curr->next;
        delete curr;
        privateDestructor(next);
    }
}


 /* name:     elementAtRecur
 * purpose:   recursive function that locates the node at a given index
 * arguments: Node pointer curr, which must point to the front of the list, 
 *            because it always goes to the next node and reduces the index
 *            based off of that. integer index for the user requested index 
 * returns:   Node pointer to the node at the given index
 * effects:   none
 */
CharLinkedList:: Node* CharLinkedList:: elementAtRecur(Node *curr, int index) 
const {
    if (index == 0){
        return curr;
    } else {
        index--;
        return elementAtRecur(curr->next, index);
    }
}

 /* name:     elementAtRecur
 * purpose:   recursive function that locates the node where a given character 
 *            should go based off of alphabetical order
 * arguments: Node pointer curr, which must point to the front of the list, 
 *            because it always goes to the next node to search. character c 
 *            for the user provided character 
 * returns:   Node pointer to the node that the provided char should go after
 * effects:   none
 */
CharLinkedList:: Node* CharLinkedList:: inOrderRecur(Node *curr, char c)
const {
    if (c >= curr->data and c <= curr->next->data){
        return curr;
    } else {
        return inOrderRecur(curr->next, c);
    }
}


/*
 *  CharLinkedList.h
 *  Jasmine Schaber
 *  02/04/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Interface for a CharLinkedList with dynamically allocated memory. Elements
 *  can be added or deleted, with functions like pushAtBack(), popFromFront(),
 *  insertAt(), etc. Each list can also be spelled out through the sstream.
 *  Contains some private recursive helper functions to facilitate 
 *  implementation. 
 *
 */

#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H
#include <sstream>

class CharLinkedList {
public:
    CharLinkedList();
    CharLinkedList(char c);
    ~CharLinkedList();
    CharLinkedList(char arr[], int size);
    CharLinkedList(const CharLinkedList &other);
    CharLinkedList &operator=(const CharLinkedList &other);
    bool isEmpty();
    void clear();
    int size() const;
    char first() const;
    char last() const;
    char elementAt(int index) const;
    std::string toString() const;
    std::string toReverseString() const;
    void pushAtFront(char c);
    void pushAtBack(char c);
    void insertAt(char c, int index);
    void insertInOrder(char c);
    void popFromFront();
    void popFromBack();
    void removeAt(int index);
    void replaceAt(char c, int index);
    void concatenate(CharLinkedList *other);

private:
    struct Node {
        char data;
        Node *previous;
        Node *next;
    };

    Node* front; 
    Node* back;
    int listSize = 0;
    Node* newNode(char c, Node *prev, Node *next);
    void privateDestructor(Node *curr);
    Node* elementAtRecur(Node *curr, int index) const;
    Node* inOrderRecur(Node *curr, char c) const;

};

#endif

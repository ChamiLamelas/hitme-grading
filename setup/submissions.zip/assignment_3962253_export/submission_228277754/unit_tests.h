/*
 *  unit_tests.h
 *  Aadya Akkipeddi
 *  2/5/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  Purpose: Uses Matt Russell's unit_test framework to test the 
 *           CharLinkedList class thoroughly.
 *
 */

#include "CharLinkedList.h"
#include <cassert>

/********************************************************************\
*                       CHAR LINKED LIST TESTS                        *
\********************************************************************/

// PRIVATE HELPER FUNCTION TEST:
// // Tests the custom Node constructor to see if all of its fields are
// // set to the expected values, by checking if the char at the new 
// // node is what is expected to be there
// void newNode_test() {
//     char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
//     char *first_char = &test_arr[0];
//     CharLinkedList test_list;
//     CharLinkedList::Node *test = 
//     test_list.newNode(first_char, nullptr, nullptr);
//     assert(test->data == test_arr[0]);
//     delete test;
// }

// Tests if the overloaded assignment operator is functioning properly
// by checking if two CharLinkedLists are equal to each other when they're
// set equal to each other
void test_operator() {
    CharLinkedList test_list;
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    char arr[5] = {'h', 'e', 'l', 'l', 'o'};
    CharLinkedList test_list2(test_arr, 9);
    CharLinkedList test_list3(arr, 5);
    test_list2 = test_list3;
    assert(test_list2.toString() == test_list3.toString());
}

// Tests two constructors for a CharLinkedList, one that takes in both an array
// and a integer representing the number of elements in the array, as well as 
// the copy constructor, which takes in a &CharLinkedList, to produce another 
// copy of it.  
void test_deep_copy() {
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list2(test_arr, 9);
    CharLinkedList test_list3(test_list2);
    assert(test_list3.toString() == "[CharLinkedList of size 9 <<abczdefgh>>]");
}

// Tests if the default constructor is initializing an empty CharLinkedList
// as it is supposed to, and also simaltaneously testing to see if the 
// isEmpty() function is working properly, as a CharLinkedList initialized
// using the default constructor should be empty.
void is_empty_correct() {
    CharLinkedList test_list;
    assert(test_list.isEmpty());
}

// Tests the false conditions of the isEmpty() function which are testing
// if CharLinkedLists with a single element are empty or if CharLinkedLists
// with multiple elements are empty (both should be false), thus also 
// implicitly testing whether or not the constructors for the respective
// LinkedLists are working
void is_empty_false() {
    CharLinkedList test_list1('c');
    assert(not test_list1.isEmpty());
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    char test_arr2[1] = {'a'};
    CharLinkedList test_list2(test_arr, 9); 
    CharLinkedList test_list3(test_arr2, 1);
    assert(not test_list2.isEmpty());
    assert(not test_list3.isEmpty());
}

// Tests the clear function on all types of CharLinkedLists by checking if
// a CharLinkedList after using clear() is empty. Also implicitly tests the 
// destructor's functionality as well, since the destructor relies solely on
// this function
void clear_test() {
    CharLinkedList test_list;
    test_list.clear();
    assert(test_list.isEmpty());
    CharLinkedList test_list1('a');
    test_list1.clear();
    assert(test_list1.isEmpty());
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list2(test_arr, 9);
    test_list2.clear();
    assert(test_list2.isEmpty());
}

// PRIVATE HELPER FUNCTION TEST:
// // Tests the private helper function, remove() on all types of 
// // CharLinkedLists by checking if a CharLinkedList after using remove() 
// // is empty
// void remove_test() {
//     CharLinkedList test_list;
//     test_list.remove(test_list.front);
//     assert(test_list.front == nullptr);
// }


// Tests if the size() function is correctly outputting the number of items
// stored in the CharLinkedList, and simaltaneously tests if the constructor 
// for the single element CharLinkedList is functioning properly (by checking
// if the size of a single element CharLinkedList is 1).
void size_test() {
    CharLinkedList test_list;
    assert(test_list.size() == 0);
    CharLinkedList test_list1('a');
    assert(test_list1.size() == 1);
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list2(test_arr, 9);
    assert(test_list2.size() == 9);
}

// Tests the first() function by making sure it outputs the expected first
// character in a CharLinkedList.
void first_correct() {
    CharLinkedList test_list1('a');
    assert(test_list1.first() == 'a');
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list2(test_arr, 9);
    assert(test_list2.first() == 'a');
}

// Tests if runtime_error message of the first() function is outputted
// for an empty CharLinkedList.
void first_false() {
    bool runtime_error_thrown = false;
    std::string error_message = "";
    CharLinkedList test_list;
    try {
        test_list.first();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "cannot get first of empty LinkedList");
}

// Tests if the correct last element of a CharLinkedList is outputted when
// the function last() is called on CharLinkedLists of different sizes.
void last_correct() {
    CharLinkedList test_list1('a');
    assert(test_list1.last() == 'a');
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list2(test_arr, 9);
    assert(test_list2.last() == 'h');
}

// Tests if the runtime_error message of the last() function is outputted
// for an empty CharLinkedList.
void last_false() {
    bool runtime_error_thrown = false;
    std::string error_message = "";
    CharLinkedList test_list;
    try {
        test_list.last();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "cannot get last of empty LinkedList");

}

// Tests if the expected character at the specified index is outputted
// when the function elementAt(int index) is called.
void elementAt_correct() {
    CharLinkedList test_list1('a');
    assert(test_list1.elementAt(0) == 'a');
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list2(test_arr, 9);
    assert(test_list2.elementAt(0) == 'a');
    assert(test_list2.elementAt(8) == 'h');
    assert(test_list2.elementAt(3) == 'z');
    assert(test_list2.elementAt(6) == 'f');
}

// Tests the case where elementAt(int index) is called on an empty 
// CharLinkedList and if the range_error message is being outputted. 
void elementAt_false_emptyList0() {
    bool range_error_thrown = false;
    std::string error_message = "";
    CharLinkedList test_list;
    try {
        test_list.elementAt(0);   
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (0) not in range [0..0)"); 
}

// Test the case where the index given to elementAt is an invalid 
// negative number for an empty CharLinkedList
void elementAtNegative_false_emptyList() {
    bool range_error_thrown = false;
    std::string error_message = "";
    CharLinkedList test_list;
    
    try {
        test_list.elementAt(-1);   
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (-1) not in range [0..0)"); 
}

// Test the case where the index given to elementAt is an invalid 
// negative number for a CharLinkedList with one element, and if the 
// range_error message is being outputted
void elementAtNegative_false_oneElemList() {
    bool range_error_thrown = false;
    std::string error_message = "";
    CharLinkedList test_list1('a');
    
    try {
        test_list1.elementAt(-1);   
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (-1) not in range [0..1)"); 
}

// Test the case where the index given to elementAt is out of bounds
// for a CharLinkedList of one element, and if the range_error message is 
// being outputted
void elementAt_false_oneElemList() {
    bool range_error_thrown = false;
    std::string error_message = "";
    CharLinkedList test_list1('a');
    
    try {
        test_list1.elementAt(2);   
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (2) not in range [0..1)"); 
}

// Test the case where the index given to elementAt is an invalid 
// negative number for an CharLinkedList with multiple elements, and if
// the range_error message is being outputted
void elementAtNegative_false() {
    bool range_error_thrown = false;
    std::string error_message = "";
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list2(test_arr, 9);
    
    try {
        test_list2.elementAt(-1);   
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (-1) not in range [0..9)"); 
}

// Test the case where the index given to elementAt is too big
// for an CharLinkedList with multiple elements, and if the range_error
// message is being outputted
void elementAt_false_bigNum() {
    bool range_error_thrown = false;
    std::string error_message = "";
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list2(test_arr, 9);
    
    try {
        test_list2.elementAt(20);   
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (20) not in range [0..9)"); 
}

// Test the case where the index given to elementAt the size of the 
// CharLinkedList, and if the range_error message is being outputted
void elementAtSize_false() {
    bool range_error_thrown = false;
    std::string error_message = "";
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list2(test_arr, 9);
    
    try {
        test_list2.elementAt(9);   
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (9) not in range [0..9)"); 
}

// PRIVATE HELPER FUNCTION TEST:
// // Test the findNode() function to see if it is outputting the right
// // node, by seeing if it is outputting the expected char at that node
// void findNode_test() {
//     CharLinkedList test_list1('a');
//     assert(test_list1.findNode(0, 0, test_list1.front)->data == 'a');
//     char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
//     CharLinkedList test_list2(test_arr, 9);
//     assert(test_list2.findNode(6, 0, test_list2.front)->data == 'f');
// }

// Tests if the outputted string from the function toString() is the 
// expected string of a CharLinkedList
void toString_test() {
    CharLinkedList test_list1;
    assert(test_list1.toString() == "[CharLinkedList of size 0 <<>>]");
    CharLinkedList test_list2('a');
    assert(test_list2.toString() == "[CharLinkedList of size 1 <<a>>]");
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);
    assert(test_list.toString() == "[CharLinkedList of size 9 <<abczdefgh>>]");
}

// Tests if the outputted string from the function toReverseString() is the 
// expected string of a CharLinkedList
void toReverseString_test() {
    CharLinkedList test_list;
    assert(test_list.toReverseString() == "[CharLinkedList of size 0 <<>>]");
    CharLinkedList test_list1('a');
    assert(test_list1.toReverseString() == "[CharLinkedList of size 1 <<a>>]");
    char test_arr[7] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f',};
    CharLinkedList test_list2(test_arr, 7);
    assert(test_list2.toReverseString() 
    == "[CharLinkedList of size 7 <<fedzcba>>]");
}

// Tests the pushAtBack() function, by checking if the updated CharLinkedList's
// size and elements inside have been incremented correctly (checked using 
// toString() function to print the elements in the CharLinkedList)
void pushAtBack_test() {
    CharLinkedList test_list;
    test_list.pushAtBack('a');
    assert(test_list.toString() == "[CharLinkedList of size 1 <<a>>]");
    CharLinkedList test_list1('a');
    test_list1.pushAtBack('b');
    assert(test_list1.toString() == "[CharLinkedList of size 2 <<ab>>]");
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list2(test_arr, 9);
    test_list2.pushAtBack('i');
    assert(test_list2.toString() 
        == "[CharLinkedList of size 10 <<abczdefghi>>]");
}

// Tests pushAtFront() function, by checking if the updated CharLinkedList's
// size and elements inside have been incremented correctly (checked using 
// toString() function to print the elements in the CharLinkedList)
void pushAtFront_test() {
    CharLinkedList test_list;
    test_list.pushAtFront('a');
    assert(test_list.toString() == "[CharLinkedList of size 1 <<a>>]");
    CharLinkedList test_list1('a');
    test_list1.pushAtFront('b');
    assert(test_list1.toString() == "[CharLinkedList of size 2 <<ba>>]");
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list2(test_arr, 9);
    test_list2.pushAtFront('i');
    assert(test_list2.toString() 
        == "[CharLinkedList of size 10 <<iabczdefgh>>]");
}

// Tests correct insertion into an empty LinkedList.
// Afterwards, size should be 1 and element at index 0
// should be the element we inserted.
void insertAt_empty_correct() { 
    CharLinkedList test_list;
    test_list.insertAt('a', 0);
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');
}

// Tests incorrect insertion into an empty LinkedList.
// Attempts to call insertAt for index > but not = 0.
// This should result in an std::range_error being raised.
void insertAt_empty_incorrect() {
    bool range_error_thrown = false;
    std::string error_message = "";

    CharLinkedList test_list;
    try {
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0]");
}

// Tests correct insertAt for front of 1-element list.
void insertAt_front_singleton_list() {
    CharLinkedList test_list('a');
    test_list.insertAt('b', 0);
    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'a');
}

// Tests correct insertAt for back of 1-element list.
void insertAt_back_singleton_list() {
    CharLinkedList test_list('a');
    test_list.insertAt('b', 1);
    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');   
}

// Tests calling insertAt for a large number of elements.
// Not only does this test insertAt, it also checks that
// array expansion works correctly.
void insertAt_many_elements() {
    CharLinkedList test_list;
    for (int i = 0; i < 1000; i++) {
        test_list.insertAt('a', i);
    }
    assert(test_list.size() == 1000);
    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
}

// Tests insertion into front of a larger list
void insertAt_front_large_list() {
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);
    test_list.insertAt('y', 0);
    assert(test_list.size() == 10);
    assert(test_list.elementAt(0) == 'y');
    assert(test_list.toString() == 
    "[CharLinkedList of size 10 <<yabczdefgh>>]");

}

// Tests insertion into the back of a larger list
void insertAt_back_large_list() {
    char test_arr[10] = { 'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 10);  
    test_list.insertAt('x', 10);
    assert(test_list.size() == 11);
    assert(test_list.elementAt(10) == 'x');
    assert(test_list.toString() == 
    "[CharLinkedList of size 11 <<yabczdefghx>>]"); 

}

// Tests insertion into the middle of a larger list
void insertAt_middle_large_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);
    test_list.insertAt('z', 3);
    assert(test_list.size() == 9);
    assert(test_list.elementAt(3) == 'z');
    assert(test_list.toString() == "[CharLinkedList of size 9 <<abczdefgh>>]");

}

// Tests out-of-range insertion for a non-empty list.
void insertAt_nonempty_incorrect() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);
    bool range_error_thrown = false;
    std::string error_message = "";
    try {
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8]"); 
}

// Tests the insertInOrder() function is inserting a character in the 
// correct spot in the CharLinkedList (for empty, single-element, and 
// multi-element CharLinkedLists) using toString() to print out the contents
// of the updated CharLinkedList, to see if the expected insertion has occured
void insertInOrder_correct() {
    CharLinkedList test_list;
    test_list.insertInOrder('a');
    assert(test_list.toString() == "[CharLinkedList of size 1 <<a>>]");
    CharLinkedList test_list1('a');
    test_list1.insertInOrder('c');
    assert(test_list1.toString() == "[CharLinkedList of size 2 <<ac>>]");
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list2(test_arr, 8);
    test_list2.insertInOrder('i');
    assert(test_list2.toString() == 
    "[CharLinkedList of size 9 <<abcdefghi>>]");
    test_list2.insertInOrder('c');
    assert(test_list2.toString() == 
    "[CharLinkedList of size 10 <<abccdefghi>>]");
}

// Tests the popFromFront() function to see if it is correctly removing the 
// first element of a CharLinkedList, by using toString() to print out the
// updated CharLinkedList and seeing if it matches the expected CharLinkedList
void popFromFront_correct() {
    CharLinkedList test_list1('a');
    test_list1.popFromFront();
    assert(test_list1.toString() == "[CharLinkedList of size 0 <<>>]");
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list2(test_arr, 8);
    test_list2.popFromFront();
    assert(test_list2.toString() == "[CharLinkedList of size 7 <<bcdefgh>>]");
    test_list2.popFromFront();
    assert(test_list2.toString() == "[CharLinkedList of size 6 <<cdefgh>>]");
}

// Tests if the corresponding runtime_error message of popFromFront()
// is being outputted when given an empty CharLinkedList to remove an element
// from the front
void popFromFront_false() {
    bool runtime_error_thrown = false;
    std::string error_message = "";
    
    CharLinkedList test_list;
    try {
        test_list.popFromFront();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

// Tests if popFromBack() is correctly removing the last element of a 
// CharLinkedList, by using toString() to print out the elements of the 
// updated CharLinkedList, and comparing that result with the expected result
void popFromBack_correct() {
    CharLinkedList test_list1('a');
    test_list1.popFromBack();
    assert(test_list1.toString() == "[CharLinkedList of size 0 <<>>]");
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list2(test_arr, 8);
    test_list2.popFromBack();
    assert(test_list2.toString() == "[CharLinkedList of size 7 <<abcdefg>>]");
    test_list2.popFromBack();
    assert(test_list2.toString() == "[CharLinkedList of size 6 <<abcdef>>]");
}

// Tests if the corresponding runtime_error message of popFromBack()
// is being outputted when given an empty CharLinkedList to remove an element
// from
void popFromBack_false() {
    bool runtime_error_thrown = false;
    std::string error_message = "";
    
    CharLinkedList test_list;
    try {
        test_list.popFromBack();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

// Tests if the removeAt() function is removing the correct element at the 
// specified index, by using toString() to print out the elements of the 
// updated CharLinkedList, and comparing that result with the expected result
void removeAt_correct() {
    CharLinkedList test_list1('a');
    test_list1.removeAt(0);
    assert(test_list1.toString() == "[CharLinkedList of size 0 <<>>]");
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list2(test_arr, 8);
    test_list2.removeAt(2);
    assert(test_list2.toString() == "[CharLinkedList of size 7 <<abdefgh>>]");
    test_list2.removeAt(6);
    assert(test_list2.toString() == "[CharLinkedList of size 6 <<abdefg>>]");
}

// Tests the case where removeAt(int index) is called on an empty 
// CharLinkedList and if the range_error message is being outputted. 
void removeAt_empty_false() {
    bool range_error_thrown = false;
    std::string error_message = "";
    CharLinkedList test_list;
    
    try {
        test_list.removeAt(1);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (1) not in range [0..0)"); 
}

// Tests the case where removeAt(int index) is called on a CharLinkedList 
// with a size that is smaller than the index, and if the range_error message
// is being outputted.
void removeAt_index_false() {
    bool range_error_thrown = false;
    std::string error_message = "";
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list2(test_arr, 8);
    
    try {
        test_list2.removeAt(10);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (10) not in range [0..8)"); 
}

// Tests the case where elementAt(int index) is called on a CharLinkedList of
// one element, with an inputted index that is bigger than the size of the 
// CharLinkedList, and if the range_error message is being outputted. 
void removeAt_oneElem_false() {
    bool range_error_thrown = false;
    std::string error_message = "";
    CharLinkedList test_list1('a');
    
    try {
        test_list1.removeAt(10);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (10) not in range [0..1)"); 
}

// Tests if the replaceAt() function is replacing the correct element at the 
// specified index, by using toString() to print out the elements of the 
// updated CharLinkedList, and comparing that result with the expected result
void replaceAt_correct() {
    CharLinkedList test_list1('a');
    test_list1.replaceAt('b', 0);
    cerr << test_list1.toString();
    assert(test_list1.toString() == "[CharLinkedList of size 1 <<b>>]");
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list2(test_arr, 8);
    test_list2.replaceAt('d', 2);
    assert(test_list2.toString() == "[CharLinkedList of size 8 <<abddefgh>>]");
    test_list2.replaceAt('c', 2);
    assert(test_list2.toString() == "[CharLinkedList of size 8 <<abcdefgh>>]");
    test_list2.replaceAt('z', 7);
    assert(test_list2.toString() == "[CharLinkedList of size 8 <<abcdefgz>>]");
}

// Tests the case where replaceAt(int index) is called on an empty  
// CharLinkedList, with an inputted index that is equal to the size of
// the CharLinkedList, and if the range_error message is being outputted. 
void replaceAt_empty_false() {
    bool range_error_thrown = false;
    std::string error_message = "";
    CharLinkedList test_list;
    
    try {
        test_list.replaceAt('a', 0);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (0) not in range [0..0)"); 
}

// Tests the case where replaceAt(int index) is called on a CharLinkedList of
// multiple elements, with an inputted index that is bigger than the size of 
// the CharLinkedList, and if the range_error message is being outputted. 
void replaceAt_index_false() {
    bool range_error_thrown = false;
    std::string error_message = "";
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list2(test_arr, 8);
    
    try {
        test_list2.replaceAt('b', 10);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (10) not in range [0..8)"); 
}

// Tests the case where replaceAt(int index) is called on a CharLinkedList of
// one element, with an inputted index that is bigger than the size of the 
// CharLinkedList, and if the range_error message is being outputted. 
void replaceAt_oneElem_false() {
    bool range_error_thrown = false;
    std::string error_message = "";
    CharLinkedList test_list1('a');
    
    try {
        test_list1.replaceAt('a', 10);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (10) not in range [0..1)"); 
}

// Tests if the concatenate() function is outputting a new, combined
// CharLinkedList by using toString() to print out the elements of the 
// updated CharLinkedList, and comparing that result with the expected result
void concatenate_test() {
    CharLinkedList test_list;
    test_list.concatenate(&test_list);
    assert(test_list.toString() == "[CharLinkedList of size 0 <<>>]");
    CharLinkedList test_list1('a');
    test_list1.concatenate(&test_list);
    assert(test_list1.toString() == "[CharLinkedList of size 1 <<a>>]");
    test_list1.concatenate(&test_list1);
    assert(test_list1.toString() == "[CharLinkedList of size 2 <<aa>>]");
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list2(test_arr, 8);
    test_list1.concatenate(&test_list2);
    assert(test_list1.toString() 
    == "[CharLinkedList of size 10 <<aaabcdefgh>>]");
}

/*
 *  CharLinkedList.cpp
 *  Name: Aadya Akkipeddi (aakkip01)
 *  Date: 2/4/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Purpose: Implementing a version of a doubly linked list data structure 
 *           that contains characters and also writing/testing the 
 *           corresponding functions for the linked list. 
 *
 */

#include "CharLinkedList.h"
#include <sstream>
#include <string>
#include <iostream>

using namespace std;

/*
 * name:      custom Node constructor
 * purpose:   takes in arguments to initialize a new node
 * arguments: takes in a pointer to a new char that you want the new node to
              hold, a pointer to the next node that the new node will point to
              and a pointer to the previous node that the new node will point
              to
 * returns:   none
 * effects:  sets all fields to the inputted values
 */
CharLinkedList::Node *CharLinkedList::newNode(char *new_data, 
Node *new_next, Node *new_prev) {
   Node *new_node = new Node;
   new_node->data = *new_data;
   new_node->next = new_next;
   new_node->prev = new_prev;

   return new_node;
}

/*
 * name:      CharLinkedList default constructor
 * purpose:   initialize an empty CharLinkedList
 * arguments: none
 * returns:   none
 * effects:  sets all fields to their null/empty values
 */
CharLinkedList::CharLinkedList() {
   front = nullptr;
   tail = nullptr;
   numItems = 0;
}


/*
 * name:      CharLinkedList constructor 
 * purpose:   initialize a CharLinkedList with a single element
 * arguments: takes in a single character
 * returns:   none
 * effects:  sets size to 1, and adds the node with a single char
             into the LinkedList
 */
CharLinkedList::CharLinkedList(char c) {
    front = newNode(&c, nullptr, nullptr);
    tail = front;
    numItems = 1;
}

/* 
 * name:    CharLinkedList constructor 
 * purpose:   initialize a CharLinkedList with multiple elements
 * arguments: takes in a character array and the integer size of the array
 * returns:   none
 * effects:  sets the numItems to size, and initializes each node of the 
             LinkedList with the given char
 */
CharLinkedList::CharLinkedList(char arr[], int size) {
    numItems = 0;
    front = nullptr;
    tail = nullptr;
    for (int i = 0; i < size; i++) {
        this->pushAtBack(arr[i]);
    }
}

/*
 * name: CharLinkedList assignment constructor 
 * purpose:   to recycle storage associated with 
 * arguments: takes in the address of another CharLinkedList
 * returns:   none
 * effects:  sets the numItems to size, the capacity to size, and sets data 
             copies the elements in arr, into data
 */
CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other) {
        cerr << "Assignment operator called." << endl;
        if (this == &other) {
            return *this;
        }
        else {
            this->clear();
            int length = other.numItems;
            for (int i = 0; i < length; i++) {
            this->pushAtBack(other.elementAt(i));
            }
            return *this;       
        }     
    }
         
/*
 * name: CharLinkedList copy constructor 
 * purpose:   initialize a copy of a CharLinkedList 
 * arguments: takes in the address of another CharLinkedList
 * returns:   none
 * effects:  sets the fields of a copy of the given CharLinkedList,
 *           to be equal to the given CharLinkedList
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other) {
    int length = other.numItems;
    numItems = 0;
    front = nullptr;
    tail = nullptr;

    for (int i = 0; i < length; i++) {
        this->pushAtBack(other.elementAt(i));
    }
}

/* 
 * name:      CharLinkedList destructor
 * purpose:   free memory associated with the CharLinkedList
 * arguments: none
 * returns:   none
 * effects:   frees memory allocated by CharLinkedlist instances
 */
CharLinkedList::~CharLinkedList() {
    this->clear();
}

/*
 * name:      isEmpty
 * purpose:   determines if the CharLinkedList is empty or not
 * arguments: none
 * returns:   true if CharLinkedList contains no elements, false otherwise
 * effects:   none 
 */
bool CharLinkedList::isEmpty() const{
    if (numItems == 0) {
        return true;
    }
    else {
        return false;
    }
}

/* 
 * name:      clear
 * purpose:   makes the instance of the CharLinkedList into an empty one.
 * arguments: none
 * returns:   none
 * effects:   updates the corresponding fields to their null values.
 */
void CharLinkedList::clear() {
    Node *temp_node = front;

    if(isEmpty()) {
        return;
    }
    remove(this->front);
    numItems = 0;
}

/* 
 * name:      remove
 * purpose:   remove nodes starting at a given node
 * arguments: a pointer to a node that the function will start removing at
 * returns:   none
 * effects:   deletes nodes and continuously updates the front pointer
              variable until you have no nodes left.
 */
void CharLinkedList:: remove(Node *front) {
    Node *temp = front;
    
    if (isEmpty()) {
        return;
    }
    if (front->next == nullptr) {
        delete front;
        front = nullptr;
        return; 
    }
    else {
        if(front->next != nullptr) {
            temp = front;
            front = front->next;
            delete temp;
            temp = nullptr;
            remove(front);
        }
    }
}

/*
 * name:      size
 * purpose:   to calculate the size of an LinkedList
 * arguments: none
 * returns:   returns an int representing the size of a LinkedList
 * effects:   none
 */
int CharLinkedList::size() const {
    return this->numItems;
}

/*
 * name:      first
 * purpose:   to identify and return the first element of a LinkedList
 * arguments: none
 * returns:   returns the char at the first node of the CharArrayList
 * effects:   none
 */
 char CharLinkedList::first() const {
    if (this->isEmpty()) {
        throw std::runtime_error("cannot get first of empty LinkedList");
    }
    else {
        return front->data;
    }
 }

 /*
 * name:      last
 * purpose:   to identify and return the last element of a CharLinkedList
 * arguments: none
 * returns:   returns the char at the last node of the CharLinkedList
 * effects:   none
 */
char CharLinkedList::last() const {
    Node *curr_node = front;
    if (this->isEmpty()) {
        throw std::runtime_error("cannot get last of empty LinkedList");
    }
    else {
        return tail->data;
    }
}

/* 
 * name:      elementAt
 * purpose:   identifies the element at a given index if it exists
 * arguments: takes in an int representing the inputted index
 * returns:   returns the a char in the CharArrayList
 * effects:   none
 */
char CharLinkedList::elementAt(int index) const {
    if (index < 0 or index >= numItems) {
        std::stringstream ss;
        ss << "index (" << index << ") not in range [0.." << numItems << ")";
    throw std::range_error(ss.str());
    }
    Node *toReturn = findNode(index, 0, front);
   
   return toReturn->data;
}

/* 
 * name:      findNode
 * purpose:   finds a node at the given index
 * arguments: the index of the node you want to find, the count you are on
              and a pointer to a node representing the current node you are on
 * returns:   returns a pointer to the node at a given index
 * effects:   none
 */
CharLinkedList::Node *CharLinkedList::findNode(int index, int count, Node *n) 
const{
    if (count == index) {
        return n;
    }
    else {
        n = n->next;
        count++;
        return findNode(index, count, n);
    }
}

/*
 * name:      toString
 * purpose:   converts a CharLinkedList into a string
 * arguments: none
 * returns:   returns a string with the characters in the CharLinkedList
 * effects:   none
 */
 std::string CharLinkedList::toString() const {
    std::stringstream ss;
    Node *curr_node = front;
    ss << "[CharLinkedList of size " << numItems << " <<";
    if (this->isEmpty()) {
        ss << "";
    }
    else {
        while (curr_node != nullptr) {
            ss << curr_node->data;
            curr_node = curr_node->next;
        }
    }
    ss << ">>]";
    return ss.str();
 }

 /* 
 * name:      toReverseString
 * purpose:   converts a CharLinkedList into a string with all characters
              reversed
 * arguments: none
 * returns:   returns a string with the reversed characters in a CharLinkedList
 * effects:   none
 */
std::string CharLinkedList::toReverseString() const {
    std::stringstream ss;
    Node *curr_node = tail;
    ss << "[CharLinkedList of size " << numItems << " <<";
    if (this->isEmpty()) {
        ss  << "";
    }
    else {
        while (curr_node != nullptr) {
            ss << curr_node->data;
            curr_node = curr_node->prev;
        }   
    }
    ss << ">>]";
    return ss.str();
}

/*
 * name:      pushAtBack
 * purpose:   adds an element to the back of a LinkedList
 * arguments: the char you want to add at the back of the LinkedList
 * returns:   none
 * effects:   changes where the tail of the LinkedList is pointing to
 */
void CharLinkedList::pushAtBack(char c) {
    insertAt(c, numItems);
}

/*
 * name:      pushAtFront
 * purpose:   adds an element to the front of an LinkedList
 * arguments: that char you want to add at the front of the LinkedList
 * returns:   none
 * effects:   changes where the front of the LinkedList is pointing to
 */
void CharLinkedList::pushAtFront(char c) {
    insertAt(c, 0);
}

/*
 * name:      insertAt
 * purpose:   adds an element at a specified index
 * arguments: the char you want to insert, and an int representing the index
              you want to insert the given char at
 * returns:   none
 * effects:   adds a element at the specified index, and updates the pointers
              in the LinkedList accordingly
 */
 void CharLinkedList::insertAt(char c, int index) {
    if (index < 0 or index > numItems) {
        std::stringstream ss;
        ss << "index (" << index << ") not in range [0.." << numItems << "]";
        throw std::range_error(ss.str());
    }
    if (isEmpty()) {
        front = newNode(&c, nullptr, nullptr);
        tail = front;
        numItems = 1;
        return;
    }
    if (index == 0) {
        front = newNode(&c, front, nullptr);
    }
    else if (index == numItems) {
        Node *temp = tail;
        tail = newNode(&c, nullptr, tail);
        temp->next = tail;
    }
    else {
    Node *curr_node = front;
    int curr_index = 0;
    while(curr_index < index - 1) {
        curr_node = curr_node->next;
        curr_index++;
    }
    curr_node->next = newNode(&c, curr_node->next, curr_node->prev);
    }
    numItems++;
}

/* 
 * name:      insertInOrder
 * purpose:   adds an element in an ordered LinkedList at the corresponding spot
 * arguments: the char you want to insert
 * returns:   none
 * effects:   otherwise just adds an element at its correct position in the 
              ordered CharLinkedList
 */
 void CharLinkedList::insertInOrder(char c) {
    if (isEmpty()) {
        this->pushAtBack(c);
        return;
    }
    if (numItems == 1) {
        if (front->data >= c) {
            this->pushAtFront(c);
        }
        if (front->data <= c) {
            this->pushAtBack(c);
        }
        return;
    }
    if (numItems > 1) {
        Node *curr_node = front;
        int curr_index = 0;
        int length = this->numItems;
        while(curr_index < length) {
            if (curr_node->data >= c) {
                this->insertAt(c, curr_index);
                return;
            }
            else {
                curr_node = curr_node->next;
                curr_index++;
            }
        }
    this->pushAtBack(c);
    }
}
  
/*
 * name:      popFromFront
 * purpose:   deletes the first element in a LinkedList
 * arguments: none
 * returns:   none
 * effects:   removes the first element of a LinkedList, and updates
              the corresponding pointers accordingly
 */
 void CharLinkedList::popFromFront() {
    Node *temp = front;
    if (this->isEmpty()) {
        throw std::runtime_error("cannot pop from empty LinkedList");
    }
    if (numItems == 1) {
        remove(front);
    }
    else {
        front = temp->next;
        front->next = temp->next->next;
        front->prev = nullptr;
        delete temp;
    }
    numItems--;
}

/*
 * name:      popFromBack
 * purpose:   deletes the last element in a LinkedList
 * arguments: none
 * returns:   none
 * effects:   removes the last element of an LinkedList, and updates
              the corresponding pointers accordingly
 */
 void CharLinkedList::popFromBack() {
    Node *temp = tail;
    if (this->isEmpty()) {
        throw std::runtime_error("cannot pop from empty LinkedList");
    }
    if (numItems == 1) {
        remove(front);
    }
    else {
        tail = temp->prev;
        tail->next = nullptr;
        tail->prev = temp->prev->prev;
        delete temp;
    }
    numItems--;
}

/*
 * name:      removeAt
 * purpose:   removes an element at a specified index of a CharLinkrfList
 * arguments: takes in an int representing the index of the element you want
              to remove
 * returns:   none
 * effects:   removes element in an LinkedList, and decrements the size of the
              LinkedList correspondingly
 */
void CharLinkedList::removeAt(int index) {
 if (index < 0 or index >= numItems) {
    std::stringstream ss;
    ss << "index (" << index << ") not in range [0.." << numItems << ")";
    throw std::range_error(ss.str());
  }
  if (index == 0) {
    this->popFromFront();
    return;
  }
  if (index == numItems - 1) {
    this->popFromBack();
    return;
  }
  else {
    Node *temp = findNode(index, 0, front);
    temp->next->prev = temp->prev;
    temp->prev->next = temp->next;
    delete temp;
    numItems--;
  }
    
}

/* 
 * name:      replaceAt
 * purpose:   to replace the element at a node given the specified index
 * arguments: takes in an int representing the index of the element you want
              to replace, and the char you want to replace it with
 * returns:   none
 * effects:   updates LinkedList correspondingly with new element at specified
              index
 */
void CharLinkedList::replaceAt(char c, int index) {
 if (index < 0 or index > numItems - 1) {
    std::stringstream ss;
    ss << "index (" << index << ") not in range [0.." << numItems << ")";
    throw std::range_error(ss.str());
  }
    Node *curr = findNode(index, 0, front);
    curr->data = c;
}

/*
 * name:      concatenate
 * purpose:   to combine two CharLinkedLists into one
 * arguments: takes a pointer to another CharLinkedList
 * returns:   none
 * effects:   combines the current CharLinkedList with the other CharLinkedList
              such that the new array has the elements of both
 */
void CharLinkedList::concatenate(CharLinkedList *other){
    Node *curr_node = front;
    int length = other->numItems;
    int curr_index = 0;

    while (curr_index < length) {
        this->pushAtBack(other->elementAt(curr_index));
        curr_index++;
    }

}

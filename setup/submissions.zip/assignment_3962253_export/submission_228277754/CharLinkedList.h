/*
 *  CharLinkedList.h
 *  Name: Aadya Akkipeddi
 *  Date: 2/4/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Purpose: This file serves as an Interface for the CharLinkedList class
             containing all of the constructors, destructors, functions etc.
             that implement the CharLinkedList class. 
             
 *
 */

#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H

#include <sstream>
#include <string>
#include <iostream>

using namespace std;

class CharLinkedList {
public: 
    
    CharLinkedList();
    CharLinkedList(char c);
    CharLinkedList(char arr[], int size);
    CharLinkedList &operator=(const CharLinkedList &other);
    CharLinkedList(const CharLinkedList &other);

    ~CharLinkedList();

    bool isEmpty() const;
    void clear();
    int size() const;
    char first() const;
    char last() const;
    char elementAt(int index) const;
    std::string toString() const;
    std::string toReverseString() const;
    void pushAtBack(char c);
    void pushAtFront(char c);
    void insertAt(char c, int index);
    void insertInOrder(char c);
    void popFromFront();
    void popFromBack();
    void removeAt(int index);
    void replaceAt(char c, int index);
    void concatenate(CharLinkedList *other);
    
private:
    struct Node {
        char data;
        Node *next;
        Node *prev;
    };

    Node *front;
    Node *tail;
    int numItems;

    Node *newNode(char *new_data, Node *new_next, Node *new_prev);
    Node *findNode(int index, int count, Node *n) const;
    void remove(Node *front);
};
#endif

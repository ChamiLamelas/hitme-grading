/*
 *  unit_tests.h
 *  Richard Major
 *  2/4/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 * Uses Matt Russell's unit_test framework to test the CharLinkedList class.
 *
 */
#include "CharLinkedList.h"
#include <cassert>
#include <iostream>

using namespace std;

/********************************************************************\
*                       CHAR LINKED LIST TESTS                        *
\********************************************************************/

/* dummy_test
*  Tests correct syntax for class definition
*/
void dummy_test() {
    
}

/* default_constructor_test
*  Tests that there are no fatal errors/memory leaks
*  in the default constructor
*/
void default_constructor_test() {
    CharLinkedList list;
}

/* char_input_constructor_test
*  Tests that there are no fatal errors/memory leaks in the char
*  input constructor and that it has correct info with one element
*/
void char_input_constructor_test() {
    CharLinkedList list('a');
    assert(list.elementAt(0) == 'a');
    assert(list.toString() == "[CharLinkedList of size 1 <<a>>]");
    assert(list.size() == 1);
}

/* array_and_int_input_constructor_test_0
*  Tests that there are no fatal errors/memory leaks in the
*  array and int input constructor and that it has correct info with 2 elements
*/
void array_and_int_input_constructor_test_0() {
    char char_array[2] = {'a', 'b'};
    int size = 2;
    CharLinkedList list(char_array, size);
    assert(list.toString() == "[CharLinkedList of size 2 <<ab>>]");
    assert(list.size() == 2);
}

/* array_and_int_input_constructor_test_1
*  Tests that there are no fatal errors/memory leaks in the
*  array and int input constructor and that it has correct info with
*  3 elements
*/
void array_and_int_input_constructor_test_1() {
    char char_array[3] = {'a', 'b', 'c'};
    int size = 3;
    CharLinkedList list(char_array, size);
    assert(list.toString() == "[CharLinkedList of size 3 <<abc>>]");
    assert(list.size() == 3);
}

/* array_and_int_input_constructor_test_2
*  Tests that there are no fatal errors/memory leaks in the
*  array and int input constructor and that it has correct info with
*  more than 3 elements
*/
void array_and_int_input_constructor_test_2() {
    char char_array[9] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i'};
    int size = 9;
    CharLinkedList list(char_array, size);
    assert(list.toString() == "[CharLinkedList of size 9 <<abcdefghi>>]");
    assert(list.size() == 9);
}

/* CharLinkedList_input_constructor_singleton_test
*  Tests that there are no fatal errors/memory leaks in the
*  CharLinkedList input constructor with a singleton
*/
void CharLinkedList_input_constructor_singleton_test() {
    CharLinkedList list('a');
    CharLinkedList list_2(list);
}

// /* CharLinkedList_input_constructor_general_test
// *  Tests that there are no fatal errors/memory leaks in the
// *  CharLinkedList input constructor with a small array of chars
// */
void CharLinkedList_input_constructor_general_test_0() {
    char char_array[3] = {'a', 'b', 'c'};
    int size = 3;
    CharLinkedList list(char_array, size);
    CharLinkedList list_2(list);
    assert(list_2.toString() == "[CharLinkedList of size 3 <<abc>>]");
}

// /* CharLinkedList_input_constructor_general_test
// *  Tests that there are no fatal errors/memory leaks in the
// *  CharLinkedList input constructor with a large array of chars
// */
void CharLinkedList_input_constructor_general_test_1() {
    char char_array[9] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i'};
    int size = 9;
    CharLinkedList list(char_array, size);
    CharLinkedList list_2(list);
    assert(list_2.toString() == "[CharLinkedList of size 9 <<abcdefghi>>]");
}

/* CharLinkedList_assignment_operator_test
*  Tests that there are no fatal errors/memory leaks in the
*  CharLinkedList assignment operator
*/
void CharLinkedList_assignment_operator_test() {
    char char_array[9] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i'};
    int size = 9;
    CharLinkedList list(char_array, size);
    CharLinkedList new_list;
    new_list = list;
}

/* isEmpty_test_0
 * Make sure we report an empty list correctly.
*/
void isEmpty_test_0() {
    CharLinkedList list;
    if (list.isEmpty()) {
        assert(list.size() == 0);
    }
}

/* isEmpty_test_1
 * Make sure we report a nonempty list correctly.
*/
void isEmpty_test_1() {
    CharLinkedList list('a');
    if (list.isEmpty()) {
        assert(list.size() != 0);
    }
}

/*
 * clear_test
 * Make sure that the clear function correctly handles 
 * an empty linkedlist.
 */
void clear_test_0() {
    CharLinkedList list;
    list.clear();
    assert(list.size() == 0);
}

/*
 * clear_test
 * Make sure that the clear function clears a nonempty linkedlist.
 */
void clear_test_1() {
    CharLinkedList list;
    list.pushAtBack('a');
    list.clear();
    assert(list.size() == 0);
}


/*
 * clear_test_2
 * Make sure that the clear function clears a nonempty linkedlist with 
 * multiple elements
 */
void clear_test_2() {
    CharLinkedList list;
    list.pushAtBack('a');
    list.pushAtBack('b');
    list.pushAtBack('c');
    list.clear();
    assert(list.size() == 0);
}

/*
 * first_test_0
 * Make sure that the first function returns the 
 * first element of the linkedlist.
 */
void first_test_0() {
    CharLinkedList list;
    list.pushAtBack('a');
    assert(list.first() == 'a');
}

/*
 * first_test_1
 * Make sure that the first function returns an
 * error message if given an empty LinkedList
 */
void first_test_1() {
    // var to track whether runtime_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
        // first for empty LinkedList
        test_list.first();
    }
    catch (const std::runtime_error &e) {
        // if first is correctly implemented, a range_error will be thrown,
        // and we will end up here
        runtime_error_thrown = true;
        error_message = e.what();
    }
    // out here, we make our assertions
    assert(runtime_error_thrown);
    assert(error_message == "cannot get first of empty LinkedList");
}

/*
 * last_test_0
 * Make sure that the last function returns the 
 * last element of the linkedlist.
 */
void last_test_0() {
    CharLinkedList list;
    list.pushAtBack('a');
    list.pushAtBack('b');
    list.pushAtBack('c');
    assert(list.last() == 'c');
}

/*
 * last_test_1
 * Make sure that the last function returns an
 * error message if given an empty LinkedList.
 */
void last_test_1() {
    // var to track whether runtime_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
        // last for out-of-range index
        test_list.last();
    }
    catch (const std::runtime_error &e) {
        // if popFromFront is correctly implemented, 
        // a range_error will be thrown, 
        // and we will end up here
        runtime_error_thrown = true;
        error_message = e.what();
    }
    // out here, we make our assertions
    assert(runtime_error_thrown);
    assert(error_message == "cannot get last of empty LinkedList");
}

/*
 * elementAt_test_0
 * Make sure that the elementAt function works correctly
 * for a small list of multiple elements.
 */
void elementAt_test_0() {
    CharLinkedList list;
    list.pushAtBack('a');
    list.pushAtBack('b');
    list.pushAtBack('c');
    cout << list.elementAt(2) << endl;
    assert(list.elementAt(2) == 'c');
}

/*
 * elementAt_test_1
 * Make sure that the elementAt function works correctly
 * for a small list of multiple elements.
 */
void elementAt_test_1() {
    CharLinkedList list;
    list.pushAtBack('a');
    list.pushAtBack('b');
    list.pushAtBack('c');
    list.pushAtBack('d');
    list.pushAtBack('e');
    list.pushAtBack('f');
    list.pushAtBack('g');
    list.pushAtBack('h');
    list.pushAtBack('i');
    assert(list.elementAt(6) == 'g');
}

/*
 * elementAt_test_2
 * Make sure that the elementAt function works correctly
 * for a larger list of multiple elements.
 */
void elementAt_test_2() {
    char char_array[9] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i'};
    int size = 9;
    CharLinkedList list(char_array, size);
    assert(list.elementAt(5) == 'f');
}

/*
 * elementAt_test_3
 * Print the error message for an impossible request.
 */
void elementAt_test_3() {
    //var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";
    CharLinkedList test_list;
    try {
        // insertAt for out-of-range index
        test_list.elementAt(1);
    }
    catch (const std::range_error &e) {
        // if insertAt is correctly implemented, 
        // a range_error will be thrown,
        // and we will end up here
        range_error_thrown = true;
        error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (1) not in range [0..0)");
}

/*
 * toString_test_0
 * Checks that the given list is as we expect it to be, without  
 * pushing any elements back.
 */
void toString_test_0() {
    CharLinkedList list;
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}

/*
 * toString_test_1
 * Checks that the given list is as we expect it to be, with
 * pushing 1 element back.
 */
void toString_test_1() {
    CharLinkedList list;
    list.pushAtBack('a');
    assert(list.toString() == "[CharLinkedList of size 1 <<a>>]");
}

/*
 * toString_test_2
 * Checks that the given list is as we expect it to be, with
 * pushing multiple elements back.
 */
void toString_test_2() {
    CharLinkedList list;
    list.pushAtBack('a');
    list.pushAtBack('b');
    list.pushAtBack('c');
    assert(list.toString() == "[CharLinkedList of size 3 <<abc>>]");
}

/*
 * toReverseString_test_0
 * Checks that the given list (in reverse) is as we expect it to be, with
 * pushing elements back, with a smaller list.
 */
void toReverseString_test_0() {
    CharLinkedList list;
    list.pushAtBack('a');
    list.pushAtBack('b');
    list.pushAtBack('c');
    assert(list.toReverseString() == "[CharLinkedList of size 3 <<cba>>]");
}

/*
 * toReverseString_test_1
 * Checks that the given list (in reverse) is as we expect it to be, with
 * pushing elements back, with a larger list.
 */
void toReverseString_test_1() {
    CharLinkedList list;
    list.pushAtBack('a');
    list.pushAtBack('b');
    list.pushAtBack('c');
    list.pushAtBack('d');
    list.pushAtBack('e');
    list.pushAtBack('f');
    list.pushAtBack('g');
    list.pushAtBack('h');
    list.pushAtBack('i');
    assert(list.toReverseString() == 
    "[CharLinkedList of size 9 <<ihgfedcba>>]");
}

/*
 * push_AtBack_test_0
 * Print the list to cout and make sure num_items is correctly updated
 * if a character is pushed to the back of an empty linkedlist.
 */
void pushAtBack_test_0() {
    CharLinkedList list;
    list.pushAtBack('a');
    assert(list.size() == 1);
}

/*
 * push_AtBack_test_1
 * Print the list to cout and make sure num_items is correctly updated in
 * a linkedlist with 2 elements.
 */
void pushAtBack_test_1() {
    CharLinkedList list;
    list.pushAtBack('a');
    list.pushAtBack('b');
    assert(list.last() == 'b');
    assert(list.size() == 2);
}

/*
 * push_AtBack_test_2
 * Print the list to cout and make sure num_items is correctly updated in
 * a linkedlist with more than 2 elements.
 */
void pushAtBack_test_2() {
    CharLinkedList list;
    list.pushAtBack('a');
    list.pushAtBack('b');
    list.pushAtBack('c');
    assert(list.last() == 'c');
    assert(list.size() == 3);
}

/*
 * pushAtFront_test_0
 * Print the first character to cout 
 * and make sure num_items is correctly updated
 * if a character is pushed to the front of an empty linkedlist.
 */
void pushAtFront_test_0() {
    CharLinkedList list;
    list.pushAtFront('a');
    assert(list.first() == 'a');
    assert(list.size() == 1);
}

/*
 * pushAtFront_test_1
 * Print the first character to cout 
 * and make sure num_items is correctly updated in an linkedlist
 * with multiple elements
 */
void pushAtFront_test_1() {
    CharLinkedList list;
    list.pushAtFront('a');
    list.pushAtFront('b');
    list.pushAtFront('c');
    list.pushAtFront('d');
    assert(list.first() == 'd');
    assert(list.size() == 4);
}

// Tests correct insertion into an empty LL.
// Afterwards, size should be 1 and element at index 0
// should be the element we inserted.
void insertAt_empty_correct() { 
    CharLinkedList test_list;
    test_list.insertAt('a', 0);
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');
}

// Tests incorrect insertion into an empty LL.
// Attempts to call insertAt for index larger than 0.
// This should result in an std::range_error being raised.
void insertAt_empty_incorrect() {
    
    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
        // insertAt for out-of-range index
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        // if insertAt is correctly implemented, 
        // a range_error will be thrown,
        // and we will end up here
        range_error_thrown = true;
        error_message = e.what();
    }
    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0]");
}

// Tests correct insertAt for front of 1-element list.
void insertAt_front_singleton_list() {
    // initialize 1-element list
    CharLinkedList test_list('a');
    // insert at front
    test_list.insertAt('b', 0);
    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'a');
}

// Tests correct insertAt for back of 1-element list.
void insertAt_back_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at back
    test_list.insertAt('b', 1);
    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    
}

// Tests calling insertAt for a large number of elements.
// Not only does this test insertAt, it also checks that
// array expansion works correctly.
void insertAt_many_elements() {
    
    CharLinkedList test_list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.insertAt('a', i);
    }

    assert(test_list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
    
}

// Tests insertion into front of a larger list
void insertAt_front_large_list() {
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    test_list.insertAt('y', 0);

    assert(test_list.size() == 10);
    assert(test_list.elementAt(0) == 'y');
    assert(test_list.toString() ==     
    "[CharLinkedList of size 10 <<yabczdefgh>>]");

}

// Tests insertion into the back of a larger list
void insertAt_back_large_list() {

    char test_arr[10] = { 'y', 'a', 'b', 'c', 'z', 'd', 
    'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 10);  

    test_list.insertAt('x', 10);
    assert(test_list.size() == 11);
    assert(test_list.elementAt(10) == 'x');
    assert(test_list.toString() == 
    "[CharLinkedList of size 11 <<yabczdefghx>>]"); 

}

// Tests insertion into the middle of a larger list
void insertAt_middle_large_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.insertAt('z', 3);
    cout << test_list.elementAt(3) << endl;
    assert(test_list.size() == 9);
    assert(test_list.elementAt(3) == 'z');
    assert(test_list.toString() ==     
    "[CharLinkedList of size 9 <<abczdefgh>>]");

}

// Tests out-of-range insertion for a non-empty list.
void insertAt_nonempty_incorrect() {
   
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8]");
}

// /*
//  * insertInOrder_test_0
//  * Test that insertInOrder executes correctly if 
//  * the list is empty
//  */
void insertInOrder_test_0() { 
    CharLinkedList list;
    list.insertInOrder('A');
    assert(list.size() == 1);
    assert(list.elementAt(0) == 'A');
}

// /*
//  * insertInOrder_test_1
//  * Test that insertInOrder executes correctly if 
//  * the inputted char fits in the first slot.
//  */
void insertInOrder_test_1() { 
    CharLinkedList list;
    list.pushAtBack('Z');
    list.pushAtBack('E');
    list.pushAtBack('D');
    list.insertInOrder('A');
    assert(list.size() == 4);
    assert(list.elementAt(0) == 'A');
}

/*
 * insertInOrder_test_2
 * Test that insertInOrder executes correctly if 
 * the inputted char fits inbetween the first and
 * last slots.
 */
void insertInOrder_test_2() { 
    CharLinkedList list;
    list.pushAtBack('A');
    list.pushAtBack('B');
    list.pushAtBack('D');
    list.pushAtBack('E');
    list.pushAtBack('F');
    list.insertInOrder('C');
    assert(list.size() == 6);
    assert(list.elementAt(2) == 'C');
}

/*
 * insertInOrder_test_3
 * Test that insertInOrder executes correctly if 
 * the inputted char fits in the last slot.
 */
void insertInOrder_test_3() { 
    CharLinkedList list;
    list.pushAtBack('A');
    list.pushAtBack('B');
    list.pushAtBack('C');
    list.pushAtBack('D');
    list.pushAtBack('E');
    list.insertInOrder('F');
    assert(list.size() == 6);
    assert(list.elementAt(5) == 'F');
}

/*
 * name:      popFromFront_test_0
 * purpose:   test that the first character in the LinkedList
 * is correctly deleted, and that numItems is updated.
*/
void popFromFront_test_0() {
    CharLinkedList list;
    list.pushAtBack('a');
    list.pushAtBack('b');
    list.pushAtBack('c');
    list.popFromFront();
    assert(list.first() == 'b');
    assert(list.size() == 2);
}

/*
 * name:      popFromFront_test_1
 * purpose:   test that the correct error is outputted
 * when popFromFront is used on an empty list.
*/
void popFromFront_test_1() {
    // var to track whether range_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
        // deploy popFromFront on empty list
        test_list.popFromFront();
    }
    catch (const std::runtime_error &e) {
        // if popFromFront is correctly implemented, 
        // a range_error will be thrown,
        // and we will end up here
        runtime_error_thrown = true;
        error_message = e.what();
    }
    // out here, we make our assertions
    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

/*
 * name:      popFromBack_test_0
 * purpose:   test that the last character in the LinkedList
 * is correctly deleted, and that numItems is updated.
*/
void popFromBack_test_0() {
    CharLinkedList list;
    list.pushAtBack('a');
    list.pushAtBack('b');
    list.pushAtBack('c');
    list.popFromBack();
    assert(list.first() == 'a');
    assert(list.size() == 2);
}

/*
 * name:      popFromBack_test_1
 * purpose:   test that the correct error is outputted
 * when popFromF is used on an empty list.
*/
void popFromBack_test_1() {
    // var to track whether range_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
        // deploy popFromBack on empty list
        test_list.popFromBack();
    }
    catch (const std::runtime_error &e) {
        // if popFromFront is correctly implemented,
        // a range_error will be thrown,
        // and we will end up here
        runtime_error_thrown = true;
        error_message = e.what();
    }
    // out here, we make our assertions
    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

// Tests correct error message for removal from
// empty LinkedList
void removeAt_empty_linkedlist() { 
    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
        // deploy removeAt on empty list
        test_list.removeAt(0);
    }
    catch (const std::range_error &e) {
        // if removeAt is correctly implemented, 
        // a range_error will be thrown,
        // and we will end up here
        range_error_thrown = true;
        error_message = e.what();
    }
    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (0) not in range [0..0)");
}

// Tests correct removeAt for 1-element list.
void removeAt_singleton_list() {
    // initialize 1-element list
    CharLinkedList test_list('a');
    // remove element
    test_list.removeAt(0);
    assert(test_list.size() == 0);
}

// Tests correct removeAt for multiple-element list.
void removeAt_multiple_list() {
    // initialize 3-element list
    CharLinkedList list;
    list.pushAtBack('a');
    list.pushAtBack('b');
    list.pushAtBack('c');
    // remove element
    list.removeAt(1);
    assert(list.size() == 2);
    assert(list.toString() == "[CharLinkedList of size 2 <<ac>>]");
}

// Tests correct removeAt for multiple-element list with many elements.
void removeAt_large_list() {
    // initialize 3-element list
    CharLinkedList list;
    list.pushAtBack('a');
    list.pushAtBack('b');
    list.pushAtBack('c');
    list.pushAtBack('d');
    list.pushAtBack('e');
    list.pushAtBack('f');
    list.pushAtBack('g');
    list.pushAtBack('h');
    list.pushAtBack('i');
    // remove element
    list.removeAt(5);
    assert(list.size() == 8);
    assert(list.toString() == "[CharLinkedList of size 8 <<abcdeghi>>]");
}

// Tests correct replaceAt for empty list and invalid
// input
void replaceAt_empty_list_incorrect() {
    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
        // replaceAt for invalid index
        test_list.replaceAt('a', 0);
    }
    catch (const std::range_error &e) {
        // if replaceAt is correctly implemented, 
        //a range_error will be thrown,
        // and we will end up here
        range_error_thrown = true;
        error_message = e.what();
    }
    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (0) not in range [0..0)");
}

// Tests correct replaceAt for 1-element list
void replaceAt_single_list() {
    // initialize 1-element list
    CharLinkedList test_list('a');
    // replace element
    test_list.replaceAt('b', 0);
    assert(test_list.first() == 'b');
    assert(test_list.size() == 1);
}

//Tests correct replaceAt for list with multiple elements 
void replaceAt_multiple_element_list() {
    char char_array[3] = {'a', 'b', 'c'};
    int size = 3;
    CharLinkedList list(char_array, size);
    list.replaceAt('d', 1);
    assert(list.elementAt(1) == 'd');
}

//Tests correct concatenation (is that a word?) of two
//different LinkedLists
void concatenate_distinct_lists_test() {
    CharLinkedList list1;
    CharLinkedList list2;
    list1.pushAtBack('a');
    list1.pushAtBack('b');
    list1.pushAtBack('c');
    list2.pushAtBack('d');
    list2.pushAtBack('e');
    list2.pushAtBack('f');
    list1.concatenate(&list2);
    assert(list1.toString() ==     
    "[CharLinkedList of size 6 <<abcdef>>]");
}

//Tests correct concatenation (is that a word?) of two
//different LinkedLists where an empty list is concatenated
//with a non empty list
void concatenate_empty_with_non_empty_list() {
    CharLinkedList list1;
    CharLinkedList list2;
    list2.pushAtBack('a');
    list2.pushAtBack('b');
    list2.pushAtBack('c');
    list1.concatenate(&list2);
    assert(list1.toString() ==     
    "[CharLinkedList of size 3 <<abc>>]");
}

//Tests correct concatenation (is that a word?) of two
//different LinkedLists where a non empty list is concatenated
//with a empty list
void concatenate_non_empty_with_empty_list() {
    CharLinkedList list1;
    CharLinkedList list2;
    list1.pushAtBack('a');
    list1.pushAtBack('b');
    list1.pushAtBack('c');
    list1.concatenate(&list2);
    assert(list1.toString() ==     
    "[CharLinkedList of size 3 <<abc>>]");
}

//Tests correct concatenation (is that a word?) of a
//LinkedList with itself
void concatenate_identical_lists_test() {
    CharLinkedList list1;
    list1.pushAtBack('a');
    list1.pushAtBack('b');
    list1.pushAtBack('c');
    list1.concatenate(&list1);
    assert(list1.toString() ==     
    "[CharLinkedList of size 6 <<abcabc>>]");
}

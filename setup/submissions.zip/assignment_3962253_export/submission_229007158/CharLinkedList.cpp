/*
 *  CharLinkedList.cpp
 *  Richard Major
 *  2/2/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  This class can be used to dynamically store information, i.e. freely add 
 *  and delete elements, unlike a regular array. Although the ArrayList has
 *  the exact same purpose, this LinkedList class has some advantages. 
 *  Specifically, this class is better for implementations which require
 *  frequent insertions and deletions: whereas the ArrayList requires constant
 *  monitoring and expansion, the LinkedList simply adds a new element through
 *  the use of pointers.
 *
 */

#include "CharLinkedList.h"
#include <cassert>
#include <sstream>
#include <iostream>
#include <string>

using namespace std;

/*
 * name:      CharLinkedList default constructor
 * purpose:   initialize an empty LinkedList
 * arguments: none
 * returns:   none
 * effects:   size to 0 (also updates front node)
 */
CharLinkedList::CharLinkedList() {
    front = nullptr;
    back = nullptr;
    numItems = 0;
}

/*
 * name:      CharLinkedList constructor with char input
 * purpose:   initialize a LinkedList with one character
 * arguments: char c
 * returns:   none
 * effects:   numItems to 1 (also updates nodes)
 */
CharLinkedList::CharLinkedList(char c) {
    Node *curr = new Node;
    curr->c = c;
    front = curr;
    back = curr;
    front->next = nullptr;
    numItems = 1;
}

/*
 * name:      CharLinkedList constructor with array and size inputs
 * purpose:   initialize a LinkedList with an array of characters
 * arguments: char arr[], int size
 * returns:   none
 * effects:   numItems to size (also updates nodes)
 */
CharLinkedList::CharLinkedList(char arr[], int size) {
    Node *temp;
    for (int i = 0; i < size; i++) {
        Node *curr = new Node;
        if (i == 0) {
            curr->c = arr[0];
            front = curr;
            temp = front;
        }
        else if (i == size - 1) {
            curr->c = arr[i];
            temp->next = curr;
            curr->previous = temp;
            back = curr;
            back->next = nullptr;
            numItems++;
        }
        else {
            curr->c = arr[i];
            temp->next = curr;
            curr->previous = temp;
            curr->next = nullptr;
            temp = curr;
        }
    }
    numItems = size;
}

/*
 * name:      CharLinkedList constructor with CharLinkedist input 
 * purpose:   initialize a LinkedList with the information of 
 * another CharLinkedList
 * arguments: const CharLinkedList &other (reference to CharLinkedList)
 * returns:   none
 * effects:   stores all info from other CharLinkedList
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other) {
    numItems = other.numItems;
    Node *temp1, *temp2;
    for (int i = 0; i < numItems; i++) {
        Node *curr = new Node;
        if (i == 0) {
            temp1 = other.front;
            curr->c = temp1->c;
            front = curr;
            back = curr;
            front->next = nullptr;
            temp2 = front;
        }
        else if (i == numItems - 1) {
            temp1 = temp1->next;
            curr->c = temp1->c; 
            temp2->next = curr;
            curr->previous = temp2;
            curr->next = nullptr;
            back = curr;
        }
        else {
            temp1 = temp1->next;
            curr->c = temp1->c;
            temp2->next = curr;
            curr->previous = temp2;
            temp2 = curr;
        }
    }
}

/*
 * name:      delete_list
 * purpose:   recursively delete all of the memory allocated by the 
 * CharLinkedList
 * arguments: pointer to front Node
 * returns:   none
 * effects:   deletes all memory allocated by the list
 */
void CharLinkedList::delete_list(Node *curr) {
    //base case
    if (curr == nullptr) {
        return;
    }
    //recursive case
    else {
        // cout << curr->c << endl;
        Node *next = curr->next;
        delete curr;
        delete_list(next);
    }
}


/*
 * name:      CharLinkedList destructor
 * purpose:   frees memory associated with the CharLinkedList
 * arguments: none
 * returns:   none
 * effects:   frees memory allocated by CharLinkedList instances
 */
CharLinkedList::~CharLinkedList() {
    delete_list(front);
}

/*
 * name:      CharLinkedList assignment operator
 * purpose:   create an assignment operator that 
 * recycles the storage associated with the instance 
 * on the left of the assignment and makes a deep copy of the 
 * instance on the right hand side into the instance on the left
 * hand side.
 * arguments: none
 * returns:   none
 * effects:   frees memory allocated by CharLinkedlist instances
 */
CharLinkedList& CharLinkedList::operator=(const CharLinkedList &other) {
    //error message
    if (this == &other) {
        return *this;
    }
    // CharLinkedList list;
    // list.front = other.front;
    // list.back = other.back;
    // list.numItems = other.numItems;
    numItems = other.numItems;
    Node *temp1, *temp2;
    for (int i = 0; i < numItems; i++) {
        Node *curr = new Node;
        if (i == 0) {
            temp1 = other.front;
            curr->c = temp1->c;
            front = curr;
            back = curr;
            front->next = nullptr;
            temp2 = front;
        }
        else if (i == numItems - 1) {
            temp1 = temp1->next;
            curr->c = temp1->c; 
            temp2->next = curr;
            curr->previous = temp2;
            curr->next = nullptr;
            back = curr;
        }
        else {
            temp1 = temp1->next;
            curr->c = temp1->c;
            temp2->next = curr;
            curr->previous = temp2;
            temp2 = curr;
        }
    }
    return *this;
}

/*
 * name:      isEmpty
 * purpose:   determines if the LinkedList is empty or not
 * arguments: none
 * returns:   true if LinkedList contains no elements, false otherwise
 * effects:   none
 */
bool CharLinkedList::isEmpty() const {
    return numItems == 0;
}

/*
 * name:      clear
 * purpose:   turns the linkedlist into an empty linkedlist
 * arguments: none
 * returns:   none
 * effects:   linkedlist is now empty
 */
void CharLinkedList::clear(){
    Node *temp = front;
    //base case
    if (temp == nullptr) {
        return;
    }
    //recursive case
    else {
        temp = front->next;
        delete front;
        delete_list(temp);
    }
    front = nullptr;
    numItems = 0;
}

/*
 * name:      size
 * purpose:   determine the number of items in the LinkedList
 * arguments: none
 * returns:   number of elements currently stored in the LinkedList
 * effects:   none
 */
int CharLinkedList::size() const {
    return numItems;
}

/*
 * name:      first
 * purpose:   returns the first entry in the linkedlist
 * arguments: none
 * returns:   char
 * effects:   none
 */
char CharLinkedList::first() const{
    std::stringstream error;
    error << "cannot get first of empty LinkedList";
    if (numItems == 0) {
        throw std::range_error(error.str());
    }
    else {
        return front->c;
    }
}

/*
 * name:      last
 * purpose:   returns the last entry in the linkedlist
 * arguments: none
 * returns:   char
 * effects:   none
 */
char CharLinkedList::last() const{
    std::stringstream error;
    error << "cannot get last of empty LinkedList";
    if (numItems == 0) {
        throw std::range_error(error.str());
    }
    else {
        return back->c;
    }
}

CharLinkedList::Node *CharLinkedList::locate_element(Node *curr, int index) 
const {
    //base case
    if (index == 0) {
        return curr;
    }
    //recursive case
    else {
        return locate_element(curr->next, index - 1);
    }
}

/*
 * name:      elementAt
 * purpose:   returns the element of the list at a given index
 * arguments: int index
 * returns:   a char
 * effects:   none
 */
char CharLinkedList::elementAt(int index) const {
    std::stringstream error;
    error << "index (" << index << ") " << 
    "not in range [0.." << numItems << ")";
    if ((index < 0) or (index >= numItems)) {
        throw std::range_error(error.str());
    }
    else {
        Node *curr = front;
        Node *found = locate_element(curr, index);
        return found->c;
    }
}

/*
 * name:      toString
 * purpose:   turns the array into a string, and returns it
 * arguments: none
 * returns:   a string representation of the array
 * effects:   none
 */
std::string CharLinkedList::toString() const {
    std::stringstream ss;
    ss << "[CharLinkedList of size " << this->numItems << " <<";
    Node *curr = this->front;
    while (curr != nullptr) {
        ss << curr->c;
        curr = curr->next;
    }
    ss << ">>]";
    return ss.str();
}

/*
 * name:      toReverseString
 * purpose:   turns the list into a string (where the
 * first character is the last element, etc), and returns it
 * arguments: none
 * returns:   a string representation of the array
 * effects:   none
 */
std::string CharLinkedList::toReverseString() const{
    std::stringstream ss;
    ss << "[CharLinkedList of size " << numItems << " <<";
    Node *curr = this->back;
    bool finished = false;
    while (not finished) {
        ss << curr->c;
        curr = curr->previous;
        if (curr == front) {
            ss << curr->c;
            finished = true;
        }
    }
    ss << ">>]";
    return ss.str();
}

/*
 * name:      pushAtBack
 * purpose:   push the provided character into the back of the CharLinkedList
 * arguments: a char to add to the back of the list
 * returns:   none
 * effects:   increases num characters of LinkedList by 1,
 *            adds element to list
 */
void CharLinkedList::pushAtBack(char c) {
    Node *curr = new Node;
    Node *temp;
    if (numItems == 0) {
        curr->c = c;
        curr->next = front;
        front = curr;
        back = curr;
        front->next = nullptr;
        front->previous = nullptr;
        numItems++;
    
    }
    else {
        curr->c = c;
        back->next = curr;
        curr->previous = back;
        back = curr;
        back->next = nullptr;
        numItems++;
    }
}

/*
 * name:      pushAtFront
 * purpose:   Adds a Node to the front of the linkedlist
 * arguments: char c
 * returns:   none
 * effects:   numItems increases by 1, new Node added to front of list
 */
void CharLinkedList::pushAtFront(char c) {
    Node *curr = new Node;
    if (numItems == 0) {
        curr->c = c;
        curr->next = front;
        front = curr;
        back = curr;
        numItems++;
    }
    else {
        curr->c = c;
        curr->next = front;
        front->previous = curr;
        front = curr;
        numItems++;
    }
}

/*
 * name:      insertAt
 * purpose:   insert the provided character at the specified index
 * of the linkedlist
 * arguments: a char to add, a specified index at which to add it
 * returns:   none
 * effects:   increases num characters of LinkedList by 1,
 *            adds element to list at specified index
 */
void CharLinkedList::insertAt(char c, int index) {
    //prepare error message if needed
    std::stringstream error;
    error << "index (" << index << ") " << 
    "not in range [0.." << numItems << "]";
    //if char is inserted in an empty linkedlist
    if (numItems == 0 and index == 0) {
        pushAtFront(c);
    }
    //if the desired index is out of bounds
    else if ((index < 0) or (index > numItems)) {
        throw std::range_error(error.str());
    }
    //if the insertion occurs at the beginning of the list
    else if (index == 0) {
        pushAtFront(c);
    }
    //if the insertion occurs at the end of the list
    else if (index == numItems) {
        pushAtBack(c);
    }
    //general case: if the insertion occurs somewhere
    //in the middle of the list
    else {
        Node *insert = new Node;
        Node *curr = front;
        //increment until the node we want to move back for the new insert
        for (int i = 0; i < index - 1; i++) {
            curr = curr->next;
        }
        //initialize the new insert such that it will take the old node's spot
        //while still preserving the list's order
        insert->c = c;
        insert->previous = curr;
        insert->next = curr->next;
        curr->next->previous = insert;
        curr->next = insert;
        numItems++;
    }
}

/*
 * name:      insertInOrder
 * purpose:   insert the provided character such that it is 
 * in alphabetical order with its neighbors
 * arguments: a char to add
 * returns:   none
 * effects:   increases num characters of LinkedList by 1,
 *            adds element to list at valid index
 */
void CharLinkedList::insertInOrder(char c) {
    //if linkedlist is empty
    if (numItems == 0) {
        pushAtBack(c);
    }
    //if the input can be placed at the beginning
    else if (c <= front->c) {
        pushAtFront(c);
    }
    //general case: the letter's valid index is somewhere
    //between the first and last entries of the linkedlist
    else {
        bool done = false;
        Node *curr = front->next;
        int i = 1;
        while (not done) {
            //increment through list, insert at correct spot.
            if (c <= curr->c) {
                if (c >= curr->previous->c) {
                    insertAt(c, i);
                    done = true;
                }
            }
            else if (i == numItems - 1) {
                pushAtBack(c);
                done = true;
            }
            else {
                curr = curr->next;
                i++;
            }
        }
    }
}

/*
 * name:      popFromFront
 * purpose:   delete the first character in the LinkedList
 * arguments: none
 * returns:   none
 * effects:   decreases num characters of LinkedList by 1,
 *            removes first element in list
 */
void CharLinkedList::popFromFront() {
    //prepare error message if needed
    std::stringstream error;
    error << "cannot pop from empty LinkedList";
    if (numItems == 1) {
        clear();
    }
    else if (numItems > 0) {
        Node *temp;
        temp = front->next;
        delete front;
        front = temp;
        numItems--;
    }
    else {
        throw std::runtime_error(error.str());
    }
}

/*
 * name:      popFromBack
 * purpose:   delete the last character in the LinkedList
 * arguments: none
 * returns:   none
 * effects:   decreases num characters of LinkedList by 1,
 *            removes last element in list
 */
void CharLinkedList::popFromBack() {
    //prepare error message if needed
    std::stringstream error;
    error << "cannot pop from empty LinkedList";
    if (numItems == 0) {
        throw std::runtime_error(error.str());
    }
    else {
        numItems--;
    }
}

/*
 * name:      removeAt
 * purpose:   remove the character at the specified index
 * of the linkedlist
 * arguments: the index of the character to remove
 * returns:   none
 * effects:   decreases num characters of LinkedList by 1,
 *            removes element from list
 */
void CharLinkedList::removeAt(int index) {
    //prepare error message if needed
    std::stringstream error;
    error << "index (" << index << ") " << 
    "not in range [0.." << numItems << ")";
    //if the linkedlist is empty, display error message
    if (numItems == 0) {
        throw std::range_error(error.str());
    }
    //if the desired index is out of bounds, display error message
    else if ((index < 0) or (index >= numItems)) {
        throw std::range_error(error.str());
    }
    //if the first char is removed
    else if (index == 0) {
        popFromBack();
    }
    //if the removal occurs somewhere
    //in the middle of the list
    else {
        Node *curr = front;
        Node *temp = front;
        //increment until the node we want to remove
        for (int i = 0; i < index; i++) {
            curr = curr->next;
            if (i == index - 1) {
                //when we reach the end, update the previous node's next
                //pointer and delete the removed node
                temp->next = curr->next;
                delete curr;
            }
            else {
                //update the placeholder for the deleted node's previous node
                temp = temp->next;
            }
        }
        numItems--;
    }
}

/*
 * name:      replaceAt
 * purpose:   replace the character at the specified index
 * of the linkedlist with the inputted charater
 * arguments: the index of the character to replace, 
 * the character to replace it with
 * returns:   none
 * effects:   replaces the element at the given index
 */
void CharLinkedList::replaceAt(char c, int index) {
    //prepare error message if needed
    std::stringstream error;
    error << "index (" << index << ") " << 
    "not in range [0.." << numItems << ")";
    //if the linkedlist is empty
    if (numItems == 0) {
        throw std::range_error(error.str());
    }
    //if the desired index is out of bounds
    else if ((index < 0) or (index >= numItems)) {
        throw std::range_error(error.str());
    }
    //if the replacement is valid
    else {
        Node *curr = front;
        if (numItems == 1 and index == 0) {
            front->c = c;
        }
        else {
            Node *curr = front;
            Node *found = locate_element(curr, index);
            found->c = c;
        }
    }
}

/*
 * name:      delete_list
 * purpose:   recursively delete all of the memory allocated by the 
 * CharLinkedList
 * arguments: pointer to front Node
 * returns:   none
 * effects:   deletes all memory allocated by the list
 */
void CharLinkedList::delete_list_backwards(Node *curr) {
    //base case
    if (curr == nullptr) {
        return;
    }
    //recursive case
    else {
        Node *previous = curr->previous;
        delete curr;
        delete_list_backwards(previous);
    }
}


/*
 * name:      concatenate
 * purpose:   concatenate a CharLinkedList
 * with another given linkedlist (have the second linked
 * list added onto the first)
 * arguments: a reference to another linkedlist
 * returns:   none
 * effects:   concatenate the linkedlist
 */
void CharLinkedList::concatenate(CharLinkedList *other) {
    if (front == other->front)  {
        Node *curr = front;
        char *chars = new char[numItems];
        for (int i = 0; i < numItems; i++) {
            chars[i] = curr->c;
            curr = curr->next;
        }
        int temp = numItems;
        for (int i = 0; i < temp; i++) {
            pushAtBack(chars[i]);
        }
        delete [] chars;
    }
    else {
        Node *curr = other->front;
        for (int i = 0; i < other->numItems; i++ ) {
            pushAtBack(curr->c);
            curr = curr->next;
        }
    }
}


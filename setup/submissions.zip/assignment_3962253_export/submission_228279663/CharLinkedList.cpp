/*
 *  CharLinkedList.cpp
 *  Tianle (Tim) Xu (UTLN: txu05)
 *  Feb. 6, 2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Furs
 *
 *  FILE PURPOSE HERE: This file contains an implementation of the
 *  CharLinkedList class
 *
 */

#include "CharLinkedList.h"
#include <iostream>
#include <string>

/*
 * name:      Default constructor
 * purpose:   Initializes an empty linked list with characters
 * arguments: None
 * returns:   None
 * effects:   Set front pointer to nullptr and currSize to 0
 */
CharLinkedList::CharLinkedList(){
    front = nullptr;
    currSize = 0;
}

/*
 * name:      First constructor
 * purpose:   Initialize a linked list with a single character
 * arguments: A element character
 * returns:   None
 * effects:   Create a node pointer that points to a new node on the heap,
 *            point front to the node, and set currSize = 1 
 */
CharLinkedList::CharLinkedList(char c){
    front = nullptr;
    CharLinkedList::Node *node1 = CharLinkedList::newNode(c, nullptr, front);
    front = node1;
    currSize = 1;
}

/*
 * name:      Second constructor
 * purpose:   Initialize a linked list with an array of characters
 * arguments: The array of characters and its size
 * returns:   None
 * effects:   Set front to nullptr and add every character in the array to
 *            the linked list
 */
CharLinkedList::CharLinkedList(char arr[], int size){
    front = nullptr;
    for(int i = 0; i < size; i++){
        pushAtBack(arr[i]);
    }
}

/*
 * name:      Copy constructor
 * purpose:   Makes a deep copy of a given instance
 * arguments: A reference to the 'other' instance of linked list to be copied
 * returns:   None
 * effects:   Created a linked list with initialized front & currSize and the
 *            same data as the instance
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other){
    front = nullptr;
    currSize = 0;
    Node *curr = other.front;
    while (curr != nullptr){
        pushAtBack(curr->data);
        curr = curr->next;
    }
}

/*
 * name:      Assignment operator
 * purpose:   Recycles the storage associated with the instance on the left of
 *            the assignment and makes a deep copy of the instance on the right
 *            hand side into the instance on the left hand side
 * arguments: A reference to the 'other' instance of linked list to be copied
 * returns:   A reference to the altered linked list
 * effects:   Clear the original instacne and fill it with data of the other
 *            instance 
 */
CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other){
    // return pointer to itself if 'other' is the same with the original 
    // linkeclist
    if (this == &other){
        return *this;
    }
    clear();

    Node *curr = other.front;
    while (curr != nullptr){
        pushAtBack(curr->data);
        curr = curr->next;
    }

    return *this;
}

/*
 * name:      Destructor
 * purpose:   Deletes all heap-allocated data in the current linked list
 * arguments: None
 * returns:   None
 * effects:   Call function recycleRecursive to clear all nodes
 */
CharLinkedList::~CharLinkedList(){
    recycleRecursive(front);
    front = nullptr;
}

/*
 * name:      isEmpty
 * purpose:   Determine if the linked list is empty
 * arguments: None
 * returns:   A boolean variale for if the linekd list is empty
 * effects:   Check if front is equal to nullptr
 */
bool CharLinkedList::isEmpty() const{
    return (front == nullptr);
}

/*
 * name:      clear
 * purpose:   Makes the instance into an empty linked list
 * arguments: None
 * returns:   None
 * effects:   Call function recycleRecursive to clear all nodes, set front
 *            to nullptr, and currSize to 0
 */
void CharLinkedList::clear(){
    recycleRecursive(front);
    front = nullptr;
    currSize = 0;
}

/*
 * name:      recycleRecursive
 * purpose:   Clear the memories of all node in the linked list
 * arguments: A Node pointer for iteration purposes
 * returns:   None
 * effects:   Iterate through every node and delete the node while deducting
 *            currSize by 1 with each recursion
 */
void CharLinkedList::recycleRecursive(Node *curr){
    if (curr == nullptr){
        return;
    } else {
        Node *next = curr->next;
        delete curr;
        currSize--;
        recycleRecursive(next);
    }
}

/*
 * name:      size
 * purpose:   Determine the size of the linked list
 * arguments: None
 * returns:   Integer value that is the number of nodes in the linked list
 * effects:   Gets the private variale currSize, which is the size of the
 *            linked list
 */
int CharLinkedList::size() const{
    return currSize;
}

/*
 * name:      first
 * purpose:   Returns the first character in the linked list
 * arguments: None
 * returns:   The first character in the linked list
 * effects:   Finds the data of the node front is pointing to and throws an
 *            exception if the linked list is empty
 */
char CharLinkedList::first() const{
    if (front == nullptr) {
        throw std::runtime_error("cannot get first of empty LinkedList");
    }
    return front->data;
}

/*
 * name:      last
 * purpose:   Returns the last character in the linked list
 * arguments: None
 * returns:   The last character in the linked list
 * effects:   Iterate through the list to find the last character of the
 *            linked list; throws an exception i the linked list is empty
 */
char CharLinkedList::last() const{
    if (front == nullptr) {
        throw std::runtime_error("cannot get last of empty LinkedList");
    }
    Node *curr = front;
    while (curr->next != nullptr){
        curr = curr->next;
    }
    return curr->data;
}

/*
 * name:      elementAt
 * purpose:   Returns the character at the specified index in the linked list
 * arguments: An integer index
 * returns:   The character at the specified index of the linked list
 * effects:   Calls element elementAtRecHelper to help find the character
 *            at the specified index and throws an exception if the index is
 *            out of range
 */
char CharLinkedList::elementAt(int index) const{
    if (index >= currSize or index < 0){
        throw std::range_error("index (" + std::to_string(index) +
        ") not in range [0.." + std::to_string(currSize) + ")");
    }
    return elementAtRecHelper(front, index);
}

/*
 * name:      elementAtRecHelper
 * purpose:   Find the character at the specified index
 * arguments: A Node pointer for iteration purposes and the specified index
 * returns:   The character at the specified index
 * effects:   Recursively, iterate through the linked list with index deducted
 *            by 1 everytime the function recurses
 */
char CharLinkedList::elementAtRecHelper(Node *curr, int index) const{
    if (index == 0){
        return curr->data;
    }
    return elementAtRecHelper(curr->next, index - 1);
}

/*
 * name:      toString
 * purpose:   Organize elements in the linked list to a string
 * arguments: None
 * returns:   A string which contains the characters of the linked list
 * effects:   Iterate through the nodes and add the characters onto the string
 */
std::string CharLinkedList::toString() const{
    std::string result = "[CharLinkedList of size " +
    std::to_string(currSize) + " <<";
    for (Node *curr = front; curr != nullptr; curr = curr->next){
        result += curr->data;
    }
    result += ">>]";
    return result;
}

/*
 * name:      toReverseString
 * purpose:   Organize elements in the linked list to a string but in reverse
 * arguments: None
 * returns:   A string which contains the characters of the linked list but in
 *            reverse
 * effects:   Calls recursive helper tRSHelper
 */
std::string CharLinkedList::toReverseString() const{
    std::string result = "[CharLinkedList of size " +
    std::to_string(currSize) + " <<";
    if (front != nullptr){
        tRSHelper(result, front);
    }
    result += ">>]";
    return result;
}

/*
 * name:      tRSHelper
 * purpose:   Append the characters in the linked list to result string from
 *            the back to the front
 * arguments: Reference to the string result and a Node pointer for iteration
 *            purposes
 * returns:   None
 * effects:   Recursively iterate to the end of the linked list and goes back,
 *            adding each recursion's node's data elements(characters) to the
 *            string, making it in reverse
 */
void CharLinkedList::tRSHelper(std::string &result, Node *curr) const{
    if (curr != nullptr){
        tRSHelper(result, curr->next);
        result += curr->data;
    }
}  

/*
 * name:      pushAtBack
 * purpose:   Inserts the given new element after the end of the existing
 *            elements of the linked list
 * arguments: An element (character)
 * returns:   None
 * effects:   Create a new node at the very end of the linked list 
 *            and update the pointers 
 */
void CharLinkedList::pushAtBack(char c){
    insertAt(c, currSize);
}

/*
 * name:      pushAtFront
 * purpose:   Inserts the given new element in front of the existing elements
 *            of the linked list
 * arguments: An element (character)
 * returns:   None
 * effects:   Create a new node at the very front of the linked list and update
 *            the pointers
 */
void CharLinkedList::pushAtFront(char c){
    insertAt(c, 0);
}

/*
 * name:      insertAt
 * purpose:   Inserts the new element at the specified index
 * arguments: An element (character)
 * returns:   None
 * effects:   Create a new node at the specified index and update the pointers.
 *            and increase currSize by 1. Throws an exception if the index is
 *            out of range
 */
void CharLinkedList::insertAt(char c, int index){
    if (index > currSize or index < 0){
        throw std::range_error("index (" + std::to_string(index) +
        ") not in range [0.." + std::to_string(currSize) + "]");
    }

    CharLinkedList::Node *new_node = 
    CharLinkedList::newNode(c, nullptr, nullptr);
    if (index == 0){
        new_node->next = front;
        front = new_node;
    } else {
        Node *curr = front;
        int curr_index = 0;
        while (curr_index < index - 1){
            curr = curr->next;
            curr_index++;
        }
        new_node->next = curr->next;
        // different case if inserting at the end
        if (curr->next != nullptr){
            curr->next->prev = new_node;
        }
        new_node->prev = curr;
        curr->next = new_node;
    }
    currSize++;
}

/*
 * name:      insertInOrder
 * purpose:   Insert the element at the first correct index assuming the linked
 *            list is correctly sorted in an ascending order
 * arguments: An element (character)
 * returns:   None
 * effects:   Check input character with characters in the linked list one by
 *            one and call insertAt to insert it in the right order
 */
void CharLinkedList::insertInOrder(char c){
    if(isEmpty()){
        pushAtBack(c);
        return;
    }
    for (int i = 0; i < currSize; i++){
        if (c <= elementAt(i)){
            insertAt(c, i);
            return;
        }
    }
    pushAtBack(c);
}

/*
 * name:      popFromFront
 * purpose:   Removes the first element from the linked list
 * arguments: None
 * returns:   None
 * effects:   Update the pointers for front and new first node. Throws an
 *            exception if the linked list is empty
 */
void CharLinkedList::popFromFront(){
    if (isEmpty()){
        throw std::runtime_error("cannot pop from empty LinkedList");
    }
    removeAt(0);
}

/*
 * name:      popFromBack
 * purpose:   Removes the character from the back of the CharLinkedList
 * arguments: None
 * returns:   None
 * effects:   Update the pointers for the last node. Throws and exception if
 *            the linked list is empty
 */
void CharLinkedList::popFromBack() {
    if (isEmpty()) {
        throw std::runtime_error("cannot pop from empty LinkedList");
    }
    removeAt(currSize - 1);
}

/*
 * name:      removeAt
 * purpose:   Removes the element at the specifiedindex
 * arguments: An integer index
 * returns:   None
 * effects:   Create temp pointer for pointer manipulation. Update pointers for
 *            neighbouring nodes at the removed index. Throws an exception if
 *            the index is out of range
 */
void CharLinkedList::removeAt(int index){
    if (index < 0 or index >= currSize) {
        throw std::range_error("index (" + std::to_string(index) +
        ") not in range [0.." + std::to_string(currSize) + ")");
    }
    Node *temp = front;

    if (index == 0){
        front = front->next;
        if (front != nullptr){
            front->prev = nullptr;
        }
    } else {
        Node *curr = front;
        int curr_index = 0;
        while (curr_index < index - 1){
            curr = curr->next;
            curr_index++;
        }
        temp = curr->next;
        curr->next = temp->next;
        // different case if removing the end node
        if (temp->next != nullptr){
            temp->next->prev = curr;
        }
    }
    delete temp;
    currSize--;
}

/*
 * name:      replaceAt
 * purpose:   Replaces the element at the speciied index with the new element
 * arguments: An element (char) and an integer index
 * returns:   None
 * effects:   
 */
void CharLinkedList::replaceAt(char c, int index){
    if (index < 0 or index >= currSize) {
        throw std::range_error("index (" + std::to_string(index) +
        ") not in range [0.." + std::to_string(currSize) + ")");
    }
    replaceAtRecHelper(c, front, index);
}

/*
 * name:      replaceAtRecHelper
 * purpose:   Replace the character at the specified index with the new
 *            character
 * arguments: An element (char), a node pointer iteration purposes, and an
 *            integer index
 * returns:   None
 * effects:   Recursively calls itself with index deducted by 1 with each
 *            recursion. Replaces the character when arriving at the specified
 *            index
 */
void CharLinkedList::replaceAtRecHelper(char c, Node *curr, int index){
    if (index == 0){
        curr->data = c;
        return;
    } else {
        replaceAtRecHelper(c, curr->next, index - 1);
    }
}

/*
 * name:      concatenate
 * purpose:   Adds a copy of the linked list pointed to by the parameter value
 *            to the end of the linked list
 * arguments: A pointer to a second instance of linked list
 * returns:   None
 * effects:   Adds every element of the linked list pointed to by the parameter
 *            value to the end of the linked list. If the pointer is a nullptr,
 *            or the size is zero, exit the function.
 */
void CharLinkedList::concatenate(CharLinkedList *other){
    if (other == nullptr or other->currSize == 0){
        return;
    }
    CharLinkedList tempCopy(*other);
    for (int i = 0; i < tempCopy.size(); i++){
        pushAtBack(tempCopy.elementAt(i));
    }
}

/*
 * name:      newNode
 * purpose:   Creates a new node with specified data and pointers
 * arguments: The character data, a pointer to the next node and one to the
 *            previous node
 * returns:   A pointer to the new node
 * effects:   Allocate memory on the heap for the new node
 */
CharLinkedList::Node *CharLinkedList::newNode(char d, Node *next, Node *prev){
    Node *new_node = new Node;
    new_node->data = d;
    new_node->next = next;
    new_node->prev = prev;

    return new_node;
}




/*
 *  unit_tests.h
 *  YOUR NAME HERE
 *  DATE CREATED
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  FILE PURPOSE HERE: CharLinkedList is a class that represents an arraylist
 *  for character. The user can initiate linkedlist of characters and modify
 *  the linked list using the declared functions
 *
 */

 #include "CharLinkedList.h"
 #include <cassert>

// test default constructor by checking if its empty
void default_constructor_test(){
    CharLinkedList list1;
    assert(list1.isEmpty());
}

// test second constructor by testing if it has a single character
void second_constructor_test(){
    CharLinkedList list1('c');
    assert(list1.toString() == "[CharLinkedList of size 1 <<c>>]");
}

// test third constructor by testing if it has all the elements in the array
void third_constructor_test(){
    char arr[] = {'C', 'a', 'T'};
    CharLinkedList list1(arr, 3);
    assert(list1.toString() == "[CharLinkedList of size 3 <<CaT>>]");
}

// testing copy constructor by initializing list1 with reference to list2
void copy_constructor_test(){
    char arr[] = {'C', 'a', 'T'};
    CharLinkedList list1(arr, 3);
    CharLinkedList list2(list1);
    assert(list1.toString() == list2.toString());
}

// testing assignment operator by assigning list2 to list1 with operator '='
void assignment_operator_test(){
    char arr[] = {'C', 'a', 'T'};
    char arr2[] = {'d', 'O', 'g'};
    CharLinkedList list1(arr, 3);
    CharLinkedList list2(arr2, 3);
    list1 = list2;
    assert(list1.toString() == list2.toString());
}

// test isEmpty by asserting if an empty list is empty
void isEmpty_test(){
    CharLinkedList list1;
    assert(list1.isEmpty());
}

// testing size by asserting if a linked list has the right size
void size_test(){
    char arr[] = {'C', 'a', 'T'};
    CharLinkedList list1(arr, 3);
    assert(list1.size() == 3);
    list1.clear();
    assert(list1.size() == 0);
}

// testing clear by asserting if the cleared list has 0 size
void clear_test(){
    char arr[] = {'C', 'a', 'T'};
    CharLinkedList list1(arr, 3);
    list1.clear();
    assert(list1.size() == 0);
}

// testing first by seeing if the first element matches up (with insertion)
void first_test(){
    char arr[] = {'a', 'C', 'T'};
    CharLinkedList list1(arr, 3);
    assert(list1.first() == 'a');
    list1.insertAt('b', 0);
    assert(list1.first() == 'b');
}

// test first with empty list
void first_empty_test(){
    CharLinkedList list1;
    bool runtime_error_thrown = false;
    std::string error_message = "";
    try {
        list1.first();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "cannot get first of empty LinkedList");
}

// test last by seeing if the first element matches up
void last_test(){
    CharLinkedList list1('c');
    assert(list1.last() == 'c');
}

// test empty with a empty list
void last_empty_test(){
    CharLinkedList list1;
    bool runtime_error_thrown = false;
    std::string error_message = "";
    try {
        list1.last();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "cannot get last of empty LinkedList");
}

// test elementAt with first, middle, and last index (with insertion and
// deletion)
void elementAt_test(){
    char arr[] = {'C', 'a', 'T'};
    CharLinkedList list1(arr, 3);
    assert(list1.size() == 3);
    assert(list1.elementAt(0) == 'C');
    assert(list1.elementAt(1) == 'a');
    assert(list1.elementAt(2) == 'T');
    list1.insertAt('t', 2);
    assert(list1.elementAt(2) == 't');
    list1.removeAt(0);
    assert(list1.elementAt(0) == 'a');
}

// test elementAt with empty list
void elementAt_empty_test(){
    CharLinkedList list1;
    bool range_error_thrown = false;
    std::string error_message = "";
    try {
        list1.elementAt(42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0)");
}

// test elementAt with negative index
void elementAt_neg_range_test(){
    char arr[] = {'C', 'a', 'T'};
    CharLinkedList list1(arr, 3);
    bool range_error_thrown = false;
    std::string error_message = "";
    try {
        list1.elementAt(-1);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (-1) not in range [0..3)");
}

// test elementAt with large index
void elementAt_large_range_test(){
    char arr[] = {'C', 'a', 'T'};
    CharLinkedList list1(arr, 3);
    bool range_error_thrown = false;
    std::string error_message = "";
    try {
        list1.elementAt(3);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (3) not in range [0..3)");
}

// test toString with empty and non empty list
void toString_test(){
    char arr[] = {'C', 'a', 'T'};
    CharLinkedList list1(arr, 3);
    assert(list1.toString() == "[CharLinkedList of size 3 <<CaT>>]");
    list1.clear();
    assert(list1.toString() == "[CharLinkedList of size 0 <<>>]");
}

// test toReverseString with empty and non empty list
void toReverseString_test(){
    char arr[] = {'C', 'a', 'T'};
    CharLinkedList list1(arr, 3);
    assert(list1.toReverseString() == "[CharLinkedList of size 3 <<TaC>>]");
    list1.clear();
    assert(list1.toReverseString() == "[CharLinkedList of size 0 <<>>]");
}

// test pushAtBack with empty and nonempty list
void pushAtBack_test(){
    CharLinkedList list1;
    list1.pushAtBack('c');
    list1.pushAtBack('h');
    assert(list1.toString() == "[CharLinkedList of size 2 <<ch>>]");
}

// test pushAtFront with empty and nontempty list
void pushAtFront_test(){
    CharLinkedList list1;
    list1.pushAtFront('h');
    list1.pushAtFront('c');
    assert(list1.toString() == "[CharLinkedList of size 2 <<ch>>]");
}

// test insertAt with empty and nonempty list (testing when index == currSize)
void insertAt_test(){
    CharLinkedList list1;
    list1.insertAt('t', 0);
    list1.insertAt('c', 0);
    list1.insertAt('a', 1);
    list1.insertAt('s', 3);
    assert(list1.toString() == "[CharLinkedList of size 4 <<cats>>]");
}

// test insertAt with negative index
void insertAt_neg_range_test(){
    CharLinkedList list1;
    list1.insertAt('t', 0);
    list1.insertAt('c', 0);
    list1.insertAt('a', 1);
    bool range_error_thrown = false;
    std::string error_message = "";
    try {
        list1.insertAt('c', -1);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (-1) not in range [0..3]");
}

// test insertAt with large index
void insertAt_large_range_test(){
    CharLinkedList list1;
    list1.insertAt('t', 0);
    list1.insertAt('c', 0);
    list1.insertAt('a', 1);
    bool range_error_thrown = false;
    std::string error_message = "";
    try {
        list1.insertAt('c', 4);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (4) not in range [0..3]");
}

// test insertInorder with empty and nonempty list
void insertInOrder_test(){
    CharLinkedList list1;
    list1.insertInOrder('c');
    list1.insertInOrder('b');
    list1.insertInOrder('a');
    list1.insertInOrder('d');
    list1.insertInOrder('f');
    list1.insertInOrder('e');
    list1.insertInOrder('A');
    list1.insertInOrder('7');
    assert(list1.toString() == "[CharLinkedList of size 8 <<7Aabcdef>>]");
}

// test popFromFront with empty and nonempty list
void popFromFront_test(){
    char arr[] = {'C', 'a', 'T'};
    CharLinkedList list1(arr, 3);
    list1.popFromFront();
    assert(list1.toString() == "[CharLinkedList of size 2 <<aT>>]");
    list1.popFromFront();
    list1.popFromFront();
    bool runtime_error_thrown = false;
    std::string error_message = "";
    try {
        list1.popFromFront();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

// test popFromBack with empty and nonempty list
void popFromBack_test(){
    char arr[] = {'C', 'a', 'T'};
    CharLinkedList list1(arr, 3);
    list1.popFromBack();
    assert(list1.toString() == "[CharLinkedList of size 2 <<Ca>>]");
    list1.popFromBack();
    list1.popFromBack();
    bool runtime_error_thrown = false;
    std::string error_message = "";
    try {
        list1.popFromBack();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

// test removeAt with first, middle, last index
void removeAt_test(){
    char arr[] = {'C', 'a', 'T', 'e', 'R'};
    CharLinkedList list1(arr, 5);
    assert(list1.toString() == "[CharLinkedList of size 5 <<CaTeR>>]");
    list1.removeAt(2);
    assert(list1.toString() == "[CharLinkedList of size 4 <<CaeR>>]");
    list1.removeAt(3);
    assert(list1.toString() == "[CharLinkedList of size 3 <<Cae>>]");
    list1.removeAt(0);
    assert(list1.toString() == "[CharLinkedList of size 2 <<ae>>]");
    list1.removeAt(1);
    assert(list1.toString() == "[CharLinkedList of size 1 <<a>>]");
    list1.removeAt(0);
    assert(list1.toString() == "[CharLinkedList of size 0 <<>>]");
}

// test removeAt with negative index
void removeAt_neg_range_test(){
    char arr[] = {'C', 'a', 'T', 'e', 'R'};
    CharLinkedList list1(arr, 5);
    bool runtime_error_thrown = false;
    std::string error_message = "";
    try {
        list1.removeAt(-1);
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "index (-1) not in range [0..5)");
}

// test removeAt with large index
void removeAt_large_range_test(){
    char arr[] = {'C', 'a', 'T', 'e', 'R'};
    CharLinkedList list1(arr, 5);
    bool runtime_error_thrown = false;
    std::string error_message = "";
    try {
        list1.removeAt(5);
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "index (5) not in range [0..5)");
}

// test replaceAt with first, middle, last index
void replaceAt_test(){
    char arr[] = {'C', 'a', 'T', 'e', 'R'};
    CharLinkedList list1(arr, 5);
    list1.replaceAt('S', 2);
    list1.replaceAt('V', 0);
    list1.replaceAt('K', 4);
    assert(list1.toString() == "[CharLinkedList of size 5 <<VaSeK>>]");
}

// test replaceAt with negative index
void replaceAt_neg_range_test(){
    char arr[] = {'C', 'a', 'T', 'e', 'R'};
    CharLinkedList list1(arr, 5);
    bool runtime_error_thrown = false;
    std::string error_message = "";
    try {
        list1.replaceAt('c', -1);
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "index (-1) not in range [0..5)");
}

// test replaceAt with large index
void replaceAt_large_range_test(){
    char arr[] = {'C', 'a', 'T', 'e', 'R'};
    CharLinkedList list1(arr, 5);
    bool runtime_error_thrown = false;
    std::string error_message = "";
    try {
        list1.replaceAt('c', 5);
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "index (5) not in range [0..5)");
}

// test concatenate with one list empty, two list empty, and concatenate itself
void concatenate_test(){
    char arr[] = {'C', 'a', 'T'};
    char arr2[] = {'t', 'Y'};
    CharLinkedList list1(arr, 3);
    CharLinkedList list2(arr2, 2);
    list1.concatenate(&list2);
    assert(list1.toString() == "[CharLinkedList of size 5 <<CaTtY>>]");
    list1.concatenate(&list1);
    assert(list1.toString() == "[CharLinkedList of size 10 <<CaTtYCaTtY>>]");
    list1.clear();
    list1.concatenate(&list2);
    assert(list1.toString() == "[CharLinkedList of size 2 <<tY>>]");
    list1.clear();
    list2.clear();
    list1.concatenate(&list2);
    assert(list1.toString() == "[CharLinkedList of size 0 <<>>]");
}




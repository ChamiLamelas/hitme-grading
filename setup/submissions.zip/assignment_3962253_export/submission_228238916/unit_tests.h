/*
 *  unit_tests.h
 *  Aiden McComiskey
 *  31/01/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  Contains tests for all of the functions in CharLinkedList, testing each 
 * function for edge cases.
 *
 */

#include "CharLinkedList.h"
#include <cassert>
#include <stdexcept>

void constructorTestNoArgs() {
    CharLinkedList list;
}

//Tests the second constructor (which accepts a char).  Should be of size 1, 
// and the first and last should both be the same
void constructorTestOneChar() {
    char c = 'a';   
    CharLinkedList list(c);
    assert(list.size() == 1);
    assert(list.first() == 'a');
    assert(list.last() == 'a');
}
//Tests the third constuctor that takes in an array of chars.  The size should
// be the size you give it, and it should toString what the array had
void constructorTestWithArray() {
    char arr[5] = {'a','b','c','d','e'};
    CharLinkedList list(arr, 5);
    
    assert(list.size() == 5);
    assert(list.toString() == "[CharLinkedList of size 5 <<abcde>>]");
}

//Tests that copy constructor actually makes a deep copy
void copyConstructorDeepCopyTest() {
    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList originalList(arr, 5);

    // Use copy constructor to create a new list as a copy of the original
    CharLinkedList copiedList(originalList);

    originalList.clear();

    // Check if sizes are equal
    assert(copiedList.size() == 5);
    assert(copiedList.toString() == "[CharLinkedList of size 5 <<abcde>>]");
}

//Tests empty variable with assignment operator.  The new list should 
//remain unaffected even if the original one is changed. 
void assignment_operator_test_0() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    CharLinkedList newList = test_list;

    assert(newList.size() == 8);
    test_list.pushAtFront('z');
    assert(newList.size() == 8);
    test_list.insertAt('c', 1);
    assert(newList.toString() == "[CharLinkedList of size 8 <<abcdefgh>>]");
}

void assignment_operator_test_1() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);
    CharLinkedList test_list2(test_arr, 8);

    test_list2 = test_list;
    test_list.pushAtFront('z');
    assert(test_list2.size() == 8);
    assert(test_list2.toString() == "[CharLinkedList of size 8 <<abcdefgh>>]");
}

//Tests basic functionality of size given an array list
void size_Test0() {
    char arr[5] = {'a','b','c','d','e'};
    CharLinkedList list(arr, 5);
    assert(list.size() == 5);
}

//Test for when it is empty
void isEmpty_test0() {
    CharLinkedList list;
    assert(list.isEmpty());
}

//Test for when it isn't empty
void isEmpty_test1() {
    CharLinkedList list('c');
    assert(not list.isEmpty());
}

//Test the first and last functions for when there is stuff in the array
void firstAndLast_test0() {
    char arr[5] = {'a','b','c','1','e'};
    CharLinkedList list(arr, 5);
    assert(list.first() =='a');
    assert(list.last() =='e');
}


//Test the first function for when the array is empty
void first_test1() {
    CharLinkedList list;
    // var to track any error messages raised
    std::string error_message = "";
    // var to track whether range_error is thrown
    bool runtime_error_thrown = false;

    try {
        list.first();
    }
    catch (const std::runtime_error &e) {
        // if first is correctly implemented, a range_error will be thrown,
        // and we will end up here
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "cannot get first of empty LinkedList");
}

//Test the last function for when the array is empty
void last_test1() {
    CharLinkedList list;
    // var to track any error messages raised
    std::string error_message = "";
    // var to track whether range_error is thrown
    bool runtime_error_thrown = false;

    try {
        list.last();
    }
    catch (const std::runtime_error &e) {
        // if first is correctly implemented, a range_error will be thrown,
        // and we will end up here
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "cannot get last of empty LinkedList");
}

// Tests the elementAt function for a non-empty CharLinkedList.
// Verifies that the function returns the correct element at the specified 
//index
void elementAtTest_0() {
    char arr[5] = {'a','b','c','1','e'};
    CharLinkedList list(arr, 5);
    assert(list.elementAt(1) =='b');
}

// Tests the elementAt function for an out-of-range index in a non-empty
// CharLinkedList.
// Ensures that attempting to get an element at an out-of-range index raises 
//a range error.
void elementAtTest_1() {
    std:: cout << "test";
    char arr[3] = {'a','a','a'};
    CharLinkedList list(arr, 3);

    // var to track any error messages raised
    std::string error_message = "";
    // var to track whether range_error is thrown
    bool range_error_thrown = false;
    try {
        list.elementAt(3);
    }
    catch (const std::range_error &e) {
        // if first is correctly implemented, a range_error will be thrown,
        // and we will end up here
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (3) not in range [0..3)");
}

// Tests the elementAt function for a negative index in a non-empty
// CharLinkedList.
// Ensures that attempting to get an element at an out-of-range index raises 
//a range error.
void elementAtTest_2() {
    std:: cout << "test";
    char arr[5] = {'a','b','c','1','e'};
    CharLinkedList list(arr, 5);

    // var to track any error messages raised
    std::string error_message = "";
    // var to track whether range_error is thrown
    bool range_error_thrown = false;
    try {
        list.elementAt(-2);
    }
    catch (const std::range_error &e) {
        // if first is correctly implemented, a range_error will be thrown,
        // and we will end up here
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (-2) not in range [0..5)");
}


// Tests the elementAt function for a non-empty CharLinkedList.
// Verifies that the function returns the correct element at the specified 
//index
void elementAtTest_3() {
    char arr[5] = {'a','b','c','1','e'};
    CharLinkedList list(arr, 5);
    assert(list.elementAt(4) =='e');
}


// Test the clear function
void clear_test0() {
    char arr[5] = {'a','b','c','1','e'};
    CharLinkedList list(arr, 5);
    list.clear();
    assert(list.isEmpty());
}

void clear_test1() {
    CharLinkedList list('c');
    list.clear();
    // var to track any error messages raised
    std::string error_message = "";
    // var to track whether range_error is thrown
    bool runtime_error_thrown = false;

    try {
        list.first();
    }
    catch (const std::runtime_error &e) {
        // if first is correctly implemented, a range_error will be thrown,
        // and we will end up here
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "cannot get first of empty LinkedList");
}

void clear_test2() {
    char arr[3] = {'s','f','c'};
    CharLinkedList list(arr, 3);
    list.clear();
    // var to track any error messages raised
    std::string error_message = "";
    // var to track whether range_error is thrown
    bool runtime_error_thrown = false;

    try {
        list.first();
    }
    catch (const std::runtime_error &e) {
        // if first is correctly implemented, a range_error will be thrown,
        // and we will end up here
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "cannot get first of empty LinkedList");
}

// Tests the toString function for a non-empty array list
void toString_test0() {
    char arr[5] = {'a','b','c','1', 'e'};
    CharLinkedList list(arr, 5);
    assert(list.toString() == "[CharLinkedList of size 5 <<abc1e>>]");
}

// Tests the toString function for an empty array list
void toString_test1() {
    CharLinkedList list;
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}

// Tests the toReverseString function for a non-empty array list
void toReverseString_test0() {
    char arr[5] = {'a','b','c','1','e'};
    CharLinkedList list(arr, 5);
    assert(list.toReverseString() == "[CharLinkedList of size 5 <<e1cba>>]");
}

// Tests the toReverseString function for an empty array list
void toReverseString_test1() {
    CharLinkedList list;
    assert(list.toReverseString() == "[CharLinkedList of size 0 <<>>]");
}

// Tests the pushAtBack and expand functionality for a non-empty CharLinkedList
// Validates that the list expands correctly when necessary.
void pushAtBack_test0() {
    char arr[5] = {'a','b','c','1','e'};
    CharLinkedList list(arr, 5);
    list.pushAtBack('e');
    assert(list.toString() == "[CharLinkedList of size 6 <<abc1ee>>]");
}


// Tests the pushAtBack and expand functionality for an empty CharLinkedList
// Validates that the list expands correctly when necessary.
void pushAtBack_test1() {
    CharLinkedList list;
    list.pushAtBack('l');
    assert(list.toString() == "[CharLinkedList of size 1 <<l>>]");
}

// Tests the pushAtFront functionality for a non-empty CharLinkedList.
// Checks if the function correctly adds an element at the front of the list.
void pushAtFront_test0() {
    char arr[5] = {'a','b','c','1','e'};
    CharLinkedList list(arr, 5);
    list.pushAtFront('e');
    assert(list.toString() == "[CharLinkedList of size 6 <<eabc1e>>]");
}

void insertInOrder_test0() {
    char test_arr[8] = { 'A', 'B', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);  

    test_list.insertInOrder('H');
    assert(test_list.toString() == "[CharLinkedList of size 9 <<ABHcdefgh>>]");
}

// Tests the insertInOrder functionality for CharLinkedList on an empty list.
void insertInOrder_test1() { 
    CharLinkedList test_list;  

    test_list.insertInOrder('H');
    assert(test_list.toString() == "[CharLinkedList of size 1 <<H>>]");

    // std::cout << test_list.toString
}

void insertInOrderManyElements() { 
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    char newChar = 'X';
    for (int i = 0; i < 26; i++) {
        test_list.insertInOrder(newChar);
        newChar += 1;
    }

    assert(test_list.size() == 34); 
}



// Tests the removeAt functionality for a non-empty CharLinkedList.
// Verifies that the element at the specified index is removed, 
//and the size decreases
void removeAt_test0() { 
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);        

    test_list.removeAt(2);
    assert(test_list.size() == 7);
    assert(test_list.toString() == "[CharLinkedList of size 7 <<abdefgh>>]");
}

// Tests the removeAt function for an out-of-range index.
// Ensures that attempting to remove an element at an out-of-range index raises
// a std::runtime_error.
void removeAtOutofRange() { 
    char test_arr[6] = { 'a', 'b', 'c', 'd', 'e', 'f' };
    CharLinkedList test_list(test_arr, 6);
    
    // var to track any error messages raised
    std::string error_message = "";
    // var to track whether range_error is thrown
    bool runtime_error_thrown = false;

    try {
        test_list.removeAt(6);
    }
    catch (const std::runtime_error &e) {
        // if first is correctly implemented, a range_error will be thrown,
        // and we will end up here
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "index (6) not in range [0..6)");
}

// Tests the removeAt function for an empty CharLinkedList.
// Ensures that attempting to remove an element from an empty list raises a 
//std::runtime_error.
void removeAt_test2() { 
    CharLinkedList test_list('a');        
    // var to track any error messages raised
    std::string error_message = "";
    // var to track whether range_error is thrown
    bool runtime_error_thrown = false;

    try {
        test_list.removeAt(10);
    }
    catch (const std::runtime_error &e) {
        // if first is correctly implemented, a range_error will be thrown,
        // and we will end up here
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "index (10) not in range [0..1)");
}

// Tests the popFromBack functionality for a non-empty CharLinkedList.
// Verifies that the size decreases, and the last element is removed.
void popFromBack_test0() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);    

    test_list.popFromBack();
    assert(test_list.size() == 7);
    assert(test_list.last() == 'g');
    assert(test_list.first() == 'a');
}

// Tests the popFromFront functionality for a non-empty CharLinkedList.
// Verifies that the size decreases, and the first element is removed.
void popFromFront_test0() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);    

    test_list.popFromFront();
    assert(test_list.size() == 7);
    assert(test_list.last() == 'h');
    assert(test_list.first() == 'b');
}

// Tests the replaceAt functionality for a non-empty CharLinkedList.
// Verifies that the element at the specified index is replaced with the given 
//element.
void replaceAtNonEmptyList() { 
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);        

    test_list.replaceAt('z',2);
    assert(test_list.size() == 8);
    assert(test_list.toString() == "[CharLinkedList of size 8 <<abzdefgh>>]");
}


// Tests the replaceAt function for an out-of-range index.
// Ensures that attempting to replace an element at an out-of-range index 
//raises a std::runtime_error.
void replaceAtOutOfRange() { 
    char test_arr[6] = { 'a', 'b', 'c', 'd', 'e', 'f'};
    CharLinkedList test_list(test_arr, 6);        
    // var to track any error messages raised
    std::string error_message = "";
    // var to track whether range_error is thrown
    bool runtime_error_thrown = false;

    try {
        test_list.replaceAt('c', 6);
    }
    catch (const std::runtime_error &e) {
        // if first is correctly implemented, a range_error will be thrown,
        // and we will end up here
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "index (6) not in range [0..6)");
}

// Tests the replaceAt function for an empty CharLinkedList.
// Ensures that attempting to replace an element in an empty list raises a 
//std::runtime_error.
void replaceAtOnEmptyArray() { 
    CharLinkedList test_list;        
    // var to track any error messages raised
    std::string error_message = "";
    // var to track whether range_error is thrown
    bool runtime_error_thrown = false;

    try {
        test_list.replaceAt('c', 10);
    }
    catch (const std::runtime_error &e) {
        // if first is correctly implemented, a range_error will be thrown,
        // and we will end up here
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "index (10) not in range [0..0)");
}


// Tests the concatenate functionality for CharLinkedLists.
// Verifies that the second list is correctly appended to the first one.
void concatenate_test0() {
    CharLinkedList test_list('c');
    CharLinkedList test_list2('z');

    test_list.concatenate(&test_list2);

    assert(test_list.size() == 2);
    assert(test_list.toString() == "[CharLinkedList of size 2 <<cz>>]" );
}

// Tests the concatenate function for an empty CharLinkedList.
// Ensures that concatenating with an empty list doesn't change the original 
//list.
void concatenate_test1() {
    CharLinkedList test_list('c');
    CharLinkedList test_list2('z');

    test_list.concatenate(&test_list2);

    assert(test_list.size() == 2);
    assert(test_list.toString() == "[CharLinkedList of size 2 <<cz>>]" );
}

// Tests the concatenate function for a larger CharLinkedList.
// Verifies that the second list is correctly appended to the first one.
void concatenate_test2() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);          
    CharLinkedList test_list2('z');

    test_list.concatenate(&test_list2);

    assert(test_list.size() == 9);
    assert(test_list.toString() == "[CharLinkedList of size 9 <<abcdefghz>>]" );
}

// Tests the concatenate function for a very large CharLinkedList
// Verifies that concatenating a large list with another list works correctly.
void concatenate_test3() {
    char test_arr[8] = { 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a' };
    CharLinkedList test_list(test_arr, 8);
    CharLinkedList test_list2;
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list2.insertAt('a', i);
    }
    test_list.concatenate(&test_list2);

    assert(test_list.size() == 1008);
    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
}

// Verifies that concatenating a large list with another list works correctly
//Tests concatenate to an empty.
void concatenate_test4() {
    CharLinkedList test_list;
    CharLinkedList test_list2;
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list2.insertAt('a', i);
    }
    test_list.concatenate(&test_list2);

    assert(test_list.size() == 1000);
    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
}

// Verifies that concatenating a large list with another list works correctly
//Tests concatenate to an empty.
void concatenate_test5() {
    CharLinkedList test_list;
    CharLinkedList test_list2;
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list2.insertAt('a', i);
    }
    test_list2.concatenate(&test_list);

    assert(test_list2.size() == 1000);
    for (int i = 0; i < 1000; i++) {
        assert(test_list2.elementAt(i) == 'a');
    }
}

// Tests incorrect insertion into an empty LL.
// Attempts to call insertAt for index larger than 0.
// This should result in an std::range_error being raised.
void insertAt_empty_incorrect() {

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    // insertAt for out-of-range index
    test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
    // if insertAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    range_error_thrown = true;
    error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0]");
    
}

// Tests correct insertAt for front of 1-element list.
void insertAt_front_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at front
    test_list.insertAt('b', 0);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'a');
    
}

// Tests correct insertAt for back of 1-element list.
void insertAt_back_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at back
    test_list.insertAt('b', 1);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    
}

// Tests calling insertAt for a large number of elements.
// Not only does this test insertAt,
void insertAt_many_elements() {
    
    CharLinkedList test_list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.insertAt('a', i);
    }

    assert(test_list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
    
}
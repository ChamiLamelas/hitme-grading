/*
 *  CharLinkedList.cpp
 *  Aiden McComiskey
 *  06/02/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  This file contains an implementation of the CharArrayList class
 *
 */

#include "CharLinkedList.h"
#include <sstream>
#include <string>

/*
 * name:      CharLinkedList
 * purpose:   Initializes an empty CharLinkedList with size of 0.
 * arguments: None
 * returns:   None
 * effects:   None
 */
CharLinkedList::CharLinkedList() {
    intializeMembers();
}

/*
 * name:      CharLinkedList
 * purpose:   Initializes a CharLinkedList with a single character.
 * arguments: A char c representing the character to be added.
 * returns:   None
 * effects:   None
 */
CharLinkedList::CharLinkedList(char c) {
    front = createNode(c);
    back = front;
    numItems = 1;
}

/*
 * name:      CharLinkedList
 * purpose:   Initializes a CharLinkedList with characters from an array.
 * arguments: A char array (arr) and an integer (size) representing the 
 * characters and size respectively.
 * returns:   None
 * effects:   None
 */
CharLinkedList::CharLinkedList(char arr[], int size) {
    intializeMembers();

    // Loop through and add a node for each char
    for (int i = 0; i < size; i++) {
        appendNode(arr[i]);
    }
}

/*
 * name:      CharLinkedList
 * purpose:   Copy constructor for CharLinkedList.
 * arguments: A constant reference to another CharLinkedList (other) to be 
 * copied.
 * returns:   None
 * effects:   None
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other) {
    intializeMembers();

    copyConstructorHelper(other.front);
}

/*
 * name:      copyConstructorHelper
 * purpose:   Helper function for the copy constructor to copy elements from 
 * another CharLinkedList.
 * arguments: A pointer to the starting node (curr) of the CharLinkedList to 
 * be copied.
 * returns:   None
 * effects:   Adds elements to the current CharLinkedList using pushAtBack.
 */
void CharLinkedList::copyConstructorHelper(Node *curr) {
    while (curr != nullptr) {
        pushAtBack(curr->data);
        curr = curr->next;
    }
}

/*
 * name:      ~CharLinkedList
 * purpose:   Destructor for CharLinkedList.
 * arguments: None
 * returns:   None
 * effects:   Frees memory allocated for CharLinkedList nodes.
 */
CharLinkedList::~CharLinkedList() {
    destroyList(front);
}

/*
 * name:      destroyList
 * purpose:   Recursively destroys the linked nodes starting from the given 
 * node.
 * arguments: A pointer to a Node (curr), representing the starting node for 
 * destruction.
 * returns:   None
 * effects:   Frees memory for all nodes in the linked list, starting from the
 * given node.
 */
void CharLinkedList::destroyList(Node* curr) {
    if (curr != nullptr) { //until the last node
        //call itself on the next node
        destroyList(curr->next);
        delete curr;
    }
}

/*
 * name:      operator=
 * purpose:   Assigns the contents of another CharLinkedList to this instance.
 * arguments: A constant reference to a CharLinkedList object (other) to be 
 * assigned.
 * returns:   A reference to the current CharLinkedList instance (*this).
 * effects:   Frees the existing memory.
 */
CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other) {
    if (this == &other) {
        return *this;
    }

    // Clear existing content
    destroyList(front);

    intializeMembers();

    // Copy the elements from the other list
    copyConstructorHelper(other.front);

    return *this;
}

/*
 * name:      initializeMembers
 * purpose:   Initializes the members of the CharLinkedList.
 * arguments: None
 * returns:   None
 * effects:   Sets front and back pointers to nullptr and numItems to 0.
 */
void CharLinkedList::intializeMembers() {
    front = nullptr;
    back = nullptr;
    numItems = 0;
}

/*
 * name:      createNode
 * purpose:   Creates a new Node for the CharLinkedList with the given 
 * character.
 * arguments: A char c representing the character to be stored in the new Node.
 * returns:   A pointer to the newly created Node.
 * effects:   Allocates memory for a new Node and initializes its data, next, 
 * and prev members.
 */
CharLinkedList::Node *CharLinkedList::createNode(char c) {
    Node* newNode = new Node;
    newNode->data = c;
    newNode->next = nullptr;
    newNode->prev = nullptr;
    return newNode;
}

/*
 * name:      isEmpty
 * purpose:   Checks if the CharLinkedList is empty.
 * arguments: None
 * returns:   A boolean indicating whether the CharLinkedList is empty.
 * effects:   None
 */
bool CharLinkedList::isEmpty() const {
    return (numItems==0);
}

/*
 * name:      clear
 * purpose:   Clears the contents of the CharLinkedList.
 * arguments: None
 * returns:   None
 * effects:   Frees the existing heap memory.
 */
void CharLinkedList::clear() {
    destroyList(front);
    intializeMembers();
}

/*
 * name:      size
 * purpose:   Returns the number of elements in the CharLinkedList.
 * arguments: None
 * returns:   An integer representing the number of elements in the
 * CharLinkedList.
 * effects:   None
 */
int CharLinkedList::size() const {
    return numItems;
}

/*
 * name:      first
 * purpose:   Retrieves the first character in the CharLinkedList.
 * arguments: None
 * returns:   The first character in the CharLinkedList.
 * effects:   Raises a std::runtime_error if the CharLinkedList is empty.
 */
char CharLinkedList::first() const {
    if (not isEmpty()) {
        return front->data;
    } else {
        throw std::runtime_error("cannot get first of empty LinkedList");
    }
}

/*
 * name:      last
 * purpose:   Retrieves the last character in the CharLinkedList.
 * arguments: None
 * returns:   The last character in the CharLinkedList.
 * effects:   Raises a std::runtime_error if the CharLinkedList is empty.
 */
char CharLinkedList::last() const {
    if (not isEmpty()) {
        return back->data;
    } else {
        throw std::runtime_error("cannot get last of empty LinkedList");
    }
}

/*
 * name:      appendNode
 * purpose:   Appends a character to the end of the CharLinkedList.
 * arguments: A char c representing the character to be appended.
 * returns:   None
 * effects:   Increases the size of the CharLinkedList.
 */
void CharLinkedList::appendNode(char c) {
    Node* newNode = createNode(c);

    if (isEmpty()) {
        // If the list is empty, set both front and back to the new node
        front = newNode;
        back = newNode;
    } else {
        // Otherwise, add the new node to the end of the list
        back->next = newNode;
        newNode->prev = back;
        back = newNode;
    }
    numItems++;
}

/*
 * name:      elementAt
 * purpose:   Retrieves the character at the specified index in the
 * CharLinkedList.
 * arguments: An integer index representing the position in the CharLinkedList.
 * returns:   The character at the specified index.
 * effects:   Raises a std::range_error if the index is out of bounds.
 */
char CharLinkedList::elementAt(int index) const {
    std::stringstream ss;

    if (index >= numItems or index < 0 or (index == 0 and isEmpty())) {
        ss << "index (" << index << ") not in range [0.." << numItems << ")";
        throw std::range_error(ss.str());
    } else {
        return findElement(front, index);
    }
}

/*
 * name:      findElement
 * purpose:   Recursively finds the character at the specified index in the 
 * CharLinkedList.
 * arguments: A pointer to a Node (curr) representing the current node being 
 * checked,
 *            and an integer index representing the position in the 
 * CharLinkedList.
 * returns:   The character at the specified index.
 * effects:   Raises a std::out_of_range exception if the index is out of 
 * bounds.
 */
char CharLinkedList::findElement(Node *curr, int index) const {
    if (curr == nullptr) {
        throw std::out_of_range("Index out of bounds");
    }
    if (index == 0) {
        return curr->data;
    } else {
        return findElement(curr->next, index - 1);
    }
}

/*
 * name:      findNode
 * purpose:   Recursively finds the node at the specified index in the 
 * CharLinkedList.
 * arguments: A pointer to a Node (curr) representing the current node being 
 * checked,
 *            and an integer index representing the position in the 
 * CharLinkedList.
 * returns:   A pointer to the Node at the specified index.
 * effects:   Raises a std::out_of_range exception if the index is out of 
 * bounds.
 */
CharLinkedList::Node *CharLinkedList::findNode(Node *curr, int index) const {
    if (curr == nullptr) {
        throw std::out_of_range("Index out of bounds");
    }
    if (index == 0) {
        return curr;
    } else {
        return findNode(curr->next, index - 1);
    }
}

/*
 * name:      toString
 * purpose:   Generates a string representation of the CharLinkedList.
 * arguments: None
 * returns:   A string containing the CharLinkedList elements.
 * effects:   None
 */
std::string CharLinkedList::toString() const {
    std::stringstream ss;
    ss << "[CharLinkedList of size ";
    ss << numItems << " <<";

    //fill the ss with the chars in the array
    for (int i = 0; i < numItems; i++) {
        char c = elementAt(i);
        ss << c;
    }
    ss << ">>";
    ss << "]";
    return ss.str();
}

/*
 * name:      toReverseString
 * purpose:   Generates a string representation of the CharLinkedList 
 * in reverse order.
 * arguments: None
 * returns:   A string containing the CharLinkedList elements in reverse order.
 * effects:   None
 */
std::string CharLinkedList::toReverseString() const {
    std::stringstream ss;
    ss << "[CharLinkedList of size ";
    ss << numItems << " <<";

    //fill the ss with the chars in the array backwards
    for (int i = numItems - 1; i >= 0; i--) {
        char c = elementAt(i);
        ss << c;
    }
    
    ss << ">>]";
    return ss.str();
}

/*
 * name:      pushAtBack
 * purpose:   Adds a character to the end of the CharLinkedList.
 * arguments: A char c representing the character to be added.
 * returns:   None
 * effects:   None.
 */
void CharLinkedList::pushAtBack(char c) {
    appendNode(c);
}

/*
 * name:      pushAtFront
 * purpose:   Adds a character to the front of the CharLinkedList.
 * arguments: A char c representing the character to be added.
 * returns:   None
 * effects:   None.
 */
void CharLinkedList::pushAtFront(char c) {
    insertAt(c, 0);
}

/*
 * name:      insertAt
 * purpose:   Inserts a character at the specified index in the CharLinkedList.
 * arguments: A char c representing the character to be inserted, and an 
 * integer index.
 * returns:   None
 * effects:   Raises a std::range_error if the index is out of bounds.
 */
void CharLinkedList::insertAt(char c, int index) {
    std::stringstream ss;

    if (index < 0 or index > numItems) {
        ss << "index (" << index << ") not in range [0.." << numItems << "]";
        throw std::range_error(ss.str());
    }

    // Create a new node with the given character
    Node* newNode = createNode(c);

    insertion(c, index, newNode);

    numItems++;
}

/*
 * name:      insertion
 * purpose:   Insert characters into the CharLinkedList in sorted order.
 * arguments: A char c representing the character to be inserted, A pointer to 
 * the new node to insert, and the index.
 * returns:   None
 * effects: 
 */
void CharLinkedList::insertion(char c, int index, Node *newNode) {
    if (index == 0) {
        frontInsertion(newNode);
    } else if (index == numItems) {
        back->next = newNode;
        newNode->prev = back;
        back = newNode;
    } else {
        // Insert in the middle
        Node* curr = front;
        for (int i = 0; i < index - 1; i++) {
            curr = curr->next;
        }
        newNode->next = curr->next;
        newNode->prev = curr;
        curr->next->prev = newNode;
        curr->next = newNode;
    }
}

/*
 * name:      insertInOrder
 * purpose:   Inserts a character into the front of CharLinkedList
 * arguments: A pointer to the new node to insert
 * returns:   None
 * effects:   None
 */
void CharLinkedList::frontInsertion(Node *newNode) {
    // Insert at the beginning 
    newNode->next = front;
    if (front != nullptr) {
        front->prev = newNode;
    }
    front = newNode;

    // Update back if the list was empty
    if (back == nullptr) {
        back = newNode;
    }
}

/*
 * name:      insertInOrder
 * purpose:   Inserts a character into the CharLinkedList in sorted order.
 * arguments: A char c representing the character to be inserted.
 * returns:   None
 * effects:   None
 */
void CharLinkedList::insertInOrder(char c) {
    Node *newNode = createNode(c);

    if (isEmpty() or c < front->data) {
        //Insert at the beginning
        frontInsertion(newNode);
    } else {
        Node *curr = front;

        while (curr->next != nullptr and c > curr->next->data) {
            curr = curr->next;
        }

        // Insert in the middle or at the end
        newNode->next = curr->next;
        newNode->prev = curr;
        if (curr->next != nullptr) {
            curr->next->prev = newNode;
        } else {
            // If inserting at the end, update back
            back = newNode;
        }
        curr->next = newNode;
    }
    numItems++;
}

/*
 * name:      removeAt
 * purpose:   Removes the character at the specified index in the 
 * CharLinkedList.
 * arguments: An integer index representing the position in the CharLinkedList.
 * returns:   None
 * effects:   Frees memory and decreases the number of items in the 
 * CharLinkedList.
 *            Raises a std::range_error if the index is out of bounds.
 */
void CharLinkedList::removeAt(int index) {
    std::stringstream ss;

    if (index >= numItems or index < 0 or (isEmpty() and index == 0)) {
        ss << "index (" << index << ") not in range [0.." << numItems << ")";
        throw std::range_error(ss.str());
    } else {
        Node *toRemove = findNode(front, index);

        if (toRemove->prev != nullptr) {
            toRemove->prev->next = toRemove->next;
        } else {
            // If toRemove is the first node, update front
            front = toRemove->next;
        }

        if (toRemove->next != nullptr) {
            toRemove->next->prev = toRemove->prev;
        } else {
            // If toRemove is the last node, update back
            back = toRemove->prev;
        }

        delete toRemove;
        numItems--;
    }
}

/*
 * name:      popFromBack
 * purpose:   Removes the last character from the CharLinkedList.
 * arguments: None
 * returns:   None
 * effects:   Frees memory and decreases the size of the CharLinkedList.
 *            Raises a std::range_error if the CharLinkedList is empty.
 */
void CharLinkedList::popFromBack() {
    if (isEmpty()) {
        throw std::range_error("cannot pop from empty LinkedList");
    } else {
        removeAt(numItems - 1);
    }
}

/*
 * name:      popFromFront
 * purpose:   Removes the first character from the CharLinkedList.
 * arguments: None
 * returns:   None
 * effects:   Raises a std::range_error if the CharLinkedList is empty.
 */
void CharLinkedList::popFromFront() {
    if (isEmpty()) {
        throw std::range_error("cannot pop from empty LinkedList");
    } else {
        removeAt(0);
    }
}

/*
 * name:      replaceAt
 * purpose:   Replaces the character at the specified index in the 
 * CharLinkedList.
 * arguments: A char c representing the character to be inserted, 
 * and an integer index.
 * returns:   None
 * effects:   Frees memory and updates the CharLinkedList at the specified 
 * index.
 *            Raises a std::range_error if the index is out of bounds.
 */
void CharLinkedList::replaceAt(char c, int index) {
    std::stringstream ss;
    if (index >= numItems or index < 0 or (index == 0 and isEmpty())) {
        ss << "index (";
        ss << index << ") not in range [0.." << numItems << ")";
        throw std::range_error(ss.str());
    } else {
        removeAt(index); //this function has the findNode function
        //which is a recursive helper function.
        insertAt(c, index); 
    }
}

/*
 * name:      concatenate
 * purpose:   Concatenates the elements of another CharLinkedList to the end 
 * of this one.
 * arguments: A pointer to a CharLinkedList object (other) to be concatenated.
 * returns:   None
 * effects:   None
 */
void CharLinkedList::concatenate(CharLinkedList *other) {
    if (other->isEmpty()) {
        // Nothing to concatenate if the other list is empty
        return;
    }

    // Iterate through the nodes in the 'other' list
    Node *currNode = other->front;
    while (currNode != nullptr) {
        // Use pushAtBack instead of insertAt for simplicity
        pushAtBack(currNode->data);
        currNode = currNode->next;
    }

}
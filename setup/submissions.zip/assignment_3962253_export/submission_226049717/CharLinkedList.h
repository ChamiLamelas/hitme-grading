/*
 *  CharLinkedList.cpp
 *  Matthew Sheng
 *  Jan 30, 2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  .h file for character linked list implementation created as a homework
 *  assignment.
 */

#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H
#include <string>

class CharLinkedList
{

public:
    // Constructors
    CharLinkedList();
    CharLinkedList(char c);
    CharLinkedList(char arr[], int size);
    CharLinkedList(const CharLinkedList &other);

    // Destructor
    ~CharLinkedList();

    // Getters
    bool isEmpty() const;
    void clear();
    int size() const;
    char first() const;
    char last() const;
    char elementAt(int index) const;

    // Equality operator
    CharLinkedList &operator=(const CharLinkedList &other);

    // Insertion of new data
    void pushAtBack(char elem);
    void pushAtFront(char c);
    void insertAt(char c, int index);
    void insertInOrder(char c);

    // Removal of data
    void popFromBack();
    void popFromFront();
    void removeAt(int index);

    // Replacing data
    void replaceAt(char c, int index);

    // Combining two CharArrayLists
    void concatenate(CharLinkedList *other);

    // ToString methods
    std::string toString() const;
    std::string toReverseString() const;

    // JFFEs
    void sort();
    CharLinkedList *slice(int left, int right);

private:
    // Node struct for linked list
    // Includes previous and next pointers to make it a doubly linked list
    struct Node
    {
        char data;
        Node *next;
        Node *prev;
    };

    // Private fields for size, the head, and the tail
    Node *head;
    Node *tail;
    int llSize;

    // Private recursive helper methods for elementAt, deletion, and replaceAt
    char recurElem(Node *searched, int depth, int ind) const;
    void recurDel(Node *deleted);
    void recurRepl(Node *searched, int depth, int ind, char data);

    // Private helper methods for JFFE sorting
    void getMiddle(Node *a, Node **tort, Node **hair);
    Node *merge(Node *l1, Node *l2);
    void mergeSortLogic(Node **start);
};

#endif

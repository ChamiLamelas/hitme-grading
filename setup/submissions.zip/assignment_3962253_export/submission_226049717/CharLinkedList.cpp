/*
 *  CharLinkedList.cpp
 *  Matthew Sheng
 *  Jan 30, 2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  .cpp file for character linked list implementation created as a homework
 *  assignment.
 */

#include "CharLinkedList.h"
#include <sstream>
using namespace std;

/*
 * name:      CharLinkedList default constructor
 * purpose:   initialize an empty LinkedList
 * arguments: none
 * returns:   none
 * effects:   size to 0, head and tail set to null pointer
 */
CharLinkedList::CharLinkedList()
{
    head = nullptr;
    tail = nullptr;
    llSize = 0;
}

/*
 * name:      CharLinkedList constructor
 * purpose:   initialize a LinkedList with a single value
 * arguments: char c
 * returns:   none
 * effects:   size is one, pointers correctly initialized, head and tail point
 *            to value
 */
CharLinkedList::CharLinkedList(char c)
{
    Node *temp = new Node();
    temp->data = c;
    temp->next = nullptr;
    temp->prev = nullptr;
    head = temp;
    tail = temp;
    llSize = 1;
}

/*
 * name:      CharLinkedList constructor
 * purpose:   initialize a populated LinkedList from an array
 * arguments: char a[], int size
 * returns:   none
 * effects:   items correctly initialized and added, size/head/tail correctly
 *            set
 */
CharLinkedList::CharLinkedList(char a[], int s)
{
    llSize = 0;
    head = nullptr;
    tail = nullptr;

    for (int x = 0; x < s; x++)
    {
        pushAtBack(a[x]);
    }
}

/*
 * name:      CharLinkedList constructor
 * purpose:   initialize an empty LinkedList
 * arguments: Reference to another CharLinkedList
 * returns:   none
 * effects:   this CharLinkedList object is created with a
 *            deep copy of the CharLinkedList from the arg.
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other)
{
    llSize = 0;
    head = nullptr;
    tail = nullptr;
    Node *curr = other.head;
    while (curr != nullptr)
    {
        pushAtBack(curr->data);
        curr = curr->next;
    }
}

/*
 * name:      CharLinkedList destructor
 * purpose:   free memory associated with the LinkedList
 * arguments: none
 * returns:   none
 * effects:   frees memory allocated by LinkedList instances
 */
CharLinkedList::~CharLinkedList()
{
    recurDel(head);
}

/*
 * name:      recurDel
 * purpose:   recursive backend code for deletion
 * arguments: Node *searched, int depth, int index, char c
 * returns:   none
 * effects:   recursive driver code that actually deletes all data from the 
 *            linked list
 */
void CharLinkedList::recurDel(Node *deleted)
{
    if (deleted == nullptr)
    {
        return;
    }
    recurDel(deleted->next);
    delete deleted;
}

/*
 * name:      CharLinkedList operator =
 * purpose:   Create an operator to set the left CharLinkedList to a deep copy
 *            of the CharLinkedList on the right (acts as a normal equals sign
 *            for primitives, for ex. int x = y)
 * arguments: Reference to another CharLinkedList
 * returns:   This object after it has been updated
 * effects:   this CharLinkedList object is set with a
 *            deep copy of the CharLinkedList from the arg.
 *            Num Items and capacity are also set
 */
CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other)
{
    clear();
    Node *curr = other.head;
    while (curr != nullptr)
    {
        pushAtBack(curr->data);
        curr = curr->next;
    }
    return *this;
}

/*
 * name:      size
 * purpose:   determine the number of items in the LinkedList
 * arguments: none
 * returns:   number of elements currently stored in the LinkedList
 * effects:   none
 */
int CharLinkedList::size() const
{
    return (llSize);
}

/*
 * name:      isEmpty
 * purpose:   determines if the LinkedList is empty or not
 * arguments: none
 * returns:   true if LinkedList contains no elements, false otherwise
 * effects:   none
 */
bool CharLinkedList::isEmpty() const
{
    return (llSize == 0);
}

/*
 * name:      clear
 * purpose:   clear the LinkedList
 * arguments: none
 * returns:   none
 * effects:   sets numItems to 0, set all values to ' '
 */
void CharLinkedList::clear()
{
    Node *current = head;
    Node *next = nullptr;
    while (current != nullptr)
    {
        next = current->next;
        delete current;
        current = next;
    }
    head = nullptr;
    tail = nullptr;
    llSize = 0;
}

/*
 * name:      first
 * purpose:   get the first value in the LinkedList
 * arguments: none
 * returns:   data at the first index of the LinkedList
 * effects:   none
 */
char CharLinkedList::first() const
{
    if (isEmpty())
    {
        throw std::runtime_error("cannot get first of empty LinkedList");
    }
    return head->data;
}

/*
 * name:      last
 * purpose:   get the last value in the LinkedList
 * arguments: none
 * returns:   data at the last index of the LinkedList
 * effects:   none
 */
char CharLinkedList::last() const
{
    if (isEmpty())
    {
        throw std::runtime_error("cannot get last of empty LinkedList");
    }
    return tail->data;
}

/*
 * name:      elementAt
 * purpose:   get the value at a specific index in the LinkedList
 * arguments: int index
 * returns:   data at the specific index specified in params of the LinkedList
 * effects:   none
 */
char CharLinkedList::elementAt(int index) const
{
    if (index < 0 or index >= llSize)
    {
        throw std::range_error("index (" +
                               to_string(index) +
                               ") not in range [0.." +
                               to_string(llSize) + ")");
    }
    int d = 0;
    return recurElem(head, d, index);
}

char CharLinkedList::recurElem(Node *searched, int depth, int ind) const
{
    if (depth == ind)
    {
        return searched->data;
    }
    return recurElem(searched->next, depth + 1, ind);
}

/*
 * name:      toString
 * purpose:   turns the array into a formatted string and returns it
 * arguments: none
 * returns:   a string representation of the LinkedList
 * effects:   none
 */
std::string CharLinkedList::toString() const
{
    std::stringstream ss;
    ss << "[CharLinkedList of size " << llSize << " <<";
    if (not isEmpty())
    {
        Node *curr = head;
        int ind = 0;
        while (ind != llSize)
        {
            ss << curr->data;
            curr = curr->next;
            ind++;
        }
    }
    ss << ">>]";
    return ss.str();
}

/*
 * name:      toReverseString
 * purpose:   turns the array into a formatted, reversed string and returns it
 * arguments: none
 * returns:   a string representation of the LinkedList
 * effects:   none
 */
std::string CharLinkedList::toReverseString() const
{
    std::stringstream ss;
    ss << "[CharLinkedList of size " << llSize << " <<";
    if (not isEmpty())
    {
        Node *curr = tail;
        int ind = 0;
        while (ind != llSize)
        {
            ss << curr->data;
            curr = curr->prev;
            ind++;
        }
    }
    ss << ">>]";
    return ss.str();
}

/*
 * name:      pushAtBack
 * purpose:   push the provided char into the back of the LinkedList
 * arguments: char elem
 * returns:   none
 * effects:   increases num elements of LinkedList by 1,
 *            adds element to list
 */
void CharLinkedList::pushAtBack(char elem)
{
    Node *newNode = new Node();
    newNode->data = elem;
    newNode->next = nullptr;
    newNode->prev = tail;
    if (tail != nullptr)
    {
        tail->next = newNode;
    }
    if (head == nullptr)
    {
        head = newNode;
    }
    tail = newNode;
    llSize++;
}

/*
 * name:      pushAtFront
 * purpose:   push the provided char into the front of the LinkedList
 * arguments: char elem
 * returns:   none
 * effects:   increases num elements of LinkedList by 1,
 *            adds element to list, shifts all other values to the right by one
 *            to make room
 */
void CharLinkedList::pushAtFront(char elem)
{
    Node *newNode = new Node();
    newNode->data = elem;
    newNode->next = head;
    newNode->prev = nullptr;
    if (head != nullptr)
    {
        head->prev = newNode;
    }
    if (tail == nullptr)
    {
        tail = newNode;
    }
    head = newNode;
    llSize++;
}

/*
 * name:      insertAt
 * purpose:   push the provided char into a specific index of the LinkedList
 * arguments: char elem, int index
 * returns:   none
 * effects:   increases num elements of LinkedList by 1,
 *            adds element to list, shifts all other values at larger indecises
 *            than the given index to the right by one to make room
 */
void CharLinkedList::insertAt(char elem, int index)
{
    if (index > llSize or index < 0)
    {
        std::stringstream ss;
        ss << "index (" << index << ") not in range [0.." << llSize << "]";
        throw std::range_error(ss.str());
    }
    if (index == 0)
    {
        pushAtFront(elem);
        return;
    }
    if (index == llSize)
    {
        pushAtBack(elem);
        return;
    }
    Node *newNode = new Node();
    newNode->data = elem;
    Node *curr = head;
    int ind = 0;
    while (ind != index)
    {
        curr = curr->next;
        ind++;
    }
    // a b c e f g h
    // 0 1 2 3 4 5 6
    // insert d at 3
    newNode->prev = curr->prev;
    curr->prev = newNode;
    newNode->next = curr;
    newNode->prev->next = newNode;
    llSize++;
}

/*
 * name:      insertInOrder
 * purpose:   insert the given character in the correct, ascii-based position.
 *            in a low to high orientation (index 0 = lowest)
 * arguments: char elem
 * returns:   none
 * effects:   inserts the element somewhere in the LinkedList utilizing the
 *            insertAt method
 */
void CharLinkedList::insertInOrder(char elem)
{
    int ind = -1;
    int x = 0;
    while (x < llSize and ind == -1)
    {
        if (elementAt(x) >= elem)
        {
            ind = x;
        }
        x++;
    }
    if (ind == -1)
    {
        insertAt(elem, llSize);
    }
    else
    {
        insertAt(elem, ind);
    }
}

/*
 * name:      popFromFront
 * purpose:   remove the value at the front of the LinkedList
 * arguments: none
 * returns:   none
 * effects:   removes the first value in the LinkedList and shifts all
 *            remaining values to the left, decrements numItems
 */
void CharLinkedList::popFromFront()
{
    if (isEmpty())
    {
        throw std::runtime_error("cannot pop from empty LinkedList");
    }
    Node *temp = head;
    head = head->next;
    if (head != nullptr)
    {
        head->prev = nullptr;
    }
    else
    {
        tail = nullptr;
    }
    llSize--;

    delete temp;
}

/*
 * name:      popFromBack
 * purpose:   remove the value at the back of the LinkedList
 * arguments: none
 * returns:   none
 * effects:   removes the last value in the LinkedList, decrements numItems
 */
void CharLinkedList::popFromBack()
{
    if (isEmpty())
    {
        throw std::runtime_error("cannot pop from empty LinkedList");
    }
    Node *temp = tail;
    tail = tail->prev;
    if (tail != nullptr)
    {
        tail->next = nullptr;
    }
    else
    {
        head = nullptr;
    }
    llSize--;

    delete temp;
}

/*
 * name:      removeAt
 * purpose:   remove an entry at a specific index in the LinkedList
 * arguments: int index
 * returns:   none
 * effects:   removes a value in the LinkedList and shifts all affected values
 *            to the left
 */
void CharLinkedList::removeAt(int index)
{
    if (isEmpty())
    {
        throw std::runtime_error("cannot remove from empty LinkedList");
    }
    if (index < 0 or index >= llSize)
    {
        std::stringstream ss;
        ss << "index (" << index << ") not in range [0.." << llSize << ")";
        throw std::range_error(ss.str());
    }
    if (index == llSize - 1)
    {
        popFromBack();
        return;
    }
    else if (index == 0)
    {
        popFromFront();
        return;
    }
    else
    {
        Node *curr = head;
        int ind = 0;
        while (ind != index)
        {
            curr = curr->next;
            ind++;
        }
        // a b c d d e f g
        // 0 1 2 3 4 5 6 7
        // delete d at 3
        curr->next->prev = curr->prev;
        curr->prev->next = curr->next;
        delete curr;
        llSize--;
        return;
    }
}

/*
 * name:      replaceAt
 * purpose:   replace an entry with another value
 * arguments: char c, int index
 * returns:   none
 * effects:   changes the data at that index with the parameter c using 
 *            recursive helper method
 */
void CharLinkedList::replaceAt(char c, int index)
{
    if (isEmpty())
    {
        throw std::runtime_error("cannot replace from empty LinkedList");
    }
    if (index < 0 or index >= llSize)
    {
        std::stringstream ss;
        ss << "index (" << index << ") not in range [0.." << llSize << ")";
        throw std::range_error(ss.str());
    }
    int d = 0;
    recurRepl(head, d, index, c);
}

/*
 * name:      recurRepl
 * purpose:   recursive backend code for replaceAt
 * arguments: Node *searched, int depth, int index, char c
 * returns:   none
 * effects:   recursive driver code that actually changes the data at that 
 *            index with the parameter c
 */
void CharLinkedList::recurRepl(Node *searched, int depth, int ind, char nData)
{
    if (depth == ind)
    {
        searched->data = nData;
        return;
    }
    recurRepl(searched->next, depth + 1, ind, nData);
}

/*
 * name:      concatenate
 * purpose:   concatenate the original LinkedList with the LinkedList given in
 *            the parameters
 * arguments: CharLinkedList *other
 * returns:   none
 * effects:   combines the values of the two LinkedLists into THIS LinkedList
 *            the same LinkedList can be concatenated onto itself. Capacity and
 *            numItems are increased accordingly
 */
void CharLinkedList::concatenate(CharLinkedList *other)
{
    if (not other->isEmpty())
    {
        int size = other->llSize;
        int ind = 0;
        Node *curr = other->head;
        while (ind < size)
        {
            pushAtBack(curr->data);
            curr = curr->next;
            ind++;
        }
    }
}

/*
 * name:      sort
 * purpose:   sort the original LinkedList in alphabetical order
 * arguments: none
 * returns:   none
 * effects:   sorts the CharLinkedList utilizing merge sort (check read me
 *            for more information on the algorithm and why it's optimal for
 *            linked list sorting)
 */
void CharLinkedList::sort()
{
    if (isEmpty())
    {
        throw std::runtime_error("cannot sort empty LinkedList");
    }
    Node *prev = nullptr;
    Node *curr = head;
    while (curr != nullptr)
    {
        curr->prev = prev;
        prev = curr;
        curr = curr->next;
    }
    mergeSortLogic(&head);
}

/*
 * name:      getMiddle
 * purpose:   update the two params tortoise and hair to find the middle of the
 *            linked list
 * arguments: Node *start, Node **tort, Node **hair
 * returns:   none
 * effects:   Based on the initial start node, it will find where the middle
 *            node is for the subsequent nodes following the start node. It
 *            then updates tort and hair (tortoise and the hare) with the nodes
 *            at the half and the node directly after respectively to make up 
 *            the two halves of the merge sort algorithm
 */
void CharLinkedList::getMiddle(Node *start, Node **tort, Node **hair)
{
    Node *fast;
    Node *slow;
    slow = start;
    fast = slow->next;
    while (fast != nullptr)
    {
        fast = fast->next;
        if (fast != nullptr)
        {
            slow = slow->next;
            fast = fast->next;
        }
    }
    *tort = start;
    *hair = slow->next;
    slow->next = nullptr;
}

/*
 * name:      merge
 * purpose:   merge two separate "linked lists" (merely nodes linked together
 *            rather than two entirely unique CharLinkedList objects)
 * arguments: Node *l1, Node *l2
 * returns:   Node *result
 * effects:   Utilizing the two nodes l1 and l2, it merges the two into a 
 *            single one the code then returns.
 */
CharLinkedList::Node *CharLinkedList::merge(Node *l1, Node *l2)
{
    Node *result = nullptr;
    if (l1 == nullptr)
        return (l2);
    else if (l2 == nullptr)
        return (l1);
    if (l1->data <= l2->data)
    {
        result = l1;
        result->next = merge(l1->next, l2);
    }
    else
    {
        result = l2;
        result->next = merge(l1, l2->next);
    }
    return result;
}

/*
 * name:      mergeSortLogic
 * purpose:   main recursive logic for the merge sort method
 * arguments: Node **start
 * returns:   none
 * effects:   Given the start node or original linked list, this mehtod will
 *            break apart the linked list into numerous singular "sublists" to
 *            then re-combine into correct ordered pairs, continuing to merge 
 *            until all values are sorted
 */
void CharLinkedList::mergeSortLogic(Node **start)
{
    Node *head = *start;
    Node *l;
    Node *r;

    if ((head == nullptr) or (head->next == nullptr))
    {
        return;
    }
    getMiddle(head, &l, &r);
    mergeSortLogic(&l);
    mergeSortLogic(&r);
    *start = merge(l, r);
}

/*
 * name:      slice
 * purpose:   slice the original LinkedList into a smaller LinkedList determined
 *            by the two parameters
 * arguments: int left, int right (right can be the actual length of the
 *            LinkedList as the method does not include the right's index in
 *            the slice)
 * returns:   a pointer to a new CharLinkedList created from the parameters. If
 *            the left pointer is larger than the right pointer, an empty
 *            CharLinkedList is returned
 * effects:   none
 */
CharLinkedList *CharLinkedList::slice(int left, int right)
{
    if (isEmpty())
    {
        throw std::runtime_error("cannot slice from empty LinkedList");
    }
    if (left < 0 or left >= llSize)
    {
        std::stringstream ss;
        ss << "index (" << left << ") not in range [0.." << llSize << ")";
        throw std::range_error(ss.str());
    }
    if (right < 0 or right > llSize)
    {
        std::stringstream ss;
        ss << "index (" << right << ") not in range [0.." << llSize << "]";
        throw std::range_error(ss.str());
    }
    const int s = right - left;
    if (s <= 0)
    {
        return new CharLinkedList();
    }
    char slice[s];
    Node *curr = head;
    int ind = 0;
    while (ind < left)
    {
        curr = curr->next;
        ind++;
    }
    while (ind < right)
    {
        slice[ind - left] = curr->data;
        curr = curr->next;
        ind++;
    }
    return new CharLinkedList(slice, s);
}

/*
 *  unit_tests.h
 *  Anthony Insogna-Parziale
 *  Feburary 4 2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  This file holds all of my testing for my linkedlist and all the 
 *  operations we can use on it in the interface. Checks everything
 *  throughly so that I know that my functions are working properly
 *  like I hope they would. 
 *
 */
#include "CharLinkedList.h"
#include <cassert>

// checks to see if initialized CharLinkedList is empty and contains no 
// elements before it has undergone any functions
void isEmpty_test() 
{
    CharLinkedList list; // One way to invoke the default constructor.
    assert(list.size() == 0);
}

// checks if the constructor has initialized correctly
void constructor_test_0() 
{
    CharLinkedList list;
}

// checks if the constructor has been initialized correctly, and that the size
// of that list is 0
void constructor_test_1() 
{
    CharLinkedList list;
    assert(list.size() == 0);
}

// checks that when I create a linkedlsit that is a singleton, my constructor
// is doing what it needs to do to create the instance of the singleton
void singleton() 
{
    CharLinkedList list('A');
}

// this is where I check that my copy constructor is working properly
// by checking the size of the list and the copy are the same
void copyconstructor() 
{
    char array[3] = {'A', 'B', 'C'};
    CharLinkedList list(array, 3);

    CharLinkedList copy(list);
    assert(copy.size() == list.size());
}

// this is where I test my assignment operator is working properly
void assignmentoperator()
{
    char array[3] = {'A', 'B', 'C'};
    CharLinkedList list(array, 3);
    char chararray[3] = {'D', 'E', 'F'};
    CharLinkedList copy(chararray, 3);
    copy = list;
    assert(list.toString() == copy.toString());
}

// checks if when I clear a linked list there are no items left in it
void clear_test() 
{
    char array[3] = {'A', 'B', 'C'};
    CharLinkedList list(array, 3);
    list.clear();
    assert(list.size() == 0);
}

// this is where I test the clear function on an emptylist
void clear_test_empty()
{
    CharLinkedList emptyList;
    emptyList.clear();
    assert(emptyList.size() == 0);
}

// checks that my size function works independently and can assert that
// the size of a list is correct
void testsize() 
{
    CharLinkedList list('a');
    assert(list.size() == 1);
    list.pushAtBack('D');
    assert(list.size() == 2);
    cerr << "HERE:" << list.last() << endl;
}

// checks if my first function works when there is an array of three 
// chars
void first_test() 
{
    char array[3] = {'A', 'B', 'C'};
    CharLinkedList list(array, 3);
    assert(list.first() == 'A');
}

// this is where I test my first function on an empty list, should catch the
// runtime error properly
void first_test_empty()
{
    CharLinkedList empty_list;

    bool runtime_erroR = false;

    string error_message = "";

    try {
        empty_list.first();
    }
    catch (const runtime_error &e) {
        runtime_erroR = true;
        error_message = e.what();
    }

    assert(error_message == "cannot get first of empty LinkedList");
}

// checks if my first function works when there is an array of three 
// chars
void last_test() 
{
    char array[3] = {'A', 'B', 'C'};
    CharLinkedList list(array, 3);
    assert(list.last() == 'C');
}

// this is where I test my last function on an empty list, should catch the
// runtime error properly
void last_test_empty()
{
    CharLinkedList empty_list;

    bool runtime_erroR = false;

    string error_message2 = "";

    try {
        empty_list.last();
    }
    catch (const runtime_error &e) {
        runtime_erroR = true;
        error_message2 = e.what();
    }

    assert(error_message2 == "cannot get last of empty LinkedList");
}

// checks that my elementAt function works independently of my other 
// functions
void elementAt() 
{
    char array[3] = {'A', 'B', 'C'};
    CharLinkedList list(array, 3);
    assert(list.elementAt(1) == 'B');
}

// this is where I check that my elementAt function works after I pop
// a char of the list
void elementAt_removing()
{
    char array[3] = {'A', 'B', 'C'};
    CharLinkedList list(array, 3);
    list.popFromFront();
    assert(list.elementAt(0) == 'B');
    assert(list.size() == 2);
}

// this is where I test my elementAt at an invalid index on an array
// should catch the range error correctly
void elementAt_invalid()
{
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    bool range_error_thrown = false;

    string error_message = "";

    try {
        test_list.elementAt(-1);
    }
    catch (const range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (-1) not in range [0..8)");
}

// tests my tostring function, by checking if when we push A, B, and C,
// to the back of a list, and then run tostring, if the size of the 
// list is still 3, but the list now contains, those three chars in order
// like this <<ABC>>
void toString_test() 
{
    string output = "";
    CharLinkedList list;
    list.pushAtBack('A');
    list.pushAtBack('B');
    list.pushAtBack('C');
    output = list.toString();
    assert(output == "[CharLinkedList of size 3 <<ABC>>]");
}

// checks if the tostring function printss the correct message when 
// there is an empty charlinkedlist, like explained in the spec
void empty_tostring()
{
    string output;
    CharLinkedList emptyList;
    output = emptyList.toString();
    assert(output == "[CharLinkedList of size 0 <<>>]");
}

// checks if the tostring function printss the correct message when 
// there is an empty charlinkedlist, like explained in the spec
void empty_reverse_tostring()
{
    string output;
    CharLinkedList emptyList;
    output = emptyList.toReverseString();
    assert(output == "[CharLinkedList of size 0 <<>>]");
}

// tests my reversetostring function, by checking if when we push A, B, and C,
// to the back of a list, and then run reversetostring, if the size of the 
// list is still 3, but the list now contains, those three chars in reverse 
// like this <<CBA>>
void toReverseString_test() 
{
    string output = "";
    CharLinkedList list;
    list.pushAtBack('A');
    list.pushAtBack('B');
    list.pushAtBack('C');
    output = list.toReverseString();
    assert(output == "[CharLinkedList of size 3 <<CBA>>]");
}

// checks if the reversetostring function printss the correct message when 
// there is an empty charlinkedlist, like explained in the spec
void empty_test_reversetostring()
{
    string output;
    CharLinkedList emptyList;
    output = emptyList.toReverseString();
    assert(output == "[CharLinkedList of size 0 <<>>]");
}

// checks that my pushAtBack function works on an empty list and will not
// segfault or produce weird errors
void testpushatback_onempty() 
{
    CharLinkedList list;
    list.pushAtBack('A');
    assert(list.size() == 1);
    assert(list.first() == 'A');
}

// checks that my pushAtBack function works on an empty list and will not
// segfault or produce weird errors
void testpushatback_onlist() 
{
    char array[3] = {'A', 'B', 'C'};
    CharLinkedList list(array, 3);
    list.pushAtBack('Z');
    assert(list.elementAt(3) == 'Z');
    assert(list.size() == 4);
}

// checks that my pushAtFront function works on an empty list and will not
// segfault or produce weird errors
void testpushatfront_onempty() 
{
    CharLinkedList list;
    list.pushAtFront('A');
    assert(list.size() == 1);
    assert(list.first() == 'A');
}

// pushes chars to the front of list and checks to see if they are in the 
// correct order as they should be, pushed onto front in order C, B, A, so
// <<ABC>> should be printed, along with the size 3, by the last assertion
void pushAtFront_test()
{
    CharLinkedList list;
    list.pushAtFront('C');
    assert(list.first() == 'C');
    list.pushAtFront('B');
    assert(list.first() == 'B');    
    list.pushAtFront('A');
    assert(list.first() == 'A');
}

// checks that my insertAt function works when I am inserting a char
// in the middle of the list
void insertAt_infront() 
{
    char array[3] = {'A', 'B', 'C'};
    CharLinkedList list(array, 0);
    list.pushAtBack('Z');
    assert(list.first() == 'Z');
}

// checks that my insertAt function works when I want to insert a char
// in the middle of my linked list
void insertAt_inmiddle()
{
    char array[3] = {'A', 'B', 'C'};
    CharLinkedList list(array, 1);
    list.pushAtBack('Z');
    assert(list.elementAt(1) == 'Z');
}

// checks that my insertAt function works when i want to insert a char
// into an empty linked list
void insertAt_empty_correct()
{ 
    char array[3] = {'A', 'B', 'C'};
    CharLinkedList list(array, 3);
    list.pushAtBack('D');
}

// Tests insertion into the back of a larger list
void insertAt_back_large_list() 
{
    char test_arr[10] = 
                 { 'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 10);  

    test_list.insertAt('x', 10);

    assert(test_list.size() == 11);
    assert(test_list.elementAt(10) == 'x');
    assert(test_list.toString() == 
    "[CharLinkedList of size 11 <<yabczdefghx>>]"); 
}

// Tests insertion into the middle of a larger list
void insertAt_middle_large_list() 
{
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.insertAt('z', 3);

    assert(test_list.size() == 9);
    assert(test_list.elementAt(3) == 'z');
    assert(test_list.toString() == 
                                "[CharLinkedList of size 9 <<abczdefgh>>]");
}

// Tests out-of-range insertion for a non-empty list.
void insertAt_nonempty_incorrect() 
{
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    bool range_error_thrown = false;

    string error_message = "";

    try {
        test_list.insertAt('a', 42);
    }
    catch (const range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8]");
}

// Tests calling insertAt for a large number of elements.
// Not only does this test insertAt, it also checks that
// array expansion works correctly.
void insertAt_many_elements() 
{
    
    CharLinkedList test_list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.insertAt('a', i);
    }

    assert(test_list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
    
}

// Tests insertion into front of a larger list after pushing a lot of chars
// onto the list
void insertAt_front_large_list() 
{
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    test_list.insertAt('y', 0);

    assert(test_list.size() == 10);
    assert(test_list.elementAt(0) == 'y');
    assert(test_list.toString() == 
                              "[CharLinkedList of size 10 <<yabczdefgh>>]");

}

// tests my insertinorder function on a long array list, that trys to 
// insert something near the end of the list
void InsertInOrder_test() 
{ 
    char test_arr[8] = {'b', 'c', 'd', 'e', 'f', 'g', 'h', 'z'}; 

    CharLinkedList test_list(test_arr, 8); 
    test_list.insertInOrder('y'); 
    assert(test_list.elementAt(7) == 'y'); 
    assert(test_list.size() == 9); 
}

// this is my second insertinorder test that inserts a char in the middle 
// of a short array list
void InsertInOrder_test2() 
{
    CharLinkedList list;
    list.pushAtBack('A');
    list.pushAtBack('N');
    list.pushAtBack('T');
    list.pushAtBack('S');
    list.removeAt(2);
    list.insertInOrder('B');
    assert(list.size() == 4);
}

// this is my third insertinorder test that tests whether my function
// works on an emptylist
void testInsertInEmptyList() 
{
    CharLinkedList list;
    list.insertInOrder('C');
    assert(list.size() == 1);  
    assert(list.first() == 'C');  
    assert(list.last() == 'C');  
}

// this is where I call insertInOrder three times in a row and check the
// size, first, and last functions are all correct
void testInsertInOrder() 
{
    CharLinkedList list;
    list.insertInOrder('A');
    list.insertInOrder('B');
    list.insertInOrder('D');
    assert(list.size() == 3);  
    assert(list.first() == 'A');  
    assert(list.last() == 'D');   
}

// this is where I test my pop from back function after pushing back three
// chars and popfromfront, checking the size is correct and the first
// is correctly identified
void testpopfromfront() 
{
    CharLinkedList list;
    list.pushAtFront('A');
    list.pushAtFront('B');
    list.pushAtFront('C');
    list.popFromFront();
    assert(list.size() == 2);
    assert(list.first() == 'B');
}

// this tests my pop from front function on one element in a list
// and want to pop an element from the front of the linked list
// should not produce a seg fault or any weird errors
void testpopfromfront_empty1() 
{
    CharLinkedList list;
    list.pushAtFront('A');
    list.popFromFront();
    assert(list.size() == 0);
}

// this tests my pop from front function on an empty list should
// throw an error and should produce an error messagae
void popfromfront_failtest2()
{
    CharLinkedList emptyList;
    try {
        emptyList.popFromFront();
        assert(false); 
        // Assertion should fail if no exception is thrown
    } catch (const std::runtime_error& e) {
        // Verify the exception message (optional)
        string expected_error_message = "cannot pop from empty LinkedList";
        assert(e.what() == expected_error_message);
    } 
}

// this tests my pop from back function after pushing multiple chars onto
// the linkedlist and want to pop from back
void testpopfromback() 
{
    CharLinkedList list;
    list.pushAtBack('A');
    list.pushAtBack('B');
    list.pushAtBack('C');
    list.popFromBack();
    assert(list.size() == 2);
    assert(list.last() == 'B');
}

// this tests my pop from back funtion when I have one element in the 
// linkedlist and want to pop it off, should not throw a seg fault
// or produce any weird errors
void testpopfromback_empty1() 
{
    CharLinkedList list;
    list.pushAtBack('A');
    list.popFromBack();
    assert(list.size() == 0);
}

// this checks that my pop from back function works properly when I create
// an instance of an emptylist and want to throw an error message
void popfromback_failtest2()
{
    CharLinkedList emptyList;
    try {
        emptyList.popFromBack();
        assert(false); 
        // Assertion should fail if no exception is thrown
    } catch (const std::runtime_error& e) {
        // Verify the exception message (optional)
        string expected_error_message = "cannot pop from empty LinkedList";
        assert(e.what() == expected_error_message);
    } 
}

// this tests my replaceAt function after pushing multiple items onto the 
// linkedlist and replacing an element in the middle
void replaceAt() 
{
    CharLinkedList list;
    list.pushAtBack('A');
    list.pushAtBack('B');
    list.pushAtBack('C');
    list.replaceAt('D', 1);
    assert(list.toString() == "[CharLinkedList of size 3 <<ADC>>]");
}

// this tests my replaceat function when I am creating an instance 
// of a char array and want to replace the last item in the list
void replaceAt2()
{
    char array[3] = {'A', 'B', 'C'};
    CharLinkedList list(array, 3);
    list.replaceAt('D', 2);
    assert(list.toString() == "[CharLinkedList of size 3 <<ABD>>]");
}

// here I test my replaceAt function on an array of 8 chars, and want to
// replace a char at an invalid index, should catch an range error
void replaceAt3()
{
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    bool range_error_thrown = false;

    string error_message = "";

    try {
        test_list.replaceAt('z', 9);
    }
    catch (const range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (9) not in range [0..8)");
}

// this tests my removeAt test after pushing at back multiple items and
// removing the first item in teh list
void removeAt_test1() 
{
    CharLinkedList list;
    list.pushAtBack('A');
    list.pushAtBack('B');
    list.pushAtBack('C');
    list.removeAt(0);
    assert(list.toString() == "[CharLinkedList of size 2 <<BC>>]");
}

// this tests my replaceat function when I create a linkedlist and push
// at back one item and want to remove it, should not seg fault or 
// produce any weird statements
void removeAt_test2() 
{
    CharLinkedList list;
    list.pushAtBack('X');
    list.removeAt(0);
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}

// here I test my removeAt function after pushing back 4 chars onto a list
// and remove a node in the middle of the list
void removeAt_test3() 
{
    CharLinkedList list;
    list.pushAtBack('A');
    list.pushAtBack('N');
    list.pushAtBack('T');
    list.pushAtBack('S');
    list.removeAt(2);
    assert(list.toString() == "[CharLinkedList of size 3 <<ANS>>]");
}

// this is where I test my removeAt function on an invalid index,
// throw a range error 
void removeat_invalid()
{
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    bool range_error_thrown = false;

    string error_message = "";

    try {
        test_list.removeAt(9);
    }
    catch (const range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (9) not in range [0..8)");
}

// here i test if my concatenate function works when I want to concatenate
// two lists 
void concatenate_test() 
{
        CharLinkedList list1;
        list1.pushAtBack('c');
        list1.pushAtBack('a');
        list1.pushAtBack('t');

        CharLinkedList list2;
        list2.pushAtBack('C');
        list2.pushAtBack('H');
        list2.pushAtBack('E');
        list2.pushAtBack('S');
        list2.pushAtBack('H');
        list2.pushAtBack('I');
        list2.pushAtBack('R');
        list2.pushAtBack('E');

        list1.concatenate(&list2);
        assert(list1.toString() == 
                            "[CharLinkedList of size 11 <<catCHESHIRE>>]");
}

// here i test if my concatenate function works when I want to concatenate
// a list with an empty list
void concatenate_test2() 
{
    CharLinkedList list1;
        list1.pushAtBack('X');
        list1.pushAtBack('Y');
        list1.pushAtBack('Z');

        CharLinkedList emptyList;

        list1.concatenate(&emptyList);
        assert(list1.toString() == "[CharLinkedList of size 3 <<XYZ>>]");
}

// here i test if my concatenate function works when I want to
// concatenare the same list
void concatenate_test3()
{
    CharLinkedList list1;
        list1.pushAtBack('C');
        list1.pushAtBack('S');
        list1.pushAtBack('1');
        list1.pushAtBack('5');

        list1.concatenate(&list1);
        assert(list1.toString() == "[CharLinkedList of size 8 <<CS15CS15>>]");
}

// here i test if my concatenate function works when I concatenate 
// an empty list with a list of size 3
void concatenate_test4() 
{
    CharLinkedList list1;

    CharLinkedList emptyList;

        list1.concatenate(&emptyList);
        assert(list1.toString() == "[CharLinkedList of size 0 <<>>]");
}

// here i test if my concatenate function works when I concatenate
// a list of size 3 with an empty list
void concatenate_test5() 
{
    CharLinkedList list1;
        list1.pushAtBack('X');
        list1.pushAtBack('Y');
        list1.pushAtBack('Z');

    CharLinkedList emptyList;

        emptyList.concatenate(&list1);
        assert(list1.toString() == "[CharLinkedList of size 3 <<XYZ>>]");
}
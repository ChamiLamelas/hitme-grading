/*
 *  CharLinkedList.h
 *  Anthony Insogna
 *  DATE:  February 6th 2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  The purpose of this homework was to familarize ourselves with linkedlists,
 *  how to build and use them. So that we are able to build lists in C++ that
 *  are both dynamic and expandable, and able to undergo functions such as, 
 *  popping chars off from the front or back of the array, concatenate two 
 *  chararrays, insert, delete or replace new chars into the existing array.
 *  This is where I define all of my functions for my CharLinkedList class.
 *
 */

#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H
#include <string>
using namespace std;

class CharLinkedList {
    public:
        CharLinkedList();
        ~CharLinkedList();
        CharLinkedList(const CharLinkedList &other);
        CharLinkedList &operator=(const CharLinkedList &other);

        CharLinkedList(char c);
        CharLinkedList(char arr[], int size);
      
        bool isEmpty() const;
        void clear();
        int size() const;
        char first() const;
        char last() const;
        char elementAt(int index) const;
        void range_error1(int index) const;
        void range_error2(int index) const;
        void throw_runtime_error();
        string toString() const;
        string toReverseString() const;
        void popFromFront();
        void popFromBack();
        void pushAtBack(char c);
        void pushAtFront(char c);
        void insertAt(char c, int index);
        void insertInOrder(char c);
        void removeAt(int index);
        void replaceAt(char c, int intex);
        void concatenate(CharLinkedList *other);

    private:

        struct Node {
            char data;
            Node *next;
            Node *prev;
        };

        int numItems;
        Node *front;
        Node *back;
        Node* create_node(char c, Node *nextnode, Node *prevnode);
        Node* recursivecheck(Node *curr, int index) const;
        void deletenode(Node *current);

};

#endif

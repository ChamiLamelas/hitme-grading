/*
 *  CharLinkedList.cpp
 *  Anthony Insogna
 *  DATE Feb 4th 2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  The purpose of this homework was to familarize ourselves with linkedlists,
 *  how to build and use them. So that we are able to build lists in C++ that
 *  are both dynamic and expandable, and able to undergo functions such as, 
 *  popping chars off from the front or back of the array, concatenate two 
 *  chararrays, insert, delete or replace new chars into the existing array.
 *
 */

#include "CharLinkedList.h"
#include <sstream>
#include <iostream>
#include <string>
#include <stdexcept>

// CharLinkedList(), basic constructor
// Input: this does not take in any input 
// Description: initializes all of the private members of a charlinkedlist, 
// by setting numItems to 0, since there aren't any, and the front and back
// pointers of the node to nullptr, since we do not have an instance yet
// Output: no output
CharLinkedList::CharLinkedList() 
{
    numItems = 0;
    front = nullptr;
    back = nullptr; 
}

// CharLinkedList(char c), constructor for one element
// Input: takes in a char c
// Description: initializes all of the private members of a charlinkedlist 
// that consists of one element, so numItems would be set to 1 since we
// are creating an instance of one item, we create a node pointer to that
// node, set its data to c, its next and prev to nullptr (since there is
// nothing to right or left of it), and front and back to curr
// Output: no output
CharLinkedList::CharLinkedList(char c)
{
    numItems = 1;
    Node *curr = new Node;
    curr->data = c;
    curr->next = nullptr;
    curr->prev = nullptr;
    front = curr;
    back = curr;
}

// ~CharLinkedList()
// Input: has no inputs
// Description: this deconstructor is called to clean up any memory leaks
// by deleting all data that is not nullptr, calls upon deletenode
// Output: no output
CharLinkedList::~CharLinkedList()
{
    deletenode(front);
}

// ~CharLinkedList()
// Input: has no inputs
// Description: this is a helper function for my deconstructor is called to 
// clean up any memory leaks by deleting all data that is not nullptr
// Output: no output
void CharLinkedList::deletenode(Node *current)
{
    if (current == nullptr) {
        return;
    }
    deletenode(current->next);
    delete current;
}

// CharLinkedList(char arr[], int size), constructor for any size list
// Input: takes char array, and an integer value for the size of the arraylist
// Description: initializes all of the private members of a chararraylist that
// so numItems should be set to 0 and front and back should be set to 
// nullptr, who are then updated in the for loop, using the pushAtBack
// function that adds to numItems and links the linkedlist together
// Output: nothing makes an instance of a constructor
CharLinkedList::CharLinkedList(char arr[], int size)
{
    numItems = 0;
    front = nullptr;
    back = nullptr;

        for (int i = 0; i < size; i++) {
            pushAtBack(arr[i]);
        }
}

// CharLinkedList(const CharLinkedList &other)
// Input: A constant reference to a CharLinkedList object, from which 
// elements are copied.
// Description: This is a copy constructor for the CharLinkedList class, 
// which initializes a new CharLinkedList object with the same elements
// as the "other"
// Output: no output
CharLinkedList::CharLinkedList(const CharLinkedList &other)
{
    numItems = 0;
    front = nullptr;
    back = nullptr;

    Node *curr = other.front;

    while (curr != nullptr) {
        pushAtBack(curr->data);
        curr = curr->next;
    }
}

// &CharLinkedList::operator=(const CharLinkedList &other)
// Input: A constant reference to a CharLinkedList object, from which 
// elements are copied.
// Description: This is a assignment operatorfor the CharLinkedList class, 
// which initializes a new CharLinkedList object with the same elements
// as the "other" to the current linked list object (list1)
// Output: no output
CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other)
{
   if (this == &other) {
    return *this;
   }
   
    deletenode(front);

    front = nullptr;
    back = nullptr;
    numItems = 0;

   for (int i = 0; i < other.numItems; i++) {
        pushAtBack(other.elementAt(i));
   }

    numItems = other.size();

    return *this;
}

// isEmpty() const
// Input: takes in no input
// Description: checks if the number of items (chars) in the arraylist is 0
// Output: a boolean value, true when the arraylist is empty and false 
// when not 
bool CharLinkedList::isEmpty() const
{
    return numItems == 0;
}

// clear()
// Input: takes in no input
// Description: recursively deletes nodes using my deletenode helper 
// function, then sets front and back to nullptr, reseting numItems to 0,
// effectively clear everything
// Output: no output
void CharLinkedList::clear()
{
   deletenode(front);

   front = nullptr;
   back = nullptr;
   numItems = 0;
}

// size() const
// Input: takes in no input
// Description: returns the size of the arraylist (how many chars are in it!)
// Output: returns the number of chars in the arraylist
int CharLinkedList::size() const
{
    return numItems;
}

// throw_runtime_error()
// Input: has no inputs
// Description: if the array is empty, contains no elements throws a runtime
// error since we can not pop something off an empty arraylist
// Output: nothing is void function
void CharLinkedList::throw_runtime_error()
{
    if (isEmpty()) {
        throw runtime_error("cannot pop from empty LinkedList");
    }
}

// first() const
// Input: takes in no input
// Description: throws a runtime error if the list is empty, otherwise
// it returns the char at the front of the list
// Output: returns that char at the 0th index
char CharLinkedList::first() const
{
    if (isEmpty()) {
        throw runtime_error ("cannot get first of empty LinkedList"); 
    } else {
        return front->data;
    }
}

// last() const
// Input: takes in no input
// Description: throws are runtime error if the list is empty, otherwise
// returns the char at the back of the list
// Output: returns that char at the last index
char CharLinkedList::last() const
{
    if (isEmpty()) {
        throw runtime_error ("cannot get last of empty LinkedList"); 
    } else {
        return back->data;
    }
}

// elementAt(int index) const
// Input: takes in an integer that represents the index in the linked
// list we want to recurse to
// Description: throws a range error to check if the index is valid,
// then recurses down to the node we desire, using a helper function
// Output: returns the char at the index that the user wants
char CharLinkedList::elementAt(int index) const
{
    range_error2(index);

    Node *the_node = recursivecheck(front, index);

    return the_node->data;
}

// range_error(int index) const
// Input: takes in an integer that represnts teh index of the array the user
// wants to access
// Description: throws the range_error with the BRACKET at the end if the 
// index the user wants to access it outside of the arraylist
// Output: does not return anything, just a range_error if the index is 
// out of bounds
void CharLinkedList::range_error1(int index) const
{
    if (index < 0 or index > numItems) {
        throw range_error ("index (" + to_string(index) + ") not in range " 
             + "[0.." + to_string(numItems) + "]");
    }
}

// range_error2(int index) const
// Input: takes in an integer that represnts teh index of the array the user
// wants to access
// Description: throws the range_error with the PARENTHESIS at the end if the 
// index the user wants to access it outside of the arraylist
// Output: does not return anything, just a range_error if the index is 
// out of bounds
void CharLinkedList::range_error2(int index) const
{
    if (index < 0 or index >= numItems) {
        throw range_error ("index (" + to_string(index) + ") not in range " 
             + "[0.." + to_string(numItems) + ")");
    }
}

// toString() const
// Input: does not have any input
// Description: creates a stringstream message, a node pointer to the 
// front of the link list and travels down the list until that pointer
// is null, adding to the message as we traverse
// Output: returns a string with message "[CharArrayList of size "numItems" 
// <<message>>], even if the message is empty
string CharLinkedList::toString() const 
{
    stringstream message;

        message << "[CharLinkedList of size " << numItems << " <<";

        Node *curr = front;

        while (curr != nullptr) {
            message << curr->data;
            curr = curr->next;
        }

        message << ">>]";

    return message.str();
}

// toReverseString() const
// Input: does not have any input
// Description: creates a stringstream message and a node pointer 
// that points to the back of the link list and travels down the list
// until that pointer is null, adding to the message backwards as we 
// traverse
// Output: returns a string with message "[CharArrayList of size "numItems" 
// <<message>>], even if the message is empty
string CharLinkedList::toReverseString() const 
{
    stringstream message;

        message << "[CharLinkedList of size " << numItems << " <<";

        Node *curr = back;

        while (curr != nullptr) { 
            message << curr->data;
            curr = curr->prev;
        }

        message << ">>]";

    return message.str();
}

// create_node(char c, Node *nextnode, Node *prevnode) 
// Input: does not have any input
// Description: helper function that creates a new node, assigns c to
// to its data value and sets up nextnode and prevnode
// Output: returns a node pointer to this newnode we created
CharLinkedList::Node* CharLinkedList::create_node(char c, Node *nextnode, 
                                                  Node *prevnode) 
{
    Node *newnode = new Node;
    newnode->data = c;
    newnode->next = nextnode;
    newnode->prev = prevnode;

    return newnode;
}

// pushAtFront(char c)
// Input: takes in a char c
// Description: uses the elementAt function to push a char to the front
// of the linked list. handles whether this is added to an emptylist, 
// list with one char or many 
// Output: nothing is void function
void CharLinkedList::pushAtFront(char c) 
{
    insertAt(c, 0);
}

// pushAtBack(char c)
// Input: takes in a char c
// Description: uses teh elementAt function to push a char to the back of
// a linked list. handles if this is added to an emptylist, list with one
// char or many
// Output: nothing is void function
void CharLinkedList::pushAtBack(char c)
{
    
    insertAt(c, numItems);
}

// insertAt(char c, int index)
// Input: takes in a char c and an integer value that represents the index 
// of the array the user wants to access
// Description: throws a range error to see if the user wants to access
// an index out of bounds, creates an instance of a new node, and is 
// able to handles if the node is added to an empty list, to the front
// of a list, the back of a list, or somewhere in the middle, adjusting
// the pointers to prev, next, front, and back as needed (also increases
// numItems by 1 since we are adding a char to the linkedlist)
// Output: nothing is void function
void CharLinkedList::insertAt(char c, int index)
{
    range_error1(index);

    Node *newnode = create_node(c, nullptr, nullptr);
    // allows for inserting into an emptylist
    if (isEmpty()) {
        front = newnode;
        back = newnode;
    } 
    // allows for inserting in the front
    else if (index == 0) {
        front->prev = newnode;
        newnode->next = front;
        front = newnode;
    // allows for inserting in the back
    } else if (index == numItems) {
        back->next = newnode;
        newnode->prev = back;
        back = newnode;
    // allows for inserting somewhere in the middle
    } else {
        Node *current = recursivecheck(front, index);
        newnode->prev = current->prev;
        current->prev->next = newnode;
        newnode->next = current;
        current->prev = newnode;
    }
    numItems++;
}

// insertInOrder(char c)
// Input: takes in a char c
// Description: when the list is in alphabetical order, this function will 
// be able to loop through the items within the linkedlist, and compare the
// ascii values of the two chars, and place where it goes alphabetically.
// since we are inserting something we also add 1 to numItems
// Output: nothing is void function
void CharLinkedList::insertInOrder(char c)
{
    if (isEmpty()) {
        insertAt(c, 0);
        return;
    }

    for (int index = 0; index < numItems; index++) {
        Node *info = recursivecheck(front, index);
        if (info->data > c){
            insertAt(c, index);
            return;
        }
    }
    pushAtBack(c);
}

// popFromFront()
// Input: has no inputs
// Description: throws a runtime_error, adds a node to the front of the 
// linkedlist, updating the front, next, and prev pointers as needed, and
// also deleting the old front node that is no longer present
// Output: nothing is void function
void CharLinkedList::popFromFront()
{
    throw_runtime_error();
    Node *trash = front;
    front = front->next;
    if (front == nullptr) {
        back = nullptr;
    } else {
        front->prev = nullptr;
    }
    numItems--;
    delete trash; 
}

// popFromBack()
// Input: has no inputs
// Description: throws a runtime_error, adds a node to the back of the 
// linkedlist, updating the back, next, and prev pointers as needed, and
// also deleting the old back node that is no longer present
// Output: nothing is void function
void CharLinkedList::popFromBack()
{
    throw_runtime_error();
    Node *trash = back; 

    back = back->prev;
    if (back == nullptr) {
        front = nullptr;
    } else {
        back->next = nullptr;
    }
    numItems--;
    delete trash; 
}

// recursivecheck(Node *curr, int index) const
// Input: takes in a node pointer called curr and a index we want to 
// recurse down to in the linkedlist
// Description: is a recursive helper function returns a node pointer
// to the index of a node we want to use in other functions. 
// Output: returns a node pointer to the index we want to get and use
// in other functions
CharLinkedList::Node* CharLinkedList::recursivecheck(Node *curr, int index) 
                                                     const
{
    if (index == 0) {
        return curr;
    } else {
        return recursivecheck(curr->next, index - 1);
    }
}

// removeAt()
// Input: takes in an integer value that represents the index the user wants
// to access
// Description: throws an range error (outrange is the range error with the 
// parenthesis) and then creates a node pointer to the front of the list and
// calls upon recursivecheck on that node pointer. then based on the index
// handles removing a node in the beginning of the list, at the end of a
// list, or somewhere in teh middle. also handles when we are removing
// the only element in a list. decreases numItems by 1 and deletes the node
// we removed from the linked list
// Output: nothing is void function
void CharLinkedList::removeAt(int index)
{
    range_error2(index);

    Node *curr = front;
    curr = recursivecheck(front, index);
    if (index == 0) {
        if (curr->next != nullptr) {
        curr->next->prev = nullptr;
        }
        front = curr->next;
    } else if (index == numItems) {
        curr->next = nullptr;
        back = curr->prev;
    } else {
    curr->prev->next = curr->next;
    curr->next->prev = curr->prev;
    }
    numItems--;
    delete curr;
}

// replaceAt()
// Input: takes in a char c and an integer value that represents the index the
// user wants to access
// Description:  throws a range error and calls teh recursivecheck 
// function that gives us a pointer to the node at the index we desire,
// then I update that nodes info with the new nodes data
// Output: nothing is void function
void CharLinkedList::replaceAt(char c, int index)
{
    range_error2(index);
    Node *trashed_node = recursivecheck(front, index);
    trashed_node->data = c;
}

// concatenate(CharArrayList *other)
// Input: takes in a pointer to a CharArrayList
// Description: checks if the pointer to the second CharArrayList is the 
// same list as the first, if it is handles this edge case if not, pushes
// each character of the second arraylist onto the back of the list
// Output: nothing is void function
void CharLinkedList::concatenate(CharLinkedList *other)
{
    if (this == other) {
        CharLinkedList copy(*other);
        Node *curr = copy.front;
        for (int i = 0; i < copy.size(); i++) {
            pushAtBack(curr->data);
            curr = curr->next;
        } 
    }
    else {
        Node *current = other->front;
        for (int i = 0; i < other->size(); i++) {
            pushAtBack(current->data);
            current = current->next;
        }
    }
}
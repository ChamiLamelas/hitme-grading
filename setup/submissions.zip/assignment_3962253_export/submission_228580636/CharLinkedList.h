/*
 *  CharLinkedList.h
 *  Jack Mandell
 *  2/6/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Purpose:
 *  The CharLinkedList class defines instances of the abtract data type (ADT)
 *  of "list". That is, an instance of the CharLinkedClass will be a resizable,
 *  modifiable list of specifically data type "char". When a CharLinkedList is
 *  made, it may be created in one of four ways:
 *      1. It can be made empty
 *      2. It can be made with one element specified by the user
 *      3. It can be made with many elements specified by the user
 *      4. It can be made by becoming a copy of a seperate CharLinkedList
 *         specified by the user
 *  There are many public methods that allow for the modification of a given
 *  CharLinkedList. The most important ones may be described as the following:
 *      1. pushAtBack(char c) takes an input element (char) and adds it to the
 *         back of a CharLinkedList
 *      2. pushAtFront(char c) takes an input element (char) and adds it to the
 *         front of a CharLinkedList
 *      3. insertAt(char c, int index) takes an input element (char) and a
 *         valid input index (int) and adds the specified element to a
 *         CharLinkedList at the specified index
 *      4. popFromFront() removes the first element of a CharLinkedList
 *      5. popFromBack() removes the last element of a CharLinkedList
 *      6. removeAt(int index) takes a valid input index (int) and removes from
 *         a CharLinkedList the element at the specified index
 *      7. replaceAt(char c, int index) takes an input element (char) and a
 *         valid input index (int) and replaces the element of a CharLinkedList
 *         at the specified index with the specified element
 *      8. isEmpty() returns true if a CharLinkedList is empty and false
 *         otherwise
 *      9. clear() empties all elements from a CharLinkedList
 *      10. size() returns the number of elements in a CharLinkedList
 *      11. first() returns the first element of a CharLinkedList
 *      12. last() returns the last element of a CharLinkedList
 *      13. elementAt(int index) takes a valid input index (int) and returns
 *          the element of a CharLinkedList at the specified index
 *      14. toString() returns a CharLinkedList as a string
 *  There are more functions that may be of use for more specific scenarios--
 *  please see the below definitions as well as the .cpp file for more
 *  explanation.
 *
 */

#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H

#include <iostream>
#include <string>

using namespace std;

class CharLinkedList {
public:
    CharLinkedList();
    CharLinkedList(char c);
    CharLinkedList(char arr[], int size);
    CharLinkedList(const CharLinkedList &other);
    ~CharLinkedList();
    CharLinkedList &operator=(const CharLinkedList &other);
    void pushAtBack(char c);
    void pushAtFront(char c);
    void insertAt(char c, int index);
    void insertInOrder(char c);
    void popFromFront();
    void popFromBack();
    void removeAt(int index);
    void replaceAt(char c, int index);
    void concatenate(CharLinkedList *other);
    bool isEmpty() const;
    void clear();
    int size() const;
    char first() const;
    char last() const;
    char elementAt(int index) const;
    std::string toString() const;
    std::string toReverseString() const;
private:
    // struct Node stores element data (char c) as well as two pointers to
    // other Nodes representing the previous and next elements in the linked
    // list (Node *prev and Node *next)
    struct Node {
        char c;
        Node *prev;
        Node *next;
    };
    int numItems;
    Node *front;
    Node *back;

    // helper functions below
    void initializeEmptyHelper();
    void insertEmptyHelper(char c);
    void initializeArrayHelper(char arr[], int size);
    void destructorRecHelper(Node *curr_node);
    Node *elAtRecHelp(Node *curr, int &idx) const;
    std::string intToString(int num) const;
};

#endif

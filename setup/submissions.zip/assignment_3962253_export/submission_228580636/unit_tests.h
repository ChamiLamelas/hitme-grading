/*
 *  unit_tests.h
 *  Jack Mandell
 *  2/6/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  Purpose:
 *  This file contains a number of tests on the methods of the CharLinkedList
 *  class. All tests have been passed.
 *
 */

#include "CharLinkedList.h"
#include <cassert>

// Tests default constructor builds an empty list
void constructor_default() {
    CharLinkedList test_list;
    assert(test_list.size() == 0);
}

// Tests one-element constructor builds a list with one element
void constructor_one_element() {
    CharLinkedList test_list('a');
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');
}

// Tests many-element constructor builds a list with no elements
void constructor_empty_array() {
    char test_arr[0] = {};
    CharLinkedList test_list(test_arr, 0);
    assert(test_list.size() == 0);
}

// Tests many-element constructor builds a list with no elements for error
void constructor_empty_array_incorrect() {
    char test_arr[0] = {};
    CharLinkedList test_list(test_arr, 0);
    assert(test_list.size() == 0);
    bool range_error_thrown = false;
    string error_message = "";
    try {
        test_list.elementAt(0);
    } catch (const range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (0) not in range [0..0)");
}

// Tests many-element constructor builds a list with a given amount of
// elements
void constructor_sized_array() {
    char test_arr[9] = {'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(test_arr, 9);
    assert(test_list.size() == 9);
    for (int i = 0; i < 9; i++) {
        assert(test_list.elementAt(i) == test_arr[i]);
    }
}

// Tests copy constructor with an empty list
void constructor_copy_empty_list() {
    CharLinkedList list;
    CharLinkedList test_list(list);
    assert(test_list.size() == 0);
}

// Tests copy constructor with a one-element list
void constructor_copy_one_element() {
    CharLinkedList list('a');
    CharLinkedList test_list(list);
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');
}

// Tests copy constructor with a sized list
void constructor_copy_sized_array() {
    char test_arr[9] = {'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList list(test_arr, 9);
    CharLinkedList test_list(list);
    assert(test_list.size() == 9);
    for (int i = 0; i < 9; i++) {
        assert(test_list.elementAt(i) == test_arr[i]);
    }
}

// Tests overide assignment operator with a one-element list
void assignment_operator_one_element() {
    CharLinkedList list('a');
    CharLinkedList test_list;
    test_list = list;
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');
}

// Tests overide assignment operator with a sized list
void assignment_operator_sized_list() {
    char arr[9] = {'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList list(arr, 9);
    CharLinkedList test_list;
    test_list = list;
    assert(test_list.size() == 9);
    for (int i = 0; i < 9; i++) {
        assert(test_list.elementAt(i) == list.elementAt(i));
    }
}

// Tests overide assignment operator with two sized lists, one being
// overwritten
void assignment_operator_sized_list_onto_nonempty_list() {
    char arr1[9] = {'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h'};
    char arr2[3] = {'x', 'y', 'z'};
    CharLinkedList list(arr1, 9);
    CharLinkedList test_list(arr2, 3);
    test_list = list;
    assert(test_list.size() == 9);
    for (int i = 0; i < 9; i++) {
        assert(test_list.elementAt(i) == list.elementAt(i));
    }
}

// Tests pushAtBack with an empty list
void pushAtBack_empty_list() {
    CharLinkedList test_list;
    test_list.pushAtBack('a');
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');
}

// Tests pushAtBack with a sized list
void pushAtBack_sized_list() {
    char arr[9] = {'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(arr, 9);
    test_list.pushAtBack('i');
    assert(test_list.size() == 10);
    for (int i = 0; i < 9; i++) {
        assert(test_list.elementAt(i) == arr[i]);
    }
    assert(test_list.elementAt(9) == 'i');
}

// Tests pushAtFront with an empty list
void pushAtFront_empty_list() {
    CharLinkedList test_list;
    test_list.pushAtFront('a');
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');
}

// Tests pushAtFront with a sized list
void pushAtFront_sized_list() {
    char arr[9] = {'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(arr, 9);
    test_list.pushAtFront('z');
    assert(test_list.size() == 10);
    for (int i = 0; i < 9; i++) {
        assert(test_list.elementAt(i + 1) == arr[i]);
    }
    assert(test_list.elementAt(0) == 'z');
}

// Tests correct insertion into an empty LL
void insertAt_empty_correct() {
    CharLinkedList test_list;
    test_list.insertAt('a', 0);
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');
}

// Tests incorrect insertion into an empty LL
void insertAt_empty_incorrect() {
    bool range_error_thrown = false;
    std::string error_message = "";
    CharLinkedList test_list;
    try {
    test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
    range_error_thrown = true;
    error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0]");
}

// Tests correct insertAt for front of 1-element list
void insertAt_front_singleton_list() {
    CharLinkedList test_list('a');
    test_list.insertAt('b', 0);
    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'a');
}

// Tests correct insertAt for back of 1-element list
void insertAt_back_singleton_list() {
    CharLinkedList test_list('a');
    test_list.insertAt('b', 1);
    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
}

// Tests calling insertAt for a large number of elements
void insertAt_many_elements() {
    CharLinkedList test_list;
    for (int i = 0; i < 1000; i++) {
        test_list.insertAt('a', i);
    }
    assert(test_list.size() == 1000);
    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
}

// Tests insertion into front of a larger list
void insertAt_front_large_list() {
    char test_arr[9] = {'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(test_arr, 9);
    test_list.insertAt('y', 0);
    assert(test_list.size() == 10);
    assert(test_list.elementAt(0) == 'y');
    string output = "[CharLinkedList of size 10 <<yabczdefgh>>]";
    assert(test_list.toString() == output);
}

// Tests insertion into the back of a larger list
void insertAt_back_large_list() {
    char test_arr[10] = {'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(test_arr, 10);  
    test_list.insertAt('x', 10);
    assert(test_list.size() == 11);
    assert(test_list.elementAt(10) == 'x');
    string output = "[CharLinkedList of size 11 <<yabczdefghx>>]";
    assert(test_list.toString() == output);
}

// Tests insertion into the middle of a larger list
void insertAt_middle_large_list() {
    char test_arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(test_arr, 8);
    test_list.insertAt('z', 3);
    assert(test_list.size() == 9);
    assert(test_list.elementAt(3) == 'z');
    string output = "[CharLinkedList of size 9 <<abczdefgh>>]";
    assert(test_list.toString() == output);
}

// Tests out-of-range insertion for a non-empty list.
void insertAt_nonempty_incorrect() {
    char test_arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(test_arr, 8);
    bool range_error_thrown = false;
    std::string error_message = "";
    try {
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8]");
}

// Tests insertInOrder with an empty list
void insertInOrder_empty_list() {
    CharLinkedList test_list;
    test_list.insertInOrder('a');
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');
}

// Tests insertInOrder at the end with a sized list 
void insertInOrder_sized_list() {
    char arr[9] = {'a', 'b', 'c', 'd', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(arr, 9);
    test_list.insertInOrder('z');
    assert(test_list.size() == 10);
    for (int i = 0; i < 9; i++) {
        assert(test_list.elementAt(i) == arr[i]);
    }
    assert(test_list.elementAt(9) == 'z');
}

// Tests insertInOrder in the middle with a sized list 
void insertInOrder_middle_char_sized_list() {
    char arr[9] = {'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(arr, 9);
    test_list.insertInOrder('z');
    assert(test_list.size() == 10);
    for (int i = 0; i < 3; i++) {
        assert(test_list.elementAt(i) == arr[i]);
    }
    assert(test_list.elementAt(3) == 'z');
    for (int i = 3; i < 9; i++) {
        assert(test_list.elementAt(i + 1) == arr[i]);
    }
    assert(test_list.elementAt(9) == 'h');
}

// Tests popFromFront with a sized list
void popFromFront_sized_array() {
    char arr[9] = {'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(arr, 9);
    test_list.popFromFront();
    assert(test_list.size() == 8);
    for (int i = 0; i < 8; i++) {
        assert(test_list.elementAt(i) == arr[i + 1]);
    }
}

// Tests popFromFront for error with an empty list
void popFromFront_incorrect() {
    CharLinkedList test_list;
    bool runtime_error_thrown = false;
    string error_message = "";
    try {
        test_list.popFromFront();
    } catch (const runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

// Tests popFromBack with a sized list
void popFromBack_sized_array() {
    char arr[9] = {'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(arr, 9);
    test_list.popFromBack();
    assert(test_list.size() == 8);
    for (int i = 0; i < 8; i++) {
        assert(test_list.elementAt(i) == arr[i]);
    }
}

// Tests popFromBack for error with an empty list
void popFromBack_incorrect() {
    CharLinkedList test_list;
    bool runtime_error_thrown = false;
    string error_message = "";
    try {
        test_list.popFromBack();
    } catch (const runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

// Tests removeAt for error with an empty list
void removeAt_empty_incorrect() {
    CharLinkedList test_list;
    bool range_error_thrown = false;
    string error_message = "";
    try {
        test_list.removeAt(0);
    } catch (const range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (0) not in range [0..0)");
}

// Tests removeAt the front with a sized list
void removeAt_front_sized_array() {
    char arr[9] = {'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(arr, 9);
    test_list.removeAt(0);
    assert(test_list.size() == 8);
    for (int i = 0; i < 8; i++) {
        assert(test_list.elementAt(i) == arr[i + 1]);
    }
}

// Tests removeAt the middle with a sized list
void removeAt_middle_sized_array() {
    char arr[9] = {'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(arr, 9);
    test_list.removeAt(4);
    assert(test_list.size() == 8);
    for (int i = 0; i < 4; i++) {
        assert(test_list.elementAt(i) == arr[i]);
    }
    for (int i = 4; i < 8; i++) {
        assert(test_list.elementAt(i) == arr[i + 1]);
    }
}

// Tests removeAt the back with a sized list
void removeAt_back_sized_array() {
    char arr[9] = {'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(arr, 9);
    test_list.removeAt(8);
    assert(test_list.size() == 8);
    for (int i = 0; i < 8; i++) {
        assert(test_list.elementAt(i) == arr[i]);
    }
}

// Tests removeAt out-of-bounds error with a sized list
void removeAt_sized_array_incorrect() {
    char arr[9] = {'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(arr, 9);
    bool range_error_thrown = false;
    string error_message = "";
    try {
        test_list.removeAt(9);
    } catch (const range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (9) not in range [0..9)");
}

// Tests replaceAt for error with an empty list
void replaceAt_empty_incorrect() {
    CharLinkedList test_list;
    bool range_error_thrown = false;
    string error_message = "";
    try {
        test_list.replaceAt('a', 0);
    } catch (const range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (0) not in range [0..0)");
}

// Tests replaceAt the middle with a sized list
void replaceAt_sized_array() {
    char arr[9] = {'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(arr, 9);
    test_list.replaceAt('t', 4);
    assert(test_list.size() == 9);
    for (int i = 0; i < 4; i++) {
        assert(test_list.elementAt(i) == arr[i]);
    }
    assert(test_list.elementAt(4) == 't');
    for (int i = 5; i < 9; i++) {
        assert(test_list.elementAt(i) == arr[i]);
    }
}

// Tests concatenate with a sized list onto an empty list
void concatenate_empty_array() {
    char arr[3] = {'c', 'a', 't'};
    CharLinkedList list(arr, 3);
    CharLinkedList test_list;
    test_list.concatenate(&list);
    assert(test_list.size() == 3);
    for (int i = 0; i < 3; i++) {
        assert(test_list.elementAt(i) == arr[i]);
    }
}

// Tests concatenate with a sized list onto a sized list
void concatenate_sized_array() {
    char arr[3] = {'c', 'a', 't'};
    CharLinkedList list(arr, 3);
    CharLinkedList test_list(arr, 3);
    test_list.concatenate(&list);
    assert(test_list.size() == 6);
    for (int i = 0; i < 3; i++) {
        assert(test_list.elementAt(i) == arr[i]);
    }
    for (int i = 0; i < 3; i++) {
        assert(test_list.elementAt(i + 3) == arr[i]);
    }
}

// Tests concatenate with a sized list onto itself
void concatenate_sized_array_itself() {
    char arr[3] = {'c', 'a', 't'};
    CharLinkedList test_list(arr, 3);
    test_list.concatenate(&test_list);
    assert(test_list.size() == 6);
    for (int i = 0; i < 3; i++) {
        assert(test_list.elementAt(i) == arr[i]);
    }
    for (int i = 0; i < 3; i++) {
        assert(test_list.elementAt(i + 3) == arr[i]);
    }
}

// Tests isEmpty with an empty list
void isEmpty_true() {
    CharLinkedList test_list;
    assert(test_list.isEmpty());
}

// Tests isEmpty with a nonempty list
void isEmpty_false() {
    CharLinkedList test_list('a');
    assert(not test_list.isEmpty());
}

// Tests clear with a nonempty list
void clear_check() {
    CharLinkedList test_list('a');
    test_list.clear();
    assert(test_list.isEmpty());
}

// Tests size with a nonempty list
void size_check() {
    CharLinkedList test_list('a');
    assert(test_list.size() == 1);
}

// Tests first with a nonempty list
void first_sized_array() {
    CharLinkedList test_list('a');
    assert(test_list.first() == 'a');
}

// Tests first for error with an empty list
void first_empty_array_incorrect() {
    CharLinkedList test_list;
    bool runtime_error_thrown = false;
    string error_message = "";
    try {
        test_list.first();
    } catch (const runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "cannot get first of empty LinkedList");
}

// Tests last with a nonempty list
void last_sized_array() {
    CharLinkedList test_list('a');
    assert(test_list.last() == 'a');
}

// Tests elementAt with a sized list
void elementAt_sized_array() {
    char arr[9] = {'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(arr, 9);
    for (int i = 0; i < 9; i++) {
        assert(test_list.elementAt(i) == arr[i]);
    }
}

// Tests toString with a sized list
void toString_sized_array() {
    char arr[9] = {'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(arr, 9);
    assert(test_list.toString() == "[CharLinkedList of size 9 <<abczdefgh>>]");
}

// Tests toString with an empty list
void toString_empty_array() {
    CharLinkedList test_list;
    assert(test_list.toString() == "[CharLinkedList of size 0 <<>>]");
}

// Tests toReverseString with a sized list
void toReverseString_sized_array() {
    char arr[9] = {'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(arr, 9);
    string output = "[CharLinkedList of size 9 <<hgfedzcba>>]";
    assert(test_list.toReverseString() == output);
}

/*
 *  CharLinkedList.cpp
 *  Jack Mandell
 *  2/6/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Purpose:
 *  This file contains the implementation of the CharLinkedList class. It has
 *  completed function contracts for each of the 29 public and private methods
 *  that explain at a high level what the method does for the class to
 *  ultimately implement the abstract data type (ADT) of list.
 *
 */

#include "CharLinkedList.h"
#include <sstream>
#include <stdexcept>

/*
 * name:      CharLinkedList (constructor)
 * purpose:   initialize an empty CharLinkedList
 * arguments: none
 * returns:   N/A
 * effects:   none
 */
CharLinkedList::CharLinkedList() {
    initializeEmptyHelper();
}

/*
 * name:      CharLinkedList (constructor)
 * purpose:   initialize a CharLinkedList with one element
 * arguments: an element (char) to be the single element of a CharLinkedList
 * returns:   N/A
 * effects:   none
 */
CharLinkedList::CharLinkedList(char c) {
    insertEmptyHelper(c);
}

/*
 * name:      CharLinkedList (constructor)
 * purpose:   initialize a CharLinkedList with any number of elements
 * arguments: an array of elements (char) to be the only elements of a
 *            CharLinkedList and a number (int) indicating how many elements
 *            there are in said array
 * returns:   N/A
 * effects:   none
 */
CharLinkedList::CharLinkedList(char arr[], int size) {
    // use of helpers avoids necesity for constructors inside constructors
    if (size == 0) {
        initializeEmptyHelper();
    } else if (size == 1) {
        insertEmptyHelper(arr[0]);
    } else {
        initializeArrayHelper(arr, size);
    }  
}

/*
 * name:      CharLinkedList (constructor)
 * purpose:   initialize a CharLinkedList that is an exact copy of another
 *            CharLinkedList
 * arguments: a CharLinkedList
 * returns:   N/A
 * effects:   none
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other) {
    // use of helpers avoids necesity for constructors inside constructors
    if (other.isEmpty()) {
        initializeEmptyHelper();
    } else if (other.size() == 1) {
        insertEmptyHelper(other.front->c);
    } else {
        char arr[other.size()];
        for (int i = 0; i < other.size(); i++) {
            arr[i] = other.elementAt(i);
        }
        initializeArrayHelper(arr, other.size());
    }
}

/*
 * name:      ~CharLinkedList (destructor)
 * purpose:   free the heap memory that a CharLinkedList uses
 * arguments: none
 * returns:   N/A
 * effects:   none
 */
CharLinkedList::~CharLinkedList() {
    if (isEmpty()) {
        return;
    } else {
        destructorRecHelper(front);
    }
}

/*
 * name:      operator= (overload assignment operator)
 * purpose:   change the functionality of the assignment operator "=" so that
 *            when a user attempts to assign one CharLinkedList to another, a
 *            deep copy will be made (meaning that componenets of the
 *            CharLinkedLists will not share any unique data)
 * arguments: a CharLinkedList
 * returns:   N/A
 * effects:   none
 */
CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other) {
    if (this == &other) {
        return *this;
    }
    if (not isEmpty()) {
        destructorRecHelper(front);
    }
    if (other.isEmpty()) {
        initializeEmptyHelper();
    } else if (other.size() == 1) {
        insertEmptyHelper(other.front->c);
    } else {
        char arr[other.size()];
        for (int i = 0; i < other.size(); i++) {
            arr[i] = other.elementAt(i);
        }
        initializeArrayHelper(arr, other.size());
    }
    return *this;
}

/*
 * name:      pushAtBack
 * purpose:   add a given element to the back of a CharLinkedList
 * arguments: an element (char)
 * returns:   N/A
 * effects:   none
 */
void CharLinkedList::pushAtBack(char c) {
    if (isEmpty()) {
        insertEmptyHelper(c);
    } else {
        Node *new_node = new Node;
        new_node->c = c;
        new_node->prev = back;
        new_node->next = nullptr;
        back->next = new_node;
        back = new_node;
        numItems++;
    }
}

/*
 * name:      pushAtFront
 * purpose:   add a given element to the front of a CharLinkedList
 * arguments: an element (char)
 * returns:   N/A
 * effects:   none
 */
void CharLinkedList::pushAtFront(char c) {
    if (isEmpty()) {
        insertEmptyHelper(c);
    } else {
        Node *new_node = new Node;
        new_node->c = c;
        new_node->prev = nullptr;
        new_node->next = front;
        front->prev = new_node;
        front = new_node;
        numItems++;
    }
}

/*
 * name:      insertAt
 * purpose:   add a given element to a CharLinkedList at a given index
 * arguments: an element (char) and an index (int)
 * returns:   N/A
 * effects:   throws an error if the index is not in the range of the
 *            CharLinkedList
 */
void CharLinkedList::insertAt(char c, int index) {
    if (index < 0 or index > size()) {
        throw range_error("index (" +
                          intToString(index) +
                          ") not in range [0.." +
                          intToString(size()) +
                          "]");
    }
    if (isEmpty()) {
        insertEmptyHelper(c);
    } else if (index == 0) {
        pushAtFront(c);
    } else if (index == size()) {
        pushAtBack(c);
    } else {
        Node *new_node = new Node;
        Node *next_node = elAtRecHelp(front, index);
        Node *prev_node = next_node->prev;
        prev_node->next = new_node;
        next_node->prev = new_node;
        new_node->c = c;
        new_node->prev = prev_node;
        new_node->next = next_node;
        numItems++;
    }
}

/*
 * name:      insertInOrder
 * purpose:   add a given element to a CharLinkedList at the first position in
 *            the CharLinkedList where the ASCII value of the given element is
 *            smaller than the next element in the CharLinkedList.
 * arguments: an element (char)
 * returns:   N/A
 * effects:   none
 */
void CharLinkedList::insertInOrder(char c) {
    bool broken = false;
    int index = 0;
    for (int i = 0; i < size(); i++) {
        if (broken) {
            continue;
        }
        if (c <= elementAt(i)) {
            broken = true;
        } else {
            index++;
        }
    }
    insertAt(c, index);
}

/*
 * name:      popFromFront
 * purpose:   remove the first element of a CharLinkedList
 * arguments: none
 * returns:   N/A
 * effects:   throws an error if the CharLinkedList is empty
 */
void CharLinkedList::popFromFront() {
    if (isEmpty()) {
        throw runtime_error("cannot pop from empty LinkedList");
    }
    if (size() == 1) {
        delete front;
        initializeEmptyHelper();
    } else {
        Node *new_front = front->next;
        new_front->prev = nullptr;
        delete front;
        front = new_front;
        numItems--;
    }    
}

/*
 * name:      popFromBack
 * purpose:   remove the last element of a CharLinkedList
 * arguments: none
 * returns:   N/A
 * effects:   throws an error if the CharLinkedList is empty
 */
void CharLinkedList::popFromBack() {
    if (isEmpty()) {
        throw runtime_error("cannot pop from empty LinkedList");
    }
    if (size() == 1) {
        delete back;
        initializeEmptyHelper();
    } else {
        Node *new_back = back->prev;
        new_back->next = nullptr;
        delete back;
        back = new_back;
        numItems--;
    }
}

/*
 * name:      removeAt
 * purpose:   remove from a CharLinkedList the element at a given index
 * arguments: an index (int)
 * returns:   N/A
 * effects:   throws an error if the index is not in the range of the
 *            CharLinkedList
 */
void CharLinkedList::removeAt(int index) {
    if (index < 0 or index > size() - 1) {
        throw range_error("index (" +
                          intToString(index) +
                          ") not in range [0.." +
                          intToString(size()) +
                          ")");
    }
    if (size() == 1) {
        delete front;
        initializeEmptyHelper();
    } else if (index == 0) {
        popFromFront();
    } else if (index == size() - 1) {
        popFromBack();
    } else {
        Node *remove_node = elAtRecHelp(front, index);
        Node *prev_node = remove_node->prev;
        Node *next_node = remove_node->next;
        prev_node->next = next_node;
        next_node->prev = prev_node;
        delete remove_node;
        numItems--;
    }
}

/*
 * name:      replaceAt
 * purpose:   replace the element of a CharLinkedList at a given index with
 *            a given element
 * arguments: an element (char) and an index (int)
 * returns:   N/A
 * effects:   throws an error if the index is not in the range of the
 *            CharLinkedList
 */
void CharLinkedList::replaceAt(char c, int index) {
    if (index < 0 or index > size() - 1) {
        throw range_error("index (" +
                          intToString(index) +
                          ") not in range [0.." +
                          intToString(size()) +
                          ")");
    }
    elAtRecHelp(front, index)->c = c;
}

/*
 * name:      concatenate
 * purpose:   add all of the elements of a given CharLinkedList to the back of
 *            a CharLinkedList
 * arguments: a pointer to a CharLinkedList
 * returns:   N/A
 * effects:   none
 */
void CharLinkedList::concatenate(CharLinkedList *other) {
    CharLinkedList other_copy(*other);
    for (int i = 0; i < other_copy.size(); i++) {
        pushAtBack(other_copy.elementAt(i));
    }
}

/*
 * name:      isEmpty
 * purpose:   return true if a CharLinkedList is empty and false otherwise
 * arguments: none
 * returns:   bool true or false
 * effects:   none
 */
bool CharLinkedList::isEmpty() const {
    if (size() == 0) {
        return true;
    }
    return false;
}

/*
 * name:      clear
 * purpose:   empty all elements from a CharLinkedList
 * arguments: none
 * returns:   N/A
 * effects:   none
 */
void CharLinkedList::clear() {
    destructorRecHelper(front);
    initializeEmptyHelper();
}

/*
 * name:      size
 * purpose:   return the number of elements in a CharLinkedList
 * arguments: none
 * returns:   int number of elements
 * effects:   none
 */
int CharLinkedList::size() const {
    return numItems;
}

/*
 * name:      first
 * purpose:   return the first element of a CharLinkedList
 * arguments: none
 * returns:   char element
 * effects:   throws an error if the CharLinkedList is empty
 */
char CharLinkedList::first() const {
    if (isEmpty()) {
        throw runtime_error("cannot get first of empty LinkedList");
    }
    return front->c;
}

/*
 * name:      last
 * purpose:   return the last element of a CharLinkedList
 * arguments: none
 * returns:   char element
 * effects:   throws an error if the CharLinkedList is empty
 */
char CharLinkedList::last() const {
    if (isEmpty()) {
        throw runtime_error("cannot get last of empty LinkedList");
    }
    return back->c;
}

/*
 * name:      elementAt
 * purpose:   return the element of a CharLinkedList at the given index
 * arguments: an index (int)
 * returns:   char element
 * effects:   throws an error if the index is not in the range of the
 *            CharLinkedList
 */
char CharLinkedList::elementAt(int index) const {
    if (index < 0 or index > size() - 1) {
        throw range_error("index (" +
                          intToString(index) +
                          ") not in range [0.." +
                          intToString(size()) +
                          ")");
    }
    return elAtRecHelp(front, index)->c;
}

/*
 * name:      toString
 * purpose:   return a CharLinkedList as a string
 * arguments: none
 * returns:   CharLinkedList as a string
 * effects:   none
 */
std::string CharLinkedList::toString() const {
    std::stringstream ss;
    ss << "[CharLinkedList of size ";
    ss << size();
    ss << " <<";
    for (int i = 0; i < size(); i++) {
        ss << elementAt(i);
    }
    ss << ">>]";
    return ss.str();
}

/*
 * name:      toReverseString
 * purpose:   return a CharLinkedList as a string that's been inverted
 * arguments: none
 * returns:   CharLinkedList as an inverted string
 * effects:   none
 */
std::string CharLinkedList::toReverseString() const {
    std::stringstream ss;
    ss << "[CharLinkedList of size ";
    ss << size();
    ss << " <<";
    for (int i = size() - 1; i > -1; i--) {
        ss << elementAt(i);
    }
    ss << ">>]";
    return ss.str();
}

/*
 * name:      initializeEmptyHelper
 * purpose:   reset a list
 * arguments: None
 * returns:   N/A
 * effects:   none
 */
void CharLinkedList::initializeEmptyHelper() {
    numItems = 0;
    front = nullptr;
    back = nullptr;
}

/*
 * name:      insertEmptyHelper
 * purpose:   reset a CharLinkedList with one given element
 * arguments: an element (char)
 * returns:   N/A
 * effects:   none
 */
void CharLinkedList::insertEmptyHelper(char c) {
    numItems = 1;
    Node *new_node = new Node;
    new_node->c = c;
    new_node->next = nullptr;
    new_node->prev = nullptr;
    front = new_node;
    back = new_node;
}

/*
 * name:      initializeArrayHelper
 * purpose:   reset a CharLinkedList with a given array of elements
 * arguments: an array of elements (char) to be the only elements of a
 *            CharLinkedList and a number (int) indicating how many elements
 *            there are in said array
 * returns:   N/A
 * effects:   none
 */
void CharLinkedList::initializeArrayHelper(char arr[], int size) {
    numItems = size;
    Node *node_holder;
    for (int i = 0; i < size; i++) {
        Node *new_node = new Node;
        if (i == 0) {
            new_node->prev = nullptr;
            front = new_node;
            node_holder = new_node;
        } else if (i == size - 1) {
            new_node->prev = node_holder;
            node_holder->next = new_node;
            new_node->next = nullptr;
            back = new_node;
        } else {
            new_node->prev = node_holder;
            node_holder->next = new_node;
            node_holder = new_node;
        }
        new_node->c = arr[i];
    }
}

/*
 * name:      destructorRecHelper
 * purpose:   help the destructor free the heap memory that a CharLinkedList
 *            uses
 * arguments: An address of something containing an element (pointer to a Node)
 * returns:   N/A
 * effects:   none
 */
void CharLinkedList::destructorRecHelper(Node *curr_node) {
    if (curr_node->next == nullptr) {
        delete curr_node;
    } else {
        destructorRecHelper(curr_node->next);
        delete curr_node;
    }
}

/*
 * name:      elAtRecHelp
 * purpose:   recursively help the elementAt function by returning information
 *            (a node) that contains the element
 * arguments: An address of something containing an element (pointer to a Node)
 *            and an index (inx passed by reference)
 * returns:   pointer to a node containing the element
 * effects:   none
 */
CharLinkedList::Node *CharLinkedList::elAtRecHelp(Node *curr, int &idx) const {
    if (idx == 0) {
        return curr;
    } else {
        idx--;
        return elAtRecHelp(curr->next, idx);
    }
}

/*
 * name:      intToString
 * purpose:   return an int as a string
 * arguments: an integer number (int)
 * returns:   string number
 * effects:   none
 */
std::string CharLinkedList::intToString(int num) const {
    std::stringstream ss;
    ss << num;
    return ss.str();
}

/*
 *  unit_tests.h
 *  YOUR NAME HERE
 *  DATE CREATED
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  This file includes the unit tests for the methods in CharLinked.cpp (h).
 *
 */

#include "CharLinkedList.h"
#include <cassert>
using namespace std;

// Tests correct if the initialized instance has a size 0 and is empty.
void first_constructor_test() { 
    
    CharLinkedList test_list;

    // assertions
    assert(test_list.size() == 0);
    assert(test_list.isEmpty());
}

// Tests correct if the initialized instance has a size 1 and one element.
void second_constructor_test() { 
    
    CharLinkedList test_list('T');
    
    // assertions
    assert(test_list.size() == 1);
    assert(test_list.first() == 'T');
    assert(test_list.last() == 'T');
}

// Tests correct if the initialized instance has a size same as the parameter 
// array and produces the right string.
void third_constructor_test() { 
     
    char test_arr[10] = { 'b', 'e', 'n', 't', 'u', 'r', 'k','i', 'y', 'e' };
    CharLinkedList test_list(test_arr, 10);

    // assertions
    assert(test_list.size() == 10);
    assert(test_list.first() == 'b');
    assert(test_list.last() == 'e');
    assert(test_list.toString() == 
                                "[CharLinkedList of size 10 <<benturkiye>>]");
}

// Tests correct if isEmpty returns true.
void isEmpty_correct_test() {
    
    CharLinkedList test_list;

    // assertions
    assert(test_list.isEmpty());
}

// Tests correct if isEmpty returns false.
void isEmpty_incorrect_test() {
    
    CharLinkedList test_list('O');

    // assertions
    assert(test_list.size() == 1);
    assert(not test_list.isEmpty());
}

// Tests correct for isEmpty().
void clear_test() { 

    char test_arr[10] = { 'b', 'e', 'n', 't', 'u', 'r', 'k','i', 'y', 'e' };
    CharLinkedList test_list(test_arr, 10);

    // Attempt
    test_list.clear();

    // assertions
    assert(test_list.isEmpty());
}

// Tests corrext for isEmpty(). Attempts to run clear()on an empty list.
void clear_empty_test() { 
    
    CharLinkedList test_list;

    // Attempt
    test_list.clear();

    // assertions
    assert(test_list.isEmpty());
}

// Tests correct for size 0.
void size_empty_test() { 

    char test_arr[0] = {};
    CharLinkedList test_list(test_arr, 0);

    // assertions
    assert(test_list.size() == 0);
    assert(test_list.isEmpty());
}

// Tests correct for size 5.
void size_normal_test() {
    
    char test_arr[5] = {'b', 'e', 'g', 'u', 'm' };
    CharLinkedList test_list(test_arr, 5);

    // assertions 
    assert(test_list.size() == 5);
}

// Tests correct for runtime error thrown.
void first_empty_test() {

    CharLinkedList test_list;

    // variables to keep track of error thrown
    bool runtime_error_thrown = false;
    std::string error_message = "";

    // Attempt
    try {
        test_list.first();
    }
    catch(const std::runtime_error &e){
        runtime_error_thrown = true;
        error_message = e.what();
    }

    // assertions
    assert(runtime_error_thrown);
    assert(error_message == "cannot get first of empty LinkedList");
}

// Tests correct for right element.
void first_test() {
    
    char test_arr[5] = {'b', 'e', 'g', 'u', 'm' };
    CharLinkedList test_list(test_arr, 5);

    // assertions 
    assert(test_list.first() == 'b');
}

void first_last_push_mixed_test() {

    CharLinkedList test_list;

    // Attempt 
    test_list.pushAtFront('H');
    test_list.pushAtBack('i');

    // assertions
    assert(test_list.first() == 'H');
    assert(test_list.last() == 'i');
    assert(test_list.toString() == "[CharLinkedList of size 2 <<Hi>>]");
    assert(test_list.size() == 2);
}

// Tests true for first being 'D'.
void first_normal_test() {
    
    char test_arr[6] = {'D', 'w', 'i', 'g' ,'h', 't'};
    CharLinkedList test_list(test_arr, 6);

    // assertions
    assert(test_list.first() == 'D');
}

// Tests correct for runtime error thrown.
void last_empty_test() {
    
    CharLinkedList test_list;

    // variables to keep track of error thrown
    bool runtime_error_thrown = false;
    std::string error_message = "";

    // Attempt
    try {
        test_list.last();
    }
    catch(const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    // assertions
    assert(runtime_error_thrown);
    assert(error_message == "cannot get last of empty LinkedList");
}

// Tests correct for right back node.
void last_normal_test() {

    char test_arr[6] = {'D', 'w', 'i', 'g' ,'h', 't'};
    CharLinkedList test_list(test_arr, 6);

    // assertions
    assert(test_list.last() == 't');
}

// Tests correct for right last element after pushAtBack and popFromBack.
void last_popFromBack_pushAtBack_test() {

    char test_arr[6] = {'D', 'w', 'i', 'g' ,'h', 't'};
    CharLinkedList test_list(test_arr, 6);

    // Attempt
    test_list.pushAtBack('s');

    // assertions
    assert(test_list.last() == 's');

    // Attempt
    for (int i = 0; i < 3; i++) {
        test_list.popFromBack();
    }

    // assertions
    assert(test_list.size() == 4);
    assert(test_list.last() == 'g');
}

// Attempts to change the size of the linkedlist using pushAtBack.
void size_pushAtBack_mix_test() { 

    char test_arr[5] = {'b', 'e', 'g', 'u', 'm' };
    CharLinkedList test_list(test_arr, 5);

    // Attempt
    test_list.pushAtBack(' ');
    test_list.pushAtBack('n');
    test_list.pushAtBack('i');
    test_list.pushAtBack('c');
    test_list.pushAtBack('e');

     // assertions
    assert(test_list.size() == 10);
    assert(test_list.toString() == 
                                "[CharLinkedList of size 10 <<begum nice>>]");
}

// Attempts to change the size of the linkedlist uing pushAtFront.
void size_pushAtFront_mix_test() { 
    
    char test_arr[5] = {'b', 'e', 'g', 'u', 'm' };
    CharLinkedList test_list(test_arr, 5);

    // Attempt
    // Trying different characters for pushAtFront
    test_list.pushAtFront(' ');
    test_list.pushAtFront('m');
    test_list.pushAtFront('a');
    test_list.pushAtFront(' ');
    test_list.pushAtFront('I');

    // assertions
    assert(test_list.size() == 10);
    assert(test_list.toString() == 
                                "[CharLinkedList of size 10 <<I am begum>>]");
}

// Tests correct if a runtime error is thrown.
void elementAt_empty_test() { 
    
    CharLinkedList test_list;

    // variables to track error 
    bool range_error_thrown = false;
    std::string error_message = "";

    // Attempt
    try {
    // elementAt for empty list
    test_list.elementAt(42);
    }
    catch (const std::range_error &e) {
    range_error_thrown = true;
    error_message = e.what();
    }
    
    // assertions
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0)");
}

// Tests correct if correct element is returned.
// Attempts to use the elementAt_helper_front.
void elementAt_front_test() { 
    
    char test_arr[10] = { 'b', 'e', 'n', 't', 'u', 'r', 'k','i', 'y', 'e' };
    CharLinkedList test_list(test_arr, 10);

    // assertions
    assert(test_list.elementAt(3) == 't');
}

// Tests correct if correct element is returned.
// Attempts to use the elementAt_helper_back.
void elementAt_back_test() { 
    
    char test_arr[10] = { 'b', 'e', 'n', 't', 'u', 'r', 'k','i', 'y', 'e' };
    CharLinkedList test_list(test_arr, 10);

    // assertions
    assert(test_list.elementAt(6) == 'k');
}

// Tests correct for returning the right string.
void toString_normal_test() {
    
    char test_arr[5] = {'b', 'e', 'g', 'u', 'm'};
    CharLinkedList test_list(test_arr,5);

    // assertions
    assert(test_list.toString() == "[CharLinkedList of size 5 <<begum>>]");
}

// Tests correct for returning empty string.
void toString_empty_test() {

    CharLinkedList test_list;

    // assertions
    assert(test_list.toString() == "[CharLinkedList of size 0 <<>>]");
}

// Tests correct for returning right string.
void toString_oneelement_test() {

    CharLinkedList test_list('*');

    // assertions
    assert(test_list.toString() == "[CharLinkedList of size 1 <<*>>]");
    assert(test_list.first() == test_list.last());
}

// Tests correct for right string.
void toReverseString_test() {

    char test_arr[5] = {'b', 'e', 'g', 'u', 'm'};
    CharLinkedList test_list(test_arr, 5);

    // assertions
    assert(test_list.toReverseString() == 
                                    "[CharLinkedList of size 5 <<mugeb>>]");
}

// Tests correct for returning empty string.
void toReverseString_empty_test() {

    CharLinkedList test_list;

    // assertions
    assert(test_list.toReverseString() == "[CharLinkedList of size 0 <<>>]");
}

// Tests correct for returning right string.
void toReverseString_oneelement_test() {

    CharLinkedList test_list('*');

    // assertions
    assert(test_list.toReverseString() == "[CharLinkedList of size 1 <<*>>]");
    assert(test_list.first() == test_list.last());
}

// Attempt to pushAtBack on an empty string.
// Tests correct for right size, pointers, and string.
void pushAtBack_empty_test() {

    CharLinkedList test_list;

    // Attempt
    test_list.pushAtBack('M');

    // assertions
    assert(test_list.size() == 1);
    assert(test_list.last() == test_list.first());
    assert(test_list.elementAt(0) == 'M');
}

// Attempt to pushAtBack on a one-element string.
// Tests correct for right size, pointers, and string.
void pushAtBack_oneelement_test() {

    CharLinkedList test_list('A');

    // Attempt
    test_list.pushAtBack('M');

    // assertions
    assert(test_list.size() == 2);
    assert(test_list.last() == 'M');
    assert(test_list.elementAt(1) == 'M');
    assert(test_list.toString() == "[CharLinkedList of size 2 <<AM>>]");
}

// Tests correct for right size, pointers, elementAt, string.
void pushAtBack_normal_test() {

    char test_arr[6] = { 'k', 'a', 'r', 'd', 'e', 's'};
    CharLinkedList test_list(test_arr, 6);

    // Attempt
    test_list.pushAtBack('M');

    // assertions
    assert(test_list.size() == 7);
    assert(test_list.last() == 'M');
    assert(test_list.elementAt(6) == 'M');
    assert(test_list.toString() == "[CharLinkedList of size 7 <<kardesM>>]");
}

// Attempt to pushAtBack multiple times in a row.
// Tests correct for right size, back pointer, and string.
void pushAtBack_multiple_test() {

    char test_arr[6] = { 'k', 'a', 'r', 'd', 'e', 's'};
    CharLinkedList test_list(test_arr, 6);

    // Attempt
    char add_arr[3] = {'c', 'i', 'm'};
    for (int i = 0; i < 3; i++) {
        test_list.pushAtBack(add_arr[i]);
        // assertions
        assert(test_list.last() == add_arr[i]);
    }

    // assertions
    assert(test_list.size() == 9);
    assert(test_list.last() == 'm');
    assert(test_list.elementAt(7) == 'i');
    assert(test_list.toString() == "[CharLinkedList of size 9 <<kardescim>>]");
}

// Tests correct for returning nothing.
void pushAtFront_test() {
    
    char test_arr[9] = { 'e', 'n', 't', 'u', 'r', 'k','i', 'y', 'e' };
    CharLinkedList test_list(test_arr, 9);

    // Attempt
    test_list.pushAtFront('b');

    // assertions
    assert(test_list.size() == 10);
    assert(test_list.first() == 'b');
    assert(test_list.last() == 'e');
    assert(test_list.toString() == 
                                "[CharLinkedList of size 10 <<benturkiye>>]");
}

// Attempt to pushAtFront on a one-element list.
// Tests correct right size, pointers, and string.
void pushAtFront_oneelement_test() {
    
    CharLinkedList test_list('K');

    // Attempt
    test_list.pushAtFront('M');

    // assertions
    assert(test_list.size() == 2);
    assert(test_list.first() == 'M');
    assert(test_list.last() == 'K');
    assert(test_list.toString() == 
                                "[CharLinkedList of size 2 <<MK>>]");
}

// Attempt to pushAtFront on an empty list.
// Tests correct right size and pointers.
void pushAtFront_empty_test() {
    CharLinkedList test_list;

    // Attempt
    test_list.pushAtFront('K');

    // assertions
    assert(test_list.size() == 1);
    assert(test_list.first() == 'K');
    assert(test_list.last() == 'K');
}

// Tests correct for range error thrown.
void insertAt_rangeerror_test() {
    
    char test_arr[6] = { 'k', 'a', 'r', 'd', 'e', 's'};
    CharLinkedList test_list(test_arr, 6);

    // variables to track error 
    bool range_error_thrown = false;
    std::string error_message = "";

    // Attempt
    try {
    // insertAt with out of range index
    test_list.insertAt('p', 35);
    }
    catch (const std::range_error &e) {
    range_error_thrown = true;
    error_message = e.what();
    }
    
    // assertions
    assert(range_error_thrown);
    assert(error_message == "index (35) not in range [0..6]");
}

// Tests correct for range error thrown.
// Attempt to insertAt with a negative index.
void insertAt_negativeindex_test() {

    char test_arr[6] = { 'k', 'a', 'r', 'd', 'e', 's'};
    CharLinkedList test_list(test_arr, 6);

    // variables to track error 
    bool range_error_thrown = false;
    std::string error_message = "";

    // Attempt
    try {
    // insertAt with out of range index
    test_list.insertAt('a', -5);
    }
    catch (const std::range_error &e) {
    range_error_thrown = true;
    error_message = e.what();
    }
    
    // assertions
    assert(range_error_thrown);
    assert(error_message == "index (-5) not in range [0..6]");
}

// Tests correct for inserting new character to an empty list.
void insertAt_empty_test() {

    CharLinkedList test_list;

    // Attempt
    test_list.insertAt('Q', 0);

    // assertions
    assert(test_list.size() == 1);
    assert(test_list.first() == test_list.last());
    assert(test_list.elementAt(0) == 'Q');
}

// Tests correct for inserting new character at the back of the list.
void insertAt_end_test() {    

    char test_arr[6] = { 'k', 'a', 'r', 'd', 'e', 's'};
    CharLinkedList test_list(test_arr, 6);

    // Attempt
    test_list.insertAt('i', 6);

    // assertions
    assert(test_list.size() == 7);
    assert(test_list.last() == 'i');
    assert(test_list.elementAt(5) == 's');
    assert(test_list.elementAt(6) == 'i');
    assert(test_list.toString() == "[CharLinkedList of size 7 <<kardesi>>]");
    
    // Attempt 2
    test_list.insertAt('m', 7);

    // assertions
    assert(test_list.size() == 8);
    assert(test_list.last() == 'm');
    assert(test_list.elementAt(6) == 'i');
    assert(test_list.elementAt(7) == 'm');
    assert(test_list.toString() == "[CharLinkedList of size 8 <<kardesim>>]");
}

// Tests correct for the right char inserted.
void insertAt_normal_frontandback_test() {    

    char test_arr[6] = { 'a', 'c', 'd', 'e', 'g', 'h'};
    CharLinkedList test_list(test_arr, 6);

    // Attempt
    test_list.insertAt('b', 1);

    // assertions
    assert(test_list.size() == 7);
    assert(test_list.last() == 'h');
    assert(test_list.first() == 'a');
    assert(test_list.elementAt(1) == 'b');
    assert(test_list.elementAt(2) == 'c');
    assert(test_list.toString() == "[CharLinkedList of size 7 <<abcdegh>>]");
    
    // Attempt 2
    test_list.insertAt('f', 5);

    // assertions
    assert(test_list.size() == 8);
    assert(test_list.last() == 'h');
    assert(test_list.first() == 'a');
    assert(test_list.elementAt(4) == 'e');
    assert(test_list.elementAt(5) == 'f');
    assert(test_list.elementAt(6) == 'g');
    assert(test_list.toString() == "[CharLinkedList of size 8 <<abcdefgh>>]");
}

// Tests correct for insertins a new character to empty list.
void insertInOrder_empty_test() {

    CharLinkedList test_list;
    
    // Attempt
    test_list.insertInOrder('A');

    // assertions
    assert(test_list.size() == 1);
    assert(test_list.first() == test_list.last());
    assert(test_list.elementAt(0) == 'A');
}

// Tests correct for inserting element at the back
void insertInOrder_last_test() {

    char test_arr[5] = {'B', 'E', 'G', 'U', 'M'};
    CharLinkedList test_list(test_arr, 5);

    // Attempt
    test_list.insertInOrder('Z');

    // assertions
    assert(test_list.size() == 6);
    assert(test_list.last() == 'Z');
    assert(test_list.toString() == "[CharLinkedList of size 6 <<BEGUMZ>>]");
}

// Tests correct for inserting element at the back (lowercase-uppercase mixed)
void insertInOrder_mixed_test() {

    char test_arr[6] = {'c', 'D', 'T', 'z', 'u', 'P'};
    CharLinkedList test_list(test_arr, 6);

    // Attempt
    test_list.insertInOrder('e');

    // assertions
    assert(test_list.size() == 7);
    assert(test_list.elementAt(3) == 'e');
    assert(test_list.toString() == "[CharLinkedList of size 7 <<cDTezuP>>]");
}

// Tests correct for right size, and first.
void insertInOrder_front_test() {

    CharLinkedList test_list('b');

    // Attempt
    test_list.insertInOrder('a');

    // assertions
    assert(test_list.size() == 2);
    assert(test_list.first() == 'a');
}

// Tests correct for runtime error thrown.
void popFromFront() {
    CharLinkedList test_list;

    // variables to keep track of error thrown
    bool runtime_error_thrown = false;
    std::string error_message = "";

    // Attempt
    try {
        test_list.popFromFront();
    }
    catch(const std::runtime_error &e){
        runtime_error_thrown = true;
        error_message = e.what();
    }

    // assertions
    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

// Tests correct for updated size and first.
void popFromFront_test() {
    
    char test_arr[5] = {'b', 'e', 'g', 'u', 'm' };
    CharLinkedList test_list(test_arr, 5);

    // Attempt
    test_list.popFromFront();

    // assertions
    assert(test_list.size() == 4);
    assert(test_list.first() == 'e');
    assert(test_list.toString() == "[CharLinkedList of size 4 <<egum>>]");
}

// Tests correct for isEmpty.
void popFromFront_empty_first_mix_test() {

    char test_arr[5] = {'b', 'e', 'g', 'u', 'm' };
    CharLinkedList test_list(test_arr, 5);

    // Attempt
    for (int i = 0; i < 5; i++) {
        test_list.popFromFront();
    }

    // assertions
    assert(test_list.size() == 0);
    assert(test_list.isEmpty());

    // variables to keep track of error thrown
    bool runtime_error_thrown = false;
    std::string error_message = "";

    try {
        test_list.first();
    }
    catch(const std::runtime_error &e){
        runtime_error_thrown = true;
        error_message = e.what();
    }

    // assertions
    assert(runtime_error_thrown);
    assert(error_message == "cannot get first of empty LinkedList");
}

// Tests correct for runtime error thrown.
// Attempt to pop from empty list.
void popFromBack_empty_test() {
    
    CharLinkedList test_list;

    // variables to keep track of error thrown
    bool runtime_error_thrown = false;
    std::string error_message = "";

    // Attempt
    try {
        test_list.popFromBack();
    }
    catch(const std::runtime_error &e){
        runtime_error_thrown = true;
        error_message = e.what();
    }

    // assertions
    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

// Tests correct for isEmpty.
// Attempts to popFromBack one element.
void popFromBack_oneelement_test() {
    
    CharLinkedList test_list('T');

    // Attempt
    test_list.popFromBack();

    // assertions
    assert(test_list.size() == 0);
    assert(test_list.isEmpty());
}

// Tests correct for size 7.
// Attempts to popFromBack three times.
void popFromBack_three_test() {
    
    char test_arr[10] = { 'b', 'e', 'n', 't', 'u', 'r', 'k', 'i', 'y', 'e' };
    CharLinkedList test_list(test_arr, 10);

    // Attempt
    for (int i = 0; i < 3; i++) {
        test_list.popFromBack();
    }
    
    // assertions
    assert(test_list.size() == 7);
    assert(test_list.last() == 'k');
    assert(test_list.toString() == "[CharLinkedList of size 7 <<benturk>>]");

}

// Tests correct for range error thrown.
void removeAt_empty_test() {

    CharLinkedList test_list;

    // variables to keep track of error thrown
    bool range_error_thrown = false;
    std::string error_message = "";

    // Attempt
    try {
        test_list.removeAt(9);
    }
    catch(const std::range_error &e){
        range_error_thrown = true;
        error_message = e.what();
    }

    // assertions
    assert(range_error_thrown);
    assert(error_message == "index (9) not in range [0..0)");
}

// Tests correct for reduced ize and edited list.
// Attempts to remove element from around the middle.
void removeAt_normal_test() {

    char test_arr[5] = {'b', 'e', 'g', 'u', 'm'};
    CharLinkedList test_list(test_arr, 5);

    // Attempt
    test_list.removeAt(3);

    // assertions
    assert(test_list.size() == 4);
    assert(test_list.elementAt(3) == 'm');
    assert(test_list.last() == 'm');
    assert(test_list.toString() == "[CharLinkedList of size 4 <<begm>>]");
}

// Tests correct for reduced size and edited string.
void removeAt_three_test() {
    
    char test_arr[10] = { 'b', 'e', 'n', 't', 'u', 'r', 'k', 'i', 'y', 'e' };
    CharLinkedList test_list(test_arr, 10);

    // Attempt
    for (int i = 0; i < 3; i++){
        test_list.removeAt(test_list.size()-1);
    }

    // assertions
    assert(test_list.size() == 7);
    assert(test_list.last() == 'k');
    assert(test_list.toString() == "[CharLinkedList of size 7 <<benturk>>]");
}

// Tests correct for cleaning the list.
void removeAt_full_test() {
    
    char test_arr[10] = { 'b', 'e', 'n', 't', 'u', 'r', 'k', 'i', 'y', 'e' };
    CharLinkedList test_list(test_arr, 10);

    // Attempt
    test_list.removeAt(5);

    // assertions
    assert(test_list.size() == 9);
    assert(test_list.elementAt(5) == 'k');
    assert(test_list.elementAt(4) == 'u');
    assert(test_list.toString() == "[CharLinkedList of size 9 <<bentukiye>>]");

    // Attempt
    for (int i = 0; i < 7; i++) {
        test_list.removeAt(test_list.size()-1);
        assert(test_list.last() == test_list.elementAt(test_list.size()-1));
    }

    // assertions
    assert(test_list.size() == 2);
    assert(test_list.toString() == "[CharLinkedList of size 2 <<be>>]");

    // Attempt 2
    test_list.removeAt(0);

    // assertions
    assert(test_list.size() == 1);
    assert(test_list.first() == 'e');
    assert(test_list.last() == 'e');
    assert(test_list.elementAt(0) == 'e');
    assert(test_list.toString() == "[CharLinkedList of size 1 <<e>>]");

    // Attempt 3
    test_list.removeAt(0);

    // assertions
    assert(test_list.isEmpty());
}

// Tests correct if the right element is replaced.
void replaceAt_test() {

    char test_arr[3] = {'b', 'e', 'n'};
    CharLinkedList test_list(test_arr, 3);

    // Attempt
    test_list.replaceAt('a', 1);

    // assertions
    assert(test_list.size() == 3);
    assert(test_list.elementAt(1) == 'a');
    assert(test_list.toString() == "[CharLinkedList of size 3 <<ban>>]");

}

// Attempts to replaceAt empty list.
// Tests correct for a rangeerror thrown.
void replaceAt_empty_test() {

    CharLinkedList test_list;

    // variables to keep track of error thrown
    bool range_error_thrown = false;
    std::string error_message = "";

    // Attempt
    try {
        test_list.replaceAt('i', 9);
    }
    catch(const std::range_error &e){
        range_error_thrown = true;
        error_message = e.what();
    }

    // assertions
    assert(range_error_thrown);
    assert(error_message == "index (9) not in range [0..0)");
}

// Attempts to replaceAt nonpositive index.
// Tests correct for a rangeerror thrown.
void replaceAt_nonpositive_test() {

    CharLinkedList test_list('c');

    // variables to keep track of error thrown
    bool range_error_thrown = false;
    std::string error_message = "";

    // Attempt
    try {
        test_list.replaceAt('i', -1);
    }
    catch(const std::range_error &e){
        range_error_thrown = true;
        error_message = e.what();
    }

    // assertions
    assert(range_error_thrown);
    assert(error_message == "index (-1) not in range [0..1)");
}

// Attempts to replaceAt out of range index.
// Tests correct for a rangeerror thrown.
void replaceAt_rangeerror_test() {

    char test_arr[7] = {'a', 'b', 'c', 'd', 'e', 'f', 'g'};
    CharLinkedList test_list(test_arr, 7);

    // variables to keep track of error thrown
    bool range_error_thrown = false;
    std::string error_message = "";

    // Attempt
    try {
        test_list.replaceAt('i', 12);
    }
    catch(const std::range_error &e){
        range_error_thrown = true;
        error_message = e.what();
    }

    // assertions
    assert(range_error_thrown);
    assert(error_message == "index (12) not in range [0..7)");
}

// Attempts to concatenate two nonempty lists.
// Tests correct for right string, size, and back.
void concatenate_test() {

    char test_arr[3] = {'b', 'e', 'n'};
    CharLinkedList test_list(test_arr, 3);

    char test_arr_two[4] = {'t', 'u', 'r', 'k'};
    CharLinkedList test_list_two(test_arr_two, 4);

    // Attempt
    test_list.concatenate(&test_list_two);

    // assertions
    assert(test_list.size() == 7);
    assert(test_list.last() == 'k');
    assert(test_list.toString() == "[CharLinkedList of size 7 <<benturk>>]");
}

// Attempts to concatenate an empty list with a non-empty list.
// Tests correct for right string, size, and back.
void concatenate_empty_nonempty_test() {

    CharLinkedList test_list;
    char test_arr[5] = {'b', 'e', 'g', 'u', 'm'};
    CharLinkedList test_list_two(test_arr, 5);

    // Attempt
    test_list.concatenate(&test_list_two);

    // assertions
    assert(test_list.size() == 5);
    assert(test_list.elementAt(3) == 'u');
    assert(test_list.first() == 'b');
    assert(test_list.last() == 'm');
    assert(test_list.toString() == "[CharLinkedList of size 5 <<begum>>]");
}

// Attempts to concatenate a non-empty list with an empty list.
// Tests correct for right string, size, and back.
void concatenate_nonempty_empty_test() {

    char test_arr[5] = {'b', 'e', 'g', 'u', 'm'};
    CharLinkedList test_list(test_arr, 5);
    CharLinkedList test_list_two;

    // Attempt
    test_list.concatenate(&test_list_two);

    // assertions
    assert(test_list.size() == 5);
    assert(test_list.elementAt(3) == 'u');
    assert(test_list.first() == 'b');
    assert(test_list.last() == 'm');
    assert(test_list.toString() == "[CharLinkedList of size 5 <<begum>>]");
}

// Attempts to concatenate a list with itself.
// Tests correct for right string, size, and back.
void concatenate_itself_test() {

    char test_arr[6] = {'b', 'l', 'o', 'u', 's', 'e'};
    CharLinkedList test_list(test_arr, 6);

    // Attempt
    test_list.concatenate(&test_list);

    // assertions
    assert(test_list.size() == 12);
    assert(test_list.elementAt(3) == test_list.elementAt(9));
    assert(test_list.first() == 'b');
    assert(test_list.last() == 'e');
    assert(test_list.toString() == 
                            "[CharLinkedList of size 12 <<blouseblouse>>]");
}

// Attempts to concatenate an empty list with empty list.
// Tests correct for isEmpty.
void concatenate_empty_empty_test() {

    CharLinkedList test_list;
    CharLinkedList test_list_two;

    // Attempt
    test_list.concatenate(&test_list_two);

    // assertions
    assert(test_list.isEmpty());
}

// Tests correct for having the same size, first, last, and string.
void assignment_operator_test() {

    char test_arr[5] = {'b', 'e', 'g', 'u', 'm'};
    CharLinkedList test_list(test_arr, 5);

    // Attempt
    CharLinkedList *new_list = &test_list;

    // assertions
    assert(new_list->size() == test_list.size());
    assert(new_list->first() == test_list.first());
    assert(new_list->last() == test_list.last());
    assert(new_list->toString() == test_list.toString());
}

// Tests correct for having the same size, first, last, and string.
void copy_constructor_test() {

    char test_arr[5] = {'a', 'n', 'n', 'e', 'm'};
    CharLinkedList test_list(test_arr, 5);

    // Attempt
    CharLinkedList new_list(test_list);

    // assertions
    assert(new_list.size() == test_list.size());
    assert(new_list.first() == test_list.first());
    assert(new_list.last() == test_list.last());
    assert(new_list.toString() == test_list.toString());
}

// // Below are tests using a mix and variety of functions in longer spans.

// // Attempts to create an empty list. Tests correct for isEmpty.
// // Attempts to fill the list using pushAtBack. 
// // Tests correct for multiple assertions (size, first, last, elementAt, 
// // string)
// // Attempts to popFromBack to empty the list. Tests correct for isEmpty.
// void playfulMixVersion_one_test() {
    
//     CharLinkedList test_list;

//     // assertions
//     assert(test_list.isEmpty());

//     // Attempt to fill the list
//     char test_arr[10] = { 'b', 'e', 'n', 't', 'u', 'r', 'k','i', 'y', 'e' };
//     for (int i = 0; i < 10; i++) {
//         test_list.pushAtBack(test_arr[i]);
//     }

//     // assertions
//     assert(not test_list.isEmpty());
//     assert(test_list.size() == 10);
//     assert(test_list.first() == 'b');
//     assert(test_list.last() == 'e');
//     assert(test_list.elementAt(8) == 'y');
//     assert(test_list.elementAt(2) == 'n');

//     // Attempt to empty the list
//     for (int i = 0; i < 10; i++) {
//         test_list.popFromBack();
//     }

//     // assertions
//     assert(test_list.isEmpty());
// }

// // Attempts to pushAtBack multiple times and pushAtFront multiple times.
// // Tests correct for right front&back pointers, size, and string.
// void playfulMixVersion_two_test() {

//     char test_arr[7] = {'H', 'a', 'l', 'p', 'e', 'r', 't'};
//     CharLinkedList test_list(test_arr, 7);

//     // assertions
//     assert(test_list.first() == 'H');
//     assert(test_list.last() == 't');

//     // Attempt to pushAtBack multiple times
//     char add_arr[9] = {' ', 'B', 'e', 'a', 'r', ' ', 'M', 'a', 'n'};
//     for (int i = 0; i < 9; i++) {
//         test_list.pushAtBack(add_arr[i]);
//         // assertions
//         assert(test_list.last() == add_arr[i]);
//     }
//     // assertions 
//     assert(test_list.size() == 16);
//     assert(test_list.toString() == 
//                      "[CharLinkedList of size 16 <<Halpert Bear Man>>]");

//     // Attempt to pushAtFront multiple times
//     char add_arr_two[4] = {' ', 'm', 'i', 'J'};
//     for (int i = 0; i < 4; i++) {
//         test_list.pushAtFront(add_arr_two[i]);
//         // assertions
//         assert(test_list.first() == add_arr_two[i]);
//     }
//     // assertions 
//     assert(test_list.size() == 20);
//     assert(test_list.toString() == 
//                     "[CharLinkedList of size 20 <<Jim Halpert Bear Man>>]");
// }

// // Below are commented out code to test the private helper functions.

// // Tests correct for assigning the right char and node pointers.
// void create_node_test() {

//     CharLinkedList test_list;
//     // Attempt
//     CharLinkedList::Node *new_node = 
//                             test_list.create_node(nullptr, 'y', nullptr);

//     // assertions
//     assert(new_node->element == 'y');
//     assert(new_node->previous == nullptr);
//     assert(new_node->next == nullptr);
// }

// // Tests correct for returning right element
// void elementAt_helper_front_test() {

//     char test_arr[7] = {'H', 'a', 'l', 'p', 'e', 'r', 't'};
//     CharLinkedList test_list(test_arr, 7);

//     // Attempt
//     char element_wanted = 
//                 test_list.elementAt_helper_front(test_list.front, 2, 0);

//     // assertions
//     assert(element_wanted == 'l');
// }

// // Tests correct for returning right element
// void elementAt_helper_back_test() {

//     char test_arr[7] = {'H', 'a', 'l', 'p', 'e', 'r', 't'};
//     CharLinkedList test_list(test_arr, 7);

//     // Attempt
//     char element_wanted = 
//     test_list.elementAt_helper_back(test_list.back, 4, 
//                                                  (test_list.currSize-1));

//     // assertions
//     assert(element_wanted == 'e');
// }

// // Tests correct for inserting right element in right place
// void insertAt_helper_front_test() {

//     char test_arr[7] = {'H', 'a', 'l', 'p', 'e', 'r', 't'};
//     CharLinkedList test_list(test_arr, 7);

//     // Attempt
//     CharLinkedList::Node *new_node = 
//                            test_list.create_node(nullptr, 'j', nullptr);
//     test_list.insertAt_helper_front(test_list.front, new_node, 3, 0);

//     // assertions
//     assert(test_list.elementAt(3) == 'j');
//     assert(test_list.size() == 8);
// }

// // Tests correct for inserting right element in right place
// void insertAt_helper_back_test() {

//     char test_arr[7] = {'H', 'a', 'l', 'p', 'e', 'r', 't'};
//     CharLinkedList test_list(test_arr, 7);

//     // Attempt
//     CharLinkedList::Node *new_node = 
//                             test_list.create_node(nullptr, 'b', nullptr);
//     test_list.insertAt_helper_back(test_list.back, new_node, 5, 
//                                                    (test_list.size()-1));

//     // assertions
//     assert(test_list.elementAt(5) == 'b');
//     assert(test_list.size() == 8);
// }

// // Tests correct for replacing right element in right place
// void replaceAt_helper_front_test() {

//     char test_arr[7] = {'H', 'a', 'l', 'p', 'e', 'r', 't'};
//     CharLinkedList test_list(test_arr, 7);

//     // Attempt
//     test_list.replaceAt_helper_front(test_list.front, 'j', 0, 0);

//     // assertions
//     assert(test_list.elementAt(0) =='j');
//     assert(test_list.first() == 'j');
//     assert(test_list.size() == 7);
// }

// // Tests correct for replacing right element in right place
// void replaceAt_helper_back_test() {

//     char test_arr[7] = {'H', 'a', 'l', 'p', 'e', 'r', 't'};
//     CharLinkedList test_list(test_arr, 7);

//     // Attempt
//     test_list.replaceAt_helper_back(test_list.back, 'z', 6, 
//                                                     (test_list.size()-1));

//     // assertions
//     assert(test_list.elementAt(6) == 'z');
//     assert(test_list.last() == 'z');
//     assert(test_list.size() == 7);
// }




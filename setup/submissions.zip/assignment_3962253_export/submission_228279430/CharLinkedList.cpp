/*
 *  CharLinkedList.cpp
 *  YOUR NAME HERE
 *  DATE CREATED
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  This file includes implementations of the class CharLinkedList.h.
 *
 */

#include "CharLinkedList.h"

using namespace std;

/*
 * name:      create node
 * purpose:   create a new node
 * parameters: a node pointer to previous node, a node pointer to next node, 
 *             and a character for element
 * returns:   a pointer to the newly created node
 * effects:   Creates a new node, sets the content of the node
 */
CharLinkedList::Node* CharLinkedList::create_node(Node* previous, char element, 
                                                                Node *next) {
    Node *new_node = new Node;
    new_node->previous = previous;
    new_node->element = element;
    new_node->next = next;
    return new_node;
}

/*
 * name:      CharLinkedList
 * purpose:   construct / initialize an object of CharLinkedList class
 * parameters: none
 * returns:   none
 * effects:   Constructs an instance of CharLinkedList class with no element. 
 */
CharLinkedList::CharLinkedList() {
    currSize = 0;
    front = nullptr;
    back = nullptr;
}

/*
 * name:      CharLinkedList
 * purpose:   construct / initialize an object of CharLinkedList class
 * parameters: a character representing the only element 
 * returns:   none
 * effects:   Constructs an instance of CharLinkedList class with one element. 
 */
CharLinkedList::CharLinkedList(char c) {
    Node *new_node = create_node(nullptr, c, nullptr);

    currSize = 1;
    front = new_node;
    back = new_node;
}

/*
 * name:      CharLinkedList
 * purpose:   construct / initialize an object of CharLinkedList class
 * parameters: an array of characters to become the elements of the list, and 
 *            integer size
 * returns:   none
 * effects:   Constructs an instance of CharLinkedList class with one element. 
 */
CharLinkedList::CharLinkedList(char arr[], int size) {
    currSize = 0;
    if (size != 0) {
        for (int i = 0; i < size; i++) {
            pushAtBack(arr[i]);
        }
    } else { // Create an empty list
        front = nullptr;
        back = nullptr;
    }
}

/*
 * name:      CharLinkedList
 * purpose:   Copy constructor -  makes a deep copy of a given instance
 * parameters: the adress of another instance of CharLinkedList class
 * returns:   none
 * effects:   makes a deep copy of the parameter instance
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other) {
    currSize = 0;
    if (other.size()) {
        Node *curr_node = other.front;
        for (int i = 0; i < other.size(); i++) {
            pushAtBack(curr_node->element); 
            curr_node = curr_node->next;   
        }
    } else {
        front = nullptr;
        back = nullptr;
    }
}

/*
 * name:      CharLinkedList
 * purpose:   destruct the instance of the CharLinkedList class
 * parameters: none
 * returns:   none
 * effects:   Calls the private recursive function destructor_helper to go
 *            through the linked list and delete elements;
 */
CharLinkedList::~CharLinkedList() {
    destructor_helper(front);
}

/*
 * name:      operator'=' (assignment operator)
 * purpose:   recycles the storage associated with the instance on the left of 
 *            the assignment and makes a deep copy of the instance on the right
 *            hand side into the instance on the left hand side
 * parameters: none
 * returns:   none
 * effects:   Calls the private recursive function destructor_helper to go
 *            through the linked list and delete elements;
 */
CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other) {
    if (this == &other) {
        return *this;
    }
    currSize = other.size();
    Node *curr_node = other.front;
    for (int i = 0; i < currSize; i++) {
        pushAtBack(curr_node->element);    
        curr_node = curr_node->next;
    }
    return *this;
}

/*
 * name:      destructor_helper
 * purpose:   a private recusrive helper function to go through the linked list
 *            and delete nodes;
 * parameters: a node pointer (preferably the front node)
 * returns:   none
 * effects:   Two base cases (empty list or 1-element-list) and recursive case 
 */
void CharLinkedList::destructor_helper(Node *node) {
    // Base case: if the list is empty
    if (node == nullptr) {
        return;
    }
    // Base case: if the list has one element
    if (node->next == nullptr) {
        delete node;
    } else { // Recursive case
        Node *next_node = node->next;
        delete node;
        destructor_helper(next_node);
    }
}

/*
 * name:      isEmpty
 * purpose:   decide whether a linked list is empty or not
 * parameters: none
 * returns:   a boolean value true if empty, false if not
 * effects:   Check on the size of the linked list
 */
bool CharLinkedList::isEmpty() const {
    if (currSize == 0){
        return true;
    }
    return false;
}

/*
 * name:      clear
 * purpose:   empty a linked list
 * parameters: none
 * returns:   none
 * effects:   Removes each element in the linked list using popFromBack.
 */
void CharLinkedList::clear() {
    while(front != nullptr) {
        popFromBack();
    }
}

/*
 * name:      size
 * purpose:   give the size of a list
 * parameters: none
 * returns:   an integer representing the size of the list 
 * effects:   Returns the size of the linked list.
 */
int CharLinkedList::size() const {
    return currSize;
}

/*
 * name:      first
 * purpose:   give the first element of a list
 * parameters: none
 * returns:   a char representing the element at the 0th index of the list
 * effects:   Throws a runtime error if the list is empty.
 */
char CharLinkedList::first() const {
    if (isEmpty()){
        throw std::runtime_error("cannot get first of empty LinkedList");
    } 
    return front->element; 
}

/*
 * name:      last
 * purpose:   give the last element from a list
 * parameters: none
 * returns:   a char representing the element at the last index of the list
 * effects:   Throws a runtime error if the list is empty.
 */
char CharLinkedList::last() const {
    if (isEmpty()) {
        throw std::runtime_error("cannot get last of empty LinkedList");
    }
    return back->element;
}

/*
 * name:      elementAt
 * purpose:   give the element at the index indicated as the parameter
 * paramteres: an integer representing the index the requested element is at
 * returns:   a char representing the element at the requested index 
 * effects:   Throws a range error if the index is out of range. Calls 
 *            private recursive helper functions (through front or back).
 */
char CharLinkedList::elementAt(int index) const {
    // Check if index is in order 
    if (isEmpty() or index < 0 or index >= currSize) {
        throw std::range_error("index (" + to_string(index) +
                        ") not in range [0.." +  to_string(currSize) + ")");
    }
    // Call helper function
    if (index > (currSize / 2)) {
        return elementAt_helper_back(back, index, (currSize-1));
    } else {
        return elementAt_helper_front(front, index, 0);
    }
    
}

/*
 * name:      elementAt_helper_front
 * purpose:   give the element at the index indicated as the parameter
 * parameters: a Node pointer, an integer representing the index the requested 
 *             element is at, and an integer count
 * returns:   a char representing the element at the requested index 
 * effects:   Returns itself with an updated next_node parameter to go through
 *            the linked list. (Note: the initial parameter node pointer for
 *            this helper fucntion must be the front node)
 */
char CharLinkedList::elementAt_helper_front(Node *node, int index, int count) 
                                                                        const {
    // Base case: If the list has one element
    // Count variable keeps track of the index the loop is at.
    if (count == index) {
        return node->element;
    } else {
        Node *next_node = node->next;
        count++;
        return elementAt_helper_front(next_node, index, count);
    }
}

/*
 * name:      elementAt_helper_back
 * purpose:   give the element at the index indicated as the parameter
 * parameters: a Node pointer, an integer representing the index the requested 
 *             element is at, and an integer count
 * returns:   a char representing the element at the requested index 
 * effects:   Returns itself with an updated next_node parameter to go through
 *            the linked list. (Note: the initial parameter node pointer for
 *            this helper fucntion must be the back node)
 */
char CharLinkedList::elementAt_helper_back(Node *node, int index, int count) 
                                                                        const {
    // Base case: If the list has one element
    if (count == index) {
        return node->element;
    } else {
        Node *next_node = node->previous;
        count --; // must decrease because going backwards
        return elementAt_helper_back(next_node, index, count);
    }                                                                        
}

/*
 * name:      toString
 * purpose:   turn the elements of a list into a string all together
 * parameters: none
 * returns:   a string representing all the elements of the list together
 * effects:   Puts together all the elements in the list in order, 
 *            creates a string including the size of the list as well.
 */
std::string CharLinkedList::toString() const {
    string s = "";
    Node *curr_node = front;
    for (int i = 0; i < currSize ; i++) {
        s = s + curr_node->element;
        curr_node = curr_node->next;
    }
    return "[CharLinkedList of size " + to_string(currSize) + " <<" + 
                                                                    s + ">>]";
}

/*
 * name:      toReverseString
 * purpose:   turn the elements of an list into a string all together, 
 *            but in reverse order
 * parameters: none
 * returns:   a string representing all the elements of the list together, 
 *            but on reverse order
 * effects:   Puts together all the elements in the list in reverse order, 
 *            creates a string including the size of the list as well.
 */
std::string CharLinkedList::toReverseString() const {
    string s = "";
    Node *curr_node = back;
    for (int i = 0; i < currSize ; i++) {
        s = s + curr_node->element;
        curr_node = curr_node->previous;
    }
    return "[CharLinkedList of size " + to_string(currSize) + " <<" + 
                                                                    s + ">>]";
}  


/*
 * name:      pushAtBack
 * purpose:   add a new node at the end of the linked list
 * parameters: a character representing the element of the node
 * returns:   none
 * effects:   Sets the pointers, increases the currSize 
 */
void CharLinkedList::pushAtBack(char c) {
    if (isEmpty()) {
        // creating the first node
        Node *new_node = create_node(nullptr, c, nullptr);
        front = new_node;
        back = new_node;
    } else {
        // adding next nodes
        Node *node_to_add = create_node(back, c, nullptr);
        back->next = node_to_add;
        back = node_to_add;
    }
    currSize++;
}

/*
 * name:      pushAtFront
 * purpose:   add a new element at the beginning of the list
 * parameters: a character representing the elements to be added
 * returns:   none
 * effects:   Creates a new node to add; if the list is empty, sets the front 
 *            node, else, sets its next and previous pointers accordingly.
 */
void CharLinkedList::pushAtFront(char c) {
    if (isEmpty()) {
        // creating the first node
        Node *new_node = create_node(nullptr, c, nullptr);
        front = new_node;
        back = new_node;
    } else {
        // adding additional node at front
        Node *node_to_add = create_node(nullptr, c, front);
        front->previous = node_to_add;
        front = node_to_add;
    }
    currSize++;
}

/*
 * name:      insertAt
 * purpose:   insert a new requested element at the requested index
 * parameters: a character representing the element to be inserted, an integer 
 *            representing the index in which the element is to be inserted
 * returns:   none
 * effects:   Throws a range error if the index is out of range, creates a new 
 *            node, calls pushAtFront if the list is empty or index is 0, 
 *            pushAtBack if index is the last, calls two private recursive 
 *            helper functions depending on whether the idnex is closer to the 
 *            front node or the back.
 */
void CharLinkedList::insertAt(char c, int index) {
    if (index < 0 or index > currSize) {
        throw range_error("index (" + to_string(index) +
                            ") not in range [0.." + to_string(currSize) + "]");
    } 
    // Two cases: adding at the front or at the back
    if (isEmpty() or index == 0) {
        pushAtFront(c);
    } else if (index == currSize) { 
        pushAtBack(c);
    } else {
        Node *new_node = create_node(nullptr, c, nullptr);
        if (index > (index/2)) {
            insertAt_helper_back(back, new_node, index, currSize-1);
        } else {
            insertAt_helper_front(front, new_node, index, 0);
        }
    }
}

/*
 * name:      insertAt_helper_front
 * purpose:   insert a new requested element at the requested index
 * parameters: a Node pointer representing current node, a node pointer 
 *             representing node to be added, an integer index and integer
 *             count.
 * effects:   Calls itself with the next linked node as the parameter until
 *            count reaches the desired index. (Note: must be initially called 
 *            using the front node as current node)
 */
void CharLinkedList::insertAt_helper_front(Node *curr_node, 
                                        Node *new_node, int index, int count) {
    // Base case: count equals index
    if (count == index) {
        curr_node->previous->next = new_node;
        curr_node->previous = new_node;
        new_node->previous = curr_node->previous;
        new_node->next = curr_node;
        currSize++;
        return;
    } else { // recursive case
        curr_node = curr_node->next;
        count++; // increase count to keep track of the index
        insertAt_helper_front(curr_node, new_node, index, count);
    }
}

/*
 * name:      insertAt_helper_back
 * purpose:   insert a new requested element at the requested index
 * parameters: a Node pointer representing current node, a node pointer 
 *             representing node to be added, an integer index and integer
 *             count.
 * effects:   Calls itself with the next linked node as the parameter until
 *            count reaches the desired index. (Note: must be initially called 
 *            using the back node as current node)
 */
void CharLinkedList::insertAt_helper_back(Node *curr_node, 
                                        Node *new_node, int index, int count) {
    if (count == index) {
        curr_node->previous->next = new_node;
        curr_node->previous = new_node;
        new_node->previous = curr_node->previous;
        new_node->next = curr_node;
        currSize++;
        return;
    } else {
        curr_node = curr_node->previous;
        count--; // decrease count as the loop is going backwards
        insertAt_helper_back(curr_node, new_node, index, count);
    }
}

/*
 * name:      insertInOrder
 * purpose:   insert a new requested element in the list in accordance with 
 *            ASCII order
 * parameters: a character representing the element to be inserted
 * returns:   none
 * effects:   If the list is empty, creates and adds a new node. 
 *            Else, goes through the linked list to find the right place.
 */
void CharLinkedList::insertInOrder(char c) {
    Node *curr_node = front;
    // if the list is empty, create and add new node
    if (isEmpty()) { 
        Node *new_node = create_node(nullptr, c, nullptr);
        front = new_node;
        back = new_node;
        currSize++;
        return;
    }
    for (int i = 0; i < currSize; i++) {
        // ascii order place is found
        if (c < curr_node->element) { 
            if (i == 0) { 
                pushAtFront(c);
                return;
            } else {
                insertAt(c, i);
                return;
            }
        } else if (i == currSize - 1) { 
            // if need to insert at the end
            pushAtBack(c);
            return;
        } else {
            // move to the next one
            curr_node = curr_node->next; 
        }
    }
}

/*
 * name:      popFromFront
 * purpose:   remove an element from the front of the list list
 * parameters: none
 * returns:   none
 * effects:   Throws a runtime error if the list is empty, decreases size by 
 *            one, changes front pointer.
 */
void CharLinkedList::popFromFront() {
    if (isEmpty()) {
        throw runtime_error("cannot pop from empty LinkedList");
    }
    if (currSize == 1) {
        delete front;
        front = nullptr;
        back = nullptr;
        currSize--;
    } else {
        front = front->next;
        delete front->previous;
        front->previous = nullptr;
        currSize--;
    }
}

/*
 * name:      popFromBack
 * purpose:   remove an element from the end of the list list
 * parameters: none
 * returns:   none
 * effects:   Throws a runtime error if the list is empty, decreases size by 
 *            one, changes back pointer.
 */
void CharLinkedList::popFromBack() {
    if (isEmpty()) {
        throw runtime_error("cannot pop from empty LinkedList");
    }
    if (currSize == 1) {
        delete front;
        front = nullptr;
        back = nullptr;
        currSize--;
    } else {
        back = back->previous;
        delete back->next;
        back->next = nullptr;
        currSize--;
    }
    
}

/*
 * name:      removeAt
 * purpose:   remove an element from the requested index
 * parameters: an integer representing the index of the element to be removed
 * returns:   none
 * effects:   Throws a range error if the index is out or list's range, has to
 *            pop from front if rremoving at index 0, or pop from back if
 *            removing the last element
 */
void CharLinkedList::removeAt(int index) {
    if (index < 0 or index >= currSize) {
        throw range_error("index (" + to_string(index) +
                            ") not in range [0.." + to_string(currSize) + ")");
    }
    Node *curr_node = front;
    int count = 0;
    for (int i = 0; i < currSize; i++) {
        if (count == index) {
            if (index == 0) { // have to change front
                popFromFront();
            } else if (index == currSize-1) { // have to change back
                popFromBack();
            } else { // something in between
                curr_node->next->previous = curr_node->previous;
                curr_node->previous->next = curr_node->next; 
                delete curr_node;
                currSize--;   
            }
            return;
        } else {
            count++;
            curr_node = curr_node->next;
        }
    }
}

/*
 * name:      replaceAt
 * purpose:   replace an element at the requested index with the requested 
 *            element
 * parameters: a character to replace, an integer as the index to be replaced at
 * returns:   none
 * effects:   Throws a range error if the index is out or list's range, 
 *            uses two recursive helper functions depending on the index
 */
void CharLinkedList::replaceAt(char c, int index) {
    if (index < 0 or index >= currSize) {
        throw range_error("index (" + to_string(index) +
                            ") not in range [0.." + to_string(currSize) + ")");
    }
    if (index > (currSize/2)) {
        replaceAt_helper_back(back, c, index, (currSize-1));
    } else {
        replaceAt_helper_front(front, c, index, 0);
    }
}

/*
 * name:      replaceAt_helper_front
 * purpose:   replace a new requested element at the requested index
 * parameters: a Node pointer representing current node, a character c, an 
 *             integer index and integer count.
 * effects:   Calls itself with the next linked node as the parameter until
 *            count reaches the desired index. (Note: must be initially called 
 *            using the front node as current node)
 */
void CharLinkedList::replaceAt_helper_front(Node *curr_node, char c, int index, 
                                                                int count) {
    // Base case
    if (count == index) {
        curr_node->element = c;
    } else {
        // Recursive case
        curr_node = curr_node->next;
        count++;
        replaceAt_helper_front(curr_node, c, index, count);
    }
}

/*
 * name:      replaceAt_helper_back
 * purpose:   replace a new requested element at the requested index
 * parameters: a Node pointer representing current node, a character c, an 
 *             integer index and integer count.
 * effects:   Calls itself with the next linked node as the parameter until
 *            count reaches the desired index. (Note: must be initially called 
 *            using the back node as current node)
 */
void CharLinkedList::replaceAt_helper_back(Node *curr_node, char c, int index, 
                                                                int count) {
    // Base case
    if (count == index) {
        curr_node->element = c;
    } else {
        // Recursive case
        curr_node = curr_node->previous;
        count--;
        replaceAt_helper_back(curr_node, c, index, count);
    }
}

/*
 * name:      concatenate
 * purpose:   adds a copy of the parameter list at the end of the 
 *            first/existing list
 * parameters: a pointer to a CharLinkedList object
 * returns:   none
 * effects:   if both lists are the same, makes a deep copy of the list and 
 *            uses that temporary list to concatenate, using pushAtBack
 */
void CharLinkedList::concatenate(CharLinkedList *other) {
    Node *curr_node;
    int size = other->size();
    if (toString() == other->toString() and currSize != 0) {
        CharLinkedList *temp_list = other;
        curr_node = temp_list->front;
    } else {
        curr_node = other->front;
    }
    for (int i = 0; i < size; i++) {
        pushAtBack(curr_node->element);
        curr_node = curr_node->next;
    }
}




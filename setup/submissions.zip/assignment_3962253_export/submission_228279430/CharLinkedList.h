/*
 *  CharLinkedList.h
 *  YOUR NAME HERE
 *  DATE CREATED
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  THis file is the interface for the class CharLinkedList.h
 *
 */

#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H

#include <string>
#include <stdexcept>
#include <iostream>

class CharLinkedList {

public:

    // Constructors:
    CharLinkedList(); // all tests done
    CharLinkedList(char c); // all tests done
    CharLinkedList(char arr[], int size); // all tests done
    // Copy constructor
    CharLinkedList(const CharLinkedList &other); // !!!!!!!!! // done
    // Destructor
    ~CharLinkedList(); // done
    // Assignment operator
    CharLinkedList &operator=(const CharLinkedList &other); // !!!!!!!! // done

    // Other methods
    bool isEmpty() const; // all tests done
    void clear(); // all tests done
    int size() const; // all tests done
    char first() const; // all tests done
    char last() const; // all tests done
    char elementAt(int index) const; // all tests done
    std::string toString() const; // all tests done
    std::string toReverseString() const; // all tests done
    void pushAtBack(char c); // done // tested (need more) - mix
    void pushAtFront(char c); // done // tested (need more) - mix
    void insertAt(char c, int index); // done // tested (need more) - mix
    void insertInOrder(char c); // done // tested (need more) - mix
    void popFromFront(); // done // tested (need more) - mix
    void popFromBack(); // done // tested (need more) - mix
    void removeAt(int index); // done // tested (need more) - mix
    void replaceAt(char c, int index); // done // tested (need more) - mix
    void concatenate(CharLinkedList *other); // done // tested (need more) - mix

private:

    struct Node {
        Node *previous;
        char element;
        Node *next;
    };

    int currSize;
    Node *front;
    Node *back;

    // helper functions
    Node *create_node(Node *previous, char element, Node *next);
    void destructor_helper(Node *node);
    char elementAt_helper_front(Node *node, int index, int count) const;
    char elementAt_helper_back(Node *node, int index, int count) const;
    void insertAt_helper_front(Node *curr_node, Node *new_node, 
                                                        int index, int count);

    void insertAt_helper_back(Node *curr_node, Node *new_node, 
                                                        int index, int count);
    void replaceAt_helper_front(Node *curr_node, char c, int index, int count);
    void replaceAt_helper_back(Node *curr_node, char c, int index, int count);

};

#endif

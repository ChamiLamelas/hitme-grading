/*
 *  CharLinkedList.h
 *  Amelicha Trinidad: atrini02
 *  01/31/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  PURPOSE: Will have the class defintions for CharLinkedList
 *
 */

#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H
#include <string>

class CharLinkedList {

public:
CharLinkedList();
~CharLinkedList();
int size() const;
std::string toString() const;
void insertAt(char c, int index);
bool isEmpty() const;
void clear();
char first() const;
char last() const;
char elementAt(int index) const;
CharLinkedList(char c);
CharLinkedList(char arr[], int size);
CharLinkedList(const CharLinkedList &other);
CharLinkedList &operator=(const CharLinkedList &other);
std::string toReverseString() const; 
void pushAtBack(char c);
void pushAtFront(char c);
void insertInOrder(char c);
void popFromFront();
void popFromBack();
void removeAt(int index);
void replaceAt(char c, int index);
void concatenate(CharLinkedList *other);


private:

struct Node{
char data;
Node*next;
Node*prev;
};

Node*head;
Node*tail;
int Size;
void deleteNodes();
char elementAtHelper(Node* current, int index) const;
std::string reverseToStringHelper(Node* current) const;
void replaceAtHelper(Node* current, char c, int index);

};

#endif




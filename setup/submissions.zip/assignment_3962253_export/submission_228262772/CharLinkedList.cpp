/*
 *  CharLinkedList.cpp
 *  Amelicha Trinidad: atrini02
 *  01/31/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  PURPOSE: Will have the class implementations for CharLinkedList 
 *
 *
 */

#include "CharLinkedList.h"
#include <iostream>


/*
 * name:      CharArrayList
 * purpose:   default constructor that initialzies an empty list
 * arguments: void
 * returns:   none
 * effects:   adds new char array into the stack, makes an empty array
 */
CharLinkedList::CharLinkedList(){
    head = nullptr;
    tail = nullptr;
    Size = 0;
}


/*
 * name:      size
 * purpose:  keeps track of size of linkedlise
 * arguments: none
 * returns:   the Size of linkedlist
 * effects:   none
 */
 int CharLinkedList::size() const{
    return Size;
}


/*
 * name:      ~CharArrayList
 * purpose:   calls deletNodes to delete data
 * arguments: void
 * returns:   none
 * effects:   deletes memory on the heap 
 */
CharLinkedList::~CharLinkedList(){
 deleteNodes();
}


/*
 * name:      deleteNodes
 * purpose:   delets all nodes in the linked list
 * arguments: void
 * returns:   none
 * effects:   deletes memory on the heap 
 */
void CharLinkedList::deleteNodes(){
    Node* current = head;
    while (current != nullptr) {
        Node* next = current->next;
        delete current;
        current = next;
    }
}
  

/*
 * name:      toString
 * purpose:   to print out cotents of linkedlist
 * arguments: none
 * returns:   none
 * effects:   none
 */
std::string CharLinkedList::toString() const{
     std::string result = "[CharLinkedList of size "
    + std::to_string(Size) + " <<";
    Node* current = head;
    while (current != nullptr) {
        result += current->data;
        current = current->next;
    }
    result += ">>]";
    return result;
}


/*
 * name:      inserAt
 * purpose:   putting a character into given index
 * arguments: character and index you want node to be in
 * returns:   none
 * effects:   range_error
 */
void CharLinkedList::insertAt(char c, int index) {
    if (index < 0 or index > Size) {
        throw std::range_error
        ("index (" + std::to_string(index) +
            ") not in range [0.." + std::to_string(Size) + "]");
    }
    // Create a new node
    Node* newNode = new Node;
    newNode->data = c;

    if (index == 0) {
        // Inserting at the beginning
        newNode->next = head;
        newNode->prev = nullptr;
        if (head != nullptr)
            head->prev = newNode;
        head = newNode;
        if (tail == nullptr)
            tail = newNode;
    } else if (index == Size) {
        // Inserting at the end
        newNode->next = nullptr;
        newNode->prev = tail;
        if (tail != nullptr)
            tail->next = newNode;
        tail = newNode;
        if (head == nullptr)
            head = newNode;
    } else {
        // Inserting in the middle
        Node* temp = head;
        for (int i = 0; i < index - 1; i++) {
            temp = temp->next;
        }
        newNode->next = temp->next;
        newNode->prev = temp;
        temp->next = newNode;
        if (newNode->next != nullptr)
            newNode->next->prev = newNode;
    }
    Size++;
}


/*
 * name:      isEmpty
 * purpose:   makes sure the linkedlist is empty
 * arguments: none
 * returns:   a true or false syaing if the linked is empty
 * effects:   none
 */
bool CharLinkedList::isEmpty() const{
    return size() == 0;
}


/*
 * name:      clear
 * purpose:   makes the instance of an LinkedList empty
 * arguments: none
 * returns:   none
 * effects:   clears the linkedList
 */
void CharLinkedList::clear(){
    deleteNodes();
    head = nullptr;
    tail = nullptr;
    Size = 0;
}


/*
 * name:      first
 * purpose:   returns the character at the first node 
 * arguments: none
 * returns:   char at front
 * effects:   runtime_error
 */
char CharLinkedList::first() const{
    if (isEmpty()) {
    throw std::runtime_error
    ("cannot get first of empty LinkedList");
    }
    return head->data;
}


 /*
 * name:      last
 * purpose:   returns the character at the last node 
 * arguments: none
 * returns:   char at end
 * effects:   runtime_error
 */
char CharLinkedList::last() const{
     if (isEmpty()) {
        throw std::runtime_error
        ("cannot get last of empty LinkedList");
    }
    return tail->data;
}


 /*
 * name:      elementAtHelper
 * purpose:   recursive function that finds a certain element
 * arguments: pointer to current node, index
 * returns:   char at element
 * effects:   none
 */
char CharLinkedList::elementAtHelper(Node* current, int index) const {
     if (index == 0) {
        // Accessing the character directly
        return current->data;
    }
    return elementAtHelper(current->next, index - 1);
}


/*
 * name:      elementAt
 * purpose:   finds a certain element
 * arguments: wanted index to return
 * returns:   char at element
 * effects:   range_error
 */
char CharLinkedList::elementAt(int index) const {
    if (index < 0 or index >= Size) {
        throw std::range_error
        ("index (" + std::to_string(index)
         + ") not in range [0.." + std::to_string(Size) + ")");
    }
    return elementAtHelper(head, index);
}


/*
 * name:      CharLinkedList
 * purpose:   inserts char c into 1 node list
 * arguments: char c
 * returns:   none
 * effects:   1 size list
 */
CharLinkedList::CharLinkedList(char c){
    Size = 1; 
    head = new Node;
    head->data = c;
    head->next = nullptr;
    head->prev = nullptr;
    tail = head;
}


/*
 * name:      CharLinkedList
 * purpose:   expands list depending on size 
 * arguments: char array, size
 * returns:   none
 * effects:   none
 */
CharLinkedList::CharLinkedList(char arr[], int size){
    head = nullptr;
    tail = nullptr;
    Size = 0;

    // Check for empty array or negative size
    if (size <= 0 or arr == nullptr) {
        return;
    }

    // Iterate through the array and add elements to the linked list
    for (int i = 0; i < size; ++i) {
        // Create a new node
        Node* newNode = new Node;
        newNode->data = arr[i];
        // Initialize next pointer to nullptr
        newNode->next = nullptr;

        // If this is the first node, set it as both head and tail
        if (head == nullptr) {
            head = newNode;
            tail = newNode;
        } else {
            //append the new node to the tail
            tail->next = newNode;
            newNode->prev = tail;
            tail = newNode;
        }
        Size++;
    }
}



/*
 * name:      CharLinkedList
 * purpose:   make a copy
 * arguments: class and address
 * returns:   none
 * effects:   none
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other) {
    head = nullptr;
    tail = nullptr;
    Size = 0;

    //copy each node
    Node* current = other.head;
    while (current != nullptr) {
        // Create a new node
        Node* newNode = new Node;
        newNode->data = current->data;
        newNode->next = nullptr; 

        // If this is the first node, set it as both head and tail
        if (head == nullptr) {
            head = newNode;
            tail = newNode;
        } else {
            //append the new node to the tail
            tail->next = newNode;
            newNode->prev = tail;
            tail = newNode;
        }
        // Move to the next node in the other list
        current = current->next;
        Size++;
    }
}




/*
 * name:      CharLinkedList& operator=
 * purpose:   makes a copy
 * arguments: class and address
 * returns:   none
 * effects:   none
 */
CharLinkedList& CharLinkedList::operator=(const CharLinkedList &other) {
    // Check for self-assignment
    if (this == &other) {
        return *this;
    }

    clear();

    //  the other list and copy each node
    Node* current = other.head;
    while (current != nullptr) {
        Node* newNode = new Node;
        newNode->data = current->data;
         // Initialize next pointer to nullptr
        newNode->next = nullptr;

        // If this is the first node, set it as both head and tail
        if (head == nullptr) {
            head = newNode;
            tail = newNode;
        } else {
            // Otherwise, append the new node to the tail
            tail->next = newNode;
            newNode->prev = tail;
            tail = newNode;
        }
        // Move to the next node in the other list
        current = current->next;
        Size++;
    }
    // Return *this for chaining assignments
    return *this; 
}



/*
 * name:      reverseToStringHelper
 * purpose:   recursively goes backward
 * arguments: the current node
 * returns:   none
 * effects:   string of information
 */
std::string CharLinkedList::reverseToStringHelper(Node* current) const {
        if (current == nullptr) {
            // Base case: reached the end of the list
            return ""; 
        }
         // Recursively goes backwards
        return current->data + reverseToStringHelper(current->prev);
}



/*
 * name:      toReverseString
 * purpose:   couts backward string
 * arguments: the current node
 * returns:   string backwards
 * effects:   none
 */
std::string CharLinkedList::toReverseString() const {
        std::string reversedString =
         "[CharLinkedList of size " + std::to_string(Size) + " <<";
        if (Size > 0) {
            // Call the private recursive helper function
            reversedString += reverseToStringHelper(tail); 
        }
        reversedString += ">>]";
        return reversedString;
}


/*
 * name:      pushAtBack
 * purpose:    It inserts the given new element
 *             in the end of the existing elements of the list.
 * arguments: char c
 * returns:   none
 * effects:   none
 */
void CharLinkedList:: pushAtBack(char c) {
        Node* newNode = new Node();
        newNode->data = c; // Set the data separately
        if (head == nullptr) {
            // If the list is empty, set both head and tail to the new node
            head = tail = newNode;
        } else {
            // Otherwise, append the new node after the current tail
            tail->next = newNode;
            newNode->prev = tail;
            tail = newNode;
        }
        Size++;
}


/*
 * name:      pushAtFront
 * purpose:    It inserts the given new element
 *             in front of the existing elements of the list.
 * arguments: char c
 * returns:   none
 * effects:   none
 */
void CharLinkedList:: pushAtFront(char c){
    Node* newNode = new Node();
    newNode->data = c;
    if (head == nullptr){
        // If the list is empty,
        // set both head and tail to the new node
        head = tail = newNode;
    }
    else{
        // Otherwise, insert the new node before the current head
        newNode->next = head;
        head = newNode;
    }
    Size++;
}


 
 /*
 * name:      insertInOrder
 * purpose:    inserts into list in ASCII order
 * arguments: char c
 * returns:   none
 * effects:   none
 */
void CharLinkedList:: insertInOrder(char c) {
    Node* newNode = new Node();
    newNode->data = c;
    if (head == nullptr or c <= head->data) {
    // If the list is empty or
    // the new element is
    // smaller than the head, insert at the beginning
    newNode->next = head;
    head = newNode;
    } else {
    Node* current = head;
    while (current->next != nullptr and
     c > current->next->data) {
    current = current->next;
    }
    newNode->next = current->next;
    current->next = newNode;
    }
    if (newNode->next == nullptr) {
    // If the new node is inserted at the end,
    // update the tail pointer
    tail = newNode;
    }
    Size++;
}


 /*
 * name:      popFromFront
 * purpose:   to remove the first element from the list
 * arguments: none
 * returns:   none
 * effects:   runtime_error
 */
void CharLinkedList:: popFromFront() {
    if (head == nullptr) {
    throw std::runtime_error
    ("cannot pop from empty LinkedList");
    }
    Node* temp = head;
    head = head->next;
    delete temp;
    if (head == nullptr) {
        // If the list becomes empty after popping,
        // update the tail pointer
        tail = nullptr;
    }
    Size--;
}



 /*
 * name:      popFromBack
 * purpose:   to remove the end element from the list
 * arguments: none
 * returns:   none
 * effects:   runtime_error
 */
void CharLinkedList:: popFromBack() {
        if (isEmpty()) {
            throw std::runtime_error
            ("cannot pop from empty LinkedList");
        }
        if (head == tail) {
            delete tail;
            head = tail = nullptr;
        } else {
            Node* current = head;
            while (current->next != tail) {
                current = current->next;
            }
            delete tail;
            tail = current;
            tail->next = nullptr;
        }
        Size--;
}


 /*
 * name:      removeAt
 * purpose:   to remove at specfied index
 * arguments: none
 * returns:   none
 * effects:   range_error
 */
void CharLinkedList:: removeAt(int index){
if (index < 0 or index >= Size) {
            throw std::range_error
            ("index (" + std::to_string(index) + ") not in range [0.." + 
            std::to_string(Size) + ")");
        }

        if (index == 0) {
            Node* temp = head;
            head = head->next;
            delete temp;
            if (head == nullptr) {
                tail = nullptr;
            }
        } else {
            Node* current = head;
            for (int i = 0; i < index - 1; ++i) {
                current = current->next;
            }
            Node* temp = current->next;
            current->next = current->next->next;
            delete temp;
            if (current->next == nullptr) {
                tail = current;
            }
        }
        Size--;
}


 /*
 * name:      replaceAtHelper
 * purpose:   makes the replaceAt function faster
 * arguments: none
 * returns:   none
 * effects:   range_error
 */
void CharLinkedList:: replaceAtHelper(Node* current, char c, int index){
     if (index == 0) {
            current->data = c;
            return;
        }
        if (current->next == nullptr) {
        throw std::range_error("index (" + std::to_string(index)
         + ") not in range [0.." + std::to_string(Size) + ")");
        }
        replaceAtHelper(current->next, c, index - 1);
}


 /*
 * name:      replaceAt
 * purpose:   to remove at and replace element
 * arguments: none
 * returns:   none
 * effects:   range_error
 */
void CharLinkedList:: replaceAt(char c, int index) {
        if (index < 0 or index >= Size) {
            throw std::range_error("index (" + std::to_string(index)
             + ") not in range [0.." + std::to_string(Size) + ")");
        }
        replaceAtHelper(head, c, index);
}


 /*
 * name:      concatenate
 * purpose:   concatenate another thing to the end of the list 
 * arguments: class and address
 * returns:   none
 * effects:   none
 */
//Function to concatenate another CharLinkedList to the end of this list
void CharLinkedList::concatenate(CharLinkedList *other) {
        if (other == nullptr) {
            return; 
        }
        Node* otherCurrent = other->head;
        while (otherCurrent != nullptr) {
            pushAtBack(otherCurrent->data);
            otherCurrent = otherCurrent->next;
        }
    }
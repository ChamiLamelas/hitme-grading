/*
 *  unit_tests.h
 *  Amelicha Trinidad: atrini02
 *  01/31/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  PURPOSE: Uses Amelicha's unit_test framework
 *           to test the CharArrayList class.
 *
 */
#include "CharLinkedList.h"
#include <cassert>
#include <iostream>
using namespace std;


//tests if the constructor size is 0
void default_constructor_test(){
   CharLinkedList test_list;

   assert(test_list.size() == 0);
}

//test by interting elements 
//then testing if the expected cout statement
//is the same 
void toString_test(){
   CharLinkedList list_test;

   list_test.insertAt('a', 0 );
   list_test.insertAt('b', 1 );
   list_test.insertAt('c', 2 );

   std::string result = list_test.toString();
   std::string expected = "[CharLinkedList of size 3 <<abc>>]";
   assert(result == expected);

}


//creating memory so it can get deleted
void deconstructor_test(){
    CharLinkedList list_test;
    
    // Add some elements to the list
    list_test.insertAt('a',0);
    list_test.insertAt('b',1);
    list_test.insertAt('c',2);
}



//test by adding elements, 
//then testing the expected size 
void size_test(){
   CharLinkedList list_test;
   
   list_test.insertAt('a',0);
   list_test.insertAt('b',1);
   list_test.insertAt('c',2);
   
   assert(list_test.size() == 3);
   
}

//tetsing by making sure that size is 
//0 when it isEmpty
void size_test2(){
   CharLinkedList list_test;

   if(list_test.size() == 0){
      assert(list_test.isEmpty());
   }

}

//testing to see if when I add elements
//it knows that it is NOT empty
void isEmpty(){
   CharLinkedList list_test;

   list_test.insertAt('a',0);
   list_test.insertAt('b',1);
   list_test.insertAt('c',2);
   
   assert(not list_test.isEmpty());
}

//testing clear by adding elements 
//then clearing it then using 
//my is empty function because there should 
//not be anything there
void clear_test(){
   CharLinkedList list_test;

   list_test.insertAt('a',0);
   list_test.insertAt('b',1);
   list_test.insertAt('c',2);

   list_test.clear();

   assert(list_test.isEmpty());

}

//inserting elements 
//making sure my first function 
//is returning the letter a
void first_test(){
   CharLinkedList list_test;
   
   list_test.insertAt('a',0);
   list_test.insertAt('b',1);
   list_test.insertAt('c',2);

   assert(list_test.first() == 'a');
}



//testing by inserting elements 
//then making sure that my last function is 
//going to return c
void last_test(){
   CharLinkedList list_test;

   list_test.insertAt('a',0);
   list_test.insertAt('b',1);
   list_test.insertAt('c',2);

   assert(list_test.last() == 'c');

}


//testing by making elmements, then
//picking one of the nodes and making 
//sure it will return the expected c
void elementAt_test(){
   CharLinkedList list_test;

   list_test.insertAt('a',0);
   list_test.insertAt('b',1);
   list_test.insertAt('c',2);

   assert(list_test.elementAt(2) == 'c');
}


//test for elementAt range error cout
void elementAt_test2(){
   CharLinkedList list_test;

   list_test.insertAt('a',0);
   list_test.insertAt('b',1);
   list_test.insertAt('c',2);

   bool rangeErrorThrown = false;
   std::string errorMessage = "";

   try {

        list_test.elementAt(42);
   }
   catch (const std::range_error &e) {
        rangeErrorThrown = true;
        errorMessage = e.what();
   }
    assert(rangeErrorThrown);
    assert(errorMessage == "index (42) not in range [0..3)");
}


//testing if constructor is increamenting 
//in size and should not be empty
void CharLinkedList_char_test(){
   CharLinkedList list_test('c');
   assert(list_test.size() == 1);
   assert(not list_test.isEmpty());
}


//test for CharLinkedList char/ int empty
//by making an empty array and making 
//sure that the size is 0 and that it isEmpty
void CharLinkedList_char_int_test(){
   char arr[] = {};
   CharLinkedList list_test(arr, 0);
   assert(list_test.size() == 0);
   assert(list_test.isEmpty());

}


//test for charLinkedList char/int not empty
//by adding elements to array 
//then testing if the size is 3 and it noe empty
void CharLinkedList_char_int_test2(){
   char arr[3] = {'a','b','c'};
   CharLinkedList list_test(arr, 3);
   assert(list_test.size() == 3);
   assert(not list_test.isEmpty());
}


//test that when there is nothing to copy
//it should be empty
void copy_constructor_test(){
   CharLinkedList original;
   CharLinkedList copy(original);

   assert(copy.size() == 0);
   assert(copy.isEmpty());
}


//test for copy constructor not empty
//by making an orginal version 
//then calling the function
//then seeing if it copied it correctlty
//by giving the expected elements
void copy_constructor_test2(){
   CharLinkedList original;
   original.insertAt('a', 0);
   original.insertAt('b', 1);
   original.insertAt('c', 2);

   CharLinkedList copy(original);

   assert(copy.size() == 3);
   assert(not copy.isEmpty());

   assert(copy.elementAt(0) == 'a');
   assert(copy.elementAt(1) == 'b');
   assert(copy.elementAt(2) == 'c');
}


//test if it is copying correclty
//by making a list, then setting them 
//= should mean that the both should be the same
void copy_constructor2_test(){
   
   CharLinkedList list_test;
   list_test.insertAt('a', 0);
   list_test.insertAt('b',1);

   list_test = list_test;

   assert(list_test.size() == 2);
   assert(list_test.elementAt(0) == 'a');
   assert(list_test.elementAt(1) == 'b');

}


//test if you can modify orginal list
//I should be able to modify the 
//original list without it affecting 
//the copy
void copy_constructor2_test2(){
   CharLinkedList list_test;
   list_test.insertAt('a', 0);
   list_test.insertAt('b', 1);
        
   CharLinkedList other;
   other.insertAt('x', 0);
   other.insertAt('y', 1);
        
   list_test = other;
        
   // Modify the original list
   other.insertAt('z', 2);

   // Check that the copied list remains unchanged
   assert(list_test.size() == 2);
   assert(list_test.elementAt(0) == 'x');
   assert(list_test.elementAt(1) == 'y');
}



//testing if my set array will cout in reverse
void reverse_test(){
      // Create a CharArrayList object
    CharLinkedList list_test;

    // Insert elements into the list
    list_test.insertAt('a', 0);
    list_test.insertAt('b', 1);
    list_test.insertAt('c', 2);

    // Call the toReverseString function
    std::string result = list_test.toReverseString();

    // Verify the expected reversed string representation
    std::string expected = "[CharLinkedList of size 3 <<cba>>]";
    assert(result == expected);
}



//testing by making my array and testing expected size 
//and what it should be
void pushAtBack_test(){
    // Create a CharArrayList object
    CharLinkedList list_test;

    // Add some elements to the list
    list_test.pushAtBack('a');
    list_test.pushAtBack('b');
    list_test.pushAtBack('c');

    // Verify that the elements are added correctly
    assert(list_test.elementAt(0) == 'a');
    assert(list_test.elementAt(1) == 'b');
    assert(list_test.elementAt(2) == 'c');

    // Verify that the size of the list increases
    assert(list_test.size() == 3);
}


//testing if it properly adds everything to front
void push_at_front_test(){
      // Create a CharArrayList object
    CharLinkedList list_test;

    // Add some elements to the list
    list_test.pushAtFront('a');
    list_test.pushAtFront('b');
    list_test.pushAtFront('c');

    // Verify that the elements are added correctly
    assert(list_test.elementAt(0) == 'c');
    assert(list_test.elementAt(1) == 'b');
    assert(list_test.elementAt(2) == 'a');

    // Verify that the size of the list increases
    assert(list_test.size() == 3);
}


// Tests correct insertion into an empty AL.
// Afterwards, size should be 1 and element at index 0
// should be the element we inserted.
void insertAt_empty_correct() { 

    CharLinkedList test_list;
    test_list.insertAt('a', 0);
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');

}

// Tests out-of-range insertion for a non-empty list.
void insertAt_nonempty_incorrect() {
   
    char test_arr[8] = 
    { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    // cerr << error_message << "\n";
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8]");
    
}


// Tests insertion into the middle of a larger list
void insertAt_middle_large_list() {
    char test_arr[8] =
     { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.insertAt('z', 3);

    assert(test_list.size() == 9);
    assert(test_list.elementAt(3) == 'z');
    assert(test_list.toString() ==
     "[CharLinkedList of size 9 <<abczdefgh>>]");

}


// Tests insertion into the back of a larger list
void insertAt_back_large_list() {
    char test_arr[10] = 
    { 'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 10);  

    test_list.insertAt('x', 10);

    assert(test_list.size() == 11);
    assert(test_list.elementAt(10) == 'x');
    assert(test_list.toString() == 
    "[CharLinkedList of size 11 <<yabczdefghx>>]"); 

}


// Tests insertion into front of a larger list
void insertAt_front_large_list() {
    char test_arr[9] = 
    { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    test_list.insertAt('y', 0);

    assert(test_list.size() == 10);
    assert(test_list.elementAt(0) == 'y');
    assert(test_list.toString() ==
         "[CharLinkedList of size 10 <<yabczdefgh>>]");

}

// Tests calling insertAt for a large number of elements.
// Not only does this test insertAt, it also checks that
// array expansion works correctly.
void insertAt_many_elements() {
    
    CharLinkedList test_list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.insertAt('a', i);
    }

    assert(test_list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
    
}

// // Tests incorrect insertion into an empty AL.
// // Attempts to call insertAt for index larger than 0.
// // This should result in an std::range_error being raised.
void insertAt_empty_incorrect() {

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    // insertAt for out-of-range index
    test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
    // if insertAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    range_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0]");
    
}


// Tests correct insertAt for front of 1-element list.
void insertAt_front_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at front
    test_list.insertAt('b', 0);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'a');
    
}


// Tests correct insertAt for back of 1-element list.
void insertAt_back_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at back
    test_list.insertAt('b', 1);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    
}

//testing by making an array out of order
//then calling inorder to see if knows how 
void insertInOrder_test(){
    // Create a CharArrayList object
    CharLinkedList list_test;

    // Add some elements to the list
    list_test.insertInOrder('b');
    list_test.insertInOrder('d');
    list_test.insertInOrder('a');
    list_test.insertInOrder('c');

    // Verify that the elements are added in the correct order
    assert(list_test.elementAt(0) == 'a');
    assert(list_test.elementAt(1) == 'b');
    assert(list_test.elementAt(2) == 'c');
    assert(list_test.elementAt(3) == 'd');

    // Verify that the size of the list increases
    assert(list_test.size() == 4);
}



//testing by adding the elements to list
//then removing them, then testing if they are
//getting shifted
void popFromFront_test(){
      // Create a CharLinkedList object
    CharLinkedList list_test;

    // Add some elements to the list
    list_test.pushAtBack('a');
    list_test.pushAtBack('b');
    list_test.pushAtBack('c');

    // Remove the first element
    list_test.popFromFront();

    // Verify that the first element is removed correctly
    assert(list_test.elementAt(0) == 'b');
    assert(list_test.elementAt(1) == 'c');

    // Verify that the size of the list decreases
    assert(list_test.size() == 2);

}


//testing if the error message is same
void popFromFront_test2(){
CharLinkedList list_test;

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        list_test.popFromFront();
    }
    catch (const std::runtime_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message
     == "cannot pop from empty LinkedList");

}


//testing by adding elements 
//then using popback to check if
//the size is correct 
void popFromBack_test(){
    CharLinkedList list_test;

    list_test.insertAt('a',0);
    list_test.insertAt('b',1);
    list_test.insertAt('c',2);


    list_test.popFromBack();

    assert(list_test.elementAt(0) == 'a');
    assert(list_test.elementAt(1) == 'b');

   assert(list_test.size() == 2);

}

//testing if the error message is same
void popFromBack_test2(){
CharLinkedList list_test;

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        list_test.popFromBack();
    }
    catch (const std::runtime_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");

}

//testing by inserting at element then
//then verifying if everything shifted
//by calling removeAt to see if the element 
//is where its supposed to be 
void removeAt_function() {
    // Create a CharArrayList object
    CharLinkedList list_test;

    // Insert elements into the list
    list_test.insertAt('a', 0);
    list_test.insertAt('b', 1);

    // Remove an element at index 0
    list_test.removeAt(0);

    // Verify the element at index 0 after removal (should be 'b')
    assert(list_test.elementAt(0) == 'b');
}


//testing by making array then
//seeing if it is the expected char
void replaceAt_test(){
    CharLinkedList list_test;

    list_test.insertAt('a', 0);
    list_test.insertAt('b',1);
    list_test.insertAt('c',2);

    list_test.replaceAt('z',1);
    assert(list_test.elementAt(1) == 'z');
}


//test for one list and another list copy
void concatenate_test() {
    // Create two CharArrayList objects
    CharLinkedList list1;
    list1.insertAt('c',0);
    list1.insertAt('a',1);
    list1.insertAt('t',2);

    CharLinkedList list2;
    list2.insertAt('C',0);
    list2.insertAt('H',1);
    list2.insertAt('E',2);
    list2.insertAt('S',3);
    list2.insertAt('H',4);
    list2.insertAt('I',5);
    list2.insertAt('R',6);
    list2.insertAt('E',7);

    // Concatenate list2 to list1
    list1.concatenate(&list2);

    // Verify the result
    assert(list1.size() == 11);
    assert(list1.elementAt(3) == 'C');
    assert(list1.elementAt(8) == 'I');
}


/*
*  CharLinkedList.h
*  Robert Stark
*  2/1/2024
*
*  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
*
*  Purpose: CharLinkedList class definition. This file contains the 
*  definitions of all public and private functions and variables necessary
*  to create a CharLinkedList. A client can look at this file and understand
*  what types of information can be stored in a CharLinkedList and what
*  methods can be performed to create/manipulate their CharLinkedList.
*
*/

#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H

#include <string>

class CharLinkedList
{
public:
    // Constructors
    CharLinkedList();
    CharLinkedList(char c);
    CharLinkedList(char arr[], int size);
    CharLinkedList(const CharLinkedList &other);

    // Destructors
    ~CharLinkedList();

    // Recycle
    CharLinkedList &operator=(const CharLinkedList &other);

    // Const Helpers
    bool isEmpty() const;
    void clear();
    int size() const;
    char first() const;
    char last() const;
    char elementAt(int index) const;
    std::string toString() const;
    std::string toReverseString() const;

    // Modifiers
    void pushAtBack(char c);
    void pushAtFront(char c);
    void insertAt(char c, int index);
    void insertInOrder(char c);
    void popFromFront();
    void popFromBack();
    void removeAt(int index);
    void replaceAt(char c, int index);
    void concatenate(CharLinkedList *other);

    
private:
    struct Node {
        char data;
        Node *next;
        Node *prev;
    };

    int currSize;
    Node *front;
    Node *back;

    Node *newNode(char newData, Node *next, Node *prev);
    void recycleRecursive(Node *curr);
    Node *searchHelper(int index) const;
    Node *frontSearch(Node *curr, int index) const;
    Node *backSearch(Node *curr, int index) const;
    void insertInOrderHelper(Node *curr, char c, int index);
};

#endif
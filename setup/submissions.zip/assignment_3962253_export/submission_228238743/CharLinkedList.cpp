/*
*  CharLinkedList.cpp
*  Robert Stark (rstark03)
*  2/1/2024
*
*  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
*
*  Purpose: CharLinkedList.h implementation file. This file contains the
*  implementation and contracts for all public and private functions defined in
*  CharLinkedList.h. The public functions in this file can be used by the 
*  client to create and manage a CharLinkedList.
*/

#include "CharLinkedList.h"
#include <stdexcept>

using namespace std;

/*
* name:      newNode
* purpose:   Constructs an object of type Node on the heap
* arguments: Data for node to hold and the previous and next nodes 
*            in the LL.
* returns:   A pointer to a node.
* effects:   
*/
CharLinkedList::Node *CharLinkedList::newNode(char newData, Node *next, 
Node *prev){

    Node *new_node = new Node;
    new_node->data = newData;
    new_node->next = next;
    new_node->prev = prev;
    return new_node;
}

// Constructors

/*
* name:      CharLinkedList()
* purpose:   Constructs empty char LL
* arguments: None
* returns:   None
* effects:   
*/
CharLinkedList::CharLinkedList(){

    front = newNode('\0', nullptr, nullptr);
    back = newNode('\0', nullptr, front);
    front->next = back;
    currSize = 0;
}

/*
* name:      CharLinkedList(char c)
* purpose:   Constructs char LL with a single char
* arguments: Char to put in array
* returns:   None
* effects:   
*/
CharLinkedList::CharLinkedList(char c){
    
    front = newNode('\0', nullptr, nullptr);
    back = newNode('\0', nullptr, front);
    front->next = newNode(c, back, front);
    back->prev = front->next;
    currSize = 1;
}

/*
* name:      CharLinkedList(char arr[], int size)
* purpose:   Creates char LL with a copy of an existing arr
* arguments: Char arr to copy and size of that arr
* returns:   None
* effects:   
*/
CharLinkedList::CharLinkedList(char arr[], int size){
    front = newNode('\0', nullptr, nullptr);
    back = newNode('\0', nullptr, front);
    front->next = back;
    currSize = 0;

    for(int i = 0; i < size; i++){  
        pushAtBack(arr[i]);
    }
}

/*
* name:      CharLinkedList(const CharLinkedList &other)
* purpose:   Creates a new char LL that is a deep copy of another
* arguments: An existing LL
* returns:   None
* effects:   
*/
CharLinkedList::CharLinkedList(const CharLinkedList &other){
    front = newNode('\0', nullptr, nullptr);
    back = newNode('\0', nullptr, front);
    front->next = back;
    currSize = 0;

    for(int i = 0; i < other.size(); i++){  
        pushAtBack(other.elementAt(i));
    }
}

// Destructors

/*
* name:      ~CharLinkedList
* purpose:   Deletes memory used on the heap by LL
* arguments: None
* returns:   None
* effects:   
*/
CharLinkedList::~CharLinkedList(){
    recycleRecursive(front);
}

/*
* name:      recycleRecursive
* purpose:   Recursively deletes memory used on the heap by LL.
* arguments: Current node.
* returns:   None
* effects:   
*/
void CharLinkedList::recycleRecursive(Node *curr){
    if(curr == nullptr){
        return;
    }
    else{
        Node *next = curr->next;
        delete curr;
        recycleRecursive(next);
    }
}

/*
* name:      &CharLinkedList::operator=
* purpose:   Recycles memory of instance on the left and creates
*            a deep copy of the right onto the left.
* arguments: Two existing LL.
* returns:   Copied LL.
* effects:   
*/
CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other){
    // If already the same list, return
    if (this == &other) return *this;

    // Else recycle data, make deep copy, and return
    recycleRecursive(front);
    front = newNode('\0', nullptr, nullptr);
    back = newNode('\0', nullptr, front);
    front->next = back;
    currSize = 0;

    for(int i = 0; i < other.size(); i++){  
        pushAtBack(other.elementAt(i));
    }

    return *this;
}

// Const Helpers

/*
* name:      isEmpty
* purpose:   Checks to see if LL is empty.
* arguments: None.
* returns:   True if LL is empty, False otherwise.
* effects:   
*/
bool CharLinkedList::isEmpty() const{
    return currSize == 0;
}

/*
* name:      clear
* purpose:   Sets LL size to zero.
* arguments: None.
* returns:   None.
* effects:   
*/
void CharLinkedList::clear(){
    recycleRecursive(front);
    front = newNode('\0', nullptr, nullptr);
    back = newNode('\0', nullptr, front);
    front->next = back;
    currSize = 0;
}

/*
* name:      size
* purpose:   Returns size of LL.
* arguments: None.
* returns:   Size of LL.
* effects:   
*/
int CharLinkedList::size() const{
    return currSize;
}

/*
* name:      first
* purpose:   Returns first element of LL.
* arguments: None.
* returns:   First element of LL if possible, otherwise an error.
* effects:   If LL is empty will throw runtime error.
*/
char CharLinkedList::first() const{
    if(currSize == 0){
        throw std::runtime_error("cannot get first of empty LinkedList");
    }
    else return front->next->data;
}

/*
* name:      last
* purpose:   Returns last element of LL.
* arguments: None.
* returns:   Last element of LL (if possible), otherwise an error.
* effects:   If LL is empty will throw runtime error.
*/
char CharLinkedList::last() const{
    if(currSize == 0){
        throw std::runtime_error("cannot get last of empty LinkedList");
    }
    else return back->prev->data;
}

/*
* name:      elementAt
* purpose:   Returns specified element of LL.
* arguments: An index of the LL.
* returns:   Element of LL at index (if possible), otherwise an error.
* effects:   If LL is empty will throw range error.
*/
char CharLinkedList::elementAt(int index) const{
    if(index >= currSize or index < 0){
        throw std::range_error("index (" + std::to_string(index) + 
        ") not in range [0.." + std::to_string(currSize) + ")");
    }
    return searchHelper(index)->data;
}

/*
* name:      searchHelper
* purpose:   Calls most efficient recursive search function based on index.
* arguments: Pointer to front of LL and index to find.
* returns:   Element of LL at index.
* effects:   
*/
CharLinkedList::Node* CharLinkedList::searchHelper(int index) const{
    // Include index of currSize for elementAt func
    if(index == currSize) return back;
    // If index is in first half of list, search from the front
    else if(index <= currSize/2) return frontSearch(front->next, index);
    // Otherwise search from the back
    else return backSearch(back->prev, index);
}

/*
* name:      frontSearch
* purpose:   Returns specified node of LL.
* arguments: Pointer to front of LL and index to find.
* returns:   Element of LL at index.
* effects:   
*/
CharLinkedList::Node *CharLinkedList::frontSearch(Node *curr, int index) 
const{
    if(index == 0) return curr;
    else return frontSearch(curr->next, index - 1);
}

/*
* name:      backSearch
* purpose:   Returns specified element of LL.
* arguments: Pointer to back of LL and index to find.
* returns:   Element of LL at index.
* effects:   
*/
CharLinkedList::Node *CharLinkedList::backSearch(Node *curr, int index) 
const{
    if(index == currSize - 1) return curr;
    else return backSearch(curr->prev, index + 1);
}

/*
* name:      toString
* purpose:   Returns LL in format of a string.
* arguments: None.
* returns:   LL in format of a string.
* effects:   
*/
std::string CharLinkedList::toString() const{
    std::string concat = "[CharLinkedList of size " + 
    to_string(currSize) + " <<";
    Node *curr_node = front->next;
    for(int i = 0; i < currSize; i++){
        concat += curr_node->data;
        curr_node = curr_node->next;
    }
    concat += ">>]";
    return concat;
}

/*
* name:      toReverseString
* purpose:   Returns reversed LL in format of a string.
* arguments: None.
* returns:   Reversed LL in format of a string.
* effects:   
*/
std::string CharLinkedList::toReverseString() const{
    std::string concat = "[CharLinkedList of size " + 
    to_string(currSize) + " <<";
    Node *curr_node = back->prev;
    for(int i = 0; i < currSize; i++){
        concat += curr_node->data;
        curr_node = curr_node->prev;
    }
    concat += ">>]";
    return concat;
}

// Modifiers

/*
* name:      pushAtBack
* purpose:   Adds element to end of LL. If no space for the
*            new element, resize LL.
* arguments: Char to be added to LL.
* returns:   None.
* effects:   
*/
void CharLinkedList::pushAtBack(char c){
    back->prev = newNode(c, back, back->prev);
    back->prev->prev->next = back->prev; 
    currSize++;
}

/*
* name:      pushAtFront
* purpose:   Adds element to front of LL. If no space for the
*            new element, resize LL.
* arguments: Char to be added to LL.
* returns:   None.
* effects:   
*/
void CharLinkedList::pushAtFront(char c){
    front->next = newNode(c, front->next, front);
    front->next->next->prev = front->next;
    currSize++;
}

/*
* name:      insertAt
* purpose:   Inserts element at specified index. 
*            If no space for the new element, resize LL.
* arguments: Char to be added to LL.
* returns:   None.
* effects:   If LL is empty will throw range error.
*/
void CharLinkedList::insertAt(char c, int index){
    if(index > currSize or index < 0){
        throw std::range_error("index (" + std::to_string(index) + 
        ") not in range [0.." + std::to_string(currSize) + "]");
    }
    Node *next = searchHelper(index);
    Node *prev = next->prev;
    prev->next = newNode(c, next, prev);
    next->prev = prev->next;
    currSize++;
}

/*
* name:      insertInOrder
* purpose:   Given an alphabetically ordered LL, inserts given char to
*            maintain order.
* arguments: Char to be added to LL.
* returns:   None.
* effects:   
*/
void CharLinkedList::insertInOrder(char c){
    insertInOrderHelper(front, c, 0);
}

/*
* name:      insertInOrderHelper
* purpose:   Recursively goes through LL and finds location to insert char
* arguments: Char to be added to LL, current node, and current index.
* returns:   None.
* effects:   
*/
void CharLinkedList::insertInOrderHelper(Node *curr, char c, int index){
    // If at the back of LL, insert at back
    if(curr->next == back){
        insertAt(c, currSize);
        return;
    }
    // If the char comes before char of next node, insert at curr index
    else if(c <= curr->next->data){
        insertAt(c, index);
        return;
    }
    else return insertInOrderHelper(curr->next, c, index + 1);
}

/*
* name:      popFromFront
* purpose:   Removes first element from LL
* arguments: None.
* returns:   None.
* effects:   If LL is empty will throw runtime error.
*/
void CharLinkedList::popFromFront(){
    if(currSize == 0){
        throw std::runtime_error("cannot pop from empty LinkedList");
    }
    removeAt(0);
}

/*
* name:      popFromBack
* purpose:   Removes last element from LL
* arguments: None.
* returns:   None.
* effects:   If LL is empty will throw runtime error.
*/
void CharLinkedList::popFromBack(){
    if(currSize == 0){
        throw std::runtime_error("cannot pop from empty LinkedList");
    }
    removeAt(currSize - 1);
}

/*
* name:      removeAt
* purpose:   Removes element from LL at specified index
* arguments: Index to remove element at.
* returns:   None.
* effects:   If LL is empty will throw range error.
*/
void CharLinkedList::removeAt(int index){
    if(index >= currSize or index < 0){
        throw std::range_error("index (" + std::to_string(index) + 
        ") not in range [0.." + std::to_string(currSize) + ")");
    }
    Node *next = searchHelper(index)->next;
    Node *prev = next->prev->prev;
    delete next->prev;
    next->prev = prev;
    prev->next = next;
    currSize--;
}

/*
* name:      replaceAt
* purpose:   Replaces element at specified index with provided char.
* arguments: Index to replace and new char.
* returns:   None.
* effects:   If LL is empty will throw range error.
*/
void CharLinkedList::replaceAt(char c, int index){
    if(index >= currSize or index < 0){
        throw std::range_error("index (" + std::to_string(index) + 
        ") not in range [0.." + std::to_string(currSize) + ")");
    }
    searchHelper(index)->data = c;
}

/*
* name:      concatenate
* purpose:   Concatenates provided LL to the end of LL.
* arguments: Pointer to another LL.
* returns:   None.
* effects:   
*/
void CharLinkedList::concatenate(CharLinkedList *other){
    if(other->currSize == 0) return;
    int concatSize = currSize + other->currSize;

    int j = 0;
    for(int i = currSize; i < concatSize; i++){
        insertAt(other->elementAt(j), i);
        j++;
    }
    currSize = concatSize;
}
/*
*  unit_tests.h
*  Robert Stark (rstark03)
*  2/1/2024
*
*  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
*
*  An implementation of tests for the CharLinkedList interface. These tests
*  can be run to ensure edge cases are handled by the CharLinkedList and that
*  there are no unexpected errors/memory leaks.
*
*/

#include "CharLinkedList.h"
#include <cassert>

using namespace std;

// Constructor Tests

// Tests base constructor
void baseConstructorTest() { 

    CharLinkedList test_list;

    assert(test_list.isEmpty());
}

// Tests single character constructor
void singleCharConstructorTest() { 

    CharLinkedList test_list('a');

    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');
}

// Tests copy of array constructor if array is nonempty
void nonempty_existingArrConstructorTest() { 

    char arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(arr, 9);

    assert(test_list.size() == 9);
    assert(test_list.toString() == "[CharLinkedList of size 9 <<abczdefgh>>]");
}

// Tests copy of array constructor if array is empty
void empty_existingArrConstructorTest() { 

    char sec_arr[0] = {};
    CharLinkedList test_list(sec_arr, 0);

    assert(test_list.isEmpty());
}

// Tests deep copy constructor if LL is nonempty
void nonempty_deepCopyConstructorTest(){

    char arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(arr, 9);
    CharLinkedList deepcopy_list(test_list);

    assert(test_list.size() == deepcopy_list.size());
    assert(&(test_list) != &(deepcopy_list));
    assert(deepcopy_list.toString() == 
    "[CharLinkedList of size 9 <<abczdefgh>>]");
}

// Tests deep copy constructor if LL is empty
void empty_deepCopyConstructorTest(){

    CharLinkedList test_list;
    CharLinkedList deepcopy_list(test_list);

    assert(deepcopy_list.isEmpty());
}

// Tests recycle of deep copy if LL is nonempty
void nonempty_deepCopyRecycleTest(){

    char arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(arr, 9);
    CharLinkedList deepcopy_list = test_list;
    
    assert(test_list.size() == deepcopy_list.size());
    assert(&(test_list) != &(deepcopy_list));
    assert(deepcopy_list.toString() == 
    "[CharLinkedList of size 9 <<abczdefgh>>]");
}

// Tests recycle of deep copy if LL is empty
void empty_deepCopyRecycleTest(){

    CharLinkedList test_list;
    CharLinkedList deepcopy_list = test_list;

    assert(deepcopy_list.isEmpty());
}

// Tests isEmpty if LL is nonempty
void nonempty_isEmptyTest(){

    CharLinkedList test_list('a');

    assert(not(test_list.isEmpty()));
}

// Tests isEmpty if LL is empty
void empty_isEmptytest(){

    CharLinkedList test_list;

    assert(test_list.isEmpty());
}

// Tests clear 
void clearTest(){

    CharLinkedList test_list('a');

    assert(not(test_list.isEmpty()));
    test_list.clear();
    assert(test_list.isEmpty());
}

// Tests size if LL is nonempty
void nonempty_sizeTest(){

    char arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(arr, 9);

    assert(test_list.size() == 9);
}

// Tests size if LL is empty
void empty_sizeTest(){

    CharLinkedList test_list;
    assert(test_list.size() == 0);
}

// Tests first if LL is nonempty
void nonempty_firstTest(){

    char arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(arr, 9);

    assert(test_list.first() == 'a');
}

// Tests first if LL is empty
void empty_firstTest(){

    bool runtime_error_thrown = false;
    std::string error_message = "";

    CharLinkedList test_list;
    try {
        test_list.first();
    }
    catch (const std::runtime_error &e) {
    runtime_error_thrown = true;
    error_message = e.what();
    }
    // Ensure error is thrown correctly
    assert(runtime_error_thrown);
    assert(error_message == "cannot get first of empty LinkedList");
}

// Tests first if LL is nonempty
void nonempty_lastTest(){

    char arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(arr, 9);

    assert(test_list.last() == 'h');
}

// Tests first if LL is empty
void empty_lastTest(){

    bool runtime_error_thrown = false;
    std::string error_message = "";

    CharLinkedList test_list;
    try {
        test_list.last();
    }
    catch (const std::runtime_error &e) {
    runtime_error_thrown = true;
    error_message = e.what();
    }
    // Ensure error is thrown correctly
    assert(runtime_error_thrown);
    assert(error_message == "cannot get last of empty LinkedList");
}

// Tests elementAt if expected input
void expected_elementAtTest(){

    char arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(arr, 9);

    for(int i = 0; i < 9; i++) assert(arr[i] == test_list.elementAt(i));
}

// Tests elementAt if LL is empty
void empty_elementAtTest(){

    // If empty AL
    bool range_error_thrown = false;
    std::string error_message = "";

    CharLinkedList test_list;
    try {
        test_list.elementAt(0);
    }
    catch (const std::range_error &e) {
    range_error_thrown = true;
    error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (0) not in range [0..0)");
}

// Tests elementAt if out of bounds index given
void oob_elementAtTest(){

    bool range_error_thrown = false;
    std::string error_message = "";

    CharLinkedList test_list('a');
    try {
        test_list.elementAt(-1);
    }
    catch (const std::range_error &e) {
    range_error_thrown = true;
    error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (-1) not in range [0..1)");
}

// Tests toString if LL is nonempty
void nonempty_toStringTest(){
    
    char arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(arr, 9);

    assert(test_list.toString() == "[CharLinkedList of size 9 <<abczdefgh>>]");
}

// Tests toString if LL is empty
void empty_toStringTest(){
    
    CharLinkedList test_list;

    assert(test_list.toString() == "[CharLinkedList of size 0 <<>>]");
}

// Tests toReverseString if LL is nonempty
void nonempty_toReverseStringTest(){

    char arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(arr, 9);

    assert(test_list.toReverseString() == 
    "[CharLinkedList of size 9 <<hgfedzcba>>]");
}

// Tests toReverseString if LL is nempty
void empty_toReverseStringTest(){

    CharLinkedList test_list;
    assert(test_list.toReverseString() == "[CharLinkedList of size 0 <<>>]");
}

// Tests pushAtBack if LL is nonempty
void nonempty_pushAtBackTest(){

    CharLinkedList test_list('d');
    test_list.pushAtBack('n');
    test_list.pushAtBack('a');

    assert(test_list.toString() == "[CharLinkedList of size 3 <<dna>>]");
}

// Tests pushAtBack if LL is empty
void empty_pushAtBackTest(){

    CharLinkedList test_list;
    test_list.pushAtBack('n');
    test_list.pushAtBack('a');

    assert(test_list.toString() == "[CharLinkedList of size 2 <<na>>]");
}

// Tests pushAtFront if LL is nonempty
void nonempty_pushAtFrontTest(){
    
    CharLinkedList test_list('d');
    test_list.pushAtFront('n');
    test_list.pushAtFront('a');

    assert(test_list.toString() == "[CharLinkedList of size 3 <<and>>]");
}

// Tests pushAtFront if LL is empty
void empty_pushAtFrontTest(){
    
    CharLinkedList empty_test_list;
    empty_test_list.pushAtFront('n');
    empty_test_list.pushAtFront('a');

    assert(empty_test_list.toString() == "[CharLinkedList of size 2 <<an>>]");
}

// Tests insertInOrder if char comes at front
void front_insertInOrderTest(){

    char arr[7] = { 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(arr, 7);
    test_list.insertInOrder('a');

    assert(test_list.toString() == "[CharLinkedList of size 8 <<abcdefgh>>]");
}

// Tests insertInOrder if char comes at back
void back_insertInOrderTest(){
    char arr[7] = { 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(arr, 7);
    test_list.insertInOrder('i');

    assert(test_list.toString() == "[CharLinkedList of size 8 <<bcdefghi>>]");
}

// Tests insertInOrder if char comes in the middle
void middle_insertInOrderTest(){
    char arr[6] = { 'b', 'c', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(arr, 6);
    test_list.insertInOrder('d');

    assert(test_list.toString() == "[CharLinkedList of size 7 <<bcdefgh>>]");
}

// Tests insertInOrder if char is a duplicate
void dupe_insertInOrderTest(){
    char arr[7] = { 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(arr, 7);
    test_list.insertInOrder('d');
    test_list.insertInOrder('d');

    assert(test_list.toString() == 
    "[CharLinkedList of size 9 <<bcdddefgh>>]");
}

// Tests popFromFront if LL is nonempty
void nonempty_popFromFrontTest(){

    // If LL is nonempty
    char arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(arr, 9);
    test_list.popFromFront();

    assert(test_list.toString() == "[CharLinkedList of size 8 <<bczdefgh>>]");
    for(int i = 0; i < 8; i++) test_list.popFromFront();
    assert(test_list.toString() == "[CharLinkedList of size 0 <<>>]");
}

// Tests popFromFront if LL is empty
void empty_popFromFrontTest(){

    bool runtime_error_thrown = false;
    std::string error_message = "";

    CharLinkedList test_list;
    try {
        test_list.popFromFront();
    }
    catch (const std::runtime_error &e) {
    runtime_error_thrown = true;
    error_message = e.what();
    }
    // Ensure error is thrown correctly
    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

// Tests popFromBack if LL is nonempty
void nonempty_popBackFrontTest(){

    // If LL is nonempty
    char arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(arr, 9);
    test_list.popFromBack();

    assert(test_list.toString() == "[CharLinkedList of size 8 <<abczdefg>>]");
    for(int i = 0; i < 8; i++) test_list.popFromBack();
    assert(test_list.toString() == "[CharLinkedList of size 0 <<>>]");
}

// Tests popFromBack if LL is empty
void empty_popFromBackTest(){

    bool runtime_error_thrown = false;
    std::string error_message = "";

    CharLinkedList test_list;
    try {
        test_list.popFromBack();
    }
    catch (const std::runtime_error &e) {
    runtime_error_thrown = true;
    error_message = e.what();
    }
    // Ensure error is thrown correctly
    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

// Tests removeAt if LL is nonempty
void nonempty_removeAtTest(){

    char arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(arr, 9);
    test_list.removeAt(0);

    assert(test_list.toString() == "[CharLinkedList of size 8 <<bczdefgh>>]");
    for(int i = 7; i >= 0; i--) test_list.removeAt(i);
    assert(test_list.toString() == "[CharLinkedList of size 0 <<>>]");
}

// Tests removeAt if LL is empty
void empty_removeAtTest(){

    bool range_error_thrown = false;
    std::string error_message = "";

    CharLinkedList test_list;
    try {
        test_list.removeAt(0);
    }
    catch (const std::range_error &e) {
    range_error_thrown = true;
    error_message = e.what();
    }
    // Ensure error is thrown correctly
    assert(range_error_thrown);
    assert(error_message == "index (0) not in range [0..0)");
}

// Tests replaceAt if LL is nonempty
void nonempty_replaceAtTest(){

    char arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(arr, 9);
    test_list.replaceAt('b', 0);

    assert(test_list.toString() == "[CharLinkedList of size 9 <<bbczdefgh>>]");
}

// Tests replaceAt if LL is empty
void empty_replaceAtTest(){

    bool range_error_thrown = false;
    std::string error_message = "";

    CharLinkedList empty_test_list;
    try {
        empty_test_list.replaceAt('b', 0);
    }
    catch (const std::range_error &e) {
    range_error_thrown = true;
    error_message = e.what();
    }
    // Ensure error is thrown correctly
    assert(range_error_thrown);
    assert(error_message == "index (0) not in range [0..0)");
}

// Tests concatenate if LL is nonempty
void nonempty_concatenateTest(){

    char arr[4] = { 'a', 'b', 'c', 'z'};
    CharLinkedList test_list(arr, 4);
    char concat_arr[5] = { 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList concat(concat_arr, 5);
    test_list.concatenate(&concat);
    assert(test_list.toString() == "[CharLinkedList of size 9 <<abczdefgh>>]");
}

// Tests concatenate if LL is empty
void empty_concatenateTest(){

    char arr[4] = { 'a', 'b', 'c', 'z'};
    CharLinkedList test_list(arr, 4);
    CharLinkedList empty_test_list;
    test_list.concatenate(&empty_test_list);

    assert(test_list.toString() == "[CharLinkedList of size 4 <<abcz>>]");
}

// Tests concatenate if LL is itself
void itself_concatenateTest(){

    char arr[4] = { 'a', 'b', 'c', 'z'};
    CharLinkedList test_list(arr, 4);
    test_list.concatenate(&test_list);

    assert(test_list.toString() == 
    "[CharLinkedList of size 8 <<abczabcz>>]");
}

// The following test functions work when the private functions and vars
// in CharArrayList.h are made public. They currently do not work and therefore 
// are commented out.

// // Tests Node creatiion
// void nodeCreationTest(){
//     Node *test = newNode('c', nullptr, nullptr);
//     assert(test->data == 'c');
//     assert(test->next == nullptr);
//     assert(test->prev == nullptr);
// }

// // Tests recycle if want to preserve front and back
// void preserve_recycleRecursive(){
//     CharLinkedList test_list;
//     test_list.recycleRecursive(front->next, back);
//     assert(test_list.front->data == '\0');
//     assert(test_list.back->data == '\0');
//
// }


// Tests correct insertion into an empty AL.
// Afterwards, size should be 1 and element at index 0
// should be the element we inserted.
void empty_correct_insertAtTest() { 

    CharLinkedList test_list;
    test_list.insertAt('a', 0);
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');

}

// Tests incorrect insertion into an empty AL.
// Attempts to call insertAt for index larger than 0.
// This should result in an std::range_error being raised.
void empty_incorrect_insertAtTest() {

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    // insertAt for out-of-range index
    test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
    // if insertAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    range_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0]");
    
}

// Tests correct insertAt for front of 1-element list.
void front_singleton_insertAtTest() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at front
    test_list.insertAt('b', 0);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'a');
    
}

// Tests correct insertAt for back of 1-element list.
void back_singleton_insertAtTest() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at back
    test_list.insertAt('b', 1);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    
}

// Tests calling insertAt for a large number of elements.
// Not only does this test insertAt, it also checks that
// array expansion works correctly.
void many_elements_insertAtTest() {
    
    CharLinkedList test_list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.insertAt('a', i);
    }

    assert(test_list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
    
}

// Tests insertion into front of a larger list
void front_large_insertAtTest() {
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    test_list.insertAt('y', 0);

    assert(test_list.size() == 10);
    assert(test_list.elementAt(0) == 'y');
    assert(test_list.toString() == 
    "[CharLinkedList of size 10 <<yabczdefgh>>]");

}

// Tests insertion into the back of a larger list
void back_large_insertAtTest() {

    char test_arr[10] = { 'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 10);  

    test_list.insertAt('x', 10);

    assert(test_list.size() == 11);
    assert(test_list.elementAt(10) == 'x');
    assert(test_list.toString() == 
    "[CharLinkedList of size 11 <<yabczdefghx>>]"); 

}

// Tests insertion into the middle of a larger list
void middle_large_insertAtTest() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.insertAt('z', 3);

    assert(test_list.size() == 9);
    assert(test_list.elementAt(3) == 'z');
    assert(test_list.toString() == "[CharLinkedList of size 9 <<abczdefgh>>]");
}

// Tests out-of-range insertion for a non-empty list.
void nonempty_incorrect_insertAtTest() {
   
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8]");
    
}

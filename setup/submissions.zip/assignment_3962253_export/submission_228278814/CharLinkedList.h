/*
 *  CharLinkedList.h
 *  Shayna Ssanyu
 *  31 January 2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  FILE PURPOSE HERE
 *
 */

#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H
#include <string>

class CharLinkedList {
    public:
    //constructors:
        CharLinkedList(); //default constructor
        CharLinkedList(char c); //constructor with one char input
        CharLinkedList(char arr[], int size); //constructor with
        // one char array input & the size of that array
        CharLinkedList(const CharLinkedList &other);
        //copy constructor from another CharLinkedList
        ~CharLinkedList(); //destructor

        CharLinkedList &operator=(const CharLinkedList &other);
        // above: assignment operator

    //functions:
        bool isEmpty() const; //checks if list is empty
        void clear(); // clears list
        int size() const; //returns the size of the list
        char first() const; //returns the element at 1st index
        char last() const; //returns the element at last index
        char elementAt(int index) const; //returns elem at given index
        std::string toString() const; //returns the list as a string
        std::string toReverseString() const; 
        // above returns the list as a string in reverse
        void pushAtBack(char c); //pushes given char to end of list
        void pushAtFront(char c); //pushes given char to start of list
        void insertAt(char c, int index); //inserts given char at given index
        void insertInOrder(char c); //inserts given char in ASCII order of list
        void popFromFront(); //removes the element at front of list
        void popFromBack(); //removes the element at end of list
        void removeAt(int index); //removes the element at the given index
        void replaceAt(char c, int index); //replaces the element at
        //the given index with the given char
        void concatenate(CharLinkedList *other); //concatenates two
        //lists by adding the "other" list to the end of the first.

    private:
        struct Node{
            char data; //the element held at list
            Node *next; //points to next node in chain
            Node *prev; //points to previous node in chain
            std::string toString(){
                return std::string(1, data);
                };
            //above returns the node as a string
        };

        Node *front; //points to front of list
        Node *back; //points to back of list
        int numItems; //keeps track of size of list
        
        Node *newNode();
        Node *newNode(char newData, Node *prevNode, Node *nextNode);

        void deleteRecursive(Node *curr);
        void reverseStringRecursive(Node* curr, std::stringstream& ss) const;
        char searchElementRecursive(Node *curr, int index) const; 
        //above is a private helper function for elementAt().
};

#endif
    

/*
 *  CharLinkedList.cpp
 *  Shayna Ssanyu 
 *  31 January 2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation-
 *  Time to get linked up in Fur
 *
 *  The purpose of this file is to implement
 *  the constructors/destructor and functions
 *  for the CharLinkedList class, a class 
 *  that allows the user to create a dynamic 
 *  list of chars made from nodes.
 *
 */

#include "CharLinkedList.h"
#include <sstream>
#include <stdexcept>

using namespace std;

// below are the Node constructors

//node default constructor
CharLinkedList::Node* CharLinkedList::newNode(){
    Node *newNode = new Node;
    newNode->prev = nullptr;
    newNode->next = nullptr;
    return newNode;
}

//node overloaded constructor
CharLinkedList::Node* CharLinkedList::newNode(char newData,
                         Node *prevNode, Node *nextNode){
    Node *newNode = new Node;
    newNode->data = newData;
    newNode->prev = prevNode;
    newNode->next = nextNode;
    return newNode;
}

// below are the constructors- default & overloaded- and the destructor

/*
 * name:      CharLinkedList default constructor
 * purpose:   initialize an empty CharLinkedList
 * arguments: none
 * returns:   none
 * effects:   none
 */
CharLinkedList::CharLinkedList(){
    numItems = 0;
    front = nullptr;
    back = nullptr;
}

/*
 * name:      CharLinkedList constructor with one parameter, a char
 * purpose:   initialize a CharLinkedList with one given char
 * arguments: char c
 * returns:   none
 * effects:   creates a list with one char item.
 */
CharLinkedList::CharLinkedList(char c){
    numItems = 1;
    front = newNode(c, nullptr, nullptr);
    back = front;
    //front->prev = nullptr;
    //front->next = nullptr;
}

/*
 * name:      CharLinkedList constructor from a given array
 * purpose:   initialize a linked list from an array of chars and a given size
 * arguments: char arr[], int size
 * returns:   none
 * effects:   creates a list with items from the given array.
 */
CharLinkedList::CharLinkedList(char arr[], int size){
    numItems = size;

    if(size == 0){
        front = nullptr;
        back = nullptr;
        return;
    }

    Node startNode = *newNode(arr[0], nullptr, nullptr);
    front = &startNode;
    back = nullptr;
    Node nodeArr[size]; 

    // initialize all nodes in chain after start node
    for(int i = 1; i < size; i++){
        nodeArr[i].data = arr[i];
        
        // link each node's previous node to that current node
        if(i == 1){
            nodeArr[i].prev = &startNode;
        }
        else{
            nodeArr[i].prev = &nodeArr[i-1];
        }

        // update the back node to the most current mode
        back = &nodeArr[i];
    }

    // update the "next" nodes of each node in chain
    for(int i = 0; i < size; i++){
        nodeArr[i].next = &nodeArr[i+1];
    }
}

/*
 * name:      CharLinkedList copy constructor
 * purpose:   the copy constructor copies the contents from another 
 *            CharLinkedList to this one.
 * arguments: a pointer to another charlinkedlist
 * returns:   none
 * effects:   creates a new list that has the same contents as given
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other){
    if(other.size() > 0){
        numItems = other.numItems;

        front = newNode(other.front->data, nullptr, nullptr);
        Node *newest = front;
        
        Node *curr = other.front->next;
        
        // now copy the rest of the elements until we hit nullptr
        while(curr != nullptr){
            newest->next = newNode(curr->data, newest, nullptr);
            newest = newest->next;
            curr = curr->next;
        }

        back = newest;
    }

    else{ //if other is empty, make this an empty list too
        numItems = 0;
        front = nullptr;
        back = nullptr;
    }
} 

/*
 * name:      CharLinkedList destructor
 * purpose:   delete the charlinkedlist to free memory
 * arguments: none
 * returns:   none
 * effects:   frees memory allocated by CharLinkedList instances
 */
CharLinkedList::~CharLinkedList(){
    
}
 
 /*
 * name:      CharLinkedList destructor helper
 * purpose:   delete the charlinkedlist to free memory recursively
 * arguments: none
 * returns:   none
 * effects:   frees memory allocated by CharLinkedList instances
 */
void CharLinkedList::deleteRecursive(Node *curr){
    if(curr == nullptr){
        return;
    }
    else{
        delete curr;
        deleteRecursive(curr->next);
    }
}

CharLinkedList& CharLinkedList::operator=(const CharLinkedList &other){
    Node *curr = other.front;
    while(curr != nullptr){
        pushAtBack(curr->data);
        curr = curr->next;
    }
    return *this;
}

// below are the functions

/*
 * name:      isEmpty
 * purpose:   determines if the CharLinkedList is empty (has no nodes)
 * arguments: none
 * returns:   true if CharLinkedList contains no nodes, false otherwise
 * effects:   none
 */
bool CharLinkedList::isEmpty() const{
    if(numItems == 0){
        return true;
    }
    else{
        return false;
    }
}

/*
 * name:      size
 * purpose:   finds the size of a list by getting the number of items.
 * arguments: none
 * returns:   the size of the list
 * effects:   none
 */
int CharLinkedList::size() const{
    return numItems;
}

/*
 * name:      clear
 * purpose:   finds the size of a list by getting the number of items.
 * arguments: none
 * returns:   the size of the list
 * effects:   none
 */
void CharLinkedList::clear(){
    if(size() > 0){
        numItems = 0;
        Node* curr = front;
        while(curr != nullptr){
            Node* newest = curr->next;
            delete curr;
            curr = newest;
        }
        front = nullptr;
        back = nullptr;
    }
}

/*
 * name:      first
 * purpose:   finds the first element of a linked list.
 * arguments: none
 * returns:   the first element of the list
 * effects:   none
 */
char CharLinkedList::first() const{
    if(isEmpty()){
        throw std::runtime_error("cannot get first of empty LinkedList");
    }
    else{
        return front->data;
    }
}

/*
 * name:      last
 * purpose:   finds the last element of a linked list.
 * arguments: none
 * returns:   the last element of the list
 * effects:   none
 */
char CharLinkedList::last() const{
    if(isEmpty()){
        throw std::runtime_error("cannot get last of empty LinkedList");
    }
    else{
        return back->data;
    }
}

/*
 * name:      elementAt
 * purpose:   finds the element at a specified index of the list.
 * arguments: an index
 * returns:   the element at that index
 * effects:   none
 */
char CharLinkedList::elementAt(int index) const{
    if(index < 0 or index >= numItems){
        throw std::range_error("index (" + std::to_string(index) +
         ") not in range [0.." + std::to_string(numItems) + ")");
    }
    else{
        return searchElementRecursive(front, index);
    }
}

/*
 * name:      searchElementRecursive
 * purpose:   uses a recursive method call to find the element
 *            at index.
 * arguments: a pointer to a given node, an index
 * returns:   the element at that index
 * effects:   none
 */
char CharLinkedList::searchElementRecursive(Node *curr,
                                     int index) const{
    if(index == 0){
        return curr->data;
    }
    else{
        return searchElementRecursive(curr->next, (index-1));
    }
}

/*
 * name:      toString
 * purpose:   creates a string of a linked list from given list
 * arguments: none
 * returns:   the string version of the list
 * effects:   none
 */
std::string CharLinkedList::toString() const{
    std::stringstream ss;
    if(isEmpty()){
        ss << "[CharLinkedList of size 0 <<>>]";
    }
    else{
        ss << "[CharLinkedList of size " << size() << " <<";

        Node *curr = this->front;
        while(curr != nullptr){
            ss << curr->data;
            if(curr->next != nullptr){
                ss << ",";
            }
            curr = curr->next;
        }
    ss << ">>]";
    }

    return ss.str();
}

/*
 * name:      reverseStringRecursive
 * purpose:   uses a recursive method call to make a new string
 *            that is the elements of a list in reverse.
 * arguments: a pointer to a given node, a given string from 
 *            the non-recurseve toReverseString
 * returns:   none
 * effects:   none
 */
void CharLinkedList::reverseStringRecursive(Node* curr,
                         std::stringstream& ss) const{
    if(curr != nullptr){
        ss << curr->data;
        reverseStringRecursive(curr->prev, ss);
    }
}

/*
 * name:      toReverseString
 * purpose:   returns all the list's elements in reverse by
 *            calling the recursive helper function.
 * arguments: none
 * returns:   the list in reverse (in string form)
 * effects:   none
 */
std::string CharLinkedList::toReverseString() const{
    std::stringstream ss2;
    ss2 << "[CharLinkedList of size " << size() << " <<";
    if(size() > 0){
        reverseStringRecursive(back, ss2);
    }
    ss2 << ">>]";
    
    return ss2.str();
}

/*
 * name:      push at back
 * purpose:   adds a given character to the end of the list.

 * arguments: one char
 * returns:   none
 * effects:   adds a new element to end of list
 */
void CharLinkedList::pushAtBack(char c){
    if(isEmpty()){
        front = newNode(c, nullptr, nullptr);
        back = front;
        numItems = 1;
    }
    else{
        back->next = newNode(c, back, nullptr);
        back = back->next;
        numItems++;
    }
}

/*
 * name:      push at front
 * purpose:   adds a given character to the beginning of the list.
 * arguments: one char
 * returns:   none
 * effects:   adds a new element to start of list
 */
void CharLinkedList::pushAtFront(char c){
    if(isEmpty()){
        front = newNode(c, nullptr, nullptr);
        back = front;
        numItems = 1;
    }
    else{
        front->prev = newNode(c, nullptr, front);
        front = front->prev;
        numItems++;
    }
}

/*
 * name:      insert at 
 * purpose:   inserts a given character at a given index in the list 
 *            by rerouting the nodes' pointers,
 * arguments: one char and one index
 * returns:   none
 * effects:   adds the char at specified index
 */
void CharLinkedList::insertAt(char c, int index){
    if(index < 0 or index > numItems){
        throw std::range_error("index (" + std::to_string(index) +
            ") not in range [0.." + std::to_string(numItems) + "]");
    }
    else if(index == 0){
        pushAtFront(c);
    } 
    else if(index == numItems){
        pushAtBack(c);
    } 
    
    else{
        Node* curr = front;
        for(int i = 0; i < index; i++){
            curr = curr->next;
        }
        Node* newest = newNode(c, curr->prev, curr);
        curr->prev->next = newest;
        curr->prev = newest;
        
        numItems++;
    }
}

/*
 * name:      insert in order
 * purpose:   inserts the given char in ASCII order into an 
 *            already-sorted list of chars.  
 * arguments: one char
 * returns:   none
 * effects:   inserts the char in ASCII order into the list
 */
void CharLinkedList::insertInOrder(char c){
    if (isEmpty()){
        pushAtFront(c);
        return;
    }
    else if(c <= front->data){
        pushAtFront(c);
        return;
    }
    else{
        Node* curr = front;
        while((curr->next != nullptr) and (curr->next->data < c)){
            curr = curr->next;
        }

        Node* newest = newNode(c, curr, curr->next);
        if(curr->next != nullptr){
            curr->next->prev = newest;
        } 
        else{
            back = newest;
        }
        curr->next = newest;
        numItems++;
    }
}

/*
 * name:      pop (remove) from front
 * purpose:   removes the item at the front of the list.
 * arguments: none
 * returns:   none
 * effects:   removes the item at the front of the list
 */
void CharLinkedList::popFromFront(){
    if(isEmpty()){
        throw std::runtime_error("cannot pop from empty LinkedList");
    }

    else{
        Node* front_holder = front;
        front = front->next;
        front->prev = nullptr;
        numItems--;
        delete front_holder;
    }
}

/*
 * name:      pop (remove) from end
 * purpose:   removes the item at the end of the list.
 * arguments: none
 * returns:   none
 * effects:   removes the item at the end of the list
 */
void CharLinkedList::popFromBack(){
    if(isEmpty()){
        throw std::runtime_error("cannot pop from empty LinkedList");
    }
    else{
        Node* back_holder = back;
        back = back->prev;
        back->next = nullptr;
        numItems--;
        delete back_holder;
    }
}

/*
 * name:      remove at
 * purpose:   removes the element at a given index.
 * arguments: an int (index)
 * returns:   none
 * effects:   none
 */
void CharLinkedList::removeAt(int index){
    if(index < 0 or index >= numItems){
        throw std::range_error("index (" + std::to_string(index) +
                ") not in range [0.." + std::to_string(numItems) + ")");
    }

    else{
        if(index == 0){
            popFromFront();
        } 
        else if(index == numItems - 1){
            popFromBack();
        }
        else{
            Node* curr = front;
            for(int i = 0; i < index; i++){
                curr = curr->next;
            }

            Node* holder = curr;
            curr->prev->next = curr->next;
            curr->next->prev = curr->prev;
            numItems--;
            delete holder;
        }
    }
}

/*
 * name:      replace at
 * purpose:   replaces the char at a given index with a new given char.
 * arguments: a char, and index
 * returns:   none
 * effects:   replaces the char at a given index with a new given char.
 */
void CharLinkedList::replaceAt(char c, int index){
    if(index < 0 or index >= numItems){
        throw std::range_error("index (" + std::to_string(index) +
            ") not in range [0.." + std::to_string(numItems) + ")");
    }
    else{
        Node* curr = front;
        for(int i = 0; i < index; i++){
            curr = curr->next;
        }
        curr->data = c;
    }
}

/*
 * name:      concatenate
 * purpose:   adds the contents of another CharLinkedList 
 *            to the end of the current one.
 * arguments: other linked list
 * returns:   none
 * effects:   adds the 2nd list to end of 1st.
 */
void CharLinkedList::concatenate(CharLinkedList *other){
    if(other->isEmpty()) {
        return;
    }
    if (isEmpty()) {
        front = other->front;
        back = other->back;
    } 
    else{
        back->next = other->front;
        if(other->front != nullptr){
            other->front->prev = back;
        }
        back = other->back;
    }
    numItems += other->size();
    
    //delete other;
    //other->front = nullptr;
   // other->back = nullptr;
    //other->numItems = 0;

}
/*
 *  unit_tests.h
 *  Shayna Ssanyu
 *  31 January 2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation-Time to linked up in Fur
 *
 *  FILE PURPOSE HERE
 *
 */

#include "CharLinkedList.h"
#include <cassert>

// tests if unit tests are implemented properly
void dummyTest(){
    bool a = true;
    bool b = a;
    assert(b);
}

// tests if the default constructor is working properly
void constructor_test_1(){
    CharLinkedList list1;
}

// tests if the 2nd constructor is working by putting in
// one char into the list and checking to see if the size
// is actually one
void constructor_test_2(){
    char test_char = 's';
    CharLinkedList list1(test_char);
    assert(list1.size() == 1);
}

// tests if the 3rd constructor is working by 
// inputting an array of chars and the size of the array.
// the size of the list should be 5.
void constructor_test_3(){
    char test_arr[5] = {'a','b','c','d','e'};
    CharLinkedList list1(test_arr, 5);
    assert(list1.size() == 5);
}

// tests if the copy constructor is working by making
// a charlinkedlist and calling the copy constructor
// to make a duplicated list.
/*void copy_constructor_test(){
    char test_arr[5] = {'a','b','c','d','e'};
    CharLinkedList list1(test_arr, 5);
    CharLinkedList list2(list1);
}*/

// tests if isEmpty() is returning true when a list has no items
void isempty_test_true(){
    CharLinkedList list1;
    assert(list1.isEmpty());
}

// tests if isEmpty() is returning false when a list has items
void isempty_test_false(){
    char test_char = 's';
    CharLinkedList list1(test_char);
    assert(list1.size() > 0);
}

// tests the size() function when the list is empty
void size_test_empty(){
    CharLinkedList list1;
    assert(list1.size() == 0);
}

// tests the size() function with 1 element
void size_test_nonempty(){
    char test_char = 's';
    CharLinkedList list1(test_char);
    assert(list1.size() == 1);
}

void clear_test(){
    char test_char = 's';
    CharLinkedList list1(test_char);
    list1.clear();
    assert(list1.isEmpty());
}

// tests the first() function on a list with no elements
// should throw error
void first_test_empty(){
    try{
        CharLinkedList list1;
        list1.first();
        // if no exception thrown, failed
    } 
    catch(const std::runtime_error &e){
        std::string error = e.what();
        assert(error == "cannot get first of empty LinkedList");
    }
}

// tests the first() function on a list with one element
void first_test_oneelement(){
    char test_char = 's';
    CharLinkedList list1(test_char);
    assert(list1.first() == 's');
}

// tests the first() function on a list with several elements
void first_test_severalelements(){
    char test_arr[5] = {'a','b','c','d','e'};
    CharLinkedList list1(test_arr, 5);
    assert(list1.first() == 'a');
}

// tests the last() function on a list with no elements
// should throw error
void last_test_empty(){
    try{
        CharLinkedList list1;
        list1.last();
        // if no exception thrown, failed
    } 
    catch(const std::runtime_error &e){
        std::string error = e.what();
        assert(error == "cannot get last of empty LinkedList");
    }
}
// tests the last() function on a list with one element
void last_test_oneelement(){
    char test_char = 's';
    CharLinkedList list1(test_char);
    assert(list1.last() == 's');
}

// tests the last() function on a list with several elements
void last_test_severalelements(){
    char test_arr[5] = {'a','b','c','d','e'};
    CharLinkedList list1(test_arr, 5);
    assert(list1.last() == 'e');
}

// tests the elementAt function on an invalid index
// should throw a range error
void elementAt_test_invalid(){
    char test_arr[5] = {'a','b','c','d','e'};
    CharLinkedList list1(test_arr, 5);
    try{
        list1.elementAt(500);
    } 
    catch(const std::range_error &e){
        assert(std::string(e.what()) == "index (500) not in range [0..5)");
    }
}

// tests the elementAt function on 1 element list
// should only work for the index of that 1 element
void elementAt_test_1element(){
    char test_char = 's';
    CharLinkedList list1(test_char);
    assert(list1.elementAt(0) == 's');
}

// tests the elementAt function on several element list front
void elementAt_test_several_front(){
    char test_arr[5] = {'a','b','c','d','e'};
    CharLinkedList list1(test_arr, 5);
    assert(list1.elementAt(0) == 'a');
}

// tests the elementAt function on several element list middle
void elementAt_test_several_middle(){
    char test_arr[5] = {'a','b','c','d','e'};
    CharLinkedList list1(test_arr, 5);
    assert(list1.elementAt(2) == 'c');
}

// tests the elementAt function on several element list back
void elementAt_test_several_back(){
    char test_arr[5] = {'a','b','c','d','e'};
    CharLinkedList list1(test_arr, 5);
    assert(list1.elementAt(4) == 'e');
}

// tests the toString function on empty list
void toString_test_empty(){
    CharLinkedList list1;
    assert(list1.toString() == "[]");
}

// tests the toString function on one element list
void toString_test_1element(){
    char test_char = 's';
    CharLinkedList list1(test_char);
    assert(list1.toString() == "[s]");
}

// tests the toString function on several element list
void toString_test_several(){
    char test_arr[5] = {'a','b','c','d','e'};
    CharLinkedList list1(test_arr, 5);
    assert(list1.toString() == "[a,b,c,d,e]");
}

// tests the toReverseString function on empty list
void toReverseString_test_empty(){
    CharLinkedList list1;
    assert(list1.toReverseString() == "[]");
}

// tests the toReverseString function on one element list
void toReverseString_test_1element(){
    char test_char = 's';
    CharLinkedList list1(test_char);
    assert(list1.toReverseString() == "[s]");
}

// tests the toReverseString function on several element list
void toReverseString_test_several(){
    char test_arr[5] = {'a','b','c','d','e'};
    CharLinkedList list1(test_arr, 5);
    assert(list1.toReverseString() == "[e,d,c,b,a]");
}

// this tests the pushAtBack() function on an empty list.
// this should push the given element 
// into the first space of the list,
// this elementAt(0) should be 's'.
void pushAtBack_test_empty(){
    CharLinkedList list1;
    list1.pushAtBack('s');
    assert(list1.elementAt(0) == 's');
}

// this tests the pushAtBack() function on a non-empty list.
// this should put the given char at the end of the list.
// thus, the last element should be the newly added one when 
// elementAt([lastindex]) is called.
void pushAtBack_test_nonempty(){
    int given_size = 5;
    char given_array[5] = {'h', 'e', 'l', 'l', 'o'};

    CharLinkedList list1(given_array, given_size);
    list1.pushAtBack('s');

    assert(list1.elementAt(5) == 's');
}

// this tests the pushAtFront() function on an empty list.
// this should push the given element into the first space of the list.
void pushAtFront_test_empty(){
    CharLinkedList list;
    list.pushAtFront('s');
    assert(list.elementAt(0) == 's');
}

// this tests the pushAtFront() function on a non-empty list.
// this should push the given element into the first place of the list
// and shift the rest of the elements down one place.
// thus, the first element should be the newly added one when 
// elementAt([lastindex]) is called.
void pushAtFront_test_nonempty(){
    int given_size = 5;
    char given_array[5] = {'h', 'e', 'l', 'l', 'o'};
    CharLinkedList list(given_array, given_size);
    list.pushAtFront('s');

    assert(list.elementAt(0) == 's');
}

// this inserts a char into an empty list.
void insert_in_order_empty(){
    CharLinkedList list;
    list.insertInOrder('s');
    assert(list.elementAt(0) == 's');
}

// this inserts an alphabet char in ASCII order into its correct place
// in the already-sorted list.
void insert_in_order_alpha(){
    int given_size = 5;
    char given_array[5] = {'a', 'b', 'd', 'e', 'f'};
    CharLinkedList list(given_array, given_size);
    list.insertInOrder('c');
    assert(list.elementAt(2) == 'c');
}

// this inserts a numeric char in ASCII order into its correct place
// in the already-sorted list.
void insert_in_order_numeric(){
    int given_size = 5;
    char given_arr[5] = {'1', '2', '4', '5', '6'};
    CharLinkedList list(given_arr, given_size);
    list.insertInOrder('3');
    assert(list.elementAt(2) == '3');
}

// this attempts to remove the first element of an empty list and
// this should throw a runtime error.
void pop_from_front_empty(){
    CharLinkedList list;
    try {
        list.popFromFront();
    } 
    catch(const std::runtime_error &e){
        assert(std::string(e.what()) == "cannot pop from empty ArrayList");
    }
}

// this tests the popFromFront() function on a non-empty list and
// thus should remove the first element of the list and shift the
// subsequent elements back one.
void pop_from_front_correct(){
    int given_size = 5;
    char given_array[5] = {'h', 'e', 'l', 'l', 'o'};
    CharLinkedList list(given_array, given_size);
    list.popFromFront();
    assert(list.elementAt(0) == 'e');
}

// this attempts to remove the last element of an empty list and
// this should throw a runtime exception.
void pop_from_back_empty(){
    CharLinkedList list;
    try {
        list.popFromBack();
    } 
    catch(const std::runtime_error &e){
        assert(std::string(e.what()) == "cannot pop from empty ArrayList");
    }
}

// this tests the popFromBack() function on a non-empty list and
// thus should remove the last element of the list.
void pop_from_back_correct(){
    int given_size = 5;
    char given_array[5] = {'h', 'e', 'l', 'l', 'o'};
    CharLinkedList list(given_array, given_size);
    list.popFromBack();
    assert(list.elementAt(1) == 'l');
}

// this attempts to remove an element at an index greater
// or less than the allowable indices, and thus should throw 
// a range error.
void remove_at_outofbounds(){
    int given_size = 5;
    char given_array[5] = {'h', 'e', 'l', 'l', 'o'};
    CharLinkedList list(given_array, given_size);
    try {
        list.removeAt(600);
    }
    catch(const std::range_error &e){
        assert(std::string(e.what()) == "index (600) not in range [0..4]");
    }
}

// this tests the removeAt() function with a correct index within
// bounds and thus should remove the element at that index and
// shift the other elements.
void remove_at_correct(){
    int given_size = 5;
    char given_array[5] = {'h', 'e', 'l', 'l', 'o'};
    CharLinkedList list(given_array, given_size);
    list.removeAt(1);
    assert(list.elementAt(1) == 'l');
}

// this tests the removeAt() function with a correct index within
// bounds in a CharLinkedList with only one element. Therefore,
// if isEmpty() is called after removing the one element, it should
// return true.
void remove_at_one_element(){
    CharLinkedList list('s');
    list.removeAt(0);
    // After removeAt, the list should be empty
    assert(list.isEmpty());
}

// this attempts to replace an element at an index greater
// or less than the allowable indices, and thus should throw 
// a range error.
void replace_at_outofbounds(){
    int given_size = 5;
    char given_array[5] = {'h', 'e', 'l', 'l', 'o'};
    CharLinkedList list(given_array, given_size);
    try {
        list.replaceAt('s', 600);
    }
    catch(const std::range_error &e){
        assert(std::string(e.what()) == "index (600) not in range [0..4]");
    }
}

// this tests the replaceAt() function with a correct index within
// bounds, and thus should replace the element at the given index
// with the new given element.
void replace_at_correct(){
    int given_size = 5;
    char given_array[5] = {'h', 'e', 'l', 'l', 'o'};
    CharLinkedList list(given_array, given_size);
    list.replaceAt('a', 1);
    assert(list.elementAt(1) == 'a');
}

// this should concatenate two non-empty lists together, with
// the contents of the second list coming after the contents of the
// first list in the final larger list.
void concatenate_lists(){
    int first_size = 5;
    char first_array[5] = {'h', 'e', 'l', 'l', 'o'};
    CharLinkedList first_list(first_array, first_size);

    int second_size = 1;
    char second_array[1] = {'s'};
    CharLinkedList second_list(second_array, second_size);

    first_list.concatenate(&second_list);
    assert(first_list.elementAt(first_size) == 's');
}

// SAMPLE CS15 UNIT TESTS BELOW USING INSERTAT()

/* To give an example of thorough testing, we are providing
 * the unit tests below which test the insertAt function. Notice: we have
 * tried to consider all of the different cases insertAt may be
 * called in, and we test insertAt in conjunction with other functions!
 *
 * You should emulate this approach for all functions you define.
 */


// Tests correct insertion into an empty AL.
// Afterwards, size should be 1 and element at index 0
// should be the element we inserted.
void insertAt_empty_correct() {
    CharLinkedList test_list;
    test_list.insertAt('a', 0);
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');
}

// Tests incorrect insertion into an empty AL.
// Attempts to call insertAt for index larger than 0.
// This should result in an std::range_error being raised.
void insertAt_empty_incorrect() {
    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
        // insertAt for out-of-range index
        test_list.insertAt('a', 42);
    }
    catch(const std::range_error &e){
        // if insertAt is correctly implemented, a range_error will be thrown,
        // and we will end up here
        range_error_thrown = true;
        error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0]");
}

// Tests correct insertAt for front of 1-element list.
void insertAt_front_singleton_list() {
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at front
    test_list.insertAt('b', 0);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'a');
}

// Tests correct insertAt for back of 1-element list.
void insertAt_back_singleton_list() {
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at back
    test_list.insertAt('b', 1);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
}

// Tests calling insertAt for a large number of elements.
// Not only does this test insertAt, it also checks that
// array expansion works correctly.
void insertAt_many_elements() {
    CharLinkedList test_list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.insertAt('a', i);
    }

    assert(test_list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
}

// Tests insertion into front of a larger list
void insertAt_front_large_list() {
    char test_arr[9] = {'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(test_arr, 9);

    test_list.insertAt('y', 0);

    assert(test_list.size() == 10);
    assert(test_list.elementAt(0) == 'y');
    assert(test_list.toString() ==
    "[CharLinkedList of size 10 <<yabczdefgh>>]");
}

// Tests insertion into the back of a larger list
void insertAt_back_large_list() {
    char test_arr[10] = {'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(test_arr, 10);

    test_list.insertAt('x', 10);

    assert(test_list.size() == 11);
    assert(test_list.elementAt(10) == 'x');
    assert(test_list.toString() ==
           "[CharLinkedList of size 11 <<yabczdefghx>>]");
}

// Tests insertion into the middle of a larger list
void insertAt_middle_large_list() {
    char test_arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(test_arr, 8);

    test_list.insertAt('z', 3);

    assert(test_list.size() == 9);
    assert(test_list.elementAt(3) == 'z');
    assert(test_list.toString() == "[CharLinkedList of size 9 <<abczdefgh>>]");
}

// Tests out-of-range insertion for a non-empty list.
void insertAt_nonempty_incorrect() {
    char test_arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.insertAt('a', 42);
    } catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8]");
}
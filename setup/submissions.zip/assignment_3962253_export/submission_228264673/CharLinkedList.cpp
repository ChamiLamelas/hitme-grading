/*
 *  CharLinkedList.cpp
 *  Jonah Rudin
 *  2/1
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Implement a linked list ADT that contains a multitude of functions
 * No know bugs
 */

#include "CharLinkedList.h"

/*
 * name:      CharLinkedList
 * purpose:   construct empty char linked list
 * arguments: none
 * returns:   none
 * effects:   constructs instance of class
 */
CharLinkedList::CharLinkedList(){
    front = nullptr;
    lsize = 0;
}

/*
 * name:      CharLinkedList
 * purpose:   construct char list w one char
 * arguments: char
 * returns:   none
 * effects:   constructs instance of class one char
 */
CharLinkedList::CharLinkedList(char c){
    front = new Node;
    lsize = 1;
    front->info = c;
    front->next = nullptr;
    front->prior = nullptr;
}

/*
 * name:      CharLinkedList
 * purpose:   construct char list from an array
 * arguments: arr and size
 * returns:   none
 * effects:   constructs instance of class w containing chars
 */
CharLinkedList::CharLinkedList(char arr[], int size){
    if(size != 0){
        front = new Node;
        front->prior = nullptr;
        front->next = nullptr;
        front->info = arr[0];
        lsize = 1;
        Node *tmp = front;
        for(int i = 1; i < size; i++){
            newnode(arr[i], tmp);
            tmp = tmp->next;
        }
    }
    else{
        front = nullptr;
        lsize = 0;
    }
}

/*
 * name:      CharLinkedList
 * purpose:   construct char list from another list
 * arguments: char
 * returns:   none
 * effects:   constructs instance of class from other class
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other){
    if(other.lsize != 0){
        front = new Node;
        front->prior = nullptr;
        front->next = nullptr;
        front->info = other.front->info;
        lsize = 1;
        Node *tmp = other.front;
        int bound = other.size();
        for(int i = 1; i < bound; i++){
            newnode(tmp->next->info, tmp);
            tmp = tmp->next;
        }
    }
    else{
        front = nullptr;
        lsize = 0;
    }
}

/*
 * name:      ~CharLinkedlist
 * purpose:   deconsturcts  char list
 * arguments: none
 * returns:   none
 * effects:   uses helper recursive function to deconstruct instance of class
 */
CharLinkedList::~CharLinkedList(){
    deconstructer(front);
}

/*
 * name:      operator
 * purpose:   copy other linked list
 * arguments: linked list
 * returns:   cll addy
 * effects:   copies a link list to a new location and returns the address
 */
CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other){
    deconstructer(front);
    front = new Node;
    front->prior = nullptr;
    front->next = nullptr;
    front->info = other.front->info;
    lsize = 1;
    Node *tmp = other.front;
    int bound = other.size();
    for(int i = 1; i < bound; i++){
        newnode(tmp->next->info, tmp);
        tmp = tmp->next;
    }
    return *this;
}

/*
 * name:      isempty
 * purpose:   checks if list is empy
 * arguments: none
 * returns:   bool
 * effects:   returns a bool indicating whether empty or not
 */
bool CharLinkedList::isEmpty() const{
    return lsize == 0;
}

/*
 * name:      clear
 * purpose:   clears existing list
 * arguments: char
 * returns:   none
 * effects:   gets rid of all data in a list
 */
void CharLinkedList::clear(){
    deconstructer(front);
    front = new Node;
    int lsize = 0;
    front->next = nullptr;
    front->prior = nullptr;
}

/*
 * name:      size
 * purpose:   returns the size of the list
 * arguments: none
 * returns:   int
 * effects:   returns int thats size
 */
int CharLinkedList::size() const{
    return lsize;
}

/*
 * name:      first
 * purpose:   returns first char in list
 * arguments: none
 * returns:   char
 * effects:   gives first char in list or throws message
 */
char CharLinkedList::first() const{
    if(lsize == 0){
        throw runtime_error("cannot get first of empty LinkedList");
    }
    else{
        return front->info;
    }
}

/*
 * name:      last
 * purpose:   returns last char in list
 * arguments: none
 * returns:   char
 * effects:   gives last char in list or throws message
 */
char CharLinkedList::last() const{
    if(lsize == 0){

        throw runtime_error("cannot get last of empty LinkedList");
    }
    else{
        Node *tmp = recursiveHelp(front, lsize - 1); // uses recursive func
        return tmp->info;
    }
}

/*
 * name:      elementAt
 * purpose:   gives element at a given index
 * arguments: index
 * returns:   char
 * effects:   gives element at index or throws message
 */
char CharLinkedList::elementAt(int index) const{
    if(index >= lsize or index < 0){
        throw range_error("index (" + to_string(index)+ 
        ") not in range [0.." + to_string(lsize) + ")");
    }
    Node *tmp = recursiveHelp(front, index);
    return tmp->info;
}

/*
 * name:      toString
 * purpose:   return std string with message and content of
 * arguments: char
 * returns:   string
 * effects:   returns std string with message and content of
 */
std::string CharLinkedList::toString() const{
    std::stringstream ss;
    ss << "[CharLinkedList of size " << lsize << " <<";
    Node *tmp = front;
    for(int i = 0; i < lsize; i++){
        ss << tmp->info;
        tmp = tmp->next;
    }
    ss << ">>]";
    return ss.str();
}

/*
 * name:      toReverseString
 * purpose:   return std string with message and content of
 * in reverse
 * arguments: char
 * returns:   string
 * effects:   returns std string with message and content of
 * in reverse
 */
std::string CharLinkedList::toReverseString() const{
    std::stringstream ss;
    ss << "[CharLinkedList of size " << lsize << " <<";
    if(lsize != 0){
        Node *end = recursiveHelp(front, lsize - 1); // same recursive function
        for(int i = 0; i < lsize; i++){
            ss << end->info;
            end = end->prior;
        }
    }
    ss << ">>]";
    return ss.str();
}

/*
 * name:      pushAtBack
 * purpose:   adds new node to end
 * arguments: char
 * returns:   none
 * effects:   adds new node to end
 */
void CharLinkedList::pushAtBack(char c){
    if(lsize != 0){
        Node *end = recursiveHelp(front, lsize - 1);
        newnode(c, end); // same func for most inserts
    }
    else{
        newnode(c, nullptr);
    }
}

/*
 * name:      pushAtFront
 * purpose:   adds node at front
 * arguments: char
 * returns:   none
 * effects:   adds node at front
 */
void CharLinkedList::pushAtFront(char c){
    newnode(c, nullptr);
}

/*
 * name:      insertAt
 * purpose:   adds node at given index
 * arguments: char and index
 * returns:   none
 * effects:   adds node at given index or throws message
 */
void CharLinkedList::insertAt(char c, int index){
    if(index < 0 or index > lsize){
        throw range_error("index (" + to_string(index)+ 
        ") not in range [0.." + to_string(lsize) + "]");
    }
    else{
        if(lsize == 0 or index == 0){
            newnode(c, nullptr);
        }
        else{
            Node *spot = recursiveHelp(front, index - 1);
            newnode(c, spot);
        }
    }
}

/*
 * name:      insertInOrder
 * purpose:   inserts a char in ASCII order assuming list is
 * in order
 * arguments: char
 * returns:   none
 * effects:   =inserts char in ASCII
 */
void CharLinkedList::insertInOrder(char c){
    Node *tmp = front;
    if(c <= front->info){
        newnode(c, nullptr);
    }
    else{
        tmp = tmp->next;
        while(c >= tmp->info and tmp->next != nullptr){ 
            tmp = tmp->next;
        } // if it gets to end needs to decide where
        if(tmp->next != nullptr){
            newnode(c, tmp->prior);
        }
        else if(tmp->info >= c){
            newnode(c, tmp->prior);
        }
        else if(tmp->info < c){
            newnode(c, tmp);
        }
    }
}

/*
 * name:      popFromFront
 * purpose:   removes first element
 * arguments: none
 * returns:   none
 * effects:   removes first element and decreases lsize
 */
void CharLinkedList::popFromFront(){
     if(lsize == 0){
        throw runtime_error("cannot pop from empty LinkedList");
    }
    else{
        Node *tmp = front->next;
        delete front;
        front = tmp;
        lsize -= 1;
    }
}

/*
 * name:      popFromBack
 * purpose:   removes last element
 * arguments: none
 * returns:   none
 * effects:   removes last element and decreases lsize
 */
void CharLinkedList::popFromBack(){
     if(lsize == 0){
        throw runtime_error("cannot pop from empty LinkedList");
    }
    else{
        Node *end = recursiveHelp(front, lsize - 1);
        end->prior->next = nullptr;
        delete end;
        lsize -= 1;
    }
}

/*
 * name:      removeAt
 * purpose:   removes indexed element
 * arguments: none
 * returns:   none
 * effects:   removes indexed element and decreases lsize or throw message
 */
void CharLinkedList::removeAt(int index){
    if(index >= lsize or index < 0){
        throw range_error("index (" + to_string(index)+ 
        ") not in range [0.." + to_string(lsize) + ")");
    }
    else{
        Node *deleting = recursiveHelp(front, index);
        deleting->prior->next = deleting->next; //this line and following 
        deleting->next->prior = deleting->prior; // redirect the pointers
        delete deleting;
        lsize -= 1;
    }
}

/*
 * name:      replaceAt
 * purpose:   replace indexed element
 * arguments: none
 * returns:   none
 * effects:   replace index element or throw message
 */
void CharLinkedList::replaceAt(char c, int index){
    if(index >= lsize or index < 0){
        throw range_error("index (" + to_string(index)+ 
        ") not in range [0.." + to_string(lsize) + ")");
    }
    else{
        Node *replace = recursiveHelp(front, index);
        replace->info = c;
    }
}

/*
 * name:      concatenate
 * purpose:   adds other list to end of list
 * arguments: other 
 * returns:   none
 * effects:   adds the other list to the end of the first
 */
void CharLinkedList::concatenate(CharLinkedList *other){
    Node *tmp = other->front;
    int bound = other->lsize;
    for(int i = 0; i < bound; i++){
        pushAtBack(tmp->info);
        tmp = tmp->next;
    }
}

/*
 * name:      newnode
 * purpose:   private helper function to make others easier
 * arguments: char and previous node
 * returns:   none
 * effects:   adds an array after the previous in arg and updates accordinngly
 */
void CharLinkedList::newnode(char c, Node *previous){
    Node *created = new Node;
    created->info = c;
    created->next = nullptr;
    created->prior = previous;
    if(previous != nullptr){ // if not at front
        created->next = previous->next;
        previous->next = created;
    }
    else{ // if at front
        if(lsize == 0){ // empty
            front = created;
            created->next = nullptr;
        }
        else{ // not empty
            front->prior = created;
            created->next = front;
            front = created;
        }
    }
    lsize += 1;
}

/*
 * name:      recursiveHelp
 * purpose:   gives Node pointer at index
 * which makes it easy to insert and delete elements
 * arguments: starting node and index
 * returns:   Node pointer
 * effects:   gives Node pointer at index
 */
CharLinkedList::Node*CharLinkedList::recursiveHelp(Node *tmp, int index) const{
    if(index == 0){;
        return tmp;
    }
    else{
        Node *recursive = recursiveHelp(tmp->next, index - 1);
        return recursive;
    }
}

/*
 * name:      deconstructer
 * purpose:   recursive func to make decon easier
 * arguments: starting node
 * returns:   Node pointer
 * effects:   deletes all nodes after linked 
 */
void CharLinkedList::deconstructer(Node *linked){
    if (linked == nullptr){
        return;
    }
    else{
        Node *deletenext = linked->next;
        delete linked;
        lsize -= 1;
        deconstructer(deletenext);
    }
}
// /*
//  *  unit_tests.h
//  *  Jonah Rudin
//  *  2/1
//  *
//  *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
//  *
//  *  Test linked list functions individually to find bugs
//  * No known bugs
//  */

#include "CharLinkedList.h"
#include <cassert>
#include <iostream>

void constructerempty(){
    CharLinkedList test_list;
}

void constructertwo(){
    CharLinkedList test_list('c');
}

void deconstucter(){
    CharLinkedList test_list;
}

void deconstuctertwo(){
    CharLinkedList test_list('c');
}
void constructerthree(){
    char array[3];
    array[0] = 'a';
    array[1] = 'b';
    array[2] = 'c';
    CharLinkedList test_list(array, 3);
    assert(test_list.size() == 3);
}

void constructerfour(){
    char array[3];
    array[0] = 'a';
    array[1] = 'b';
    array[2] = 'c';
    CharLinkedList test_list(array, 3);
    CharLinkedList test_two(test_list);
    assert(test_two.size() == 3);
}

void notempty(){
    char array[3];
    array[0] = 'a';
    array[1] = 'b';
    array[2] = 'c';
    CharLinkedList test_list(array, 3);
    assert(test_list.isEmpty() == 0);
}

void emptyandclear(){
    char array[3];
    array[0] = 'a';
    array[1] = 'b';
    array[2] = 'c';
    CharLinkedList test_list(array, 3);
    test_list.clear();
    assert(test_list.size() == 0);
    assert(test_list.isEmpty() == 1);
}

//first function test
void assertfirst(){
    char array[3];
    array[0] = 'a';
    array[1] = 'b';
    array[2] = 'c';
    CharLinkedList test_list(array, 3);
    assert(test_list.first() == 'a');
}

//first with empty catch
void assertfirstempty(){
    cerr << "before";
    CharLinkedList test_list;
    cerr << "after";
    try{
        cerr << "test";
        test_list.first();
    }
    catch(runtime_error){
        cout << "error caught";
    }
}

//checks last function
void assertlast(){
    char array[3];
    array[0] = 'a';
    array[1] = 'b';
    array[2] = 'c';
    CharLinkedList test_list(array, 3);
    assert(test_list.last() == 'c');
}

//checks last function when empty catch
void assertlastempty(){
    CharLinkedList test_list;
    try{
        test_list.last();
    }
    catch(runtime_error){
        cout << "error caught";
    }
}

void assertelementat(){
    char array[3];
    array[0] = 'a';
    array[1] = 'b';
    array[2] = 'c';
    CharLinkedList test_list(array, 3);
    char test = test_list.elementAt(0);
    assert(test == 'a');
}

//makes sure out of bound element catches
void assertelementatoutofbounds(){
    char array[3];
    array[0] = 'a';
    array[1] = 'b';
    array[2] = 'c';
    CharLinkedList test_list(array, 3);
    try{
        int el = test_list.elementAt(4);
    }
    catch(range_error){
        cout << "range_error";
    }
}

void constructerthreetoString(){
    char array[3];
    array[0] = 'a';
    array[1] = 'b';
    array[2] = 'c';
    CharLinkedList test_list(array, 3);
    string str = test_list.toString();
    cerr << str;
    assert( str == "[CharLinkedList of size 3 <<abc>>]");
}

//checks toStringreverse function
void constructerthreetoStringreverse(){
    char array[3];
    array[0] = 'a';
    array[1] = 'b';
    array[2] = 'c';
    CharLinkedList test_list(array, 3);
    string str = test_list.toReverseString();
    cerr << str;
    assert( str == "[CharLinkedList of size 3 <<cba>>]");
}

// checks tostring reverse when empty
void toStringreverse(){
    CharLinkedList test_list;
    string array = test_list.toReverseString();
    cerr << array;
    assert( array == "[CharLinkedList of size 0 <<>>]");
}

//checks add to end
void assertPushatback(){
    char array[3];
    array[0] = 'a';
    array[1] = 'b';
    array[2] = 'c';
    CharLinkedList test_list(array, 3);
    test_list.pushAtBack('d');
    assert(test_list.elementAt(3) == 'd');
}

//checks with empty array
void assertPushatbackempty(){
    CharLinkedList test_list;
    test_list.pushAtBack('d');
    assert(test_list.elementAt(0) == 'd');
}

//adds at front
void assertPushatfront(){
    char array[3];
    array[0] = 'a';
    array[1] = 'b';
    array[2] = 'c';
    CharLinkedList test_list(array, 3);
    test_list.pushAtFront('d');
    assert(test_list.elementAt(0) == 'd');
}

//add at front with empty check
void assertPushatFrontempty(){
    CharLinkedList test_list;
    test_list.pushAtFront('d');
    assert(test_list.elementAt(0) == 'd');
}

//checks insert at specific element
void insertAt_empty_correct() { 

    CharLinkedList test_list;
    test_list.insertAt('a', 0);
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');

}

// Tests incorrect insertion into an empty AL.
// Attempts to call insertAt for index larger than 0.
// This should result in an std::range_error being raised.
void insertAt_empty_incorrect() {

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
        // insertAt for out-of-range index
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        // if insertAt is correctly implemented, a range_error will be thrown,
        // and we will end up here
        range_error_thrown = true;
        error_message = e.what();
    }
    cerr << error_message << endl;
    // out here, we make our assertions
    // assert(range_error_thrown);
    // assert(error_message == "index (42) not in range [0..0]");


    
}

// Tests correct insertAt for front of 1-element list.
void insertAt_front_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at front
    test_list.insertAt('b', 0);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'a');
    
}

// Tests correct insertAt for back of 1-element list.
void insertAt_back_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at back
    test_list.insertAt('b', 1);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    
}

// Tests calling insertAt for a large number of elements.
// Not only does this test insertAt, it also checks that
// array expansion works correctly.
void insertAt_many_elements() {
    
    CharLinkedList test_list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.insertAt('a', i);
    }

    assert(test_list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
    
}

// Tests insertion into front of a larger list
void insertAt_front_large_list() {
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    test_list.insertAt('y', 0);

    assert(test_list.size() == 10);
    assert(test_list.elementAt(0) == 'y');
    assert(test_list.toString() ==     
    "[CharLinkedList of size 10 <<yabczdefgh>>]");

}

// Tests insertion into the back of a larger list
void insertAt_back_large_list() {

    char test_arr[10] = { 'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 10);  

    test_list.insertAt('x', 10);

    assert(test_list.size() == 11);
    assert(test_list.elementAt(10) == 'x');
    assert(test_list.toString() == 
    "[CharLinkedList of size 11 <<yabczdefghx>>]"); 

}

// Tests insertion into the middle of a larger list
void insertAt_middle_large_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.insertAt('z', 3);

    assert(test_list.size() == 9);
    assert(test_list.elementAt(3) == 'z');
    assert(test_list.toString() ==     
    "[CharLinkedList of size 9 <<abczdefgh>>]");

}

// Tests out-of-range insertion for a non-empty list.
void insertAt_nonempty_incorrect() {
   
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    cerr << error_message << endl;

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8]");
}

//checks insert in order of ASII
void assertInOrder(){
    char array[3];
    array[0] = 'a';
    array[1] = 'b';
    array[2] = 'c';
    CharLinkedList test_list(array, 3);
    test_list.insertInOrder('d');
    assert(test_list.elementAt(3) == 'd');
}
 //checks different spot ASII
void assertInOrderTwo(){
    char array[3];
    array[0] = 'a';
    array[1] = 'b';
    array[2] = 'c';
    CharLinkedList test_list(array, 3);
    test_list.insertInOrder('a');
    assert(test_list.elementAt(1) == 'a');
}

//checks different spot
void assertInOrderthree(){
    char array[3];
    array[0] = 'a';
    array[1] = 'b';
    array[2] = 'c';
    CharLinkedList test_list(array, 3);
    test_list.insertInOrder('b');
    assert(test_list.elementAt(1) == 'b');
}

//removes first element
void assertpopFromFront(){
    char array[3];
    array[0] = 'a';
    array[1] = 'b';
    array[2] = 'c';
    CharLinkedList test_list(array, 3);
    test_list.popFromFront();
    assert(test_list.elementAt(0) == 'b');
}

//removes last element
void assertpopFromBack(){
    char array[3];
    array[0] = 'a';
    array[1] = 'b';
    array[2] = 'c';
    CharLinkedList test_list(array, 3);
    test_list.popFromBack();
    assert(test_list.elementAt(1) == 'b');
}

//checks remove specific spot
void assertRemoveAt(){
    char array[3];
    array[0] = 'a';
    array[1] = 'b';
    array[2] = 'c';
    CharLinkedList test_list(array, 3);
    test_list.removeAt(1);
    assert(test_list.elementAt(1) == 'c');
}

void assertReplaceAt(){
    char array[3];
    array[0] = 'a';
    array[1] = 'b';
    array[2] = 'c';
    CharLinkedList test_list(array, 3);
    test_list.replaceAt('c', 0);
    assert(test_list.elementAt(0) == 'c');
}

void assertconcatenate(){
    char arrayone[3];
    arrayone[0] = 'a';
    arrayone[1] = 'b';
    arrayone[2] = 'c';
    CharLinkedList test_list(arrayone, 3);
    test_list.concatenate(&test_list);
    // assert(test_list.elementAt(5) == 'c');
    // assert(test_list.size() == 6);
}

//tested private functions in functions that 
//use them and then adjusted unit test to functions
/*
 *  unit_tests.h
 *  Chance Rebish
 *  1/31/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  Function tests for the CharLinkedList class
 *
 */
#include "CharLinkedList.h"
#include <cassert>

//Tests if the CharLinkedList initializes and is set to size 0
void constructor1_test() {
    CharLinkedList test_list;
    assert(test_list.size() == 0);
}

//Tests the second constructor by seeing if the given character is
//added at position 0
void constructor2_test() {
    CharLinkedList test_list('x');
    assert(test_list.first() == 'x');
}

//Tests the third constructor by seeing if the given array is
//added at correctly to the LinkedList
void constructor3_test() {
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList test_list(arr, 3);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    assert(test_list.elementAt(2) == 'c');
}

//Tests if the fourth constructor successfully makes a deep copy 
//of the other ArrayList
void constructor4_test() {
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList test_list(arr, 3);
    CharLinkedList list(test_list);

    assert(list.size() == 3);
    assert(list.toString() == "[CharLinkedList of size 3 <<abc>>]");
}

//Tests if the isEmpty function works when it is supposed to be true
void isEmpty_true_test() {
    CharLinkedList test_list;
    assert(test_list.isEmpty());
}

//Tests if the isEmpty function works when it is supposed to be false
void isEmpty_false_test() {
    CharLinkedList test_list('x');
    assert(not test_list.isEmpty());
}

//Test if the clear function works, leading to size being 0
void clear_test() {
    CharLinkedList test_list('x');
    test_list.clear();
    assert(test_list.size() == 0);
}

//Tests if the first function returns the first element of the list
void first_test() {
    CharLinkedList test_list('x');
    assert(test_list.first() == 'x');
}

//Tests if the first function throws an error correctly when the LinkedList
//is empty
void first_fail_test() {
    bool runtime_error_thrown = false;
    std::string error_message = "";

    CharLinkedList test_list;
    try {
        test_list.first();
    }
    catch(const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "cannot get first of empty LinkedList");
}

//Tests if the last function returns the last element of the list
void last_test() {
    CharLinkedList test_list;
    test_list.pushAtBack('a');
    test_list.pushAtBack('b');
    test_list.pushAtBack('c');
    assert(test_list.last() == 'c');
}

//Tests if the elementAt function returns the correct character
void elementAt_correct_test() {
    CharLinkedList test_list;
    test_list.pushAtBack('a');
    test_list.pushAtBack('b');
    test_list.pushAtBack('c');
    assert(test_list.elementAt(1) == 'b');
}

//Tests elementAt when calling the first position
void elementAt_0_test(){
    CharLinkedList test_list;
    test_list.pushAtBack('a');
    test_list.pushAtBack('b');
    test_list.pushAtBack('c');
    assert(test_list.elementAt(0) == 'a');
}

//Tests elementAt when calling on the last element
void elementAt_last_test(){
    CharLinkedList test_list;
    test_list.pushAtBack('a');
    test_list.pushAtBack('b');
    test_list.pushAtBack('c');
    assert(test_list.elementAt(2) == 'c');
}

//Tests elementAt on an empty list to see if exceptions are thrown correctly
void elementAt_empty_test(){
    bool range_error_thrown = false;
    std::string error_message = "";

    CharLinkedList test_list;
    try {
        test_list.elementAt(0);
    }
    catch(const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (0) not in range [0..0)");

}

//Tests if the elementAt function properly responds to an out of scope index 
//input
void elementAt_incorrect_test() {
    bool range_error_thrown = false;
    std::string error_message = "";

    CharLinkedList test_list;
    test_list.pushAtBack('a');
    test_list.pushAtBack('b');
    test_list.pushAtBack('c');
    try {
        test_list.elementAt(6);
    }
    catch(const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (6) not in range [0..3)");
}

//Tests if the elementAt function properly responds to an out of scope negative
//index input
void elementAt_incorrect2_test(){
    bool range_error_thrown = false;
    std::string error_message = "";

    CharLinkedList test_list;
    test_list.pushAtBack('a');
    test_list.pushAtBack('b');
    test_list.pushAtBack('c');
    try {
        test_list.elementAt(-3);
    }
    catch(const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (-3) not in range [0..3)");
}

//Tests the popFromFront function and if it moves all other memebers of the
//ArrayList down when the front is popped
void popFromFront_test() {
    char arr[4] = {'a', 'b', 'c', 'd'};
    CharLinkedList test_list(arr, 4);
    test_list.popFromFront();
    test_list.popFromFront();
    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'c');
    assert(test_list.elementAt(1) == 'd');
}

//Tests popFromBack thrown exception when it is used one too many
void popFromFront_incorrect_test() {
    bool runtime_error_thrown = false;
    std::string error_message = "";

    CharLinkedList test_list;
    test_list.pushAtBack('a');
    try {
        test_list.popFromFront();
        test_list.popFromFront();
    } catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

//Tests the popFromBack function and if it moves all other memebers of the
//ArrayList down when the front is popped
void popFromBack_test() {
    char arr[4] = {'a', 'b', 'c', 'd'};
    CharLinkedList test_list(arr, 4);
    test_list.popFromBack();
    test_list.popFromBack();
    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
}

//Tests if the toString function works
void toString_test() {
    char arr[4] = {'a', 'z', 'g', 'l'};
    CharLinkedList test_list(arr, 4);
    assert(test_list.toString() == "[CharLinkedList of size 4 <<azgl>>]");
}

//Tests if the toString function works on an empty LinkedList
void toString_0_test() {
    CharLinkedList test_list;
    assert(test_list.toString() == "[CharLinkedList of size 0 <<>>]");
}

//Tests if the toReverseString function works
void toReverseString_test() {
    char arr[4] = {'a', 'z', 'g', 'l'};
    CharLinkedList test_list(arr, 4);
    assert(test_list.toReverseString() == 
        "[CharLinkedList of size 4 <<lgza>>]");
}

//Tests if toReverseString has correct output on list of 0
void toReverseString_0_test() {
    CharLinkedList test_list;
    assert(test_list.toReverseString() == "[CharLinkedList of size 0 <<>>]");
}

//Tests the pushAtFront function
void pushAtFront_test() {
    char arr[4] = {'a', 'z', 'g', 'l'};
    CharLinkedList test_list(arr, 4);
    test_list.pushAtFront('d');
    assert(test_list.toString() == "[CharLinkedList of size 5 <<dazgl>>]");
}

//Tests the pushAtFront function when the list is empty
void pushAtFront_0_test() {
    CharLinkedList test_list;
    test_list.pushAtFront('d');
    assert(test_list.toString() == "[CharLinkedList of size 1 <<d>>]");
}

//Tests the pushAtBack function
void pushAtBack_test() {
    char arr[4] = {'a', 'z', 'g', 'l'};
    CharLinkedList test_list(arr, 4);
    test_list.pushAtBack('d');
    assert(test_list.toString() == "[CharLinkedList of size 5 <<azgld>>]");
}

//Tests the pushAtBack function when the list is empty
void pushAtBack_0_test() {
    CharLinkedList test_list;
    test_list.pushAtBack('d');
    assert(test_list.toString() == "[CharLinkedList of size 1 <<d>>]");
}

//Tests if the insertInOrder function works properly
void insertInOrder_test() {
    char arr[4] = {'z', 'z', 'g', 'l'};
    CharLinkedList test_list(arr, 4);
    test_list.insertInOrder('b');
    assert(test_list.toString() == "[CharLinkedList of size 5 <<bzzgl>>]");
}

//Tests if the insertInOrder function works properly
void insertInOrder2_test() {
    char arr[4] = {'a', 'z', 'g', 'l'};
    CharLinkedList test_list(arr, 4);
    test_list.insertInOrder('b');
    assert(test_list.toString() == "[CharLinkedList of size 5 <<abzgl>>]");
}

//Tests if insertInOrder works on an empty LinkedList
void insertInOrder_0_test() {
    CharLinkedList test_list;
    test_list.insertInOrder('b');
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'b');
}

//Tests if the removeAt function works properly
void removeAt_test() {
    char arr[4] = {'a', 'z', 'g', 'l'};
    CharLinkedList test_list(arr, 4);
    test_list.removeAt(1);
    assert(test_list.size() == 3);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'g');
    assert(test_list.elementAt(2) == 'l');
}

//Tests when removeAt removes twice when theres only 1 element
void removeAt_0_test() {
    bool range_error_thrown = false;
    std::string error_message = "";
    
    CharLinkedList test_list;
    test_list.pushAtBack('a');
    
    try {
        test_list.removeAt(0);
        test_list.removeAt(0);
    }
    catch(const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (0) not in range [0..0)");
}

//Tests if a runtime error occurs when removeAt is used improperly
void removeAt_incorrect_test() {
    bool range_error_thrown = false;
    std::string error_message = "";
    
    char arr[4] = {'a', 'z', 'g', 'l'};
    CharLinkedList test_list(arr, 4);

    try {
        test_list.removeAt(18);
    }
    catch(const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (18) not in range [0..4)");
}

//Tests if the replaceAt function works properly
void replaceAt_test() {
    char arr[4] = {'a', 'z', 'g', 'l'};
    CharLinkedList test_list(arr, 4);
    test_list.replaceAt('f', 1);
    assert(test_list.size() == 4);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'f');
    assert(test_list.elementAt(2) == 'g');
    assert(test_list.elementAt(3) == 'l');
}

//Tests if a runtime error occurs when replaceAt is used improperly
void replaceAt_incorrect_test() {
    bool range_error_thrown = false;
    std::string error_message = "";
    
    char arr[4] = {'a', 'z', 'g', 'l'};
    CharLinkedList test_list(arr, 4);

    try {
        test_list.replaceAt('a', 18);
    }
    catch(const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (18) not in range [0..4)");
}

//Tests if the concatenate function works properly
void concatenate_test() {
    char arr[3] = {'c', 'a', 't'};
    char array[4] = {'a', 'z', 'g', 'l'};
    CharLinkedList test_list(arr, 3);
    CharLinkedList list_test(array, 4);

    test_list.concatenate(&list_test);
    assert(test_list.size() == 7);
    assert(test_list.toString() == "[CharLinkedList of size 7 <<catazgl>>]");
}

//Tests if the concatenate function works when one list is empty
void concatenate_empty_test() {
    char arr[3] = {'c', 'a', 't'};
    CharLinkedList test_list;
    CharLinkedList list_test(arr, 3);

    test_list.concatenate(&list_test);
    assert(test_list.size() == 3);
    assert(test_list.toString() == "[CharLinkedList of size 3 <<cat>>]");
}

//Tests if the concatenate function works when other list is empty
void concatenate_reverse_empty_test() {
    char arr[3] = {'c', 'a', 't'};
    CharLinkedList test_list;
    CharLinkedList list_test(arr, 3);

    list_test.concatenate(&test_list);
    assert(list_test.size() == 3);
    assert(list_test.toString() == "[CharLinkedList of size 3 <<cat>>]");
}

//Tests if the concatenate function works when concatenating itself
void concatenate_self_test() {
    char arr[3] = {'c', 'a', 't'};
    CharLinkedList test_list(arr, 3);
    CharLinkedList list_test(arr, 3);

    test_list.concatenate(&list_test);
    assert(test_list.size() == 6);
    assert(test_list.toString() == "[CharLinkedList of size 6 <<catcat>>]");
}

//Tests the overload operator function
void overloadOperator_test() {
    char arr[3] = {'c', 'a', 't'};
    CharLinkedList test_list(arr, 3);
    CharLinkedList list;

    list = test_list;
    
    assert(list.size() == 3);
    assert(list.toString() == "[CharLinkedList of size 3 <<cat>>]");
}

//tests making a deep copy of an empty list
void overloadOperator_empty_test() {
    char arr[3] = {'c', 'a', 't'};
    CharLinkedList test_list;
    CharLinkedList list(arr, 3);

    list = test_list;

    assert(list.size() == 0);
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}

// Tests correct insertion into an empty AL.
// Afterwards, size should be 1 and element at index 0
// should be the element we inserted.
void insertAt_empty_correct() { 

    CharLinkedList test_list;
    test_list.insertAt('a', 0);
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');

}

// Tests incorrect insertion into an empty AL.
// Attempts to call insertAt for index larger than 0.
// This should result in an std::range_error being raised.
void insertAt_empty_incorrect() {

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    // insertAt for out-of-range index
    test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
    // if insertAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    range_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0]");
    
}

// Tests correct insertAt for front of 1-element list.
void insertAt_front_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at front
    test_list.insertAt('b', 0);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'a');
    
}

// Tests correct insertAt for back of 1-element list.
void insertAt_back_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at back
    test_list.insertAt('b', 1);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    
}

// Tests calling insertAt for a large number of elements.
// Not only does this test insertAt, it also checks that
// list expansion works correctly.
void insertAt_many_elements() {
    
    CharLinkedList test_list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.insertAt('a', i);
    }

    assert(test_list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
    
}

// Tests insertion into front of a larger list
void insertAt_front_large_list() {
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    test_list.insertAt('y', 0);

    assert(test_list.size() == 10);
    assert(test_list.elementAt(0) == 'y');
    assert(test_list.toString() ==     
        "[CharLinkedList of size 10 <<yabczdefgh>>]");

}

// Tests insertion into the back of a larger list
void insertAt_back_large_list() {

    char test_arr[10] = { 'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 10);  

    test_list.insertAt('x', 10);

    assert(test_list.size() == 11);
    assert(test_list.elementAt(10) == 'x');
    assert(test_list.toString() == 
        "[CharLinkedList of size 11 <<yabczdefghx>>]"); 

}

// Tests insertion into the middle of a larger list
void insertAt_middle_large_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.insertAt('z', 3);

    assert(test_list.size() == 9);
    assert(test_list.elementAt(3) == 'z');
    assert(test_list.toString() == "[CharLinkedList of size 9 <<abczdefgh>>]");

}

// Tests out-of-range insertion for a non-empty list.
void insertAt_nonempty_incorrect() {
   
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8]");
    
} 
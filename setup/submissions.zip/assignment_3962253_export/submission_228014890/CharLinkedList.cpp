/*
 *  CharLinkedList.cpp
 *  Chance Rebish
 *  1/31/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Function definitions for the CharLinkedList class
 *
 */

#include "CharLinkedList.h"

using namespace std;

/*
 * name:      CharLinkedList constructor1
 * purpose:   initialize the CharLinkedList when called
 * arguments: none
 * returns:   none
 * effects:   sets all values to 0 or nullptr
 */
CharLinkedList::CharLinkedList() {
    numItems = 0;
    front = nullptr;
    back = nullptr;
}

/*
 * name:      CharLinkedList constructor2
 * purpose:   initialize the CharLinkedList when called with 1 element already
 *             added
 * arguments: a char
 * returns:   none
 * effects:   Adds a single node to the LinkedList
 */
CharLinkedList::CharLinkedList(char c) {
    numItems = 1;

    //Creates starting node
    front = newNode(c);
    back = front;
}

/*
 * name:      CharLinkedList constructor3
 * purpose:   initialize the CharLinkedList when called with an array of chars
 *             added as nodes
 * arguments: array of chars and size of the array
 * returns:   none
 * effects:   Adds all chars in teh array as nodes in the LinkedList in order
 */
CharLinkedList::CharLinkedList(char arr[], int size) {
    numItems = 0;
    front = nullptr;
    back = nullptr;

    //Adds array data as nodes
    for (int i = size - 1; i >= 0; i--) {
        pushAtFront(arr[i]);
    }
}

/*
 * name:      CharLinkedList constructor4
 * purpose:   initialize the CharLinkedList when called with a deep copy of the
 *             other given LinkedList
 * arguments: other LinkedList
 * returns:   none
 * effects:  creates deep copy of given LinkedList
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other) {
    numItems = 0;
    front = nullptr;
    back = nullptr;
    
    //copies the other CharLinkedList
    Node *curr = other.front;
    for (int i = 0; i < other.size(); i++) {
        pushAtBack(curr->data);
        curr = curr->next;
    }
}

/*
 * name:      Overflow Operator function
 * purpose:   makes current function a deep copy of the other given LinkedList
 * arguments: other LinkedList
 * returns:   this LinkedList
 * effects:   creates deep copy of given LinkedList
 */
CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other) {
    //first clear all existing data
    clear();

    //copies the other CharLinkedList
    Node *curr = other.front;
    for (int i = 0; i < other.size(); i++) {
        pushAtBack(curr->data);
        curr = curr->next;
    }

    return *this;
}

/*
 * name:      isEmpty
 * purpose:   checks if the LinkedList is empty
 * arguments: none
 * returns:   true or false
 * effects:   none
 */
bool CharLinkedList::isEmpty() const {
    if (numItems == 0) {
        return true;
    }
    return false;
}

/*
 * name:      clear
 * purpose:   creates an empty LinkedList, clearing the memory of the current
 *             one
 * arguments: none
 * returns:   none
 * effects:   removes all data from LinkedList
 */
void CharLinkedList::clear() {
    //delete everything from memory
    recycleRecursive(front);

    numItems = 0;
    front = nullptr;
    back = nullptr;
}

/*
 * name:      size
 * purpose:   gives the size of the LinkedList
 * arguments: none
 * returns:   int
 * effects:   none
 */
int CharLinkedList::size() const {
    return numItems;
}

/*
 * name:      first
 * purpose:   gives the data of the first element in the LinkedList
 * arguments: none
 * returns:   char of the first element
 * effects:   none
 */
char CharLinkedList::first() const {
    if (numItems == 0) {
        throw runtime_error("cannot get first of empty LinkedList");
    }

    return front->data;
}

/*
 * name:      last
 * purpose:   gives the data of the last element in the LinkedList
 * arguments: none
 * returns:   char of the last element
 * effects:   none
 */
char CharLinkedList::last() const {
    if (numItems == 0){
        throw runtime_error("cannot get last of empty ArrayList");
    }
    
    return back->data;
}

/*
 * name:      element
 * purpose:   gives the data of the index element in the LinkedList
 * arguments: an index
 * returns:   char of the index element
 * effects:   none
 */
char CharLinkedList::elementAt(int index) const {
    if (index >= numItems or index < 0) {
            throw range_error("index (" + to_string(index) + 
            ") not in range [0.." + to_string(numItems) + ")");
        }
    //Recursively find the elementAt position
    return elementAtRecursiveHelper(index, front);
}

/*
 * name:      elementAtRecursiveHelper
 * purpose:   recursively finds the data of the index element from elementAt
 * arguments: an index and pointer to first element in LinkedList
 * returns:   char of the first element
 * effects:   none
 */
char CharLinkedList::elementAtRecursiveHelper(int index, Node *curr) const {
    if (index == 0) {
        return curr->data;
    } else {
        curr = curr->next;
        index--;
        return elementAtRecursiveHelper(index, curr);
    }
}

/*
 * name:      toString
 * purpose:   writes out all characters in the LinkedList as a string
 * arguments: none
 * returns:   a string
 * effects:   none
 */
std::string CharLinkedList::toString() const {
    std::stringstream ss;
    ss << "[CharLinkedList of size " << numItems << " <<";
    
    //individually adds each letter to stringstream
    Node *curr = front;
    for (int i = 0; i < numItems; i++) {
        ss << curr->data;
        curr = curr->next;
    }

    ss << ">>]";
    return ss.str();
}

/*
 * name:      toReverseString
 * purpose:   writes out all characters in the ArrayList as a string 
 *             in backwards order
 * arguments: none
 * returns:   a string
 * effects:   none
 */
std::string CharLinkedList::toReverseString() const {
    std::stringstream ss;
    ss << "[CharLinkedList of size " << numItems << " <<";
    
    //individually adds each letter to stringstream
    Node *curr = back;
    for (int i = 0; i < numItems; i++){
        ss << curr->data;
        curr = curr->prev;
    }

    ss << ">>]";
    return ss.str();
}

/*
 * name:      pushAtBack
 * purpose:   places given character at end of the LinkedList
 * arguments: a char
 * returns:   none
 * effects:   adds new char at end of LinkedList
 */
void CharLinkedList::pushAtBack(char c) {
    //edge case if LinkedList is empty
    if (numItems == 0){
        front = newNode(c);
        back = front;
        numItems++;
        return;
    }

    //inserts new node and moves pointer accordingly
    Node *curr = newNode(c);
    back->next = curr;
    curr->prev = back;
    back = curr;

    numItems++;
}

/*
 * name:      pushAtFront
 * purpose:   places given character at front of the LinkedList
 * arguments: a char
 * returns:   none
 * effects:   adds new char at front of LinkedList
 */
void CharLinkedList::pushAtFront(char c) {
    //edge case if LinkedList is empty
    if (numItems == 0){
        front = newNode(c);
        back = front;
        numItems++;
        return;
    }

    //inserts new node and moves pointer accordingly
    Node *curr = newNode(c);
    front->prev = curr;
    curr->next = front;
    front = curr;
    
    numItems++;
}

/*
 * name:      insertAt
 * purpose:   inserts a given char at the given index in the LinkedList
 * arguments: a char and index
 * returns:   none
 * effects:   adds new node at selected index and moves pointer to point
 *             at correct positions
 */
void CharLinkedList::insertAt(char c, int index) {
    if (index > numItems or index < 0) {
        throw range_error("index (" + to_string(index) + 
            ") not in range [0.." + to_string(numItems) + "]");
    }

    //edge cases when inserting on either end of the LinkedList
    if (index == 0) {
        pushAtFront(c);
        return;
    } else if (index == numItems) {
        pushAtBack(c);
        return;
    }

    //finds position to insert at
    Node *left = front;
    Node *right = front->next;
    for (int i = 0; i < index - 1; i++) {
        left = left->next;
        right = right->next;
    }

    //inserts new node and moves pointer accordingly
    Node *curr = newNode(c);
    curr->prev = left;
    curr->next = right;
    left->next = curr;
    right->prev = curr;

    numItems++;
}

/*
 * name:      insertInOrder
 * purpose:   inserts a char where it should be placed alphabetically
 * arguments: a char
 * returns:   none
 * effects:   adds new node and points pointers accordingly
 */
void CharLinkedList::insertInOrder(char c) {
    //edge case if LinkedList is empty
    if (numItems == 0) {
        pushAtFront(c);
        return;
    }

    //finds the alphabetical position for the given char and insertAt it
    int index = 0;
    char letter = front->data;
    Node *curr = front;
    while (c > letter) {
        curr = curr->next;
        letter = curr->data;
        index++;
    }
    insertAt(c, index);
}

/*
 * name:      popFromFront
 * purpose:   removes first node from the CharLinkedList
 * arguments: none
 * returns:   none
 * effects:   deletes node from LinkedList
 */
void CharLinkedList::popFromFront() {
    if (numItems == 0) {
        throw runtime_error("cannot pop from empty LinkedList");
    } 
    
    //edge case when there is only 1 node in the LinkedList
    if (numItems == 1) {
        front = nullptr;
        delete back;
        back = nullptr;
        numItems--;
        return;
    }

    //removes chosen node and moves pointers accordingly
    Node *old_front = front;
    front = front->next;
    front->prev = nullptr;
    delete old_front;

    numItems--;
}

/*
 * name:      popFromBack
 * purpose:   removes the last node from the CharLinkedList
 * arguments: none
 * returns:   none
 * effects:   deletes node from LinkedList
 */
void CharLinkedList::popFromBack() {
    if (numItems == 0) {
        throw runtime_error("cannot pop from empty LinkedList");
    } 
    
    //edge case when there is only 1 node in LinkedList
    if (numItems == 1) {
        front = nullptr;
        delete back;
        back = nullptr;
        numItems--;
        return;
    }

    //removes chosen node and moves pointers accordingly
    Node *old_back = back;
    back = back->prev;
    back->next = nullptr;
    delete old_back;

    numItems--;
}

/*
 * name:      removeAt
 * purpose:   removes node at given index position
 * arguments: an index
 * returns:   none
 * effects:   deletes node from LinkedList
 */
void CharLinkedList::removeAt(int index) {
    if (index >= numItems or index < 0) {
        throw range_error("index (" + to_string(index) + 
            ") not in range [0.." + to_string(numItems) + ")");
    }

    //edge cases when the node being removed is on the end of LinkedLIst
    if (index == 0) {
        popFromFront();
        return;
    } else if (index == numItems - 1) {
        popFromBack();
        return;
    }

    //find position of chosen node
    Node *curr = front;
    for (int i = 0; i < index; i++) {
        curr = curr->next;
    }

    //removes chosen node and moves pointers accordingly
    curr->prev->next = curr->next;
    curr->next->prev = curr->prev;
    delete curr;

    numItems--;
}

/*
 * name:      replaceAt
 * purpose:   replaces char at given index with the given char
 * arguments: a char and index
 * returns:   none
 * effects:   changes char at given index
 */
void CharLinkedList::replaceAt(char c, int index) {
    if (index >= numItems or index < 0) {
        throw range_error("index (" + to_string(index) + 
            ") not in range [0.." + to_string(numItems) + ")");
    }

    //recursive helper to replace data
    replaceAtRecursiveHelper(c, index, front);
}

/*
 * name:      replaceAtRecursiveHelper
 * purpose:   recursively finds position of char being replaced and replaces it
 * arguments: a char and index
 * returns:   none
 * effects:   changes char at given index
 */
void CharLinkedList::replaceAtRecursiveHelper(char c, int index, Node *curr) {
    if (index == 0) {
        curr->data = c;
    } else {
        curr = curr->next;
        index--;
        replaceAtRecursiveHelper(c, index, curr);
    }
}

/*
 * name:      concatenate
 * purpose:   adds a given CharLinkedList to the end of the LinkedList
 * arguments: other CharLinkedList
 * returns:   none
 * effects:   adds the other CharLinkedList's data to the end of 
 *             the LinkedList
 */
void CharLinkedList::concatenate(CharLinkedList *other) {
    //adds other LinkedList to end of current LinkedList
    Node *curr = other->front;
    for (int i = 0; i < other->size(); i++) {
        pushAtBack(curr->data);
        curr = curr->next;
    }
}

/*
 * name:      newNode
 * purpose:   intializes a new node with its char data to be placed in the
 *             LinkedList
 * arguments: a char
 * returns:   the initialized node
 * effects:   creates a new node on the heap
 */
CharLinkedList::Node *CharLinkedList::newNode(char c) {
    Node *new_node = new Node;
    new_node->data = c;
    new_node->next = nullptr;
    new_node->prev = nullptr;

    return new_node;
}

/*
 * name:      CharLinkedList destructor
 * purpose:   deletes data on the heap as it goes out of scope
 * arguments: none
 * returns:   none
 * effects:   deletes data on the heap
 */
CharLinkedList::~CharLinkedList() {
    recycleRecursive(front);
}

/*
 * name:      recycleRecursive
 * purpose:   recusively deletes data on the heap by following pointers
 * arguments: none
 * returns:   none
 * effects:   deletes data on the heap
 */
void CharLinkedList::recycleRecursive(Node *curr) {
    if (curr == nullptr) {
        return;
    } else {
        Node *next = curr->next;
        delete curr;
        recycleRecursive(next);
    }
}
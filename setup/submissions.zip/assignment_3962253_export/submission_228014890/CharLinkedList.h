/*
 *  CharLinkedList.h
 *  Chance Rebish
 *  1/31/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  CharLinkedList is a class that represents an ordered list of char
 *  instances. The CharLinkedList can start empty or with characters already
 *  in it depending on the constructor called. You can add, remove, and access
 *  a character to/at any position in the list. The class will become slower at
 *  performing actions to data in the middle of the list as the list increases 
 *  in size.
 *
 */

#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H

#include <stdexcept>
#include <string>
#include <sstream>
#include <iostream>

class CharLinkedList {
    public:
    //Constructors
    CharLinkedList();
    CharLinkedList(char c);
    CharLinkedList(char arr[], int size);
    CharLinkedList(const CharLinkedList &other);

    //Destructor
    ~CharLinkedList();

    //LinkedList Functions
    CharLinkedList &operator=(const CharLinkedList &other);
    bool isEmpty() const;
    void clear();
    int size() const;
    char first() const;
    char last() const;
    char elementAt(int index) const;
    std::string toString() const;
    std::string toReverseString() const;
    void pushAtBack(char c);
    void pushAtFront(char c);
    void insertAt(char c, int index);
    void insertInOrder(char c);
    void popFromFront();
    void popFromBack();
    void removeAt(int index);
    void replaceAt(char c, int index);
    void concatenate(CharLinkedList *other);

    private:
    //Private variables
    struct Node{
        char data;
        Node *next;
        Node *prev;
    };

    Node *front;
    Node *back;
    int numItems;

    //Private Functions
    char elementAtRecursiveHelper(int index, Node *curr) const;
    void replaceAtRecursiveHelper(char c, int index, Node *curr);
    void recycleRecursive(Node *curr);
    Node *newNode(char c);

};

#endif

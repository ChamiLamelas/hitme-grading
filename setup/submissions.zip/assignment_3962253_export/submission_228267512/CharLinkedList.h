/*
 *  CharLinkedList.h
 *  Yue Ma
 *  02/02/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  This header file defines the CharLinkedList class, which represents
 *  a linked list for characters. The class provides methods for common list 
 *  operations such as insertion, deletion, and concatenation.
 *
 */

#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H

#include <string>
#include <stdexcept>

class CharLinkedList 
{
public:
    CharLinkedList();
    CharLinkedList(char c);
    CharLinkedList(char arr[], int size);
    CharLinkedList(const CharLinkedList &other);

    ~CharLinkedList();

    CharLinkedList &operator=(const CharLinkedList &other);
    int size() const;
    bool isEmpty() const;
    void clear();
    char first() const;
    char last() const;
    char elementAt(int index) const;
    std::string toString() const;
    std::string toReverseString() const;
    void pushAtBack(char c);
    void pushAtFront(char c);
    void insertAt(char c, int index);
    void insertInOrder(char c);
    void popFromFront();
    void popFromBack();
    void removeAt(int index);
    void replaceAt(char c, int index);
    void concatenate(CharLinkedList *other);

private:
    int cSize;
    
    struct Node 
    { 
    char data; 
    Node *next; 
    Node *prev;
    };

    Node *front;

    Node *newNode(char newData, Node *next, Node *prev);

    char elementAtRecursive(Node *curr, int index, int curr_index) const;
    void replaceAtRecursive(Node *curr, int index, char Value, int curr_index);
};

#endif


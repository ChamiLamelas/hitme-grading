/*
 *  CharLinkedList.cpp
 *  Yue Ma
 *  02/02/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 * An implementation of the CharLinkedList interface, the LinkedList can be 
 * used to store nodes. This includes operations for adding, removing, and 
 * accessing characters, as well as managing the size of the array.
 *
 * NOTE: This is implemented using a doubly-linked list with no back pointer.
 *
 */

#include "CharLinkedList.h"
#include <stdexcept>
#include <sstream>

using namespace std;

/*
 * name:      LinkedList default constructor.
 * purpose:   Initialize an empty LinkedList.
 * arguments: none.
 * returns:   none.
 * effects:   cSize to 0 and front pointer to nullptr.
 */
CharLinkedList::CharLinkedList()
{
    front = nullptr;
    cSize = 0;
}

/*
 * name:      newNode
 * purpose:   Creates a new Node with specified data and links.
 * arguments: 'newData' - The character data to store in the new node.
 *            'next' - Pointer to the next Node in the list.
 *            'prev' - Pointer to the previous Node in the list.
 * returns:   A pointer to the newly created Node.
 * effects:   Allocates memory for a new Node, initializes it with the given
 *            data and links, and returns the pointer
 *            to this new Node. 
 */
CharLinkedList::Node *CharLinkedList::newNode(char newData, Node *next, 
                                                Node *prev)
{
    Node *new_node = new Node;
    new_node->data = newData;
    new_node->next = next;
    new_node->prev = prev;

    return new_node;
}

/*
 * name:      CharLinkedList - Constructor with Single Character
 * purpose:   Initializes CharLinkedList with a single character.
 * arguments: 'c' - A character to initialize the list.
 * returns:   None.
 * effects:   Sets cSize to 1, and stores 'c'.
 */
CharLinkedList::CharLinkedList(char c)
{
    cSize = 1;
    front = newNode(c, nullptr, nullptr);
}

/*
 * name:      CharLinkedList
 * purpose:   Initializes CharLinkedList with a linkedlist of characters.
 * arguments: 'arr' - linkedlist of characters, 
 *            'size' - Number of elements in 'arr'.
 * returns:   None.
 * effects:   Copies 'arr' into the internal linked list, sets cSize.
 */
CharLinkedList::CharLinkedList(char arr[], int size)
{
    front = nullptr; 
    cSize = 0;

    Node *curr = nullptr;

    for (int i = 0; i < size; i++) 
    {
        Node *new_node = newNode(arr[i], nullptr, curr);
        if (curr != nullptr) 
        { 
            curr->next = new_node;
        } else 
        {
            front = new_node;
        }
        curr = new_node;
        cSize++;
    }
}

/*
 * name:      CharLinkedList
 * purpose:   Creates a copy of another CharLinkedList.
 * arguments: 'other' - The CharLinkedList to copy.
 * returns:   None.
 * effects:   Copies all elements from 'other' to this instance.
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other)
{
    front = nullptr;
    cSize = 0;

    if (other.cSize == 0)
    {
        return;
    }
    
    Node *other_curr = other.front;
    while (other_curr != nullptr)
    {
        pushAtBack(other_curr->data);
        other_curr = other_curr->next;
    }
    cSize++;
}


/*
 * name:      LinkedList destructor
 * purpose:   free heap-allocated memory associated with the LinkedList.
 * arguments: none.
 * returns:   none.
 * effects:   frees memory allocated by Linkedlist instances.
 */
CharLinkedList::~CharLinkedList() 
{
    while (front != nullptr) 
    {
        Node *curr = front;     
        front = front->next; 
        delete curr;        
    }
}

/*
 * name:      operator=
 * purpose:   Assigns one CharLinkedList to another.
 * arguments: 'other' - The CharLinkedList to assign from.
 * returns:   Reference to the updated CharLinkedList.
 * effects:   Copies data from 'other' to this instance.
 */
CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other)
{
    if (this == &other) 
    {
        return *this;
    }

    Node *other_curr = other.front;
    while (other_curr != nullptr)
    {
        pushAtBack(other_curr->data);
        other_curr = other_curr->next;
    }
    cSize = other.cSize;

    return *this; 

}


/*
 * name:      size
 * purpose:   determine the number of items in the LinkedList.
 * arguments: none.
 * returns:   number of elements currently stored in the LinkedList.
 * effects:   none.
 */
int CharLinkedList::size() const
{
    return cSize;
}

/*
 * name:      isEmpty
 * purpose:   determines if the LinkedList is empty or not
 * arguments: none
 * returns:   true if LinkedList contains no elements, false otherwise
 * effects:   none
 */
bool CharLinkedList::isEmpty() const 
{
    return cSize == 0; 
}

/*
 * name:      clear
 * purpose:   Clears the list.
 * arguments: None.
 * returns:   None.
 * effects:   Sets cSize to 0.
 */
void CharLinkedList::clear()
{
    while (front != nullptr) 
    {
        Node *curr = front;     
        front = front->next; 
        delete curr;        
    }
    cSize = 0; 
}

/*
 * name:      first
 * purpose:   Gets the first character in the list.
 * arguments: None.
 * returns:   The first character.
 * effects:   Throws runtime_error if list is empty.
 */
char CharLinkedList::first() const 
{
    if (isEmpty())
    {
        throw runtime_error("cannot get first of empty LinkedList");
    }else
    {
        return front->data;
    }
}

/*
 * name:      last
 * purpose:   Gets the last character in the list.
 * arguments: None.
 * returns:   The last character.
 * effects:   Throws runtime_error if list is empty.
 */
char CharLinkedList::last() const 
{
    if (isEmpty())
    {
        throw runtime_error("cannot get last of empty LinkedList");
    }else
    {
        Node *curr = front;
        while (curr->next != nullptr)
        {
            curr = curr->next;
        }
        return curr->data;
    }
}

/*
 * name:      elementAt
 * purpose:   Gets the character at a specific index.
 * arguments: 'index' - Index of the element.
 * returns:   The character at the given index.
 * effects:   Throws range_error if index is out of range.
 */
char CharLinkedList::elementAt(int index) const 
{
    if (index < 0 or index >= cSize)
    {
        throw range_error("index (" + to_string(index) + ") not in range [0.." 
                            + to_string(cSize) + ")");
    }else
    {
        return elementAtRecursive(front, index, 0);
    }
}

/*
 * name:      elementAtRecursive
 * purpose:   Retrieves the character at a specified index using recursion.
 * arguments: 'curr' - Pointer to the current Node in the traversal.
 *            'index' - The target index for the character to retrieve.
 *            'curr_index' - The current index during recursion, starts at 0.
 * returns:   The character at the specified index.
 * effects:   Traverses the list recursively. 
 */

char CharLinkedList::elementAtRecursive(Node *curr, int index, 
                                        int curr_index) const 
{
    // Base case
    if (index == curr_index) {
        return curr->data;
    }
    // Recursive step: move to the next node
    return elementAtRecursive(curr->next, index, curr_index+1);
}

/*
 * name:      replaceAt
 * purpose:   Replaces the character at a specific index.
 * arguments: 'c' - The new character, 'index' - Index to replace at.
 * returns:   None.
 * effects:   Throws range_error if index is out of range.
 */
void CharLinkedList::replaceAt(char c, int index)
{
    if (index < 0 or index >= cSize)
    {
        throw range_error("index (" + to_string(index) + ") not in range [0.." 
                            + to_string(cSize) + ")");
    }

    replaceAtRecursive(front, index, c, 0);

}

/*
 * name:      replaceAtRecursive
 * purpose:   Replaces the character using recursion.
 * arguments: 'curr' - Pointer to the current node in the traversal.
 *            'index' - Target index where the character should be replaced.
 *            'value' - New character to replace at the target index.
 *            'curr_index' - Current index in the traversal, initialized to 0.
 * returns:   None.
 * effects:   Modifies the data of the node at the specified index to 
 *            the new value.
 */

void CharLinkedList::replaceAtRecursive(Node *curr, int index, char value, 
                                        int curr_index) 
{
    // Base case: if the current node is the target node
    if (index == curr_index) 
    {
        curr->data = value; 
        return;
    }
    // Recursive call to move to the next node
    return replaceAtRecursive(curr->next, index, value, curr_index+1);
}

/*
 * name:      pushAtFront
 * purpose:   push the provided integer into the front of the LinkedList.
 * arguments: an integer to add to the front of the list.
 * returns:   none.
 * effects:   increases num elements of LinkedList by 1,
 *            adds element to list.
 */
void CharLinkedList::pushAtFront(char c) 
{
    front = newNode(c, front, nullptr);
    cSize++;
}


/*
 * name:      pushAtBack
 * purpose:   push the provided integer into the back of the LinkedList.
 * arguments: an integer to add to the back of the list.
 * returns:   none.
 * effects:   increases num elements of LinkedList by 1,
 *            adds element to list.
 */
void CharLinkedList::pushAtBack(char c) 
{
    Node *new_node = newNode(c, nullptr, nullptr);
    if (front == nullptr) 
    {
        // If the list is empty, the new node becomes the front
        front = new_node;
    } else 
    {
        Node *curr = front;
        while (curr->next != nullptr) 
        {
            curr = curr->next;
        }
        new_node->prev = curr; 
        curr->next = new_node; 
    }
    cSize++;
    
}

/*
 * name:      insertAt
 * purpose:   Inserts a character at a specific index.
 * arguments: 'c' - The character to insert, 'index' - The index to insert at.
 * returns:   None.
 * effects:   Increases cSize by 1, shifts elements. Throws 
 *            range_error if index is out of range.
 */
void CharLinkedList::insertAt(char c, int index)
{
    if (index < 0 or index > cSize)
    {
        throw range_error("index (" + to_string(index) + ") not in range [0.." 
                            + to_string(cSize) + "]");
    }

    Node *new_node = newNode(c, nullptr, nullptr);

    //Insert at front
    if (index == 0) 
    {
        // If the list is empty, the new node becomes the front
        new_node->next = front; 

        if (front != nullptr)
        {
            front->prev = new_node;
        }
        front = new_node;
    } else
    {
        Node *curr = front;
        for (int i = 0; i < index-1; i++)
        {
            curr = curr->next;
        }
        
        new_node->next = curr->next; 
        if (new_node->next != nullptr) 
        { 
            new_node->next->prev = new_node; 
        }
        curr->next = new_node; 
        new_node->prev = curr; 
    }
    cSize++;
}


/*
 * name:      popFromFront
 * purpose:   Removes the first character from the list.
 * arguments: None.
 * returns:   None.
 * effects:   Decreases cSize by 1, shifts elements. Throws runtime_error if 
 *            list is empty.
 */
void CharLinkedList::popFromFront()
{
    if (isEmpty())
    {
        throw runtime_error("cannot pop from empty LinkedList");
    }else
    {
        Node *new_front = front;
        front = front->next;
        if (front != nullptr)
        {
            front->prev = nullptr;
        }
        delete new_front;

        cSize--;

    }   
}

/*
 * name:      popFromBack
 * purpose:   Removes the last character from the list.
 * arguments: None.
 * returns:   None.
 * effects:   Decreases cSize by 1. Throws runtime_error if list is empty.
 */
void CharLinkedList::popFromBack()
{
    if (isEmpty())
    {
        throw runtime_error("cannot pop from empty LinkedList");
    }

    if (front->next == nullptr)
    {
        delete front;
        front = nullptr;
    }else
    {
        Node *curr = front;
        // Traverse to the second-to-last node
        while (curr->next->next != nullptr) 
        {
            curr = curr->next;
        }
        delete curr->next; 
        curr->next = nullptr; 
    }
    cSize--;
}

/*
 * name:      removeAt
 * purpose:   Removes the character at a specific index.
 * arguments: 'index' - The index of the character to remove.
 * returns:   None.
 * effects:   Decreases cSize by 1, shifts elements. Throws range_error if 
 *            index is out of range.
 */
void CharLinkedList::removeAt(int index)
{
    if (index < 0 or index >= cSize)
    {
        throw range_error("index (" + to_string(index) + ") not in range [0.." 
                            + to_string(cSize) + ")");
    }

    if (index == 0)
    {
        Node *new_front = front;
        front = front->next;
        if (front != nullptr)
        {
            front->prev = nullptr;
        }
        delete new_front;
    } else
    {
        Node *curr = front;
        for (int i = 0; i < index -1; i++)
        {
            curr = curr->next;
        }
        Node *delete_node = curr->next;
        Node* nextNode = delete_node->next;
        curr->next = nextNode; 
        if (nextNode != nullptr) 
        { 
            nextNode->prev = curr;
        }
        delete delete_node;   
    }
    cSize--;
}

/*
 * name:      toString
 * purpose:   Report the state of the list as a string
 * arguments: None.
 * returns:   String representation of the list.
 * effects:   None.
 */
std::string CharLinkedList::toString() const
{
    std::stringstream ss;
    ss << "[CharLinkedList of size " << cSize;
    if (isEmpty())
    {
        ss << " <<>>]";
    }else
    {
        ss << " <<";
        Node *curr = front;
        for (int i = 0; i < cSize; i++)
        {
            ss << curr->data;
            curr = curr->next;
        }
        ss << ">>]";
    }
    return ss.str();
}

/*
 * name:      toReverseString
 * purpose:   Creates a reverse string representation of the list.
 * arguments: None.
 * returns:   Reverse string representation of the list.
 * effects:   None.
 */
std::string CharLinkedList::toReverseString() const
{
    std::stringstream ss;
    ss << "[CharLinkedList of size " << cSize;
    if (isEmpty())
    {
        ss << " <<>>]";
    }else
    {
        ss << " <<";
        Node* curr = front;
        // find the last node
        while (curr->next != nullptr) 
        {
            curr = curr->next;
        }
        // curr is at the last node, traverse back to front
        while (curr != nullptr) 
        {
            ss << curr->data;
            curr = curr->prev; 
        }
        ss << ">>]";
    }
    return ss.str();
}

/*
 * name:      insertInOrder
 * purpose:   Inserts a character in a sorted order.
 * arguments: 'c' - The character to insert.
 * returns:   None.
 * effects:   Increases cSize by 1, inserts in sorted 
 *            position.
 */
void CharLinkedList::insertInOrder(char c) 
{
    Node* new_node = newNode(c, nullptr, nullptr);
    // Empty list or insert at the front 
    if (front == nullptr or c < front->data) 
    {
        new_node->next = front;
        if (front != nullptr) 
        {
            front->prev = new_node;
        }
        front = new_node;
    } else 
    {
        Node* curr = front;
        // Find the correct insertion point
        while (curr->next != nullptr and c > curr->next->data) 
        {
            curr = curr->next;
        }

        new_node->next = curr->next;
        if (curr->next != nullptr) 
        {
            curr->next->prev = new_node;
        }
        curr->next = new_node;
        new_node->prev = curr;
    }
    cSize++;
}




/*
 * name:      concatenate
 * purpose:   Appends another CharLinkedList to this list.
 * arguments: 'other' - The CharLinkedList to append.
 * returns:   None.
 * effects:   Increases cSize by the size of 'other', appends elements.
 */
void CharLinkedList::concatenate(CharLinkedList *other) 
{
    if (other == nullptr or other->cSize == 0) 
    {
        return; 
    }

    if (this == other) 
    {
        CharLinkedList temp(*other);
        concatenate(&temp); 
        return;
    }

    Node *other_curr = other->front;
    while (other_curr != nullptr)
    {
        this->pushAtBack(other_curr->data);
        other_curr = other_curr->next;
    }
}




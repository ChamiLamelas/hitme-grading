/*
 *  unit_tests.h
 *  Yue Ma
 *  02/02/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 * Uses Matt Russell's unit_test framework to test the CharLinkedList class.
 *
 */

#include "CharLinkedList.h"
#include <cassert>
#include <iostream>
#include <string>
#include <stdexcept>

using namespace std;

/*
 * constructor test 0
 * Make sure no fatal errors/memory leaks in the default constructor
 */
void constructor_test_0() 
{
    CharLinkedList list;
}

/*
 * constructor test 1
 * Checks that a new list is initially empty.
 */
void constructor_test_1() 
{
    CharLinkedList list; 
    assert(list.size() == 0);
}

/*
 * constructor test 2
 * Tests initialization with a single character.
 */
void constructor_test_2() 
{
    CharLinkedList list('A'); 
    assert(list.size() == 1);
    assert(list.elementAt(0) == 'A');
}

/*
 * constructor test 3
 * Verifies initialization with a linkedlist of characters reflects the correct 
 * size.
 */
void constructor_test_3() 
{
    char arr[5] = {'A','B','C','D','E'};
    int cSize = 5;
    CharLinkedList list(arr, cSize);
    assert(list.size() == 5);
    assert(list.elementAt(4) == 'E');
}

/*
 * Verifies empty array initialization results in an empty list.
 */
void constructor_empty_test_3() 
{
    char arr[0] = {};
    int cSize = 0;
    CharLinkedList list(arr, cSize);
    assert(list.size() == 0);
}

/*
 * Ensures single-element array initialization is correct.
 */
void constructor_singleton_test_3() 
{
    char arr[1] = {'A'};
    int cSize = 1;
    CharLinkedList list(arr, cSize);
    assert(list.size() == 1);
    assert(list.elementAt(0) == 'A');
}

/*
 * copy_constructor_test
 * Ensures the copy constructor accurately duplicates the list and changes to 
 * the original list do not affect the copied list.
 */
void copy_constructor_test() 
{
    char arr[5] = {'A','B','C','D','E'};
    int cSize = 5;
    CharLinkedList list(arr, cSize);

    CharLinkedList copiedList(list);

    for (int i = 0; i < list.size(); i++) 
    {
        assert(copiedList.elementAt(i) == list.elementAt(i));
    }

    list.replaceAt('Z', 0);
    assert(copiedList.elementAt(0) != 'Z');
}

// Tests the assignment operator for deep copying and independence from the 
// original list.
void assignment_operator_test() 
{
    char arr[5] = {'A','B','C','D','E'};
    int cSize = 5;
    CharLinkedList list(arr, cSize);

    CharLinkedList newList = list;

    for (int i = 0; i < list.size(); i++) 
    {
        assert(newList.elementAt(i) == list.elementAt(i));
    }

    list.replaceAt('Z', 0);
    assert(newList.elementAt(0) != 'Z'); 
}

// Confirms that the size method correctly reports the number of elements 
// in the list.
void size_test() 
{
    CharLinkedList list;
    assert(list.size() == 0);
}


// Make sure we report an empty list correctly.
void isEmpty_test() 
{
    CharLinkedList list;
    assert(list.isEmpty());
}

// Verifies that clear effectively empties the list.
void clear_test() 
{
    CharLinkedList list;
    assert(list.isEmpty());
}

// Tests retrieving the first element from a populated list.
void first_test() 
{
    char arr[5] = {'A','B','C','D','E'};
    int cSize = 5;
    CharLinkedList list(arr, cSize);
    assert(list.first() == 'A');
}

// Ensures calling first on an empty list throws a runtime error.
void first_empty_incorrect() 
{
    // track whether range_error is thrown
    bool runtime_error_thrown = false;

    // track any error messages raised
    std::string error_message = "";

    CharLinkedList list;
    try 
    {
    list.first();
    }
    catch (const std::runtime_error &e) 
    {
    // if insertAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    runtime_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(runtime_error_thrown);
    assert(error_message == "cannot get first of empty LinkedList");
}

// Checks retrieval of the last element in a list.
void last_test() 
{
    char arr[5] = {'A','B','C','D','E'};
    int cSize = 5;
    CharLinkedList list(arr, cSize);
    assert(list.last() == 'E');
}

// Ensures calling last on an empty list throws a runtime error.
void last_empty_incorrect() 
{
    // var to track whether range_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList list;
    try 
    {
    list.last();
    }
    catch (const std::runtime_error &e) 
    {
    // if insertAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    runtime_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(runtime_error_thrown);
    assert(error_message == "cannot get last of empty LinkedList");
}

// Validates correct element access at a specific index.
void element_at_test()
{
    char arr[5] = {'A','B','C','D','E'};
    int cSize = 5;
    CharLinkedList list(arr, cSize);
    assert(list.elementAt(3) == 'D');

}

// Confirms element access accuracy while adding elements.
void elementAt_while_adding_test()
{
    char arr[5] = {'A','B','C','D','E'};
    int cSize = 5;
    CharLinkedList list(arr, cSize);
    list.pushAtFront('C');
    assert(list.elementAt(3) == 'C');
    assert(list.elementAt(0) == 'C');
}

//  Tests error handling for out-of-range access.
void element_not_at_range_incorrect()
{
    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    char arr[5] = {'A','B','C','D','E'};
    int cSize = 5;
    CharLinkedList list(arr, cSize);
    try 
    {
    list.elementAt(6);
    }
    catch (const std::range_error &e) 
    {
    // if insertAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    range_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (6) not in range [0..5)");
}

//  Verifies replacement of elements at specific indices.
void replace_at_test()
{
    char arr[5] = {'A','B','C','D','E'};
    int cSize = 5;
    CharLinkedList list(arr, cSize);
    list.replaceAt('O', 3);
    assert(list.elementAt(3) == 'O');
}

//  Tests replacement in a single-element list.
void replace_at_single_test()
{
    CharLinkedList list('A'); 
    list.replaceAt('O', 0);
    assert(list.first() == 'O');
}

// Ensures error handling for out-of-range replacement.
void replace_not_at_range_incorrect()
{

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    char arr[5] = {'A','B','C','D','E'};
    int cSize = 5;
    CharLinkedList list(arr, cSize);
    try 
    {
    list.replaceAt('O', 6);
    }
    catch (const std::range_error &e) 
    {
    // if insertAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    range_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (6) not in range [0..5)");
}

//  Checks adding elements to the front.
void pushAtFront_test() 
{
    char arr[5] = {'A','B','C','D','E'};
    int cSize = 5;
    CharLinkedList list(arr, cSize);
    list.pushAtFront('C');
    assert(list.elementAt(2) == 'B');
}

// Tests front insertion into a larger list.
void pushAtFront_from_large_list() 
{
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    test_list.pushAtFront('y');

    assert(test_list.size() == 10);
    assert(test_list.elementAt(0) == 'y');
    assert(test_list.toString() == 
    "[CharLinkedList of size 10 <<yabczdefgh>>]");
}

//  Validates front insertion with many elements.
void pushAtFront2_many_elements() 
{
    
    CharLinkedList test_list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        test_list.pushAtFront('a');
    }

    assert(test_list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
    
}

// Confirms adding elements to the back.
void pushAtBack_test() 
{
    char arr[5] = {'A','B','C','D','E'};
    int cSize = 5;
    CharLinkedList list(arr, cSize);
    list.pushAtBack('C');
    assert(list.last() == 'C');
}

// Tests inserting elements at specific indices.
void insert_at_test()
{
    char arr[5] = {'A','B','C','D','E'};
    int cSize = 5;
    CharLinkedList list(arr, cSize);
    list.insertAt('O', 4);
    assert(list.elementAt(4) == 'O');
}

// Ensures error handling for out-of-range insertion.
void insert_not_at_range_test()
{
    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    char arr[5] = {'A','B','C','D','E'};
    int cSize = 5;
    CharLinkedList list(arr, cSize);
    try 
    {
    list.insertAt('O', 7);
    }
    catch (const std::range_error &e) 
    {
    // if insertAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    range_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (7) not in range [0..5]");
    
}

// Verifies removal of the last element.
void pop_back_test() 
{
    char arr[5] = {'A','B','C','D','E'};
    int cSize = 5;
    CharLinkedList list(arr, cSize);
    list.popFromBack();
    assert(list.last() == 'D');
}

//  Tests popping back in a single-element list.
void pop_back_single_test(){
    CharLinkedList list('A'); 
    list.popFromBack();
    assert(list.isEmpty());
    
}

// Ensures error handling when popping back in an empty list.
void pop_back_empty_incorrect() 
{
    // var to track whether range_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList list;
    try 
    {
    list.popFromBack();
    }
    catch (const std::runtime_error &e)
    {
    // if insertAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    runtime_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

// Checks removal of the first element.
void pop_front_test() 
{
    char arr[5] = {'A','B','C','D','E'};
    int cSize = 5;
    CharLinkedList list(arr, cSize);
    list.popFromFront();
    assert(list.first() == 'B');
}

//Tests popping front in a single-element list.
void pop_front_single_test(){
    CharLinkedList list('A'); 
    list.popFromFront();
    assert(list.isEmpty());

}

// Ensures error handling when popping front in an empty list.
void pop_front_empty_incorrect() 
{
    // var to track whether range_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList list;
    try 
    {
    list.popFromFront();
    }
    catch (const std::runtime_error &e) 
    {
    // if insertAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    runtime_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

//  Validates removal of elements at specific indices.
void remove_at_test() 
{
    char arr[5] = {'A','B','C','D','E'};
    int cSize = 5;
    CharLinkedList list(arr, cSize);
    list.removeAt(2);
    assert(list.size() == 4);
    assert(list.elementAt(2) == 'D');
}

//  Tests removal in a single-element list.
void remove_single_test(){
    CharLinkedList list('A'); 
    list.removeAt(0);
    assert(list.isEmpty());
}

// Ensures error handling for out-of-range removal.
void remove_not_at_range_test()
{
    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    char arr[5] = {'A','B','C','D','E'};
    int cSize = 5;
    CharLinkedList list(arr, cSize);
    try 
    {
    list.removeAt(7);
    }
    catch (const std::range_error &e) 
    {
    // if insertAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    range_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (7) not in range [0..5)");
    
}

// Checks string representation of the list.
void to_string_test() 
{
    char arr[5] = {'A','B','C','D','E'};
    int cSize = 5;
    CharLinkedList list(arr, cSize);
    assert(list.toString() == "[CharLinkedList of size 5 <<ABCDE>>]");
}

// Verifies string representation of an empty list.
void to_string_empty_test() 
{
    CharLinkedList list;
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}

// Tests reverse string representation.
void to_reverse_string_test()
{
    char arr[5] = {'A','B','C','D','E'};
    int cSize = 5;
    CharLinkedList list(arr, cSize);
    assert(list.toReverseString() == "[CharLinkedList of size 5 <<EDCBA>>]");
}

// reverse string representation of an empty list.
void to_reverse_string_empty_test()
{
    CharLinkedList list;
    assert(list.toReverseString() == "[CharLinkedList of size 0 <<>>]");
}

//  Validates ordered insertion.
void insert_in_order_test()
{
    char arr[5] = {'A','B','D','E','F'};
    int cSize = 5;
    CharLinkedList list(arr, cSize);
    list.insertInOrder('C');
    assert(list.elementAt(2) == 'C');
    assert(list.elementAt(3) == 'D');
}

// Tests ordered insertion into an empty list.
void insert_in_order_empty_test() 
{
    CharLinkedList list;
    list.insertInOrder('C');
    assert(list.elementAt(0) == 'C');
}

//  Checks ordered insertion at the front.
void insert_in_order_front_test() 
{
    char arr[5] = {'B','D','E','F','G'};
    int cSize = 5;
    CharLinkedList list(arr, cSize);
    list.insertInOrder('A');
    assert(list.elementAt(0) == 'A');
    assert(list.elementAt(1) == 'B');
}

// Verifies ordered insertion at the back.
void insert_in_order_back_test()
{
    char arr[5] = {'A','B','C','D','E'};
    int cSize = 5;
    CharLinkedList list(arr, cSize);
    list.insertInOrder('F');
    assert(list.elementAt(5) == 'F');
    assert(list.elementAt(4) == 'E');
}

// Tests concatenation with another list.
void concatenate_test()
{
    char arr1[5] = {'A','B','C','D','E'};
    CharLinkedList list1(arr1, 5);
    char arr2[4] = {'F','G','H','I'};
    CharLinkedList list2(arr2, 4);
    list1.concatenate(&list2);
    assert(list1.size() == 9); 
    assert(list1.elementAt(7) == 'H'); 
}

// Ensures correct behavior when concatenating with an empty list.
void concatenate_empty_test()
{
    CharLinkedList list1;
    CharLinkedList list2;
    int originalSize = list1.size();
    list1.concatenate(&list2);
    assert(list1.size() == originalSize);
    assert(list1.isEmpty());

}

// Validates concatenation behavior when the initial list is empty.
void concatenate_former_empty_test()
{
    char arr1[5] = {'A','B','C','D','E'};
    CharLinkedList list1(arr1, 5);
    CharLinkedList list;
    int originalSize = list1.size();
    list.concatenate(&list1);
    assert(list.size() == 5);

}

// Checks behavior when concatenating an empty list to a populated one.
void concatenate_latter_empty_test()
{
    char arr1[5] = {'A','B','C','D','E'};
    CharLinkedList list1(arr1, 5);
    CharLinkedList list;
    int originalSize = list1.size();
    list1.concatenate(&list);
    assert(list1.size() == originalSize);

}

// Tests self-concatenation.
void concatenate_double_test()
{
    char arr2[4] = {'F','G','H','I'};
    CharLinkedList list2(arr2, 4);

    // Concatenating list with itself 
    list2.concatenate(&list2);
    assert(list2.size() == 8);
}

/********************************************************************\
*                       CHAR Linked LIST TESTS                        *
\********************************************************************/

/* To give an example of thorough testing, we are providing
 * the unit tests below which test the insertAt function. Notice: we have
 * tried to consider all of the different cases insertAt may be
 * called in, and we test insertAt in conjunction with other functions!
 *
 * You should emulate this approach for all functions you define.
 */

// Tests correct insertion into an empty AL.
// Afterwards, size should be 1 and element at index 0
// should be the element we inserted.
void insertAt_empty_correct() 
{ 
    CharLinkedList test_list;
    test_list.insertAt('a', 0);
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');

}

// Tests incorrect insertion into an empty AL.
// Attempts to call insertAt for index larger than 0.
// This should result in an std::range_error being raised.
void insertAt_empty_incorrect() 
{

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try 
    {
    // insertAt for out-of-range index
    test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) 
    {
    // if insertAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    range_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0]");
    
}

// Tests correct insertAt for front of 1-element list.
void insertAt_front_singleton_list() 
{
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at front
    test_list.insertAt('b', 0);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'a');
    
}

// Tests correct insertAt for back of 1-element list.
void insertAt_back_singleton_list() 
{
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at back
    test_list.insertAt('b', 1);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    
}


// Tests calling insertAt for a large number of elements.
void insertAt_many_elements() 
{
    
    CharLinkedList test_list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.insertAt('a', i);
    }

    assert(test_list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
    
}

// Tests insertion into front of a larger list
void insertAt_front_large_list() 
{
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    test_list.insertAt('y', 0);

    assert(test_list.size() == 10);
    assert(test_list.elementAt(0) == 'y');
    assert(test_list.toString() == 
    "[CharLinkedList of size 10 <<yabczdefgh>>]");
}

// Tests insertion into the back of a larger list
void insertAt_back_large_list() 
{

    char test_arr[10] = { 'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 10);  

    test_list.insertAt('x', 10);

    assert(test_list.size() == 11);
    assert(test_list.elementAt(10) == 'x');
    assert(test_list.toString() == 
    "[CharLinkedList of size 11 <<yabczdefghx>>]"); 

}

// Tests insertion into the middle of a larger list
void insertAt_middle_large_list() 
{
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.insertAt('z', 3);

    assert(test_list.size() == 9);
    assert(test_list.elementAt(3) == 'z');
    assert(test_list.toString() == "[CharLinkedList of size 9 <<abczdefgh>>]");

}

// Tests out-of-range insertion for a non-empty list.
void insertAt_nonempty_incorrect() 
{
   
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try 
    {
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) 
    {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8]");
    
}

//  Confirms that removing the only element in a single-item list results 
//  in an empty list.
void single_element_removal_test() 
{
    CharLinkedList list('A');
    list.popFromBack();
    assert(list.isEmpty());
}

// Validates that a list can be cleared of its contents and subsequently 
// reused for new elements.
void clear_and_reuse_test() 
{
    CharLinkedList list;
    list.pushAtBack('X');
    list.clear();
    assert(list.isEmpty());

    list.pushAtBack('Y');
    assert(list.size() == 1);
    assert(list.first() == 'Y');
}

// Tests functionality and assertions for a list initialized with a single 
// element, including correct size and behavior upon element removal.
void single_element_test() 
{
    CharLinkedList list('A');
    assert(list.size() == 1);
    assert(list.first() == 'A');
    assert(list.last() == 'A');

    list.popFromBack();
    assert(list.isEmpty());
}




/*
 * CharLinkedList.h
 * Hengxu Li
 * 2/6/2024
 *
 * CS 15 HW 2 hw_linkedlists
 * Defines the CharLinkedList class,
 * which implements a doubly linked list for storing characters.
 */

#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H

#include <stdexcept>
#include <string>

// Represents a doubly linked list for storing characters
class CharLinkedList {
public:

    // Default constructor initializes an empty list
    CharLinkedList();

    // Initializes a list with a single character
    CharLinkedList(char c);

    // Initializes a list from an array of characters
    CharLinkedList(char arr[], int size);

    // Copy constructor for deep copying
    CharLinkedList(const CharLinkedList &other);

    // Destructor to free allocated memory
    ~CharLinkedList();

    // Assignment operator for deep copying
    CharLinkedList &operator=(const CharLinkedList &other);

    // Utility methods
    // Checks if the list is empty
    bool isEmpty() const;

    // Clears the list
    void clear(); 

    // Returns the number of elements in the list
    int size() const;

    // Returns the first element
    char first() const;

    // Returns the last element
    char last() const;

    // Returns the element at the given index
    char elementAt(int index) const;

    // Returns a string representation of the list
    std::string toString() const;

    // Returns a string representation of the list in reverse order
    std::string toReverseString() const;

    // Adds an element to the end of the list
    void pushAtBack(char c);

    // Adds an element to the front of the list
    void pushAtFront(char c);

    // Inserts an element at the specified index
    void insertAt(char c, int index);

    // Inserts an element in ascending order
    void insertInOrder(char c);

    // Removes the first element
    void popFromFront();

    // Removes the last element
    void popFromBack();

    // Removes the element at the specified index
    void removeAt(int index);

    // Replaces the element at the specified index
    void replaceAt(char c, int index);

    // Concatenates another list to the end of this list
    void concatenate(CharLinkedList *other);

private:

    // Node structure for the doubly linked list
    struct Node {
        char data;
        Node* prev;
        Node* next;
        Node(char data, Node* prev = nullptr, Node* next = nullptr)
            : data(data), prev(prev), next(next) {}
    };

    Node* head; // Pointer to the first node
    Node* tail; // Pointer to the last node
    int listSize; // Number of elements in the list

    // Helper functions
    // For deep copying
    void deepCopy(const CharLinkedList &other);

    // For accessing a node at a given index
    Node* getNodeAt(int index) const;

    // For the destructor
    void clearListRecursively(Node* node);

    // For elementAt
    char elementAtRecursively(Node* node, int index) const;

    // For replaceAt
    void replaceAtRecursively(Node* node, char c, int index);

    // For toReverseString
    std::string toReverseStringRecursively(Node* node) const;
};

#endif // CHAR_LINKED_LIST_H

/*
 *  unit_tests.h
 *  Hengxu Li
 *  2/6/2024
 *
 *  CS 15 HW 2 hw_linkedlists
 *
 *  Uses Matt Russell's unit_test framework to test the CharLinkedList class.
 *
 */
#include <cassert>
#include <stdexcept>
#include <string>
#include "CharLinkedList.h"

/********************************************************************\
*                       CHAR LINKED LIST TESTS                       *
\********************************************************************/

// Tests default constructor by checking if a new list is empty
void test_DefaultConstructor() {
    CharLinkedList testList;
    assert(testList.isEmpty());
}

// Tests single character constructor by checking the size and the first element
void test_SingleCharConstructor() {
    CharLinkedList testList('a');
    assert(not testList.isEmpty());
    assert(testList.size() == 1);
    assert(testList.first() == 'a');
}

// Tests array constructor with non-empty array
void test_ArrayConstructor_NonEmpty() {
    char arr[] = {'a', 'b', 'c'};
    CharLinkedList testList(arr, 3);
    assert(testList.size() == 3);
    assert(testList.elementAt(1) == 'b');
}

// Tests array constructor with empty array
void test_ArrayConstructor_Empty() {
    char arr[] = {};
    CharLinkedList testList(arr, 0);
    assert(testList.isEmpty());
}

// Tests copy constructor for deep copy
void test_CopyConstructor() {
    CharLinkedList originalList;
    originalList.pushAtBack('a');
    CharLinkedList copiedList(originalList);
    originalList.popFromFront(); // Modify original after copying

    assert(copiedList.size() == 1);
    assert(copiedList.first() == 'a');
}

// Tests assignment operator for deep copy
void test_AssignmentOperator() {
    CharLinkedList list1;
    list1.pushAtBack('x');
    CharLinkedList list2 = list1;
    list1.popFromFront(); // Modify list1 after copying

    assert(list2.size() == 1);
    assert(list2.first() == 'x');
}

// Tests isEmpty on an empty list
void test_isEmpty_True() {
    CharLinkedList testList;
    assert(testList.isEmpty());
}

// Tests isEmpty on a non-empty list
void test_isEmpty_False() {
    CharLinkedList testList('a');
    assert(not testList.isEmpty());
}

// Tests clear on a non-empty list
void test_Clear() {
    CharLinkedList testList;
    testList.pushAtBack('a');
    testList.clear();
    assert(testList.isEmpty());
}

// Tests size on a list with multiple elements
void test_Size_MultipleElements() {
    CharLinkedList testList;
    testList.pushAtBack('a');
    testList.pushAtBack('b');
    assert(testList.size() == 2);
}

// Tests first on a non-empty list
void test_First_NonEmpty() {
    CharLinkedList testList('a');
    assert(testList.first() == 'a');
}

// Tests last on a non-empty list
void test_Last_NonEmpty() {
    CharLinkedList testList;
    testList.pushAtBack('a');
    testList.pushAtBack('b');
    assert(testList.last() == 'b');
}

// Tests elementAt with valid index
void test_ElementAt_ValidIndex() {
    CharLinkedList testList;
    testList.pushAtBack('a');
    testList.pushAtBack('b');
    assert(testList.elementAt(1) == 'b');
}

// Tests pushAtBack by adding elements and checking size and last element
void test_PushAtBack() {
    CharLinkedList testList;
    testList.pushAtBack('a');
    testList.pushAtBack('b');
    assert(testList.size() == 2);
    assert(testList.last() == 'b');
}

// Tests pushAtFront by adding elements and checking size and first element
void test_PushAtFront() {
    CharLinkedList testList;
    testList.pushAtFront('b');
    testList.pushAtFront('a');
    assert(testList.size() == 2);
    assert(testList.first() == 'a');
}

// Tests insertAt in the middle of a list
void test_InsertAt_Middle() {
    CharLinkedList testList;
    testList.pushAtBack('a');
    testList.pushAtBack('c');
    testList.insertAt('b', 1);
    assert(testList.elementAt(1) == 'b');
}

// Tests popFromFront by removing the first element
// and checking the new first element
void test_PopFromFront() {
    CharLinkedList testList;
    testList.pushAtBack('a');
    testList.pushAtBack('b');
    testList.popFromFront();
    assert(testList.first() == 'b');
}

// Tests popFromBack by removing the last element
// and checking the new last element
void test_PopFromBack() {
    CharLinkedList testList;
    testList.pushAtBack('a');
    testList.pushAtBack('b');
    testList.popFromBack();
    assert(testList.last() == 'a');
}

// Tests removeAt by removing an element from the middle and checking size
void test_RemoveAt_Middle() {
    CharLinkedList testList;
    testList.pushAtBack('a');
    testList.pushAtBack('b');
    testList.pushAtBack('c');
    testList.removeAt(1); // Remove 'b'
    assert(testList.size() == 2);
    assert(testList.elementAt(1) == 'c');
}

// Tests replaceAt by replacing an element and checking the new value
void test_ReplaceAt() {
    CharLinkedList testList;
    testList.pushAtBack('a');
    testList.pushAtBack('b');
    testList.replaceAt('z', 1);
    assert(testList.elementAt(1) == 'z');
}

// Tests concatenate with a non-empty list
void test_Concatenate_NonEmpty() {
    CharLinkedList list1;
    CharLinkedList list2;
    list1.pushAtBack('a');
    list2.pushAtBack('b');
    list1.concatenate(&list2);
    assert(list1.size() == 2);
    assert(list1.last() == 'b');
}

void test_ToString_Empty() {
    CharLinkedList list;
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}

void test_ToString_MultipleElements() {
    char arr[] = {'C', 'O', 'M', 'P', ' ', '1', '5'};
    CharLinkedList list(arr, 7);
    assert(list.toString() == "[CharLinkedList of size 7 <<COMP 15>>]");
}

void test_ToReverseString_Empty() {
    CharLinkedList list;
    assert(list.toReverseString() == "[CharLinkedList of size 0 <<>>]");
}

void test_ToReverseString_MultipleElements() {
    char arr[] = {'A', 'l', 'i', 'c', 'e'};
    CharLinkedList list(arr, 5);
    assert(list.toReverseString() == "[CharLinkedList of size 5 <<ecilA>>]");
}

/*
 * CharLinkedList.cpp
 * Hengxu Li
 * 2/6/2024
 *
 * CS 15 HW 2 hw_linkedlists
 * Implements the CharLinkedList class functions.
 */

#include "CharLinkedList.h"

/**
 * Default constructor.
 * Initializes an empty CharLinkedList.
 */
CharLinkedList::CharLinkedList()
    : head(nullptr), tail(nullptr), listSize(0) {}

/**
 * Single character constructor.
 * Initializes a CharLinkedList with a single character.
 *
 * @param c The character to initialize the list with.
 */
CharLinkedList::CharLinkedList(char c)
    : head(new Node(c)), tail(head), listSize(1) {}

/**
 * Array constructor.
 * Initializes a CharLinkedList from an array of characters.
 *
 * @param arr The array of characters to initialize the list from.
 * @param size The number of elements in the array.
 */
CharLinkedList::CharLinkedList(char arr[], int size) 
    : head(nullptr), tail(nullptr), listSize(0) {
    for (int i = 0; i < size; ++i) {
        pushAtBack(arr[i]);
    }
}

/**
 * Copy constructor.
 * Creates a deep copy of another CharLinkedList.
 *
 * @param other The CharLinkedList to copy from.
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other) 
    : head(nullptr), tail(nullptr), listSize(0) {
    deepCopy(other);
}

/**
 * Destructor.
 * Frees all allocated memory associated with the CharLinkedList.
 */
CharLinkedList::~CharLinkedList() {
    clearListRecursively(head); // Clear the current list
    head = tail = nullptr; // Reset head and tail pointers
}

/**
 * Assignment operator.
 * Replaces the contents of this CharLinkedList with a deep copy of another.
 *
 * @param other The CharLinkedList to copy from.
 * @return A reference to this CharLinkedList.
 */
CharLinkedList& CharLinkedList::operator=(const CharLinkedList &other) {
    if (this != &other) {
        clearListRecursively(head); // Clear the current list
        head = tail = nullptr; // Reset head and tail pointers
        listSize = 0; // Reset the size of the list
        deepCopy(other); // Deep copy the other list
    }
    return *this;
}

// Recursive helper for destructor to clear the list
void CharLinkedList::clearListRecursively(Node* node) {
    if (node) {
        clearListRecursively(node->next);
        delete node;
    }
}

// Deep copy another list
void CharLinkedList::deepCopy(const CharLinkedList &other) {
    Node* current = other.head;
    while (current != nullptr) {
        pushAtBack(current->data);
        current = current->next;
    }
}

// Helper function to access a node at a given index
CharLinkedList::Node* CharLinkedList::getNodeAt(int index) const {
    Node* current = head;
    for (int i = 0; i < index and current != nullptr; ++i) {
        current = current->next;
    }
    return current;
}

/**
 * Checks if the CharLinkedList is empty.
 *
 * @return True if the list is empty, false otherwise.
 */
bool CharLinkedList::isEmpty() const {
    return listSize == 0;
}

/**
 * Clears the CharLinkedList, removing all elements.
 */
void CharLinkedList::clear() {
    clearListRecursively(head); // Clear the list
    head = tail = nullptr; // Reset head and tail pointers
    listSize = 0; // Reset the size of the list
}

/**
 * Gets the number of elements in the CharLinkedList.
 *
 * @return The size of the list.
 */
int CharLinkedList::size() const {
    return listSize;
}

/**
 * Gets the first character in the CharLinkedList.
 *
 * @return The first character.
 * @throws std::runtime_error if the list is empty.
 */
char CharLinkedList::first() const {
    if (isEmpty()) {
        throw std::runtime_error("cannot get first of empty LinkedList");
    }
    return head->data;
}

/**
 * Gets the last character in the CharLinkedList.
 *
 * @return The last character.
 * @throws std::runtime_error if the list is empty.
 */
char CharLinkedList::last() const {
    if (isEmpty()) {
        throw std::runtime_error("cannot get last of empty LinkedList");
    }
    return tail->data;
}

/**
 * Gets the character at a specific position in the CharLinkedList.
 *
 * @param index The index of the character to retrieve.
 * @return The character at the specified index.
 * @throws std::range_error if the index is out of range.
 */
char CharLinkedList::elementAt(int index) const {
    if (index < 0 or index >= listSize) {
        throw std::range_error(
            "index (" + std::to_string(index) + 
            ") not in range [0.." + std::to_string(listSize) + ")"
        );
    }
    return elementAtRecursively(head, index);
}

// Recursive helper for elementAt
char CharLinkedList::elementAtRecursively(Node* node, int index) const {
    if (index == 0) return node->data;
    return elementAtRecursively(node->next, index - 1);
}

/**
 * Converts the CharLinkedList to a string representation.
 *
 * @return A string representing the CharLinkedList.
 */
std::string CharLinkedList::toString() const {
    std::string result =
        "[CharLinkedList of size " + std::to_string(listSize) + " <<";
    Node* current = head;
    while (current != nullptr) {
        result += current->data;
        current = current->next;
    }
    result += ">>]";
    return result;
}

/**
 * Converts the CharLinkedList to a string representation in reverse order.
 *
 * @return A string representing the CharLinkedList in reverse.
 */
std::string CharLinkedList::toReverseString() const {
    return "[CharLinkedList of size " + std::to_string(listSize) +
           " <<" + toReverseStringRecursively(head) + ">>]";
}

// Recursive helper for toReverseString
std::string CharLinkedList::toReverseStringRecursively(Node* node) const {
    if (not node) return "";
    std::string result = toReverseStringRecursively(node->next);
    result += node->data;
    return result;
}

/**
 * Adds a character to the back of the CharLinkedList.
 *
 * @param c The character to add.
 */
void CharLinkedList::pushAtBack(char c) {
    Node* newNode = new Node(c, tail, nullptr);
    if (isEmpty()) {
        head = tail = newNode;
    } else {
        tail->next = newNode;
        tail = newNode;
    }
    listSize++;
}

/**
 * Adds a character to the front of the CharLinkedList.
 *
 * @param c The character to add.
 */
void CharLinkedList::pushAtFront(char c) {
    Node* newNode = new Node(c, nullptr, head);
    if (isEmpty()) {
        head = tail = newNode;
    } else {
        head->prev = newNode;
        head = newNode;
    }
    listSize++;
}

/**
 * Inserts a character at a specified index in the CharLinkedList.
 *
 * @param c The character to insert.
 * @param index The index at which to insert the character.
 * @throws std::range_error if the index is out of range.
 */
void CharLinkedList::insertAt(char c, int index) {
    if (index < 0 or index > listSize) {
        throw std::range_error(
            "index (" + std::to_string(index) + 
            ") not in range [0.." + std::to_string(listSize) + "]"
        );
    }
    if (index == 0) {
        pushAtFront(c);
    } else if (index == listSize) {
        pushAtBack(c);
    } else {
        Node* nextNode = getNodeAt(index);
        Node* newNode = new Node(c, nextNode->prev, nextNode);
        nextNode->prev->next = newNode;
        nextNode->prev = newNode;
        listSize++;
    }
}

/**
 * Inserts a character into the CharLinkedList in sorted order.
 *
 * @param c The character to insert.
 */
void CharLinkedList::insertInOrder(char c) {
    if (isEmpty() or c < head->data) {
        pushAtFront(c);
    } else {
        Node* current = head;
        while (current->next != nullptr and current->next->data < c) {
            current = current->next;
        }
        Node* newNode = new Node(c, current, current->next);
        if (current->next != nullptr) {
            current->next->prev = newNode;
        } else {
            tail = newNode;
        }
        current->next = newNode;
        listSize++;
    }
}

/**
 * Removes the first character from the CharLinkedList.
 *
 * @throws std::runtime_error if the list is empty.
 */
void CharLinkedList::popFromFront() {
    if (isEmpty()) {
        throw std::runtime_error("cannot pop from empty LinkedList");
    }
    Node* temp = head;
    head = head->next;
    if (head != nullptr) {
        head->prev = nullptr;
    } else {
        tail = nullptr;
    }
    delete temp;
    listSize--;
}


/**
 * Removes the last character from the CharLinkedList.
 *
 * @throws std::runtime_error if the list is empty.
 */
void CharLinkedList::popFromBack() {
    if (isEmpty()) {
        throw std::runtime_error("cannot pop from empty LinkedList");
    }
    Node* temp = tail;
    tail = tail->prev;
    if (tail != nullptr) {
        tail->next = nullptr;
    } else {
        head = nullptr;
    }
    delete temp;
    listSize--;
}
/**
 * Removes the character at a specified index from the CharLinkedList.
 *
 * @param index The index of the character to remove.
 * @throws std::range_error if the index is out of range.
 */
void CharLinkedList::removeAt(int index) {
    if (index < 0 or index >= listSize) {
        throw std::range_error(
            "index (" + std::to_string(index) + 
            ") not in range [0.." + std::to_string(listSize) + ")"
        );
    }
    if (index == 0) {
        popFromFront();
    } else if (index == listSize - 1) {
        popFromBack();
    } else {
        Node* toRemove = getNodeAt(index);
        toRemove->prev->next = toRemove->next;
        toRemove->next->prev = toRemove->prev;
        delete toRemove;
        listSize--;
    }
}

/**
 * Replaces the character at a specified index with a new character.
 *
 * @param c The new character.
 * @param index The index of the character to replace.
 * @throws std::range_error if the index is out of range.
 */
void CharLinkedList::replaceAt(char c, int index) {
    if (index < 0 or index >= listSize) {
        throw std::range_error(
            "index (" + std::to_string(index) + 
            ") not in range [0.." + std::to_string(listSize) + ")"
        );
    }
    replaceAtRecursively(head, c, index);
}

// Recursive helper for replaceAt
void CharLinkedList::replaceAtRecursively(Node* node, char c, int index) {
    if (index == 0) {
        node->data = c;
    } else {
        replaceAtRecursively(node->next, c, index - 1);
    }
}

/**
 * Concatenates another CharLinkedList to the end of this list.
 *
 * @param other A pointer to the CharLinkedList to concatenate.
 */
void CharLinkedList::concatenate(CharLinkedList *other) {
    // Do nothing if the other list is empty
    if (other == nullptr or other->isEmpty()) return;

    // Handles self-concatenation by creating a copy to iterate over
    CharLinkedList temp = (this == other) ? CharLinkedList(*other) : *other;

    for (Node* current = temp.head; 
        current != nullptr; 
        current = current->next) {
        pushAtBack(current->data);
    }
}

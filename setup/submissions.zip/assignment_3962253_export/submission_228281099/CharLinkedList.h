/*
 *  CharLinkedList.h
 *  Victor Salcedo
 *  February 5, 2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Header file of a CharLinkedList in C++
 *
 */

#include <string>
#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H

class CharLinkedList {
public:
    // Default Constructor
    CharLinkedList();

    // Alternative Constructor
    CharLinkedList(char c);

    // Array Constructor
    CharLinkedList(char arr[], int size);

    // Copy Constructor
    CharLinkedList(const CharLinkedList &other);

    // Destructor
    ~CharLinkedList();

    // Overloaded assignment operator
    CharLinkedList &operator=(const CharLinkedList &other);

    // Main Methods
    bool isEmpty() const;
    void clear();
    int size() const;
    char first() const;
    char last() const;
    char elementAt(int index) const;
    std::string toString() const;
    std::string toReverseString() const;
    void pushAtBack(char c);
    void pushAtFront(char c);
    void insertAt(char c, int index);
    void insertInOrder(char c);
    void popFromFront();
    void popFromBack();
    void removeAt(int index);
    void replaceAt(char c, int index);
    void concatenate(CharLinkedList *other);

private:
    // Node Struct Declaration
    struct Node {
        Node *next;
        Node *previous;
        char data;
    };
    
    // Private Helper Funcitons
    void destructorHelper(Node *curr);
    char elementAtHelper(Node *curr, int index, int target) const;
    Node * singleElementHelper(char c);
    Node * singleElementPtrHelper(Node *previous, char c, Node *next);
    void addNodes(int num);
    void removeNodes(int num);
    Node * nodeAt(Node *front, int index, int tar);
    void replaceAtHelper(Node *curr, char c, int index, int target);

    Node *front;
    Node *back;
    int numElements;
};

#endif

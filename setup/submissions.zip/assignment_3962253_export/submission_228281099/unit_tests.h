/*
 *  unit_tests.h
 *  YOUR NAME HERE
 *  DATE CREATED
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  FILE PURPOSE HERE
 *
 */

#include <cassert>

#include "CharLinkedList.h"
#include <stdexcept>
#include <iostream>

/********************************************************************\
*                      Char Linked LIST TESTS                        *
\********************************************************************/

// Tests calling the default constructor.
// Should initialize an empty CharLinkedList
// with size 0 and no nodes.
void empty_constructor_test()
{
    CharLinkedList list;
    
    assert(list.isEmpty());
    assert(list.size() == 0);
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}

// Tests calling an alternative constructor.
// Makes a CharLinkedList of size 1 with a
// char provided by the user.
// Confirmation the constructor works for lists
// of size 1.
void single_element_constructor_test()
{
    CharLinkedList list = CharLinkedList('V');

    assert(not list.isEmpty());
    assert(list.size() == 1);
    assert(list.toString() == "[CharLinkedList of size 1 <<V>>]");
    assert(list.first() == 'V');
    assert(list.last() == 'V');
}

// Tests calling array based constructor
// Makes a CharLinkedList based on the contents
// of an array of chars and confirms the contents
// of the list is correct. Also confirmation that the
// destructor works for lists of various sizes.
void array_based_constructor_tests()
{
    char one[1] = {'V'};
    char two[2] = {'O', 'V'};
    char five[5] = {'W', 'A', 'T', 'E', 'R'};

    CharLinkedList list_one = CharLinkedList(one, 1);
    CharLinkedList list_two = CharLinkedList(two, 2);
    CharLinkedList list_five = CharLinkedList(five, 5);

    assert(not list_one.isEmpty());
    assert(list_one.size() == 1);
    assert(list_one.toString() == "[CharLinkedList of size 1 <<V>>]");
    assert(list_one.first() == 'V');
    assert(list_one.last() == 'V');

    assert(not list_two.isEmpty());
    assert(list_two.size() == 2);
    assert(list_two.toString() == "[CharLinkedList of size 2 <<OV>>]");
    assert(list_two.first() == 'O');
    assert(list_two.last() == 'V');

    assert(not list_five.isEmpty());
    assert(list_five.size() == 5);
    assert(list_five.toString() == "[CharLinkedList of size 5 <<WATER>>]");
    assert(list_five.first() == 'W');
    assert(list_five.last() == 'R');
}

// Tests calling the copy constructor.
// Creates lists of multiple sizes and
// makes new lists using them.
void copy_constructor_tests()
{
    char one[1] = {'V'};
    char two[2] = {'O', 'V'};
    char five[5] = {'W', 'A', 'T', 'E', 'R'};
    
    CharLinkedList empty;
    CharLinkedList list_one = CharLinkedList(one, 1);
    CharLinkedList list_two = CharLinkedList(two, 2);
    CharLinkedList list_five = CharLinkedList(five, 5);

    CharLinkedList empty_copy = CharLinkedList(empty);
    CharLinkedList list_one_copy = CharLinkedList(list_one);
    CharLinkedList list_two_copy = CharLinkedList(list_two);
    CharLinkedList list_five_copy = CharLinkedList(list_five);


    // Compares all copied lists with the lists used to make them
    assert(empty_copy.isEmpty() == empty.isEmpty());
    assert(empty_copy.size() == empty.size());
    assert(empty_copy.toString() == empty.toString());

    assert(list_one_copy.isEmpty() == list_one.isEmpty());
    assert(list_one_copy.size() == list_one.size());
    assert(list_one_copy.toString() == list_one.toString());
    assert(list_one_copy.first() == list_one.first());
    assert(list_one_copy.last() == list_one.last());

    assert(list_two_copy.isEmpty() == list_two.isEmpty());
    assert(list_two_copy.size() == list_two.size());
    assert(list_two_copy.toString() == list_two.toString());
    assert(list_two_copy.first() == list_two.first());
    assert(list_two_copy.last() == list_two.last());

    assert(list_five_copy.isEmpty() == list_five.isEmpty());
    assert(list_five_copy.size() == list_five.size());
    assert(list_five_copy.toString() == list_five.toString());
    assert(list_five_copy.first() == list_five.first());
    assert(list_five_copy.last() == list_five.last());
}

// Tests calling the overloaded assignment operator.
// Chekcs to make sure the assignment operator works
// on lists of various sizes. Ensures a deep copy is made 
// and not a shallow copy if there is no double free error.
void overloaded_assignment_operator_tests()
{
    // Test on empty lists
    CharLinkedList list_empty;
    CharLinkedList test_empty;

    list_empty = test_empty;

    // Test on lists of size one
    CharLinkedList list_one = CharLinkedList('Y');
    CharLinkedList test_one = CharLinkedList('N');

    list_one = test_one;

    // Test on larger lists
    char five[5] = {'a','b','c','d','e'};
    char test[5] = {'1','2','3','4','5'};
    CharLinkedList list_five = CharLinkedList(five, 5);
    CharLinkedList test_five = CharLinkedList(test, 5);

    list_five = test_five;

    assert(list_empty.isEmpty() == test_empty.isEmpty());
    assert(list_empty.size() == test_empty.size());
    assert(list_empty.toString() == test_empty.toString());

    assert(list_one.isEmpty() == test_one.isEmpty());
    assert(list_one.size() == test_one.size());
    assert(list_one.toString() == test_one.toString());
    assert(list_one.first() == test_one.first());
    assert(list_one.last() == test_one.last());

    assert(list_five.isEmpty() == test_five.isEmpty());
    assert(list_five.size() == test_five.size());
    assert(list_five.toString() == test_five.toString());
    assert(list_five.first() == test_five.first());
    assert(list_five.last() == test_five.last());
}

// Tests calling isEmpty method.
// Checks isEmpty method on CharLinkedLists
// of different sizes. Simultaneously checks
// the clear function.
void isEmpty_and_clear_tests()
{
    char test[5] = {'1','2','3','4','5'};

    CharLinkedList list_empty;
    CharLinkedList list_one = CharLinkedList('&');
    CharLinkedList list_five = CharLinkedList(test,5);

    assert(list_empty.isEmpty());
    assert(not list_one.isEmpty());
    assert(not list_five.isEmpty());

    list_empty.clear();
    list_one.clear();
    list_five.clear();

    assert(list_empty.isEmpty());
    assert(list_one.isEmpty());
    assert(list_five.isEmpty());
} 

// Tests calling the size method.
// This test uses the size method 
// on lists of varying sizes.
void size_tests()
{
    char test[5] = {'p','l','a','t','o'};
    CharLinkedList list_empty;
    CharLinkedList list_one = CharLinkedList('#');
    CharLinkedList list_five = CharLinkedList(test,5);

    assert(list_empty.size() == 0);
    assert(list_one.size() == 1);
    assert(list_five.size() == 5);
}

// Tests calling the first and last methods.
// This test uses the first and last methods
// on lists of different sizes.
void first_and_last_tests()
{
    char test[5] = {'p','l','a','t','o'};
    CharLinkedList list_empty;
    CharLinkedList list_one = CharLinkedList('#');
    CharLinkedList list_five = CharLinkedList(test,5);

    bool range_error_thrown_first = false;
    bool range_error_thrown_last = false;

    std::string error_message_first = "";
    std::string error_message_last = "";

    try
    {
        char c = list_empty.first();
    }
    catch(const std::runtime_error& e)
    {
        range_error_thrown_first = true;
        error_message_first = e.what();
    }

    try
    {
        char c = list_empty.last();
    }
    catch(const std::runtime_error& e)
    {
        range_error_thrown_last = true;
        error_message_last = e.what();
    }
    
    assert(range_error_thrown_first);
    assert(range_error_thrown_last);
    assert(error_message_first == "cannot get first of empty LinkedList");
    assert(error_message_last == "cannot get last of empty LinkedList");

    assert(list_one.first() == '#');
    assert(list_one.last() == '#');
    assert(list_five.first() == test[0]);
    assert(list_five.last() == test[4]);
}

// Tests calling the elementAt method.
// Makes sure the elementAt method 
// properly handles empty CharLinkedLists.
void empty_elementAt_tests()
{
    CharLinkedList list_empty;

    bool range_error_negative_num = false;
    bool range_error_positive_num = false;
    bool range_error_neg_one = false;
    bool range_error_zero = false;
    bool range_error_one = false;

    std::string error_message_nn = "";
    std::string error_message_pn = "";
    std::string error_message_no = "";
    std::string error_message_z = "";
    std::string error_message_o = "";

    try
    {
        char c = list_empty.elementAt(-5);
    }
    catch(const std::range_error& e)
    {
        range_error_negative_num = true;
        error_message_nn = e.what();
    }

    try
    {
        char c = list_empty.elementAt(10);
    }
    catch(const std::range_error& e)
    {
        range_error_positive_num = true;
        error_message_pn = e.what();
    }

    try
    {
        char c = list_empty.elementAt(-1);
    }
    catch(const std::range_error& e)
    {
        range_error_neg_one = true;
        error_message_no = e.what();
    }

    try
    {
        char c = list_empty.elementAt(0);
    }
    catch(const std::range_error& e)
    {
        range_error_zero = true;
        error_message_z = e.what();
    }

    try
    {
        char c = list_empty.elementAt(1);
    }
    catch(const std::range_error& e)
    {
        range_error_one = true;
        error_message_o = e.what();
    }
    
    assert(range_error_negative_num);
    assert(range_error_positive_num);
    assert(range_error_neg_one);
    assert(range_error_zero);
    assert(range_error_one);

    assert(error_message_nn == "index (-5) not in range [0..0)");
    assert(error_message_pn == "index (10) not in range [0..0)");
    assert(error_message_no == "index (-1) not in range [0..0)");
    assert(error_message_z == "index (0) not in range [0..0)");
    assert(error_message_o == "index (1) not in range [0..0)");
}

// Tests calling the elementAt method.
// Makes sure the elementAt method 
// properly handles CharLinkedLists if size 1.
void size_one_elementAt_tests()
{
    CharLinkedList list_one = CharLinkedList('B');

    bool range_error_negative_num = false;
    bool range_error_positive_num = false;
    bool range_error_neg_one = false;
    bool range_error_one = false;

    std::string error_message_nn = "";
    std::string error_message_pn = "";
    std::string error_message_no = "";
    std::string error_message_o = "";

    try
    {
        char c = list_one.elementAt(-4);
    }
    catch(const std::range_error& e)
    {
        range_error_negative_num = true;
        error_message_nn = e.what();
    }

    try
    {
        char c = list_one.elementAt(7);
    }
    catch(const std::range_error& e)
    {
        range_error_positive_num = true;
        error_message_pn = e.what();
    }

    try
    {
        char c = list_one.elementAt(-1);
    }
    catch(const std::range_error& e)
    {
        range_error_neg_one = true;
        error_message_no = e.what();
    }

    try
    {
        char c = list_one.elementAt(1);
    }
    catch(const std::range_error& e)
    {
        range_error_one = true;
        error_message_o = e.what();
    }
    
    assert(range_error_negative_num);
    assert(range_error_positive_num);
    assert(range_error_neg_one);
    assert(range_error_one);

    assert(error_message_nn == "index (-4) not in range [0..1)");
    assert(error_message_pn == "index (7) not in range [0..1)");
    assert(error_message_no == "index (-1) not in range [0..1)");
    assert(error_message_o == "index (1) not in range [0..1)");

    assert(list_one.elementAt(0) == 'B');
}

// Tests calling the elementAt method.
// Makes sure the elementAt method 
// properly handles CharLinkedLists if size 6.
void size_six_elementAt_tests()
{
    char arr[6] = {'p','o','l','i','c','e'};

    CharLinkedList list_six = CharLinkedList(arr, 6);

    bool range_error_negative_num = false;
    bool range_error_positive_num = false;
    bool range_error_neg_one = false;

    std::string error_message_nn = "";
    std::string error_message_pn = "";
    std::string error_message_no = "";

    try
    {
        char c = list_six.elementAt(-4);
    }
    catch(const std::range_error& e)
    {
        range_error_negative_num = true;
        error_message_nn = e.what();
    }

    try
    {
        char c = list_six.elementAt(15);
    }
    catch(const std::range_error& e)
    {
        range_error_positive_num = true;
        error_message_pn = e.what();
    }

    try
    {
        char c = list_six.elementAt(-1);
    }
    catch(const std::range_error& e)
    {
        range_error_neg_one = true;
        error_message_no = e.what();
    }

    
    assert(range_error_negative_num);
    assert(range_error_positive_num);
    assert(range_error_neg_one);

    assert(error_message_nn == "index (-4) not in range [0..6)");
    assert(error_message_pn == "index (15) not in range [0..6)");
    assert(error_message_no == "index (-1) not in range [0..6)");

    assert(list_six.elementAt(0) == arr[0]);
    assert(list_six.elementAt(1) == arr[1]);
    assert(list_six.elementAt(2) == arr[2]);
    assert(list_six.elementAt(3) == arr[3]);
    assert(list_six.elementAt(4) == arr[4]);
    assert(list_six.elementAt(5) == arr[5]);
}

// Tests calling elementAt method.
// This test checks the elementAt
// method on a growing list.
void growing_list_elementAt_tests()
{
    char arr[10] = {'w','a','s','h','i',
                   'n','g','t','o','n'};

    CharLinkedList list;

    for(int i = 0; i < 10; i++)
    {
        list.pushAtBack(arr[i]);
        assert(list.elementAt(i) == arr[i]);
    }

    assert(list.elementAt(0) == arr[0]);
    assert(list.elementAt(1) == arr[1]);
    assert(list.elementAt(2) == arr[2]);
    assert(list.elementAt(3) == arr[3]);
    assert(list.elementAt(4) == arr[4]);
    assert(list.elementAt(5) == arr[5]);
    assert(list.elementAt(6) == arr[6]);
    assert(list.elementAt(7) == arr[7]);
    assert(list.elementAt(8) == arr[8]);
    assert(list.elementAt(9) == arr[9]);
}

// Tests calling the toString method.
// Uses the toString method on lists 
// of varying sizes.
void toString_multiple_sizes_tests()
{
    char test[5] = {'p','l','a','t','o'};
    CharLinkedList list_empty;
    CharLinkedList list_one = CharLinkedList('#');
    CharLinkedList list_five = CharLinkedList(test,5);

    assert(list_empty.toString() == "[CharLinkedList of size 0 <<>>]");
    assert(list_one.toString() == "[CharLinkedList of size 1 <<#>>]");
    assert(list_five.toString() == "[CharLinkedList of size 5 <<plato>>]");
}

// Tests calling the toReverseString method.
// Uses the toReverseString method on lists 
// of varying sizes.
void toReverseString_multiple_sizes_tests()
{
    char test[5] = {'p','l','a','t','o'};
    CharLinkedList list_empty;
    CharLinkedList list_one = CharLinkedList('#');
    CharLinkedList list_five = CharLinkedList(test,5);

    assert(list_empty.toReverseString() == "[CharLinkedList of size 0 <<>>]");
    assert(list_one.toReverseString() == "[CharLinkedList of size 1 <<#>>]");

    std::string testWord = list_five.toReverseString();
    assert(testWord == "[CharLinkedList of size 5 <<otalp>>]");
}

// Tests calling the pushAtBack method.
// This test makes sure the method 
// properly handles adding to an empty
// list.
void empty_pushAtBack_tests()
{
    CharLinkedList list;
    list.pushAtBack('G');

    assert(not list.isEmpty());
    assert(list.size() == 1);
    assert(list.first() == 'G');
    assert(list.last() == 'G');
    assert(list.toString() == "[CharLinkedList of size 1 <<G>>]");
}

// Tests calling the pushAtBack method.
// This test makes sure the method 
// properly handles adding to a list of 
// size 1.
void size_one_pushAtBack_tests()
{
    CharLinkedList list = CharLinkedList('U');
    list.pushAtBack('M');

    assert(not list.isEmpty());
    assert(list.size() == 2);
    assert(list.first() == 'U');
    assert(list.last() == 'M');
    assert(list.toString() == "[CharLinkedList of size 2 <<UM>>]");
}

// Tests calling the pushAtBack method.
// This test makes sure the method 
// properly handles adding to a list of 
// size greater than 1.
void large_pushAtBack_tests()
{
    char arr[5] = {'w','o','k','i','e'};
    CharLinkedList list = CharLinkedList(arr, 5);
    list.pushAtBack('?');

    assert(not list.isEmpty());
    assert(list.size() == 6);
    assert(list.first() == 'w');
    assert(list.last() == '?');
    assert(list.toString() == "[CharLinkedList of size 6 <<wokie?>>]");
}

// Tests calling the pushAtFront method.
// This test makes sure the method 
// properly handles adding to an empty
// list.
void empty_pushAtFront_tests()
{
    CharLinkedList list;
    list.pushAtFront('G');

    assert(not list.isEmpty());
    assert(list.size() == 1);
    assert(list.first() == 'G');
    assert(list.last() == 'G');
    assert(list.toString() == "[CharLinkedList of size 1 <<G>>]");
}

// Tests calling the pushAtFront method.
// This test makes sure the method 
// properly handles adding to a list of 
// size 1.
void size_one_pushAtFront_tests()
{
    CharLinkedList list = CharLinkedList('U');
    list.pushAtFront('M');

    assert(not list.isEmpty());
    assert(list.size() == 2);
    assert(list.first() == 'M');
    assert(list.last() == 'U');
    assert(list.toString() == "[CharLinkedList of size 2 <<MU>>]");
}

// Tests calling the pushAtFront method.
// This test makes sure the method 
// properly handles adding to a list of 
// size greater than 1.
void large_pushAtFront_tests()
{
    char arr[5] = {'w','o','k','i','e'};
    CharLinkedList list = CharLinkedList(arr, 5);
    list.pushAtFront('s');

    assert(not list.isEmpty());
    assert(list.size() == 6);
    assert(list.first() == 's');
    assert(list.last() == 'e');
    assert(list.toString() == "[CharLinkedList of size 6 <<swokie>>]");
}

// Test calling the insertAt method.
// This test checks to make sure that 
// the method throws range errors when 
// given invalid input on empty list.
void empty_insertAt_out_of_range_tests()
{
    CharLinkedList list_empty;
    bool range_error_thrown = false;
    std::string error_message = "";

    try
    {
        list_empty.insertAt('c', 1);
    }
    catch(const std::range_error& e)
    {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (1) not in range [0..0]");


    range_error_thrown = false;
    error_message = "";


    try
    {
        list_empty.insertAt('c', -1);
    }
    catch(const std::range_error& e)
    {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (-1) not in range [0..0]");
}

// Test calling the insertAt method.
// This test checks to make sure that 
// the method throws range errors when 
// given invalid input on non empty list.
void non_empty_insertAt_out_of_range_tests()
{
    CharLinkedList list_empty = CharLinkedList('T');
    bool range_error_thrown = false;
    std::string error_message = "";

    try
    {
        list_empty.insertAt('c', 10);
    }
    catch(const std::range_error& e)
    {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (10) not in range [0..1]");


    range_error_thrown = false;
    error_message = "";


    try
    {
        list_empty.insertAt('c', -5);
    }
    catch(const std::range_error& e)
    {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (-5) not in range [0..1]");
}

// Tests calling the insertAt method.
// This tests tries using the insertAt
// method on an empty.
void insertAt_empty_tests()
{
    CharLinkedList list;
    list.insertAt('j', 0);

    assert(list.size() == 1);
    assert(list.first() == 'j');
    assert(list.last() == 'j');
    assert(list.toString() == "[CharLinkedList of size 1 <<j>>]");
}

// Tests calling the insertAt method.
// This tests tries using the insertAt
// method at the front of a list.
void insertAt_front_non_empty_tests()
{
    char arr[5] = {'w','o','k','i','e'};
    CharLinkedList list = CharLinkedList(arr, 5);

    list.insertAt('X',0);

    assert(list.size() == 6);
    assert(list.first() == 'X');
    assert(list.last() == 'e');
    assert(list.toString() == "[CharLinkedList of size 6 <<Xwokie>>]");
}

// Tests calling the insertAt method.
// This tests tries using the insertAt
// method at the middle of a list.
void insertAt_middle_non_empty_tests()
{
    char arr[5] = {'w','o','k','i','e'};
    CharLinkedList list = CharLinkedList(arr, 5);

    list.insertAt('X',2);

    assert(list.size() == 6);
    assert(list.first() == 'w');
    assert(list.last() == 'e');
    assert(list.toString() == "[CharLinkedList of size 6 <<woXkie>>]");
}

// Tests calling the insertAt method.
// This tests tries using the insertAt
// method at the end of a list.
void insertAt_end_non_empty_tests()
{
    char arr[5] = {'w','o','k','i','e'};
    CharLinkedList list = CharLinkedList(arr, 5);

    list.insertAt('X',5);

    assert(list.size() == 6);
    assert(list.first() == 'w');
    assert(list.last() == 'X');
    assert(list.toString() == "[CharLinkedList of size 6 <<wokieX>>]");
}

// Tests calling the insertInOrder method.
// Sees if the method properly inserts
// into an empty list.
void insertInOrder_empty_tests()
{
    CharLinkedList list;
    list.insertInOrder('A');

    assert(list.size() == 1);
    assert(list.first() == 'A');
    assert(list.last() == 'A');
    assert(list.toString() == "[CharLinkedList of size 1 <<A>>]");
}

// Tests calling the insertInOrder method.
// Checks to see if the insertInOrder
// method properly inserts into lists
// of size greater than 1.
void back_insertInOrder_nonempty_tests()
{
    char arr[5] = {'a','b','c','d','e'};
    CharLinkedList list = CharLinkedList(arr, 5);

    list.insertInOrder('f');

    assert(list.size() == 6);
    assert(list.first() == 'a');
    assert(list.last() == 'f');
    assert(list.toString() == "[CharLinkedList of size 6 <<abcdef>>]");
}

// Tests calling the insertInOrder method.
// Checks to see if the insertInOrder
// method properly inserts into lists
// of size greater than 1.
void front_insertInOrder_nonempty_tests()
{
    char arr[5] = {'b','c','d','e','f'};
    CharLinkedList list = CharLinkedList(arr, 5);

    list.insertInOrder('a');

    assert(list.size() == 6);
    assert(list.first() == 'a');
    assert(list.last() == 'f');
    assert(list.toString() == "[CharLinkedList of size 6 <<abcdef>>]");
}

// Tests calling the insertInOrder method.
// Checks to see if the insertInOrder
// method properly inserts into lists
// of size greater than 1.
void middle_insertInOrder_nonempty_tests()
{
    char arr[5] = {'a','b','c','e','f'};
    CharLinkedList list = CharLinkedList(arr, 5);

    list.insertInOrder('d');

    assert(list.size() == 6);
    assert(list.first() == 'a');
    assert(list.last() == 'f');
    assert(list.toString() == "[CharLinkedList of size 6 <<abcdef>>]");
}

// Tests calling popFromBack method.
// This test makes sure that the method
// throws a runtime error when used
// on an empty list.
void empty_popFromBack_tests()
{
    CharLinkedList list;
    
    bool runtime_error_thrown = false;
    std::string error_message = "";

    try
    {
        list.popFromBack();
    }
    catch(const std::runtime_error& e)
    {
        runtime_error_thrown= true;
        error_message = e.what();
    }
    
    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

// Tests calling popFromBack method.
// This test makes sure that the method
// handles lists of size 1 properly.
void size_one_popFromBack_tests()
{
    CharLinkedList list = CharLinkedList('W');
    list.popFromBack();

    assert(list.isEmpty()); 
}

// Tests calling popFromFront method.
// This test makes sure that the method
// handles lists of size greater than 1 properly.
void size_large_popFromBack_tests()
{
    char arr[5] = {'a','b','c','d','e'};
    CharLinkedList list = CharLinkedList(arr, 5);

    list.popFromBack();

    assert(list.size() == 4);
    assert(list.first() == 'a');
    assert(list.last() == 'd');
    assert(list.toString() == "[CharLinkedList of size 4 <<abcd>>]");
}

// Tests calling popFromFront method.
// This test makes sure that the method
// throws a runtime error when used
// on an empty list.
void empty_popFromFront_tests()
{
    CharLinkedList list;
    
    bool runtime_error_thrown = false;
    std::string error_message = "";

    try
    {
        list.popFromFront();
    }
    catch(const std::runtime_error& e)
    {
        runtime_error_thrown= true;
        error_message = e.what();
    }
    
    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

// Tests calling popFromFront method.
// This test makes sure that the method
// handles lists of size 1 properly.
void size_one_popFromFront_tests()
{
    CharLinkedList list = CharLinkedList('W');
    list.popFromFront();

    assert(list.isEmpty()); 
}

// Tests calling popFromFront method.
// This test makes sure that the method
// handles lists of size greater than 1 properly.
void size_large_popFromFront_tests()
{
    char arr[5] = {'a','b','c','d','e'};
    CharLinkedList list = CharLinkedList(arr, 5);

    list.popFromFront();

    assert(list.size() == 4);
    assert(list.first() == 'b');
    assert(list.last() == 'e');
    assert(list.toString() == "[CharLinkedList of size 4 <<bcde>>]");

}

// Tests calling the removeAt method.
// This test makes sure that the method
// throws a range error when given an invalid
// range.
void empty_removeAt_tests()
{
    CharLinkedList list;
    bool range_error_thrown = false;
    std::string error_message = "";

    try
    {
        list.removeAt(10);
    }
    catch(const std::range_error& e)
    {
        range_error_thrown = true;
        error_message = e.what();
    }
    
    assert(range_error_thrown);
    assert(error_message == "index (10) not in range [0..0)");

    range_error_thrown = false;
    error_message = "";

    try
    {
        list.removeAt(-5);
    }
    catch(const std::range_error& e)
    {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (-5) not in range [0..0)");
}

// Tests calling the removeAt method.
// This test makes sure that the method
// properly removes elements from lists.
void front_removeAt_tests()
{
    char arr[5] = {'a','b','c','d','e'};
    CharLinkedList list = CharLinkedList(arr, 5);

    list.removeAt(0);

    assert(list.size() == 4);
    assert(list.first() == 'b');
    assert(list.last() == 'e');
    assert(list.toString() == "[CharLinkedList of size 4 <<bcde>>]");
}

// Tests calling the removeAt method.
// This test makes sure that the method
// properly removes elements from lists.
void back_removeAt_tests()
{
    char arr[5] = {'a','b','c','d','e'};
    CharLinkedList list = CharLinkedList(arr, 5);

    list.removeAt(4);

    assert(list.size() == 4);
    assert(list.first() == 'a');
    assert(list.last() == 'd');
    assert(list.toString() == "[CharLinkedList of size 4 <<abcd>>]");
}

// Tests calling the removeAt method.
// This test makes sure that the method
// properly removes elements from lists.
void middle_removeAt_tests()
{
    char arr[5] = {'a','b','c','d','e'};
    CharLinkedList list = CharLinkedList(arr, 5);

    list.removeAt(2);

    assert(list.size() == 4);
    assert(list.first() == 'a');
    assert(list.last() == 'e');
    assert(list.toString() == "[CharLinkedList of size 4 <<abde>>]");
}

// Tests calling the replaceAt method.
// This test makes sure that the method
// properly throws a range error when 
// given an invalid input.
void empty_replaceAt_test()
{
    CharLinkedList list;

    bool range_error_thrown = false;
    std::string error_message = "";

    try
    {
        list.removeAt(2);
    }
    catch(const std::range_error& e)
    {
        range_error_thrown = true;
        error_message = e.what();
    }
    
    assert(range_error_thrown);
    assert(error_message == "index (2) not in range [0..0)");

    range_error_thrown = false;
    error_message = "";

    try
    {
        list.removeAt(-5);
    }
    catch(const std::range_error& e)
    {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (-5) not in range [0..0)");
}

// Tests calling the replaceAt method.
// Tests the replaceAt method on the
// front, back, and middle of a list.
void non_empty_replaceAt_tests()
{
    char arr[5] = {'a','b','c','d','e'};
    CharLinkedList list = CharLinkedList(arr, 5);

    list.replaceAt('1', 0);
    list.replaceAt('2', 1);
    list.replaceAt('3', 2);
    list.replaceAt('4', 3);
    list.replaceAt('5', 4);

    assert(list.toString() == "[CharLinkedList of size 5 <<12345>>]");
}

// Tests calling the concatenate method.
// This tests makes tests the 
// concatenate method on empty lists.
void empty_concatenate_tests()
{
    CharLinkedList list;
    CharLinkedList list2;

    list.concatenate(&list2);

    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}

// Tests calling the concatenate method.
// This tests makes tests the 
// concatenate method on non emptylists.
void non_empty_concatenate_tests()
{
    char arr[4] = {'r','a','c','e'};
    char marr[3] = {'c','a','r'};
    CharLinkedList list = CharLinkedList(arr, 4);
    CharLinkedList list2 = CharLinkedList(marr, 3);

    list.concatenate(&list2);

    assert(list.toString() == "[CharLinkedList of size 7 <<racecar>>]");
}
/*
 *  CharLinkedList.cpp
 *  Victor Salcedo
 *  February 5, 2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Implementation of a CharLinkedList in C++
 *
 */

#include "CharLinkedList.h"
#include <stdexcept>
#include <iostream>

/*
 * name:      CharLinkedList default constructor
 * purpose:   Create an instance of an empty CharLinkedList
 * arguments: none
 * returns:   none
 * effects:   size to 0 and front/back pointer set to nullptr
 */
CharLinkedList::CharLinkedList()
{
    front = nullptr;
    back = nullptr;
    numElements = 0;
}

/*
 * name:      singleElementHelper
 * purpose:   Creates a single node with the character passed to the funciton.
 * arguments: A character that will be used to create the single node.
 * returns:   Return a pointer to the node created.
 * effects:   Initializes the node with the provided character, and 
 *            sets both next and previous pointer to nullptr.
 */
CharLinkedList::Node * CharLinkedList::singleElementHelper(char c)
{
    // Makes a pointer to a new node
    // and initializes data to c and
    // both pointers to nullptr.
    Node *newNode = new Node;
    newNode->data = c;
    newNode->next = nullptr;
    newNode->previous = nullptr;

    return newNode;
}

/*
 * name:      singleElementPtrHelper
 * purpose:   Creates a single node with the character passed to the funciton.
 * arguments: A character that will be used to create the single node. Two
 *            pointers, one for the previous node and one for the next node
 *            in the list.
 * returns:   Return a pointer to the single node created.
 * effects:   Initializes the node with the provided character, and 
 *            sets both next and previous pointer to the values passed
 *            in to the method.
 */
CharLinkedList::Node * CharLinkedList::singleElementPtrHelper(Node *previous, char c, Node *next)
{
    // Makes a pointer to a new node
    // and initializes data to c and
    // both pointers to the values passed in.
    Node *newNode = new Node;
    newNode->data = c;
    newNode->next = next;
    newNode->previous = previous;

    return newNode;
}

/*
 * name:      CharLinkedList alternative constructor
 * purpose:   Creates an instance of a CharLinkedList with a single node
 *            that gets initialized with the value in the parameter.
 * arguments: A character that will be used to create the single node
 *            CharLinkedList.
 * returns:   none
 * effects:   Initializes a CharLinkedList of size 1 with the provided 
 *            character.
 *            Front and back pointer both set to the single node. 
 */
CharLinkedList::CharLinkedList(char c)
{
    // Creates a single node using the helper function.
    // Then sets the front and back of
    // the linked list to this single node.
    // Also updates the size.
    front = singleElementHelper(c);
    back = front;
    numElements = 1;
}

/*
 * name:      CharLinkedList array based constructor
 * purpose:   Uses the contents of a character array to create
 *            a new CharLinkedList.
 * arguments: An array of characters and the size of the array.
 * returns:   none
 * effects:   Copies data from an array and places it into a CharLinkedList.
 */
CharLinkedList::CharLinkedList(char arr[], int size)
{
    // Creates a single node with the helper function.
    // Then sets the front and back of
    // the linked list to this single node.
    front = singleElementHelper(arr[0]);
    back = front;

    // Get the front of the list to be able to add to
    // the back of the list.
    Node *curr = front;

    for(int i = 1; i < size; i++)
    {
        // Create new node and attach it to the list
        // using the values in the array, and pointers 
        // to the previous node in the list and then 
        // nullptr to the next. 
        curr->next = singleElementPtrHelper(curr, arr[i], nullptr);
        curr = curr->next;
        back = curr;
    }

    numElements = size;
}

/*
 * name:      CharLinkedList copy constructor
 * purpose:   To initialize a CharLinkedList with the contents of another 
 *            CharLinkedList.
 * arguments: A CharLinkedList of any size.
 * returns:   none
 * effects:   Copies data from nodes of a CharLinkedList and puts it into a 
 *            new CharLinkedList.
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other)
{
    // If the other linked list is empty
    // then create an empty linked list.
    if(other.numElements == 0)
    {
        front = nullptr;
        back = nullptr;
        numElements = 0;
        return;
    }

    // Create the first node in the list
    // and set the front and back of the list
    // equal to that node.
    front = singleElementHelper(other.front->data);
    back = front;

    // Creates a buffer to pass through the linked list
    // that we are copying from. 
    // Also creates curr to be able to add new nodes
    // to the back of the new list.
    Node *buffer = other.front->next;
    Node *curr = front;
    
    // Create copies off each node in the orginal 
    // linked list and add then to the back of the 
    // new list until we reach the end of the original
    // list.
    while(buffer not_eq nullptr)
    {
        curr->next = singleElementPtrHelper(curr, buffer->data, nullptr);
        back = curr->next;

        curr = back;
        buffer = buffer->next;
    }

    // Set the size of the new list equal to the
    // size of the list we copied from
    numElements = other.size();
}

/*
 * name:      CharLinkedList destructor
 * purpose:   frees any memory used by a CharLinkedList
 * arguments: none
 * returns:   none
 * effects:   deletes CharLinkedList
 */
CharLinkedList::~CharLinkedList()
{
    destructorHelper(this->front);
}

/*
 * name:      CharLinkedList destructor helper function
 * purpose:   frees any memory used by a CharLinkedList
 * arguments: none
 * returns:   none
 * effects:   deletes CharLinkedList
 */
void CharLinkedList::destructorHelper(Node *curr)
{
    // Checks to see if we have reached the end of the list
    if(curr == nullptr)
    {
        return;
    }

    // Recurive call
    destructorHelper(curr->next);
    
    // Freeing the nodes from the back to the front
    delete curr;
}

/*
 * name:      removeNodes
 * purpose:   To remove a certain number of nodes from a linked list.
 * arguments: Number of nodes that we want to remove from the
 *            list.
 * returns:   none
 * effects:   Removes a number of nodes from the list from the back
 *            and adjusts the numElements variable.
 */
void CharLinkedList::removeNodes(int num)
{
    // Get the pointer from the back 
    // of the list.
    Node *curr = back;

    // Deletes a number of nodes from the list.
    while(num > 0)
    {
        Node *tmp = curr;
        curr = curr->previous;
        delete tmp;
        num--;
    }

    // Sets the back pointer to the node we ended on
    // and didnt delete. Also set the next pointer of curr
    // to nullptr.
    curr->next = nullptr;
    back = curr;
}

/*
 * name:      addNodes
 * purpose:   To add a certain number of nodes to the back of a list.
 * arguments: Number of nodes that we want to add to the
 *            list.
 * returns:   none
 * effects:   Adds a number of nodes to the list to the back
 *            and adjusts the numElements variable. Data filled
 *            in with random chars.
 */
void CharLinkedList::addNodes(int num)
{
    // Gets the pointer to the last node in the
    // list.
    Node *curr = back;

    // Adds a number of nodes to the back of the list.
    while(num > 0)
    {
        curr->next = singleElementPtrHelper(curr, '#', nullptr);
        curr = curr->next;
        num--;
    }

    // Sets the back pointer to the last node 
    // that we added to the back.
    back = curr;
}

/*
 * name:      CharLinkedList overloaded assignment operator
 * purpose:   To make a deep copy of another CharLinkedList when
 *            using the assignment operator.
 * arguments: none
 * returns:   A deep copy of a CharLinkedList
 * effects:   Sets all values of one CharLinkedList using the
 *            values of another list, without having any pointers
 *            crossover.
 */
CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other)
{
    // If setting a CharLinkedList equal to itself then
    // the method will just return itself.
    if(this == &other)
    {
        return *this;    
    }

    // Makes it so that the linked lists have the same number of nodes,
    // by calling either the addNodes or removeNodes functions.
    if(other.numElements > this->numElements)
    {
        addNodes(other.numElements - this->numElements);
    }else if(other.numElements < this->numElements)
    {
        removeNodes(this->numElements - other.numElements);
    }

    // Creates a buffer and a curr node pointer
    // to pass through both lists at the same time.
    Node *curr = this->front;
    Node *buffer = other.front;

    // Updates all data values in the nodes of the 
    // first list to the data values in the nodes
    // from the list it is being set equal to.
    while(buffer not_eq nullptr)
    {
        curr->data = buffer->data;
        curr = curr->next;
        buffer = buffer->next;   
    }

    return *this;    
}

/*
 * name:      isEmpty
 * purpose:   To identify whether or not a list contains any nodes.
 * arguments: none
 * returns:   True, false whether or not the list is empty.
 * effects:   none
 */
bool CharLinkedList::isEmpty() const
{
    return numElements == 0;
}

/*
 * name:      clear
 * purpose:   To removes all elements stored in a CharLinkedList
 * arguments: none
 * returns:   none
 * effects:   Frees all memory allocated for a CharLinkedList. Also
 *            sets list variables to that of any empty list.
 */
void CharLinkedList::clear()
{
    // Pass through the list and delete all
    // nodes.
    destructorHelper(front);

    // Updates all values of the linked list
    // to that of an emoty list.
    front = nullptr;
    back = nullptr;
    numElements = 0;
}

/*
 * name:      size
 * purpose:   To get the number of elements in the CharLinkedList
 * arguments: none
 * returns:   numElements of the CharLinkedList
 * effects:   none
 */
int CharLinkedList::size() const
{
    return numElements;
}

/*
 * name:      first
 * purpose:   To get the character from the first element in the CharLinkedList
 * arguments: none
 * returns:   The char data contained in the first element of the list.
 * effects:   none
 */
char CharLinkedList::first() const
{
    // Checks to make sure that the list is not empty,
    // and actually has a front.
    if(numElements <= 0)
    {
        throw std::runtime_error("cannot get first of empty LinkedList");
    }

    return front->data;
}

/*
 * name:      last
 * purpose:   To get the data from the last element in the CharLinkedList
 * arguments: none
 * returns:   The character from the last element of the list.
 * effects:   none
 */
char CharLinkedList::last() const
{
    // Checks to make sure that the list is not empty,
    // and actually has a last.
    if(numElements <= 0)
    {
        throw std::runtime_error("cannot get last of empty LinkedList");
    }

    return back->data;
}

/*
 * name:      elementAtHelper
 * purpose:   To aid the elementAt method in finding the 
 *            character from the node at the requested index.
 * arguments: Pointer to a node in the list, the current index
 *            the method is on, and the target index.
 * returns:   The character data from the node at the given index.
 * effects:   none
 */
char CharLinkedList::elementAtHelper(Node *curr, int index, int target) const
{
    // Base Case: checks to see if we have reached the target index.
    if(index == target)
    {
        return curr->data;
    }

    // Recursive call
    return elementAtHelper(curr->next, index + 1, target);
}

/*
 * name:      elementAt
 * purpose:   To get the data of an element in the CharLinkedList at a specific
 *            index.
 * arguments: The index we would like to reach.
 * returns:   Character data from the node at the given index.
 * effects:   none
 */
char CharLinkedList::elementAt(int index) const
{
    // Checking to make sure the user provided a valid
    // index. If not then the method will throw a range
    // error.
    if(numElements == 0 or index < 0 or index > numElements - 1)
    {
        // “index (index) not in range [0..numElements)”
        throw std::range_error("index (" + std::to_string(index) 
                               + ") not in range [0.."
                               + std::to_string(numElements) + ")");
    }

    // Pass the first node of the linked list to the 
    // helper function.
    Node *first = this->front;
    char element = elementAtHelper(first, 0, index);

    return element;
}

/*
 * name:      toString
 * purpose:   To display the contents of the CharLinkedList
 * arguments: none
 * returns:   String of the contents of the CharLinkedList
 * effects:   none
 */
std::string CharLinkedList::toString() const
{
    std::string output = "[CharLinkedList of size " 
                         + std::to_string(numElements) + " <<";
    
    // Get the node from the front of the list.
    // Use that to pass through the list and add
    // each character to the string output.
    Node *curr = front;
    while(curr not_eq nullptr)
    {
        output += curr->data;
        curr = curr->next;
    }

    output += ">>]";

    return output;
}

/*
 * name:      toReverseString
 * purpose:   To display the contents of the CharLinkedList
 * arguments: none
 * returns:   Reversed string of the contents of the CharLinkedList
 * effects:   none
 */
std::string CharLinkedList::toReverseString() const
{
    std::string output = "[CharLinkedList of size " 
                         + std::to_string(numElements) + " <<";
    
    // Get the node from the back of the list.
    // Use that to pass through the list and add
    // each character to the string output.
    Node *curr = back;
    while(curr not_eq nullptr)
    {
        output += curr->data;
        curr = curr->previous;
    }

    output += ">>]";
    return output;
}

/*
 * name:      pushAtBack
 * purpose:   To push a new node to the back of the CharLinkedList.
 * arguments: The character that will be put in the node.
 * returns:   none
 * effects:   Changes the back of the list to be the new node
 *            and increments the size of the list.
 */
void CharLinkedList::pushAtBack(char c)
{
    // Handles pushing at back for empty
    // lists.
    if(numElements == 0)
    {
        front = singleElementHelper(c);
        back = front;
        numElements++;
        return;
    }

    // Add a new item to the back of the linked 
    // list using helper funcitons. Also set
    // the back to be equal to the new node.
    back->next = singleElementPtrHelper(back, c, nullptr);
    back = back->next;

    // Increment the size of the list.
    numElements++;
}

/*
 * name:      pushAtFront
 * purpose:   To push a new element to the front of the CharLinkedList.
 * arguments: The character that will be put in the node.
 * returns:   none
 * effects:   Changes the front of the list to be the new node
 *            and increments the size of the list.
 */
void CharLinkedList::pushAtFront(char c)
{
    // Handles pushing at front for empty
    // lists.
    if(numElements == 0)
    {
        front = singleElementHelper(c);
        back = front;
        numElements++;
        return;
    }

    // Add a new item to the front of the linked 
    // list using helper funcitons. Also set
    // the front to be equal to the new node.
    front->previous = singleElementPtrHelper(nullptr, c, front);
    front = front->previous;

    // Increment the size of the list.
    numElements++;
}

/*
 * name:      nodeAt
 * purpose:   To find the pointer to a node at a given index.
 * arguments: The pointer to the from of the linked list, the current
 *            index of where we are in the list, and the target index.
 * returns:   A pointer to the node at a given index.
 * effects:   node
 */
CharLinkedList::Node * CharLinkedList::nodeAt(Node *front, int index, int tar)
{
    // Gets the node at the front of the list.
    // Passes through the list until
    // we get to the target index.
    Node *curr = front;
    while(index < tar)
    {
        curr = curr->next;
        index++;
    }

    return curr;
}

/*
 * name:      insertAt
 * purpose:   To insert a new element in the CharLinkedList at a given index.
 * arguments: The index of where the new node will be inserted,
 *            and the character that will be placed in the new node.
 * returns:   none
 * effects:   Adds a new element to the list, increments the size.
 */
void CharLinkedList::insertAt(char c, int index)
{
    // Checks to make sure that the user provided
    //  a valid index.
    if(index < 0 or index > numElements)
    {
        // “index (index) not in range [0..numElements)”
        throw std::range_error("index (" + std::to_string(index) 
                               + ") not in range [0.."
                               + std::to_string(numElements) + "]");
    }

    // Checks whether the insertions is at the front,
    // back, or middle. Uses pushAtFront and pushAtBack
    // if needed.
    if(index == 0)
    {
        pushAtFront(c);
    }else if(index == numElements)
    {
        pushAtBack(c);
    }else{

        // Rearranges pointers
        Node *requestedNode = nodeAt(front, 0, index);
        Node *tmp = requestedNode->previous;

        tmp->next = singleElementPtrHelper(tmp, c, requestedNode);
        requestedNode->previous = tmp->next;
        numElements++;
    }
}

/*
 * name:      insertInOrder
 * purpose:   To insert a new element in the CharLinkedList in ascending order
 *            using ASCII value.
 * arguments: The character that will be used to put into the node.
 * returns:   none
 * effects:   Adds a new element to the list, increments the size.
 */
void CharLinkedList::insertInOrder(char c)
{
    // Pushes to the front of the list
    // if it is empty
    if(numElements == 0)
    {
        pushAtFront(c);
        return;
    }

    Node *curr = front;
    int index = 0;
    bool found = false;

    // Passes through ther list until we reach
    // the end or we find where to insert the 
    // new node.
    while(curr not_eq nullptr and not found)
    {
        if(curr->data >= c)
        {
            found = true;
            index--;
        }

        curr = curr->next;
        index++;
    }

    // Gives the index we calculated to the insertAt
    // mnethod.
    insertAt(c, index);
}

/*
 * name:      popFromFront
 * purpose:   To remove the element at the front of the list 
 * arguments: none
 * returns:   none
 * effects:   Reduces numElements by 1, front pointer changed 
 */
void CharLinkedList::popFromFront()
{
    // Throws error if list is empty, since
    // you do not have any nodes to remove.
    if(numElements == 0)
    {
        throw std::runtime_error("cannot pop from empty LinkedList");
    }

    // If there is only one node then just
    // run the clear method.
    if(numElements == 1)
    {
        clear();
        return;
    }

    // Removes the old front
    // Sets the new front
    // And then cleans up memory
    // and decrements numElements
    Node *tmp = front;
    front = front->next;
    front->previous = nullptr;

    delete tmp;
    numElements--;
}

/*
 * name:      popFromBack
 * purpose:   To remove the element at the back of the list 
 * arguments: none
 * returns:   none
 * effects:   Reduces numElements by 1, front pointer changed 
 */
void CharLinkedList::popFromBack()
{
    // Throws error if list is empty, since
    // you do not have any nodes to remove.
    if(numElements == 0)
    {
        throw std::runtime_error("cannot pop from empty LinkedList");
    }

    // If there is only one node then just
    // run the clear method.
    if(numElements == 1)
    {
        clear();
        return;
    }

    // Removes the old back
    // Sets the new back
    // And then cleans up memory
    // and decrements numElements
    Node *tmp = back;
    back = back->previous;
    back->next = nullptr;

    delete tmp;
    numElements--;
}

/*
 * name:      removeAt
 * purpose:   To removes an element from the list at a given index
 * arguments: The index of the node we want to remove.
 * returns:   none
 * effects:   Reduces numElements by 1 
 */
void CharLinkedList::removeAt(int index)
{
    // Throws error if invalid input
    if(index < 0 or index > numElements - 1)
    {
        // “index (index) not in range [0..numElements)”
        throw std::range_error("index (" + std::to_string(index) 
                               + ") not in range [0.."
                               + std::to_string(numElements) + ")");
    }

    // Runs clear method if only 1 element in list
    if(numElements == 1)
    {
        clear();
        return;
    }

    // Runs pop from either from or back
    // if the index is at one of those
    // locations.
    if(index == 0)
    {
        popFromFront();
        return;
    }else if (index == numElements - 1)
    {
        popFromBack();
        return;
    }
    
    // Removes the node, rearranges the pointers
    // and then cleans up
    Node *remove = nodeAt(front, 0, index);
    Node *tmp = remove->previous;

    remove->next->previous = tmp;
    tmp->next = remove->next;
    numElements--;

    delete remove;
}

/*
 * name:      replaceAtHelper
 * purpose:   To aid the replaceAt method find
 *            the node it wants to replace with
 *            a new character.
 * arguments: Node pointer to the start of the list,
 *            a character to use in the swap, the index
 *            of where we are in the list, and the target
 *            index.
 * returns:   none
 * effects:   Changes the data value of a node at the provided index. 
 */
void CharLinkedList::replaceAtHelper(Node *curr, char c, int index, int target)
{
    // Base Case
    if(index == target)
    {
        curr->data = c;
        return;
    }

    // Update tracker variables
    curr = curr->next;
    index++;

    // Recursive call
    replaceAtHelper(curr, c, index, target);
}

/*
 * name:      replaceAt
 * purpose:   To replace an element from the list at a given index
 * arguments: A character to use in the swap, and the index of where
 *            we want the char swap to take place.
 * returns:   none
 * effects:   C the data value of a node at a given index.
 */
void CharLinkedList::replaceAt(char c, int index)
{
    replaceAtHelper(front, c, 0, index);
}

/*
 * name:      concatenate
 * purpose:   Adds a copy of another CharArrayList to the back of another 
 * arguments: CharArrayList
 * returns:   none
 * effects:   Appends the information from one CharLinkedList
 *            to the back of another. 
 */
void CharLinkedList::concatenate(CharLinkedList *other)
{
    Node *curr = other->front;

    while(curr not_eq nullptr)
    {
        pushAtBack(curr->data);
        curr = curr->next;
    }
}
/*
 *  unit_tests.h
 *  NAME: Cynthia Chao(gchao02)
 *  DATE CREATED: 2.2
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  FILE PURPOSE HERE: implement tests to test 
 *  whether functions are working properly
 *
 */
#include "CharLinkedList.h"
#include <cassert>

//Testing the copy constructor function in a non-empty list
void copyConstructor_test(){
    char arr[5] = {'a','b','c','d','e'};
    CharLinkedList obj1(arr, 5);
    // Initialize obj1 with some data
    CharLinkedList obj2 = obj1; // Use copy constructor
    // Test data equality
    for (int i = 0; i < 5; i++){
        assert(obj2.elementAt(i) == obj1.elementAt(i));
    }
}
//Testing the assignment operator function in a non-empty list
void assignop_test(){
    char arr[5] = {'a','b','c','d','e'};
    CharLinkedList obj1(arr, 5);
    // Initialize obj1 with some data
    char arr1[4] = {'x','c','v','b'};
    CharLinkedList obj2(arr1, 4); 
    // Test data equality
    obj2 = obj1;
    for (int i = 0; i < 5; i++){
        assert(obj2.elementAt(i) == obj1.elementAt(i));
    }
}
//Testing the assignment operator function by assigning to itself
void assignop_edge_test(){
    char arr[5] = {'a','b','c','d','e'};
    CharLinkedList obj1(arr, 5);
    // Initialize obj1 with some data
    char arr1[5] = {'a','b','c','d','e'};
    CharLinkedList obj2(arr1, 5); 
    // Test data equality
    obj2 = obj1;
    for (int i = 0; i < 5; i++){
        assert(obj2.elementAt(i) == obj1.elementAt(i));
    }
}

// Testing the first function when list is empty
void first_error_test(){
    CharLinkedList test_list;

    // var to track whether range_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.first();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "cannot get first of empty LinkedList");
}

//Testing the last function when the list is empty
void last_error_test(){
    CharLinkedList test_list;

    // var to track whether range_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.last();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "cannot get last of empty LinkedList");
}

//Testing the first function in a non-empty list
void firstTest(){
    char arr[5] = {'a','b','c','d','e'};
    CharLinkedList test_list(arr, 5);
    assert(test_list.first() == 'a');
}

//Testing the last function in a non-empty list
void LastTest(){
    char arr[5] = {'a','b','c','d','e'};
    CharLinkedList test_list(arr, 5);
    assert(test_list.last() == 'e'); 
}

//Testing whether size works properly in non-empty list
void size_test(){
    CharLinkedList test_list('c');
    assert(test_list.size() == 1);
}

//Testing whether size works properly in empty list
void size_test1(){
    CharLinkedList test_list;
    assert(test_list.size() == 0);
}

//Testing the clear function in a non-empty list
void clearTest(){
    char arr[5] = {'a','b','c','d','e'};
    CharLinkedList test_list(arr, 5);
    test_list.clear();
    assert(test_list.isEmpty());
}
//Testing the isEmpty function in a empty list
void isEmptyTest(){
    CharLinkedList test_list;
    assert(test_list.isEmpty());
}
//Testing the isEmpty function in a non-empty list
void isEmptyTest1(){
    char arr[5] = {'a','b','c','d','e'};
    CharLinkedList test_list(arr, 5);
    assert(not test_list.isEmpty());
}

// Testing the pushatback function in a non-empty list
void pushAtBackTest(){
    char arr[5] = {'a','b','c','d','e'};
    CharLinkedList test_list(arr, 5);
    test_list.pushAtBack('x');
    assert(test_list.toString() ==
     "[CharLinkedList of size 6 <<abcdex>>]");

}
// Testing the pushatfront function in a non-empty list
void pushAtFrontTest(){
    char arr[5] = {'a','b','c','d','e'};
    CharLinkedList test_list(arr, 5);
    test_list.pushAtFront('z');
    assert(test_list.toString() ==
     "[CharLinkedList of size 6 <<zabcde>>]");
}
//Testing the pushatback function in a empty list
void pushAtBackTestEdge(){
    CharLinkedList test_list;
    test_list.pushAtBack('x');
    assert(test_list.toString() ==
     "[CharLinkedList of size 1 <<x>>]");
}
//Testing the pushatfront function in a empty list
void pushAtFrontTestEdge(){
    CharLinkedList test_list;
    test_list.pushAtFront('z');
    assert(test_list.toString() ==
     "[CharLinkedList of size 1 <<z>>]");
}


//Testing the toString function with non-empty list
void toStringTest(){
    char arr[5] = {'a','b','c','d','e'};
    CharLinkedList test_list(arr, 5);
    assert(test_list.toString() ==
     "[CharLinkedList of size 5 <<abcde>>]"); 
}
//Testing the toReverseString function with non-empty list
void toReverseStringTest(){
    char arr[5] = {'a','b','c','d','e'};
    CharLinkedList test_list(arr, 5);
    assert(test_list.toReverseString() ==
     "[CharLinkedList of size 5 <<edcba>>]");    
}
//Testing the toString function with empty list
void toString_edge_test(){
    CharLinkedList test_list;
    assert(test_list.toString() ==
     "[CharLinkedList of size 0 <<>>]");
}
//Testing the toReverseString function with empty list
void toReverseString_edge_Test(){
    CharLinkedList test_list;
    assert(test_list.toString() ==
     "[CharLinkedList of size 0 <<>>]");
}

//Testing the insertAt function in a non-empty list with first, 
// middle, and last insertions
void insertTest(){
    char arr[5] = {'a','b','c','d','e'};
    CharLinkedList test_list(arr, 5);
    test_list.insertAt('x', 0);
    test_list.insertAt('e', 2);
    test_list.insertAt('c', 7);
    assert(test_list.elementAt(2) == 'e');
    assert(test_list.elementAt(0) == 'x');
    assert(test_list.elementAt(7) == 'c');
}

// Tests correct insertion into an empty AL.
// Afterwards, size should be 1 and element at index 0
// should be the element we inserted.
void insertAt_empty_correct() { 

    CharLinkedList test_list;
    test_list.insertAt('a', 0);
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');

}

// Tests incorrect insertion into an empty AL.
// Attempts to call insertAt for index larger than 0.
// This should result in an std::range_error being raised.
void insertAt_empty_incorrect() {

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    // insertAt for out-of-range index
    test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
    // if insertAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    range_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0]");
    
}

// Tests correct insertAt for front of 1-element list.
void insertAt_front_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at front
    test_list.insertAt('b', 0);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'a');
    
}

// Tests correct insertAt for back of 1-element list.
void insertAt_back_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at back
    test_list.insertAt('b', 1);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    
}

// Tests calling insertAt for a large number of elements.
// Not only does this test insertAt, it also checks that
// array expansion works correctly.
void insertAt_many_elements() {
    
    CharLinkedList test_list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.insertAt('a', i);
    }

    assert(test_list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
    
}

// Tests insertion into front of a larger list
void insertAt_front_large_list() {
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    test_list.insertAt('y', 0);

    assert(test_list.size() == 10);
    assert(test_list.elementAt(0) == 'y');
    assert(test_list.toString() ==
     "[CharLinkedList of size 10 <<yabczdefgh>>]");

}

// Tests insertion into the back of a larger list
void insertAt_back_large_list() {

    char test_arr[10] = { 'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 10);  

    test_list.insertAt('x', 10);

    assert(test_list.size() == 11);
    assert(test_list.elementAt(10) == 'x');
    assert(test_list.toString() == 
    "[CharLinkedList of size 11 <<yabczdefghx>>]"); 

}

// Tests insertion into the middle of a larger list
void insertAt_middle_large_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.insertAt('z', 3);

    assert(test_list.size() == 9);
    assert(test_list.elementAt(3) == 'z');
    assert(test_list.toString() ==
     "[CharLinkedList of size 9 <<abczdefgh>>]");

}

// Tests out-of-range insertion for a non-empty list.
void insertAt_nonempty_incorrect() {
   
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8]");
    
}

//Testing the insertAt function in a non-empty list with first, 
// middle, and last insertions
void insertInOrderTest(){
    char arr[5] = {'a','e','c','z','e'};
    CharLinkedList test_list(arr, 5);
    test_list.insertInOrder('a');
    test_list.insertInOrder('c');
    test_list.insertInOrder('f');
    //aacef
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'c');
    assert(test_list.elementAt(4) == 'f');
}
//Testing the insertAt function in a empty list 
void insertInOrder_EdgeTest(){
    CharLinkedList test_list;
    test_list.insertInOrder('a');
    // acecf
    assert(test_list.elementAt(0) == 'a');
}

//Testing the popfront function when the list is empty
void popFront_error_test() {
    CharLinkedList test_list;

    // var to track whether range_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.popFromFront();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}
//Testing the popback function when the list is empty
void popBack_error_test() {
    CharLinkedList test_list;

    // var to track whether range_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.popFromBack();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

//Testing the popfromback function in a non-empty list
void popFromBackTest(){
    char arr[5] = {'a','b','c'};
    CharLinkedList test_list(arr, 3);
    test_list.popFromBack();
    assert(test_list.toString() ==
     "[CharLinkedList of size 2 <<ab>>]");
    test_list.popFromBack();
    assert(test_list.toString() ==
     "[CharLinkedList of size 1 <<a>>]");
    test_list.popFromBack();
    assert(test_list.toString() ==
     "[CharLinkedList of size 0 <<>>]");
}
//Testing the popfromfront function in a non-empty list
void popFromFrontTest(){
    char arr[5] = {'a','b','c'};
    CharLinkedList test_list(arr, 3);
    test_list.popFromFront();
    assert(test_list.toString() ==
     "[CharLinkedList of size 2 <<bc>>]");
    test_list.popFromFront();
    assert(test_list.toString() ==
     "[CharLinkedList of size 1 <<c>>]");
    test_list.popFromFront();
    assert(test_list.toString() ==
     "[CharLinkedList of size 0 <<>>]");
}
//Testing the removeAt function when the index is larger than range
void removeAt_error_test() {
   
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.removeAt(42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8)");
    
}
//Testing the removeAt function when the index is smaller than range
void removeAt_error_test1() {
   
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.removeAt(-10);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (-10) not in range [0..8)");
    
}
//Testing the removeAt function when the index in empty list
void removeAt_error_test2() {
   
    CharLinkedList test_list;

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.removeAt(0);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (0) not in range [0..0)");
    
}
//Testing the replaceAt function when the index is larger than range
void replaceAt_error_test() {
   
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.replaceAt('c', 42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8)");
}

//Testing the replaceAt function when the index is smaller than range
void replaceAt_error_test1() {
   
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.replaceAt('c', -10);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (-10) not in range [0..8)");
}
//Testing the replaceAt function when the list is empty
void replaceAt_error_test2() {
   
    CharLinkedList test_list;

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.replaceAt('c', 0);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (0) not in range [0..0)");
}

//Testing the elementAt function in a non-empty list 
// with element at first, middle, and last
void elementAtTest(){
    char arr[5] = {'a','b','c','d','e'};
    CharLinkedList test_list(arr, 5);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(2) == 'c'); 
    assert(test_list.elementAt(4) == 'e'); 
}


//Testing the elementAt function when the index is larger than range
void elementAt_error_test() {
   
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.elementAt(42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8)");
}

//Testing the elementAt function when the index smaller than range
void elementAt_error_test1() {
   
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.elementAt(-10);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (-10) not in range [0..8)");
}
//Testing the elementAt function when the list is empty
void elementAt_error_test2() {
   
    CharLinkedList test_list;

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.elementAt(0);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (0) not in range [0..0)");
}
//Testing the remove function in a non-empty list
void removeTest(){
    char arr[5] = {'a','b','c','d','e'};
    CharLinkedList test_list(arr, 5);
    test_list.removeAt(1);
    assert(test_list.toString() ==
     "[CharLinkedList of size 4 <<acde>>]");
}
//Testing the replaceAt function in a non-empty list
void replaceAtTest(){
    char arr[5] = {'a','b','c','d','e'};
    CharLinkedList test_list(arr, 5);
    test_list.replaceAt('c', 1);
    assert(test_list.elementAt(1) == 'c');
}
//Testing the concatenate function in a non-empty list
void concatenate(){
    char arr[5] = {'a','b','c','d','e'};
    CharLinkedList test_list(arr, 5);
    CharLinkedList test_list1('a');
    test_list.concatenate(&test_list1);
    assert(test_list.toString() ==
     "[CharLinkedList of size 6 <<abcdea>>]");
    test_list.concatenate(&test_list);
    assert(test_list.toString() ==
     "[CharLinkedList of size 12 <<abcdeaabcdea>>]");
}

//Testing the concatenate function in connecting an empty 
// list to a non-empty list
void concatenate_edge_test1(){
    char arr[5] = {'a','b','c','d','e'};
    CharLinkedList test_list(arr, 5);
    CharLinkedList test_list1;
    test_list.concatenate(&test_list1);
    assert(test_list.toString() ==
     "[CharLinkedList of size 5 <<abcde>>]");
}
//Testing the concatenate function in connecting an empty list to a empty list
void concatenate_edge_test2(){
    CharLinkedList test_list;
    CharLinkedList test_list1;
    test_list.concatenate(&test_list1);
    assert(test_list.toString() ==
     "[CharLinkedList of size 0 <<>>]");
}

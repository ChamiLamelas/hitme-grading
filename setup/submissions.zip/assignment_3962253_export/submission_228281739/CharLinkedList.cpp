/*
 *  CharLinkedList.cpp
 *  NAME: Cynthia Chao (gchao02)
 *  DATE CREATED: 2.2
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  FILE PURPOSE HERE: Implement a version of the doubly linked 
 *  list data structure. 
 *  This is the CharLinkedList class definition. 
 *
 */

#include "CharLinkedList.h"
/*
 * name:      deleteNodesRecursively
 * purpose:   helper function to assist deleting nodes recursively
 * arguments: take a node pointer as parameter
 * returns:   none
 * effects:   recurse and delete the nodes in a post-order
 */
void CharLinkedList::deleteNodesRecursively(Node* node){
    if (node == nullptr) {
        return;// Base case
    } else {
        deleteNodesRecursively(node->next); // Recur to the next node
        delete node; // Delete the current node
    }
}
/*
 * name:      clear
 * purpose:   make the instance into an empty linked list.
 * arguments: none
 * returns:   none 
 * effects:   delete and deallocate data array and reinitialize the array
 *            by using the helper function to delete nodes
 */
void CharLinkedList::clear(){
    // Start recursive deletion from the front
    deleteNodesRecursively(front); 
    front = nullptr;
    currsize = 0;
}
/*
* name:      newNode
* purpose:   create new node on the heap
* arguments: take a char type data, next pointer, and prev pointer as parameter
* returns:   new_node that is created
* effects:   create new node and updates private variables 
* like data, next, and prev with provided input
*/
CharLinkedList::Node *CharLinkedList::newNode(char newData, 
Node *next, Node *prev){
    Node *new_node = new Node;
    new_node->data = newData;
    new_node->next = next;
    new_node->prev = prev;        
    return new_node;
}
/*
* name:      CharLinkedList
* purpose:   constructor to initialize an empty CharLinkedList
* arguments: none
* returns:   none
* effects:   currSize to 0 and set front to nullptr
*/
CharLinkedList::CharLinkedList(){
    front = nullptr;
    currsize  = 0;
}
/*
 * name:      CharLinkedList
 * purpose:   constructor to creates a one element
 *            linked list consisting of that character
 * arguments: takes in a single character as a parameter 
 * returns:   none
 * effects:   updates currsize to 1; 
 * create a new node with newNode function with one character;
 * connect front pointer to the node
 */
CharLinkedList::CharLinkedList(char c){
    front = nullptr;
    CharLinkedList::Node *node =
    CharLinkedList::newNode(c, nullptr, front);
    front = node;
    currsize = 1;
}

/*
 * name:      CharLinkedList
 * purpose:   constructor to create a new linked list 
 *            containing the characters in the array
 * arguments: takes an array of characters and the integer 
 *            length of that list of
 *            characters as parameters;
 * returns:   none
 * effects:   updates capacity and currSize to inputted size; 
 *            create a new data array with given array of characters
 */
CharLinkedList::CharLinkedList(char arr[], int size){
    front = nullptr;
    currsize = 0;
    for (int i = 0; i < size; ++i) {
        this->pushAtBack(arr[i]);
    }
}
/*
 * name:      copyFrom
 * purpose:   Utility function to copy list from another instance
 * arguments: takes a instance of the class as parameter
 * returns:   none
 * effects:   copying another list to build a new list
 */

void CharLinkedList::copyFrom(const CharLinkedList& other){
    Node* curr = other.front;
    while (curr != nullptr) {
        pushAtBack(curr->data); 
        curr = curr->next;
    }
}
/*
 * name:      CharLinkedList
 * purpose:   copy constructor for the class that makes 
 *            a deep copy of a given instance
 * arguments: takes a instance of the class as parameter
 * returns:   none
 * effects:   initialize current list, 
 *            create a new linked list with given array of characters
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other){
    if (other.isEmpty()) {
        // If the other list is empty, 
        // simply initialize this list to be empty.
        return;
    }
    // initialize data for copying another list
    front = nullptr;
    currsize = 0;
    copyFrom(other);
}
/*
 * name:      CharLinkedList
 * purpose:   destructor that destroys/deletes/recycles 
 *            all heap-allocated data in the current linked
 *            list.
 * arguments: none
 * returns:   none
 * effects:   delete the every node to deallocate the memory
 */
CharLinkedList::~CharLinkedList(){
    // Start recursive deletion from the front
    deleteNodesRecursively(front); 
    front = nullptr;
}
/*
 * name:      assignment operator
 * purpose:   Assigns the contents of the specified 
 *            CharLinkedList to this instance.
 * arguments: const CharLinkedList &other - A reference to the
 *            CharLinkedList to copy from.
 * returns:   CharLinkedList& - A reference to this instance 
 *            after the assignment.
 * effects:   Copies all the elements from the specified 
 *            CharLinkedList to this instance. If the current size is 
 *            less than the size of 'other', it reallocates memory to 
 *            accommodate the new elements. Previous contents of this instance
 *            are overwritten. If the function is called with the same
 *            object, it does nothing.
 */
CharLinkedList& CharLinkedList::operator=(const CharLinkedList& other) {
    if (this != &other) {
        // Delete current nodes
        clear();
        // copy the contents
        copyFrom(other);
    }
    return *this;
}
/*
 * name:      isEmpty
 * purpose:   decide whether or not the the list is empty
 * arguments: none
 * returns:   boolean value of true or false
 * effects:   it is true if this
 *            specific instance of the class is empty 
 *            (front points to nullptr) 
 *            and false otherwise
 */
bool CharLinkedList::isEmpty() const{
    if (front == nullptr){
        return true;
    } else {
        return false;
    }
}
/*
 * name:      size
 * purpose:   a getter to return the private variable
 * arguments: none
 * returns:   private variable currsize 
 * effects:   return the private variable currsize to make it accesible
 */
int  CharLinkedList::size() const{
    return currsize;
}
/*
 * name:      first
 * purpose:   a getter to return the first element of the list
 * arguments: none
 * returns:   first element of the list
 * effects:   get the first character in the linked list, make it accesible;
 *            if the linked list is empty, 
 *            throw an std::runtime_error exception
 */
char CharLinkedList::first() const{
    if (isEmpty()) {
        throw std::runtime_error("cannot get first of empty LinkedList");
    }
    return elementAt(0);
}
/*
 * name:      last
 * purpose:   a getter to return the last element of the list
 * arguments: none
 * returns:   last element of the list
 * effects:   get the last character in the linked list, make it accesible;
 *            if the linked list is empty, 
 *            throw an std::runtime_error exception
 */
char CharLinkedList::last() const{
    if (isEmpty()) {
        throw std::runtime_error("cannot get last of empty LinkedList");
    }
    return elementAt(currsize - 1);
}
/*
 * name:      elementAt
 * purpose:   get the element (char) in 
 *            the linked list at that index
 * arguments: a index in linked list
 * returns:   the element (char) in the linked list at that index
 * effects:   get the element (char) in given index in the linked list, 
 *            make it accesible by recursing until reach the index;
 *            If the index is out of range it should throw a C++
 *            std::range_error exception
 */
char CharLinkedList::elementAt(int index) const{
    if (index < 0 or index >= currsize) {
        throw std::range_error("index (" + std::to_string(index) + 
        ") not in range [0.." + std::to_string(currsize) + ")");
    }
    return elementAtHelper(front, index, 0);
}
/*
 * name:      elementAtHelper
 * purpose:   helper function to recurse until find the index and 
 *            return the data at that index
 * arguments: a index in linked list, a node pointer, and an integer counter
 * returns:   the element (char) in the linked list at that index
 * effects:   get the element (char) in given index in the linked list, 
 *            make it accesible by recursing until reach the index
 */
char CharLinkedList::elementAtHelper(Node* curr, int index, int counter) const{
    if (index == counter){
        return curr->data;
    } else {
        counter++;
        return elementAtHelper(curr->next, index, counter);
    }
}

/*
 * name:      toString
 * purpose:   form a line of text consists of characters
 *            of the CharLinkedList and the size.
 * arguments: none
 * returns:   It returns a string which contains the characters
 *            of the CharLinkedList and the size.
 * effects:   returns a string formatted like [CharLinkedList of size 5
 *            (the size of the array) 
 *            <<Alice>> (the elements in the array)]
 */
std::string CharLinkedList::toString() const{
    std::string result = "[CharLinkedList of size " +
    std::to_string(currsize) + " <<";
    for (Node *curr = front; curr != nullptr; curr = curr->next){
        result += curr->data;
    }
    result += ">>]";
    return result;
}    
/*
 * name:      toReverseString
 * purpose:   form a line of text consists of characters
 *            of the CharLinkedList in a reverse way and the size.
 * arguments: none
 * returns:   It returns a string which contains the reversive characters
 *            of the CharLinkedList and the size.
 * effects:   returns a string formatted like [CharLinkedList of size 5
 *            (the size of the array) 
 *            <<ecila>> (the elements in the array in reversive way)]
 */
std::string CharLinkedList::toReverseString() const{
    std::string result = "[CharLinkedList of size " +
        std::to_string(currsize) + " <<";
    if (front != nullptr){
        ReverseHelper(result, front);
    }
    result += ">>]";
    return result;     
}


/*
 * name:      ReverseHelper
 * purpose:   link the characters in the linked list from
 *            the back to the front as a string
 * arguments: Reference to the string result and a node pointer
 * returns:   None
 * effects:   traverse to the end of the linked list and goes back,
 *            adding each node's data to the string reversely
 */
void CharLinkedList::ReverseHelper(std::string &result, Node *curr) const{
    if (curr != nullptr){
        ReverseHelper(result, curr->next);
        result += curr->data;
    }
}  
/*
 * name:      pushAtBack
 * purpose:   to add a character to the back of the linked list
 * arguments: takes an element (char) as parameter
 * returns:   none
 * effects:   create a new node; if list is empty, then directly 
 *            point front to newNode; if not, traverse to the 
 *            last element, update the next and prev pointers
 */
void CharLinkedList::pushAtBack(char c){
    CharLinkedList::Node* newNode 
    = CharLinkedList::newNode(c, nullptr, nullptr);
    if (isEmpty()) { // If the list is empty
        newNode->prev = nullptr; // It's the first node, so prev is nullptr
        front = newNode; // The new node is now the front of the list
    } else {
        Node* current = front;
        // Traverse to the end of the list
        while (current->next != nullptr) { 
            current = current->next;
        }
        // Link the current last node to the new node
        current->next = newNode; 
            // Set the new node's prev to the current last node
        newNode->prev = current;
    }
    currsize++;
}
/*
 * name:      pushAtFront
 * purpose:   to add a character to the front of the array list
 * arguments: takes an element (char) as parameter
 * returns:   none
 * effects:   point front to the newnode while newnode's next points 
 * to what front originally points to (the original second node, 
 * newnode's prev don't need to point back
 */
void CharLinkedList::pushAtFront(char c){
    front = newNode(c, front, nullptr);
    currsize++;
}
/*
 * name:      insertAt
 * purpose:   to insert a character at given index in linked list
 * arguments: takes an element (char) and index (int) as parameter
 * returns:   none
 * effects:   If the index is out of range, throw std::range_error exception
 *            if index is the first element, use pushAtFront function;
 *            if it's last,
 *            use pushAtBack function; if in the middle, create new node 
 *            and find right position to insert the new node 
 *            in by updating the prev and next pointers
 */
void CharLinkedList::insertAt(char c, int index){
    // Check if the index is out of range
    if (index < 0 or index > currsize) {
        throw std::range_error("index (" + std::to_string(index) 
        + ") not in range [0.." + std::to_string(currsize) + "]");
    }
    if (index == 0){
        pushAtFront(c);
    } else if (index == currsize){
        pushAtBack(c);
    } else {
        Node* curr = front;
        CharLinkedList::Node* newNode 
        = CharLinkedList::newNode(c, nullptr, nullptr); 
        // traverse to find where to insert
        for (int i = 0; i < index - 1; i++){ 
            curr = curr->next;
        }
        // updates next and prev
        newNode->next = curr->next;
        newNode->prev = curr; 
        curr->next->prev = newNode; 
        curr->next = newNode;
        currsize++;
    }
}
/*
 * name:      insertInOrder
 * purpose:   takes an element (char), inserts it into the array list in ASCII
 *            order
 * arguments: takes an element (char) as parameter
 * returns:   none
 * effects:   add given character to the list in ASCII order by comparing  
 *            each node's data with the original list; if the character's 
 *            ASCII order is larger than every node's data, 
 *            then execute the pushAtBack() to add the character at back
 */
void CharLinkedList::insertInOrder(char c){
    Node* curr = front;
    if(isEmpty()){
        pushAtBack(c);
        return;
    }
    for (int i = 0; i < currsize; i++){
        if (c <= curr->next->data){
            insertAt(c, i);
            return;
        }
        curr = curr->next;
    }
    pushAtBack(c);
}
/*
 * name:      popFromFront
 * purpose:   remove the first element from the linked list
 * arguments: none
 * returns:   none
 * effects:   If the list is empty it should throw a std::runtime_error
 *            exception; then hold the front node,
 *            move front pointer to next node,
 *            and delete the node; current size decrease one
 */
void CharLinkedList::popFromFront(){
    // Check if the list is empty
    if (isEmpty()) {
        throw std::runtime_error("cannot pop from empty LinkedList");
    }
    // Hold the node to be deleted
    Node* nodeToPop = front;
    // Move the front pointer to the next node
    front = front->next;
    if (front != nullptr) {
        front->prev = nullptr;
    }
    // Delete the old front node
    delete nodeToPop;
    // Decrement the size of the list
    currsize--;
}
/*
 * name:      popFromBack
 * purpose:   remove the last element from the linked list
 * arguments: none
 * returns:   none
 * effects:   If the list is empty it should throw a std::runtime_error
 *            exception; delete the node directly if there's only one; 
 *            find the second last node to delete the last node; 
 *            update currsize and next pointer
 */
void CharLinkedList::popFromBack(){
    if (isEmpty()) {
        throw std::runtime_error("cannot pop from empty LinkedList");
    }
    // If there's only one node in the list, delete it
    if (front->next == nullptr) {
        delete front;
        front = nullptr;
        currsize = 0;
        return;
    }
    // Traverse the list to find the second-to-last node
    Node* current = front;
    while (current->next->next != nullptr) {
        current = current->next;
    }
    // Delete the last node
    delete current->next;
    // Set the next of second-to-last node to nullptr
    current->next = nullptr;
    // Decrement the size of the list
    currsize--;
}
/*
 * name:      removeAt
 * purpose:   remove the given element from the linked list
 * arguments: integer index from the list
 * returns:   none
 * effects:   If the index is out of range it should throw a std::range_error
 *            exception; if it's first element, use popFromFront() function;
 *            if it's last element, use popFromBack(); if in the middle,
 *            find the element with the index and delete it; 
 *            updates prev and next; decrease size
 */
void CharLinkedList::removeAt(int index){
    if (index < 0 or index >= currsize) {
        throw std::range_error("index (" + std::to_string(index) 
        + ") not in range [0.." + std::to_string(currsize) + ")");
    } 
    Node* nodetoremove = front;

    if (index == 0){
        popFromFront();
    } else if (index == currsize - 1){
        popFromBack();
    } else {
        Node* curr = front;
        for (int i = 0; i < index - 1; i++){ 
            curr = curr->next;
        }
        nodetoremove = curr->next;
        curr->next = nodetoremove->next;
        if (nodetoremove->next != nullptr){
            nodetoremove->next->prev = curr;
        }
    }
    delete nodetoremove;
    currsize--;
}
/*
 * name:      replaceAt
 * purpose:   replaces the element at the specified index with the new element
 * arguments: integer index from the list
 * returns:   none
 * effects:   If the index is out of range it should throw a std::range_error
 *            exception; replaces the element at the specified
 *            index with the new element by using recursive function
 */
void CharLinkedList::replaceAt(char c, int index){
    if (index < 0 or index >= currsize) {
        throw std::range_error("index (" + std::to_string(index) 
        + ") not in range [0.." + std::to_string(currsize) + ")");
    }  
    indexFinder(front, c, index, 0);
}
/*
 * name:      indexFinder
 * purpose:   helper function to find target index 
 *            and replaces the element with the new element
 * arguments: integer index from the list
 * returns:   none
 * effects:   replaces the element at the specified
 *            index with the new element by recursing
 */
void CharLinkedList::indexFinder(Node* node, char c, 
int targetIndex, int currentIndex){
    if (node == nullptr) {
        // Base case: reached the end of the 
        // list without finding the target index
        return; 
    }
    if (currentIndex == targetIndex) {
        node->data = c; // Found the target index, replace the char
        return;
    }
    // Recurse to the next node
    indexFinder(node->next, c, targetIndex, currentIndex + 1); 
}
/*
 * name:      concatenate
 * purpose:   adds a copy of the linked list pointed to by 
 *            the parameter value to the end of the linked
 *            list the function was called from
 * arguments: a pointer to a second CharArrayList
 * returns:   none
 * effects:   if it's nullptr or empty, end the function;
 *            if it's self-concatenation, using copy constructor
 *            to make a self-copy and concatenate;
 *            then add all elements from the second 
 *            CharArrayList to the back of the first
 */
void CharLinkedList::concatenate(CharLinkedList *other){
    if (other == nullptr or other->currsize == 0) {
        // Concatenating with an empty list or 
        // a null pointer doesn't change the current list.
        return;
    }
    CharLinkedList temp(*other);
    for (int i = 0; i < temp.size(); i++){
        pushAtBack(temp.elementAt(i));
    }
}

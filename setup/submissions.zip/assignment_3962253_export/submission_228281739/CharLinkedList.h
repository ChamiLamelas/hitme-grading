/*
 *  CharLinkedList.h
 *  NAME: Cynthia Chao (gchao02)
 *  DATE CREATED: 2.2
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  FILE PURPOSE HERE: CharLinkedList is a class that 
 *  represents a linked list data structure in char type. 
 *  The list is doubly linked character list, which can be manipulated
 *  (add, remove, replace) and accessed by different functions.
 *  Below is the class declaration.
 *
 */

#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H
#include <string>
#include <iostream>
#include <stdexcept>
class CharLinkedList {
public:

    CharLinkedList();
    CharLinkedList(char c);
    CharLinkedList(char arr[], int size);
    CharLinkedList(const CharLinkedList &other);
    ~CharLinkedList();
    CharLinkedList &operator=(const CharLinkedList &other);
    bool isEmpty() const;
    int  size() const;
    char first() const;
    char last() const;
    char elementAt(int index) const;
    std::string toString() const;
    std::string toReverseString() const;
    void pushAtBack(char c);
    void pushAtFront(char c);
    void insertAt(char c, int index);
    void insertInOrder(char c);
    void popFromFront();
    void popFromBack();
    void removeAt(int index);
    void replaceAt(char c, int index);
    void concatenate(CharLinkedList *other);
    void clear();


private:
    struct Node {
        char       data;
        Node       *prev;
        Node       *next;
    };

    Node *front;
    int   currsize = 0;
    // helper functions

    void deleteNodesRecursively(Node* node);
    Node *newNode(char newData, Node *next, Node *prev);
    void copyFrom(const CharLinkedList& other); 
    void indexFinder(Node* node, char c, int targetIndex, int currentIndex);
    char elementAtHelper(Node* curr, int index, int counter) const;
    void ReverseHelper(std::string &result, Node *curr) const;
};

#endif

/*
 *  unit_tests.h
 *  Kelvin Guobadia
 *  1/3/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  Testing file for Linked List class using unit_test framework
 *
 */

#include <iostream>
#include <cassert>
#include "CharLinkedList.h"

void constructor_test()
{
    CharLinkedList list;
    assert(list.size() == 0);
}

void constructor_test_2()
{
    CharLinkedList list('b');
    assert(list.size() == 1);
    assert(list.first() == 'b');
}

void constructor_test3()
{
    char arr[5] = {'A', 'l', 'i', 'c', 'e'};
    CharLinkedList list(arr, 5);
    assert(list.size() == 5);
    assert(list.first() == 'A');
}

void constructor_test4()
{
    char arr[5] = {'A', 'l', 'i', 'c', 'e' };    
    CharLinkedList A_list(arr, 5);
    CharLinkedList B_list(A_list);
    assert(B_list.size() == 5);
    assert(B_list.first() == 'A');
}

void constructor_test5()
{
    char arr[5] = {'A', 'l', 'i', 'c', 'e' };    
    CharLinkedList A_list(arr, 5);
    CharLinkedList B_list;
    B_list = A_list;                             
    B_list.pushAtFront('B');
    assert(B_list.size() == 6);
}

void isEmpty_test()
{
    CharLinkedList list;
    assert(list.isEmpty());
}

void clear_test()
{
    char arr[3] = {'p', 'o', 'p'};
    CharLinkedList list(arr, 3);
    assert(list.size() == 3);
    list.clear();
    assert(list.size() == 0);
}

void elementAt_test()
{
    char arr[5] = {'A', 'l', 'i', 'c', 'e'};
    CharLinkedList list(arr, 5);
    assert(list.elementAt(4) == 'e');
    assert(list.elementAt(1) == 'l');
    assert(list.elementAt(0) == 'A');
}

void elementAt_range_test()
{
    bool range_error_thrown = false;

    
    std::string error_message = "";
    char arr_test[3] = {'p', 'o', 'p'};
    CharLinkedList test_list{arr_test, 3};
    try {
        test_list.elementAt(42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..3)");
}

void first_test()
{
    CharLinkedList list('a');
    assert(list.first() == 'a');
}

void first_empty_test()
{
    bool runtime_error = false;

    std::string error_message = "";

    CharLinkedList test_list;
    try {
        
        test_list.first();
    }
    catch (const std::runtime_error &e) {
        runtime_error = true;
        error_message = e.what();
    }

    // out here, we make our assertions
    assert(runtime_error);
    assert(error_message == "cannot get first of empty LinkedList");
}

void last_test()
{
    char arr[2] = {'a', 'b'};
    CharLinkedList list(arr, 2);
    assert(list.last() == 'b');
}

void last_empty_test()
{
    bool runtime_error = false;

    std::string error_message = "";

    CharLinkedList test_list;
    try {
        
        test_list.last();
    }
    catch (const std::runtime_error &e) {
        runtime_error = true;
        error_message = e.what();
    }

    // out here, we make our assertions
    assert(runtime_error);
    assert(error_message == "cannot get last of empty LinkedList");
}

void toString_test()
{
    char arr[5] = {'A', 'l', 'i', 'c', 'e'};
    CharLinkedList list(arr, 5);
    assert(list.toString() == "[CharLinkedList of size 5 <<Alice>>]");
}

void toString_empty_test()
{
    CharLinkedList list;
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}

void toReverseString_test()
{
    char arr[5] = {'A', 'l', 'i', 'c', 'e' };    
    CharLinkedList list(arr, 5);
    assert(list.toReverseString() == "[CharLinkedList of size 5 <<ecilA>>]");
}

void toReverseString_empty_test()
{
    CharLinkedList list;
    assert(list.toReverseString() == "[CharLinkedList of size 0 <<>>]");
}

void pushAtBack_test()
{
    char arr[5] = {'A', 'l', 'i', 'c', 'e' };    
    CharLinkedList list(arr, 5);
    list.pushAtBack('b');
    assert(list.size() == 6);
    assert(list.last() == 'b');
}

void pushAtBack_emptytest()
{
    CharLinkedList list;
    list.pushAtBack('a');
    assert(list.size() == 1);
    assert(list.first() == 'a');
    assert(list.last() == 'a');
    assert(list.elementAt(0) == 'a');
}

void pushAtFront_test()
{
    CharLinkedList list;
    list.pushAtFront('c');
    assert(list.size() == 1);
}

void pushAtFront_emptytest()
{
    CharLinkedList list;
    list.pushAtFront('a');
    assert(list.size() == 1);
    assert(list.first() == 'a');
    assert(list.last() == 'a');
    assert(list.elementAt(0) == 'a');
}

void insertAt_test()
{
    char arr[3] = {'S', 'o', 'p'};    
    CharLinkedList list(arr, 3);
    list.insertAt('a', 2);
    assert(list.size() == 4);
    assert(list.elementAt(0) == 'S');
    assert(list.elementAt(1) == 'o');
    assert(list.elementAt(2) == 'a');
    assert(list.elementAt(3) == 'p');
    assert(list.toString() == "[CharLinkedList of size 4 <<Soap>>]");
}

void insertAt_range_test()
{
    bool range_error_thrown = false;

    
    std::string error_message = "";
    char arr_test[3] = {'p', 'o', 'p'};
    CharLinkedList test_list{arr_test, 3};
    try {
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..3)");
}

void insertInOrder_test()
{
    char arr[2] = {'a', 'c'};
    CharLinkedList list(arr, 2);
    list.insertInOrder('b');
    assert(list.size() == 3);
    assert(list.elementAt(1) == 'b');
    assert(list.toString() == "[CharLinkedList of size 3 <<abc>>]");
}

void insertInOrder_empty_test()
{
    CharLinkedList list;
    list.insertInOrder('h');
    assert(list.size() == 1);
    assert(list.first() == 'h');
}

void insertInOrder_lastElement()
{
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList list(arr, 3);
    list.insertInOrder('d');
    assert(list.size() == 4);
}

void popFromFront_test()
{
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList list(arr, 3);
    list.popFromFront();
    assert(list.size() == 2);
    assert(list.toString() == "[CharLinkedList of size 2 <<bc>>]");
}

void popFromBack_test()
{
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList list(arr, 3);
    list.popFromBack();
    assert(list.size() == 2);
    assert(list.toString() == "[CharLinkedList of size 2 <<ab>>]");
}

void removeAt_test()
{
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList list(arr, 3);
    list.removeAt(1);
    assert(list.size() == 2);
    assert(list.toString() == "[CharLinkedList of size 2 <<ac>>]");
}

void removeAt_range_test()
{
    bool range_error_thrown = false;

    
    std::string error_message = "";
    char arr_test[3] = {'p', 'o', 'p'};
    CharLinkedList test_list{arr_test, 3};
    try {
        test_list.removeAt(42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..3)");
}

void replaceAt_test()
{
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList list(arr, 3);
    list.replaceAt('d', 1);
    assert(list.size() == 3);
    assert(list.toString() == "[CharLinkedList of size 3 <<adc>>]");
}

void replaceAt_range_test()
{
    bool range_error_thrown = false;

    
    std::string error_message = "";
    char arr_test[3] = {'p', 'o', 'p'};
    CharLinkedList test_list{arr_test, 3};
    try {
        test_list.replaceAt('a', 42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..3)");
}

void replaceAt_test_front()
{
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList list(arr, 3);
    list.replaceAt('p', 0);
    assert(list.size() == 3);
    assert(list.toString() == "[CharLinkedList of size 3 <<pbc>>]");
}

void concatenate_test()
{
    char arr1[6] = {'S', 'p', 'o', 'n', 'g', 'e'};
    char arr2[3] = {'b', 'o', 'b'};
    CharLinkedList A_list(arr1, 6);
    CharLinkedList B_list(arr2, 3);
    A_list.concatenate(&B_list);
    assert(A_list.size() == 9);
    assert(A_list.toString() == "[CharLinkedList of size 9 <<Spongebob>>]");
}

void concatenate_empty_test()
{
    char arr[3] = {'c', 'a', 't'};
    CharLinkedList list;
    CharLinkedList A_list(arr, 3);
    list.concatenate(&A_list);
    assert(list.size() == 3);
    assert(list.toString() == "[CharLinkedList of size 3 <<cat>>]");
}

void concatenate_empty_test_2()
{
    char arr[3] = {'c', 'a', 't'};
    CharLinkedList list;
    CharLinkedList A_list(arr, 3);
    A_list.concatenate(&list);
    assert(A_list.size() == 3);
    assert(A_list.toString() == "[CharLinkedList of size 3 <<cat>>]");
}

void concatenate_self_test()
{
    char arr[3] = {'c', 'a', 't'};
    CharLinkedList A_list(arr, 3);
    A_list.concatenate(&A_list);
    assert(A_list.size() == 6);
    assert(A_list.toString() == "[CharLinkedList of size 6 <<catcat>>]");
}
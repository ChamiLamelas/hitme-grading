/*
 *  CharLinkedList.cpp
 *  Kelvin Guobadia
 *  2/3/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Implementation for all methods declared in the CharLinkedList class
 *
 */

#include "CharLinkedList.h"
#include <sstream>

using namespace std;

CharLinkedList::CharLinkedList()
{
    front = nullptr;
    charSize = 0;
}

CharLinkedList::CharLinkedList(char c)
{
    Node *newNode = createNode(c);
    front = newNode;

    charSize = 1;
    
}

CharLinkedList::CharLinkedList(char arr[], int size)
{
    charSize = 0;
    front = nullptr;
    for (int i = size - 1; i >= 0; i--)
    {
        pushAtFront(arr[i]);
    }
}

CharLinkedList::CharLinkedList(const CharLinkedList &other)
{
    charSize = other.charSize;
    if (other.front == nullptr)
    {
        front = nullptr;
    }
    else
    {
        // Create a new node for the first element in the other list
        front = createNode(other.front->input);
        // Create pointers to traverse both lists
        Node *temp = front;
        Node *temp2 = other.front->next;
        // Iterate through the other list and create new nodes for each element
        while (temp2 != nullptr)
        {
            // Create a new node and copy the data
            temp->next = new Node;
            temp = temp->next;
            temp->input = temp2->input;

            // Move to the next node in the other list
            temp2 = temp2->next;
        }
        // Set the last node's next pointer to nullptr
        temp->next = nullptr;
    }
}

CharLinkedList::~CharLinkedList()
{
    Node *temp = front;
    while (temp != nullptr)
    {
        Node *temp2 = temp->next;
        delete temp;
        temp = temp2;
    }

    front = nullptr;
    charSize = 0;
}

CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other)
{
    // checking for self assignment
    if (this == &other)
    {
        return *this;
    }
    // copying data members from other to this
    charSize = other.charSize;
    if (other.front == nullptr)
    {
        front = nullptr;
    } 
    else 
    {
        // Create a new node for the first element in the other list
        front = createNode(other.front->input);
        front->input = other.front->input;
        // Create a pointer to traverse the new list
        Node *temp = front;

        // Create a pointer to traverse the other list
        Node *temp2 = other.front->next;
        // Iterate through the other list and create new nodes for each element
        while (temp2 != nullptr)
        {
            // Create a new node and copy the data
            temp->next = new Node;
            temp->next->input = temp2->input;
            // Move to the next node in both lists
            temp = temp->next;
            temp2 = temp2->next;
        }
        // Set the last node's next pointer to nullptr
        temp->next = nullptr;
    }
    return *this;
}

bool CharLinkedList::isEmpty()
{
    return (charSize == 0);
}

void CharLinkedList::clear()
{
    // Traverse the list and deallocate memory for each node
    while (front != nullptr)
    {
        Node *temp = front; // Keep a pointer to the current node
        front = front->next; // Move front to the next node
        delete temp; // Deallocate memory for the current node
    }

    // Reset the size to zero and front pointer to nullptr
    charSize = 0;
    front = nullptr;
}

int CharLinkedList::size() const
{
    return charSize;
}

char CharLinkedList::first() const
{
    if (charSize == 0)
    {
        // Throw a runtime_error exception 
        throw std::runtime_error("cannot get first of empty LinkedList");
    }
    return front->input;
}

char CharLinkedList::last() const
{
    if (charSize == 0)
    {
        // Throw a runtime_error exception 
        throw std::runtime_error("cannot get last of empty LinkedList");
    }
    if (charSize == 1)
    {
        return front->input;
    }
    else
    {
        Node *temp = front;
        for (int i = 0; i < charSize; i++)
        {
            if (temp->next == nullptr)
            {
                return temp->input;
            }
            temp = temp->next;
        }
    }
}

char CharLinkedList::elementAt(int index) const
{
    stringstream ss;
    // Check if the index is out of range
    if (index < 0 or index >= charSize)
    {
        // Throw a range_error exception 
        ss << "index (" << index << ") not in range [0.."<< charSize <<")";
        throw range_error(ss.str());
    }

    int counter = 0;
    Node *temp = front;
    for (int i = 0; i < charSize; i++)
    {
        if (counter == index)
        {
            return temp->input;
        }
        temp = temp->next;
        counter++;
    }
}

string CharLinkedList::toString() const
{
    stringstream ss;
    ss << "[CharLinkedList of size " << charSize << " <<";
    Node *temp = front;
    for (int i = 0; i < charSize; i++)
    {
        ss << temp->input;
        temp = temp->next;
    }
    ss << ">>]";
    return ss.str();
}

string CharLinkedList::toReverseString() const
{
    stringstream ss;
    ss << "[CharLinkedList of size " << charSize << " <<";
    Node *temp = front;
    // traverse through list and print out each char in each node
    for (int i = 0; i < charSize; i++)
    {
        ss << elementAt(charSize - 1 - i);
    }
    ss << ">>]";
    return ss.str();
}

void CharLinkedList::pushAtBack(char c)
{
    Node *newNode = createNode(c);

    if (isEmpty())
    {
        front = newNode;
    }
    else
    {
        Node *temp = front;
        while (temp->next != nullptr) {
            temp = temp->next;
        }
        // Connect the last node to the new node
        temp->next = newNode;
    }
    charSize++;
}

void CharLinkedList::pushAtFront(char c)
{
    // create new node
    Node *newChar = createNode(c);
    
    // empty LinkedList condition: nothing in the list yet, size = 0
    if (isEmpty())
    {
        newChar->next = nullptr;
        front = newChar;
    }
    // non-empty LinkedList condition: front points to some node
    else 
    {
        newChar->next = front;
        front = newChar;
    }
    charSize++;
}

void CharLinkedList::insertAt(char c, int index)
{
    stringstream ss;
    // Check if the index is out of range
    if (index < 0 or index > charSize)
    {
        // Throw a range_error exception 
        ss << "index (" << index << ") not in range [0.."<< charSize <<"]";
        throw range_error(ss.str());
        return;
    }
    if (index == 0)
    {
        pushAtFront(c);
    }
    else if (index == charSize)
    {
        pushAtBack(c);
    }
    else
    {
        int counter = 0;
        // create a new node
        Node *newNode = createNode(c);
        Node *temp = front;
        Node *temp2 = front->next;
        // traverse through list
        for (int i = 0; i < charSize; i++)
        {
            if (counter == index - 1)
            {
                // if index is reached, insert newNode in between temp and temp2
                temp->next = newNode;
                newNode->next = temp2;
                charSize++;
                return;
            }
            temp = temp->next;
            temp2 = temp2->next;
            counter++;
        }
        // increment charsize
        charSize++;
    }
}

void CharLinkedList::insertInOrder(char c)
{
    if (isEmpty())
    {
        pushAtFront(c);
    }
    else
    {
        Node *newNode = createNode(c);
        Node *temp = front;
        Node *temp2 = nullptr;
        // traverse through list, comparing the given char to all chars in list
        for (int i = 0; i < charSize; i++)
        {
            // if char should be inserted at the end of list, call pushAtBack
            if (i == charSize - 1 and c > temp->input)
            {
                delete newNode;
                pushAtBack(c);
            }
            if (c < temp->input)
            {
                temp2->next = newNode;
                newNode->next = temp;
                charSize++;
                return;
            }
            temp2 = temp;
            temp = temp->next;
        }
    }
}

void CharLinkedList::popFromFront()
{
    // Check if the array list is empty
    if (charSize == 0)
    {
        // Throw a runtime_error exception 
        throw runtime_error("cannot pop from empty LinkedList");
    }
    // delete the first element
    Node *temp = front;
    front = front->next;
    delete temp;
    charSize--;
}

void CharLinkedList::popFromBack()
{
    // Check if the array list is empty
    if (charSize == 0)
    {
        // Throw a runtime_error exception 
        throw runtime_error("cannot pop from empty LinkedList");
    }
    // delete the last element
    Node *temp = front;
    Node *temp2 = nullptr;
    while (temp->next != nullptr)
    {
        temp2 = temp;
        temp = temp->next;
    }
    delete temp;
    temp2->next = nullptr;
    charSize--;

}

void CharLinkedList::removeAt(int index)
{
    stringstream ss;
    // Check if the index is out of range
    if (index < 0 or index >= charSize)
    {
        // Throw a range_error exception 
        ss << "index (" << index << ") not in range [0.."<< charSize <<")";
        throw range_error(ss.str());
        return;
    }
    // call popFromFront index is the first element
    if (index == 0)
    {
        popFromFront();
        return;
    }
    // call popFromBack if index is the last element of list
    if (index == charSize - 1)
    {
        popFromBack();
        return;
    }
    else
    {
        // delete desired node
        int counter = 0;
        Node *temp = front;
        Node *temp2 = nullptr;
        while (counter != index)
        {
            temp2 = temp;
            temp = temp->next;
            counter++;
        }
        Node *targetNode = temp;
        temp = temp->next;
        delete targetNode;
        temp2->next = temp;
        charSize--;
    }
}

void CharLinkedList::replaceAt(char c, int index)
{
    stringstream ss;
    // Check if the index is out of range
    if (index < 0 or index > charSize)
    {
        // Throw a range_error exception 
        ss << "index (" << index << ") not in range [0.."<< charSize <<")";
        throw range_error(ss.str());
        return;
    }
 
    int counter = 0;
    Node *temp = front;
    // traverse through list until desired index is reached
    while (counter != index)
    {
        temp = temp->next;
        counter++;
    }
    // replace current node's input with desired input
    temp->input = c;
}

void CharLinkedList::concatenate(CharLinkedList *other)
{
    // use copy constructor to create copy of other list
    CharLinkedList temp(*other);
    // add other list to back of current list
    Node *tempNode = temp.front;
    while (tempNode != nullptr)
    {
        pushAtBack(tempNode->input);
        tempNode = tempNode->next;
    }
}

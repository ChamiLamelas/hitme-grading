/*
 *  unit_tests.h
 *  YOUR NAME HERE
 *  DATE CREATED
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  A testing file to test the Linked List class that uses the unit_test 
 *  framework. Allows for the creation of specific tests for functions to make
 *  sure everything works properly.
 *
 */

#include <cassert>
#include <iostream>
#include <string>

#include "CharLinkedList.h"

/********************************************************************\
*                       CHAR LINKED LIST TESTS                        *
\********************************************************************/

void constructor_test() {
    CharLinkedList list;
    assert(list.size() == 0);
}

void constructor_test_char() {
    CharLinkedList list('a');

    assert(list.size() == 1);
    assert(list.elementAt(0) == 'a');
}

void constructor_test_arrSize_long() {
    char arr[] = {'a','b','c','d','e','f','g','h'};
    CharLinkedList test_list(arr, 8);
    
    assert(test_list.size() == 8);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(2) == 'c');
    assert(test_list.elementAt(5) == 'f');
    assert(test_list.elementAt(7) == 'h');
}

void constructor_test_arrSize_short() {
    char arr[] = {'a','b'};
    CharLinkedList test_list(arr, 2);
    
    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
}

void copyConstructor_test(){
    char arr[] = {'a','b','c'};
    CharLinkedList test_list(arr, 3);
    CharLinkedList test_list2(test_list);
    
    assert(test_list2.size() == 3);
    assert(test_list2.elementAt(0) == 'a');
    assert(test_list2.elementAt(1) == 'b');
    assert(test_list2.elementAt(2) == 'c');
}

void copyConstructor_test_empty(){
    CharLinkedList test_list;
    CharLinkedList test_list2(test_list);
    
    std::cerr << test_list2.size();
    assert(test_list2.size() == 0);
}

void operator_test(){
    char arr[] = {'a','b','c'};
    CharLinkedList test_list(arr, 3);
    CharLinkedList test_list2 = test_list;
    
    assert(test_list2.size() == 3);
    
    assert(test_list2.elementAt(0) == 'a');
    assert(test_list2.elementAt(1) == 'b');
    assert(test_list2.elementAt(2) == 'c');
}

void operator_test_empty(){
    CharLinkedList test_list;
    CharLinkedList test_list2 = test_list;
    
    assert(test_list2.size() == 0);
}

// Tests correct insertion into an empty AL.
// Afterwards, size should be 1 and element at index 0
// should be the element we inserted.
void insertAt_empty_correct() {
    CharLinkedList test_list;
    test_list.insertAt('a', 0);
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');
}

// Tests incorrect insertion into an empty AL.
// Attempts to call insertAt for index larger than 0.
// This should result in an std::range_error being raised.
void insertAt_empty_incorrect() {
    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
        // insertAt for out-of-range index
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        // if insertAt is correctly implemented, a range_error will be thrown,
        // and we will end up here
        range_error_thrown = true;
        error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0]");
}

// Tests correct insertAt for front of 1-element list.
void insertAt_front_singleton_list() {
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at front
    test_list.insertAt('b', 0);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'a');
}

// Tests correct insertAt for back of 1-element list.
void insertAt_back_singleton_list() {
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at back
    test_list.insertAt('b', 1);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
}

// Tests calling insertAt for a large number of elements.
// Not only does this test insertAt, it also checks that
// array expansion works correctly.
void insertAt_many_elements() {
    CharLinkedList test_list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.insertAt('a', i);
    }

    assert(test_list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
}

// Tests insertion into front of a larger list
void insertAt_front_large_list() {
    char test_arr[9] = {'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(test_arr, 9);

    test_list.insertAt('y', 0);

    assert(test_list.size() == 10);
    assert(test_list.elementAt(0) == 'y');
    assert(test_list.toString() == 
    "[CharLinkedList of size 10 <<yabczdefgh>>]");
}

// Tests insertion into the back of a larger list
void insertAt_back_large_list() {
    char test_arr[10] = {'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(test_arr, 10);

    test_list.insertAt('x', 10);

    assert(test_list.size() == 11);
    assert(test_list.elementAt(10) == 'x');
    assert(test_list.toString() ==
           "[CharLinkedList of size 11 <<yabczdefghx>>]");
}

// Tests insertion into the middle of a larger list
void insertAt_middle_large_list() {
    char test_arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(test_arr, 8);

    test_list.insertAt('z', 3);

    assert(test_list.size() == 9);
    assert(test_list.elementAt(3) == 'z');
    assert(test_list.toString() == "[CharLinkedList of size 9 <<abczdefgh>>]");
}

// Tests out-of-range insertion for a non-empty list.
void insertAt_nonempty_incorrect() {
    char test_arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.insertAt('a', 42);
    } catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8]");
}

void pushAtFront_single_list() {
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at front
    test_list.pushAtFront('b');

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'a');
}

void pushAtFront_long_list() {
    char arr[] = {'b','c','d','e','f','g','h','i'};
    CharLinkedList test_list(arr, 8);

    // insert at front
    test_list.pushAtFront('a');

    assert(test_list.size() == 9);
    assert(test_list.toString() == "[CharLinkedList of size 9 <<abcdefghi>>]");
}

void pushAtFront_empty_list() {
    CharLinkedList test_list;

    // insert at front
    test_list.pushAtFront('a');

    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');
}

void pushAtBack_single_list() {
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at back
    test_list.pushAtBack('b');

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
}

void pushAtBack_long_list() {
    char arr[] = {'a','b','c','d','e','f','g','h'};
    CharLinkedList test_list(arr, 8);

    // insert at back
    test_list.pushAtBack('i');

    assert(test_list.size() == 9);
    assert(test_list.toString() == "[CharLinkedList of size 9 <<abcdefghi>>]");
}

void pushAtBack_empty_list() {
    CharLinkedList test_list;

    // insert at back
    test_list.pushAtBack('a');

    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');
}

void test_isEmpty_true(){
    CharLinkedList test_list;

    assert(test_list.size() == 0);
    assert(test_list.isEmpty());
}

void test_isEmpty_false(){
    CharLinkedList test_list('a');

    assert(test_list.size() == 1);
    assert(not(test_list.isEmpty()));
}

void test_clear_empty(){
    CharLinkedList test_list;
    test_list.clear();

    assert(test_list.size() == 0);
}

void test_clear_notEmpty(){
    CharLinkedList test_list('a');
    test_list.clear();

    assert(test_list.size() == 0);
}

void test_size_long(){
    char arr[] = {'a','b','c','d','e','f','g','h'};
    CharLinkedList test_list(arr, 8);

    assert(test_list.size() == 8);
}

void test_toString_long(){
    char arr[] = {'a','b','c','d','e','f','g','h'};
    CharLinkedList test_list(arr, 8);

    assert(test_list.toString() == "[CharLinkedList of size 8 <<abcdefgh>>]");
}

void test_size_short(){
    CharLinkedList test_list('a');

    assert(test_list.size() == 1);
}

void test_toString_short(){
    CharLinkedList test_list('a');

    assert(test_list.toString() == "[CharLinkedList of size 1 <<a>>]");
}

void test_size_empty(){
    CharLinkedList test_list;

    assert(test_list.size() == 0);
}

void test_toString_empty(){
    CharLinkedList test_list;

    assert(test_list.toString() == "[CharLinkedList of size 0 <<>>]");
}

void test_first(){
    CharLinkedList test_list('a');
    test_list.pushAtBack('b');

    test_list.first();

    assert(test_list.size() == 2);
    assert(test_list.elementAt(1) == 'b');
    assert(test_list.first() == 'a');
}

void test_first_err(){
    CharLinkedList test_list;
    bool runtime_error_thrown = false;
    std::string error_message = "";

    try {
        test_list.first();
    } catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot get first of empty LinkedList");
}

void test_last(){
    CharLinkedList test_list('a');
    test_list.pushAtBack('b');

    test_list.last();

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.last() == 'b');
}

void test_last_err(){
    CharLinkedList test_list;
    bool runtime_error_thrown = false;
    std::string error_message = "";

    try {
        test_list.last();
    } catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot get last of empty LinkedList");
}

void reverseToString_test_short(){
    CharLinkedList test_list('a');
    
    test_list.pushAtBack('b');

    assert(test_list.size() == 2);
    assert(test_list.toReverseString() == "[CharLinkedList of size 2 <<ba>>]");
}

void reverseToString_test_long(){
    char arr[] = {'a','b','c','d','e','f','g','h'};
    CharLinkedList test_list(arr, 8);

    assert(test_list.size() == 8);
    assert(test_list.toReverseString() == 
    "[CharLinkedList of size 8 <<hgfedcba>>]");
}

void reverseToString_test_empty(){
    CharLinkedList test_list;

    assert(test_list.size() == 0);
    assert(test_list.toReverseString() == "[CharLinkedList of size 0 <<>>]");
}

void test_inOrder_front(){
    char arr[] = {'b','c','d','e'};
    CharLinkedList test_list(arr, 4);

    test_list.insertInOrder('a');

    assert(test_list.size() == 5);
    assert(test_list.toString() == 
    "[CharLinkedList of size 5 <<abcde>>]");
}

void test_inOrder_middle(){
    char arr[] = {'a','b','d','e'};
    CharLinkedList test_list(arr, 4);

    test_list.insertInOrder('c');

    assert(test_list.size() == 5);
    assert(test_list.toString() == 
    "[CharLinkedList of size 5 <<abcde>>]");
}

void test_inOrder_back(){
    char arr[] = {'a'};
    CharLinkedList test_list(arr, 1);

    test_list.insertInOrder('b');

    assert(test_list.size() == 2);
    assert(test_list.toString() == 
    "[CharLinkedList of size 2 <<ab>>]");
}

void test_inOrder_empty(){
    CharLinkedList test_list;

    test_list.insertInOrder('a');

    assert(test_list.size() == 1);
    assert(test_list.toString() == 
    "[CharLinkedList of size 1 <<a>>]");
}

void elementAt_neg(){
    CharLinkedList test_list('a');
    bool range_error_thrown = false;
    std::string error_message = "";

    try {
        test_list.elementAt(-1);
    } catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (-1) not in range [0..1)");
}

void elementAt_inBounds(){
    CharLinkedList test_list('a');

    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');
}

void popFromFront_short(){
    CharLinkedList test_list('a');

    test_list.popFromFront();

    assert(test_list.size() == 0);
    assert(test_list.toString() == "[CharLinkedList of size 0 <<>>]");
}

void popFromFront_long(){
    char arr[] = {'a','b','c','d','e','f','g','h'};
    CharLinkedList test_list(arr, 8);

    test_list.popFromFront();

    assert(test_list.size() == 7);
    assert(test_list.toString() == "[CharLinkedList of size 7 <<bcdefgh>>]");
}

void popFromFront_empty(){
    CharLinkedList test_list;
    bool runtime_error_thrown = false;
    std::string error_message = "";

    try {
       test_list.popFromFront();
    } catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

void popFromBack_short(){
    CharLinkedList test_list('a');

    test_list.popFromBack();

    assert(test_list.size() == 0);
    assert(test_list.toString() == "[CharLinkedList of size 0 <<>>]");
}

void popFromBack_long(){
    char arr[] = {'a','b','c','d','e','f','g','h'};
    CharLinkedList test_list(arr, 8);

    test_list.popFromBack();

    assert(test_list.size() == 7);
    assert(test_list.toString() == "[CharLinkedList of size 7 <<abcdefg>>]");
}

void popFromBack_empty(){
    CharLinkedList test_list;
    bool runtime_error_thrown = false;
    std::string error_message = "";

    try {
       test_list.popFromBack();
    } catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

void removeAt_neg(){
    CharLinkedList test_list('a');
    bool range_error_thrown = false;
    std::string error_message = "";

    try {
        test_list.removeAt(-1);
    } catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (-1) not in range [0..1)");
}

void removeAt_outBounds(){
    CharLinkedList test_list('a');
    bool range_error_thrown = false;
    std::string error_message = "";

    try {
        test_list.removeAt(2);
    } catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (2) not in range [0..1)");
}

void removeAt_inLongFront(){
    char arr[] = {'a','b','c','d','e','f','g','h'};
    CharLinkedList test_list(arr, 8);

    test_list.removeAt(0);

    assert(test_list.size() == 7);
    assert(test_list.toString() == "[CharLinkedList of size 7 <<bcdefgh>>]");
}

void removeAt_inLongMid(){
    char arr[] = {'a','b','c','d','e','f','g','h'};
    CharLinkedList test_list(arr, 8);

    test_list.removeAt(4);

    assert(test_list.size() == 7);
    assert(test_list.toString() == "[CharLinkedList of size 7 <<abcdfgh>>]");
}

void removeAt_inLongEnd(){
    char arr[] = {'a','b','c','d','e','f','g','h'};
    CharLinkedList test_list(arr, 8);

    test_list.removeAt(7);

    assert(test_list.size() == 7);
    assert(test_list.toString() == "[CharLinkedList of size 7 <<abcdefg>>]");
}

void removeAt_empty(){
    CharLinkedList test_list;
    bool range_error_thrown = false;
    std::string error_message = "";

    try {
        test_list.removeAt(1);
    } catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (1) not in range [0..0)");
}


void replaceAt_neg(){
    CharLinkedList test_list('a');
    bool range_error_thrown = false;
    std::string error_message = "";

    try {
        test_list.replaceAt('c', -1);
    } catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (-1) not in range [0..1)");
}

void replaceAt_outBounds(){
    CharLinkedList test_list('a');
    bool range_error_thrown = false;
    std::string error_message = "";

    try {
        test_list.replaceAt('c', 2);
    } catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (2) not in range [0..1)");
}

void replaceAt_inLongFront(){
    char arr[] = {'n','b','c','d','e','f','g','h'};
    CharLinkedList test_list(arr, 8);

    test_list.replaceAt('a', 0);

    assert(test_list.size() == 8);
    assert(test_list.toString() == "[CharLinkedList of size 8 <<abcdefgh>>]");
}

void replaceAt_inLongMid(){
    char arr[] = {'a','b','c','d','n','f','g','h'};
    CharLinkedList test_list(arr, 8);

    test_list.replaceAt('e', 4);

    assert(test_list.size() == 8);
    assert(test_list.toString() == "[CharLinkedList of size 8 <<abcdefgh>>]");
}

void replaceAt_inLongEnd(){
    char arr[] = {'a','b','c','d','e','f','g','n'};
    CharLinkedList test_list(arr, 8);

    test_list.replaceAt('h', 7);

    assert(test_list.size() == 8);
    assert(test_list.toString() == "[CharLinkedList of size 8 <<abcdefgh>>]");
}

void replaceAt_empty(){
    CharLinkedList test_list;
    bool range_error_thrown = false;
    std::string error_message = "";

    try {
        test_list.replaceAt('a', 1);
    } catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (1) not in range [0..0)");
}

void concatenate_emptyOnEmpty(){
    CharLinkedList test_list1;
    CharLinkedList test_list2;

    test_list1.concatenate(&test_list2);

    assert(test_list1.toString() == "[CharLinkedList of size 0 <<>>]");
}

void concatenate_emptyOnNotEmpty(){
    char arr[] = {'a','b','c','d'};
    CharLinkedList test_list1(arr, 4);
    CharLinkedList test_list2;

    test_list1.concatenate(&test_list2);

    assert(test_list1.toString() == "[CharLinkedList of size 4 <<abcd>>]");
}

void concatenate_notEmptyOnEmpty(){
    char arr[] = {'a','b','c','d'};
    CharLinkedList test_list1;
    CharLinkedList test_list2(arr, 4);

    test_list1.concatenate(&test_list2);

    assert(test_list1.toString() == "[CharLinkedList of size 4 <<abcd>>]");
}

void concatenate_notEmptyOnNotEmpty(){
    char arr1[] = {'a','b','c','d'};
    char arr2[] = {'e','f','g'};
    CharLinkedList test_list1(arr1, 4);
    CharLinkedList test_list2(arr2, 3);

    test_list1.concatenate(&test_list2);

    assert(test_list1.toString() == "[CharLinkedList of size 7 <<abcdefg>>]");
}
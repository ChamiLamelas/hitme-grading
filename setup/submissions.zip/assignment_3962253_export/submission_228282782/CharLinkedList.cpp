/*
 *  CharLinkedList.cpp
 *  Nico Schactman
 *  2/4/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Function definitions for the CharLinkedList class
 *
 */

#include "CharLinkedList.h"
#include <sstream>
#include <string>

/*
* name: CharLinkedList
* purpose: creates an empty CharLinkedList
* arguments: none
* returns: nothing
*/
CharLinkedList::CharLinkedList(){
    front = nullptr;
    back = nullptr;
    sizeList = 0; 
}

/*
* name: CharLinkedList
* purpose: creates a CharLinkedList with element c
* arguments: a char c
* returns: nothing
*/
CharLinkedList::CharLinkedList(char c){
    Node *newNode = new Node;
    newNode->info = c;
    newNode->next = nullptr;
    newNode->prev = nullptr;
    front = newNode;
    back = newNode;
    sizeList = 1;
}

/*
* name: CharLinkedList
* purpose: creates a CharLinkedList with element c and size size
* arguments: a char c, int size
* returns: nothing
*/
CharLinkedList::CharLinkedList(char arr[], int size){
    sizeList = 0;
    for(int i = 0; i < size; i++){
        pushAtBack(arr[i]);
    }
}

/*
* name: CharLinkedList
* purpose: creates a CharLinkedList from another
* arguments: a CharLinkedList other
* returns: nothing
*/
CharLinkedList::CharLinkedList(const CharLinkedList &other){
    sizeList = 0;
    for(int i = 0; i < other.size(); i++){
        pushAtBack(other.elementAt(i));
    }
}

/*
* name: ~CharLinkedList
* purpose: calls the deconstructor_helper function to delete all nodes
* arguments: none
* returns: nothing
*/
CharLinkedList::~CharLinkedList(){
    deconstructor_helper(front);
}

/*
* name: deconstructor_helper
* purpose: recursively deletes all the nodes
* arguments: a current node representing the front of the list
* returns: nothing
*/
void CharLinkedList::deconstructor_helper(Node *current) {
    if(current != nullptr) {
        deconstructor_helper(current->next);
        delete current;
    }
}

/*
* name: &CharLinkedList::operator=
* purpose: sets a CharLinkedList from another
* arguments: a CharLinkedList other
* returns: nothing
*/
CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other){
    clear();
    for(int i = 0; i < other.size(); i++){
        pushAtBack(other.elementAt(i));
    }
    
    return *this;
}

/*
* name: isEmpty
* purpose: checks if the CharLinkedList is empty
* arguments: none
* returns: boolean if it is empty or not
*/
bool CharLinkedList::isEmpty() const{
    if (sizeList <= 0){
        return true;
    } else {
        return false;
    }
}

/*
* name: clear
* purpose: clears out the CharLinkedList
* arguments: none
* returns: nothing
*/
void CharLinkedList::clear(){
    sizeList = 0;
    if(not isEmpty()){
        deconstructor_helper(front);
    }
}

/*
* name: size
* purpose: to return the size
* arguments: none
* returns: size of the CharLinkedList
*/
int CharLinkedList::size() const{
    return sizeList;
}

/*
* name: first
* purpose: return first element if there is one
* arguments: none
* returns: first element if there is one
*/
char CharLinkedList::first() const{
    if(isEmpty()){
        throw std::runtime_error("cannot get first of empty LinkedList");
    } else {
        return front->info;
    }
}

/*
* name: last
* purpose: return last element if there is one
* arguments: none
* returns: last element if there is one
*/
char CharLinkedList::last() const{
    if(isEmpty()){
        throw std::runtime_error("cannot get last of empty LinkedList");
    } else {
        return back->info;
    }
}

/*
* name: elementAt
* purpose: return element at index index if there is one
* arguments: int index
* returns: element at index index if there is one
*/
char CharLinkedList::elementAt(int index) const{
    std::string err = "index (" + std::to_string(index) + 
    ") not in range [0.." + std::to_string(sizeList) + ")";
    if(index > sizeList-1 or index < 0){
        throw std::range_error(err);
    }
    Node *currNode;
    currNode = front;
    for(int i = 0; i < index; i++){
        currNode = currNode->next;
    }
    return currNode->info;
}

/*
* name: toString
* purpose: returns the CharLinkedList in a certain way
* arguments: none
* returns: the CharLinkedList in a certain way
*/
std::string CharLinkedList::toString() const{
    Node *currNode;
    std::string str = "[CharLinkedList of size " + 
    std::to_string(sizeList) + " <<";
    if(not isEmpty()){
        currNode = front;
        for(int i = 0; i < sizeList; i++){
            str += currNode->info;
            currNode = currNode->next;
        }
    }
    str += ">>]";
    return str;
}

/*
* name: toReverseString
* purpose: returns the CharLinkedList in a certain way (reversed)
* arguments: none
* returns: the CharLinkedList in a certain way (reversed)
*/
std::string CharLinkedList::toReverseString() const{
    Node *currNode;
    std::string str = "[CharLinkedList of size " + 
    std::to_string(sizeList) + " <<";
    if(not isEmpty()){
        currNode = back;
        for(int i = 0; i < sizeList; i++){
            str += currNode->info;
            currNode = currNode->prev;
        }
    }
    str += ">>]";
    return str;
}

/*
* name: pushAtBack
* purpose: adds element c to the back of the CharLinkedList
* arguments: a char c
* returns: nothing
*/
void CharLinkedList::pushAtBack(char c){
    Node *newNode = new Node;
    newNode->info = c;
    if(isEmpty()){
        front = newNode;
        back = newNode;
        newNode->next = nullptr;
        newNode->prev = nullptr;
    } else {
        newNode->next = nullptr;
        newNode->prev = back;
        back->next = newNode;
        back = newNode;
    }
    sizeList++;
}

/*
* name: pushAtFront
* purpose: adds element c to the front of the CharLinkedList
* arguments: a char c
* returns: nothing
*/
void CharLinkedList::pushAtFront(char c){
    Node *newNode = new Node;
    newNode->info = c;
    if(isEmpty()){
        front = newNode;
        back = newNode;
        newNode->next = nullptr;
        newNode->prev = nullptr;
    } else {
        newNode->next = front;
        newNode->prev = nullptr;
        front->prev = newNode;
        front = newNode;
    }
    sizeList++;
}

/*
* name: insertAt
* purpose: adds element c to the given index of the CharLinkedList
* arguments: a char c and int index
* returns: nothing
*/
void CharLinkedList::insertAt(char c, int index){
    std::string err = "index (" + std::to_string(index) + 
    ") not in range [0.." + std::to_string(sizeList) + "]";
    if(index == 0){
        pushAtFront(c);
    } else if(index == sizeList){
        pushAtBack(c);
    } else if((index > sizeList-1 or index < 0)){
        throw std::range_error(err);
    } else {
        Node *currNode;
        currNode = front;
        for(int i = 0; i < index; i++){
            currNode = currNode->next;
        }
        Node *newNode = new Node;
        newNode->info = c;
        currNode->prev->next = newNode;
        newNode->prev = currNode->prev;
        newNode->next = currNode;
        currNode->prev = newNode;
        sizeList++;
    }
}

/*
* name: insertInOrder
* purpose: adds element c alphabetically in CharLinkedList
* arguments: a char c
* returns: nothing
*/
void CharLinkedList::insertInOrder(char c){
    int i = 0;
    Node *currNode;
    if(isEmpty()){
        pushAtBack(c);
    } else {
        currNode = front;
        while(i < sizeList and c > currNode->info){
            i++;
            currNode = currNode->next;
        }
        if(i >= sizeList){
            pushAtBack(c);
        } else {
            insertAt(c, i);
        }
    }
}

/*
* name: popFromFront
* purpose: removes the first element of CharLinkedList if there is one
* arguments: none
* returns: nothing
*/
void CharLinkedList::popFromFront(){
    if(isEmpty()){
        throw std::runtime_error("cannot pop from empty LinkedList");
    } else if(sizeList == 1){
        delete front;
        front = nullptr;
        back = nullptr;
    } else {
        front = front->next;
        delete front->prev;
        front->prev = nullptr;
    }
    sizeList--;
}

/*
* name: popFromBack
* purpose: removes the last element of CharLinkedList if there is one
* arguments: none
* returns: nothing
*/
void CharLinkedList::popFromBack(){
    if(isEmpty()){
        throw std::runtime_error("cannot pop from empty LinkedList");
    } else if(sizeList == 1){
        delete back;
        back = nullptr;
        front = nullptr;
    } else {
        back = back->prev;
        delete back->next;
        back->next = nullptr;
    }
    sizeList--;
}

/*
* name: removeAt
* purpose: removes a given element of CharLinkedList
* arguments: int index
* returns: nothing
*/
void CharLinkedList::removeAt(int index){
    Node *currNode;
    currNode = front;
    std::string err = "index (" + std::to_string(index) + 
    ") not in range [0.." + std::to_string(sizeList) + ")";
    if(isEmpty()){
        throw std::range_error(err);
    }
    if(index >= sizeList or index < 0){
        throw std::range_error(err);
    }
    if(index == 0){
        popFromFront();
    } else if(index == sizeList - 1){
        popFromBack();
    } else {
        for(int i = 0; i < index; i++){
            currNode = currNode->next;
        }
        currNode->next->prev = currNode->prev;
        currNode->prev->next = currNode->next;
        delete currNode;
        sizeList--;
    }
}

/*
* name: replaceAt
* purpose: replaces a given char c of CharLinkedList
* arguments: int index and char c
* returns: nothing
*/
void CharLinkedList::replaceAt(char c, int index){
    removeAt(index);
    insertAt(c, index);
}

/*
* name: concatenate
* purpose: concatenates other onto the CharLinkedList
* arguments: a CharLinkedList other
* returns: nothing
*/
void CharLinkedList::concatenate(CharLinkedList *other){
    for(int i = 0; i < other->size(); i++){
        pushAtBack(other->elementAt(i));
    }
}


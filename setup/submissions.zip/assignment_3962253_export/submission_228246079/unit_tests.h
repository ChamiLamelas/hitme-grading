/*
 *  unit_tests.h
 *  Joel Lawore (jlawor01)
 *  1 February 2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  This file contains the unit-testing for the CharLinkedList Class
 *
 */
#include "CharLinkedList.h"
#include <cassert>

/********************************************************************\
*                       CHAR Linked LIST TESTS                        *
\********************************************************************/

// Default Constructor Test 0
void default_constructor_test_0() {
    // creates empty list
    CharLinkedList list;

    // checks if list is empty
    assert(list.isEmpty());
    
}

/// Char Parameter Constructor Test
void second_constructor_test() {
    CharLinkedList list('c');

    assert(list.size() == 1);
    assert(list.first() == 'c');
}

// Array and Int Constructor Test 1
void array_and_constructor_test_size() {
    char arr[] = {'1', '2', '3', '4'};
    CharLinkedList list(arr, 4);

    assert(list.size() == 4);
    assert(list.toString() == "[CharLinkedList of size 4 <<1234>>]");
}

// Copy Constructor Test
void copy_constructor_test() {
    char arr[] = {'1', '2', '3', '4'};
    CharLinkedList list1(arr, 4);

    CharLinkedList list2(list1);

    assert(list2.size() == 4);
    assert(list2.toString() == "[CharLinkedList of size 4 <<1234>>]");
}

// Deconstructor Test 1
void deconstructor_test() {
    CharLinkedList list;

    for (int i = 0; i < 5; i++) {
        list.pushAtBack('1');
    }
}

// Overloaded Assignment Operator Test 1: Large Assigned to Empty
void overloaded_assingment_operator_test_1() {
    char arr[] = {'1', '2', '3', '4'};
    CharLinkedList list1(arr, 4);
    CharLinkedList list2;

    list2 = list1;

    assert(list2.size() == 4);
    assert(list2.toString() == "[CharLinkedList of size 4 <<1234>>]");
}

// Overloaded Assignment Operator Test 2: Large Assigned to Large 
void overloaded_assingment_operator_test_2() {
    char arr1[] = {'1', '2', '3', '4'};
    CharLinkedList list1(arr1, 4);
    char arr2[] = {'a', 'b', 'c'};
    CharLinkedList list2(arr2, 3);

    list2 = list1;

    assert(list2.size() == 4);
    assert(list2.toString() == "[CharLinkedList of size 4 <<1234>>]");
}

// Overloaded Assignment Operator Test 3: Empty Assigned to Large 
void overloaded_assingment_operator_test_3() {
    CharLinkedList list1;
    char arr2[] = {'a', 'b', 'c'};
    CharLinkedList list2(arr2, 3);

    list2 = list1;

    assert(list2.size() == 0);
    assert(list2.toString() == "[CharLinkedList of size 0 <<>>]");
}

// isEmpty() Test 1: Empty List
void isEmpty_empty_list() {
    CharLinkedList list;

    assert(list.isEmpty());
}

// isEmpty() Test 2: Singleton List
void isEmpty_singleton_List() {
    CharLinkedList list('c');

    assert(not list.isEmpty());
}

// isEmpty() Test 3: Large List
void isEmpty_large_List() {
    char arr[] = {'1', '2', '3', '4'};
    CharLinkedList list(arr, 4);

    assert(not list.isEmpty());
}

// clear() Test 1: Empty List
void clear_empty_List() {
    CharLinkedList list;

    list.clear();

    assert(list.size() == 0);
    assert(list.isEmpty());
}

// clear() Test 2: Singleton List
void clear_singleton_list() {
    CharLinkedList list('c');

    list.clear();

    assert(list.size() == 0);
    assert(list.isEmpty());
}

// clear() Test 3: Large List
void clear_large_list() {
    char arr[] = {'1', '2', '3', '4'};
    CharLinkedList list(arr, 4);

    list.clear();

    assert(list.size() == 0);
    assert(list.isEmpty());
}

// size() Test 1: Empty List
void size_empty_list() {
    CharLinkedList list;

    assert(list.size() == 0);
}

// size() Test 2: Singleton List
void size_singleton_list() {
    CharLinkedList list('c');
    
    assert(list.size() == 1);
}

// size() Test 3: Large List
void size_large_list() {
    char arr[] = {'1', '2', '3', '4'};
    CharLinkedList list(arr, 4);

    assert(list.size() == 4);
}

// first() Test 1: Singleton List
void first_singleton_list() {
    CharLinkedList list('c');

    assert(list.first() == 'c');
}

// first() Test 2: Large List
void first_large_list() {
    char arr[] = {'1', '2', '3', '4'};
    CharLinkedList list(arr, 4);

    assert(list.first() == '1');
}

// first() Test 3: Empty list (exception)
void first_empty_list() {
    CharLinkedList list;

    try {
        list.first();
    }
    catch (runtime_error) {
        assert(true);
    }
}

// last() Test 1: Singleton List
void last_singleton_list() {
    CharLinkedList list('1');

    assert(list.last() == '1');
}

// last() Test 2: Large List
void last_large_list() {
    char arr[] = {'1', '2', '3', '4'};
    CharLinkedList list(arr, 4);

    assert(list.last() == '4');
}

// last() Test 3: Empty list (exception)
void last_empty_list() {
    CharLinkedList list;

    try {
        list.last();
    }
    catch (runtime_error) {
        assert(true);
    }
}

// elementAt() Test 1: Singleton List
void elementAt_singleton_list() {
    CharLinkedList list;
    list.pushAtBack('1');

    assert(list.elementAt(0) == '1');
}

// elementAt() Test 2: Large List
void elementAt_large_list() {
    char arr[] = {'1', '2', '3', '4'};
    CharLinkedList list(arr, 4);

    assert(list.elementAt(0) == '1');
    assert(list.elementAt(1) == '2');
    assert(list.elementAt(2) == '3');
    assert(list.elementAt(3) == '4');
}

// elementAt() Test 3: Empty List (exception)
void elementAt_empty_list() {
    CharLinkedList list;

    try {
        list.elementAt(3);
    }
    catch (range_error) {
        assert(true);
    }
}

// elementAt() Test 4: Negative Index (exception)
void elementAt_negative_index() {
    char arr[] = {'1', '2', '3', '4'};
    CharLinkedList list(arr, 4);

    try {
        list.elementAt(-1);
    }
    catch (range_error) {
        assert(true);
    }
}

// toString() Test 1: Singleton List
void toString_singleton_list() {
    CharLinkedList list('a');

    assert(list.toString() == "[CharLinkedList of size 1 <<a>>]");
}

// toString() Test 2: Large List
void toString_large_list() {
    char arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList list(arr, 8);

    assert(list.toString() == "[CharLinkedList of size 8 <<abcdefgh>>]");
}

// toString() Test 3: Empty List
void toString_empty_list() {
    CharLinkedList list;

    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}

// toReverseString() Test 1: Singleton List
void toReverseString_singleton_list() {
    CharLinkedList list('l');

    assert(list.toReverseString() == "[CharLinkedList of size 1 <<l>>]");
}

// toReverseString() Test 2: Large List
void toReverseString_large_list() {
    char arr[] = {'l', 'e', 'o', 'J'};
    CharLinkedList list(arr, 4);

    assert(list.toReverseString() == "[CharLinkedList of size 4 <<Joel>>]");
}

// toReverseString() Test 3: Empty List
void toReverseString_test_2() {
    CharLinkedList list;

    assert(list.toReverseString() == "[CharLinkedList of size 0 <<>>]");
}

// pushAtBack() Test 1: Singleton List
void pushAtBack_singleton_list() {
    CharLinkedList list('J');

    list.pushAtBack('o');

    assert(list.size() == 2);
    assert(list.last() == 'o');
    assert(list.toString() == "[CharLinkedList of size 2 <<Jo>>]");
}

// pushAtBack() Test 2: Large List
void pushAtBack_large_list() {
    char arr[] = {'J', 'o', 'e'};
    CharLinkedList list(arr, 3);

    list.pushAtBack('l');

    assert(list.last() == 'l');
    assert(list.size() == 4);
    assert(list.toString() == "[CharLinkedList of size 4 <<Joel>>]");
}

// pushAtBack() Test 3: Empty List, Single Push
void pushAtBack_empty_list_single() {
    CharLinkedList list;

    list.pushAtBack('J');

    assert(list.size() == 1);
    assert(list.last() == 'J');
}

// pushAtBack() Test 4: Empty List, Multiple Pushes
void pushAtBack_empty_list_mulitple() {
    CharLinkedList list;

    list.pushAtBack('J');
    assert(list.last() == 'J');
    assert(list.size() == 1);

    list.pushAtBack('o');
    assert(list.last() == 'o');
    assert(list.size() == 2);

    list.pushAtBack('e');
    assert(list.last() == 'e');
    assert(list.size() == 3);

    list.pushAtBack('l');
    assert(list.last() == 'l');
    assert(list.size() == 4);
    assert(list.toString() == "[CharLinkedList of size 4 <<Joel>>]");
}

// pushAtFront() Test 1: Singleton List
void pushAtFront_singleton_list() {
    CharLinkedList list('o');

    list.pushAtFront('J');

    assert(list.size() == 2);
    assert(list.first() == 'J');
    assert(list.toString() == "[CharLinkedList of size 2 <<Jo>>]");
}

// pushAtFront() Test 2: Large list
void pushAtFront_large_list() {
    char arr[] = {'o', 'e', 'l'};
    CharLinkedList list(arr, 3);

    list.pushAtFront('J');

    assert(list.size() == 4);
    assert(list.first() == 'J');
    assert(list.toString() == "[CharLinkedList of size 4 <<Joel>>]");
}

// pushAtFront() Test 3: Empty List, Single Push
void pushAtFront_empty_list_single() {
    CharLinkedList list;

    list.pushAtFront('J');

    assert(list.size() == 1);
    assert(list.first() == 'J');
}

// pushAtFront() Test 4: Empty List, Multiple Pushes
void pushAtFront_empty_list_multiple() {
    CharLinkedList list;
    
    list.pushAtFront('l');
    assert(list.first() == 'l');
    assert(list.size() == 1);

    list.pushAtFront('e');
    assert(list.first() == 'e');
    assert(list.size() == 2);

    list.pushAtFront('o');
    assert(list.first() == 'o');
    assert(list.size() == 3);

    list.pushAtFront('J');
    assert(list.first() == 'J');
    assert(list.size() == 4);
    assert(list.toString() == "[CharLinkedList of size 4 <<Joel>>]");
}

// Tests correct insertion into an empty AL.
// Afterwards, size should be 1 and element at index 0
// should be the element we inserted.
void insertAt_empty_correct() { 

    CharLinkedList test_list;

    test_list.insertAt('a', 0);

    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');

}

// Tests incorrect insertion into an empty AL.
// Attempts to call insertAt for index larger than 0.
// This should result in an range_error being raised.
void insertAt_empty_incorrect() {

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    string error_message = "";

    CharLinkedList test_list;
    try {
    // insertAt for out-of-range index
    test_list.insertAt('a', 42);
    }
    catch (const range_error &e) {
    // if insertAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    range_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0]");
    
}

// Tests correct insertAt for front of 1-element list.
void insertAt_front_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at front
    test_list.insertAt('b', 0);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'a');
    
}

// Tests correct insertAt for back of 1-element list.
void insertAt_back_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at back
    test_list.insertAt('b', 1);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    
}

// Tests calling insertAt for a large number of elements.
// Not only does this test insertAt, it also checks that
// array expansion works correctly.
void insertAt_many_elements() {
    
    CharLinkedList test_list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.insertAt('a', i);
    }

    assert(test_list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
    
}

// Tests insertion into front of a larger list
void insertAt_front_large_list() {
    char test_arr[] = {'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g'};
    CharLinkedList test_list(test_arr, 8);

    test_list.insertAt('y', 0);

    assert(test_list.size() == 9);
    assert(test_list.elementAt(0) == 'y');
    assert(test_list.toString() == "[CharLinkedList of size 9 <<yabczdefg>>]");

}

// Tests insertion into the back of a larger list
void insertAt_back_large_list() {

    char test_arr[10] = { 'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 10);  

    test_list.insertAt('x', 10);

    assert(test_list.size() == 11);
    assert(test_list.elementAt(10) == 'x');
    assert(test_list.toString() == 
    "[CharLinkedList of size 11 <<yabczdefghx>>]"); 

}

// Tests insertion into the middle of a larger list
void insertAt_middle_large_list() {
    char test_arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(test_arr, 8);

    test_list.insertAt('z', 3);

    assert(test_list.size() == 9);
    assert(test_list.elementAt(3) == 'z');
    assert(test_list.toString() == "[CharLinkedList of size 9 <<abczdefgh>>]");
}

// Tests out-of-range insertion for a non-empty list.
void insertAt_nonempty_incorrect() {
   
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    string error_message = "";

    try {
        test_list.insertAt('a', 42);
    }
    catch (const range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8]");
    
}

// insertInOrder() Test 1: Singleton List, Front
void insertInOrder_singleton_list_front() {
    CharLinkedList list('b');

    list.insertInOrder('a');
    
    assert(list.size() == 2);
    assert(list.first() == 'a');
}

// insertInOrder() Test 2: Singleton List, Back
void insertInOrder_singleton_list_back() {
    CharLinkedList list('b');

    list.insertInOrder('c');
    
    assert(list.size() == 2);
    assert(list.last() == 'c');
}

// insertInOrder() Test 3: Large List, Front
void insertInOrder_large_list_front() {
    char arr[] = {'2','3','4'};
    CharLinkedList list(arr,3);

    list.insertInOrder('1');

    assert(list.size() == 4);
    assert(list.first() == '1');
    assert(list.toString() == "[CharLinkedList of size 4 <<1234>>]");
}

// insertInOrder() Test 4: Large List, Back
void insertInOrder_large_list_back() {
    char arr[] = {'1','2','3'};
    CharLinkedList list(arr,3);

    list.insertInOrder('4');

    assert(list.size() == 4);
    assert(list.last() == '4');
    assert(list.toString() == "[CharLinkedList of size 4 <<1234>>]");
}

// insertInOrder() Test 5: Large List, Middle
void insertInOrder_large_list_middle() {
    char arr[] = {'1','3','4'};
    CharLinkedList list(arr,3);

    list.insertInOrder('2');

    assert(list.size() == 4);
    assert(list.elementAt(1) == '2');
    assert(list.toString() == "[CharLinkedList of size 4 <<1234>>]");
}

// insertInOrder() Test 6: Empty List
void insertInOrder_empty_list() {
    CharLinkedList list;

    list.insertInOrder('2');

    assert(list.size() == 1);
    assert(list.first() == '2');
}

// popFromFront() Test 1: Singleton List
void popFromFront_singleton_list() {
    CharLinkedList list('c');

    list.popFromFront();

    assert(list.size() == 0);
    assert(list.isEmpty());
}

// popFromFront() Test 2: Large List
void popFromFront_large_list() {
    char arr[] = {'1','2','3','4'};
    CharLinkedList list(arr,4);

    list.popFromFront();

    assert(list.size() == 3);
    assert(list.toString() == "[CharLinkedList of size 3 <<234>>]");
}

// popFromFront() Test 3: Empty List (exception)
void popFromFront_empty_list() {
    CharLinkedList list;

    try {
        list.popFromFront();
    }
    catch (runtime_error) {
        assert(true);
    }   
}

// popFromBack() Test 1: Singleton List
void popFromBack_singleton_list() {
    CharLinkedList list('c');

    list.popFromBack();

    assert(list.size() == 0);
    assert(list.isEmpty());
}

// popFromBack() Test 2: Large List
void popFromBack_large_list() {
    char arr[] = {'1','2','3','4'};
    CharLinkedList list(arr,4);

    list.popFromBack();
    cout << list.elementAt(2);

    assert(list.size() == 3);
    assert(list.last() == '3');
    assert(list.toString() == "[CharLinkedList of size 3 <<123>>]");
}

// popFromBack() Test 3: Empty List (exception)
void popFromBack_empty_list() {
    CharLinkedList list;
    try {
        list.popFromBack();
    }
    catch (runtime_error) {
        assert(true);
    }   
}

// removeAt() Test 1: Singleton List
void removeAt_singleton_list() {
    CharLinkedList list('c');

    list.removeAt(0);

    assert(list.size() == 0);
    assert(list.isEmpty());
}

// removeAt() Test 2: Large List, Front
void removeAt_large_list_front() {
    char arr[] = {'b','e','a','r'};
    CharLinkedList list(arr, 4);

    list.removeAt(0);

    assert(list.size() == 3);
    assert(list.first() == 'e');
    assert(list.toString() == "[CharLinkedList of size 3 <<ear>>]");
}

// removeAt() Test 3: Large List, Back
void removeAt_large_list_back() {
    char arr[] = {'b','e','a','r'};
    CharLinkedList list(arr, 4);

    list.removeAt(3);

    assert(list.size() == 3);
    assert(list.last() == 'a');
    assert(list.toString() == "[CharLinkedList of size 3 <<bea>>]");
}

// removeAt() Test 4: Large List, Middle
void removeAt_large_list_middle() {
    char arr[] = {'b','e','a','r'};
    CharLinkedList list(arr, 4);

    list.removeAt(1);

    assert(list.size() == 3);
    assert(list.elementAt(1) == 'a');
    assert(list.toString() == "[CharLinkedList of size 3 <<bar>>]");
}

// removeAt() Test 5: Empty List (exception)
void removeAt_empty_list() {
    CharLinkedList list;
    
    try {
        list.removeAt(1);
    }
    catch (range_error) {
        assert(true);
    }
}

// removeAt() Test 6: Out of Range (exception)
void removeAt_out_of_range() {
    char arr[] = {'b','e','a','r'};
    CharLinkedList list(arr, 4);
    
    try {
        list.removeAt(list.size() +1);
    }
    catch (range_error) {
        assert(true);
    }
}

// replaceAt() Test 1: Singleton List
void replaceAt_singleton_list() {
    CharLinkedList list('c');

    list.replaceAt('d', 0);

    assert(list.size() == 1);
    assert(list.first() == 'd');
}

// replaceAt() Test 2: Large List, Front
void replaceAt_large_list_front() {
    char arr[] = {'c','o','p'};
    CharLinkedList list(arr, 3);

    list.replaceAt('t', 0);

    assert(list.size() == 3);
    assert(list.toString() == "[CharLinkedList of size 3 <<top>>]");
}

// replaceAt() Test 3: Large List, Back
void replaceAt_large_list_back() {
    char arr[] = {'c','o','p'};
    CharLinkedList list(arr, 3);

    list.replaceAt('d', 2);

    assert(list.size() == 3);
    assert(list.toString() == "[CharLinkedList of size 3 <<cod>>]");
}

// replaceAt() Test 4: Large List, Middle
void replaceAt_large_list_middle() {
    char arr[] = {'c','o','p'};
    CharLinkedList list(arr, 3);
    
    list.replaceAt('a', 1);

    assert(list.size() == 3);
    assert(list.toString() == "[CharLinkedList of size 3 <<cap>>]");
}

// replaceAt() Test 5: Empty List (exception)
void replaceAt_empty_list() {
    CharLinkedList list;

    try {
        list.replaceAt('d', 2);
    }
    catch (range_error) {
        assert(true);
    }
}

// replaceAt() Test 6: Out of Range (exception)
void replaceAt_out_of_range() {
    char arr[] = {'c','o','p'};
    CharLinkedList list(arr, 3);

    try {
        list.replaceAt('d', list.size()+1);
    }
    catch (range_error) {
        assert(true);
    }
}

// concatenate() Test 1: Singleton List, Append Singleton List 
void concatenate_singleton_singleton() {
    CharLinkedList list1('r');
    CharLinkedList list2('c');

    list1.concatenate(&list2);

    assert(list1.size() == 2);
    assert(list1.toString() == "[CharLinkedList of size 2 <<rc>>]");
}

// concatenate() Test 2: Singleton List, Append Large List 
void concatenate_singleton_large() {
    CharLinkedList list1('r');
    char arr2[] = {'c','o','p'};
    CharLinkedList list2(arr2, 3);

    list1.concatenate(&list2);

    assert(list1.size() == 4);
    assert(list1.toString() == "[CharLinkedList of size 4 <<rcop>>]");
}

// concatenate() Test 3: Singleton List, Append Empty List 
void concatenate_singleton_empty() {
    CharLinkedList list1('r');
    CharLinkedList list2;

    list1.concatenate(&list2);

    assert(list1.size() == 1);
    assert(list1.toString() == "[CharLinkedList of size 1 <<r>>]");
}

// concatenate() Test 4: Large List, Append Singleton List 
void concatenate_large_singleton() {
    char arr1[] = {'r','o','b','o'};
    CharLinkedList list1(arr1, 4);
    CharLinkedList list2('c');

    list1.concatenate(&list2);

    assert(list1.size() == 5);
    assert(list1.toString() == "[CharLinkedList of size 5 <<roboc>>]");
}

// concatenate() Test 5: Large List, Append Large List 
void concatenate_large_large() {
    char arr[] = {'r','o','b','o'};
    CharLinkedList list(arr, 4);

    list.concatenate(&list);

    assert(list.size() == 8);
    assert(list.toString() == "[CharLinkedList of size 8 <<roborobo>>]");
}

// concatenate() Test 6: Large List, Append Empty List 
void concatenate_large_empty() {
    char arr[] = {'r','o','b','o'};
    CharLinkedList list1(arr, 4);
    CharLinkedList list2;

    list1.concatenate(&list2);

    assert(list1.size() == 4);
    assert(list1.toString() == "[CharLinkedList of size 4 <<robo>>]");
}

// concatenate() Test 7: Empty List, Append Singleton List
void concatenate_empty_singleton() {
    CharLinkedList list1;
    CharLinkedList list2('c');

    list1.concatenate(&list2);

    assert(list1.size() == 1);
    assert(list1.toString() == "[CharLinkedList of size 1 <<c>>]");
}

// concatenate() Test 8: Empty List, Append Large List
void concatenate_empty_large() {
    CharLinkedList list1;
    char arr[] = {'c','o','p'};
    CharLinkedList list2(arr, 3);

    list1.concatenate(&list2);

    assert(list1.size() == 3);
    assert(list1.toString() == "[CharLinkedList of size 3 <<cop>>]");
}

// concatenate() Test 9: Empty List, Append Empty List
void concatenate_empty_empty() {
    CharLinkedList list1;
    CharLinkedList list2;

    list1.concatenate(&list2);

    assert(list1.size() == 0);
    assert(list1.toString() == "[CharLinkedList of size 0 <<>>]");
}
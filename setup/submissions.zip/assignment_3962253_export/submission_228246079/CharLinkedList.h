/*
 *  CharLinkedList.h
 *  Joel Lawore (jlawor01)
 *  1 February 2024
 *
 *  CS 15 HW 2
 *
 *  This file contains the interface for CharLinkedList Class. The list is 
 *  implemented using Nodes therefore providing quick insertion and deletion of
 *  elements.
 */

#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H

#include <string>
#include <stdexcept>
#include <iostream>

using namespace std;

class CharLinkedList {
public:
    /* Constructors/Deconstructor */
    CharLinkedList();
    CharLinkedList(char c);
    CharLinkedList(char arr[], int size);
    CharLinkedList(const CharLinkedList &other);
    ~CharLinkedList();

    /* Overloaded Assignment Operator */
    CharLinkedList &operator=(const CharLinkedList &other);

    /* Member Functions */
    bool isEmpty() const;
    void clear();
    int size() const;
    char first() const;
    char last() const;
    char elementAt(int index) const;
    std::string toString() const;
    std::string toReverseString() const;
    void pushAtBack(char c);
    void pushAtFront(char c);
    void insertAt(char c, int index);
    void insertInOrder(char c);
    void popFromFront();
    void popFromBack();
    void removeAt(int index);
    void replaceAt(char c, int index);
    void concatenate(CharLinkedList *other);
    
private:
    
    /* Node Struct */
    struct Node {
        char c;
        Node *previous;
        Node *next;
    };

    /* Data Members */
    Node *front;
    Node *back;
    int currSize;

    /* Private Helper Functions */
    Node *newNode(char c, Node *previous, Node *next);
    Node *nodeAt(int index) const;
    Node *traverseForwards(Node *curr, int count, int index) const;
    Node *traverseBackwards(Node *curr, int count, int index) const;
    void clearHelper(Node *curr);
    void throwRangeError(int index, bool inclusive) const;
    bool inRange(int index, bool inclusive) const;

};

#endif

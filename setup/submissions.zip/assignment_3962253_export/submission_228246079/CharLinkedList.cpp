/*
 *  CharLinkedList.cpp
 *  Joel Lawore (jlawor01)
 *  1 February 2024
 *
 *  CS 15 HW 2
 *
 *  This file contains an implementation for the CharLinkedList class.
 *
 */

#include "CharLinkedList.h"

/* Default Constructor
 * Purpose: Creates empty list.
 * Parameters: N/A.
 * Returns: N/A.
*/
CharLinkedList::CharLinkedList() {

    front = nullptr;
    back = nullptr;
    currSize = 0;

}

/* Second Constructor
 * Purpose: Creates singleton list.
 * Parameters: A single character.
 * Returns: N/A.
*/
CharLinkedList::CharLinkedList(char c) {

    front = nullptr;
    back = nullptr;
    currSize = 0;
    pushAtBack(c);

}

/* Third Constructor 
 * Purpose: Creates list for a corresponding array. 
 * Parameters: An array of characters and its size.
 * Returns: N/A.
*/
CharLinkedList::CharLinkedList(char arr[], int size) {

    front = nullptr;
    back = nullptr;
    currSize = 0;
    for (int i = 0; i < size; i++) {
        pushAtBack(arr[i]);
    }
    
}

/* Copy Constructor
 * Purpose: Creates list identical to another list.
 * Parameters: A list of characters.
 * Returns: N/A.
*/
CharLinkedList::CharLinkedList(const CharLinkedList &other) {

    front = nullptr;
    back = nullptr;
    currSize = 0;

    int new_size = other.size();

    // copies elements into list
    for (int i = 0; i < new_size; i++) {
        pushAtBack(other.elementAt(i));
    }

}

/* Deconstructor
 * Purpose: Frees up memory.
 * Parameters: N/A.
 * Returns: N/A.
*/
CharLinkedList::~CharLinkedList() {
    
    if (not isEmpty())
        clear();
    
}

/* Overloaded Assignment Operator
 * Purpose: Assigns list 'other' to a list variable (deep copy).
 * Parameters: Address of CharLinkedList 'other'.
 * Returns: Address of new list in memory.
*/
CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other){

    // makes no changes if lists are the same
    if (this == &other) {
        return *this;
    }

    // clears list (clear function checks if list is empty)
    clear();
    int new_size = other.size();

    // copies elements into list
    for (int i = 0; i < new_size; i++) {
        pushAtBack(other.elementAt(i));
    }
    
    return *this;

}

/* isEmpty
 * Purpose: Indicates whether list is empty.
 * Parameters: N/A.
 * Returns: Returns true if size is 0, false otherwise.
*/
bool CharLinkedList::isEmpty() const {

    if (currSize == 0)
        return true;
    return false;

}

/* clear
 * Purpose: Removes all elements from list.
 * Parameters: N/A.
 * Returns: N/A.
*/
void CharLinkedList::clear() {

    // delete all Nodes in list
    clearHelper(front);

}

/* size
 * Purpose: Size of the list.
 * Parameters: N/A.
 * Returns: Returns size of the list as an integer.
*/
int CharLinkedList::size() const {
    return currSize;
}

/* first
 * Purpose: Returns the first character.
 * Parameters: N/A.
 * Returns: Returns the first element in the list.
*/
char CharLinkedList::first() const {

    if (not isEmpty())
        return front->c;
    
    // error if called on empty list
    throw runtime_error("cannot get first of empty LinkedList");
        return EXIT_FAILURE;

}

/* last
 * Purpose: Returns the last character.
 * Parameters: N/A.
 * Returns: Returns the last element in the list.
*/
char CharLinkedList::last() const {

    if (not isEmpty())
        return back->c;
    
    // error if called on empty list
    throw runtime_error("cannot get last of empty LinkedList");
        return EXIT_FAILURE;

}

/* elementAt
 * Purpose: Returns the nth character.
 * Parameters: Index 'n' that should be returned.
 * Returns: Returns the nth element in the list.
*/
char CharLinkedList::elementAt(int index) const {

    // checks if index is in range, throws error if not
    if (inRange(index, false)) {
    
        Node *curr = nodeAt(index);
        return curr->c;
    }

    return EXIT_FAILURE;
}

/* toString
 * Purpose: Returns characters consecutively.
 * Parameters: N/A.
 * Returns: Concatenates characters in the list
           into a string and returns them.
*/
string CharLinkedList::toString() const {

    string message = "[CharLinkedList of size " +
                     to_string(currSize) + " <<";
    
    // appends characters to string
    for (int i = 0; i < currSize; i++) {
        message += elementAt(i);
    } 

    message += ">>]";
    return message;

}

/* toReverseString
 * Purpose: Returns characters consecutively.
 * Parameters: N/A.
 * Returns: Inversely concatenates characters in the
           list into a string and returns them.
*/
string CharLinkedList::toReverseString() const {

    string message = "[CharLinkedList of size " +
                     to_string(currSize) + " <<";

    // appends characters to string inversely
    for (int i = currSize-1; i >= 0; i--) {
        message += elementAt(i);
    }

    message += ">>]";
    return message;
}

/* pushAtBack
 * Purpose: Appends character 'c' at the end of the list.
 * Parameters: Character 'c' that should be appended.
 * Returns: N/A.
*/
void CharLinkedList::pushAtBack(char c) {

    if (isEmpty()) {
        // sets front and back equal if adding to empty list
        front = back = newNode(c, nullptr, nullptr);
    }
    else {
        Node *temp = back;
        back = newNode(c, back, nullptr);
        // changes next pointer of the former back Node
        temp->next = back;
    }
    currSize++;

}

/* pushAtFront
 * Purpose: Appends character 'c' at the front of the list.
 * Parameters: Character 'c' that should be appended.
 * Returns: N/A.
*/
void CharLinkedList::pushAtFront(char c) {

    if (isEmpty()) {
        // sets front and back equal if adding to empty list
        back = front = newNode(c, nullptr, nullptr);
    }
    else {
        Node *temp = front;
        front = newNode(c, nullptr, front);
        // changes previous pointer of the former front Node
        temp->previous = front;
    }
    currSize++;

}

/* insertAt
 * Purpose: Appends character 'c' at nth index.
 * Parameters: Character 'c' that should be appended at index 'n'.
 * Returns: Error if index is out of bounds.
*/
void CharLinkedList::insertAt(char c, int index) {

    // checks if index is in range, throws error if not
    if (inRange(index,true)) {
        if (index == 0) {
            pushAtFront(c);
        }
        else if (index == currSize) {
            pushAtBack(c);
        }
        else {

            // saves Node currently at the index
            Node *curr = nodeAt(index);
            Node *temp = curr->previous;
            // creates new Node and reassigns pointers
            curr->previous = newNode(c,temp,curr);
            temp->next = curr->previous;
            currSize++;

        }
    }

}

/* insertInOrder
 * Purpose: Appends character 'c' in alphabetical order.
 * Parameters: Character 'c' that should be appended.
 * Returns: N/A.
*/
void CharLinkedList::insertInOrder(char c) {
    
    int i = 0;
    while (i < currSize) {

        // finds first available index
        if (c <= elementAt(i)) {

            // inserts at index
            insertAt(c, i);
            return;

        }
        i++;

    }

    // inserts at end if ASCII value is greatest
    pushAtBack(c);

}

/* popFromFront
 * Purpose: Removes first character.
 * Parameters: N/A.
 * Returns: Error if list is empty.
*/
void CharLinkedList::popFromFront() {

    // throws error if list is empty
    if (isEmpty()){
        throw runtime_error("cannot pop from empty LinkedList");
    }
    else {

        Node *temp = front;
        // makes the second Node the new front Node
        front = front->next;
        delete temp;
        currSize--;

        if (not isEmpty())
            front->previous = nullptr;
    }

}

/* popFromBack
 * Purpose: Removes last character.
 * Parameters: N/A.
 * Returns: Error if list is empty.
*/
void CharLinkedList::popFromBack() {

    // throws error if list is empty
    if (isEmpty()) {
        throw runtime_error("cannot pop from empty LinkedList");
    }
    else {

        Node *temp = back;
        // makes the penultimate Node the new back Node
        back = back->previous;
        delete temp;
        currSize--;

        if (not isEmpty())
            back->next = nullptr;
    }


}

/* removeAt
 * Purpose: Removes nth character.
 * Parameters: Index 'n'.
 * Returns: Error if index is out of bounds.
*/
void CharLinkedList::removeAt(int index) {

    // checks if index is in range, throws error if not
    if (inRange(index,false)) {
        
        if (index == 0) {
            popFromFront();
        }
        else if (index == currSize-1) {
            popFromBack();
        }
        else {

            // saves Node currently at index to delete later
            Node *temp = nodeAt(index);
            // links the previous and next Nodes of the saved Node
            temp->previous->next = temp->next;
            temp->next->previous = temp->previous;
            delete temp;
            currSize--;

        }

    }

}

/* replaceAt
 * Purpose: Replaces the character at the nth index with character 'c'. 
 * Parameters: Character 'c' that should be appended at index 'n'.
 * Returns: Error if index is out of range.
*/
void CharLinkedList::replaceAt(char c, int index) {

    // checks if index is in range, throws error if not
    if (inRange(index,false)) {

        Node *curr = nodeAt(index);
        curr->c = c;

    }

}

/* concatenate
 * Purpose: Consectively appends characters in list 'other'.
 * Parameters: List 'other' to be appended.
 * Returns: N/A.
*/
void CharLinkedList::concatenate(CharLinkedList *other) {

    // makes no changes if nullptr is passed in
    if (other != nullptr) {
        if (other->size() != 0) {

            // saves size of other incase it changes (if other == this)
            int new_size = other->size();

            // appends elements to back
            for (int i = 0; i < new_size; i++) {
                pushAtBack(other->elementAt(i));
            }
        }
    }
}

                        /* Helper Functions */

/* newNode
 * Purpose: Creates a Node.
 * Parameters: The character for the Node and its pointers.
 * Returns: Returns the new Node.
*/
CharLinkedList::Node *CharLinkedList::newNode(char c, Node *previous, 
                                              Node *next) {

    // dynamically create a new Node
    Node *n = new Node;
    n->c = c;
    n->previous = previous;
    n->next = next;
    return n;

}

/* nodeAt
 * Purpose: Finds Node at given index.
 * Parameters: The index of the desired Node.
 * Returns: Returns the desired Node.
*/
CharLinkedList::Node *CharLinkedList::nodeAt(int index) const {

    // traverse from back if index is at the back half of the list
    if (index >= currSize/2)
        return traverseBackwards(back, currSize-1, index);

    // traverse from the front otherwise
    return traverseForwards(front, 0, index);
            
}

/* traverseForwards
 * Purpose: Traverses through the next Nodes.
 * Parameters: The starting Node, the index of the desired Node, and a counter.
 * Returns: Returns the desired Node.
*/
CharLinkedList::Node *CharLinkedList::traverseForwards(Node *curr, int count,
                                                       int index) const{

    // Base Case: Reached Desired Node
    if (count == index)
        return curr;

    // Recursive Case: Check Next Node
    return traverseForwards(curr->next, ++count, index);

}

/* traverseBackwards
 * Purpose: Traverses through the previous Nodes.
 * Parameters: The starting Node, the index of the desired Node and a counter.
 * Returns: Returns the desired Node.
*/
CharLinkedList::Node *CharLinkedList::traverseBackwards(Node *curr, int count,
                                                        int index) const {

    // Base Case: Reached Desired Node
    if (count == index)
        return curr;

    // Recursive Case: Check Previous Node
    return traverseBackwards(curr->previous, --count, index);

}

/* clearHelper
 * Purpose: Deletes all Nodes following a given Node.
 * Parameters: Node to start from.
 * Returns: N/A.
*/
void CharLinkedList::clearHelper(Node *curr) {

    // Base Case: Nullptr
    if (curr == nullptr)
        return;

    // Recursive Case: Delete Next Node
    clearHelper(curr->next);
    delete curr;
    currSize--;

}

/* throwRangeError
 * Purpose: Throws error for when index is out of range.
 * Parameters: Index and boolean indicating whether range is inclusive.
 * Returns: N/A.
*/
void CharLinkedList::throwRangeError(int index, bool inclusive) const {

    string error = "index (" + to_string(index) +
                        ") not in range [0.." +
                        to_string(currSize);

    // appends bracket if range is inclusive, parantheses otherwise
    if (inclusive) {
        error += "]";
    }
    else {
        error += ")";
    }

    throw range_error(error);
}



/* inRange
 * Purpose: Determines whether a given index is in the range of the list.
 * Parameters: Index and boolean indicating whether range is inclusive.
 * Returns: Returns true is index is in range, false otherwise.
*/
bool CharLinkedList::inRange(int index, bool inclusive) const {
    
    // checks if index is in range for an inclusive range
    if (inclusive) {

        if (index <= currSize and index >= 0)
            return true;
        
        // throws error is range is out of bounds
        throwRangeError(index, inclusive);
        return false;

    }

    // checks if index is in range for an exclusive range
    if (index < currSize and index >= 0)
        return true;

    // throws error if range is out of bounds
    throwRangeError(index, inclusive);
    return false;

}
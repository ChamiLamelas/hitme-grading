/*
 *  unit_tests.h
 *  Ryan McClennen
 *  1/31/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  Tests the CharLinkedList class on
 *  various common and edge cases.
 *
 */

#include "CharLinkedList.h"
#include <cassert>
#include "stdexcept"

// Tests the default constructor
void default_constructor_test_0()
{
    CharLinkedList list;
}

// Tests that the default constructor initializes the correct values
void default_constructor_test_1()
{
    CharLinkedList list;
    assert(list.isEmpty());
    assert(list.size() == 0);
}

// Tests the single-char constructor
void char_constructor_test_0()
{
    CharLinkedList list = CharLinkedList('W');
}

// Tests that the single char constructor initializes the correct values
void char_constructor_test_1()
{
    CharLinkedList list = CharLinkedList('W');
    assert(list.size() == 1);
    assert(list.first() == 'W');
}

// Tests the array copy constructor
void array_constructor_test_0()
{
    char testArr[] = {'R', 'Y', 'A', 'N'};
    CharLinkedList list(testArr, 4);
}

// Tests that the array copy constructor initializes the correct values
void array_constructor_test_1()
{
    char testArr[] = {'R', 'Y', 'A', 'N'};
    CharLinkedList list(testArr, 4);
    assert(list.size() == 4);
    assert(list.toString() == "[CharLinkedList of size 4 <<RYAN>>]");
}

// Tests the copy constructor
void copy_constructor_test_0()
{
    char testArr[] = {'R', 'Y', 'A', 'N'};
    CharLinkedList list0(testArr, 4);
    CharLinkedList list1(list0);
}

// Tests that the copy constructor initializes the correct values
void copy_constructor_test_1()
{
    char testArr[] = {'R', 'Y', 'A', 'N'};
    CharLinkedList list0(testArr, 4);
    CharLinkedList list1(list0);
    assert(list1.size() == 4);
    assert(list1.toString() == "[CharLinkedList of size 4 <<RYAN>>]");
}

// Tests the assign operator on an empty list
void assign_operator_empty()
{
    CharLinkedList list0;
    char testArr[] = {'L', 'U', 'C', 'A', 'S'};
    CharLinkedList list1(testArr, 5);
    assert(list0.toString() != list1.toString());

    list0 = list1;
    assert(list0.toString() == list1.toString());
}

// Tests the assign operator on a full list
void assign_operator_full()
{
    char testArr0[] = {'R', 'Y', 'A', 'N'};
    CharLinkedList list0(testArr0, 4);
    char testArr1[] = {'L', 'U', 'C', 'A', 'S'};
    CharLinkedList list1(testArr1, 5);
    assert(list0.toString()!= list1.toString());

    list0 = list1;
    assert(list0.toString() == list1.toString());
}

// Tests the isEmpty method on a filled list
void isEmpty_false()
{
    char testArr[] = {'R', 'Y', 'A', 'N'};
    CharLinkedList list(testArr, 4);
    assert(not list.isEmpty());
}

// Tests the isEmpty method after an item is removed
void isEmpty_removal()
{
    CharLinkedList list('R');
    assert(not list.isEmpty());
    list.popFromBack();
    assert(list.isEmpty());
}

// Tests the isEmpty method after an item is added
void isEmpty_adding()
{
    CharLinkedList list;
    assert(list.isEmpty());
    list.pushAtBack('R');
    assert(not list.isEmpty());
}

// Tests the clear method
void clear()
{
    char testArr[] = {'R', 'Y', 'A', 'N'};
    CharLinkedList list(testArr, 4);
    list.clear();
    assert(list.isEmpty());
}

// Tests that chars can be added after the clear method
void clear_then_add()
{
    char testArr[] = {'R', 'Y', 'A', 'N'};
    CharLinkedList list(testArr, 4);
    list.clear();
    list.pushAtBack('R');
    assert((list.size() == 1));
}

// Tests the size method on an empty list
void size_empty()
{
    CharLinkedList list;
    assert(list.size() == 0);
}

// Tests the size method on a full list
void size_full()
{
    char testArr[] = {'1', '2', '3'};
    CharLinkedList list(testArr, 3);
    assert(list.size() == 3);
}

// Tests the size method after removing
void size_remove()
{
    char testArr[] = {'1', '2', '3'};
    CharLinkedList list(testArr, 3);
    assert(list.size() == 3);
    list.popFromBack();
    assert(list.size() == 2);
}

// Tests the size method after adding
void size_add()
{
    char testArr[] = {'1', '2', '3'};
    CharLinkedList list(testArr, 3);
    assert(list.size() == 3);
    list.pushAtBack('4');
    assert(list.size() == 4);
}

// Tests the first method one a full array
void first_full()
{
    char testArr[] = {'1', '2', '3'};
    CharLinkedList list(testArr, 3);
    assert(list.first() == '1');
}

// Tests the first method after replaceing the first char
void first_replace_start()
{
    char testArr[] = {'1', '2', '3'};
    CharLinkedList list(testArr, 3);
    assert(list.first() == '1');
    list.replaceAt('4', 0);
    assert(list.first() == '4');
}

// Tests the first method one an empty list
void first_empty()
{
    bool runtime_error_thrown = false;
    std::string error_message = "";

    CharLinkedList list;
    try
    {
        list.first();
    }
    catch (const std::runtime_error &e)
    {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot get first of empty LinkedList");
}

// Tests the last method one a full array
void last_full()
{
    char testArr[] = {'1', '2', '3'};
    CharLinkedList list(testArr, 3);
    assert(list.last() == '3');
}

// Tests the first method after adding a char
void last_add_end()
{
    char testArr[] = {'1', '2', '3'};
    CharLinkedList list(testArr, 3);
    assert(list.last() == '3');
    list.pushAtBack('4');
    assert(list.last() == '4');
}

// Tests the first method after replaceing the first char
void last_replace_end()
{
    char testArr[] = {'1', '2', '3'};
    CharLinkedList list(testArr, 3);
    assert(list.last() == '3');
    list.replaceAt('4', 2);
    assert(list.last() == '4');
}

// Tests the first method one an empty list
void last_empty()
{
    CharLinkedList list;
    bool runtime_error_thrown = false;
    std::string error_message = "";

    try
    {
        list.last();
    }
    catch (const std::runtime_error &e)
    {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot get last of empty LinkedList");
}

// Tests elementAt for the first item in the list
void elementAt_first()
{
    char testArr[] = {'1', '2', '3'};
    CharLinkedList list(testArr, 3);
    assert(list.elementAt(0) == '1');
}

// Tests elementAt for an item in the middle of the list
void elementAt_middle()
{
    char testArr[] = {'1', '2', '3'};
    CharLinkedList list(testArr, 3);
    assert(list.elementAt(1) == '2');
}

// Tests elementAt for an item at the end of the LinkedList
void elementAt_last()
{
    char testArr[] = {'1', '2', '3'};
    CharLinkedList list(testArr, 3);
    assert(list.elementAt(2) == '3');
}

// Tests elementAt with an index that is too large
void elementAt_illegal_large()
{
    char testArr[] = {'1', '2', '3'};
    CharLinkedList list(testArr, 3);
    bool range_error_thrown = false;
    std::string error_message = "";

    try
    {
        list.elementAt(5);
    }
    catch (const std::range_error &e)
    {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (5) not in range [0..3)");
}

// Tests elementAt with an index that is too small
void elementAt_illegal_small()
{
    char testArr[] = {'1', '2', '3'};
    CharLinkedList list(testArr, 3);
    bool range_error_thrown = false;
    std::string error_message = "";

    try
    {
        list.elementAt(-2);
    }
    catch (const std::range_error &e)
    {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (-2) not in range [0..3)");
}

// Tests elementAt on am empty list
void elementAt_illegal_empty()
{
    CharLinkedList list;
    bool range_error_thrown = false;
    std::string error_message = "";

    try
    {
        list.elementAt(0);
    }
    catch (const std::range_error &e)
    {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (0) not in range [0..0)");
}

// Test toString with a full list
void toString_full()
{
    char testArr[] = {'R', 'Y', 'A', 'N'};
    CharLinkedList list(testArr, 4);
    assert(list.toString() == "[CharLinkedList of size 4 <<RYAN>>]");
}

// Test toString with an empty list
void toString_empty()
{
    CharLinkedList list;
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}

// Test toReverseString with a full list
void toReverseString_full()
{
    char testArr[] = {'R', 'Y', 'A', 'N'};
    CharLinkedList list(testArr, 4);
    assert(list.toReverseString() == "[CharLinkedList of size 4 <<NAYR>>]");
}

// Test toReverseString with an empty list
void toReverseString_empty()
{
    CharLinkedList list;
    assert(list.toReverseString() == "[CharLinkedList of size 0 <<>>]");
}

// Test pushAtBack on an empty list
void pushAtBack_empty()
{
    CharLinkedList list;
    list.pushAtBack('1');
    assert(list.last() == '1');
}

// Test pushAtBack once
void pushAtBack_single()
{
    char testArr[] = {'1', '2', '3'};
    CharLinkedList list(testArr, 3);
    assert(list.last() == '3');
    list.pushAtBack('4');
    assert(list.last() == '4');
}

// Test pushAtBack multiple times
void pushAtBack_multiple()
{
    char testArr[] = {'1', '2', '3'};
    CharLinkedList list(testArr, 3);
    assert(list.last() == '3');
    list.pushAtBack('4');
    assert(list.last() == '4');
    list.pushAtBack('5');
    assert(list.last() == '5');
    list.pushAtBack('6');
    assert(list.last() == '6');
}

// Test pushAtFront on an empty list
void pushAtFront_empty()
{
    CharLinkedList list;
    list.pushAtFront('1');
    assert(list.first() == '1');
}

// Test pushAtFront once
void pushAtFront_single()
{
    char testArr[] = {'1', '2', '3'};
    CharLinkedList list(testArr, 3);
    assert(list.first() == '1');
    list.pushAtFront('4');
    assert(list.first() == '4');
}

// Test pushAtFront multiple times
void pushAtFront_multiple()
{
    char testArr[] = {'1', '2', '3'};
    CharLinkedList list(testArr, 3);
    assert(list.first() == '1');
    list.pushAtFront('4');
    assert(list.first() == '4');
    list.pushAtFront('5');
    assert(list.first() == '5');
    list.pushAtFront('6');
    assert(list.first() == '6');
}

// Tests correct insertion into an empty AL.
// Afterwards, size should be 1 and element at index 0
// should be the element we inserted.
void insertAt_empty_correct() { 

    CharLinkedList test_list;
    test_list.insertAt('a', 0);
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');

}

// Tests incorrect insertion into an empty LL.
void insertAt_empty_incorrect() {

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    // insertAt for out-of-range index
    test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
    // if insertAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    range_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0]");
    
}

// Tests correct insertAt for front of 1-element list.
void insertAt_front_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at front
    test_list.insertAt('b', 0);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'a');
    
}

// Tests correct insertAt for back of 1-element list.
void insertAt_back_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at back
    test_list.insertAt('b', 1);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    
}

// Tests calling insertAt for a large number of elements.
void insertAt_many_elements() {
    
    CharLinkedList test_list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.insertAt('a', i);
    }

    assert(test_list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
    
}

// Tests insertion into front of a larger list
void insertAt_front_large_list() {
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    test_list.insertAt('y', 0);

    assert(test_list.size() == 10);
    assert(test_list.elementAt(0) == 'y');
    assert(test_list.toString() ==
    "[CharLinkedList of size 10 <<yabczdefgh>>]");

}

// Tests insertion into the back of a larger list
void insertAt_back_large_list() {

    char test_arr[10] = { 'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 10);  

    test_list.insertAt('x', 10);

    assert(test_list.size() == 11);
    assert(test_list.elementAt(10) == 'x');
    assert(test_list.toString() == 
    "[CharLinkedList of size 11 <<yabczdefghx>>]"); 

}

// Tests insertion into the middle of a larger list
void insertAt_middle_large_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.insertAt('z', 3);

    assert(test_list.size() == 9);
    assert(test_list.elementAt(3) == 'z');
    assert(test_list.toString() == "[CharLinkedList of size 9 <<abczdefgh>>]");

}

// Tests out-of-range insertion for a non-empty list.
void insertAt_nonempty_incorrect() {
   
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8]"); 
}

// Test insertInOrder on an empty list
void insertInOrder_empty()
{
    CharLinkedList list;
    list.insertInOrder('A');
    assert(list.first() == 'A');
    assert(list.size() == 1);
}

// Test insertInOrder for the beginning of a list
void insertInOrder_beginning()
{
    char testArr[] = {'B', 'C', 'D', 'E'};
    CharLinkedList list(testArr, 4);
    list.insertInOrder('A');
    assert(list.first() == 'A');
    assert(list.size() == 5);
}

// Test insertInOrder for the middle of a list
void insertInOrder_middle()
{
    char testArr[] = {'A', 'B', 'D', 'E'};
    CharLinkedList list(testArr, 4);
    list.insertInOrder('C');
    assert(list.elementAt(2) == 'C');
    assert(list.size() == 5);
}

// Test insertInOrder for the end of a list
void insertInOrder_end()
{
    char testArr[] = {'A', 'B', 'C', 'D'};
    CharLinkedList list(testArr, 4);
    list.insertInOrder('E');
    assert(list.last() == 'E');
    assert(list.size() == 5);
}

// Tests popFromFront on am empty list
void popFromFront_empty()
{
    CharLinkedList list;
    bool runtime_error_thrown = false;
    std::string error_message = "";

    try
    {
        list.popFromFront();
    }
    catch (const std::runtime_error &e)
    {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

// Test popFromFront once
void popFromFront_single()
{
    char testArr[] = {'1', '2', '3'};
    CharLinkedList list(testArr, 3);
    list.popFromFront();
    assert(list.first() == '2');
    assert(list.size() == 2);
}

// Test popFromFront multiple times
void popFromFront_multiple()
{
    char testArr[] = {'1', '2', '3'};
    CharLinkedList list(testArr, 3);
    list.popFromFront();
    assert(list.first() == '2');
    assert(list.size() == 2);
    list.popFromFront();
    assert(list.first() == '3');
    assert(list.size() == 1);
    list.popFromFront();
    assert(list.isEmpty());
}

// Tests popFromBack on am empty list
void popFromBack_empty()
{
    CharLinkedList list;
    bool runtime_error_thrown = false;
    std::string error_message = "";

    try
    {
        list.popFromBack();
    }
    catch (const std::runtime_error &e)
    {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

// Test popFromFront once
void popFromBack_single()
{
    char testArr[] = {'1', '2', '3'};
    CharLinkedList list(testArr, 3);
    list.popFromBack();
    assert(list.last() == '2');
    assert(list.size() == 2);
}

// Test popFromBack multiple times
void popFromBack_multiple()
{
    char testArr[] = {'1', '2', '3'};
    CharLinkedList list(testArr, 3);
    list.popFromBack();
    assert(list.last() == '2');
    assert(list.size() == 2);
    list.popFromBack();
    assert(list.last() == '1');
    assert(list.size() == 1);
    list.popFromBack();
    assert(list.isEmpty());
}

// Test removeAt for the beginning of a list
void removeAt_beginning()
{
    char testArr[] = {'1', '2', '3', '4', '5'};
    CharLinkedList list(testArr, 5);
    list.removeAt(0);
    assert(list.toString() == "[CharLinkedList of size 4 <<2345>>]");
}

// Test removeAt for the middle of a list
void removeAt_middle()
{
    char testArr[] = {'1', '2', '3', '4', '5'};
    CharLinkedList list(testArr, 5);
    list.removeAt(2);
    assert(list.toString() == "[CharLinkedList of size 4 <<1245>>]");
}

// Test removeAt for the end of a list
void removeAt_end()
{
    char testArr[] = {'1', '2', '3', '4', '5'};
    CharLinkedList list(testArr, 5);
    list.removeAt(4);
    assert(list.toString() == "[CharLinkedList of size 4 <<1234>>]");
}

// Test removeAt many times on one list
void removeAt_many()
{
    char testArr[] = {'1', '2', '3', '4', '5'};
    CharLinkedList list(testArr, 5);
    list.removeAt(1);
    assert(list.toString() == "[CharLinkedList of size 4 <<1345>>]");
    list.removeAt(2);
    assert(list.toString() == "[CharLinkedList of size 3 <<135>>]");
    list.removeAt(0);
    assert(list.toString() == "[CharLinkedList of size 2 <<35>>]");
    list.removeAt(1);
    assert(list.toString() == "[CharLinkedList of size 1 <<3>>]");
}

// Tests removeAt with an index that is too large
void removeAt_illegal_large()
{
    char testArr[] = {'1', '2', '3'};
    CharLinkedList list(testArr, 3);
    bool range_error_thrown = false;
    std::string error_message = "";

    try
    {
        list.removeAt(5);
    }
    catch (const std::range_error &e)
    {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (5) not in range [0..3)");
}

// Tests removeAt with an index that is too small
void removeAt_illegal_small()
{
    char testArr[] = {'1', '2', '3'};
    CharLinkedList list(testArr, 3);
    bool range_error_thrown = false;
    std::string error_message = "";

    try
    {
        list.removeAt(-2);
    }
    catch (const std::range_error &e)
    {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (-2) not in range [0..3)");
}

// Tests removeAt on am empty list
void removeAt_illegal_empty()
{
    CharLinkedList list;
    bool range_error_thrown = false;
    std::string error_message = "";

    try
    {
        list.removeAt(0);
    }
    catch (const std::range_error &e)
    {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (0) not in range [0..0)");
}

// Test replaceAt for the beginning of a list
void replaceAt_beginning()
{
    char testArr[] = {'1', '2', '3', '4', '5'};
    CharLinkedList list(testArr, 5);
    list.replaceAt('6', 0);
    assert(list.toString() == "[CharLinkedList of size 5 <<62345>>]");
}

// Test replaceAt for the middle of a list
void replaceAt_middle()
{
    char testArr[] = {'1', '2', '3', '4', '5'};
    CharLinkedList list(testArr, 5);
    list.replaceAt('6', 2);
    assert(list.toString() == "[CharLinkedList of size 5 <<12645>>]");
}

// Test replaceAt for the end of a list
void replaceAt_end()
{
    char testArr[] = {'1', '2', '3', '4', '5'};
    CharLinkedList list(testArr, 5);
    list.replaceAt('6', 4);
    assert(list.toString() == "[CharLinkedList of size 5 <<12346>>]");
}

// Test replaceAt many times on one list
void replaceAt_many()
{
    char testArr[] = {'1', '2', '3', '4', '5'};
    CharLinkedList list(testArr, 5);
    list.replaceAt('N', 3);
    assert(list.toString() == "[CharLinkedList of size 5 <<123N5>>]");
    list.replaceAt('Y', 1);
    assert(list.toString() == "[CharLinkedList of size 5 <<1Y3N5>>]");
    list.replaceAt('R', 0);
    assert(list.toString() == "[CharLinkedList of size 5 <<RY3N5>>]");
    list.replaceAt('M', 4);
    assert(list.toString() == "[CharLinkedList of size 5 <<RY3NM>>]");
    list.replaceAt('A', 2);
    assert(list.toString() == "[CharLinkedList of size 5 <<RYANM>>]");
}

// Tests replaceAt with an index that is too large
void replaceAt_illegal_large()
{
    char testArr[] = {'1', '2', '3'};
    CharLinkedList list(testArr, 3);
    bool range_error_thrown = false;
    std::string error_message = "";

    try
    {
        list.replaceAt('R', 5);
    }
    catch (const std::range_error &e)
    {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (5) not in range [0..3)");
}

// Tests replaceAt with an index that is too small
void replaceAt_illegal_small()
{
    char testArr[] = {'1', '2', '3'};
    CharLinkedList list(testArr, 3);
    bool range_error_thrown = false;
    std::string error_message = "";

    try
    {
        list.replaceAt('R', -2);
    }
    catch (const std::range_error &e)
    {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (-2) not in range [0..3)");
}

// Tests replaceAt on am empty list
void replaceAt_illegal_empty()
{
    CharLinkedList list;
    bool range_error_thrown = false;
    std::string error_message = "";

    try
    {
        list.replaceAt('R', 0);
    }
    catch (const std::range_error &e)
    {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (0) not in range [0..0)");
}

// Test concatenate with two empty LinkedLists
void concatenate_empty_to_empty()
{
    CharLinkedList list0;
    CharLinkedList list1;
    list0.concatenate(&list1);
    assert(list0.toString() == "[CharLinkedList of size 0 <<>>]");
    assert(list1.toString() == "[CharLinkedList of size 0 <<>>]");
}

// Test concatenating an empty list to an full one
void concatenate_empty_to_full()
{
    char testArr[] = {'R', 'Y', 'A', 'N'};
    CharLinkedList list0(testArr, 4);
    CharLinkedList list1;
    list0.concatenate(&list1);
    assert(list0.toString() == "[CharLinkedList of size 4 <<RYAN>>]");
    assert(list1.toString() == "[CharLinkedList of size 0 <<>>]");
}

// Test concatenating a full list to an empty list
void concatenate_full_to_empty()
{
    char testArr[] = {'R', 'Y', 'A', 'N'};
    CharLinkedList list0(testArr, 4);
    CharLinkedList list1;
    list1.concatenate(&list0);
    assert(list0.toString() == "[CharLinkedList of size 4 <<RYAN>>]");
    assert(list1.toString() == "[CharLinkedList of size 4 <<RYAN>>]");
}

// Test concatenating two full lists
void concatenate_full_to_full()
{
    char testArr0[] = {'R', 'Y'};
    CharLinkedList list0(testArr0, 2);
    char testArr1[] = {'A', 'N'};
    CharLinkedList list1(testArr1, 2);
    list0.concatenate(&list1);
    assert(list0.toString() == "[CharLinkedList of size 4 <<RYAN>>]");
    assert(list1.toString() == "[CharLinkedList of size 2 <<AN>>]");
}

// Test concatenating a list to itself
void concatenate_self()
{
    char testArr[] = {'R', 'Y', 'A', 'N'};
    CharLinkedList list(testArr, 4);
    list.concatenate(&list);
    assert(list.toString() == "[CharLinkedList of size 8 <<RYANRYAN>>]");
}

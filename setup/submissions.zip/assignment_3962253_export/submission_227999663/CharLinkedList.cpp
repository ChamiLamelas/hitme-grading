/*
 *  CharLinkedList.cpp
 *  Ryan McClennen
 *  1/31/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Fully defines constructors/destructors,
 *  methods, and operator overrides for the
 *  CharLinkedList class.
 *
 */

#include "CharLinkedList.h"
#include "stdexcept"
#include <string>

using namespace std;

/*
 * name:      CharLinkedList
 * purpose:   initializes default values
 * arguments: none
 * returns:   the CharLinkedList
 * effects:   none
 */
CharLinkedList::CharLinkedList()
{
    numItems = 0;
    front = nullptr;
    back = nullptr;
}

/*
 * name:      CharLinkedList
 * purpose:   initializes the array list to hold one char
 * arguments: c, the first char in the list
 * returns:   the CharLinkedList
 * effects:   none
 */
CharLinkedList::CharLinkedList(char c)
{
    numItems = 1;
    Node *n = new Node {c, nullptr, nullptr};
    front = n;
    back = n;
}

/*
 * name:      CharLinkedList
 * purpose:   initializes the array list copy an array
 * arguments: arr, the array to be copied, and size, the length of arr
 * returns:   the CharLinkedList
 * effects:   none
 */
CharLinkedList::CharLinkedList(char arr[], int size)
{
    numItems = size;
    Node *prev = front = new Node {arr[0], nullptr, nullptr};

    // Loops through the array and make a new node for every char
    // Uses prev to link each node to the following node
    for (int i = 1; i < numItems; i++)
    {
        Node *temp = new Node {arr[i], prev, nullptr};
        prev->next = temp;
        prev = temp;
    }

    back = prev;
}

/*
 * name:      CharLinkedList
 * purpose:   initializes the array list copy another CharLinkedList
 * arguments: other, the CharLinkedList to be copied
 * returns:   the CharLinkedList
 * effects:   none
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other)
{
    numItems = other.numItems;
    Node *prev = front = new Node {other.front->info, nullptr, nullptr};

    // Loops through the other linked list and make a new node for every char
    // Uses prev to link each node to the following node
    for (Node *curr = other.front->next; curr != nullptr; curr = curr->next)
    {
        Node *temp = new Node {curr->info, prev, nullptr};
        prev->next = temp;
        prev = temp;
    }

    back = prev;
}

/*
 * name:      ~CharLinkedList
 * purpose:   frees the data used
 * arguments: none
 * returns:   void
 * effects:   none
 */
CharLinkedList::~CharLinkedList()
{
    deleteAll(front);
}

// Defines an = operator to delete this CharLinkedList's data
// and set it to a deep copy of other
CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other)
{
    deleteAll(front);

    numItems = other.numItems;
    Node *prev = front = new Node {other.front->info, nullptr, nullptr};

    // Loops through the other linked list and make a new node for every char
    // Uses prev to link each node to the following node
    for (Node *curr = other.front->next; curr != nullptr; curr = curr->next)
    {
        Node *temp = new Node {curr->info, prev, nullptr};
        prev->next = temp;
        prev = temp;
    }

    back = prev;

    return *this;
}

/*
 * name:      isEmpty
 * purpose:   returns if the list is empty
 * arguments: none
 * returns:   a bool indicating if the list is empty
 * effects:   none
 */
bool CharLinkedList::isEmpty() const
{
    return numItems == 0;
}

/*
 * name:      clear
 * purpose:   frees the data used
 * arguments: none
 * returns:   void
 * effects:   none
 */
void CharLinkedList::clear()
{
    deleteAll(front);

    numItems = 0;
    front = back = nullptr;
}

/*
 * name:      size
 * purpose:   returns the size of the CharLinkedList
 * arguments: none
 * returns:   the size of the CharLinkedList
 * effects:   none
 */
int CharLinkedList::size() const
{
    return numItems;
}

/*
 * name:      first
 * purpose:   returns the first element of the array list
 * arguments: none
 * returns:   the first element of the array list
 * effects:   throws an std::runtime_error if the list is empty
 */
char CharLinkedList::first() const
{
    if (isEmpty())
    {
        throw runtime_error("cannot get first of empty LinkedList");
    }

    return front->info;
}

/*
 * name:      last
 * purpose:   returns the last element of the array list
 * arguments: none
 * returns:   the last element of the array list
 * effects:   throws an std::runtime_error if the list is empty
 */
char CharLinkedList::last() const
{
    if (isEmpty())
    {
        throw runtime_error("cannot get last of empty LinkedList");
    }

    return back->info;
}

/*
 * name:      elementAt
 * purpose:   returns the element at the given index
 * arguments: index, the index of the element to get
 * returns:   returns the element at the given index
 * effects:   throws an std::range_error if index is out of bounds
 */
char CharLinkedList::elementAt(int index) const
{
    checkBounds(index);
    
    // If the index is at the front or back, go there directly to avoid looping
    if (index == 0) return front->info;
    if (index == numItems - 1) return back->info;

    // Loop until you reach the desired index
    Node *curr = front;
    for (int i = 0; i < index; i++) curr = curr->next;
    return curr->info;
}

/*
 * name:      toString
 * purpose:   returns a readable string of the CharLinkedList
 * arguments: none
 * returns:   a readable string of the CharLinkedList
 * effects:   none
 */
string CharLinkedList::toString() const
{
    string result = "[CharLinkedList of size " +
                          to_string(numItems) + " <<";

    for (Node *curr = front; curr != nullptr; curr = curr->next)
    {
        result += curr->info;
    }

    result += ">>]";
    return result;
}

/*
 * name:      toReverseString
 * purpose:   returns a reverse of the items in the CharLinkedList
 * arguments: none
 * returns:   a reverse of the items in the CharLinkedList
 * effects:   none
 */
string CharLinkedList::toReverseString() const
{
    string result = "[CharLinkedList of size " +
                          to_string(numItems) + " <<";

    for (Node *curr = back; curr != nullptr; curr = curr->prev)
    {
        result += curr->info;
    }

    result += ">>]";
    return result;
}

/*
 * name:      pushAtBack
 * purpose:   inserts the given char at the back of the list
 * arguments: c, the char to add
 * returns:   void
 * effects:   none
 */
void CharLinkedList::pushAtBack(char c)
{
    // If the list is empty, make sure the new node is pointed to by front
    // and back. Otherwise, only change back
    if (isEmpty())
    {
        front = back = new Node {c, nullptr, nullptr};
    }
    else
    {
        back->next = new Node {c, back, nullptr};
        back = back->next;
    }

    numItems++;
}

/*
 * name:      pushAtFront
 * purpose:   inserts the given char at the front of the list
 * arguments: c, the char to add
 * returns:   void
 * effects:   none
 */
void CharLinkedList::pushAtFront(char c)
{
    // If the list is empty, make sure the new node is pointed to by front
    // and back. Otherwise, only change front
    if (isEmpty())
    {
        front = back = new Node {c, nullptr, nullptr};
    }
    else
    {
        front->prev = new Node {c, nullptr, front};
        front = front->prev;
    }

    numItems++;
}

/*
 * name:      insertAt
 * purpose:   inserts the given char at the given index
 * arguments: c, the char to insert, and index, c's destination
 * returns:   void
 * effects:   throws an error if index is outside of the ArrayList's bounds
 */
void CharLinkedList::insertAt(char c, int index)
{
    if (index < 0 or index > numItems)
    {
        throw range_error("index (" + to_string(index) + ") not in range [0.." +
                          to_string(numItems) + "]");
    }

    // If the index is at the front or back, insert there without looping
    if (index == 0)
    {
        pushAtFront(c);
        return;
    }
    if (index == numItems)
    {
        pushAtBack(c);
        return;
    }

    // Lopp to one before the index of insertion
    Node *before = front;
    for (int i = 1; i < index; i++)
    {
        before = before->next;
    }
    
    // Link the new node to the nodes before and after it
    Node *after = before->next;
    before->next = new Node {c, before, after};
    after->prev = before->next;

    numItems++;
}

/*
 * name:      insertInOrder
 * purpose:   inserts the given char in ASCII order in the list
 * arguments: c, the char to insert
 * returns:   void
 * effects:   none
 */
void CharLinkedList::insertInOrder(char c)
{
    // If c is to be inserted at the beginning or end, insert there without
    // looping
    if (isEmpty())
    {
        pushAtFront(c);
        return;
    }
    if (c < front->info)
    {
        pushAtFront(c);
        return;
    }
    if (c > back->info)
    {
        pushAtBack(c);
        return;
    }

    // Loop until there is a node which should be after c
    Node *after = front;
    while (after->info < c)
    {
        after = after->next;
    }

    // Link the new node to the nodes before and after it
    Node *before = after->prev;
    before->next = new Node {c, before, after};
    after->prev = before->next;

    numItems++;
}

/*
 * name:      popFromFront
 * purpose:   removes the first character of the list
 * arguments: none
 * returns:   void
 * effects:   throws an std::runtime_error if the list is empty
 */
void CharLinkedList::popFromFront()
{
    if (isEmpty())
    {
        throw runtime_error("cannot pop from empty LinkedList");
    }

    // If the last item in the list is being deleted, reassign front and back
    // Otherwise, only reassign front
    if (numItems == 1)
    {
        delete front;
        front = back = nullptr;
    }
    else
    {
        front = front->next;
        delete front->prev;
        front->prev = nullptr;
    }

    numItems--;
}

/*
 * name:      popFromBack
 * purpose:   removes the last character of the list
 * arguments: none
 * returns:   void
 * effects:   throws an std::runtime_error if the list is empty
 */
void CharLinkedList::popFromBack()
{
    if (isEmpty())
    {
        throw runtime_error("cannot pop from empty LinkedList");
    }

    // If the last item in the list is being deleted, reassign front and back
    // Otherwise, only reassign back
    if (numItems == 1)
    {
        delete back;
        front = back = nullptr;
    }
    else
    {
        back = back->prev;
        delete back->next;
        back->next = nullptr;
    }

    numItems--;
}

/*
 * name:      removeAt
 * purpose:   removes the char at the given index
 * arguments: index, the index of the char to remove
 * returns:   void
 * effects:   throws an std::range_error if index is out of bounds
 */
void CharLinkedList::removeAt(int index)
{
    checkBounds(index);

    // If the index is at the front or back, pop from there without looping
    if (index == 0)
    {
        popFromFront();
        return;
    }
    if (index == numItems - 1)
    {
        popFromBack();
        return;
    }

    // Loop until reaching node at index
    Node *toRemove = front;
    for (int i = 0; i < index; i++)
    {
        toRemove = toRemove->next;
    }

    // Link the nodes before and after the node to remove
    Node *before = toRemove->prev;
    Node *after = toRemove->next;
    before->next = after;
    after->prev = before;

    delete toRemove;
    numItems--;
}

/*
 * name:      replaceAt
 * purpose:   replaces the char at the given index with the given char
 * arguments: c, the char to insert, and index, the index of the char to replace
 * returns:   void
 * effects:   throws an std::range_error if index is out of bounds
 */
void CharLinkedList::replaceAt(char c, int index)
{
    checkBounds(index);

    // Loop to the node at indez
    Node *toReplace = front;
    for (int i = 0; i < index; i++)
    {
        toReplace = toReplace->next;
    }

    toReplace->info = c;
}

/*
 * name:      concatenate
 * purpose:   adds the given CharLinkedList to this CharLinkedList
 * arguments: other, the CharLinkedList to add
 * returns:   void
 * effects:   none
 */
void CharLinkedList::concatenate(CharLinkedList *other)
{
    Node *curr = other->front;
    int length = other->numItems;

    // If this list is empty, prepare for the loop by creating an initial node
    if (isEmpty() and length != 0)
    {
        front = back = new Node {curr->info, nullptr, nullptr};
        // Move curr forward and deincrement length to make sure no repeat
        // chars are added
        curr = curr->next;
        length--;
    }

    for (int i = 0; i < length; i++)
    {
        back->next = new Node {curr->info, back, nullptr};
        back = back->next;
        curr = curr->next;
    }
    
    numItems += other->numItems;
}

/*
 * name:      checkBounds
 * purpose:   throws an error if index is outside of the CharLinkedList's bounds
 * arguments: index, an int to check
 * returns:   void
 * effects:   throws a range_error if index is out of bounds
 */
void CharLinkedList::checkBounds(int index) const
{
    if (index < 0 or index >= numItems)
    {
        throw range_error("index (" + to_string(index) + ") not in range [0.." +
                          to_string(numItems) + ")");
    }
}

/*
 * name:      deleteAll
 * purpose:   Recursively frees all used memory
 * arguments: n, the current node
 * returns:   void
 * effects:   none
 */
void CharLinkedList::deleteAll(Node *n)
{
    // Base case where n is nullptr and the end of the linked list has been
    // reached
    if (n == nullptr) return;

    // Recursively call deleteAll on the next element in the list
    deleteAll(n->next);

    // Delete n now that everything after it have been deleted
    delete n;
}

/*
 *  CharLinkedList.h
 *  Ryan McClennen
 *  1/31/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  CharLinkedList is a class which represents a list of chars which can be
 *  added to, edited, or removed from. It can start empty, with a sigle char, as
 *  a copy of an array, or as a copy of another CharLinkedList depending on
 *  which constructor is used. Provides methods to add to/remove from the list
 *  in various places, access any element, get basic information about the
 *  linked list, and more.
 *
 */
#ifndef CHAR_ARRAY_LIST_H
#define CHAR_ARRAY_LIST_H

#include <string>

class CharLinkedList {
    public:
        // Constructors
        CharLinkedList();
        CharLinkedList(char c);
        CharLinkedList(char arr[], int size);
        CharLinkedList(const CharLinkedList &other);

        // Destructor
        ~CharLinkedList();

        // Assign operator
        CharLinkedList &operator=(const CharLinkedList &other);

        // Methods
        bool isEmpty() const;
        void clear();
        int size() const; 
        char first() const;
        char last() const;
        char elementAt(int index) const;
        std::string toString() const;
        std::string toReverseString() const;
        void pushAtBack(char c);
        void pushAtFront(char c);
        void insertAt(char c, int index);
        void insertInOrder(char c);
        void popFromFront();
        void popFromBack();
        void removeAt(int index);
        void replaceAt(char c, int index);
        void concatenate(CharLinkedList *other);

    private:
        // Node struct to hold the individual data
        struct Node
        {
            char info;
            Node *prev;
            Node *next;
        };

        // Vaiables for the class' information
        int numItems;
        Node *front;
        Node *back;

        // checkBounds helper function to confirm
        // a given index is within the CharLinkedList
        void checkBounds(int index) const;

        // deleteAll helper function which recursively calls
        // itself to delete every Node
        void deleteAll(Node *n);
};

#endif

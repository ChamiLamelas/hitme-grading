/*
 *  CharLinkedList.cpp
 *  William Cai (bcai01)
 *  2.3.2024
 *
 *  CS 15 HW 2 LinkedLists
 *
 *  The file is an implementation of the CharLinkedList class. 
 *  This is implemented, using a doubly linked list with front and back 
 *  pointers.
 *
 */

#include "CharLinkedList.h"
#include <iostream>

/*
 * name:      CharLinkedList
 * purpose:   initialize an empty CharLinkedList
 * arguments: none
 * returns:   none
 * effects:   set pointers (front & back) to nullptr and numItems to 0
 */
CharLinkedList::CharLinkedList() {
    //set up an empty list
    numItems = 0;
}

/*
 * name:      CharLinkedList
 * purpose:   initialize a CharLinkedList with one character
 * arguments: a char variable
 * returns:   none
 * effects:   set pointers (front & back) to the newly created node and numItems
 *            to 1
 */
CharLinkedList::CharLinkedList(char c) {
    //set up a node
    Node *newNode = new Node;
    newNode->data = c;
    newNode->prev = nullptr;
    newNode->next = nullptr;
    //point both front and back pointers to the only node 
    front = newNode;
    back = newNode;
    numItems++;
}

/*
 * name:      CharLinkedList
 * purpose:   initialize a CharLinkedList with an array of characters
 * arguments: an array of chars, an integer that represents the number of
 *            characters in the array
 * returns:   none
 * effects:   set the front pointer to the first element in the array and the 
 *            back pointer to the last element in the array
 */
CharLinkedList::CharLinkedList(char arr[], int size) {
    for (int i = 0; i < size; i++) {
        pushAtBack(arr[i]);
    }
}

/*
 * name:      CharLinkedList
 * purpose:   A copy constructor for the class that makes a deep copy of a given
 *            instance.
 * arguments: none
 * returns:   none
 * effects:   create a new object in the class
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other) {
    Node *current = other.front;
    while (current != nullptr) {
        this->pushAtBack(current->data);
        current = current -> next;
    }
}

/*
 * name:      ~CharLinkedList
 * purpose:   a destructor deletes all heap-allocated data in the  current list
 * arguments: none
 * returns:   none
 * effects:   delete all memories on the heap
 */
CharLinkedList::~CharLinkedList() {
    //recurse from the front of the list
    deleteNodes(front);
}

/*
 * name:      CharLinkedList &operator=
 * purpose:   An overloaded assignment operator for the class that makes a deep 
 *            copy of a given instance.
 * arguments: none
 * returns:   none
 * effects:   create a new object in the class
 */
CharLinkedList CharLinkedList::operator=(const CharLinkedList &other) {
    if (this == &other) {
        return *this;
    }
    Node *current = other.front;
    while (current != nullptr) {
        this->pushAtBack(current->data);
        current = current -> next;
    }
    return *this;
}

/*
 * name:      deleteNodes
 * purpose:   a recursive function that delete the memories on the heap
 * arguments: none
 * returns:   none
 * effects:   delete all memories on the heap
 */
void CharLinkedList::deleteNodes(Node *node) {
    if (node != nullptr) {
        //recurse to the end of the list
        deleteNodes(node->next);
        //delete nodes on the way back back from recursion
        delete node;
    }
}

/*
 * name:      isEmpty
 * purpose:   It determines whether this specific instance of the class is empty
              (has not character) and false otherwise.
 * arguments: none
 * returns:   a boolean value
 * effects:   none
 */
bool CharLinkedList::isEmpty() const {
    return numItems == 0;
}

/*
 * name:      clear
 * purpose:   It makes the instance into an empty list. For example if you call 
 *            the clear function and then the isEmpty function the isEmpty
 *            function should return true.
 * arguments: none
 * returns:   none
 * effects:   It deletes all memories on the heap and sets front, back pointers
 *            to nullptr. It sets the numItems to 0.
 */
void CharLinkedList::clear() {
    //delete the memories of all elements on the heap
    deleteNodes(front);
    //set front and back pointers to nullptr
    front = nullptr;
    back = nullptr;
    //set the numItems to 0
    numItems = 0;
}

/*
 * name:      size
 * purpose:   return an integer value that is the number of characters in the
 *            list
 * arguments: none
 * returns:   an integer value that is the number of characters in the list
 * effects:   none
 */
int CharLinkedList::size() const {
    return numItems;
}

/*
 * name:      first
 * purpose:   This function returns the first element (char) in the list.
 * arguments: none
 * returns:   a character that is the first in the list
 * effects:   none
 */
char CharLinkedList::first() const {
    if (isEmpty()) {
        throw std::runtime_error("cannot get first of empty LinkedList");
    }
    return front->data;
}

/*
 * name:      back
 * purpose:   This function returns the last element (char) in the list.
 * arguments: none
 * returns:   a character that is the last in the list
 * effects:   none
 */
char CharLinkedList::last() const {
    if (isEmpty()) {
        throw std::runtime_error("cannot get last of empty LinkedList");
    }
    return back->data;
}

/*
 * name:      elementAt
 * purpose:   This function returns the element (char) in the list at this
 *            index. If the index is out of range it should throw a range_error
 *            exception with an error message.
 * returns:   a character that is at the specified location in the list
 * effects:   none
 */
char CharLinkedList::elementAt(int index) const {
    if (index < 0 or index >= numItems) {
        throw std::range_error("index (" + std::to_string(index) 
              + ") not in range [0.." + std::to_string(numItems) + ")");
    }
    return findCharElementAt(front, index);
}

/*
 * name:      findElementAt
 * purpose:   This private recursive function is to find the element at the 
 *            specified location.
 * returns:   a character that is at the given location in the list
 * effects:   none
 */
char CharLinkedList::findCharElementAt(Node *node, int count) const {
    //base case 1: when the function reaches the end of the list
    if (node->next == nullptr) {
        return node->data;
    }
    //base case 2: when the count reaches its maximum 
    if (count == 0) {
        return node->data;
    }
    //recurse case: go to next node and decrease the count by 1
    return findCharElementAt(node->next, --count);
}

/*
 * name:      toString
 * purpose:   It returns a string which contains the characters of the 
 *            LinkedArrayList. 
 * arguments: none
 * returns:   a std::string type
 * effects:   String format: [CharLinkedList of size 5 <<Alice>>]
 *                           [CharLinkedList of size 0 <<>>] 
 */
std::string CharLinkedList::toString() const {
    std::string list = "";
    Node *current = front;
    while(current != nullptr) {
        list += current->data;  //put each character to the string
        current = current->next;    //move to the next node
    }
    std::string result = "[CharLinkedList of size " + std::to_string(numItems) 
                         + " <<" + list + ">>]";
    return result;
}

/*
 * name:      toReverseString
 * purpose:   It returns a tring which contains the characters of the 
 *            CharLinkedList in reverse. 
 * arguments: none
 * returns:   a std::string type
 * effects:   String format: [CharLinkedList of size 5 <<ecilA>>]
 *                           [CharLinkedList of size 0 <<>>] 
 */
std::string CharLinkedList::toReverseString() const {
    std::string list = "";
    Node *current = back;
    while(current != nullptr) {
        list += current->data;  //put each character to the string
        current = current->prev;    //move to the previous node
    }
    std::string result = "[CharLinkedList of size " + std::to_string(numItems) 
                         + " <<" + list + ">>]";
    return result;
}

/*
 * name:      pushAtBack
 * purpose:   It inserts the given new element after the end of the existing
 *            elements of the list
 * arguments: a char
 * returns:   none
 * effects:   modify pointers accordingly; numItems increases by one
 */
void CharLinkedList::pushAtBack(char c) {
    Node *newNode = new Node;
    newNode->data = c;
    newNode->next = nullptr;
    if (front == nullptr) {
        //If the list is empty, make newNodes as the front and the back
        front = newNode;
        back = newNode;
        //make the prev pointer to nullptr
        newNode->prev = nullptr;
    } else {
        back->next = newNode;
        newNode->prev = back;
        back = newNode;
    }
    numItems++;
}

/*
 * name:      pushAtFront
 * purpose:   It inserts the given new element at the start of the existing
 *            elements of the list
 * arguments: a char
 * returns:   none
 * effects:   modify pointers accordingly; numItems increases by one
 */
void CharLinkedList::pushAtFront(char c) {
    Node *newNode = new Node;
    newNode->data = c;
    //In either cases, the prev pointer of the newNode is nullptr.
    newNode->prev = nullptr;
    if (front == nullptr) {
        //If the list is empty, make newNodes as the front and the back
        front = newNode;
        back = newNode;
        //make the prev pointer to nullptr
        newNode->next = nullptr;
    } else {
        newNode->next = front;
        front->prev = newNode;
        front = newNode;
    }
    numItems++;
}

/*
 * name:      insertAt
 * purpose:   It inserts the given new element in the linked list at the
 *            specified index. If the index is out of range it should throw a
 *            range error exception.
 * arguments: an element (char), an integer that represents the index
 * returns:   none
 * effects:   numItems increases by one; modify the order of the linked list
 *            accordingly, which means that adjust some pointers
 */
void CharLinkedList::insertAt(char c, int index) {
    if (index < 0 or index > numItems) {
        throw std::range_error("index (" + std::to_string(index) 
              + ") not in range [0.." + std::to_string(numItems) + "]");
    }
    if (index == 0) {   //insert at the start == pushAtFront()
        pushAtFront(c);
    } else if (index == numItems) { //insert at the end == pushAtBack()
        pushAtBack(c);
    } else {    //insert in the middle
        Node *newNode = new Node;
        newNode->data = c;
        Node *current = front;
        //loop over the list to find the previous node of the node that is
        //inserted in the linked list 
        for (int i = 0; i < index - 1; ++i) {
            current = current->next;
        }
        //set the new node's next pointer to the inserted node
        newNode->next = current->next;
        //set the new node's prev to the current node
        newNode->prev = current;
        //set the inserted node's prev to the new node
        current->next->prev = newNode;
        //set the previous node's next to the new node
        current->next = newNode;
        numItems++;
    }
}

/*
 * name:      insertInOrder
 * purpose:   It inserts the given new element in the linked list in ASCII order
 * arguments: an element (char)
 * returns:   none
 * effects:   numItems increases by one; modify the order of the linked list
 *            accordingly, which means that adjust some pointers
 */
void CharLinkedList::insertInOrder(char c) {
    //The list is empty or the new element should be inserted at front
    if (isEmpty() or c <= front->data) {
        pushAtFront(c);
    } else {
        Node *current = front;
        int count = 0;  //an integer to find the position
        //find the previous position of the right position in the list
        while (current->next != nullptr and current->next->data < c) {
            current = current->next;
            count++;
        }
        count++;    //increment by one to get to the right position
        insertAt(c, count);
    }
}

/*
 * name:      popFromFront
 * purpose:   It removes the first element from the list. If the list is empty,
 *            it should throw a runtime error exception.
 * returns:   none
 * effects:   numItems decreases by one; modify the order of the linked list
 *            accordingly, which means that adjust some pointers
 */
void CharLinkedList::popFromFront() {
    //if the list is empty, throw a runtime error
    if (isEmpty()) {
        throw std::runtime_error("cannot pop from empty LinkedList");
    }
    //hode the node to be deleted
    Node *old_front = front;
    //if there is only one element in the list, set both pointers to nullptr
    if (front == back) {
        front = nullptr;
        back = nullptr;
    } else {
        //normal situation
        front = front->next;    //move front pointer to the next node
        front->prev = nullptr;  //set the new front's prev to nullptr
    }
    //delete the old front node on the heap memory
    delete old_front;
    numItems--;
}

/*
 * name:      popFromBack
 * purpose:   It removes the last element from the list. If the list is empty,
 *            it should throw a runtime error exception.
 * returns:   none
 * effects:   numItems decreases by one; modify the order of the linked list
 *            accordingly, which means that adjust some pointers
 */
void CharLinkedList::popFromBack() {
    //if the list is empty, throw a runtime error
    if (isEmpty()) {
        throw std::runtime_error("cannot pop from empty LinkedList");
    }
    Node *old_back = back;
    //if there is only one element in the list, set both pointers to nullptr
    if (front == back) {
        front = nullptr;
        back = nullptr;
    } else {
        //normal situation
        back = back->prev;    //move front pointer to the prev node
        back->next = nullptr;  //set the new back's prev to nullptr
    }
    //delete the old front node on the heap memory
    delete old_back;
    numItems--;
}

/*
 * name:      removeAt
 * purpose:   It removes the element at the specified index. If the index is out
 *            range it should throw a std::range_error exception.
 * arguments: none
 * returns:   none
 * effects:   numItems decreases by one; elements may need to shift one position
 */
void CharLinkedList::removeAt(int index) {
    if (index < 0 or index >= numItems) {
        throw std::range_error("index (" + std::to_string(index) 
              + ") not in range [0.." + std::to_string(numItems) + ")");
    }
    if (index == 0) {
        popFromFront();
        return;
    } else if (index == numItems - 1) {
        popFromBack();
        return;
    }
    //find the node to remove
    Node *current = front;
    //loop over the list to find the right position
    for (int i = 0; i < index; ++i) {
        current = current->next;
    }
    //adjust the pointers to remove the node
    Node *toRemove = current;
    toRemove->prev->next = toRemove->next;
    toRemove->next->prev = toRemove->prev;
    delete toRemove;    //delete the memory on the heap
    numItems--;
}

/*
 * name:      replaceAt
 * purpose:   It replace the element at the specified index with a provided 
 *            element. If the index is out range it should throw a 
 *            std::range_error exception.
 * arguments: none
 * returns:   none
 * effects:   change the character in the specified node with the provided one
 */
void CharLinkedList::replaceAt(char c, int index) {
    if (index < 0 or index >= numItems) {
        throw std::range_error("index (" + std::to_string(index) 
              + ") not in range [0.." + std::to_string(numItems) + ")");
    }
    replaceAtRecursive(front, c, index);
}

/*
 * name:      replaceAtRecursive
 * purpose:   It replaces the character at the specified position to the
 *            provided character
 * arguments: a Node pointer, a character, an integer
 * returns:   none
 * effects:   change the data (character) of the node
 */
void CharLinkedList::replaceAtRecursive(Node *node, char c, int index) {
    //base case 1: node is nullptr
    if (node == nullptr) {
        return;
    }
    //base case 2: the end of the recursive function
    if (index == 0) {
        node->data = c;
        return;
    }
    replaceAtRecursive(node->next, c, index - 1);
}

/*
 * name:      concatenate
 * purpose:   It adds a copy of the linked list pointed to by the parameter 
 *            value to the end of the array list the function was called from.
 * arguments: a pointer to a second CharLinkedList.
 * returns:   none
 * effects:   add a copy of the second CharLinkedList to the end of the first 
 *            one
 */
void CharLinkedList::concatenate(CharLinkedList *other) {
    //if the list is empty
    if (not other or other->numItems == 0) {
        return;
    }
    if (this == other) {
        CharLinkedList tempList(*other);
        Node *current = tempList.front;
        while (current != nullptr) {
            this->pushAtBack(current->data);
            current = current->next;
        }
        return;
    }
    Node *current = other->front;
    while (current != nullptr) {
        this->pushAtBack(current->data);
        current = current->next;
    }
}
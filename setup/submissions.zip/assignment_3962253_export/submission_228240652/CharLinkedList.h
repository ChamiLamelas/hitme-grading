/*
 *  CharLinkedList.h
 *  William Cai(bcai01)
 *  2.3.2024
 *
 *  CS 15 HW 2 LinkedLists
 *
 *  Purpose: CharLinkedList is a class that represents a linked list of
 *           characters(i.e. 'a'). The list is a doubly linked list. Every new
 *           CharLinkedList begins empty, and cilents can add and remove
 *           elements from the list. 
 *           The file is a class definition of the CharLinkedList interface.
 *
 */

#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H

#include <string>

class CharLinkedList {
    public:
        CharLinkedList();
        CharLinkedList(char c);
        CharLinkedList(char arr[], int size);
        CharLinkedList(const CharLinkedList &other);
        ~CharLinkedList();
        CharLinkedList operator=(const CharLinkedList &other);

        bool isEmpty() const;
        void clear();
        int size() const;
        char first() const;
        char last() const;
        char elementAt(int index) const;
        std::string toString() const;
        std::string toReverseString() const;
        void pushAtBack(char c);
        void pushAtFront(char c);
        void insertAt(char c, int index);
        void insertInOrder(char c);
        void popFromFront();
        void popFromBack();
        void removeAt(int index);
        void replaceAt(char c, int index);
        void concatenate(CharLinkedList *other);
    
    private:
        struct Node {
            char data;
            Node *prev;
            Node *next;
        };

        Node *front = nullptr;
        Node *back = nullptr;
        int numItems = 0;
        
        //a recursive function that delete nodes on the heap
        void deleteNodes(Node *node);
        //a recursive function that finds the element at the specified position
        char findCharElementAt(Node *node, int count) const;
        //a recursive function that replaces the element at the specified
        //position
        void replaceAtRecursive(Node *node, char c, int index);
};

#endif

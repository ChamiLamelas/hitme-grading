/*
 *  unit_tests.h
 *  William Cai
 *  2.3.2024
 *
 *  CS 15 HW 2 LinkedLists
 *
 *  A testing file for the Linked List class that uses the unit_test framework
 *
 */

#include "CharLinkedList.h"
#include <cassert>
#include <iostream>

/*
 * dummy_test
 * Make sure no errors at linking documents (#include)
 */
void dummy_test() {
    return;
}

/*
 * cll_constructor_test0
 * Make sure no fatal errors/memory leaks in the default constructor
 */
void cll_constructor_test0() {
    CharLinkedList test_list;
}

/*
 * cll_constructor_test1
 * Make sure no fatal errors/memory leaks in the default constructor
 */
void cll_constructor_test1() {
    CharLinkedList test_list('a');
    assert(test_list.size() == 1);
}

/*
 * cll_constructor_test2
 * Make sure no fatal errors/memory leaks in the default constructor
 */
void cll_constructor_test2() {
    char array[] = {'h','e','l','l','o'};
    CharLinkedList test_list(array, 5);
    assert(test_list.size() == 5);
    assert(test_list.first() == 'h');
    assert(test_list.last() == 'o');
}

/*
 * cll_constructor_test3
 * Make sure no fatal errors/memory leaks in the copy constructor
 */
void cll_constructor_test3() {
    char array[] = {'h','e','l','l','o'};
    CharLinkedList list1(array, 5);
    CharLinkedList list2(list1);
    assert(list2.size() == 5);
    assert(list2.toString() == "[CharLinkedList of size 5 <<hello>>]");
}

/*
 * cll_constructor_test4
 * Make sure no fatal errors/memory leaks in the overloaded assignment operator
 */
void cll_constructor_test4() {
    char array[] = {'h','e','l','l','o'};
    CharLinkedList list1(array, 5);
    CharLinkedList list2 = list1;
    assert(list2.size() == 5);
    assert(list2.toString() == "[CharLinkedList of size 5 <<hello>>]");
}

/*
 * isEmpty_test_0
 * Test if isEmpty can return correct boolean based on the linkedlist
 */
void isEmpty_test_0() {
    CharLinkedList test_list;
    assert(test_list.isEmpty());
}

/*
 * isEmpty_test_1
 * Test if isEmpty can return correct boolean based on the linkedlist
 */
void isEmpty_test_1() {
    CharLinkedList test_list('a');
    assert(not test_list.isEmpty());
}

/*
 * size_test_0
 * Test if size can return the correct number of characters in the list or not
 * In this case, I test it on an empty list, which should 0 character.
 */
void size_test_0() {
    CharLinkedList test_list;
    assert(test_list.size() == 0);
}

/*
 * size_test_1
 * Test if size can return the correct number of characters in the list or not
 * In this case, I test it on a list of one character, which should 1 character.
 */
void size_test_1() {
    CharLinkedList test_list('a');
    assert(test_list.size() == 1);
}

/*
 * size_test_2
 * Test if size can return the correct number of characters in the list or not
 * In this case, I test it on a list of 5 characters.
 */
void size_test_2() {
    char array[] = {'h','e','l','l','o'};
    CharLinkedList test_list(array, 5);
    assert(test_list.size() == 5);
}

/*
 * clear_test_0
 * Test if clear function can make the instance into an empty list or not.
 * In this case, the list is already empty. Make sure there is error for
 * clearing an empty list.
 */
void clear_test_0() {
    CharLinkedList test_list;
    test_list.clear();
    assert(test_list.isEmpty());
}

/*
 * clear_test_1
 * Test if clear function can make the instance into an empty list or not.
 * In this case, the list has one character. Test if the clear function can
 * clear the list.
 */
void clear_test_1() {
    CharLinkedList test_list('a');
    test_list.clear();
    assert(test_list.isEmpty());
}

/*
 * clear_test_2
 * Test if clear function can make the instance into an empty list or not.
 * In this case, the list has some characters. Test if the clear function can
 * clear the list.
 */
void clear_test_2() {
    char array[] = {'h','e','l','l','o'};
    CharLinkedList test_list(array, 5);
    test_list.clear();
    assert(test_list.isEmpty());
}

/*
 * first_test_correct_0
 * Test if first function can return the first element in the list.
 * In this case, I only have 'a' in the list, so the first should return 'a'.
 */
void first_test_correct_0() {
    CharLinkedList test_list('a');
    assert(test_list.first() == 'a');
}

/*
 * first_test_correct_1
 * Test if first function can return the first element in the list.
 * In this case, I have a list of characters. The first char should be 'h'.
 */
void first_test_correct_1() {
    char array[] = {'h','e','l','l','o'};
    CharLinkedList test_list(array, 5);
    assert(test_list.first() == 'h');
}

/*
 * first_test_incorrect
 * Test if first function can report runtime error if the list is empty.
 * I will use 'try' and 'catch' the error message.
 */
void first_test_incorrect() {
    bool runtime_error_thrown = false;
    std::string error_message = "";

    CharLinkedList test_list;
    try {
        test_list.first();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot get first of empty LinkedList");
}

/*
 * last_test_correct_0
 * Test if last function can return the last element in the list.
 * In this case, I only have 'a' in the list, so the last should return 'a'.
 */
void last_test_correct_0() {
    CharLinkedList test_list('a');
    assert(test_list.last() == 'a');
}

/*
 * last_test_correct_1
 * Test if last function can return the last element in the list.
 * In this case, I have a list of characters. The last char should be 'h'.
 */
void last_test_correct_1() {
    char array[] = {'h','e','l','l','o'};
    CharLinkedList test_list(array, 5);
    assert(test_list.last() == 'o');
}

/*
 * last_test_incorrect
 * Test if last function can report runtime error if the list is empty.
 * I will use 'try' and 'catch' the error message.
 */
void last_test_incorrect() {
    bool runtime_error_thrown = false;
    std::string error_message = "";

    CharLinkedList test_list;
    try {
        test_list.last();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot get last of empty LinkedList");
}


/*
 * elementAt_test_correct_0
 * Test if elementAt function can correctly return the character at the given
 * index. For this one, there is only one character in the list.
 */
void elementAt_test_correct_0() {
    CharLinkedList test_list('a');
    assert(test_list.elementAt(0) == 'a');
}

/*
 * elementAt_test_correct_1
 * Test if elementAt function can correctly return the character at the given
 * index. Here is a list of characters, I will check each element with its 
 * right character.
 */
void elementAt_test_correct_1() {
    char array[] = {'h','e','l','l','o'};
    CharLinkedList test_list(array, 5);
    assert(test_list.elementAt(0) == 'h');
    assert(test_list.elementAt(1) == 'e');
    assert(test_list.elementAt(2) == 'l');
    assert(test_list.elementAt(3) == 'l');
    assert(test_list.elementAt(4) == 'o');
}

/*
 * elementAt_test_correct_2
 * Test if elementAt function can correctly return the character at the given
 * index. I pushAtBack a series of characters at the back of the list and check
 * if the newly created elements have their right characters or not.
 */
void elementAt_test_correct_2() {
    char array[] = {'h','e','l','l','o'};
    CharLinkedList test_list(array, 5);
    test_list.pushAtBack('w');
    test_list.pushAtBack('o');
    test_list.pushAtBack('r');
    test_list.pushAtBack('l');
    test_list.pushAtBack('d');
    assert(test_list.elementAt(5) == 'w');
    assert(test_list.elementAt(6) == 'o');
    assert(test_list.elementAt(7) == 'r');
    assert(test_list.elementAt(8) == 'l');
    assert(test_list.elementAt(9) == 'd');
}

/*
 * elementAt_test_incorrect_0
 * Test if elemenAt can throw a range error meesage when the provided index is
 * out of the range. In this case, the empty list should throw an error message
 * when we request a character at a given position.
 */
void elementAt_test_incorrect_0() {
    bool runtime_error_thrown = false;
    std::string error_message = "";

    CharLinkedList test_list;
    try {
        test_list.elementAt(0);
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "index (0) not in range [0..0)");
}

/*
 * elementAt_test_incorrect_1
 * Test if elemenAt can throw a range error meesage when the provided index is
 * out of the range. In this case, the index 42 is not in a list of only 5
 * characters.
 */
void elementAt_test_incorrect_1() {
    bool runtime_error_thrown = false;
    std::string error_message = "";

    char array[] = {'h','e','l','l','o'};
    CharLinkedList test_list(array, 5);
    try {
        test_list.elementAt(42);
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "index (42) not in range [0..5)");
}

/*
 * toString_test_empty
 * Test to check if toString can convert an list of characters into a string. 
 * It returns a string which contains the characters of the CharLinkedList.
 * This test should return a string.
 */
void toString_test_empty() {
    CharLinkedList test_list;
    assert(test_list.toString() == "[CharLinkedList of size 0 <<>>]");
}

/*
 * toString_test_non_empty
 * Test to check if toString can convert an list of characters into a string. 
 * It returns a string which contains the characters of the CharLinkedList.
 * This test should return a string.
 */
void toString_test_non_empty() {
    char array[] = {'h','e','l','l','o'};
    CharLinkedList test_list(array, 5);
    assert(test_list.toString() == "[CharLinkedList of size 5 <<hello>>]");
}

/*
 * toReverseString_test_non_empty
 * Test to check if toString can convert an list of characters into a string. 
 * It returns a string which contains the characters of the CharLinkedList.
 * This test should return a string.
 */
void toReverseString_test_non_empty() {
    char array[] = {'h','e','l','l','o'};
    CharLinkedList test_list(array, 5);
    assert(test_list.toReverseString() 
        == "[CharLinkedList of size 5 <<olleh>>]");
}

/*
 * toReverseString_test_empty
 * Test to check if toString can convert an list of characters into a string. 
 * It returns a string which contains the characters of the CharLinkedList.
 * This test should return a string.
 */
void toReverseString_test_empty() {
    CharLinkedList test_list;
    assert(test_list.toReverseString() == "[CharLinkedList of size 0 <<>>]");
}

/*
 * pushAtBack_test_0
 * Test if pushAtBack can insert character elements at back of the list or not
 */
void pushAtBack_test_0() {
    CharLinkedList test_list;
    test_list.pushAtBack('a');
    test_list.pushAtBack('b');
    test_list.pushAtBack('c');
    assert(test_list.size() == 3);
    assert(test_list.first() == 'a');
    assert(test_list.last() == 'c');
}

/*
 * pushAtBack_test_1
 * Test if pushAtBack can insert character elements at back of the list or not
 * In this case, I already have a list of characters. I pushAtBack of this list.
 */
void pushAtBack_test_1() {
    char array[] = {'h','e','l','l','o'};
    CharLinkedList test_list(array, 5);
    test_list.pushAtBack('w');
    test_list.pushAtBack('o');
    test_list.pushAtBack('r');
    test_list.pushAtBack('l');
    test_list.pushAtBack('d');
    assert(test_list.size() == 10);
    assert(test_list.first() == 'h');
    assert(test_list.last() == 'd');
}

/*
 * pushAtFront_test_0
 * Test if pushAtFront can insert character elements at start of the list
 */
void pushAtFront_test_0() {
    CharLinkedList test_list;
    test_list.pushAtFront('c');
    test_list.pushAtFront('b');
    test_list.pushAtFront('a');
    assert(test_list.size() == 3);
    assert(test_list.first() == 'a');
    assert(test_list.last() == 'c');
}

/*
 * pushAtFront_test_1
 * Test if pushAtFront can insert character elements at start of the list or 
 * not. In this case, I pushAtFront a series of characters in an existing list.
 */
void pushAtFront_test_1() {
    char array[] = {'h','e','l','l','o'};
    CharLinkedList test_list(array, 5);
    test_list.pushAtFront('w');
    test_list.pushAtFront('o');
    test_list.pushAtFront('r');
    test_list.pushAtFront('l');
    test_list.pushAtFront('d');
    assert(test_list.size() == 10);
    assert(test_list.first() == 'd');
    assert(test_list.last() == 'o');
}

/*
 * insertAt_empty_correct
 * Test correct insertion into an empty linkedlist.
 * Afterwards, the size should be 1 and element at index 0 should be the
 * element I inserted.
 */
void insertAt_empty_correct() {
    CharLinkedList test_list;
    test_list.insertAt('a', 0);
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');
}

/*
 * insertAt_empty_incorrect
 * Tests incorrect insertion into an empty LinkedList.
 * Attempts to call insertAt for index larger than 0. This should result in an
 * std::range_error being raised.
 */
void insertAt_empty_incorrect() {
    bool range_error_thrown = false;
    std::string error_message = "";

    CharLinkedList test_list;
    try {
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0]");
}

/*
 * insertAt_front_singleton_list
 * Tests correct insertAt for front of 1-element list.
 * Afterwards, the size should be 2 and element at index 0 and 1 are 'b' and 'a'
 */
void insertAt_front_singleton_list() {
    CharLinkedList test_list('a');
    test_list.insertAt('b', 0);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'a');
}

/*
 * insertAt_many_elements
 * Tests calling insertAt for a large number of elements.
 * Not only does this test insertAt, it also checks that array expansion works 
 * correctly.
 */
void insertAt_many_elements() {
    CharLinkedList test_list;
    for (int i = 0; i < 1000; i++) {
        test_list.insertAt('a', i);
    }

    assert(test_list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
}

/*
 * insertAt_front_large_list
 * Tests insertion into front of a larger list
 */
void insertAt_front_large_list() {
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    test_list.insertAt('y', 0);

    assert(test_list.size() == 10);
    assert(test_list.elementAt(0) == 'y');
    assert(test_list.toString() == 
        "[CharLinkedList of size 10 <<yabczdefgh>>]");
}

/*
 * insertAt_back_large_list
 * Tests insertion into the back of a larger list
 */
void insertAt_back_large_list() {
    char test_arr[10] = { 'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 10);  

    test_list.insertAt('x', 10);

    assert(test_list.size() == 11);
    assert(test_list.elementAt(10) == 'x');
    assert(test_list.toString() == 
    "[CharLinkedList of size 11 <<yabczdefghx>>]"); 

}

/*
 * insertAt_middle_large_list
 * Tests insertion into the middle of a larger list
 */
void insertAt_middle_large_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.insertAt('z', 3);

    assert(test_list.size() == 9);
    assert(test_list.elementAt(3) == 'z');
    assert(test_list.toString() == "[CharLinkedList of size 9 <<abczdefgh>>]");
}

/*
 * insertAt_nonempty_incorrect
 * Tests out-of-range insertion for a non-empty list.
 */
void insertAt_nonempty_incorrect() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    bool range_error_thrown = false;
    std::string error_message = "";

    try {
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8]");
}

/*
 * insertInOrder_test_empty
 * Test to check if insertInOrder can insert an element in the linked list of
 * characters based on the ASCII order.
 * I insert the character 'a', which should be the only element in the linked
 * list.
 */
void insertInOrder_test_empty() {
    CharLinkedList test_list;
    test_list.insertInOrder('a');
    assert(test_list.elementAt(0) == 'a');
}

/*
 * insertInOrder_test_last
 * Test to check if insertInOrder can insert an element in the linked list of
 * characters based on the ASCII order.
 * I insert the character 'b', which should be the last element in the linked
 * list.
 */
void insertInOrder_test_last() {
    CharLinkedList test_list;
    test_list.insertInOrder('a');
    test_list.insertInOrder('b');
    assert(test_list.last() == 'b');
}

/*
 * insertInOrder_test_beginning
 * Test to check if insertInOrder can insert an element in the linked list of
 * characters based on the ASCII order.
 * I insert the character 'a', which should be at the beginning alphabet in a 
 * linked list of characters. 
 */
void insertInOrder_test_beginning() {
    CharLinkedList test_list;
    test_list.insertInOrder('b');
    test_list.insertInOrder('c');
    test_list.insertInOrder('a');
    assert(test_list.elementAt(0) == 'a');
}

/*
 * insertInOrder_test_capital
 * Test to check if insertInOrder can insert an element in the linked list of
 * characters based on the ASCII order.
 * I insert the character 'A', which should be at the beginning alphabet in an 
 * linked list of characters. 
 */
void insertInOrder_test_capital() {
    CharLinkedList test_list;
    test_list.insertInOrder('B');
    test_list.insertInOrder('C');
    test_list.insertInOrder('A');
    assert(test_list.elementAt(0) == 'A');
}

/*
 * insertInOrder_test_middle
 * Test to check if insertInOrder can insert an element in the linked list of
 * characters based on the ASCII order.
 * I insert the character 'c', which should be at the middle position in a 
 * linked list of characters. 
 */
void insertInOrder_test_middle() {
    CharLinkedList test_list;
    test_list.insertInOrder('a');
    test_list.insertInOrder('b');
    test_list.insertInOrder('d');
    test_list.insertInOrder('f');
    test_list.insertInOrder('c');
    assert(test_list.elementAt(2) == 'c');
}

/*
 * insertInOrder_test_end
 * Test to check if insertInOrder can insert an element in the linked list of
 * characters based on the ASCII order.
 * I insert the character 'f', which should be at the end position in a 
 * linked list of characters. 
 */
void insertInOrder_test_end() {
    CharLinkedList test_list;
    test_list.insertInOrder('a');
    test_list.insertInOrder('b');
    test_list.insertInOrder('c');
    test_list.insertInOrder('d');
    test_list.insertInOrder('f');
    assert(test_list.elementAt(4) == 'f');
}

/*
 * insertInOrder_test_double
 * Test to check if insertInOrder can insert an duplicated element in the  
 * linked list of characters based on the ASCII order.
 * I insert the character 'c' twice. The end of the linked list should be 'c'.
 */
void insertInOrder_test_double() {
    CharLinkedList test_list;
    test_list.insertInOrder('c');
    test_list.insertInOrder('c');
    test_list.insertInOrder('a');
    test_list.insertInOrder('b');
    assert(test_list.last() == 'c');
}

/*
 * insertInOrder_test_list
 * Test to check if insertInOrder can insert an duplicated element in the  
 * linked list of characters based on the ASCII order.
 * I insert the character 'c' twice. The end of the linked list should be 'c'.
 */
void insertInOrder_test_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.insertInOrder('z');
    assert(test_list.size() == 9);
    assert(test_list.elementAt(8) == 'z');
    assert(test_list.toString() == "[CharLinkedList of size 9 <<abcdefghz>>]");
}

/*
 * popFromFront_test_correct_0
 * Test to check if popFromFront can remove the first element from the linked
 * list.
 * It should remove the first element and push the second element to the
 * position of the first one.
 */
void popFromFront_test_correct_0() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);
    test_list.popFromFront();
    assert(test_list.first() == 'b');
    assert(test_list.size() == 7);
    assert(test_list.toString() == "[CharLinkedList of size 7 <<bcdefgh>>]");
}

/*
 * popFromFront_test_correct_1
 * Test to check if popFromFront can remove the first element from the linked
 * list.
 * It should remove the first element and push the second element to the
 * position of the first one.
 */
void popFromFront_test_correct_1() {
    char array[] = {'h','e','l','l','o'};
    CharLinkedList test_list(array, 5);
    test_list.popFromFront();
    assert(test_list.elementAt(0) == 'e');
    assert(test_list.elementAt(1) == 'l');
    assert(test_list.elementAt(2) == 'l');
    assert(test_list.elementAt(3) == 'o');
    assert(test_list.size() == 4);
    assert(test_list.toString() == "[CharLinkedList of size 4 <<ello>>]");
}

/*
 * popFromFront_test_incorrect_0
 * Test to check if popFromFront can throw an runtim_error message.
 * popFromFront should throw an error message when there is nothing to pop.
 */
void popFromFront_test_incorrect_0() {
    bool runtime_error_thrown = false;
    std::string error_message = "";

    CharLinkedList test_list;

    try {
        test_list.popFromFront();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

/*
 * popFromFront_test_incorrect_1
 * Test to check if popFromFront can throw an runtim_error message.
 * In this case, although I have an initial array of one character, 'a', when I
 * pop from front twice, the array list should have nothing to pop and throw an 
 * error message.
 */
void popFromFront_test_incorrect_1() {
    bool runtime_error_thrown = false;
    std::string error_message = "";

    CharLinkedList test_list('a');

    try {
        test_list.popFromFront();
        test_list.popFromFront();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

/*
 * popFromBack_test_correct_0
 * Test to check if popFromBack can remove the last element from the linked
 * list.
 * It should remove the last element and push the second to the last element to
 * the position of the last one.
 */
void popFromBack_test_correct_0() {
    char array[] = {'h','e','l','l','o'};
    CharLinkedList test_list(array, 5);
    test_list.popFromBack();
    assert(test_list.last() == 'l');
    assert(test_list.size() == 4);
    assert(test_list.toString() == "[CharLinkedList of size 4 <<hell>>]");
}

/*
 * popFromBack_test_correct_1
 * Test to check if popFromBack can remove the last element from the linked
 * list.
 * It should remove the last element and push the second element to the
 * position of the first one.
 */
void popFromBack_test_correct_1() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);
    test_list.popFromBack();
    assert(test_list.first() == 'a');
    assert(test_list.size() == 7);
    assert(test_list.toString() == "[CharLinkedList of size 7 <<abcdefg>>]");
}

/*
 * popFromBack_test_incorrect_0
 * Test to check if popFromBack can throw an runtim_error message.
 * popFromBack should throw an error message when there is nothing to pop.
 */
void popFromBack_test_incorrect_0() {
    bool runtime_error_thrown = false;
    std::string error_message = "";

    CharLinkedList test_list;

    try {
        test_list.popFromBack();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

/*
 * removeAt_test_correct_start
 * Test to check if removeAt can remove the element at the specified index.
 * In this case, I will remove the element at the start of the linked list.
 */
void removeAt_test_correct_start() {
    char array[] = {'h','e','l','l','o'};
    CharLinkedList test_list(array, 5);
    test_list.removeAt(0);
    assert(test_list.size() == 4);
    assert(test_list.elementAt(0) == 'e');
    assert(test_list.toString() == "[CharLinkedList of size 4 <<ello>>]");
}

/*
 * removeAt_test_correct_middle
 * Test to check if removeAt can remove the element at the specified index.
 * In this case, I will remove the element in the middle of the linked list.
 */
void removeAt_test_correct_middle() {
    char array[] = {'h','e','l','l','o'};
    CharLinkedList test_list(array, 5);
    test_list.removeAt(2);
    assert(test_list.size() == 4);
    assert(test_list.elementAt(2) == 'l');
    assert(test_list.toString() == "[CharLinkedList of size 4 <<helo>>]");
}

/*
 * removeAt_test_correct_end
 * Test to check if removeAt can remove the element at the specified index.
 * In this case, I will remove the element at the end of the linked list.
 */
void removeAt_test_correct_end() {
    char array[] = {'h','e','l','l','o'};
    CharLinkedList test_list(array, 5);
    test_list.removeAt(4);
    assert(test_list.size() == 4);
    assert(test_list.elementAt(3) == 'l');
    assert(test_list.toString() == "[CharLinkedList of size 4 <<hell>>]");
}

/*
 * removeAt_back_large_list
 * Test to check if removeAt will report range error if the provided index is
 * out of the range of the array list.
 * In this test, I will test it on an large linked list of characters.
 */
 void removeAt_back_large_list() {
    char test_arr[10] = { 'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 10);  

    test_list.removeAt(9);

    assert(test_list.size() == 9);
    assert(test_list.elementAt(8) == 'g');
    assert(test_list.toString() == 
    "[CharLinkedList of size 9 <<yabczdefg>>]"); 
}

/*
 * insertAt_middle_large_list
 * Test to check if removeAt will report range error if the provided index is
 * out of the range of the array list.
 * In this test, I will test it on an large linked list of characters.
 */
 void removeAt_middle_large_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.removeAt(3);

    assert(test_list.size() == 7);
    assert(test_list.elementAt(3) == 'e');
    assert(test_list.toString() == "[CharLinkedList of size 7 <<abcefgh>>]");
}

/*
 * removeAt_test_correct_empty
 * Test to check if removeAt will report range error if the provided index is
 * out of the range of the array list.
 * In this test, I will test it on an empty linked list.
 */
void removeAt_test_incorrect_empty() {
    bool range_error_thrown = false;
    std::string error_message = "";

    CharLinkedList test_list;
    try {
        test_list.removeAt(42);
    }
    catch (const std::range_error &e) {
        // if removeAt is correctly implemented, a range_error will be thrown.
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0)");
}

/*
 * removeAt_test_correct_list
 * Test to check if removeAt will report range error if the provided index is
 * out of the range of the array list.
 * In this test, I will test it on an linked list of characters.
 */
void removeAt_test_incorrect_list() {
    bool range_error_thrown = false;
    std::string error_message = "";

    char array[] = {'h','e','l','l','o'};
    CharLinkedList test_list(array, 5);
    try {
        test_list.removeAt(42);
    }
    catch (const std::range_error &e) {
        // if removeAt is correctly implemented, a range_error will be thrown.
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..5)");
}

/*
 * replaceAt_empty_correct_0
 * Test to check if replaceAt can successfully replace a specified element in 
 * the array list with the provided character.
 * In this test, I will test it on a linked list of one character.
 */
void replaceAt_empty_correct_0() {
    // initialize 1-element list
    CharLinkedList test_list('a');

    // replace the element
    test_list.replaceAt('b', 0);

    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'b');
}

/*
 * replaceAt_empty_correct_1
 * Test to check if replaceAt can successfully replace a specified element in 
 * the array list with the provided character.
 * In this test, I will test it on a linked list of many characters.
 */
void replaceAt_empty_correct_1() {
    // initialize 1-element list
    char array[] = {'h','e','l','l','o'};
    CharLinkedList test_list(array, 5);

    // replace the element
    test_list.replaceAt('c', 2);

    assert(test_list.size() == 5);
    assert(test_list.elementAt(2) == 'c');
    assert(test_list.toString() == "[CharLinkedList of size 5 <<heclo>>]");
}

/*
 * replaceAt_many_elements
 * Test to check if replaceAt can successfully replace many specified elements  
 * in the array list with the provided character.
 * In this test, I will test it on an linked list of characters.
 */
void replaceAt_many_elements() {
    CharLinkedList test_list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.insertAt('a', i);
    }

    for (int i = 0; i < 1000; i++) {
        // replace each element in the array to 'b'
        test_list.replaceAt('b', i);
    }

    assert(test_list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'b');
    }
}

/*
 * replaceAt_empty_incorrect
 * Test to check if replaceAt will report range error if the provided index is
 * out of the range of the array list.
 * In this test, I will test it on an empty linked list of characters.
 */
void replaceAt_empty_incorrect() {
    bool range_error_thrown = false;
    std::string error_message = "";

    CharLinkedList test_list;

    try {
        test_list.replaceAt('a', 0);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (0) not in range [0..0)");
}

/*
 * replaceAt_nonempty_incorrect
 * Test to check if replaceAt will report range error if the provided index is
 * out of the range of the array list.
 * In this test, I will test it on a non linked list of characters.
 */
 void replaceAt_nonempty_incorrect() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);
    
    bool range_error_thrown = false;
    std::string error_message = "";

    try {
        test_list.replaceAt('a', 42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8)");
}

/*
 * concatenate_test_copy_other
 * Test to check if concatenate will copy another char linked list to the end 
 * of the linked list that the function was called from.
 */
void concatenate_test_copy_other() {
    char array1[] = {'h','e','l','l','o'};
    CharLinkedList test_list1(array1, 5);
    char array2[] = {'w','o','r','l','d'};
    CharLinkedList test_list2(array2, 5);

    test_list1.concatenate(&test_list2);
    assert(test_list1.size() == 10);
    assert(test_list1.toString() 
        == "[CharLinkedList of size 10 <<helloworld>>]");
}

/*
 * concatenate_test_copy_itself
 * Test to check if concatenate will copy the char linked list itself to the 
 * end of the linked list itself.
 */
void concatenate_test_copy_itself() {
    char array1[] = {'h','e','l','l','o'};
    CharLinkedList test_list1(array1, 5);


    test_list1.concatenate(&test_list1);
    assert(test_list1.size() == 10);
    assert(test_list1.toString() 
        == "[CharLinkedList of size 10 <<hellohello>>]");
}

/*
 * concatenate_test_copy_empty
 * Test to check if concatenate will copy an empty of linked list to the end of
 * the linked list that the function was called from.
 */
void concatenate_test_copy_empty() {
    char array1[] = {'h','e','l','l','o'};
    CharLinkedList test_list1(array1, 5);
    CharLinkedList test_list2;


    test_list1.concatenate(&test_list2);
    assert(test_list1.size() == 5);
    assert(test_list1.toString() == "[CharLinkedList of size 5 <<hello>>]");
}
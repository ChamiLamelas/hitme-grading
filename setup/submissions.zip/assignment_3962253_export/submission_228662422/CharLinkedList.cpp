/*
 *  CharLinkedList.cpp
 *  Will Chesney
 *  2/5/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Purpose: This file contains an implementation of the LinkedList class.
 *
 */

#include "CharLinkedList.h"
#include <sstream>

using namespace std;


//CharLinkedList
//Purpose: Constructor of an empty charLinkedList.
//Return Value: A new instance of the CharLinkedList class with size 0, 
//capacity 0, and an empty Linked List. 
CharLinkedList::CharLinkedList(){

    front = nullptr;
    back = nullptr;
    numNodes = 0;

}

//CharLinkedList(char c)
//Purpose: Constructor of a charLinkedList with one element.
//Parameters: A char that determines what char is in the CharLinkedList
//Return Value: A new instance of the CharLinkedList class with numNodes 1,
//and a front and back pointer pointing to the one node in the list.
CharLinkedList::CharLinkedList(char c){

    Node *pNode = new Node;
    pNode->c = c;
    pNode->next = nullptr;
    front = pNode;
    back = pNode;
    numNodes = 1;

}

//charLinkedList(char c)
//purpose: constructor of a charLinkedList with multiple elements.
//Parameters: An array of chars that represents the chars to be 
//added to the linked list, and an int representing the number of chars to be
//added to the linked list.
CharLinkedList::CharLinkedList(char arr[], int size){

    if (size == 0) {
        front = back = nullptr;
        numNodes = 0;
        return;
    }
    Node* curr = nullptr;
    for (int i = 0; i < size; i++) {
        //make first node in list
        if (i == 0) {
            curr = new Node;
            curr->c = arr[0];
            curr->next = nullptr;
            curr->last = nullptr;
            front = curr;
        } else {
        //make the rest of the nodes
            Node* next = new Node;
            next->c = arr[i];
            next->next = nullptr;
            next->last = curr;
            curr->next = next; 
            curr = next;
        }
    }
    back = curr; 
    numNodes = size;
}

CharLinkedList::CharLinkedList(const CharLinkedList& other) {
        
    front = back = nullptr;  // initialize pointers for the new list
    Node* curr = other.front;

    while (curr) {
        //make a corresponding node for each node in other
        Node* newNode = new Node;
        newNode->c = curr->c;
        newNode->next = nullptr;
        
        if (!front){
            front = back = newNode;
        } else {
            back->next = newNode;
            newNode->last = back;
            back = newNode;
        }

        curr = curr->next;
    }

    numNodes = other.numNodes;
}
    
//Operator
//Purpose: Assignment operator that clears one linked list and copies over
//the data of another linked list.
//Parameters: The address of another Linked List
CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other){
    
     if (this != &other) { 
        this->clear();
        Node *curr = other.front;
        while (curr != nullptr) {
            this->pushAtBack(curr->c);
            curr = curr->next;
        }
    }
    return *this;
}


//~CharLinkedList
//purpose: Destructor for the charLinkedList class.
CharLinkedList::~CharLinkedList(){
    Node *front = this->front;
    recycleRecursive(front);
}

//recycleRecursive
//Purpose: Recurses through the linked list and deletes each node
//Parameters: A pointer to the linked list to recurse through
void CharLinkedList::recycleRecursive(Node *curr){
    if(curr == nullptr){
        return;
    }else{
        Node *next = curr->next;
        delete curr;
        recycleRecursive(next);
    }
}

//isEmpty
//purpose: Returns true if the linked list is empty, false if it isnt.
//Return value: A bool, true if empty, false if not
bool CharLinkedList::isEmpty() const{
    //if numNodes is 0 the list is empty
    int size = this->numNodes;
    
    if(size == 0){
        return true; 
    }else{
        return false;
    }
}

//clear
//purpose: Empties the current linked list and sets the capacity and size to 
//0.
void CharLinkedList::clear(){
    //delete all the nodes and reset to default.
    Node *first = this->front;
    recycleRecursive(front);
    this->numNodes = 0;
    this->front = nullptr;
    this->back = nullptr;
}

//size
//Purpose: Returns the number of nodes in the linked list.
//Return value: An int representing the number of nodes in the linked list.
int CharLinkedList::size() const{
    return numNodes;
}

//first
//Purpose: Return the first char in the charLinkedList
//Return value: a char representing the first char in the charLinkedList.
char CharLinkedList::first()const{
//catch runtime_error
    if (numNodes == 0)
        throw runtime_error("cannot get first of empty LinkedList");      

    char first = front->c;
    return first;
}

//last
//Purpose: Return the last char in a charLinkedList.
//Return value: a char representing the last char in the charLinkedList.
char CharLinkedList::last() const{
    //catch runtime_error
    if (numNodes == 0)
        throw runtime_error("cannot get last of empty LinkedList");

    char last = back->c;
    return last;
}

//elementAt
//Purpose: Return the char at a user specified node in a char linkedList
//Parameters: An int representing the index of the node to be accessed
//Return value: A char representing the char stored at the user specified index
//in the linked list.
char CharLinkedList::elementAt(int index) const{

     //catch range error.
    if (index < 0 || index >= numNodes)
        throw std::range_error("index (" + std::to_string(index) +
        ") not in range [0.." + std::to_string(numNodes) + ")");

    //if we are in the first half run the element at helper from first half
    if (index < numNodes / 2) {
        Node *curr = front;
        bool dir = true;
        return elementAtHelper(index, curr, dir);
    } else { // otherwise run from the back half
        int modifiedIndex = numNodes - index - 1;
        bool dir = false;
        Node *curr = back;
        return elementAtHelper(modifiedIndex, curr, dir);
    }
}


//elementAtHelper
//Purpose: Finds a node at a user specified location in the char Linked List and 
//returns it's value.
//Parameters: An int representing the node to be accessed, a node pointer to 
//the current node, and a bool representing the direction, true if forward and
//false if backward.
//Return Value: A char representing the user specified node's char.

char CharLinkedList::elementAtHelper(int index, Node *curr, bool direction) 
const{
    if (index < 0 || index >= numNodes)
        throw std::range_error("index (" + std::to_string(index) +
        ") not in range [0.." + std::to_string(numNodes) + ")");
    //if we are starting from the front iterate forwards
    if (direction == true) {
        if (index == 0) {
            return curr->c;
        }
        return elementAtHelper(index - 1, curr->next, direction);
    } else {
    //if we are starting from the back iterate backwards.
        if (index == 0) {
            return curr->c;
        }
        return elementAtHelper(index - 1, curr->last, direction);
    }

}

//toString
//Purpose: Returns a string of the characters in the Linked List. 
//Return value: A string, where each char represents the next char in the 
//linked list. 
std::string CharLinkedList::toString() const{
    
    std::stringstream ss;
    ss << "[CharLinkedList of size " << numNodes << " <<";

    //add each node's char to the string
    Node *curr = front;
    for(int i = 0; i < numNodes; i++){
        ss <<curr->c;
        curr = curr->next;
    }
    ss << ">>]";
    return ss.str();
}

//toReverseString
//Purpose: Returns a string of the characters in the Linked List in reverse.
//Return value: A string of the chars in the nodes in reverse order. 
std::string CharLinkedList::toReverseString() const{

    std::stringstream ss;
    ss << "[CharLinkedList of size " << numNodes << " <<";
    //starting from the back add each node's char to the string.
    Node *curr = back;
    for(int i = 0; i < numNodes; i++){
        ss <<curr->c;
        curr = curr->last;
    }
    ss << ">>]";
    return ss.str();
}

//pushAtBack
//Purpose: adds a new char to the end of the LinkedList.
//Parameters: a char to be added to the back of the LinkedList.
void CharLinkedList::pushAtBack(char c){
    //run insertAt on the back
    int index = numNodes;
    insertAt(c,index);
}

//pushAtFront
//Purpose: adds a new char to the end of the Linked List.
//Parameters: a char to be added to the back of the Linked List.
void CharLinkedList::pushAtFront(char c){
    //run insertAt on the front
    int index = 0;
    insertAt(c,index);
}

//insertAt
//Purpose: adds a new node to the user specified location.
//Parameters: A char representing the char to be added at the desired location
//represented by the int
void CharLinkedList::insertAt(char c, int index){
    //catch range error
     if (index < 0 || index > numNodes) {
        throw std::range_error("index (" + std::to_string(index) +
            ") not in range [0.." + std::to_string(numNodes) + "]");
    }
    //make a new node to add
    Node *addedNode = new Node;
    addedNode->c = c;

    //if we are adding to the front make the new node the front
    if (index == 0) {
        addedNode->next = front;
        addedNode->last = nullptr;
        if (front != nullptr) {
            front->last = addedNode;
        }
        front = addedNode;
        if (numNodes == 0) {
            back = addedNode; // Update back if the list is empty
        }
    } else if (index == numNodes) {
        //if we are adding at the back make the new node the back
        addedNode->next = nullptr;
        addedNode->last = back;
        if (back != nullptr) {
            back->next = addedNode;
        }
        back = addedNode;
    } else {
        //otherwise iterate until we find the location to insert
        Node *curr;

        if (index <= numNodes / 2) {
            //if we are in the first half iterate from the front forward.
            curr = front;
            for (int i = 0; i < index - 1; i++) {
                curr = curr->next;
            }
        } else {
            //if we are in the back half iterate from back to front
            curr = back;
            for (int i = numNodes - 1; i >= index; i--) {
                curr = curr->last;
            }
        }

        addedNode->next = curr->next;
        addedNode->last = curr;
        curr->next->last = addedNode;
        curr->next = addedNode;
    }

    if (index == numNodes) {
        back = addedNode; // Update back if inserting at the back
    }

    numNodes++;
}



//insertInOrder
//purpose: Inserts a char into the correct position in a linked list that 
//has already been alphabetically ordered.
//parameters: A char representing the char to be added.
void CharLinkedList::insertInOrder(char c){

    //if the new node should go at the front put it there
    if (numNodes == 0 || c <= front->c) {
        insertAt(c, 0);
        return;
    }

    
    int counter = 0;
    Node *curr = front;
    //iterate over the list until we find the location to put the char
    while (counter < numNodes && c > curr->c) {
        ++counter;
        curr = curr->next;
    }

    //if it should go at the end, put it at the end
    if (counter == numNodes) {
        insertAt(c, counter);
    } else {
        // otherwise put it at the location we have iterated to
        insertAt(c, counter);
    }
}

//removeAt
//Purpose: Removes a node from the linked list at a user specified location.
//Parameters: An int representing the location of the node that should be 
//removed.
void CharLinkedList::removeAt(int index){
    //catch range error
    if (index < 0 || index >= numNodes) {
        throw std::range_error("index (" + std::to_string(index) +
            ") not in range [0.." + std::to_string(numNodes) + ")");
    }
    //catch runtime error
    if (numNodes == 0) {
        throw std::runtime_error("cannot remove from empty LinkedList");
    }
    //if we are at the front delete the front and make the new front the front
    if (index == 0) {
        Node *holder = front;
        front = front->next;
        delete holder;
        if (numNodes == 1) {
            //if the list is empty now reset the values
            back = nullptr;
        } else {
            front->last = nullptr; 
        }
    } else if (index == numNodes - 1) {
       //if were removing the back make the new back the back
        Node *holder = back;
        back = back->last;
        delete holder;
        back->next = nullptr;  
    } else {
        Node *curr;
        // if in the front half iterate until the location is found
        if (index < numNodes / 2) { 
            curr = front;
            for (int i = 0; i < index - 1; i++) {
                curr = curr->next;
            }
        } else {
        //if at the back iterate from the back
            curr = back;
            for (int i = numNodes - 1; i > index; i--) {
                curr = curr->last;
            }
        }
        //reassign the pointers to exclude the node being deleted then delete
        Node *holder = curr->next;
        curr->next = holder->next;
        holder->next->last = curr;
        delete holder;
    }
    numNodes--;
}



//popFromFront
//Purpose: Remove the front node of the linked list.
void CharLinkedList::popFromFront(){
    //run removeAt on the front
    if (numNodes == 0) {
        throw std::runtime_error("cannot pop from empty LinkedList");
    }
    removeAt(0);
}

//popFromFront
//Purpose: Remove the back node of the linked list.
void CharLinkedList::popFromBack(){
    //run removeAt on the back
    if (numNodes == 0) {
        throw std::runtime_error("cannot pop from empty LinkedList");
    }
    removeAt(numNodes - 1);
}

//replaceAt
//Purpose: Replaces a user-specified char with another user specified char.
//Parameters: A char c representing the replacing char, and an int representing
//the index of the char to be replaced
void CharLinkedList::replaceAt(char c, int index){
     
    if (index < 0 || index >= numNodes) {
        throw std::range_error("index (" + std::to_string(index) +
            ") not in range [0.." + std::to_string(numNodes) + ")");
    }
    Node *curr = nullptr;
    //if we are in the first half iterate until we find the node
    if (index < numNodes / 2) {
        curr = front;
        for (int i = 0; i < index; i++) {
            curr = curr->next;
        }
    } else {
    //if we are in the second half iterate from the back
        curr = back;
        for (int i = numNodes - 1; i > index; i--) {
            curr = curr->last;
        }
    }
    //replace the old char with the new char
    curr->c = c;
}


//conCatenate
//Purpose: Adds a copy of a second charLinkedList to the back of the
// original charLinkedList.
//Parameters: A pointer to the Linked List to be added to the back of the
//original Linked List.

void CharLinkedList::concatenate(CharLinkedList *other){
    if (!other || other->numNodes == 0) {
        // Handle invalid input (e.g., log an error, throw an exception).
        return;
    }

    if (this == other) {
        //copy list to its back
        CharLinkedList temp(*other);
        concatenate(&temp);
        return;
    }

    if (numNodes == 0) {
        //copy whole other if this empty
        this->front = new Node(*other->front);
        this->back = this->front;
        this->numNodes = other->numNodes;
        return;
    }

    Node *otherCurr = other->front;
    Node *curr = this->back;
    Node *old = nullptr;

    while (otherCurr != nullptr) {
        //iterate over and assign new values
        curr->next = new Node(*otherCurr);
        curr->next->last = curr;
        old = curr;
        curr = curr->next;
        otherCurr = otherCurr->next;
    }

    this->back = curr;
    this->numNodes += other->numNodes;

    old->next = this->front;
    this->front->last = old;

    // Ensure the last node of the first list points to the first node of the second list
    this->back->next = this->front;
    this->front->last = this->back;
}
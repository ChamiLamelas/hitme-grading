/*
*  LinkedList.h
*  Will Chesney
*  2/4/24
*
*  COMP 15 HW 2
*
*  Purpose: Declares the constructors, destructors, methods, and private
*  section used in the LinkedList class. An instance of a class contains a 
* pointer pointing to the front of the array, a pointer pointing to the back 
* of the array, a list of nodes, each containing two pointers that point to the 
* next node and the node behind.  This class can be used to create size adjustable
* list of chars. This list of chars can be shortened, lengthened, have parts 
* removed and added, and combined with other linkedList.
* 
*/


#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H
#include <sstream>

using namespace std;
#include <string>

class CharLinkedList {

public:


CharLinkedList();


CharLinkedList(char c);

~CharLinkedList();


bool isEmpty() const; 

void clear();

CharLinkedList(char arr[], int size);

CharLinkedList(const CharLinkedList &other);

CharLinkedList &operator=(const CharLinkedList &other);

int size() const;

char first()const;

char last() const;

char elementAt(int index) const;

std::string toString() const;

std::string toReverseString() const;

void pushAtBack(char c);

void pushAtFront(char c);

void insertAt(char c, int index);

void insertInOrder(char c);

void removeAt(int index);

void popFromFront();

void popFromBack();

void replaceAt(char c, int index);

void concatenate(CharLinkedList *other);


private: 

    struct Node {
        char c;
        Node *next;
        Node *last;
    };

    Node *front;
    Node *back;
    void recycleRecursive(Node *curr);
    char elementAtHelper(int index, Node *curr, bool direction) const;
    int numNodes;
};

#endif


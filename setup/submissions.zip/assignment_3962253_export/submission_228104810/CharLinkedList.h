/*
 *  CharLinkedList.h
 *  jdolce01
 *  02.01.24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  contains declarations of functions in the CharLinkedList
    class, and the accessable or nonaccessable members of this class.
 *
 */

#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H

#include <iostream>
#include <string>
#include <sstream>
#include <stdexcept> 

using namespace std;

class CharLinkedList {
    public: 
    // constructors: 
    CharLinkedList();
    CharLinkedList(char c);
    CharLinkedList(char arr[], int size);
    CharLinkedList(const CharLinkedList &other);
    CharLinkedList &operator=(const CharLinkedList &other);

    // destructor
    ~CharLinkedList();

    // access functions 
    int size() const;
    char first() const;
    char last() const;
    char elementAt(int index) const;
    bool isEmpty() const;

    // string/change in variable type functions
    std::string toString() const;
    std::string toReverseString() const;

    // insertion functions
    void pushAtBack(char c);
    void pushAtFront(char c);
    void insertAt(char c, int index);
    void insertInOrder(char c);
    void concatenate(CharLinkedList *other);
    // inserts element, although no change in size
    void replaceAt(char c, int index);

    // deletion functions
    void popFromFront();
    void popFromBack();
    void removeAt(int index);
    void clear();

    private:
    // node struct
    struct Node{
        char data;
        Node *next;
        Node *previous;
    };

    // end/beginning of linked list
    Node *front;
    Node *back;

    // variable integer measuring the changes in sizing
    int currSize;

    // Function to create a new node
    Node* newNode(char newData, Node *next, Node *previous);

    // recursive help functions
    void recursivereplaceAt(Node *current, char c, int index);
    char recursiveelementAt(Node *current, int index) const;
    void recursiveDestructor(Node *temp, int size);
};

#endif

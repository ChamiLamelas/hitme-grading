/*
 *  unit_tests.h
 *  jdolce01
 *  02.01.24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  The purpose of this file is to test how the functions that are in 
 *  CharLinkedList.cpp work compared to how I believe they should work, 
 *  and test edge cases for which errors are regularly returned. 
 *
 */
#include "CharLinkedList.h"
#include <cassert>

// Tests correct insertion into an empty AL.
// Afterwards, size should be 1 and element at index 0
// should be the element we inserted.
void insertAt_empty_correct() { 

    CharLinkedList test_list;
    test_list.insertAt('a', 0);
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');

}

// Tests incorrect insertion into an empty AL.
// Attempts to call insertAt for index larger than 0.
// This should result in an std::range_error being raised.
void insertAt_empty_incorrect() {

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    // insertAt for out-of-range index
    test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
    // if insertAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    range_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0]");
    
}

// Tests correct insertAt for front of 1-element list.
void insertAt_front_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at front
    test_list.insertAt('b', 0);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'a');
}

// // Tests correct insertAt for back of 1-element list.
void insertAt_back_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at back
    test_list.insertAt('b', 1);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    
}

// Tests calling insertAt for a large number of elements.
// Not only does this test insertAt, it also checks that
// list expansion works correctly.
void insertAt_many_elements() {
    
    CharLinkedList test_list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.insertAt('a', i);
    }

    assert(test_list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    
    }   
}

// Tests insertion into front of a larger list
void insertAt_front_large_list() {
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    test_list.insertAt('y', 0);

    assert(test_list.size() == 10);
    assert(test_list.elementAt(0) == 'y');
    assert(test_list.toString() == 
    "[CharLinkedList of size 10 <<yabczdefgh>>]");
    assert(test_list.toReverseString() ==  
    "[CharLinkedList of size 10 <<hgfedzcbay>>]");

}

// Tests insertion into the back of a larger list
void insertAt_back_large_list() {

    char test_arr[10] = { 'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 10);  

    test_list.insertAt('x', 10);

    assert(test_list.size() == 11);
    assert(test_list.elementAt(10) == 'x');
    assert(test_list.toString() == 
    "[CharLinkedList of size 11 <<yabczdefghx>>]"); 

}

// Tests insertion into the middle of a larger list
void insertAt_middle_large_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.insertAt('z', 3);

    assert(test_list.size() == 9);
    assert(test_list.elementAt(3) == 'z');
    assert(test_list.toString() =="[CharLinkedList of size 9 <<abczdefgh>>]");

}

// Tests out-of-range insertion for a non-empty list.
void insertAt_nonempty_incorrect() {
   
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8]");
    
}

// InsertinOrder Tests:
// tests placement of same letter in mid size set
void insertInOrder1(){
    
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.insertInOrder('c');

    assert(test_list.size() == 9);
    assert(test_list.elementAt(3) == 'c');
    assert(test_list.elementAt(2) == 'c');
    assert(test_list.toString() == "[CharLinkedList of size 9 <<abccdefgh>>]");
}
// tests placement into empty set
void insertInOrder2(){
    
    char test_arr[0] = {};
    CharLinkedList test_list(test_arr, 0);

    test_list.insertInOrder('c');

    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'c');
}
// place letter in beginning
void insertInOrder3(){
    
    char test_arr[8] = { 'c', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.insertInOrder('b');

    assert(test_list.toString() ==  
    "[CharLinkedList of size 9 <<bcbcdefgh>>]");
}
// place letter at end
void insertInOrder4(){
    
    char test_arr[8] = { 'b', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.insertInOrder('j');

    assert(test_list.size() == 9);
    assert(test_list.elementAt(8) == 'j');
    assert(test_list.toString() == 
    "[CharLinkedList of size 9 <<bbcdefghj>>]");
}

// Empty Tests: 
// check empty set
void empty1(){
    
    char test_arr[8] = { 'b', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    assert(not test_list.isEmpty());
    assert(test_list.toString() 
    == "[CharLinkedList of size 8 <<bbcdefgh>>]");
}
// check nonempty set
void empty(){
    
    char test_arr[0] = {};
    CharLinkedList test_list(test_arr, 0);

    assert(test_list.isEmpty());
    assert(test_list.toString() == "[CharLinkedList of size 0 <<>>]");
    assert(test_list.toReverseString() == "[CharLinkedList of size 0 <<>>]");
}

// Clear tests:
// clear already empty set
void clear1(){
    
    char test_arr[0] = {};
    CharLinkedList test_list(test_arr, 0);

    test_list.clear();
    assert(test_list.isEmpty());
    assert(test_list.size() == 0);
    assert(test_list.toString() == "[CharLinkedList of size 0 <<>>]");
}
// clear full set
void clear2(){
    
    char test_arr[8] = { 'b', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.clear();
    assert(test_list.isEmpty());
    assert(test_list.size() == 0);
    assert(test_list.toString() ==     "[CharLinkedList of size 0 <<>>]");
}

// Size tests: 
// check size of list 0
void size1(){
    
    char test_arr[0] = {};
    CharLinkedList test_list(test_arr, 0);

    assert(test_list.size() == 0);
}

// check size of list 1
void size2(){
    
    char test_arr[1] = { 'b'};
    CharLinkedList test_list(test_arr, 1);

    assert(test_list.size() == 1);
}

// check size of list 7
void size3(){
    
    char test_arr[7] = { 'b', 'b', 'c', 'd', 'e', 'f', 'g'};
    CharLinkedList test_list(test_arr, 7);

    assert(test_list.size() == 7);
}

// First tests:
// first of nonempty set
void first1(){
    char test_arr[7] = { 'b', 'b', 'c', 'd', 'e', 'f', 'g'};
    CharLinkedList test_list(test_arr, 7);

    assert(test_list.first() == 'b');
}
// first of empty set
void first2() {
    bool runtime_error = false;

    std::string expected_error_message = "cannot get first of empty LinkedList";

    CharLinkedList test_list;
    try {
        test_list.first();
    } 
    catch (const std::runtime_error &e) {
        runtime_error = true;
        // Check if the error message matches the expected message
        assert(e.what() == expected_error_message);
    }

    assert(runtime_error);
}

// Last tests:
// last element of full set
void last1(){
    char test_arr[7] = { 'b', 'b', 'c', 'd', 'e', 'f', 'g'};
    CharLinkedList test_list(test_arr, 7);

    assert(test_list.last() == 'g');
}
// last of empty set
void last2() {
    bool runtime_error = false;
    
    std::string expected_error_message = "cannot get last of empty LinkedList";

    CharLinkedList test_list;
    try {
        test_list.last();
    } catch (const std::runtime_error &e) {
        runtime_error = true;
        // Check if the error message matches the expected message
        assert(e.what() == expected_error_message);
    }

    assert(runtime_error);
}

// elementAt tests:
// checks last element
void elementAt1(){
    char test_arr[7] = { 'b', 'b', 'c', 'd', 'e', 'f', 'g'};
    CharLinkedList test_list(test_arr, 7);

    assert(test_list.elementAt(6) == 'g');
}
// checks first element
void elementAt2(){
    char test_arr[7] = { 'b', 'b', 'c', 'd', 'e', 'f', 'g'};
    CharLinkedList test_list(test_arr, 7);

    assert(test_list.elementAt(0) == 'b');
}
// checks middle element
void elementAt3(){
    char test_arr[7] = { 'b', 'b', 'c', 'd', 'e', 'f', 'g'};
    CharLinkedList test_list(test_arr, 7);

    assert(test_list.elementAt(2) == 'c');
}
// checks out of bonunds element
void elementAt4() {
    bool range_error = false;

    std::string expected_error_message = "index (19) not in range [0..7)";

    char test_arr[7] = { 'b', 'b', 'c', 'd', 'e', 'f', 'g'};
    CharLinkedList test_list(test_arr, 7);

    try {
        test_list.elementAt(19);
    } 
    catch (const std::range_error &e) {
        range_error = true;
        // Check if the error message matches the expected message
        assert(e.what() == expected_error_message);
    }

    assert(range_error);
}

// reverseString tests:
// check reverse of full list
void reverse1() {
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    test_list.insertAt('y', 0);

    assert(test_list.toReverseString() == 
    "[CharLinkedList of size 10 <<hgfedzcbay>>]");
}
// check reverse of empty list
void empty5(){
    
    char test_arr[0] = {};
    CharLinkedList test_list(test_arr, 0);

    assert(test_list.toReverseString() == "[CharLinkedList of size 0 <<>>]");
}

// pushAtBack tests:
// push at back of empty
void pushAtBack1(){
    char test_arr[0] = {};
    CharLinkedList test_list(test_arr, 0);
    test_list.pushAtBack('c');
    assert(test_list.toString() == "[CharLinkedList of size 1 <<c>>]");
}
// push at back of full
void pushAtBack2(){
char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);
    test_list.pushAtBack('c');  
    assert(test_list.toReverseString() == 
    "[CharLinkedList of size 10 <<chgfedzcba>>]");  
}

// pushAtFront tests:
// push at front of empty
void pushAtFront1(){
    char test_arr[0] = {};
    CharLinkedList test_list(test_arr, 0);
    test_list.pushAtFront('c');
    assert(test_list.toString() == "[CharLinkedList of size 1 <<c>>]");
}
// push at front of full
void pushAtFront2(){
char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);
    test_list.pushAtFront('c');  
    assert(test_list.toReverseString() == 
    "[CharLinkedList of size 10 <<hgfedzcbac>>]"); 
}

// popFromFront tests:
//pop from front of full
void popFromFront1(){
char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);
    test_list.pushAtFront('c');  
    test_list.popFromFront();
    assert(test_list.size() == 9);
    assert(test_list.toReverseString() == 
    "[CharLinkedList of size 9 <<hgfedzcba>>]"); 
}
// popfromfront of empty list
void popFromFront2(){
    bool runtime_error = false;

    std::string expected_error_message = "cannot pop from empty LinkedList";
    CharLinkedList test_list;

    try {
        test_list.popFromFront();
    } 
    catch (const std::runtime_error &e) {
        runtime_error = true;
        // Check if the error message matches the expected message
        assert(e.what() == expected_error_message);
    }

    assert(runtime_error);
}

// popFromBack tests:
// pop from back of full
void popFromBackt1(){
char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);
    test_list.pushAtFront('c');  
    test_list.popFromBack();
    assert(test_list.size() == 9);
    assert(test_list.toReverseString() == 
    "[CharLinkedList of size 9 <<gfedzcbac>>]"); 
}
//  pop from back of empty
void popFromBack2(){
    bool runtime_error = false;

    std::string expected_error_message = "cannot pop from empty LinkedList";
    CharLinkedList test_list;

    try {
        test_list.popFromBack();
    } 
    catch (const std::runtime_error &e) {
        runtime_error = true;
        // Check if the error message matches the expected message
        assert(e.what() == expected_error_message);
    }

    assert(runtime_error);
}

// Remove tests: 
// remove first
void removeat1(){
char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    test_list.removeAt(0);
    assert(test_list.size() == 8);
    assert(test_list.toReverseString()  
    == "[CharLinkedList of size 8 <<hgfedzcb>>]"); 
}
// remove last
void removeat2(){
char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    test_list.removeAt(8);
    assert(test_list.toReverseString()  
    == "[CharLinkedList of size 8 <<gfedzcba>>]"); 
}
// remove middle
void removeat3(){
char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    test_list.removeAt(2);
    assert(test_list.toReverseString()  
    == "[CharLinkedList of size 8 <<hgfedzba>>]"); 
}
// remove out of range
void removeat4() {
    bool range_error = false;

    std::string expected_error_message = "index (19) not in range [0..7)";

    char test_arr[7] = { 'b', 'b', 'c', 'd', 'e', 'f', 'g'};
    CharLinkedList test_list(test_arr, 7);

    try {
        test_list.removeAt(19);
    } 
    catch (const std::range_error &e) {
        range_error = true;
        // Check if the error message matches the expected message
        assert(e.what() == expected_error_message);
    }

    assert(range_error);
}

// Replace Tests
// replace at beginning
void replace1(){
char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.replaceAt('b',0);
    assert(test_list.toReverseString() 
    == "[CharLinkedList of size 8 <<hgfedcbb>>]"); 
}
// replace at end
void replace2(){
char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.replaceAt('z',7);
    assert(test_list.toReverseString() 
    == "[CharLinkedList of size 8 <<zgfedcba>>]"); 
}
// replace out of range
void replace3(){
    bool range_error = false;

    std::string expected_error_message = "index (19) not in range [0..7)";

    char test_arr[7] = { 'b', 'b', 'c', 'd', 'e', 'f', 'g'};
    CharLinkedList test_list(test_arr, 7);

    try {
        test_list.removeAt(19);
    } 
    catch (const std::range_error &e) {
        range_error = true;
        // Check if the error message matches the expected message
        assert(e.what() == expected_error_message);
    }

    assert(range_error);
}

// Concatenate tests:
// concatenate two lists
void concatenate1(){
    char test_arr[3]= {'c','a','t'};
    CharLinkedList test_list(test_arr,3);
    
    char test_arr2[3]= {'y','a','y'};
    CharLinkedList test_list2(test_arr2,3);

    test_list.concatenate(&test_list2);
    cerr << test_list.toString() << endl;
    assert(test_list.toString() 
    == "[CharLinkedList of size 6 <<catyay>>]");
}
// concatenate empty list with nonempty list
void concatenate2(){
    CharLinkedList test_list;
    
    char test_arr2[3]= {'y','a','y'};
    CharLinkedList test_list2(test_arr2,3);

    test_list.concatenate(&test_list2);
    cerr << test_list.toString() << endl;
    assert(test_list.toString() 
    == "[CharLinkedList of size 3 <<yay>>]");
}
// concatenate list with nonempty list
void concatenate3(){
    char test_arr[3]= {'c','a','t'};
    CharLinkedList test_list(test_arr,3);
    
    CharLinkedList test_list2;

    test_list.concatenate(&test_list2);
    assert(test_list.toString() 
    == "[CharLinkedList of size 3 <<cat>>]");
}

// string tests
// look at tostring function
void tostring1(){
    char test_arr[3]= {'c','a','t'};
    CharLinkedList test_list(test_arr,3);
    assert(test_list.toString() 
    == "[CharLinkedList of size 3 <<cat>>]");
}
// look at tostring function
void tostring2(){
    CharLinkedList test_list('h');

    assert(test_list.toString() 
    == "[CharLinkedList of size 1 <<h>>]");
}
// check empty string
void tostring3(){
    CharLinkedList test_list;

    assert(test_list.toString() 
    == "[CharLinkedList of size 0 <<>>]");
}
// check reverse string of multiple elements
void toreversestring1(){
    char test_arr[3]= {'c','a','t'};
    CharLinkedList test_list(test_arr,3);

    assert(test_list.toReverseString() 
    == "[CharLinkedList of size 3 <<tac>>]");
}
// check reverse string of one element
void toreversestring2(){
    CharLinkedList test_list('h');

    assert(test_list.toReverseString() 
    == "[CharLinkedList of size 1 <<h>>]");
}



/*
 *  CharLinkedList.cpp
 *  jdolce01
 *  02.01.24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  contains definitions and local declarations reflected 
    in the CharLinkedList.h file, and the implemntation of the
    functions previously described. 
 *
 */

#include "CharLinkedList.h"

/*
name:       CharLinkedList
purpose:    a constructor that creates an empty linked list
arguments:  no arguments
returns:    no returns, but creates a LinkedList that contains a nullptr of
            size 0
*/
CharLinkedList::CharLinkedList(){
    // set size to 0 and front assinged to nullptr
    front = nullptr;
    back = nullptr;
    currSize = 0;
}

/*
name:       CharLinkedList
purpose:    a constructor that creates a linked list of size one containing 
            character c
arguments:  char c, a character representing the first elemnt(front)
returns:    no returns, but creates a liked list of size one of character c
*/
CharLinkedList::CharLinkedList(char c){
    // size is 1, front is newnode filled with the inputted char c
    front = newNode(c, nullptr, nullptr);
    back = front;
    currSize = 1;
}

/*
name:       CharLinkedList
purpose:    create a linked list from the given array argument 
arguments:  char arr[] and int size, 
returns:    no returns, but creates a linked list of size size with the
            characters in the given array arr  
*/
CharLinkedList::CharLinkedList(char arr[], int size){
    // set size to inputted size
    currSize = size;

    if (currSize > 0){
        // set front, and move in order adding a node for each element
        // in the array. when size is reached, make the last element
        // the back
        front = newNode(arr[0], nullptr, nullptr);
        Node *current = front;

        for(int i = 1; i < currSize; i++){
            current->next = newNode(arr[i], nullptr, current);
            current = current->next;
        }
        back = current;
    }
    else{
        // if size is equal to 0/empty array
        front = nullptr;
        back = nullptr;
    }
}

/*
name:       CharArrayList
purpose:    a copy constructor that will make a deep copy of the given other
arguments:  the address of a pointer to CharArray list(other) of type const
returns:    no returns, but will create a deep copy of the given instance
*/
CharLinkedList::CharLinkedList(const CharLinkedList &other){
    // if other does not have any elements, return
    if(other.front == nullptr){
        return;
    }

    // set size to other size
    currSize = other.currSize;

    if(currSize > 0){
        // create new nodes from other going by their element order, set front
        front = newNode(other.elementAt(0), nullptr, nullptr);
        Node *current = front;
        Node *otherCurrent = other.front;
    
        // loop through every element in other using the current size as the
        // bound, and moving to next element. set back equal to last element
        for(int i = 1; i < currSize; i++){
            current->next = newNode(other.elementAt(i), nullptr, current);
            current = current->next;
            otherCurrent = otherCurrent->next;
        }
        back = current;
    }
    else{
        // if no elements in other
        front = nullptr; 
        back = nullptr;
    }

}

/*
name:       CharLinkedList
purpose:    recycles the storage associated with the instance on the left of 
            the assignment and makes a deep copy of the instance on the right 
            hand side into the instance on the left hand side
arguments:  the address of a pointer to CharArray list(other) of type const
returns:    no returns, but will make a deep copy of the instance on the right
*/
CharLinkedList & CharLinkedList::operator=(const CharLinkedList &other){
    // Check for self-assignment
    if(this == &other){
        return *this;
    }

    // Clear the existing linked list to deallocate memory
    clear();

    // Copy the size from the other list
    currSize = other.currSize;

    // If other is not empty, create a new node for each element in other
    if (currSize > 0){
        front = newNode(other.elementAt(0), nullptr, nullptr);
        Node *temp = front;
        Node *temp1 = other.front;

        for(int i = 1; i < currSize; i++){
            temp->next = newNode(other.elementAt(i), nullptr, temp);
            temp = temp->next;
            temp1 = temp1->next;
        }
    }
    return *this;
}

/*
name:       size
purpose:    return the currSize of the linked list
arguments:  no arguments
returns:    returns an int currSize that represents the size of the linked list
*/
int CharLinkedList::size() const{
    return currSize;
}

/*
name:       first
purpose:    return the first character in the linked list
arguments:  no arguments
returns:    returns a type char representing the frust element of the linked 
            list
affects:    will return an error message if linked list is empty
*/
char CharLinkedList::first() const{
    if(currSize == 0){
        // error message:
        throw std::runtime_error("cannot get first of empty LinkedList");
    }
    else{ 
        // char info for first node
        return front->data;
    }
}

/*
name:       last
purpose:    returns the last character of the linked list
arguments:  no arguments
returns:    will return a char the last element in the linked list
affects:    will return an error message if linked list is empty
*/
char CharLinkedList::last() const{
    if(currSize == 0){
        // error message:
        throw std::runtime_error("cannot get last of empty LinkedList"); 
    }
    else{
        // char info for last node
        return back->data; 
    }
}

/*
name:       elementAt
purpose:    show then element at the given index in the linked list
arguments:  int index, an integer value of the given index that the user wants
            to see
returns:    will return a char of the element at the given index
affects:    will return an error message if given index is out of bounds
*/
char CharLinkedList::elementAt(int index) const{
    if(index < 0 or index >= currSize){
        // error message for out of bounds:
        throw std::range_error("index (" + std::to_string(index) 
        + ") not in range [0.." 
        + std::to_string(currSize) + ")");
    }
    else{
        // use recursion to reach the index point in the list
        Node *current = front; 
        return recursiveelementAt(current, index);
    }
}

/*
name:       recursiveelementAt
purpose:    use recursion to find the element at the given index
arguments:  a pointer to node that represents the current index, and an int 
            index that will detract by 1 as moved through list
returns:    Return the char of the node at the given index
*/
char CharLinkedList::recursiveelementAt(Node *current, int index) const{
    if(index == 0){
        // data at current index
        return current->data;
    }
    else{
        // increment by 1 for each current->next used
        return recursiveelementAt(current->next, index-1);
    }
}

/*
name:       isEmpty
purpose:    assign a bool value to determine if a linkedlist is empty
arguments:  no arguments
returns:    a bool statement, true if the linked list is empty, false if it is 
            not
*/
bool CharLinkedList::isEmpty() const{
    if (currSize ==  0){
        return true;
    }
    else{
        return false; 
    }
}

/*
name:       toString
purpose:    to convert the linked list to string type
arguments:  no arguments
returns:    returns a string phrase dictating the currSize and elements of the
            linked list
*/
std::string CharLinkedList::toString() const{
    if (currSize == 0){
        // same statement for each empty list
        return std::string("[CharLinkedList of size 0 <<>>]");
    }
    else{
        // set up a stringstream
        std::stringstream ss;

        // starting at front of linked list, iterate through list while adding
        // each element as i is incremented to current size
        Node *temp = front;
        for(int i = 0; i < currSize; i++){
            ss << temp->data;
            temp = temp->next;
        }

        // set variable of std::striong type for phrase
        std::string phrase = ss.str();

        // return phrase
        return std::string("[CharLinkedList of size " 
        + std::to_string(currSize) 
        + " <<" + phrase + ">>]");
    }
    
}

/*
name:       toReverseString
purpose:    to convert the linked list to string type in descending order
            (starting from the nullptr)
arguments:  no arguments
returns:    returns a string phrase dictating the currSize and elements of the
            linked list in descending order
*/
std::string CharLinkedList::toReverseString() const{
    // initialize the stringstream 
    std::stringstream ss;

    // initialize an array to hold elements of linkedlist
    char arr[currSize];
    for(int i = 0; i < currSize; i++){
        arr[i] = elementAt(i);
    }

    // start of phrase
    ss <<  "[CharLinkedList of size " << std::to_string(currSize) 
    << " <<";

    // elements: sort through array backwards and add
    for (int i = currSize-1; i >= 0; i--){
        ss << arr[i];
    }

    ss << ">>]";

    // return the string in std::string type
    return ss.str();
}

/*
name:       pushAtBack
purpose:    place an element at the back of the linked list
arguments:  char c, the letter the user wants to place at back of linked list
returns:    no returns, but will alter the linked list to reflect a new last 
            element
affects:    currSize is increased by 1
*/
void CharLinkedList::pushAtBack(char c){
    if (front == nullptr) {
        // If the list is empty, make the new node the front
        pushAtFront(c);
    } else {
        // use insertat the index of the currentsize
        insertAt(c, currSize);
    }
}

/*
name:       pushhAtFront
purpose:    place an element at the beginning of the linked list
arguments:  char c, the letter the user wants to place at front of linked list
returns:    no returns, but will alter the linked list to reflect a new front 
            element 
affects:    currSize is increased by 1
*/
void CharLinkedList::pushAtFront(char c){
    // use newNode to make a new node for the new front element
    front = newNode(c, front, nullptr);
    if (currSize == 0){
        back = front;
    }

    // increment size by 1
    currSize++;
}

/*
name:       insertAt
purpose:    to place a character chosen by the user at the chosen index
arguments:  char c and int index- a character that the user wants to input, 
            and an integer of the index that the user wants to place the 
            character at
returns:    no returns, but will alter linked list to reflect new element at 
            given index
affects:    increased currSize by 1
*/
void CharLinkedList::insertAt(char c, int index){
    if(index < 0 or index > currSize){
        // error message
        throw std::range_error("index (" + std::to_string(index) 
        + ") not in range [0.." + std::to_string(currSize) + "]");
    }
    else if(index == 0){
        // if the given index is 0, simply just add to front
        // assigns given char to front element
        pushAtFront(c);
    }
    else{
        // set temporary node to front and loop through to index spot
        Node *temp = front;
        for(int i = 0; i < index - 1; i++){
            temp = temp->next;
        }

        // create a new node for the found spot in linkedlist
        temp->next = newNode(c, temp->next, temp);

        // increment size by 1
        currSize++;
    }
}

/*
name:       insertInOrder
purpose:    place the given element in order based on ASCII number in the 
            linked list
arguments:  char c, the character the user wants to input
returns:    no returns, but will alter linked list to reflect the new 
            character at its index determined by its ASCII number
affects:    increased currSize by 1
*/
void CharLinkedList::insertInOrder(char c){
    if (currSize == 0 or c <= front->data) {
        // if empty list or char belongs at front, simply use pushatfront 
        // function
        pushAtFront(c);
    } else {
        for(int i = 0; i < currSize; i++){
            if(elementAt(i) >= c){
                insertAt(c, i);
                return;
            }
        }
        // If c is greater than all existing elements, insert it at the back
        pushAtBack(c);
    }
}

/*
name:       concatenate
purpose:    take a pointer to CharLinkedList and add all of its elements to the
            end of preexisting linked list
arguments:  a pointer to CharLinkedList holding the elements the user wants to
            add
returns:    no return, but will alter linked list to reflect added linked list 
            at the end
*/
void CharLinkedList::concatenate(CharLinkedList *other){
    // if list is empty, just return
    if(other->size() == 0){
        return;
    }
    // case for if other is equal to the linkedlist(duplicate previous list)
    else if(other == this){
        Node *temp = front;
        while(temp != nullptr){
            pushAtBack(temp->data);
            temp = temp->next;
        }
    }
    else{ 
        // start temp at the front of other
        // cycle through using pushback
        Node *temp = other->front;
        while(temp != nullptr){
            pushAtBack(temp->data);
            temp = temp->next;
        }
    }
}

/*
name:       replaceAt
purpose:    replace a user given character at a user given index in the linked
            list
arguments:  char c and int index, a letter input by the user that the user
            wants to insert at the integer index that the user chooses
returns:    no returns, but will alter linked list to reflect the replaced 
            letter at the given index
affects:    error message if given index is out of bounds 
*/
void CharLinkedList::replaceAt(char c, int index){
    if (index < 0 or index > currSize-1){
        // error function
        throw std::range_error("index (" + std::to_string(index) 
        + ") not in range [0.." 
        + std::to_string(currSize) + ")");
    }
    else{
        // use recursion to reach the element at the given index, starting
        // at the front
        Node *temp = front;
        recursivereplaceAt(temp, c, index);

    }

}

/*
name:       recursivereplaceAt
purpose:    loop through until desired index recursively
arguments:  current, a pointer to node that tracks the current node looped on,
            and int index, the index that the current node is at
returns:    no returns, but updates current to next
*/
void CharLinkedList::recursivereplaceAt(Node *current, char c, int index){
    if(index == 0){
        // basecase: at given index
        current->data = c;
    }
    else{
        // keep iterating through linked list until desired index is reached
        recursivereplaceAt(current->next, c, index-1);
    }
}

/*
name:       popFromFront
purpose:    pop the first element from the front of the list
arguments:  no arguments
returns:    no returns, but will alter list to reflect the deletion of the 
            first element
affects:    error message if linked list is empty, decreased currSize by 1
*/
void CharLinkedList::popFromFront(){
    if(currSize == 0){
        // error message
        throw std::runtime_error("cannot pop from empty LinkedList"); 
    }
    else{
        // set second element to front, and delete the previous front
        Node *temp = front;
        front = front->next;
        delete temp;
        // decrease size by 1
        currSize --;
    }

}

/*
name:       popFromBack
purpose:    pop the last element off of the linked list
arguments:  no arguments
returns:    no returns, but will alter list to reflect the deletion of the last
            element
affects:    decreased currSize by 1, error message if empty linked list
*/
void CharLinkedList::popFromBack(){
    if(currSize == 0){
        // error message
        throw std::runtime_error("cannot pop from empty LinkedList"); 
    }
    else if(currSize == 1){
        // create an empty list
        clear();
    }
    else{
        // remove at the last index
        removeAt(currSize-1);
    }
}

/*
name:       removeAt
purpose:    to remove the element at the given index in the linked list
arguments:  int index, an integer value input by the user that represents where
            in the linked list there will be a removed element
returns:    no returns, but will alter linked list to reflect a removed element
            at the chosen index
affects:    decreased currSize by 1, error message if index is out of bounds
*/
void CharLinkedList::removeAt(int index){
    if(index < 0 or index >= currSize){
        // error message
        throw std::range_error("index (" + std::to_string(index) 
        + ") not in range [0.." + std::to_string(currSize) + ")");
    }
else if(index == 0){
        // if want to remove first element, simply use pop from vack
        popFromFront();
    }
    else{
        // set temp node to front, and iterate until at given index
        Node *temp = front;
        for (int i = 1; i < index; i++){
            temp = temp->next; 
        }

        // set another temp equal to temp->next, as to reallocate pointers 
        // of previous and next to the desired deleted elemnt before deleteing
        Node *temp2 = temp->next;
        temp->next = temp2->next;

        // if element is in back, set new value for back
        if(temp2 == back){
            back = temp;
        }
        // delete node at given index and decrease size by 1
        delete temp2;
        currSize--;
    }
}

/*
name:       clear
purpose:    to clear the elements from the linked llist
arguments:  no arguments
returns:    no returns, but will alter the linked list to contain only a 
            nullptr of size 1
*/
void CharLinkedList::clear(){
    while (currSize > 0){
        // pop from front until no elements left
        popFromFront(); 
    }
}

/*
name:       newNode
purpose:    to create a new node that reallocates the pointers to reflect a new
            element
arguments:  no arguments
returns:    returns a pointer to the class newNode that represnts a new pointer
            (element) in linked list
*/
CharLinkedList::Node *CharLinkedList::newNode(char newData, Node *next, 
Node *previous){
    // set new values for given char, and reallocate 
    // its next and previous pointers
    Node *new_node = new Node;
    new_node->data = newData;
    new_node->next = next;
    new_node->previous = previous; 

    return new_node;
}

/*
name:       ~CharLinkedList
purpose:    to clear all of the memory used to store linked list
arguments:  no arguments
returns:    no returns uses the clear to empty linked list and delete to
            delete the data
*/
CharLinkedList::~CharLinkedList(){
    // start at front of linked list, and iterate through all elements
    // using recursion
    int size = currSize; 
    Node *temp = front;
    recursiveDestructor(temp, size);
}

/*
name:       recursiveDestructor
purpose:    use recursion to delete all elements in linkedlist
arguments:  temporary pointer to the node struct, and an int for the size 
            of the linked list
returns:    no returns, but will clear all elements in linkedlist
*/
void CharLinkedList::recursiveDestructor(Node *temp, int size){
    if (size == 0){
        // base case, once all elements are deleted
        return;
    }
    else{
        // increment size by 1 and continue to move to next element
        recursiveDestructor(temp->next, size-1);
        delete temp; 
    }
}

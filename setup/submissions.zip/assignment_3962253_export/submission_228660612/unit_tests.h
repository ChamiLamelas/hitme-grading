/*
 *  unit_tests.h
 *  William Bornmann
 *  2/3/23
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  Runs in conjunction with the unit_test framework to allow for testing of 
 *  individual functions.
 *
 */

#include "CharLinkedList.h"
#include <cassert>
#include <iostream>

using namespace std;

/*
 * constructor test 0
 * Make sure no fatal errors/memory leaks in the default constructor
 */
void constructor_test_0() {
    CharLinkedList list;

}

/*
 * constructor test 1
 * Make sure no items exist in the list upon construction
 * Note: given the provided code, this test should fail. Fix it!
 */
void constructor_test_1() {
    CharLinkedList list; // One way to invoke the default constructor.
    assert(list.size() == 0);

}

//make sure the second constructor initializes the inputted data correctly
void constructor2_singleton_test(){
    CharLinkedList list('a');
    assert(list.elementAt(0) == 'a');
}

//start here


//test the 3rd constructor with multiple elements. 
void constructor3_test_1() {
    char arr[] = {'a', 'b', 'c'};
    CharLinkedList list(arr, 3);

    assert(list.size() == 3);
    assert(list.elementAt(0) == 'a');
    assert(list.elementAt(1) == 'b');
    assert(list.elementAt(2) == 'c');
}

//test the 3rd constructor with 1 elements. 
void constructor3_test_2() {
    char arr[] = {'a'};
    CharLinkedList list(arr, 1);

    assert(list.size() == 1);
    assert(list.elementAt(0) == 'a');
}

//Make sure size is 1 for a list with 1 element
void size_test_singleton() {
    CharLinkedList list('a');
    assert(list.size() == 1);
}

//Make sure size is 3 for CharLinkedList with 3 elements
void size_test_multiple() {
    char arr[] = {'a', 'b', 'c'};
    CharLinkedList list(arr, 3);
    assert(list.size() == 3);
}

//test the overloaded constructor with multiple elements. 
void overloaded_constructor_test_1() {
    char arr[] = {'a', 'b', 'c'};
    CharLinkedList arrList(arr, 3);
    CharLinkedList list(arrList);

    assert(list.size() == 3);
    assert(list.elementAt(0) == 'a');
    assert(list.elementAt(1) == 'b');
}

//test the overloaded constructor with 1 element. 
void overloaded_constructor_test_2() {
    char arr[] = {'a'};
    CharLinkedList arrList(arr, 1);
    CharLinkedList list(arrList);

    assert(list.size() == 1);
    assert(list.elementAt(0) == 'a');
}

//test the assignment operator with multiple elements. 
void assignment_operator_test_1() {
    char arr[] = {'a', 'b', 'c'};
    CharLinkedList arrList(arr, 3);
    CharLinkedList list = arrList;

    assert(list.size() == 3);
    assert(list.elementAt(0) == 'a');
    assert(list.elementAt(1) == 'b');
}

//test the assignment operator with 1 element. 
void assignment_operator_test_2() {
    char arr[] = {'a'};
    CharLinkedList arrList(arr, 1);
    CharLinkedList list = arrList;

    assert(list.size() == 1);
    assert(list.elementAt(0) == 'a');
}

/*
 * isEmpty test empty
 * Make sure we report an empty list correctly.
 */
void isEmpty_test_empty() {
    CharLinkedList list;
    assert(list.size() == 0);
}

/*
 * isEmpty test not empty
 * Make sure we report a non empty list correctly.
 */
void isEmpty_test_not_empty() {
    CharLinkedList list('a');
    assert(not list.isEmpty());
}

//Tests clear function with 1 element
void clear_test_1() {
    CharLinkedList list('a');
    list.clear();
    assert(list.size() == 0);
}

//Tests clear function with multiple elements
void clear_test_2() {
    char arr[] = {'a', 'b', 'c'};
    CharLinkedList list(arr, 3);
    list.clear();
    assert(list.size() == 0);
}


//Make sure first correctly gives the first element in a size 1 list
void first_test_singleton() {
    CharLinkedList list('a');
    assert(list.first() == 'a');
}

//Make sure first correctly gives the first element in a size 3 list
void first_test_multiple() {
    char arr[] = {'a', 'b', 'c'};
    CharLinkedList list(arr, 3);
    assert(list.first() == 'a');
}

//Make sure first throws error with a list of size 0
void first_test_error() {

    // var to track whether runtime_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    // last for empty CharLinkedList
    test_list.first();
    }
    catch (const std::runtime_error &e) {
    // if first is correctly implemented, a runtime_error will be thrown,
    // and we will end up here
    runtime_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(runtime_error_thrown);
    assert(error_message == "cannot get first of empty LinkedList");
}

//Make sure last correctly gives the last element in a size 1 list
void last_test_singleton() {
    CharLinkedList list('a');
    assert(list.last() == 'a');
}

//Make sure last correctly gives the last element in a size 3 list
void last_test_multiple() {
    char arr[] = {'a', 'b', 'c'};
    CharLinkedList list(arr, 3);
    assert(list.last() == 'c');
}

//Make sure last throws error with a list of size 0
void last_test_error() {

    // var to track whether runtime_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    // last for empty CharLinkedList
    test_list.last();
    }
    catch (const std::runtime_error &e) {
    // if last is correctly implemented, a runtime_error will be thrown,
    // and we will end up here
    runtime_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(runtime_error_thrown);
    assert(error_message == "cannot get last of empty LinkedList");
}


//Make sure elementAt correctly gives the first element in a size 1 list
void elementAt_test_singleton() {
    CharLinkedList list('a');
    assert(list.elementAt(0) == 'a');
}

//Make sure elementAt correctly gives the 2nd element in a size 3 list
void elementAt_test_multiple() {
    char arr[] = {'a', 'b', 'c'};
    CharLinkedList list(arr, 3);
    assert(list.elementAt(1) == 'b');
}

void elementAt_test_error() {
    
    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    // elementAt for out-of-range index
    test_list.elementAt(42);
    }
    catch (const std::range_error &e) {
    // if elementAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    range_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0)");
}
void elementAt_Large_test() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    assert(test_list.size() == 8);
    assert(test_list.elementAt(3) == 'd');

}

//tests if pop from front works on a list of size 1
void popFromFront_singleton_test(){
    CharLinkedList list('a');
    list.popFromFront();
    assert(list.size() == 0);
}

//tests if pop from front works on a medium sized list
void popFromFront_mediumSized_test(){
    
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList list(test_arr, 9);
    
    list.popFromFront();
    assert(list.size() == 8);

    list.popFromFront();
    list.popFromFront();
    assert(list.elementAt(0) == 'z');
    assert(list.size() == 6);
}

//tests if pop from back works on a list of size 1
void popFromBack_singleton_test(){
    CharLinkedList list('a');
    list.popFromBack();
    assert(list.size() == 0);
}

//tests if pop from back works on a medium sized list
void popFromBack_mediumSized_test(){
    
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList list(test_arr, 9);
    
    list.popFromBack();
    assert(list.size() == 8);

    list.popFromBack();
    list.popFromBack();
    assert(list.elementAt(0) == 'a');
    assert(list.size() == 6);
    assert(list.elementAt(5) == 'e');
}

//tests if pop from front works on a medium sized list
void insertInOrder_mediumSized_test(){
    
    char test_arr[9] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i' };
    CharLinkedList list(test_arr, 9);
    
    list.insertInOrder('B'); //checks case of inserting at front
    assert(list.elementAt(0) == 'B');

    list.insertInOrder('j'); //checks case of inserting at back
    assert(list.elementAt(list.size() - 1) == 'j');
}






// Tests correct insertion into an empty AL.
// Afterwards, size should be 1 and element at index 0
// should be the element we inserted.
void insertAt_empty_correct() { 

    CharLinkedList test_list;
    test_list.insertAt('a', 0);
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');

}

// Tests incorrect insertion into an empty AL.
// Attempts to call insertAt for index larger than 0.
// This should result in an std::range_error being raised.
void insertAt_empty_incorrect() {

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    // insertAt for out-of-range index
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
    // if insertAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
        range_error_thrown = true;
        error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0]");
    
}

// Tests pushAtBack function on empty CharLinkedList
// Afterwards, the array should be [a,b,c] and the size should be 3
void pushAtBack_test() { 

    CharLinkedList test_list;
    test_list.pushAtBack('a');
    test_list.pushAtBack('b');
    test_list.pushAtBack('c');

    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    assert(test_list.elementAt(2) == 'c');
    assert(test_list.size() == 3);

}


// Tests correct insertAt for front of 1-element list.
void insertAt_front_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at front
    test_list.insertAt('b', 0);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'a');
    
}

// Tests correct insertAt for back of 1-element list.
void insertAt_back_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at back
    test_list.insertAt('b', 1);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    
}

// Tests calling insertAt for a large number of elements.
// Not only does this test insertAt, it also checks that
// array expansion works correctly.
void insertAt_many_elements() {
    
    CharLinkedList test_list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.insertAt('a', i);
    }

    assert(test_list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
    
}

// Tests insertion into front of a larger list
void insertAt_front_large_list() {
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    test_list.insertAt('y', 0);


    assert(test_list.size() == 10);
    assert(test_list.elementAt(0) == 'y');

    assert(test_list.toString() == "[CharLinkedList of size 10 "
                                    "<<yabczdefgh>>]");
    assert(test_list.elementAt(9) == 'h');

}

// Tests insertion into the back of a larger list
void insertAt_back_large_list() {

    char test_arr[10] = { 'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 10);  

    test_list.insertAt('x', 10);

    assert(test_list.size() == 11);
    assert(test_list.elementAt(10) == 'x');
    assert(test_list.toString() == 
    "[CharLinkedList of size 11 <<yabczdefghx>>]"); 

}

// Tests insertion into the middle of a larger list
void insertAt_middle_large_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    assert(test_list.toString() == "[CharLinkedList of size 8 <<abcdefgh>>]");
    test_list.insertAt('z', 3);

    assert(test_list.size() == 9);

    assert(test_list.elementAt(3) == 'z');
    assert(test_list.toString() == "[CharLinkedList of size 9 <<abczdefgh>>]");

}

// Tests out-of-range insertion for a non-empty list.
void insertAt_nonempty_incorrect() {
   
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8]");
    
}

//test removeAt with 1 element
void removeAt_singleton_test() {
    CharLinkedList list('a');
    
    list.removeAt(0);
    assert(list.size() == 0);
}

//test removeAt with a few elements
void removeAt_smallList_test() {
    char arr[] = {'a', 'b', 'c'};
    CharLinkedList list(arr, 3);

    list.removeAt(1);
    assert(list.size() == 2);
    assert(list.elementAt(0) == 'a');
    assert(list.elementAt(1) == 'c');
}

//test removeAt at the front of a small list
void removeAt_front_of_smallList_test() {
    char arr[] = {'a', 'b', 'c'};
    CharLinkedList list(arr, 3);

    list.removeAt(0);
    assert(list.size() == 2);
    assert(list.elementAt(0) == 'b');
    assert(list.elementAt(1) == 'c');
}

//test removeAt at the back of a small list
void removeAt_back_of_smallList_test() {
    char arr[] = {'a', 'b', 'c'};
    CharLinkedList list(arr, 3);

    list.removeAt(3);
    assert(list.size() == 2);
    assert(list.elementAt(0) == 'a');
    assert(list.elementAt(1) == 'b');
}

void removeAt_error_outOfRange() {
    char arr[] = {'a', 'b', 'c'};
    CharLinkedList list(arr, 3);

     // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        // removeAt for out-of-range index
        list.removeAt(42);
    }
    catch (const std::range_error &e) {
    // if removeAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
        range_error_thrown = true;
        error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..3)");
}
void removeAt_error_outOfBounds() {
    char arr[] = {'a', 'b', 'c'};
    CharLinkedList list(arr, 3);

     // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        // removeAt for out-of-range index
        list.removeAt(-1);
    }
    catch (const std::range_error &e) {
    // if removeAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
        range_error_thrown = true;
        error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (-1) not in range [0..3)");
}

void replaceAt_error_outOfRange() {
    char arr[] = {'a', 'b', 'c'};
    CharLinkedList list(arr, 3);

     // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        // replaceAt for out-of-range index
        list.replaceAt('a', 42);
    }
    catch (const std::range_error &e) {
    // if replaceAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
        range_error_thrown = true;
        error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..3)");
}

void replaceAt_error_outOfBounds() {
    char arr[] = {'a', 'b', 'c'};
    CharLinkedList list(arr, 3);

     // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        // replaceAt for out-of-range index
        list.replaceAt('a', -1);
    }
    catch (const std::range_error &e) {
    // if replaceAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
        range_error_thrown = true;
        error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (-1) not in range [0..3)");
}


void toReverseString_singleton() {
    CharLinkedList list('a');

    assert(list.toReverseString() == "[CharLinkedList of size 1 <<a>>]"); 
}

void toReverseString_smallList() {
    char arr[] = {'a', 'b', 'c'};
    CharLinkedList list(arr, 3);

    assert(list.toReverseString() == "[CharLinkedList of size 3 <<cba>>]"); 
}

void concatenate_self_test() {
    char arr[] = {'a', 'b', 'c'};
    CharLinkedList list1(arr, 3);

    CharLinkedList list2(arr, 3);

    list1.concatenate(&list2);

    assert(list1.size() == 6);
    assert(list1.toString() == "[CharLinkedList of size 6 <<abcabc>>]");


}

void concatenate_test_2() {
    char arr[] = {'a', 'b', 'c'};
    CharLinkedList list1(arr, 3);

    char arr2[] = {'d', 'e', 'f'};
    CharLinkedList list2(arr2, 3);

    list1.concatenate(&list2);

    assert(list1.size() == 6);
    assert(list1.toString() == "[CharLinkedList of size 6 <<abcdef>>]");

}
/*
 *  CharLinkedList.cpp
 *  William Bornmann
 *  2/3/23
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Implementation of a simple charLinkedList Class.
 *
 */

#include "CharLinkedList.h"
#include <sstream>
#include <stdexcept>
#include <string>

using namespace std;


/*
 * name:      newNode
 * purpose:   initialize a new node object with the inserted character
 * arguments: the character that will be held by the node
 * returns:   a pointer to the node that was made
 * effects:   none
 */
Node* CharLinkedList::newNode(char newChar) {
    Node* n = new Node();
    n->next = nullptr;
    n->prev = nullptr;
    n->c = newChar;

    return n;
}

/*
 * name:      CharLinkedList default constructor
 * purpose:   initialize an empty CharLinkedList
 * arguments: none
 * returns:   none
 * effects:   numItems to 0
 */
CharLinkedList::CharLinkedList() {
    firstNode = nullptr;
    numItems = 0;
}

/*
 * name:      CharLinkedList second constructor
 * purpose:   initialize a CharLinkedList and make the first element c
 * arguments: none
 * returns:   none
 * effects:   numItems to 1 and the first element is c
 */
CharLinkedList::CharLinkedList(char c) {
    firstNode = newNode(c);
    numItems = 1;
}


/*
 * name:      CharLinkedList third constructor
 * purpose:   initialize a CharLinkedList of the inputted size with the values
 *            from the inputted char array
 * arguments: the char array you would like to copy into the CharLinkedList and
 *            the size of the array
 * returns:   none
 * effects:   numItems to the inputted size. Copys all values from the inputted
 *            array into the CharLinkedList
 */
CharLinkedList::CharLinkedList(char arr[], int size) {

    if (size == 0) {
        firstNode = nullptr;
        numItems = 0;
    }
    else {
        firstNode = newNode(arr[0]);
        numItems = 1;
        for (int i = 1; i < size; i++) {
            pushAtBack(arr[i]);
        }
    }
}

/*
 * name:      CharLinkedList destructor
 * purpose:   free memory associated with the CharLinkedList
 * arguments: none
 * returns:   none
 * effects:   frees memory allocated by CharLinkedList instances
 */
CharLinkedList::~CharLinkedList() {
    destructorRecursion(firstNode);
}



/*
 * name:      CharLinkedList overloaded constructor
 * purpose:   initialize a CharLinkedList and make its elements be the same as
 *            the inputted CharLinkedList
 * arguments: the CharLinkedList you would like to copy
 * returns:   none
 * effects:   creates another instance of the inputted CharLinkedList
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other) {
    if (other.size() == 0) {
        firstNode = nullptr;
        numItems = 0;
    }
    else {
        firstNode = newNode(other.firstNode->c);
        numItems = 1;
        for (int i = 1; i < other.size(); i++) {
            pushAtBack(other.elementAt(i));
        }
    }
}

/*
 * name:      CharLinkedList assignment operator
 * purpose:   recycles the storage associated with the current CharLinkedList
 *            and makes a deep copy of the inputted CharLinkedList. Puts this
 *            deep copy into the current CharLinkedList.
 * arguments: the CharLinkedList you would like to copy
 * returns:   none
 * effects:   creates another instance of the inputted CharLinkedList
 */
CharLinkedList&CharLinkedList::operator=(const CharLinkedList &other) {
    
    if (this == &other) {
        return *this;
    }

    numItems = other.numItems;
    
    Node* currNode = firstNode->next;
    while (currNode->next != nullptr) {
        delete currNode->prev;
    }
    delete currNode;

    if (other.firstNode == nullptr) {
        firstNode = nullptr;
        return *this;
    }
    
    for (int i = 0; i < other.size(); i++) {
        pushAtBack(other.elementAt(i));
    }
    return *this;
}


/*
 * name:      size
 * purpose:   determine the number of items in the CharLinkedList
 * arguments: none
 * returns:   number of elements currently stored in the CharLinkedList
 * effects:   none
 */
int CharLinkedList::size() const {
    return numItems; 
}

/*
 * name:      isEmpty
 * purpose:   determines if the CharLinkedList is empty or not
 * arguments: none
 * returns:   true if CharLinkedList contains no elements, false otherwise
 * effects:   none
 */
bool CharLinkedList::isEmpty() const {
    
    if (numItems == 0) {
        return true;
    }
    return false;
}

/*
 * name:      clear
 * purpose:   clears the LinkedList of all of its values
 * arguments: none
 * returns:   none
 * effects:   numItems is set to 0
 */
void CharLinkedList::clear() {

    Node* currNode = firstNode;

    while (currNode != nullptr and currNode->prev != nullptr) {
        delete currNode->prev;
    }
    
    numItems = 0;
}


/*
 * name:      first
 * purpose:   determine the first items in the CharLinkedList
 * arguments: none
 * returns:   the first element currently stored in the CharLinkedList
 * effects:   none
 */
char CharLinkedList::first() const{
    if (isEmpty()) {
        throw runtime_error("cannot get first of empty LinkedList");
    }
    else{
        return firstNode->c;
    }
    return '\0';
}

/*
 * name:      last
 * purpose:   determine the last items in the CharLinkedList
 * arguments: none
 * returns:   the last element currently stored in the CharLinkedList
 * effects:   none
 */
char CharLinkedList::last() const{
    if (isEmpty()) {
        throw runtime_error("cannot get last of empty LinkedList");
    }
    else{
        Node* currNode = getBackNode();
        return currNode->c;
    }
    return '\0';
}

/*
 * name:      elementAt
 * purpose:   determine the element at the given index of the CharLinkedList
 * arguments: the index of the desired element
 * returns:   the element currently stored in the CharLinkedList at the given 
 *            index
 * effects:   none
 */
char CharLinkedList::elementAt(int index) const{
    

    if ((index < 0) or (index >= numItems)) {
        throw range_error("index (" + to_string(index) + ") not in range [0.."
                          + to_string(numItems) + ")");
    }
    else {
        Node* currNode = findNode(nullptr, index, 0);
        return currNode->c;
    }
    return '\0';
}


/*
 * name:      toString
 * purpose:   turns the linkedList into a string, and returns it
 * arguments: none
 * returns:   a string representation of the linkedList
 * effects:   none
 */
std::string CharLinkedList::toString() const {
    
    std::stringstream ss;
    ss << "[CharLinkedList of size " + to_string(numItems) + " <<";

    for (int i = 0; i < numItems; i++) {
        ss << elementAt(i);
    }

    ss << ">>]";
    return ss.str();
}

/*
 * name:      toReverseString
 * purpose:   turns the reversed linkedList into a string, and returns it
 * arguments: none
 * returns:   a string representation of the reversed linkedList
 * effects:   none
 */
std::string CharLinkedList::toReverseString() const {
    
    std::stringstream ss;
    ss << "[CharLinkedList of size " + to_string(numItems) + " <<";

    for (int i = numItems - 1; i >= 0; i--) {
        ss << elementAt(i);
    }

    ss << ">>]";
    return ss.str();
}

/*
 * name:      pushAtBack
 * purpose:   push the provided character into the back of the CharLinkedList
 * arguments: n character to add to the back of the list
 * returns:   none
 * effects:   increases num elements of CharLinkedList by 1,
 *            adds element to list
 */
void CharLinkedList::pushAtBack(char c) {

    Node* newBackNode = newNode(c);
    Node* currNode = firstNode;
    
    if (firstNode == nullptr) {
        firstNode = newBackNode;
    }
    else {
        while (currNode->next != nullptr) {
            currNode = currNode->next;
        }
        currNode->next = newBackNode;
        newBackNode->prev = currNode;
    }
    numItems++;
}

/*
 * name:      pushAtFront
 * purpose:   push the provided character into the front of the CharLinkedList
 * arguments: n character to add to the front of the list
 * returns:   none
 * effects:   increases num elements of CharLinkedList by 1, adds element to
 *            list
 */
void CharLinkedList::pushAtFront(char c) {
    
    if (firstNode == nullptr) { 
        firstNode = newNode(c);
    }
    else {
        Node* newFrontNode = newNode(c);

        firstNode->prev = newFrontNode;
        newFrontNode->next = firstNode;
        firstNode = newFrontNode;
    }
    numItems++;
}

/*
 * name:      insertAt
 * purpose:   insert the provided character at the inputted index
 * arguments: a character to add to the list and the index of where it will be
 *            stored in the list
 * returns:   none
 * effects:   increases num elements of CharLinkedList by 1, adds element to
 *            list at index 'index'
 */
void CharLinkedList::insertAt(char c, int index) {
    if ((index < 0) or (index > numItems)) {
        throw range_error("index (" + to_string(index) + ") not in range [0.." 
                          + to_string(numItems) + "]");
    }
    else {
        if (index == 0) {
            pushAtFront(c);
        }
        else if (index == numItems) {
            pushAtBack(c);
        }
        else {


            Node* currNode = findNode(firstNode, index, 0);

            Node* insertingNode = newNode(c);
            Node* insertNodeNext = currNode->next;

            currNode->next = insertingNode;
            insertingNode->prev = currNode;
            insertingNode->next = insertNodeNext;

            numItems++;
        }
    }
}

/*
 * name:      popFromFront
 * purpose:   removes the first element of the CharLinkedList
 * arguments: none
 * returns:   none
 * effects:   numItems decreases by 1
 */
void CharLinkedList::popFromFront() {
    if (isEmpty()) {
        throw runtime_error("cannot pop from empty LinkedList");
    }
    else{
        if (numItems == 1) {
            delete firstNode;
            numItems = 0;
            firstNode = nullptr;
            return;
        }
        firstNode = firstNode->next;
        delete firstNode->prev;
        firstNode->prev = nullptr;
        numItems--;
    }
}


/*
 * name:      popFromBack
 * purpose:   removes the last element of the CharLinkedList
 * arguments: none
 * returns:   none
 * effects:   numItems decreases by 1
 */
void CharLinkedList::popFromBack() {
    if (isEmpty()) {
        throw runtime_error("cannot pop from empty LinkedList");
    }
    else{ 
        if (numItems == 1) {
            popFromFront();
        }
        else {
            Node* currNode = getBackNode()->prev;
            
            delete currNode->next;
            currNode->next = nullptr;
            numItems--;
        }
    }
}


/*
 * name:      removeAt
 * purpose:   remove the element at the given index of the CharLinkedList
 * arguments: the index of the desired element to be removed
 * returns:   none
 * effects:   numItems decreases by 1
 */
void CharLinkedList::removeAt(int index) {
    
    if ((index < 0) or (index >= numItems)) {
        throw range_error("index (" + to_string(index) + ") not in range [0.."
                          + to_string(numItems) + ")");
    }
    else {
        if (index == 0 and firstNode != nullptr) {
            popFromFront();
        }
        else if (index == numItems - 1) {
            popFromBack();
        }
        else {
            Node* currNode = findNode(nullptr, index, 0);
            Node* nextNode = currNode->next;
            Node* prevNode = currNode->prev;
            
            delete currNode;

            prevNode->next = nextNode;
            nextNode->prev = prevNode;

            numItems--;
        }
    }
}


/*
 * name:      replaceAt
 * purpose:   replaces the current char at the inputted index with the inputted
 *            character c.
 * arguments: a character to add to the list and the index of where it will be
 *            replacing another char in the list
 * returns:   none
 * effects:   none
 */
void CharLinkedList::replaceAt(char c, int index) {


    if ((index < 0) or (index >= numItems)) {
        throw range_error("index (" + to_string(index) + ") not in range [0.."
                          + to_string(numItems) + ")");
    }
    else {
        Node* currNode = findNode(nullptr, index, 0);
        currNode->c = c;
    }
}

/*
 * name:      insertInOrder
 * purpose:   insert the provided character in the linkedList in ASCII order
 * arguments: a character to add to the list
 * returns:   none
 * effects:   increases num elements of CharLinkedList by 1, adds element to 
 *            list
 */
void CharLinkedList::insertInOrder(char c) {
    
    if (numItems == 0 or c <= elementAt(0)) {
        pushAtFront(c);
    }
    else if (c >= elementAt(numItems - 1)) { 
        pushAtBack(c);
    }
    else {
        for (int i = 1; i < numItems - 1; i++) {    
            if (elementAt(i - 1) <= c and c >= elementAt(i + 1)) {
                insertAt(i, c);
            }
        }
    }
}


/*
 * name:      concatenate
 * purpose:   copys the inputted CharLinkedList and concatenates it onto the
 *            current CharLinkedList
 * arguments: a pointer to a CharLinkedList
 * returns:   none
 * effects:   copys the elements of the CharLinkedList and adds them to current
 *            CharLinkedList
 */
void CharLinkedList::concatenate(CharLinkedList *other) {

    for (int i = 0; i < other->size(); i++) {
        pushAtBack(other->elementAt(i));
    }
}


/*
 * name:      getBackNode
 * purpose:   determine the last node in the CharLinkedList
 * arguments: none
 * returns:   a pointer to the last node in the CharLinkedList
 * effects:   none
 */
Node* CharLinkedList::getBackNode() const {
    Node* currNode = firstNode;

    while (currNode->next != nullptr) {
        currNode = currNode->next;
    }
    return currNode;
}


/*
 * name:      findNode
 * purpose:   recursively finds the node of the desired index in the
 *            CharLinkedList
 * arguments: a pointer to our current node, the desired index, and our current
 *            index in the CharLinkedList
 * returns:   a pointer to the desired node in the CharLinkedList
 * effects:   none
 */
Node* CharLinkedList::findNode(Node* currNode, int idx, int currIdx) const {

    if (currIdx == 0) {
        currNode = firstNode;
    }
    if (idx == currIdx) {
        return currNode;
    }
    else {
        return findNode(currNode->next, idx, currIdx + 1);
    }
}

/*
 * name:      destructorRecursion
 * purpose:   assists in freeing 
 * arguments: a pointer to the current node
 * returns:   a pointer to the last node in the CharLinkedList
 * effects:   none
 */
void CharLinkedList:: destructorRecursion(Node* currNode) {

    if (currNode != nullptr) {
        destructorRecursion(currNode->next);
        delete currNode;
    }
}


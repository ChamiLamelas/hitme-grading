/*
 *  CharLinkedList.cpp
 *  Bijin Basu (bbasu01)
 *  1.31.2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Purpose: this file contains the implementation of the CharLinkedList.h
             this file implements functions to dynamically change
             a character array.
 *
 */

#include "CharLinkedList.h"
#include <iostream>

//Constructors 
/*
 * name:      CharLinkedList() default constructor
 * purpose:   initialize an empty LinkedList.
 * arguments: none
 * returns:   none
 * effects:   initializes the front and  back pointers and the current size of 
              the list
 */
CharLinkedList::CharLinkedList(){
    front = nullptr;
    back = nullptr;
    currSize = 0;
}

/*
 * name:      CharLinkedList(char c) constructor
 * purpose:   initialize an LinkedList that takes in one character.
 * arguments: character
 * returns:   none
 * effects:   sets the size, capacity, and adds char to the first index 
              of node. 
 */
CharLinkedList::CharLinkedList(char c){
    front = new Node;
    front->data = c;
    front->next = nullptr;
    front->prev = nullptr;
    back = front; 
    currSize = 1;
}

/*
 * name:      CharLinkedList(char arr[], int size) constructor
 * purpose:   initialize an array with passed in char arr and size.
 * arguments: character array, size of the array
 * returns:   none
 * effects:   sets the size, capacity, and adds respectives chars 
              to array nodes. 
 */
CharLinkedList::CharLinkedList(char arr[], int size){
    currSize = size;
    front = nullptr;

    if(currSize > 0){
        front = new Node;
        front->data = arr[0];
        front->next = nullptr;
        front->prev = nullptr;
        Node *current = front;
        for(int i = 1; i < size; i++){
            current->next = new Node;
            current->next->prev = current;
            current = current->next;
            current->data = arr[i];
            current->next = nullptr;
        }
    back = current;
    }
}
//destructor
/*
 * name:      ~CharLinkedList
 * purpose:   clear any dynamically allocated memory.
 * arguments: none
 * returns:   none
 * effects:   calls a recursive helper function.
 implicitly tested all of the program, if unit_tests pass valgrind.
 */
CharLinkedList::~CharLinkedList(){
    destructRecursively(front);
}

//Destructor Helper
/*
 * name:      destructRecursivly
 * purpose:   clears any dynamically allocated memory.
 * arguments: takes in the first node called current. 
 * returns:   none
 * effects:   frees memory. implicitly tested all of the program, 
 if unit_tests pass valgrind.
 */
void CharLinkedList::destructRecursively(Node *current){
    if(current == nullptr){
        // std::cout << "nullptr returning" << std::endl;
        return;
    }
    else{
        Node *newNext = current->next;
        delete current;
        destructRecursively(newNext);
    }
    // front = nullptr;
    // back = nullptr;
}

/*
 * name:      CharLinkedList(const CharLinkedList &other) constructor 
 * purpose:   create a deep copy of the provided character linked list.
 * arguments: CharLinkedList &other
 * returns:   none
 * effects:   itereates through both list references to create a copied char 
 linked list. 
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other){
    front = nullptr;
    back = nullptr;
    currSize = 0;

    Node *current = other.front;
    while(current != nullptr){
        pushAtBack(current->data);
        current = current->next;
    }
}

/*
 * name:      operator=
 * purpose:   define an assignment operator that recycles the storage of the 
              instance and creates a deep copy of it.
 * arguments: constant reference to another CharLinkedList instance
 * returns:   reference to the current object.
 * effects:   deep copies the other object to current object, ensuring that they
              are independent objects from one another. 
 */
CharLinkedList & CharLinkedList::operator=(const CharLinkedList &other){
    if(this == &other){
        return *this;
    }
    Node *otherCurrent = other.front;

    //go through and deep copy
    while(otherCurrent != nullptr){
        pushAtBack(otherCurrent->data);
        otherCurrent = otherCurrent->next;
    }
    return *this;
}

//Methods 
/*
 * name:      isEmpty
 * purpose:   check if a character linked list is empty. 
 * arguments: none
 * returns:   boolean value
 * effects:   gets the current size value of the list and 
              verifies if it is empty or not.
 */
bool CharLinkedList::isEmpty() const{
    if(front == nullptr and currSize == 0){
        return true;
    }
    return false;
}

/*
 * name:      clear
 * purpose:   clear the character lists of any size, and ensures pointers are 
set to null.
 * arguments: none
 * returns:   none
 * effects:   the size changes to 0, front and back are set nullptr, hiding 
 any values from the client. 
 */
void CharLinkedList::clear(){
    destructRecursively(front);
    currSize = 0;
    front = nullptr;
    back = nullptr;
}

/*
 * name:      size
 * purpose:   find the size of a character linked list.
 * arguments: none
 * returns:   integer of the size of the character list.
 * effects:   size value of character list is found and returned.
 */
int CharLinkedList::size() const{
    return currSize;
}

/*
 * name:      first
 * purpose:   retrieve the first character of a character linked list.
 * arguments: none
 * returns:   the first character of a character linked list. 
 * effects:   the first character is found and returned.
 */
char CharLinkedList::first() const{
    if(isEmpty()){
        throw std::runtime_error("cannot get first of empty LinkedList");
    }
    return front->data;
}

/*
 * name:      last
 * purpose:   get the last character of a character linked list.
 * arguments: none
 * returns:   the last character of a character linked list.
 * effects:   throws a runtime error if the character linked is empty.  
 */
char CharLinkedList::last() const{
    if(isEmpty()){
        throw std::runtime_error("cannot get last of empty LinkedList");
    }
    Node *current = front;
    while(current->next != nullptr){
        current = current->next;
    }
    return current->data;
}

/*
 * name: ElementAt      
 * purpose:  call the recursive private function that retrieves the element.
 * arguments: index of the element.
 * returns:   the character at the specified index.
 * effects:   throws a range error if the index is not in 
              the range [0, currSize).
 */
char CharLinkedList::elementAt(int index){
    if(index < 0 or index >= currSize){
        throw std::range_error("index (" + std::to_string(index) 
        + ") not in range [0.." + std::to_string(currSize) + ")");
    }
    return elementAtRecursively(front, index);
}
/*
 * name: elementAtRecursively      
 * purpose:  return the element at the specified index in CharLinkedList.
 * arguments: index of the element.
 * returns:   the character at the specified index.
 * effects:   throws a range error if the index is not in 
              the range [0, currSize) and gives it to the elementAt function.
 */
char CharLinkedList::elementAtRecursively(Node *current, int index){
    //basecase
    if(index == 0){
        return current->data;
    }
    return elementAtRecursively(current->next, index-1);
}

/*
 * name: toString    
 * purpose: return a string with the letters of a character linked list.
 * arguments: none
 * returns: string
 * effects: retrieves and outputs the string of the character linked list.
 */
std::string CharLinkedList::toString() const{
    Node *current = front;
    std::string word;

    if(isEmpty()){
        return std::string("[CharLinkedList of size 0 <<>>]"); 
    }
    else{
        for(int i = 0; i < currSize; i++){
            word += current->data;
            current = current->next;
        }
        return std::string("[CharLinkedList of size " 
        + std::to_string(currSize) 
        + " <<" + std::string(word) + ">>]");
    }
    
}

/*
 * name:      toReserveString
 * purpose:   take characters and put them into a string in reverse order.
 * arguments: none
 * returns:   a string containing the characters of the character 
              list reversed.
 * effects:   provides the output of the characters and the CharLinkedList size.
 */
std::string CharLinkedList::toReverseString() const{
    Node *current = back;
    std::string word;

    if(isEmpty()){
        return std::string("[CharLinkedList of size 0 <<>>]"); 
    }
    else{
        for(int i = currSize - 1; i >= 0; i--){
            word += current->data;
            current = current->prev;
        }
        return std::string("[CharLinkedList of size " 
        + std::to_string(currSize) 
        + " <<" + std::string(word) + ">>]");
    }
}

/*
 * name:    pushAtBack(char c)  
 * purpose:   add a character to the back of the CharLinkedList.
 * arguments: character to be added to the back
 * returns:   none
 * effects:   modifies the CharLinkedList by inserting a character to the end.
              modifies the size.
 */
void CharLinkedList::pushAtBack(char c){
    Node *newNode = new Node;
    newNode->data = c;
    newNode->next = nullptr;
    
    if(isEmpty()){
        front = newNode;
        back = front; 
    }
    else{
        newNode->prev = back;
        back->next = newNode;
        back = newNode;
    }
    currSize++;
}

/*
 * name:      pushAtFront(char c)
 * purpose:   add a character to the front of the CharLinkedList.
 * arguments: character to be added to the front
 * returns:   none
 * effects:   modifies the CharLinkedList by inserting a character to the 
              front. modifies the size. 
 */
void CharLinkedList::pushAtFront(char c){
    Node *newNode = new Node;
    newNode->data = c;
    newNode->prev = nullptr; 
    newNode->next = nullptr;

    if(isEmpty()){
        front = newNode;
        back = newNode;
    }
    else if(c < front->data){
        newNode->next = front;
        front->prev = newNode;
        front = newNode;
    }
    else{
        newNode->next = front;
        front->prev = newNode;
        front = newNode;
    }
    currSize++;
}

/*
 * name:      insertAt
 * purpose:   insert a character at the specified index in the CharLinkedList.
 * arguments: character to be inserted, index where the character is added
 * returns:   none
 * effects:   modifies the CharLinkedList by inserting a character
              throws a range error if the index is not in 
              the range[0, currSize]. modifies the size.
 */
void CharLinkedList::insertAt(char c, int index){
    if(index < 0 or index > currSize){
        throw std::range_error("index (" + std::to_string(index) 
        + ") not in range [0.." + std::to_string(currSize) + "]");
    }

    Node *temp;
    Node *newNode = new Node {c, nullptr}; 
    Node *current = front;
    if(index == 0){
        newNode->prev = nullptr;
        newNode->next = front;
        front = newNode;
    }
    else{
        for(int i = 0; i < index-1; i++){
            current = current->next;
        }
        temp = current->next;
        current->next = newNode;
        newNode->next = temp;
    }
    currSize++;
}

/*
 * name:      insertInOrder
 * purpose:   insert a character in ascending order.
 * arguments: character to be inserted
 * returns:   none
 * effects:   modifies the CharLinkedList by inserting a character in ascending 
              order. Updates the linking of the lists and size.
 */
void CharLinkedList::insertInOrder(char c){
    Node *newNode = new Node {c, nullptr, nullptr};

    if(isEmpty() or c < front->data){
        pushAtFront(c);
    }
    if(c >= back->data){
        pushAtBack(c);
    }
    
    Node *current = front;
    while(current->next != nullptr and c > current->next->data){
        current = current->next;
    }
    newNode->prev = current;
    newNode->next = current->next;
    current->next->prev = newNode;
    current->next = newNode;

    currSize++;
}

/*
 * name:      popFromFront
 * purpose:   remove the character from the front of the CharLinkedList.
 * arguments: none
 * returns:   none
 * effects:   modifies the CharLinkedList by removing the characters from 
              the front. throws a runtime error if the CharLinkedList is empty.
              modifies the size.
 */
void CharLinkedList::popFromFront(){
    if(currSize > 0){
    Node *gone = front;
    front = gone->next;
    delete gone;
    currSize--;
    }
    else{
        throw std::runtime_error("cannot pop from empty LinkedList");
    }
}

/*
 * name:      popFromBack
 * purpose:   remove the character from the back of the CharLinkedList.
 * arguments: none
 * returns:   none
 * effects:   modifies the CharLinkedList by removing the character from 
              the back. throws a runtime error if the CharLinkedList is empty.
              modifies the size.
 */
void CharLinkedList::popFromBack(){
    if(currSize == 0){
        throw std::runtime_error("cannot pop from empty LinkedList");
    }
    Node *gone = back;
    if(currSize == 1){
        front = nullptr;
        back = nullptr;
    }
    else{
        back = back->prev;
        back->next = nullptr;
    }
    delete gone;
    currSize--;
}
    
/*
 * name:      removeAt
 * purpose:   remove a character from a given index in the CharLinkedList.
 * arguments: integer index
 * returns:   none
 * effects:   modifies the CharLinkedList by removing the character at the 
              given index. throws a range error if the index is not in the 
              range[0, currSize]. modifies the size.
 */
void CharLinkedList::removeAt(int index){
    if(index < 0 or index >= currSize) {
        throw std::range_error("index (" + std::to_string(index) +
        ") not in range [0.." + std::to_string(currSize) + ")");
    }
    if(index == 0){
        popFromFront();
    }
    else if(index == currSize-1){
        popFromBack();
    }
    else {
        Node *current = front;

        for(int i = 0; i < index; i++){
            current = current->next;
        }
        //repoint 
        current->prev->next = current->next;
        current->next->prev = current->prev;
        delete current;
        currSize--;
    }
}

/*
 * name:      replaceAt
 * purpose:   calls the replace helper function.
 * arguments: character to replace the existing character, and the index of the
              to replace
 * returns:   none
 * effects:   modifies the CharLinkedList by replacing the character in the
              specified index through the helper function call.
 */
void CharLinkedList::replaceAt(char c, int index){
    if(index < 0 or index >= currSize){
        throw std::range_error("index (" + std::to_string(index) 
        + ") not in range [0.." + std::to_string(currSize) + ")");
    }
    replaceRecursively(front, c, index);
}

/*
 * name:      replaceRecursively
 * purpose:   recurisvely replaces elements.
 * arguments: pointer to a current node, the character to replace the existing 
              character, and the index of the element to replace
 * returns:   none
 * effects:   modifies the CharLinkedList by replacing the character in the
              specified index through the helper function call.
 */
void CharLinkedList::replaceRecursively(Node *current, char c, int index){
    if(index == 0){
        current->data = c;
    }
    else{
        return replaceRecursively(current->next, c, index-1);
    }
}

/*
 * name:      concatenate(CharLinkedList *other)
 * purpose:   concatenate the elements of another CharLinkedList to this 
              CharLinkedList
 * arguments: a pointer to another CharLinkedList to concatenate.
 * returns:   no return value.
 * effects:   directly modifies the current CharLinkedList. if 'other' is 
              empty, no modifications are made.
 */
void CharLinkedList::concatenate(CharLinkedList *other){
    //check current instance
    if(isEmpty()){
        *this = *other;
        return;
    }
    //check other instance
    if(other->isEmpty()) {
        return;
    }

    Node *current = other->front;
    int nodes = other->currSize;

    while(nodes != 0){
        pushAtBack(current->data);
        current = current->next;
        nodes--;
    }
}

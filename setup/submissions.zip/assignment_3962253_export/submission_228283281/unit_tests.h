/*
 *  unit_tests.h
 *  Bijin Basu (bbasu01)
 *  1.31.2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  Purpose: uses a similar framework from HW1 to unit test ensuring
    functionality with the functions defined in CharLinkedList.cpp
 *
 */
#include "CharLinkedList.h"
#include <cassert>
//just for testing 
#include <iostream>

//Constructor Tests
void initializeCharLinkedList(){
   CharLinkedList list;
   assert(list.size() == 0);
}

void CllCharTest(){
   CharLinkedList list('c');
   assert(list.size() == 1);
   //tostring test
}  

void CllArraySizeTest(){
   char array[5] = {'a','b','c','d','e'};
   CharLinkedList list(array, 5);
   assert(list.size() == 5);
   //run a tostring test
}

// deep copy constructor
void deepCopyConstructor(){
   char letters[3] = {'a', 'b', 'c'};

   CharLinkedList list(letters, 3);
   CharLinkedList list2(list);

   //check if a letter is the same
   assert(list.first() == list2.first());
   assert(list.last() == list2.last());
   assert(list.size() == list2.size());
}

void dCopyConMiddleLetterChange(){
    char letters[3] = {'a', 'b', 'c'};

   CharLinkedList list(letters, 3);
   CharLinkedList list2(list);

   //check if a letter is the same
   assert(list.first() == list2.first());
   assert(list.last() == list2.last());
   assert(list.size() == list2.size());

   list2.replaceAt('o', 1);
   assert(list.first() == list2.first());
   assert(list.last() == list2.last());
   assert(list.size() == list2.size());
   assert(list.elementAt(1) != list2.elementAt(1));
}

void dCopyConstructorEmpty(){
   CharLinkedList list1;
   CharLinkedList list2(list1);

   assert(list2.isEmpty()); 


}

// //Destructor is implicitly tested

//Test equal operator
void equalOperatorTest(){
   char array[3] = {'c','a','t'};
   
   CharLinkedList list(array, 3);
   CharLinkedList list2;

   list2 = list;
   assert(list2.size() == 3);
}

//isEmpty
void isEmptyTestEmpty(){
   CharLinkedList list;
   assert(list.isEmpty());
}

void isEmptyTestWithChars(){
   char arr[3] = {'d', 'o', 'g'};
   CharLinkedList list(arr, 3);
   assert(list.size() == 3);
}

//clear
void clearArrayTestFulltoEmpty(){
   char arr[3] = {'a','b','c'};
   CharLinkedList list(arr, 3);
   list.clear();
   assert(list.isEmpty());
   assert(list.size() == 0);
}
void clearArrayTestFulltoEmptyChar(){
   CharLinkedList list('a');
   list.clear();
   assert(list.isEmpty());
   assert(list.size() == 0);
}
void clearArrayTestFulltoEmptyChar2(){
   char arr[1] = {'a'};
   CharLinkedList list(arr, 1);
   list.clear();
   assert(list.isEmpty());
   assert(list.size() == 0);
}
void clearArrayTestEmpty(){
    CharLinkedList list;
    list.clear();
    assert(list.isEmpty());
}

//size
void sizeTestEmpty(){
   CharLinkedList list;
   assert(list.isEmpty());
}

void sizeTestWithArray(){
   char array[3] = {'d','o','g'};
   CharLinkedList list(array, 3);
   assert(not list.isEmpty());
   assert(list.size() == 3);
}

//first
void firstLetterTest(){
   char array[2] = {'a','b'};
   CharLinkedList list(array, 2);
   assert(list.first() == 'a');
}

void firstTryCatch(){
   CharLinkedList list;
   bool error_thrown = false;
   try {
      list.first();
   }
   catch(const std::runtime_error &e){
      error_thrown = true;
   }
   assert(error_thrown);
}

//last
void lastLetterTest(){
   char array[4] = {'h','i', 'i', 'i'};
   CharLinkedList list(array, 4);
   assert(list.last() == 'i');
}
void lastTryCatch(){
   CharLinkedList list;
   bool error_thrown = false;
   try{
      list.last();
   }
   catch(const std::runtime_error &e){
      error_thrown = true;
   }
   assert(error_thrown);
}

// //elementAt
void elementAtTest(){
    char bijin[5] = {'b', 'i', 'j', 'i', 'n'};
    CharLinkedList list(bijin, 5);
    assert(list.elementAt(4) == 'n');
}
void elementAtStressTest(){
    char bijin[15] = {'b', 'i', 'j', 'i', 'n','b', 'i', 'j', 'i', 'n','b', 
    'i', 'j', 'i', 'n'};
    CharLinkedList list(bijin, 15);
    assert(list.elementAt(12) == 'j');
}

void elementAtTryCatch(){
    char array[3] = {'b','i','j'};
    CharLinkedList list(array, 3);
    bool error_thrown = false;
    try {
        list.elementAt(3);
    }
    catch(const std::range_error &e){
        error_thrown = true;
    }
    assert(error_thrown);
}
void elementAtTryCatchEmpty(){
    CharLinkedList list;
    bool error_thrown = false;
    try {
        list.elementAt(2);
    }
    catch(const std::range_error &e){
        error_thrown = true;
    }
    assert(error_thrown);
}

//toString 
void toStringTest(){
   char arr[5] = {'b','i','j','i','n'};
   CharLinkedList list(arr, 5);
   assert(list.toString() == "[CharLinkedList of size 5 <<bijin>>]");
}
void testToStringInsert() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.insertAt('u', 3);

    assert(test_list.size() == 9);
    assert(test_list.elementAt(3) == 'u');
    assert(test_list.toString() == "[CharLinkedList of size 9 <<abcudefgh>>]");
}

void testToStringThenClearAdd() {
   char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
   CharLinkedList test_list(test_arr, 8);
   assert(test_list.toString() == "[CharLinkedList of size 8 <<abcdefgh>>]");
   test_list.insertAt('u', 3);
   assert(test_list.toString() == "[CharLinkedList of size 9 <<abcudefgh>>]");
   test_list.clear();
   assert(test_list.toString() == "[CharLinkedList of size 0 <<>>]");
}

//toReverseString
void testToReverseString() {
   char test_arr[5] = {'n', 'i', 'j', 'i', 'b'};
   CharLinkedList test_list(test_arr, 5);

   assert(test_list.size() == 5);
   assert(test_list.elementAt(1) == 'i');
   assert(test_list.elementAt(3) == 'i');
   assert(test_list.toReverseString() == 
   "[CharLinkedList of size 5 <<bijin>>]");
}

// pushAtBack
void pushAtBackTest(){
    char array[5] = {'A', 'B', 'D', 'E', 'F'};
    CharLinkedList list(array, 5);
    list.pushAtBack('G');
    assert(list.elementAt(5) == 'G');
}
void pushAtBackEmptyTest(){
    CharLinkedList list;
    list.pushAtBack('A');
    assert(list.elementAt(0) == 'A');
}

//pushAtFront
void pushAtFrontTest(){
    char array[5] = {'A', 'B', 'D', 'E', 'F'};
    CharLinkedList list(array, 5);
    list.pushAtFront('Z');
    assert(list.elementAt(0) == 'Z');
}
void pushAtFrontEmptyTest(){
    CharLinkedList list;
    list.pushAtFront('A');
    assert(list.elementAt(0) == 'A');
}

// insertAt
// Tests correct insertion into an empty AL.
// Afterwards, size should be 1 and element at index 0
// should be the element we inserted.
void insertAt_empty_correct() { 

   CharLinkedList test_list;
   test_list.insertAt('a', 0);
   assert(test_list.size() == 1);
   assert(test_list.elementAt(0) == 'a');

}

// Tests incorrect insertion into an empty AL.
// Attempts to call insertAt for index larger than 0.
// This should result in an std::range_error being raised.
void insertAt_empty_incorrect() {

   // var to track whether range_error is thrown
   bool range_error_thrown = false;

   // var to track any error messages raised
   std::string error_message = "";

   CharLinkedList test_list;
   try {
   // insertAt for out-of-range index
   test_list.insertAt('a', 42);
   }
   catch (const std::range_error &e) {
   // if insertAt is correctly implemented, a range_error will be thrown,
   // and we will end up here
   range_error_thrown = true;
   error_message = e.what();
   }

   // out here, we make our assertions
   assert(range_error_thrown);
   assert(error_message == "index (42) not in range [0..0]");
    
}

// Tests correct insertAt for front of 1-element list.
void insertAt_front_singleton_list() {
    
   // initialize 1-element list
   CharLinkedList test_list('a');

   // insert at front
   test_list.insertAt('b', 0);

   assert(test_list.size() == 2);
   assert(test_list.elementAt(0) == 'b');
   assert(test_list.elementAt(1) == 'a');
    
}

// Tests correct insertAt for back of 1-element list.
void insertAt_back_singleton_list() {
    
   // initialize 1-element list
   CharLinkedList test_list('a');

   // insert at back
   test_list.insertAt('b', 1);

   assert(test_list.size() == 2);
   assert(test_list.elementAt(0) == 'a');
   assert(test_list.elementAt(1) == 'b');
    
}

// Tests calling insertAt for a large number of elements.
// Not only does this test insertAt, it also checks that
// array expansion works correctly.
void insertAt_many_elements() {
    
   CharLinkedList test_list;

   // insert 1000 elements
   for (int i = 0; i < 1000; i++) {
      // always insert at the back of the list
      test_list.insertAt('a', i);
   }

   assert(test_list.size() == 1000);

   for (int i = 0; i < 1000; i++) {
      assert(test_list.elementAt(i) == 'a');
    }
    
}

// Tests insertion into front of a larger list
void insertAt_front_large_list() {
   char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
   CharLinkedList test_list(test_arr, 9);

   test_list.insertAt('y', 0);

   assert(test_list.size() == 10);
   assert(test_list.elementAt(0) == 'y');
   assert(test_list.toString() == "[CharLinkedList of size 10 <<yabczdefgh>>]");
}

// Tests insertion into the back of a larger list
void insertAt_back_large_list() {
   char test_arr[10] = { 'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
   CharLinkedList test_list(test_arr, 10);  

   test_list.insertAt('x', 10);

   assert(test_list.size() == 11);
   assert(test_list.elementAt(10) == 'x');
   assert(test_list.toString() == 
   "[CharLinkedList of size 11 <<yabczdefghx>>]"); 
}

// Tests insertion into the middle of a larger list
void insertAt_middle_large_list() {
   char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
   CharLinkedList test_list(test_arr, 8);

   test_list.insertAt('z', 3);

   assert(test_list.size() == 9);
   assert(test_list.elementAt(3) == 'z');
   assert(test_list.toString() == "[CharLinkedList of size 9 <<abczdefgh>>]");
}

// Tests out-of-range insertion for a non-empty list.
void insertAt_nonempty_incorrect() {
   
   char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
   CharLinkedList test_list(test_arr, 8);

   // var to track whether range_error is thrown
   bool range_error_thrown = false;

   // var to track any error messages raised
   std::string error_message = "";

   try {
      test_list.insertAt('a', 42);
   }
   catch (const std::range_error &e) {
      range_error_thrown = true;
      error_message = e.what();
   }

   assert(range_error_thrown);
   assert(error_message == "index (42) not in range [0..8]");
}

//insertInOrder 
void ascendingOrderTest(){
    char array[5] = {'A', 'B', 'D', 'E', 'F'};
    CharLinkedList list(array, 5);
    list.insertInOrder('C');
    assert(list.elementAt(2) == 'C');
}

void ascendingOrderUpperLowerCaseTest(){
    char array[3] = {'a','b','c'};
    CharLinkedList list(array, 3);
    list.insertInOrder('B');
    assert(list.elementAt(0) == 'B');
}

void ascendingOrderTest2(){
    char array[5] = {'A', 'B', 'D', 'E', 'F'};
    CharLinkedList list(array, 5);
    list.insertInOrder('G');
    assert(list.elementAt(5) == 'G');
}

//Test insertInOrder unassumed 
void ascendingOrderUnssumedTest(){
    char array[3] = {'Z', 'E', 'D'};
    CharLinkedList list(array, 3);
    list.insertInOrder('A');
    assert(list.elementAt(0) == 'A');
}

//Test insertInOrder empty
void ascendingOrderEmptyTest(){
   CharLinkedList list;
      std::cout << list.size() << std::endl;
   list.insertInOrder('A');
   std::cout << list.size() << std::endl;
   assert(not list.isEmpty());
}

//popFromFront
void popFrontTest(){
   char array[5] = {'h', 'e', 'l', 'l', 'o'};
   CharLinkedList list(array, 5);
   list.popFromFront();
   assert(list.elementAt(0) == 'e');
}

//Test popFront Try and Catch
void popFrontTryCatch(){
   CharLinkedList list;
   bool error_thrown = false;
   try {
      list.popFromFront();
   }
   catch(const std::runtime_error &e){
      error_thrown = true;
   }
   assert(error_thrown);
}

//popFromBack
void popBackTest(){
   char array[5] = {'h', 'e', 'l', 'l', 'o'};
   CharLinkedList list(array, 5);
   list.popFromBack();
   assert(list.elementAt(3) == 'l');
}

//Test popBack Try and Catch
void popBackTryCatch(){
   CharLinkedList list;
   bool error_thrown = false;
   std::string message;
   try {
      list.popFromBack();
   }
   catch(const std::runtime_error &e){
      error_thrown = true;
      message = e.what();
   }
   assert(error_thrown);
   assert(message == "cannot pop from empty LinkedList");
}

//removeAt
void removeAtTestGeneral(){
    char array[5] = {'h', 'e', 'l', 'l', 'o'};
    CharLinkedList list(array, 5);
    list.removeAt(3);
    assert(list.size() == 4);
    assert(list.elementAt(3) == 'o');
}
void removeAtTestFirstLetter(){
   char array[5] = {'h', 'e', 'l', 'l', 'o'};
   CharLinkedList list(array, 5);
   list.removeAt(0);
   assert(list.size() == 4);
   assert(list.elementAt(0) == 'e');
   assert(list.elementAt(1) == 'l');
}
void removeAtLastLetter(){
   char array[5] = {'h', 'e', 'l', 'l', 'o'};
   CharLinkedList list(array, 5);
   list.removeAt(4);
   assert(list.size() == 4);
   assert(list.elementAt(3) == 'l');
}

// //replaceAt
//Test replaceAt
void replaceAtTestFirstLetter(){
   char array[5] = {'A', 'B', 'D', 'E', 'F'};
   CharLinkedList list(array, 5);
   list.replaceAt('P', 0);
   assert(list.elementAt(0) == 'P');
}

void replaceAtTestMiddleLetter(){
   char array[5] = {'A', 'B', 'D', 'E', 'F'};
   CharLinkedList list(array, 5);
   list.replaceAt('P', 3);
   assert(list.elementAt(3) == 'P');
}

void replaceAtTestLastLetter(){
   char array[5] = {'A', 'B', 'D', 'E', 'F'};
   CharLinkedList list(array, 5);
   list.replaceAt('P', 4);
   assert(list.elementAt(4) == 'P');
}

//Test replaceAtTryCatch
void replaceAtTryCatch(){
   char array[5] = {'A', 'B', 'D', 'E', 'F'};
   CharLinkedList list(array, 5);
   bool error_thrown = false;
   try {
      list.replaceAt('G', 5);
   }
   catch(const std::range_error &e){
      error_thrown = true;
   }
   assert(error_thrown);
}

void replaceAtTryCatchEmpty(){
   CharLinkedList list;
   bool error_thrown = false;
   try {
      list.replaceAt('A', 0);
   }
   catch(const std::range_error &e){
      error_thrown = true;
   }
   assert(error_thrown);
}

//Concatenate
void concatenateTest(){
    char cat[3] = {'c','a','t'};
    char cheshire[8] = {'C','H','E','S','H','I','R','E'};

    CharLinkedList list1(cat, 3);
    CharLinkedList list2(cheshire, 8);

    list1.concatenate(&list2);
    assert(list1.elementAt(2) == 't');
    assert(list1.elementAt(3) == 'C');
}

void concatenateEmptyTest(){
    CharLinkedList list1;
    list1.concatenate(&list1);
    assert(list1.size() == 0);
}

void concatneateMultiplyTest(){
    char cat[3] = {'c','a','t'};
    char cheshire[8] = {'C','H','E','S','H','I','R','E'};

    CharLinkedList list1(cat, 3);
    CharLinkedList list2(cheshire, 8);

    list1.concatenate(&list2);
    list1.concatenate(&list1);
    assert(list1.toString() == 
    "[CharLinkedList of size 22 <<catCHESHIREcatCHESHIRE>>]");
}

void concatenateEmptyFullTest(){
    char cheshire[8] = {'C','H','E','S','H','I','R','E'};
    CharLinkedList list1;
    CharLinkedList list2(cheshire, 8);

    list1.concatenate(&list2);
    assert(list1.size() == 8);
    assert(list1.toString() == "[CharLinkedList of size 8 <<CHESHIRE>>]");
}














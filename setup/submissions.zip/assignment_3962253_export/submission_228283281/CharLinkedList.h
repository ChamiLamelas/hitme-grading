/*
 *  CharLinkedList.h
 *  Bijin Basu (bbasu01)
 *  1.31.2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Purpose: this file contains the class definitions for the CharLinkedList.
 *           CharLinkedList is a class that represents instances of a character 
             linked list. The constructors deal with varying parameters, and 
             the methods allow for manipulating the character linked lists and
             or turns their characters into strings.
 *
 */

#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H
//only to be used for toString and toReverseString
#include <string>
#include <stdexcept>

class CharLinkedList {
    public:
    //constructors
    CharLinkedList();
    CharLinkedList(char c);
    CharLinkedList(char arr[], int size);
    CharLinkedList(const CharLinkedList &other);

    //destructor 
    ~CharLinkedList();

    // // //methods 
    CharLinkedList &operator=(const CharLinkedList &other);
    bool isEmpty() const;
    void clear();
    int size() const;
    char first() const;
    char last() const;
    char elementAt(int index);
    std::string toString() const;
    std::string toReverseString() const;
    void pushAtBack(char c);
    void pushAtFront(char c);
    void insertAt(char c, int index);
    void insertInOrder(char c);
    void popFromFront();
    void popFromBack();
    void removeAt(int index);
    void replaceAt(char c, int index);
    void concatenate(CharLinkedList *other);

    private:
    struct Node{
        char data;
        Node *next;
        Node *prev;
    };
    Node *front;
    Node *back;

    int currSize;
    void destructRecursively(Node *curr);
    void replaceRecursively(Node *curr, char c, int index);
    char elementAtRecursively(Node *front, int index);
};

#endif

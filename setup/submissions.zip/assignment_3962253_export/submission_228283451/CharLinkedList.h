/*
 *  CharLinkedList.h
 *  Rachel Snyder (rsnyde02)
 *  02/01/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Interface for a CharLinkedList Class. The list is implemented using a linked
 *  list, providing an organized yet flexable structure
 *
 */

#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H

#include <string>
#include <iostream>
using namespace std;

class CharLinkedList 
{
    public:
    
    CharLinkedList();
    CharLinkedList(char c);
    CharLinkedList(char arr[], int size);
    CharLinkedList &operator=(const CharLinkedList &rhs);
    CharLinkedList(const CharLinkedList &other);

    ~CharLinkedList();

    std::string toString() const;
    std::string toReverseString() const;

    bool isEmpty() const;
    int size();

    char first() const;
    char last() const;
    char elementAt(int index) const;
    
    void clear();
    void pushAtBack(char c);
    void pushAtFront (char c);
    void insertAt(char c, int index);
    void insertInOrder(char c);
    void popFromFront();
    void popFromBack();
    void removeAt(int index);
    void replaceAt(char c, int index);
    void concatenate(CharLinkedList *other);

private:
    struct Node {
        char data;
        Node *next;
        Node *prev;
    };

    Node *front;
    Node *back;
    int numItems;

    Node *newNode(char newData, Node *prev, Node *next);
    void recursiveDestruct(Node *curr);
    char recurseToIndex(Node *curr, int index, int counter) const;
    void insertFromFront(char c, int index);
    void insertFromBack(char c, int index);
    void removeAtFromFront(int index);
    void removeAtFromBack(int index);
    Node *recursiveReplace(Node *curr, int index, int counter);
};

#endif
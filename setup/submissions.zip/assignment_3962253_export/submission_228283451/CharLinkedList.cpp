/*
 *  CharLinkedList.cpp
 *  Rachel Snyder (rsnyde02)
 *  02/01/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Implementation of a CharLinkedList Class
 *
 */

#include "CharLinkedList.h"
#include <sstream>
#include <iostream>
#include <stdexcept>

using namespace std;

//---------------------------Constructors/Destructor--------------------------//

/*
 * name:      CharLinkedList default constructor
 * purpose:   initialize an empty CharLinkedList
 * arguments: none
 * returns:   none
 * effects:   front and back pointers to nullptr and numItems to 0
 */
CharLinkedList::CharLinkedList() 
{
    front = nullptr;
    back = nullptr;
    numItems  = 0;
}

/*
 * name:      CharLinkedList single character constructor
 * purpose:   initialize a CharLinkedList with one user-provided character
 * arguments: one character
 * returns:   none
 * effects:   new node is created and front and back pointers are set to it,
 *            numItems is set to 1
 */
CharLinkedList::CharLinkedList(char c) 
{
    front = newNode(c, nullptr, nullptr);
    back = front;
    numItems = 1;
}

/*
 * name:      CharLinkedList array constructor
 * purpose:   initialize a CharLinkedList with a user-provided array and size
 * arguments: character array, integer size of character array
 * returns:   none
 * effects:   creates new nodes for each element of the array and adds them to
 *            the list
 */
CharLinkedList::CharLinkedList(char arr[], int size)
{
    if (size > 0)
    {
        front = newNode(arr[0], nullptr, nullptr);
        back = front;

        for (int i = 1; i < size; i++)
        {
            back = newNode(arr[i], back, nullptr);
            back->prev->next = back;
        }
        numItems = size;
    } else {
        front = nullptr;
        back = nullptr;
        numItems  = 0;
    }
}

/*
 * name:      Overloaded assignment operator
 * purpose:   define the "=" operator
 * arguments: CharLinkedList object
 * returns:   none
 * effects:   assignment operator will make a deep copy in the the 
 *            CharLinkedList class
 */
CharLinkedList &CharLinkedList::operator=(const CharLinkedList &rhs)
{
    if (this == &rhs)
    {
        return *this;
    }

    recursiveDestruct(front);

    if (rhs.numItems == 0)
    {
        front = nullptr;
        back = nullptr;
        numItems  = 0;
        return *this;
    }

    Node *curr = rhs.front;
    front = newNode(curr->data, nullptr, nullptr);
    back = front;
    curr = curr->next;

    while (curr != nullptr) 
    {
        back = newNode(curr->data, back, nullptr);
        back->prev->next = back;
        curr = curr->next;
    }

    numItems = rhs.numItems;

    return *this;
}

/*
 * name:      CharLinkedList copy constructor
 * purpose:   create a copy of a CharLinkedList object
 * arguments: CharLinkedList object
 * returns:   none
 * effects:   A new CharLinkedList object
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other)
{
    if (other.numItems > 0)
    {
        Node *curr = other.front;
        front = newNode(curr->data, nullptr, nullptr);
        back = front;
        curr = curr->next;


        while (curr != nullptr) 
        {
            back = newNode(curr->data, back, nullptr);
            back->prev->next = back;
            curr = curr->next;
        }

        numItems = other.numItems;

    } else {
        front = nullptr;
        back = nullptr;
        numItems  = 0;
    }
}

/*
 * name:      CharLinkedList destructor
 * purpose:   free memory associated with the CharLinkedList
 * arguments: none
 * returns:   none
 * effects:   frees memory allocated by CharLinkedlist instances using recursion
 */
CharLinkedList::~CharLinkedList()
{
    recursiveDestruct(front);
}


//-------------------------------Public-Methods-------------------------------//

/*
 * name:      toString
 * purpose:   convert the list into an std::string
 * arguments: none
 * returns:   std::string
 * effects:   creates an std::string
 */
std::string CharLinkedList::toString() const 
{
    Node *curr = this->front;
    std::stringstream ss;

    ss << "[CharLinkedList of size " << numItems << " <<";

    while (curr != nullptr) 
    {
        ss << curr->data;
        curr = curr->next;
    }

    ss << ">>]";

    return ss.str();
}

/*
 * name:      toReverseString
 * purpose:   convert the backwards list into an std::string
 * arguments: none
 * returns:   std::string
 * effects:   creates an std::string
 */
std::string CharLinkedList::toReverseString() const
{
    Node *curr = this->back;
    std::stringstream ss;

    ss << "[CharLinkedList of size " << numItems << " <<";

    while (curr != nullptr) 
    {
        ss << curr->data;
        curr = curr->prev;
    }

    ss << ">>]";

    return ss.str();
}

/*
 * name:      isEmpty
 * purpose:   determine whether the Linked List is empty
 * arguments: none
 * returns:   boolean
 * effects:   returns true if empty and false if not empty
 */
bool CharLinkedList::isEmpty() const 
{
    if (numItems > 0)
    {
        return false;
    }
    else
    {
        return true;
    }
}

/*
 * name:      clear
 * purpose:   clear the Linked List
 * arguments: none
 * returns:   none
 * effects:   the Linked List is now empty and numItems is set to 0
 */
void CharLinkedList::clear()
{
    Node *curr = this->front;
    while (curr != nullptr) 
    {
        curr->data = '\0';
        curr = curr->next;
    }
    numItems = 0;
}

/*
 * name:      size
 * purpose:   determine the number of items in the Linked List
 * arguments: none
 * returns:   number of elements currently stored in the Linked List
 * effects:   none
 */
int CharLinkedList::size()
{
    return numItems;
}

/*
 * name:      first
 * purpose:   return the first character in the Linekd List
 * arguments: none
 * returns:   first character of the Linked List
 * effects:   none
 */
char CharLinkedList::first() const
{
    if (isEmpty())
    {
        throw runtime_error("cannot get first of empty LinkedList");
    }

    return front->data;
}

/*
 * name:      last
 * purpose:   return the last character in the Linked List
 * arguments: none
 * returns:   last character of the Linked List
 * effects:   none
 */
char CharLinkedList::last() const
{
    if (isEmpty())
    {
        throw runtime_error("cannot get last of empty LinkedList");
    }

    return back->data;
}

/*
 * name:      elementAt
 * purpose:   return the character at a specified index in the Linked List
 * arguments: integer index
 * returns:   the character at a specified index in the Linked List
 * effects:   none
 */
char CharLinkedList::elementAt(int index) const
{
    if (index < 0 or index > numItems - 1)
    {
        throw range_error("index (" + std::to_string(index) + 
              ") not in range [0.." + std::to_string(numItems) + ")");  
    }
    
    if (index == 0){
        return first();
    } else if (index == numItems - 1){
        return last();
    } else {
        return recurseToIndex(front, index, 0);
    }
}

/*
 * name:      pushAtBack
 * purpose:   add a character to the back of the Linked List
 * arguments: character
 * returns:   none
 * effects:   a character is added to the back of the Linked List
 */
void CharLinkedList::pushAtBack(char c)
{
    if (isEmpty())
    {
        front = newNode(c, nullptr, nullptr);
        back = front;
        numItems = 1;
    } else {
        back->next = newNode(c, back, nullptr);
        back = back->next;
        numItems++;
    }
}

/*
 * name:      pushAtFront
 * purpose:   add a character to the front of the Linked List
 * arguments: character
 * returns:   none
 * effects:   a character is added to the front of the Linked List
 */
void CharLinkedList::pushAtFront(char c)
{
    if (isEmpty())
    {
        front = newNode(c, nullptr, nullptr);
        back = front;
        numItems = 1;
    } else {
        front->prev = newNode(c, nullptr, front);
        front = front->prev;
        numItems++;
    }
}


/*
 * name:      insertAt
 * purpose:   add a character at a specified index in the Linked List
 * arguments: character, integer index
 * returns:   none
 * effects:   a character is added at a specified index in the Linked List
 */
void CharLinkedList::insertAt(char c, int index)
{
    if (index < 0 or index > numItems){
        throw range_error("index (" + std::to_string(index) + 
              ") not in range [0.." + std::to_string(numItems) + "]");  
    }
    if (isEmpty()){
        front = newNode(c, nullptr, nullptr);
        back = front;
        numItems = 1;
    } else {
        if (index <= numItems / 2){
            if (index == 0){
                pushAtFront(c);
            } else {
                insertFromFront(c, index);
            }
        } else {
            if (index == numItems){
                pushAtBack(c);
            } else {
                insertFromBack(c, index);
            }
        }
    }
}

/*
 * name:      insertInOrder
 * purpose:   add a character to the Linked List in ASCII order
 * arguments: character
 * returns:   none
 * effects:   a character is added to the Linked List in ASCII order
 */
void CharLinkedList::insertInOrder(char c)
{
    Node *curr = front;
    int counter = 0;
    if (isEmpty()){
        front = newNode(c, nullptr, nullptr);
        back = front;
        numItems = 1;
        return;
    }
    if (front->data >= c){
        pushAtFront(c);
        return;
    }   
    if (back->data <= c){
        pushAtBack(c);
        return;
    }
    while (curr->next != nullptr){
        if (curr->data >= c){
            insertAt(c, counter);
            return;
        }
        curr = curr->next;
        counter++;
    }  
}

/*
 * name:      popFromFront
 * purpose:   remove a character from the front of the Linked List
 * arguments: none
 * returns:   none
 * effects:   a character is removed from the front of the Linked List
 */
void CharLinkedList::popFromFront()
{
    if (isEmpty()){
        throw runtime_error("cannot pop from empty LinkedList");
    }

    Node *temp = front;
    front = front->next;
    delete temp;

    numItems--;
}

/*
 * name:      popFromBack
 * purpose:   remove a character from the back of the Linked List
 * arguments: none
 * returns:   none
 * effects:   a character is removed from the back of the Linked List
 */
void CharLinkedList::popFromBack()
{
    if (isEmpty()){
        throw runtime_error("cannot pop from empty LinkedList");
    }

    Node *temp = back;

    if (numItems > 1)
    {
        back = back->prev;
        back->next = nullptr;
        delete temp;
    } else {
        back = nullptr;
        front = nullptr;
        delete temp;
    }

    numItems--;
}

/*
 * name:      removeAt
 * purpose:   remove a character from a specified index of the Linked List
 * arguments: integer index
 * returns:   none
 * effects:   a character is removed from a specified index of the Linked List
 */
void CharLinkedList::removeAt(int index)
{
    if (index < 0 or index > numItems - 1)
    {
        throw range_error("index (" + std::to_string(index) + 
              ") not in range [0.." + std::to_string(numItems) + ")");  
    }
    if (index == 0){
        popFromFront();
    } else if (index == numItems - 1){
        popFromBack();
    } else {
        removeAtFromFront(index);
    }
}

/*
 * name:      replaceAt
 * purpose:   replace a character at a specified index of the Linked List
 * arguments: character, integer index
 * returns:   none
 * effects:   a character is replaced at a specified index of the Linked List
 */
void CharLinkedList::replaceAt(char c, int index)
{
    if (index < 0 or index > numItems - 1)
    {
        throw range_error("index (" + std::to_string(index) + 
              ") not in range [0.." + std::to_string(numItems) + ")");  
    }

    Node *element = recursiveReplace(front, index, 0);
    element->data = c;
}

/*
 * name:      concatenate
 * purpose:   add one Linked List to the end of another
 * arguments: CharLinkedList
 * returns:   none
 * effects:   the Linked List is concatenated with another Linked List
 */
void CharLinkedList::concatenate(CharLinkedList *other)
{
    int numItemsOther = other->numItems;

    for (int i = 0; i < numItemsOther; i++)
    {
        pushAtBack(other->elementAt(i));
    }
}


//--------------------------Private-Helper-Functions--------------------------//

/*
 * name:      newNode
 * purpose:   create a new node
 * arguments: new data character, node pointers for the previous and next nodes
 * returns:   none
 * effects:   a new node is created
 */
CharLinkedList::Node *CharLinkedList::newNode(char newData, Node *prev, 
                                                            Node *next)
{
    Node *newElement = new Node;
    newElement->data = newData;
    newElement->prev = prev;
    newElement->next = next;

    return newElement;
}

/*
 * name:      recursiveDestruct
 * purpose:   recycle the memory associated with the Linked List
 * arguments: Node pointer to the front of the list
 * returns:   none
 * effects:   the Linked List is deleted
 */
void CharLinkedList::recursiveDestruct(Node *curr)
{
    if (curr == nullptr)
    {
        return;
    }
    else
    {
        Node *nextUp = curr->next;
        delete curr;
        recursiveDestruct(nextUp);
    }
}

/*
 * name:      recurseToIndex
 * purpose:   return the character at a given index
 * arguments: a node pointer to the front, an index, a counter which starts at 0
 * returns:   none
 * effects:   a character is returned
 */
char CharLinkedList::recurseToIndex(Node *curr, int index, int counter) const
{

    if (counter == index)
    {
        return curr->data;
    }
    else
    {
        Node *nextUp = curr->next;
        counter++;
        return recurseToIndex(nextUp, index, counter);
    }
}

/*
 * name:      insertFromFront
 * purpose:   insert a character starting moving from the front of the list
 * arguments: a character to add and an int index to add it at
 * returns:   none
 * effects:   a charcter is added at the given index
 */
void CharLinkedList::insertFromFront(char c, int index)
{
    Node *curr = front;
    int counter = 0;
                
    while (curr->next != nullptr and counter != index){
        curr = curr->next;
        counter++;
    }
    curr = newNode(c, curr->prev, curr);
    curr->prev->next = curr;
    curr->next->prev = curr;
    numItems++;
}

/*
 * name:      insertFromBack
 * purpose:   insert a character starting moving from the back of the list
 * arguments: a character to add and an int index to add it at
 * returns:   none
 * effects:   a charcter is added at the given index
 */
void CharLinkedList::insertFromBack(char c, int index)
{
    Node *curr = back;
    int counter = 0;
    
    while (curr->prev != nullptr and counter != index){
        curr = curr->prev;
        counter++;
    }
    curr = newNode(c, curr->prev, curr);
    curr->prev->next = curr;
    curr->next->prev = curr;
    numItems++;
}

/*
 * name:      removeAtFromFront
 * purpose:   remove a character starting moving from the front of the list
 * arguments: an int index to add it at
 * returns:   none
 * effects:   a charcter is removed from the given index
 */
void CharLinkedList::removeAtFromFront(int index)
{
    Node *curr = front;
    int counter = 0;
                
    while (curr->next != nullptr and counter != index){
        curr = curr->next;
        counter++;
    }

    Node *temp = curr;
    curr->prev->next = curr->next;
    curr->next->prev = curr->prev;
    delete temp;
    numItems--;
}

/*
 * name:      removeAtFromBack
 * purpose:   remove a character starting moving from the back of the list
 * arguments: an int index to add it at
 * returns:   none
 * effects:   a charcter is removed from the given index
 */
void CharLinkedList::removeAtFromBack(int index)
{
    Node *curr = back;
    int counter = 0;
    
    while (curr->prev != nullptr and counter != index){
        curr = curr->prev;
        counter++;
    }

    Node *temp = curr;

    if (numItems > 1)
    {
        curr->prev->next = curr->next;
        curr->next->prev = curr->prev;
        delete temp;
    } else {
        back = nullptr;
        front = nullptr;
        delete temp;
    }

    numItems--;
}

/*
 * name:      recursiveReplace
 * purpose:   return a node at an index to replace at
 * arguments: a pointer to a node, an int index, and a counter starting at 0
 * returns:   none
 * effects:   a charcter is removed from the given index
 */
CharLinkedList::Node *CharLinkedList::recursiveReplace(Node *curr, int index, 
                                                       int counter)
{
    if (counter == index)
    {
        return curr;
    }
    else
    {
        Node *nextUp = curr->next;
        counter++;
        return recursiveReplace(nextUp, index, counter);
    }
}
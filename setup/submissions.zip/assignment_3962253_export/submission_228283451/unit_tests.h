/*
 *  unit_tests.h
 *  Rachel Snyder (rsnyde02)
 *  02/01/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  Test functions in the CharLinkedList class
 *
 */
#include "CharLinkedList.h"
#include <cassert>
#include <iostream>

using namespace std;

/********************************************************************\
*                       CHAR LINKED LIST TESTS                        *
\********************************************************************/


//-----------------------------Default-Constructor----------------------------//

// default_constructor_test_0
// Makes sure no fatal errors/memory leaks in the default constructor
void default_constructor_test_0() 
{
    CharLinkedList list;
}

// default_constructor_test_1
// Make sure no items exist in the list upon construction
void default_constructor_test_1()
{
    CharLinkedList list;
    assert(list.size() == 0);
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}

//---------------------------END-Default-Constructor--------------------------//

//------------------------------Char-Constructor------------------------------//

// char_constructor_test
// Makes sure the list has exacly one piece of data in it
void char_constructor_test() 
{
    CharLinkedList list('a');
    assert(list.size() == 1);
    assert(list.toString() == "[CharLinkedList of size 1 <<a>>]");
}

//----------------------------END-Char-Constructor----------------------------//

//------------------------------Array-Constructor-----------------------------//

// array_constructor_test
// Makes sure the list has the size and data specified by the user
void array_constructor_test_full()
{
    char testArray[6] = {'R', 'a', 'b', 'b', 'i', 't'};
    CharLinkedList list(testArray, 6);
    assert(list.size() == 6);
    assert(list.toString() == "[CharLinkedList of size 6 <<Rabbit>>]");
}

void array_constructor_test_char()
{
    char testArray[1] = {'R'};
    CharLinkedList list(testArray, 1);
    assert(list.size() == 1);
    assert(list.toString() == "[CharLinkedList of size 1 <<R>>]");
}

void array_constructor_test_empty()
{
    char testArray[0];
    CharLinkedList list(testArray, 0);
    assert(list.size() == 0);
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}

//----------------------------END-Array-Constructor---------------------------//

//------------------------------Copy-Constructor------------------------------//

//copy_constructor_test_full
//Makes sure the copy constructor works properly on a full list
void copy_constructor_test_full()
{
    char testArray[5] = {'A', 'b', 'c', 'd', 'e'};
    CharLinkedList list1(testArray, 5);
    CharLinkedList list2(list1);

    assert(list1.toString() == "[CharLinkedList of size 5 <<Abcde>>]");
    assert(list2.toString() == "[CharLinkedList of size 5 <<Abcde>>]");
}

//copy_constructor_test_char
//Makes sure the copy constructor works properly on a list with one character
void copy_constructor_test_char()
{
    CharLinkedList list1('r');
    CharLinkedList list2(list1);

    assert(list1.toString() == "[CharLinkedList of size 1 <<r>>]");
    assert(list2.toString() == "[CharLinkedList of size 1 <<r>>]");
}

//copy_constructor_test_empty
//Makes sure the copy constructor works properly on an empty list
void copy_constructor_test_empty()
{
    CharLinkedList list1;
    CharLinkedList list2(list1);

    assert(list1.toString() == "[CharLinkedList of size 0 <<>>]");
    assert(list2.toString() == "[CharLinkedList of size 0 <<>>]");
}

//----------------------------END-Copy-Constructor----------------------------//

//-----------------------------Assignment-Operator----------------------------//

//assignment_operator_test_full
//Makes sure the assignment operator works properly on a full list
void assignment_operator_test_full()
{
    char testArray1[5] = {'A', 'b', 'c', 'd', 'e'};
    char testArray2[7] = {'f', 'g', 'h', 'i', 'j', 'k', 'l'};
    CharLinkedList list1(testArray1, 5);
    CharLinkedList list2(testArray2, 7);

    assert(list1.toString() == "[CharLinkedList of size 5 <<Abcde>>]");
    assert(list2.toString() == "[CharLinkedList of size 7 <<fghijkl>>]");

    list2 = list1;

    assert(list1.toString() == "[CharLinkedList of size 5 <<Abcde>>]");
    assert(list2.toString() == "[CharLinkedList of size 5 <<Abcde>>]");
}

//assignment_operator_test_char
//Makes sure the assignment operator works properly on a list with one character
void assignment_operator_test_char()
{
    char testArray2[7] = {'f', 'g', 'h', 'i', 'j', 'k', 'l'};
    CharLinkedList list1('r');
    CharLinkedList list2(testArray2, 7);

    assert(list1.toString() == "[CharLinkedList of size 1 <<r>>]");
    assert(list2.toString() == "[CharLinkedList of size 7 <<fghijkl>>]");

    list2 = list1;

    assert(list1.toString() == "[CharLinkedList of size 1 <<r>>]");
    assert(list2.toString() == "[CharLinkedList of size 1 <<r>>]");
}

//assignment_operator_test_empty1
//Makes sure the assignment operator works properly on an empty list getting 
//assigned
void assignment_operator_test_empty1()
{
    char testArray2[7] = {'f', 'g', 'h', 'i', 'j', 'k', 'l'};
    CharLinkedList list1;
    CharLinkedList list2(testArray2, 7);

    assert(list1.toString() == "[CharLinkedList of size 0 <<>>]");
    assert(list2.toString() == "[CharLinkedList of size 7 <<fghijkl>>]");

    list2 = list1;

    assert(list1.toString() == "[CharLinkedList of size 0 <<>>]");
    assert(list2.toString() == "[CharLinkedList of size 0 <<>>]");
}

//assignment_operator_test_empty2
//Makes sure the assignment operator works properly on an empty list being 
//assigned
void assignment_operator_test_empty2()
{
    char testArray2[7] = {'f', 'g', 'h', 'i', 'j', 'k', 'l'};
    CharLinkedList list1;
    CharLinkedList list2(testArray2, 7);

    assert(list1.toString() == "[CharLinkedList of size 0 <<>>]");
    assert(list2.toString() == "[CharLinkedList of size 7 <<fghijkl>>]");

    list1 = list2;

    assert(list1.toString() == "[CharLinkedList of size 7 <<fghijkl>>]");
    assert(list2.toString() == "[CharLinkedList of size 7 <<fghijkl>>]");
}

//---------------------------END-Assignment-Operator--------------------------//

//----------------------------------toString()--------------------------------//

//to_string_test
//Makes sure a full list gets turned into a string in the right format
void to_string_test_full()
{
    char testArray[6] = {'R', 'a', 'b', 'b', 'i', 't'};
    CharLinkedList list(testArray, 6);

    cout << "Full List: " << list.toString() << endl;
    assert(list.toString() == "[CharLinkedList of size 6 <<Rabbit>>]");
}

//to_string_test_char
//Makes sure a single char list gets turned into a string in the right format
void to_string_test_char()
{
    CharLinkedList list('r');

    cout << "Singleton List: " << list.toString() << endl;
    assert(list.toString() == "[CharLinkedList of size 1 <<r>>]");
}

//to_string_test_empty
//Makes sure an empty list gets turned into a string in the right format
void to_string_test_empty()
{
    CharLinkedList emptyList;

    cout << "Empty List: " << emptyList.toString() << endl;
    assert(emptyList.toString() == "[CharLinkedList of size 0 <<>>]");
}

//-------------------------------END-toString()-------------------------------//

//------------------------------toReverseString()-----------------------------//

//to_reverse_string_test_full
//Makes sure a full list gets turned into a reverse string in the right format
void to_reverse_string_test_full()
{
    char testArray[6] = {'R', 'a', 'b', 'b', 'i', 't'};
    CharLinkedList list(testArray, 6);

    cout << "Full List: " << list.toReverseString() << endl;
    assert(list.toReverseString() == "[CharLinkedList of size 6 <<tibbaR>>]");
}

//to_reverse_string_test_char
//Makes sure a single char list gets turned into a reverse string in the right 
//format
void to_reverse_string_test_char()
{
    CharLinkedList list('r');

    cout << "Singleton List: " << list.toReverseString() << endl;
    assert(list.toReverseString() == "[CharLinkedList of size 1 <<r>>]");
}

//to_reverse_string_test_empty
//Makes sure an empty list gets turned into a reverse string in the right format
void to_reverse_string_test_empty()
{
    CharLinkedList emptyList;

    cout << "Empty List: " << emptyList.toReverseString() << endl;
    assert(emptyList.toReverseString() == "[CharLinkedList of size 0 <<>>]");
}


//----------------------------END-toReverseString()---------------------------//

//----------------------------------isEmpty()---------------------------------//

//is_empty_test_true
//Makes sure the array is correctly identified as empty
void is_empty_test_true()
{
    CharLinkedList list;

    assert(list.isEmpty());
}

//is_empty_test_false
//Makes sure the array is correctly identified as not empty
void is_empty_test_false()
{
    char testArray[6] = {'R', 'a', 'b', 'b', 'i', 't'};
    CharLinkedList list(testArray, 6);

    assert(not list.isEmpty());
}

//--------------------------------END-isEmpty()-------------------------------//

//-----------------------------------clear()----------------------------------//

//clear_test
//Makes sure the array gets cleared when called
void clear_test()
{
    char testArray[6] = {'R', 'a', 'b', 'b', 'i', 't'};
    CharLinkedList list(testArray, 6);
    assert(not list.isEmpty());

    list.clear();

    assert(list.isEmpty());
}

//---------------------------------END-clear()--------------------------------//

//-----------------------------------first()----------------------------------//

//first_test_full
//Makes sure the first element is returned from a full list
void first_test_full()
{
    char testArray[6] = {'R', 'a', 'b', 'b', 'i', 't'};
    CharLinkedList list(testArray, 6);

    assert(list.first() == 'R');
}

//first_test_char
//Makes sure the first element is returned from a single char list
void first_test_char()
{
    CharLinkedList list('R');

    assert(list.first() == 'R');
}


//first_test_empty
//Makes sure the runtime error is thrown when list is empty
void first_test_empty()
{
    CharLinkedList list;

    bool runtime_error_thrown = false;

    std::string error_message = "";

    try 
    {
        list.first();
    }
    catch (const std::runtime_error &e) 
    {
        runtime_error_thrown = true;
        error_message = e.what();
    }


    assert(runtime_error_thrown);
    assert(error_message == "cannot get first of empty LinkedList");
}

//---------------------------------END-first()--------------------------------//

//-----------------------------------last()-----------------------------------//

//last_test_full
//Makes sure the last element is returned from a full list
void last_test_full()
{
    char testArray[6] = {'R', 'a', 'b', 'b', 'i', 't'};
    CharLinkedList list(testArray, 6);

    assert(list.last() == 't');
}

//last_test_char
//Makes sure the last element is returned from a single char list
void last_test_char()
{
    CharLinkedList list('R');

    assert(list.last() == 'R');
}


//last_test_empty
//Makes sure the runtime error is thrown when list is empty
void last_test_empty()
{
    CharLinkedList list;

    bool runtime_error_thrown = false;

    std::string error_message = "";

    try 
    {
        list.last();
    }
    catch (const std::runtime_error &e) 
    {
        runtime_error_thrown = true;
        error_message = e.what();
    }


    assert(runtime_error_thrown);
    assert(error_message == "cannot get last of empty LinkedList");
}

//---------------------------------END-last()---------------------------------//

//---------------------------------elementAt()--------------------------------//

//element_at_test_full
//Makes sure the specified element is returned from a full list
void element_at_test_full()
{
    char testArray[6] = {'R', 'a', 'b', 'b', 'i', 't'};
    CharLinkedList list(testArray, 6);

    assert(list.elementAt(3) == 'b');
}

//element_at_test_empty
//Makes sure the range error is thrown correctly
void element_at_test_empty()
{
    CharLinkedList list;

    bool range_error_thrown = false;

    std::string error_message = "";

    try 
    {
        list.elementAt(3);
    }
    catch (const std::range_error &e) 
    {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (3) not in range [0..0)");
}

//-------------------------------END-elementAt()------------------------------//

//---------------------------------pushAtBack()-------------------------------//

//push_at_back_test_full
//Makes sure the specified element added to the back of a full list
void push_at_back_test_full()
{
    char testArray[6] = {'R', 'a', 'b', 'b', 'i', 't'};
    CharLinkedList list(testArray, 6);
    assert(list.toString() == "[CharLinkedList of size 6 <<Rabbit>>]");
    assert(list.size() == 6);

    list.pushAtBack('s');
    assert(list.toString() == "[CharLinkedList of size 7 <<Rabbits>>]");
    assert(list.size() == 7);

    list.pushAtBack('t');
    list.pushAtBack('e');
    list.pushAtBack('s');
    list.pushAtBack('t');
    list.pushAtBack('i');
    list.pushAtBack('n');
    list.pushAtBack('g');

    assert(list.toString() == "[CharLinkedList of size 14 <<Rabbitstesting>>]");
    assert(list.size() == 14);
}

//push_at_back_test_empty
//Makes sure the specified element added to the back of an empty list
void push_at_back_test_empty()
{
    CharLinkedList list;
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
    assert(list.size() == 0);

    list.pushAtBack('R');
    assert(list.toString() == "[CharLinkedList of size 1 <<R>>]");
    assert(list.size() == 1);
}

//-------------------------------END-pushAtBack()-----------------------------//

//--------------------------------pushAtFront()-------------------------------//

//push_at_front_test_full
//Makes sure the specified element added to the front of a full list
void push_at_front_test_full()
{
    char testArray[6] = {'R', 'a', 'b', 'b', 'i', 't'};
    CharLinkedList list(testArray, 6);
    assert(list.toString() == "[CharLinkedList of size 6 <<Rabbit>>]");
    assert(list.size() == 6);

    list.pushAtFront('g');
    assert(list.toString() == "[CharLinkedList of size 7 <<gRabbit>>]");
    assert(list.size() == 7);

    list.pushAtFront('n');
    list.pushAtFront('i');
    list.pushAtFront('t');
    list.pushAtFront('s');
    list.pushAtFront('e');
    list.pushAtFront('t');
 
    assert(list.toString() == "[CharLinkedList of size 13 <<testingRabbit>>]");
    assert(list.size() == 13);
}

//push_at_front_test_empty
//Makes sure the specified element added to the front of an empty list
void push_at_front_test_empty()
{
    CharLinkedList list;
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
    assert(list.size() == 0);

    list.pushAtFront('R');
    assert(list.toString() == "[CharLinkedList of size 1 <<R>>]");
    assert(list.size() == 1);
}

//------------------------------END-pushAtFront()-----------------------------//

//---------------------------------InsertAt()---------------------------------//

/* To give an example of thorough testing, we are providing
 * the unit tests below which test the insertAt function. Notice: we have
 * tried to consider all of the different cases insertAt may be
 * called in, and we test insertAt in conjunction with other functions!
 *
 * You should emulate this approach for all functions you define.
 */


// Tests correct insertion into an empty LL.
// Afterwards, size should be 1 and element at index 0
// should be the element we inserted.
void insertAt_empty_correct() { 

    CharLinkedList test_list;
    test_list.insertAt('a', 0);
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');

}

// Tests incorrect insertion into an empty LL.
// Attempts to call insertAt for index larger than 0.
// This should result in an std::range_error being raised.
void insertAt_empty_incorrect() {

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    // insertAt for out-of-range index
    test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
    // if insertAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    range_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0]");
    
}

// Tests correct insertAt for front of 1-element list.
void insertAt_front_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at front
    test_list.insertAt('b', 0);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'a');
    
}

// Tests correct insertAt for back of 1-element list.
void insertAt_back_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at back
    test_list.insertAt('b', 1);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    
}

// Tests calling insertAt for a large number of elements.
void insertAt_many_elements() {
    
    CharLinkedList test_list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.insertAt('a', i);
    }

    assert(test_list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
    
}

// Tests insertion into front of a larger list
void insertAt_front_large_list() {
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    test_list.insertAt('y', 0);

    assert(test_list.size() == 10);
    assert(test_list.elementAt(0) == 'y');
    assert(test_list.toString() == 
    "[CharLinkedList of size 10 <<yabczdefgh>>]");

}

// Tests insertion into the back of a larger list
void insertAt_back_large_list() {

    char test_arr[10] = { 'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 10);  

    test_list.insertAt('x', 10);

    assert(test_list.size() == 11);
    assert(test_list.elementAt(10) == 'x');
    assert(test_list.toString() == 
    "[CharLinkedList of size 11 <<yabczdefghx>>]"); 

}

// Tests insertion into the middle of a larger list
void insertAt_middle_large_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.insertAt('z', 3);

    assert(test_list.size() == 9);
    assert(test_list.elementAt(3) == 'z');
    assert(test_list.toString() == "[CharLinkedList of size 9 <<abczdefgh>>]");
    

}

// Tests out-of-range insertion for a non-empty list.
void insertAt_nonempty_incorrect() {
   
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8]");
    
}

//-------------------------------END-InsertAt()-------------------------------//

//------------------------------insertInOrder()-------------------------------//

//insert_in_order_test_middle
//Makes sure the specified element added in the correct place in list in the
//middle of a list
void insert_in_order_test_middle()
{
    char testArray[5] = {'a', 'b', 'd', 'e', 'f'};
    CharLinkedList list(testArray, 5);
    assert(list.toString() == "[CharLinkedList of size 5 <<abdef>>]");
    assert(list.size() == 5);

    list.insertInOrder('c');

    assert(list.toString() == "[CharLinkedList of size 6 <<abcdef>>]");
    assert(list.size() == 6);
}

//insert_in_order_test_front
//Makes sure the specified element added in the correct place in list in the
//front of a list
void insert_in_order_test_front()
{
    char testArray[5] = {'g', 'h', 'i', 'j', 'k'};
    CharLinkedList list(testArray, 5);
    assert(list.toString() == "[CharLinkedList of size 5 <<ghijk>>]");
    assert(list.size() == 5);

    list.insertInOrder('a');
    assert(list.toString() == "[CharLinkedList of size 6 <<aghijk>>]");
    assert(list.size() == 6);
}

//insert_in_order_test_back
//Makes sure the specified element added in the correct place in list in the
//back of a list
void insert_in_order_test_back()
{
    char testArray[5] = {'b', 'c', 'd', 'e', 'f'};
    CharLinkedList list(testArray, 5);
    assert(list.toString() == "[CharLinkedList of size 5 <<bcdef>>]");
    assert(list.size() == 5);

    list.insertInOrder('x');
    assert(list.toString() == "[CharLinkedList of size 6 <<bcdefx>>]");
    assert(list.size() == 6);
}

//Makes sure the specified element added correctly to an empty list
void insert_in_order_test_empty()
{
    CharLinkedList list;
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
    assert(list.size() == 0);

    list.insertInOrder('x');

    assert(list.toString() == "[CharLinkedList of size 1 <<x>>]");
    assert(list.size() == 1);
}

//-----------------------------END-insertInOrder()----------------------------//

//-------------------------------popFromFront()-------------------------------//

//pop_from_front_test_full
//Make sure the first element is removed from a full list
void pop_from_front_test_full()
{
    char testArray[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(testArray, 5);
    assert(list.toString() == "[CharLinkedList of size 5 <<abcde>>]");
    assert(list.size() == 5);

    list.popFromFront();

    assert(list.toString() == "[CharLinkedList of size 4 <<bcde>>]");
    assert(list.size() == 4);
}

//pop_from_front_test_char
//Make sure the first element is removed from a single char list
void pop_from_front_test_char()
{
    CharLinkedList list('a');
    assert(list.toString() == "[CharLinkedList of size 1 <<a>>]");
    assert(list.size() == 1);

    list.popFromFront();

    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
    assert(list.size() == 0);
}

//pop_from_front_test_empty
//Make sure the runtime error is thrown when the list is empty
void pop_from_front_test_empty()
{
    CharLinkedList list;

    bool runtime_error_thrown = false;

    std::string error_message = "";

    try 
    {
        list.popFromFront();
    }
    catch (const std::runtime_error &e) 
    {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

//-----------------------------END-popFromFront()-----------------------------//

//--------------------------------popFromBack()-------------------------------//

//pop_from_back_test_full
//Make sure the last element is removed from a full list
void pop_from_back_test_full()
{
    char testArray[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(testArray, 5);
    assert(list.toString() == "[CharLinkedList of size 5 <<abcde>>]");
    assert(list.size() == 5);

    list.popFromBack();

    assert(list.toString() == "[CharLinkedList of size 4 <<abcd>>]");
    assert(list.size() == 4);
    
}

//pop_from_back_test_char
//Make sure the last element is removed from a single char list
void pop_from_back_test_char()
{
    CharLinkedList list('a');
    assert(list.toString() == "[CharLinkedList of size 1 <<a>>]");
    assert(list.size() == 1);

    list.popFromBack();

    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
    assert(list.size() == 0);
}

//pop_from_back_test_empty
//Make sure the runtime error is thrown when the list is empty
void pop_from_back_test_empty()
{
    CharLinkedList list;

    bool runtime_error_thrown = false;

    std::string error_message = "";

    try 
    {
        list.popFromBack();
    }
    catch (const std::runtime_error &e) 
    {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

//------------------------------END-popFromBack()-----------------------------//

//---------------------------------removeAt()---------------------------------//

//remove_at_test_middle 
//Make sure the specified element is removed from the middle of a list
void remove_at_test_middle()
{
    char testArray[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(testArray, 5);
    assert(list.toString() == "[CharLinkedList of size 5 <<abcde>>]");
    assert(list.size() == 5);

    list.removeAt(3);

    assert(list.toString() == "[CharLinkedList of size 4 <<abce>>]");
    assert(list.size() == 4);
}

//remove_at_test_front
//Make sure the specified element is removed from the front of a list
void remove_at_test_front()
{
    char testArray[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(testArray, 5);
    assert(list.toString() == "[CharLinkedList of size 5 <<abcde>>]");
    assert(list.size() == 5);

    list.removeAt(0);
    assert(list.toString() == "[CharLinkedList of size 4 <<bcde>>]");
    assert(list.size() == 4);
}

//remove_at_test_back
//Make sure the specified element is removed from the back of a list
void remove_at_test_back()
{
    char testArray[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(testArray, 5);
    assert(list.toString() == "[CharLinkedList of size 5 <<abcde>>]");
    assert(list.size() == 5);

    list.removeAt(list.size() - 1);
    assert(list.toString() == "[CharLinkedList of size 4 <<abcd>>]");
    assert(list.size() == 4);
}

//remove_at_test_back
//Make sure the range error is thrown correctly
void remove_at_test_incorrect()
{
    char testArray[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(testArray, 5);

    bool range_error_thrown = false;

    std::string error_message = "";

    try 
    {
        list.removeAt(5);
    }
    catch (const std::runtime_error &e) 
    {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (5) not in range [0..5)");
}

//-------------------------------END-removeAt()-------------------------------//

//---------------------------------replaceAt()--------------------------------//

//replace_at_test_full
//Make sure the specified element is replaced in a full list
void replace_at_test_full()
{
    char testArray[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(testArray, 5);
    assert(list.toString() == "[CharLinkedList of size 5 <<abcde>>]");
    assert(list.size() == 5);

    list.replaceAt('r', 3);

    assert(list.toString() == "[CharLinkedList of size 5 <<abcre>>]");   
    assert(list.size() == 5);

}

//replace_at_test_incorrect
//Make sure the range error is thrown correctly
void replace_at_test_incorrect()
{
    char testArray[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(testArray, 5);

    bool range_error_thrown = false;

    std::string error_message = "";

    try 
    {
        list.replaceAt('r', 7);
    }
    catch (const std::runtime_error &e) 
    {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (7) not in range [0..5)");
}

//-------------------------------END-replaceAt()------------------------------//

//--------------------------------concatenate()-------------------------------//

//concatenate_test_two_full
//Make sure two full lists concatenate properly
void concatenate_test_two_full()
{
    char testArray1[4] = {'j', 'a', 'c', 'k'};
    char testArray2[7] = {'r', 'a', 'b', 'b', 'i', 't', 's'};
    CharLinkedList list1(testArray1, 4);
    CharLinkedList list2(testArray2, 7);

    assert(list1.toString() == "[CharLinkedList of size 4 <<jack>>]"); 
    assert(list2.toString() == "[CharLinkedList of size 7 <<rabbits>>]");
    assert(list1.size() == 4);
    assert(list2.size() == 7);

    list1.concatenate(&list2);

    assert(list1.toString() == "[CharLinkedList of size 11 <<jackrabbits>>]"); 
    assert(list2.toString() == "[CharLinkedList of size 7 <<rabbits>>]");
    assert(list1.size() == 11);
    assert(list2.size() == 7);

}

//concatenate_test_copy
//Make sure a list can concatenate with itself
void concatenate_test_copy()
{
    char testArray[7] = {'r', 'a', 'b', 'b', 'i', 't', 's'};
    CharLinkedList list(testArray, 7);

    assert(list.toString() == "[CharLinkedList of size 7 <<rabbits>>]");
    assert(list.size() == 7);

    list.concatenate(&list);

    assert(list.toString() == "[CharLinkedList of size 14 <<rabbitsrabbits>>]");
    assert(list.size() == 14);
}

//concatenate_test_first_empty
//Make sure an empty list can concatenate with a full list
void concatenate_test_first_empty()
{
    char testArray[7] = {'r', 'a', 'b', 'b', 'i', 't', 's'};
    CharLinkedList list1;
    CharLinkedList list2(testArray, 7);

    assert(list1.toString() == "[CharLinkedList of size 0 <<>>]");
    assert(list2.toString() == "[CharLinkedList of size 7 <<rabbits>>]");
    assert(list1.size() == 0);
    assert(list2.size() == 7);

    list1.concatenate(&list2);

    assert(list1.toString() == "[CharLinkedList of size 7 <<rabbits>>]");
    assert(list2.toString() == "[CharLinkedList of size 7 <<rabbits>>]");
    assert(list1.size() == 7);
    assert(list2.size() == 7);
}

//concatenate_test_second_empty
//Make sure a full list can concatenate with an empty list
void concatenate_test_second_empty()
{
    char testArray[7] = {'r', 'a', 'b', 'b', 'i', 't', 's'};
    CharLinkedList list1(testArray, 7);
    CharLinkedList list2;

    assert(list1.toString() == "[CharLinkedList of size 7 <<rabbits>>]");
    assert(list2.toString() == "[CharLinkedList of size 0 <<>>]");
    assert(list1.size() == 7);
    assert(list2.size() == 0);

    list1.concatenate(&list2);

    assert(list1.toString() == "[CharLinkedList of size 7 <<rabbits>>]");
    assert(list2.toString() == "[CharLinkedList of size 0 <<>>]");
    assert(list1.size() == 7);
    assert(list2.size() == 0);
}

//concatenate_test_both_empty
//Make sure two empty lists can concatenate
void concatenate_test_both_empty()
{
    CharLinkedList list1;
    CharLinkedList list2;

    assert(list1.toString() == "[CharLinkedList of size 0 <<>>]");
    assert(list2.toString() == "[CharLinkedList of size 0 <<>>]");
    assert(list1.size() == 0);
    assert(list2.size() == 0);

    list1.concatenate(&list2);

    assert(list1.toString() == "[CharLinkedList of size 0 <<>>]");
    assert(list2.toString() == "[CharLinkedList of size 0 <<>>]");
    assert(list1.size() == 0);
    assert(list2.size() == 0);
}

//------------------------------END-concatenate()-----------------------------//


/*
 *  CharLinkedList.cpp
 *  Justin Yang
 *  2/2/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Function definitions for the CharLinkedList class
 *
 */

#include "CharLinkedList.h"
#include <stdexcept>

/* Purpose: Initializes an empty LinkedList */
CharLinkedList::CharLinkedList() {
    front = nullptr;
    back = nullptr;
    numItems  = 0;
}

/* Purpose: Initializes a LinkedList with one element*/
CharLinkedList::CharLinkedList(char c) {
    front = new Node(c);
    back = front;
    numItems  = 1;
}

/* Purpose: Initializes a LinkedList with an array*/
CharLinkedList::CharLinkedList(char arr[], int size) {
    // initialize a new list
    front = nullptr;
    back = nullptr;
    numItems  = 0;

    // push them into the back
    for (int i = 0; i < size; i++) {
        pushAtBack(arr[i]);
    }
}

/*
 * name:      CharLinkedList copy constructor
 * purpose:   initialize a CharLinkedList as a copy of another one
 * arguments: a CharLinkedList
 * returns:   none
 * effects:   makes a new linked list that is a deep copy of the given one
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other) {
    front = nullptr;
    back = nullptr;
    numItems = 0;

    for (int i = 0; i < other.numItems; i++) {
        pushAtBack(other.elementAt(i));
    }
}

/*
 * name:      CharLinkedList destructor
 * purpose:   free memory associated with the CharLinkedList
 * arguments: none
 * returns:   none
 * effects:   frees memory allocated by CharLinkedlist instances
 */
CharLinkedList::~CharLinkedList() {
    Node *temp;
    while (front != nullptr) {
        temp = front;
        front = front->next;
        delete temp;
    }
}

/*
 * name:      CharLinkedList assignment operator
 * purpose:   make the operator "=" copy the linked list on the right
 * arguments: a CharLinkedList
 * returns:   none
 * effects:   makes the operator "=" copy the linked list on the right
 */
CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other) {
    if (this == &other) {
        return *this;
    }

    front = nullptr;
    back = nullptr;
    numItems = 0;

    for (int i = 0; i < other.numItems; i++) {
        pushAtBack(other.elementAt(i));
    }

    return *this;
    
}

/*
 * name:      isEmpty
 * purpose:   determines if the LinkedList is empty or not
 * arguments: none
 * returns:   true if LinkedList contains no elements, false otherwise
 * effects:   none
 */
bool CharLinkedList::isEmpty() const {
    return numItems == 0;
}

/*
 * name:      clear
 * purpose:   empty a linked list
 * arguments: none
 * returns:   none
 * effects:   turn a linked list into an empty one
 */
void CharLinkedList::clear() {
    while (front != nullptr) {
        popFromFront();
    }
}

/*
 * name:      size
 * purpose:   determine the number of items in the LinkedList
 * arguments: none
 * returns:   number of elements currently stored in the LinkedList
 * effects:   none
 */
int CharLinkedList::size() const {
    return numItems;
}

/*
 * name:      first
 * purpose:   find the first value in the linked list
 * arguments: none
 * returns:   the first char in the linked list
 * effects:   none
 */
char CharLinkedList::first() const {
    if (front == nullptr) {
        throw runtime_error("cannot get first of empty LinkedList");
    }

    return front->data;
}

/*
 * name:      last
 * purpose:   find the last value in the linked list
 * arguments: none
 * returns:   the last char in the linked list
 * effects:   none
 */
char CharLinkedList::last() const {
    if (front == nullptr) {
        throw runtime_error("cannot get last of empty LinkedList");
    }

    return back->data;
}

/*
 * name:      toString
 * purpose:   get the linked list as a string
 * arguments: none
 * returns:   the elements of the linked list as a string
 * effects:   none
 */
std::string CharLinkedList::toString() const {
    std::string str = "";
    Node *curr = front;
    while (curr != nullptr) {
        str += curr->data;
        curr = curr->next;
    }

    return "[CharLinkedList of size " + to_string(numItems) + " <<" + str + ">>]";
}

/*
 * name:      toReverseString
 * purpose:   get the linked list as a string but backwards
 * arguments: none
 * returns:   the elements of the linked list as a string but backwards
 * effects:   none
 */
std::string CharLinkedList::toReverseString() const {
    std::string str = "";
    Node *curr = back;
    while (curr != nullptr) {
        str += curr->data;
        curr = curr->prev;
    }

    return "[CharLinkedList of size " + to_string(numItems) + " <<" + str + ">>]";
}

/* 
 * pushAtBack
 *    Purpose: Adds a char to the back of the list
 * Parameters: The char to be added to the list
 *    Returns: None
 */
void CharLinkedList::pushAtBack(char c) {
    // if the list is empty just put it at the front
    if (front == nullptr) {
        front = new Node(c);
        back = front;
    } else {
        // otherwise make a new node and put it at the back
        back->next = new Node(c);
        back->next->prev = back;
        back = back->next;
    }
    numItems++;
}

/* 
 * pushAtFront
 *    Purpose: Adds a char to the front of the list
 * Parameters: The char to be added to the list
 *    Returns: None
 */
void CharLinkedList::pushAtFront(char c) {
    // if the list is empty just put it at the front
    if (front == nullptr) {
        front = new Node(c);
        back = front;
    } else {
        // otherwise make a new node and put it at the front
        front->prev = new Node(c);
        front->prev->next = front;
        front = front->prev;
    }
    numItems++;
}

/*
 * name:      elementAt
 * purpose:   find the element at that index
 * arguments: an index
 * returns:   the element at that index
 * effects:   none
 */
char CharLinkedList::elementAt(int index) const {
    if (index < 0 or index >= numItems) {
        throw range_error("index (" + to_string(index) + ") not in range [0.." + to_string(numItems) + ")");
    }

    Node *curr = front;
    for (int i = 0; i < index; i++) {
        curr = curr->next;
    }
    return curr->data;
}

/*
 * name:      insertAt
 * purpose:   add an element at the given index of the linked list
 * arguments: a char to be added and the index of where to add
 * returns:   none
 * effects:   add the element to the index of the linked list
 */
void CharLinkedList::insertAt(char c, int index) {
    if (index < 0 or index > numItems) {
        throw range_error("index (" + to_string(index) + ") not in range [0.." + to_string(numItems) + "]");
    }

    // if its the front or back just push it there
    if (index == 0) pushAtFront(c);
    else if (index == numItems) pushAtBack(c);
    else {
        // get the node at that index
        Node *curr = front;
        for (int i = 0; i < index; i++) {
            curr = curr->next;
        }

        Node *temp = curr;
        curr = new Node(c);

        // shift everything around to fit the new node in
        temp->prev->next = curr;
        curr->next = temp;
        curr->prev = temp->prev;
        temp->prev = curr;

        numItems++;
    }
}

/*
 * name:      insertInOrder
 * purpose:   add an element into a sorted list in its correct spot
 * arguments: a char to be added
 * returns:   none
 * effects:   add the element into a sorted list in its correct spot
 */
void CharLinkedList::insertInOrder(char c) {
    Node *curr = front;
    int i = 0;
    while (curr != nullptr) {
        // see if any data points are "larger" then c
        if (c <= curr->data) {
            insertAt(c, i);
            return;
        }
        curr = curr->next;
        i++;
    }

    // if not just put it at the end
    pushAtBack(c);
}

/*
 * name:      removeAt
 * purpose:   remove the element at a certain index
 * arguments: the index of the element to remove
 * returns:   none
 * effects:   removes the element at a certain index
 */
void CharLinkedList::removeAt(int index) {
    if (index < 0 or index >= numItems) {
        throw range_error("index (" + to_string(index) + ") not in range [0.." + to_string(numItems) + ")");
    }

    // get the node at that index
    Node *curr = front;
    for (int i = 0; i < index; i++) {
        curr = curr->next;
    }

    // if its not the first value take it out
    if (curr->prev != nullptr) curr->prev->next = curr->next;
    
    else front = front->next;
    delete curr;
    

    numItems--;
}

/*
 * name:      popFromFront
 * purpose:   remove the element at the front of the list
 * arguments: none
 * returns:   none
 * effects:   remove the element from the front of the list
 */
void CharLinkedList::popFromFront() {
    if (front == nullptr) {
        throw runtime_error("cannot pop from empty LinkedList");
    }

    Node *temp = front;
    front = front->next;
    if (front != nullptr) front->prev = nullptr;
    delete temp;
    numItems--;
}

/*
 * name:      popFromBack
 * purpose:   remove the element at the back of the list
 * arguments: none
 * returns:   none
 * effects:   remove the element from the back of the list
 */
void CharLinkedList::popFromBack() {
    if (front == nullptr) {
        throw runtime_error("cannot pop from empty LinkedList");
    }

    Node *temp = back;
    back = back->prev;
    if (back != nullptr) back->next = nullptr;
    delete temp;
    numItems--;
}

/*
 * name:      replaceAt
 * purpose:   replace the element at a certain index
 * arguments: the index of the element to replace, and what to replace it with
 * returns:   none
 * effects:   replaces the element at a certain index
 */
void CharLinkedList::replaceAt(char c, int index) {
    if (index < 0 or index >= numItems) {
        throw range_error("index (" + to_string(index) + ") not in range [0.." + to_string(numItems) + ")");
    }

    // get the node at that index
    Node *curr = front;
    for (int i = 0; i < index; i++) {
        curr = curr->next;
    }

    curr->data = c;
}

/*
 * name:      concatenate
 * purpose:   copy a Linked list onto the end of the first linked list
 * arguments: the linked list to put onto the end of the first one
 * returns:   none
 * effects:   adds all the elements of the other linked list to the end of the first one
 */
void CharLinkedList::concatenate(CharLinkedList *other) {
    CharLinkedList list(*other);
    for (int i = 0; i < list.size(); i++) {
        pushAtBack(list.elementAt(i));
    }
}
/*
 *  unit_tests.h
 *  Justin Yang
 *  2/2/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  test the CharLinkedList class
 *
 */

#include "CharLinkedList.h"
#include <cassert>

/*
 * constructor test 0
 * Make sure no fatal errors/memory leaks in the default constructor
 */
void constructor_test_0() {
    CharLinkedList list;
}

/*
 * constructor test 1
 * Make sure no fatal errors/memory leaks in this constructor
 */
void constructor_test_1() {
    CharLinkedList list('a');
}

/*
 * constructor test 2
 * Make sure no fatal errors/memory leaks in this constructor
 */
void constructor_test_2() {
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList list(arr, 3);
}

/*
 * constructor test 3
 * Make sure no fatal errors/memory leaks in the copy constructor
 * and that everything is copied over effectivly
 */
void constructor_test_3() {
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList list(arr, 3);

    CharLinkedList newList(list);
    for (int i = 0; i < list.size(); i++) {
        assert(newList.elementAt(i) == list.elementAt(i));
    }
}

/*
 * Assignment Operator test
 * Make sure no fatal errors/memory leaks when assignment opperating
 * and that the size and contents of the LinkedList are the same
 */
void assignmentOperator_test() {
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList list1(arr, 3);
    CharLinkedList list2 = list1;

    assert(list2.toString() == "[CharLinkedList of size 3 <<abc>>]");
}

/*
 * size test 0
 * make sure size function works with empty list that it starts at size 0
 */
void size_test_0() {
    CharLinkedList list;
    assert(list.size() == 0);
}

/*
 * size test 1
 * make sure size function works with larger sized lists and that the constructer sets size
 */
void size_test_1() {
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList list(arr, 3);
    assert(list.size() == 3);
}

/*
 * empty test 0
 * make sure list starts empty and that it can tell
 */
void empty_test_0() {
    CharLinkedList list;
    assert(list.isEmpty());
}

/*
 * empty test 1
 * make sure it can tell when theres something in the list
 */
void empty_test_1() {
    CharLinkedList list('a');
    assert(not list.isEmpty());
}

// see if first() gets the first element correctly
void first_test() {
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList list(arr, 3);
    assert(list.first() =='a');

}

/*
 * first error test
 * make sure an error is thrown when the list is empty
 */
void first_error_test() {
    // var to track whether runtime_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList list;

    try {
    // first for empty list
    list.first();
    } catch (const std::runtime_error &e) {
    // if first is correctly implemented, a runtime_error will be thrown,
    // and we will end up here
    runtime_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(runtime_error_thrown);
    assert(error_message == "cannot get first of empty LinkedList");
}

// see if last() gets the last element correctly
void last_test() {
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList list(arr, 3);
    assert(list.last() == 'c');
}

/*
 * last error test
 * make sure an error is thrown when the linked list is empty
 */
void last_error_test() {
    // var to track whether runtime_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList list;

    try {
    // last for empty list
    list.last();
    } catch (const std::runtime_error &e) {
    // if last is correctly implemented, a runtime_error will be thrown,
    // and we will end up here
    runtime_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(runtime_error_thrown);
    assert(error_message == "cannot get last of empty LinkedList");
}

/*
 * elementAt test
 * make sure elementAt gives the right element
 */
void elementAt_test() {
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList list(arr, 3);
    assert(list.elementAt(1) == 'b');
}

/*
 * element error test
 * make sure an error is thrown index is out of range
 */
void elementAt_error_test() {
    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList list(arr, 3);

    try {
    // try to get an element out of range
    list.elementAt(5);
    } catch (const std::range_error &e) {
        // if first is correctly implemented, a range_error will be thrown,
        // and we will end up here
        range_error_thrown = true;
        error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (5) not in range [0..3)");
}

/*
 * toString test
 * make sure the to string function turns the list into a string correctly
 */
void toString_test() {
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList list(arr, 3);
    assert(list.toString() == "[CharLinkedList of size 3 <<abc>>]");
}

/*
 * toReverseString test
 * make sure the to string function turns the list into a string but backwards correctly
 */
void toReverseString_test() {
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList list(arr, 3);
    assert(list.toReverseString() == "[CharLinkedList of size 3 <<cba>>]");
}

/*
 * pushAtBack test
 * make sure push at back adds the right elements to the back and updates size
 */
void pushAtBack_test() {
    CharLinkedList list;
    list.pushAtBack('a');
    list.pushAtBack('b');
    list.pushAtBack('c');
    assert(list.toString() == "[CharLinkedList of size 3 <<abc>>]");
}

/*
 * pushAtFront test
 * make sure push at front adds the right elements to the front and updates size
 */
void pushAtFront_test() {
    CharLinkedList list;
    list.pushAtFront('a');
    list.pushAtFront('b');
    list.pushAtFront('c');
    assert(list.toString() == "[CharLinkedList of size 3 <<cba>>]");
}

// make sure pop from front removes the first element and changes the size
void popFromFront_test() {
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList list(arr, 3);
    list.popFromFront();
    assert(list.toString() == "[CharLinkedList of size 2 <<bc>>]");
}

// make sure an error is thrown when popping from an empty list
void popFromFront_empty() {
    // var to track whether runtime_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList list;

    try {
        // pop from empty list
        list.popFromFront();
    } catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    // out here, we make our assertions
    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

// make sure clear emptys out the list properly
void clear_test() {
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList list(arr, 3);
    list.clear();
    assert(list.isEmpty());
}

// make sure you can add to a cleared list properly
void clear_test_2() {
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList list(arr, 3);
    list.clear();
    
    list.pushAtBack('a');
    list.pushAtBack('b');
    list.pushAtBack('c');
    assert(list.toString() == "[CharLinkedList of size 3 <<abc>>]");
}

//make sure somehting can get inserted in the middle of a list
void insertAt_test() {
    char arr[3] = {'a', 'b', 'd'};
    CharLinkedList list(arr, 3);
    list.insertAt('c', 2);
    
    assert(list.toString() == "[CharLinkedList of size 4 <<abcd>>]");
    assert(list.toReverseString() == "[CharLinkedList of size 4 <<dcba>>]");
}

//make sure somehting can get inserted at the start of a list
void insertAt_start() {
    char arr[3] = {'b', 'c', 'd'};
    CharLinkedList list(arr, 3);
    list.insertAt('a', 0);
    
    assert(list.toString() == "[CharLinkedList of size 4 <<abcd>>]");
    assert(list.toReverseString() == "[CharLinkedList of size 4 <<dcba>>]");
}

// make sure insert at throws an error if its out of range
void insertAt_outOfRange() {

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    // insertAt for out-of-range index
    test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
    // if insertAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    range_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0]");
    
}

//make sure somehting can get inserted at the end of a list
void insertAt_end() {
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList list(arr, 3);
    list.insertAt('d', 3);
    
    assert(list.toString() == "[CharLinkedList of size 4 <<abcd>>]");
    assert(list.toReverseString() == "[CharLinkedList of size 4 <<dcba>>]");
}

// make sure pop from back removes the last element and changes the size
void popFromBack_test() {
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList list(arr, 3);
    list.popFromBack();

    assert(list.toString() == "[CharLinkedList of size 2 <<ab>>]");
}

// make sure an error is thrown when popping from an empty list
void popFromBack_empty() {
    // var to track whether runtime_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList list;

    try {
        // pop from empty list
        list.popFromBack();
    } catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    // out here, we make our assertions
    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

// make sure remove at removes the right element
void removeAt_test() {
    char arr[4] = {'a', 'b', 'c', 'd'};
    CharLinkedList list(arr, 4);

    list.removeAt(1);
    assert(list.toString() == "[CharLinkedList of size 3 <<acd>>]");
}

// make sure removeAt throws range errors
void removeAt_outRange() {
    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList list(arr, 3);

    try {
    // try to get an element out of range
        list.removeAt(5);
    } catch (const std::range_error &e) {
    // if removeAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    range_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (5) not in range [0..3)");
}

// make sure remove at works at the end of a list
void removeAt_end() {
    char arr[4] = {'a', 'b', 'c', 'd'};
    CharLinkedList list(arr, 4);

    list.removeAt(3);
    assert(list.toString() == "[CharLinkedList of size 3 <<abc>>]");
}

// make sure remove at works at the start of a list
void removeAt_start() {
    char arr[4] = {'a', 'b', 'c', 'd'};
    CharLinkedList list(arr, 4);

    list.removeAt(0);
    assert(list.toString() == "[CharLinkedList of size 3 <<bcd>>]");
}

// make sure it can put something in the middle
void insertInOrder_middle_test() {
    char arr[3] = {'a', 'c', 'd'};
    CharLinkedList list(arr, 3);
    list.insertInOrder('b');
    assert(list.toString() == "[CharLinkedList of size 4 <<abcd>>]");
}

// make sure it can put something at the end
void insertInOrder_end_test() {
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList list(arr, 3);
    list.insertInOrder('d');
    assert(list.toString() == "[CharLinkedList of size 4 <<abcd>>]");
}

// make sure it can put something at the start
void insertInOrder_start_test() {
    char arr[3] = {'b', 'c', 'd'};
    CharLinkedList list(arr, 3);
    list.insertInOrder('a');
    assert(list.toString() == "[CharLinkedList of size 4 <<abcd>>]");
}

// make sure it can put something in an empty list
void insertInOrder_empty_test() {
    CharLinkedList list;
    list.insertInOrder('a');
    assert(list.toString() == "[CharLinkedList of size 1 <<a>>]");
}

// make sure replace at replaces the right element
void replaceAt_test() {
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList list(arr, 3);

    list.replaceAt('d', 1);
    assert(list.toString() == "[CharLinkedList of size 3 <<adc>>]");
}

// make sure replaceAt throws a range error
void replaceAt_outRange() {
    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList list(arr, 3);

    try {
    // try to get an element out of range
        list.replaceAt('a', 5);
    } catch (const std::range_error &e) {
    // if removeAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    range_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (5) not in range [0..3)");
}

// make sure concatenate merges the two lists correctly and without error
void concatenate_test0() {
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList list1(arr, 3);

    char arrr[3] = {'d', 'e', 'f'};
    CharLinkedList list2(arrr, 3);

    list1.concatenate(&list2);

    assert(list1.toString() == "[CharLinkedList of size 6 <<abcdef>>]");
}

// make sure concatenate can work with two of the same list
void concatenate_test1() {
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList list(arr, 3);

    list.concatenate(&list);

    assert(list.toString() == "[CharLinkedList of size 6 <<abcabc>>]");
}




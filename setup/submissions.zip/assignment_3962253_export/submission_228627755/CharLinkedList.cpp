/*
 *  CharLinkedList.cpp
 *  John Carey
 *  2/1/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  An implementation for the CharLinkedList interface, the CharLinkedList
 *  can be used to store chars
 *
 */

#include "CharLinkedList.h"

/*
 * name:      CharLinkedList
 * purpose:   Create an instance of the CharLinkedList class
 * arguments: none
 * returns:   Nothing
 * effects:   Initializes front to nullptr and sets numItems to 0
 */
CharLinkedList::CharLinkedList() {
    front = nullptr;
    numItems = 0;
}

/*
 * name:      CharLinkedList
 * purpose:   Create an instance of the CharLinkedList class with one char
 * arguments: A char c representing a piece of a CharLinkedList
 * returns:   Nothing
 * effects:   Initializes a pointer to front, that has info of 0 and null next
 *            and prev pointers.
 */
CharLinkedList::CharLinkedList(char c) {
    Node *new_char = new Node;
    new_char->info = c;
    new_char->next = nullptr;
    new_char->prev = nullptr;
    numItems = 1;
    front = new_char;
}

/*
 * name:      CharLinkedList
 * purpose:   Create an instance of the CharLinkedList class that copies
 *            a given array
 * arguments: an array arr that holds a bunch of chars and an int
 *            size that holds the size of arr
 * returns:   Nothing
 * effects:   Sets numItems to size and then copies
 *            the information from arr onto a LinkedList.
 */
CharLinkedList::CharLinkedList(char arr[], int size) {
    numItems = size;
    if(numItems > 0) {
        front = new Node{arr[0], nullptr, nullptr};
        Node *curr = front;
        for(int i = 1; i < size; i++) {
            curr->next = new Node{arr[i], nullptr, curr};
            curr = curr->next;
        }
    }
    
}

/*
 * name:      CharLinkedList
 * purpose:   Creates a deep copy of a given CharLinkedList.
 * arguments: The memory of a CharLinkedList other.
 * returns:   Nothing
 * effects:   Sets numItems to the size of other and then copies the 
 *            information from other onto a LinkedList.
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other) {
    numItems = other.size();
    if(numItems > 0) {
        front = new Node{other.first(), nullptr, nullptr};
        Node *curr = front;
        for(int i = 1; i < numItems; i++) {
            curr->next = new Node{other.elementAt(i), nullptr, curr};
            curr = curr->next;
        }
    }
}

/*
 * name:      ~CharLinkedList
 * purpose:   Frees the memory from a CharLinkedList
 * arguments: Nothing
 * returns:   Nothing
 * effects:   Deletes the memory on the heap from the CharLinkedList
 */
CharLinkedList::~CharLinkedList() {
    recycleRecursively(front);
}

/*
 * name:      operator=
 * purpose:   Creates the assignment operator for the CharLinkedList
 *            class so that we can set them equal to each other.
 * arguments: The memory of a CharLinkedList other.
 * returns:   The memory of a CharLinkedList
 * effects:   Sets numItems to the size of other and then copies the 
 *            information from other onto a LinkedList after the previous 
 *            information gets deleted.
 */
CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other) {
    if(this == &other) {
        return *this;
    }
    if(front != nullptr) {
        recycleRecursively(front);
    }
    numItems = other.size();
    if(numItems > 0) {
        front = new Node{other.first(), nullptr, nullptr};
        Node *curr = front;
        for(int i = 1; i < numItems; i++) {
            curr->next = new Node{other.elementAt(i), nullptr, curr};
            curr = curr->next;
        }
    }
    
    return *this;
}

/*
 * name:      isEmpty
 * purpose:   Checks to see if a CharLinkedList is empty
 * arguments: Nothing
 * returns:   A bool regarding whether or not it was empty
 * effects:   Nothing
 */
bool CharLinkedList::isEmpty() const {
    if(numItems == 0) {
        return true;
    }
    return false;
}

/*
 * name:      clear
 * purpose:   Delete all of the information previously on the LinkedList
 * arguments: Nothing
 * returns:   Nothing
 * effects:   Deletes the current memory of the list and sets it to a new
 *            CharLinkedList and sets numItems to 0
 */
void CharLinkedList::clear() {
    recycleRecursively(front);
    numItems = 0;
    front = nullptr;
}

/*
 * name:      size
 * purpose:   Return the number of items in the CharLinkedList
 * arguments: Nothing
 * returns:   An int representing the number of items in the LinkedList
 * effects:   Nothing
 */
int CharLinkedList::size() const {
    return numItems;
}

/*
 * name:      first
 * purpose:   Return the first char in the LinkedList
 * arguments: Nothing
 * returns:   A char that is the info in front
 * effects:   Throws an error if there are no chars in the list
 */
char CharLinkedList::first() const {
    if(numItems == 0){
        throw std::runtime_error("cannot get first of empty LinkedList");
    }
    else {
        return front->info;
    }
}

/*
 * name:      last
 * purpose:   Return the last char in the LinkedList
 * arguments: Nothing
 * returns:   A char that is the last char in the list
 * effects:   Throws an error if there are no chars in the list
 */
char CharLinkedList::last() const {
    if(numItems == 0){
        throw std::runtime_error("cannot get last of empty LinkedList");
    }
    else {
        Node *curr = front;
        while(curr->next != nullptr) {
            curr = curr->next;
        }
        return curr->info;
    }
}

/*
 * name:      elementAt
 * purpose:   Return the char at the given index in the LinkedList
 * arguments: An int that is the index of the char we want
 * returns:   A char that is in the index we asked for
 * effects:   Throws an error if the index is out of the range
 *            of the LinkedList.
 */
char CharLinkedList::elementAt(int index) const {
    if(numItems == 0 or index >= numItems or index < 0) {
        throw std::range_error("index (" + this->intToString(index) +
                               ") not in range [0.." + 
                               this->intToString(numItems) + ")");
    } else {
        int count = 0;
        Node *curr = front;
        while(count != index) {
            curr = curr->next;
            count++;
        }
        return curr->info;
    }
}

/*
 * name:      toString
 * purpose:   Return a string of all of the chars in the list
 * arguments: Nothing
 * returns:   A string of all of the chars in the list concatenated
 * effects:   None
 */
std::string CharLinkedList::toString() const {
    std::stringstream ss;
    ss << "[CharLinkedList of size " << intToString(numItems) << " <<";

    Node *curr = front;
    while (curr != nullptr) {
        ss << curr->info;
        curr = curr->next;
    }

    ss << ">>]";
    return ss.str();
}

/*
 * name:      toReverseString
 * purpose:   Return a string of all of the chars in the list backwards
 * arguments: Nothing
 * returns:   A string of all of the chars in the list concatenated backwards
 * effects:   None
 */
std::string CharLinkedList::toReverseString() const {
    std::stringstream ss;
    ss << "[CharLinkedList of size " << intToString(numItems) << " <<";

    Node *curr = front;
    if(front != nullptr) {
        while (curr->next != nullptr) {
            curr = curr->next;
        }
        while(curr != nullptr) {
            ss << curr->info;
            curr = curr->prev;
        }
    }
    
    ss << ">>]";
    return ss.str();
}

/*
 * name:      pushAtBack
 * purpose:   Put a char at the back of the list
 * arguments: A char c that we want to be the last element in data
 * returns:   Nothing
 * effects:   Takes c and makes it a Node at the back and sets the pointers
 *            of the previous last Node to the new Node
 */
void CharLinkedList::pushAtBack(char c) {
    Node *new_char = new Node;
    new_char->info = c;
    new_char->next = nullptr;
    if(numItems == 0) {
        front = new_char;
    } 
    else {
        Node *curr = front;
        while(curr->next != nullptr){
            curr = curr->next;
        }
        curr->next = new_char;
        new_char->prev = curr;
    }
    numItems++;
}

/*
 * name:      pushAtFront
 * purpose:   Put a char at the front of the list
 * arguments: A char c that we want to be the first element in data
 * returns:   Nothing
 * effects:   Takes c and makes it a Node at the front and sets the pointers
 *            of front and the previous first Node to the new Node
 */
void CharLinkedList::pushAtFront(char c) {
    Node *new_char = new Node{c, nullptr, nullptr};
    if(front != nullptr) {
        new_char->next = front;
        front->prev = new_char;
    }
    front = new_char;
    numItems++;
}

/*
 * name:      insertAt
 * purpose:   Put a char at a given index in the list
 * arguments: A char c that we want to be in data and an index
 *            indicating where we want c to be.
 * returns:   Nothing
 * effects:   A new node that has char c will be placed in the given
 *            index and the LinkedList pointers will be set correctly
 */
void CharLinkedList::insertAt(char c, int index) {
    if(index > numItems or index < 0) {
        throw std::range_error("index (" + this->intToString(index) 
                                + ") not in range [0.."
                                + this->intToString(numItems) + "]");
    } else {
        if(index == 0) {
            pushAtFront(c);
        } else if (index == numItems) {
            pushAtBack(c);
        } else {
            Node *curr = front;
            int curr_index = 0;
            while(curr_index < index - 1) {
                curr = curr->next;
                curr_index++;
            }
            Node *new_node = new Node{c, nullptr, nullptr};
            new_node->prev = curr;
            new_node->next = curr->next;
            Node *nxt = curr->next;
            nxt->prev = new_node;
            curr->next = new_node;
            numItems++;
        }
        
    } 
}

/*
 * name:      insertInOrder
 * purpose:   Put a char in its alphabetical order spot in the list
 * arguments: A char c that we want to be placed in data alphabetically
 * returns:   Nothing
 * effects:   A new node that has char c will be placed in the given
 *            LinkedList in alphabetical order and the LinkedList pointers 
 *            will be set correctly
 */
void CharLinkedList::insertInOrder(char c) {
    if(numItems == 0){
        front = new Node{c, nullptr, nullptr};
        numItems++;
    }
    else {
        Node *curr = front;
        while(curr->info < c) {
            curr = curr->next;
        }
        Node *after = curr;
        Node *before = curr->prev;
        curr = new Node{c, after, before};
        before->next = curr;
        after->prev = curr;
        numItems++;
    }
}

/*
 * name:      popFromFront
 * purpose:   Remove the first element in a list
 * arguments: Nothing
 * returns:   Nothing
 * effects:   Removes the first element in the list and restructures
 *            the rest of the list accordingly
 */
void CharLinkedList::popFromFront() {
    if(numItems == 0) {
        throw std::runtime_error("cannot pop from empty LinkedList");
    }
    else {
        Node *new_front = front->next;
        new_front->prev = nullptr;
        delete front;
        front = new_front;
        numItems--;
    }
}

/*
 * name:      popFromBack
 * purpose:   Remove the last element in the list
 * arguments: Nothing
 * returns:   Nothing
 * effects:   Removes the last element in the list and restructures
 *            the rest of the list accordingly
 */
void CharLinkedList::popFromBack() {
    if(numItems == 0) {
        throw std::runtime_error("cannot pop from empty LinkedList");
    }
    else {
        Node *curr = front;
        while(curr->next != nullptr) {
            curr = curr->next;
        }
        Node *before = curr->prev;
        before->next = nullptr;
        delete curr;
        numItems--;
    }
}

/*
 * name:      removeAt
 * purpose:   Remove a char at a given index in the LinkedList
 * arguments: An int representing the index we want to remove
 * returns:   Nothing
 * effects:   Removes the element at the given index and restructures
 *            the rest of the data accordingly. Can throw error if index
 *            is out of range of the LinkedLists size.
 */
void CharLinkedList::removeAt(int index) {
    if(numItems == 0 or index >= numItems or index < 0) {
        throw std::range_error("index (" + this->intToString(index)
                                + ") not in range [0.."
                                + this->intToString(numItems) + ")");
    }
    else {
        Node *curr = front;
        int curr_index = 0;
        while(curr_index < index) {
            curr = curr->next;
            curr_index++;
        }
        Node *after = curr->next;
        Node *before = curr->prev;
        after->prev = before;
        before->next = after;
        delete curr;
        numItems--;
    }
}

/*
 * name:      replaceAt
 * purpose:   Remove a node at a given index in the LinkedList and
 *            replace it with a new node
 * arguments: An int that is the index we want to remove and a char c
 *            that is the char we want to replace it with
 * returns:   Nothing
 * effects:   Replaces the node at the given index with a new node that has 
 *            the char c. Can throw error if index is out of range of the 
 *            LinkedLists indexes.
 */
void CharLinkedList::replaceAt(char c, int index) {
    if(numItems == 0 or index >= numItems or index < 0) {
        throw std::range_error("index (" + this->intToString(index)
                                + ") not in range [0.."
                                + this->intToString(numItems) + ")");
    }
    else {
        recursiveReplace(front, c, index);
    }
}

/*
 * name:      concatenate
 * purpose:   Take a given CharLinkedList and add its elements onto
 *            the back of the current CharLinkedList.
 * arguments: A pointer to a CharLinkedList that will be added to the 
 *            current LinkedList
 * returns:   Nothing
 * effects:   Iterates through the other LinkedList and adds all of its
 *            elements to the back of the current LinkedList.
 */
void CharLinkedList::concatenate(CharLinkedList *other) {
    int totalSize = numItems + other->size();
    int otherIndex = 0;
    if(front == nullptr) {
        front = new Node{other->elementAt(otherIndex), nullptr, nullptr};
        otherIndex++;
    }
    Node *curr = front;
    while(curr->next != nullptr) {
        curr = curr->next;
    }
    while(otherIndex < other->size()) {
        curr->next = new Node{other->elementAt(otherIndex), nullptr, curr};
        curr = curr->next;
        otherIndex++;
    }
    
    numItems = totalSize;
}

/*
 * name:      recycleRecursively
 * purpose:   A function that can be used to delete all of the memory on 
 *            the heap fron the current LinkedList
 * arguments: A Node curr that is the next node to be deleted
 * returns:   Nothing
 * effects:   Recursively goes through the list and deletes each element
 */
void CharLinkedList::recycleRecursively(Node *curr) {
    if(curr == nullptr) {
        return;
    } else {
        Node *next = curr->next;
        delete curr;
        recycleRecursively(next);
    }
}

/*
 * name:      recursiveReplace
 * purpose:   Go through the LinkedList until index and then delete
 *            the node there and put in the new node with char c
 * arguments: A Node curr that is the next node in the list. A char c
 *            that will go in the new Node. An int index that is the 
 *            number of nodes left to iterate over.
 * returns:   Nothing
 * effects:   Recursively goes through the list and replaces an element
 *            at index with a new Node holding c.
 */
void CharLinkedList::recursiveReplace(Node *curr, char c, int index) {
    if(index == 0) {
        Node *before = curr->prev;
        Node *after = curr->next;
        delete curr;
        curr = new Node{c, after, before};
        before->next = curr;
        after->prev = curr;
        return;
    } else {
        curr = curr->next;
        index--;
        recursiveReplace(curr, c, index);
    }
}


/*
 * name:      intToString
 * purpose:   Take an integer and turn it to an std::string
 * arguments: An int representing the number we want as a string
 * returns:   A string that holds the number
 * effects:   Nothing
 */
std::string CharLinkedList::intToString(int num) const {
    std::string str = std::to_string(num);
    return str;
}
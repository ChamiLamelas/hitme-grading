/*
 *  unit_tests.h
 *  John Carey
 *  DATE CREATED
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  Tests the functionality of CharLinkedList and make sure it works
 *
 */
#include "CharLinkedList.h"
#include <cassert>

//Test if the class definition is syntactically correct
void dummy_test() {}

//Test that the default constructor works
void default_constructor_test() {
    CharLinkedList list;
}

//Test constructor with char parameter
void char_constructor_test() {
    CharLinkedList list('a');
    assert(list.first() == 'a');
}

//Test the constructor that makes a copy of another arr
void copy_constructor_test() {
    int size = 3;
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList list(arr, size);
    assert(list.elementAt(2) == 'c');
}

//Test the copy constructor to make sure it's the same size
void copy_constructor_length() {
    int size = 3;
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList list(arr, size);
    assert(list.size() == size);
}

//Test the deep copy constructor
void deep_constructor() {
    int size = 3;
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList list(arr, size);
    CharLinkedList list1(list);
    assert(list1.toString() == "[CharLinkedList of size 3 <<abc>>]");
}

//Test that the assignment operator works
void assignment_test() {
    int size = 3;
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList list(arr, size);
    CharLinkedList list1 = list;
    assert(list1.toString() == "[CharLinkedList of size 3 <<abc>>]");
}

//Test that isEmpty works when the LinkedList is empty
void true_isEmpty() {
    CharLinkedList list;
    assert(list.isEmpty());
}

//Test that isEmpty works when the LinkedList is filled
void false_isEmpty() {
    char a = 'a';
    CharLinkedList list(a);
    assert(!list.isEmpty());
}

//Test that clear will empty the whole array
void clear_test() {
    int size = 3;
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList list(arr, size);
    list.clear();
    assert(list.isEmpty());
}

//Test that size returns the correct number
void size_test() {
    int size = 3;
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList list(arr, size);
    assert(list.size() == size);
}

//Test that first returns the correct letter
void first_test() {
    int size = 3;
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList list(arr, size);
    assert(list.first() == 'a');
}

//Test that first returns an error when called on an empty LinkedList
void empty_first() {
    // var to track whether runtime_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    // insertAt for out-of-range index
    test_list.first();
    }
    catch (const std::runtime_error &e) {
    // if insertAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    runtime_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(runtime_error_thrown);
    assert(error_message == "cannot get first of empty LinkedList");
}

// Test that last returns the correct letter
void last_test() {
    int size = 3;
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList list(arr, size);
    assert(list.last() == 'c');
}

//Test that last returns an error when called on an empty LinkedList
void empty_last() {
    // var to track whether runtime_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    // insertAt for out-of-range index
    test_list.last();
    }
    catch (const std::runtime_error &e) {
    // if insertAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    runtime_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(runtime_error_thrown);
    assert(error_message == "cannot get last of empty LinkedList");
}

//Test that elementAt will return the correct element 
void elementAt_test() {
    int size = 3;
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList list(arr, size);
    assert(list.elementAt(1) == 'b');
}

//Test if an index is out of range over size
void elementAt_large_index() {
    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    int size = 3;
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList list(arr, size);
    try {
    // insertAt for out-of-range index
    list.elementAt(6);
    }
    catch (const std::range_error &e) {
    // if insertAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    range_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (6) not in range [0..3)");
}

//Test if an index is out of range over size
void elementAt_small_index() {
    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    int size = 3;
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList list(arr, size);
    try {
    // insertAt for out-of-range index
    list.elementAt(-1);
    }
    catch (const std::range_error &e) {
    // if insertAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    range_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (-1) not in range [0..3)");
}

//Test if an index is out of range in an empty LinkedList
void elementAt_empty_index() {
    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList list;
    try {
    // insertAt for out-of-range index
    list.elementAt(6);
    }
    catch (const std::range_error &e) {
    // if insertAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    range_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (6) not in range [0..0)");
}

//Test that toString's output is correct for an LinkedList
void toString_test() {
    int size = 3;
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList list(arr, size);
    assert(list.toString() == "[CharLinkedList of size 3 <<abc>>]");
}

//Test an empty LinkedList on toString
void empty_toString() {
    CharLinkedList list;
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}

//Test that toReverseString gives the correct output
void toReverseString_test() {
    int size = 3;
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList list(arr, size);
    assert(list.toReverseString() == "[CharLinkedList of size 3 <<cba>>]");
}

//Test an empty LinkedList on toReverseString
void empty_toReverseString() {
    CharLinkedList list;
    assert(list.toReverseString() == "[CharLinkedList of size 0 <<>>]");
}

//Test that pushAtBack adds the char to the end
void pushAtBack_test() {
    int size = 3;
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList list(arr, size);
    list.pushAtBack('d');
    
    assert(list.toString() == "[CharLinkedList of size 4 <<abcd>>]");
}

//Test that pushAtFront adds the char to the front
void pushAtFront_test() {
    int size = 3;
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList list(arr, size);
    list.pushAtFront('d');
    assert(list.toString() == "[CharLinkedList of size 4 <<dabc>>]");
}

// Tests correct insertion into an empty Linked List.
// Afterwards, size should be 1 and element at index 0
// should be the element we inserted.
void insertAt_empty_correct() { 

    CharLinkedList test_list;
    test_list.insertAt('a', 0);
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');

}

// Tests incorrect insertion into an empty Linked list.
// Attempts to call insertAt for index larger than 0.
// This should result in an std::range_error being raised.
void insertAt_empty_incorrect() {

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    // insertAt for out-of-range index
    test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
    // if insertAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    range_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0]");
    
}

// Tests correct insertAt for front of 1-element list.
void insertAt_front_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at front
    test_list.insertAt('b', 0);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'a');
    
}

// Tests correct insertAt for back of 1-element list.
void insertAt_back_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at back
    test_list.insertAt('b', 1);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    
}

// Tests calling insertAt for a large number of elements.
void insertAt_many_elements() {
    
    CharLinkedList test_list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.insertAt('a', i);
    }

    assert(test_list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
    
}

// Tests insertion into front of a larger list
void insertAt_front_large_list() {
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    test_list.insertAt('y', 0);

    assert(test_list.size() == 10);
    assert(test_list.elementAt(0) == 'y');
    assert(test_list.toString() == 
           "[CharLinkedList of size 10 <<yabczdefgh>>]");

}

// Tests insertion into the back of a larger list
void insertAt_back_large_list() {

    char test_arr[10] = { 'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 10);  

    test_list.insertAt('x', 10);

    assert(test_list.size() == 11);
    assert(test_list.elementAt(10) == 'x');
    assert(test_list.toString() == 
    "[CharLinkedList of size 11 <<yabczdefghx>>]"); 

}

// Tests insertion into the middle of a larger list
void insertAt_middle_large_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.insertAt('z', 3);

    assert(test_list.size() == 9);
    assert(test_list.elementAt(3) == 'z');
    assert(test_list.toString() == "[CharLinkedList of size 9 <<abczdefgh>>]");

}

// Tests out-of-range insertion for a non-empty list.
void insertAt_nonempty_incorrect() {
   
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8]");
    
}

//Test that insert in order will put the char correctly in a sorted LinkedList
void insertInOrder_test() {
    int size = 3;
    char arr[3] = {'a', 'b', 'd'};
    CharLinkedList list(arr, size);
    list.insertInOrder('c');
    assert(list.toString() == "[CharLinkedList of size 4 <<abcd>>]");
}

//Test that insert in order will add the char when it is equal to something
void insertInOrder_equal_test() {
    int size = 3;
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList list(arr, size);
    list.insertInOrder('b');
    assert(list.toString() == "[CharLinkedList of size 4 <<abbc>>]");
}

//Test insertInOrder is able to put something in an empty list
void insertInOrder_empty() {
    CharLinkedList list;
    list.insertInOrder('a');
    assert(list.toString() == "[CharLinkedList of size 1 <<a>>]");
}

//Test that popFromBack takes the char in the back
void popFromBack_test() {
    int size = 3;
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList list(arr, size);
    list.popFromBack();
    assert(list.toString() == "[CharLinkedList of size 2 <<ab>>]");
}

//Test that popFromBack will return an error if LinkedList is empty
void popFromBack_empty() {
    // var to track whether runtime_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    // insertAt for out-of-range index
    test_list.popFromBack();
    }
    catch (const std::runtime_error &e) {
    // if insertAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    runtime_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

//Test that popFromFront removes the first char in LinkedList
void popFromFront_test() {
    int size = 3;
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList list(arr, size);
    list.popFromFront();
    assert(list.toString() == "[CharLinkedList of size 2 <<bc>>]");
}

//Test that popFromFront will return an error if LinkedList is empty
void popFromFront_empty() {
    // var to track whether runtime_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    // insertAt for out-of-range index
    test_list.popFromFront();
    }
    catch (const std::runtime_error &e) {
    // if insertAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    runtime_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

//Test that removeAt takes the correct char
void removeAt_test() {
    int size = 3;
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList list(arr, size);
    list.removeAt(1);
    assert(list.toString() == "[CharLinkedList of size 2 <<ac>>]");
}

//Test that removeAt will return an error if index is out of bounds
void removeAt_error() {
    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    int size = 3;
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList list(arr, size);
    try {
    // insertAt for out-of-range index
    list.removeAt(3);
    }
    catch (const std::range_error &e) {
    // if insertAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    range_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (3) not in range [0..3)");
}

//Test that replaceAt replaces the correct char and returns the right LinkedList
void replaceAt_test() {
    int size = 3;
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList list(arr, size);
    list.replaceAt('d', 1);
    assert(list.toString() == "[CharLinkedList of size 3 <<adc>>]");
}

//Test that replaceAt will return an error if index is out of bounds
void replaceAt_error() {
    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    int size = 3;
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList list(arr, size);
    try {
    // insertAt for out-of-range index
    list.replaceAt('d', 6);
    }
    catch (const std::range_error &e) {
    // if insertAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    range_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (6) not in range [0..3)");
}

void concatenate_test() {
    int size = 3;
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList list(arr, size);
    CharLinkedList list1(arr, size);
    list.concatenate(&list1);
    assert(list.toString() == "[CharLinkedList of size 6 <<abcabc>>]");
}

//Test that concatenate returns the second list when the first is empty
void concatenate_empty_first() {
    int size = 3;
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList list;
    CharLinkedList list1(arr, size);
    list.concatenate(&list1);
    assert(list.toString() == "[CharLinkedList of size 3 <<abc>>]");
}

//Test that concatenate returns the first list when the second is empty
void concatenate_empty_second() {
    int size = 3;
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList list(arr, size);
    CharLinkedList list1;
    list.concatenate(&list1);
    assert(list.toString() == "[CharLinkedList of size 3 <<abc>>]");
}

//Test that concatenate works when its on itself
void concatenate_itself() {
    int size = 3;
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList list(arr, size);
    list.concatenate(&list);
    assert(list.toString() == "[CharLinkedList of size 6 <<abcabc>>]");
}




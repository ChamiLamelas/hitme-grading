/*
 *  CharLinkedList.h
 *  John Carey
 *  2/1/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  The interface for the CharLinkedList class
 *
 */

#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H
#include <sstream>
#include <string>

class CharLinkedList {
public:
    //Constructors
    CharLinkedList();
    CharLinkedList(char c);
    CharLinkedList(char arr[], int size);
    CharLinkedList(const CharLinkedList &other);

    //Destructor
    ~CharLinkedList();

    //Assignment Operator
    CharLinkedList &operator=(const CharLinkedList &other);

    //functions
    bool isEmpty() const;
    void clear();
    int size() const;
    char first() const;
    char last() const;
    char elementAt(int index) const;
    std::string toString() const;
    std::string toReverseString() const;
    void pushAtBack(char c);
    void pushAtFront(char c);
    void insertAt(char c, int index);
    void insertInOrder(char c);
    void popFromFront();
    void popFromBack();
    void removeAt(int index);
    void replaceAt(char c, int index);
    void concatenate(CharLinkedList *other);
    
private:
    struct Node {
        char      info;
        Node       *next;
        Node       *prev;
    };

    Node *front;
    int   numItems;

    void recycleRecursively(Node *curr);
    void recursiveReplace(Node *curr, char c, int index);
    std::string intToString(int num) const;

};

#endif

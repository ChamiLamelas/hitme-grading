/*
 *  CharLinkedList.cpp
 *  Nyapal Chuol
 *  01/30/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  the body
 *
 */

#include "CharLinkedList.h"
#include <sstream>
#include <iostream>

/*
 * name:      default constructor
 * purpose:   initialize an empty list
 * arguments: none
 * returns:   none
 * effects:   sets size and front pointer to nullpointer
 */
CharLinkedList::CharLinkedList(){
    numSize = 0;
    front = nullptr;
    end = nullptr;

}

/*
 * name:      node constructor
 * purpose:   initialize the struct componenets
 * arguments: character, node pointer, node pointer
 * returns:   none
 * effects:   sets size and front pointer to nullpointer
 */
CharLinkedList::Node::Node(char c, Node *next, Node *prev){
    this->c = c;
    this->next = next;
    this->prev = prev;
}

/*
 * name:      single constructor
 * purpose:   initialize a linked list with a single character
 * arguments: a character
 * returns:   none
 * effects:   assigns front pointer to char c
 */
CharLinkedList::CharLinkedList(char c){
    numSize++;
    front = new Node(c); 
}

/*
 * name:      array constructor
 * purpose:   creates a list based off given array of characters
 * arguments: a character array, int numsize
 * returns:   none
 * effects:   
 */
CharLinkedList::CharLinkedList(char arr[], int numSize){
    if (numSize > 0) {
        front = new Node(arr[0]);
        Node* current = front;

        for (int i = 1; i < numSize; i++) {
            current->next = new Node(arr[i]);
            current->next->prev = current;
            current = current->next;
        }
    } else {
        front = nullptr;
    }
}

/*
 * name:      copy constructor
 * purpose:   creates a deep copy of the list
 * arguments: reference to linkedlist
 * returns:   none
 * effects:   assigns front pointer to char c and shifts pointers
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other){
    
    //this pointer iterates through otherlist
    Node* otherCurrent = other.front;
    //this pointer builds a new list
    Node* current = nullptr;

    while (otherCurrent) {
        //if front not initalized
        if (!front) {
            //create new node assign to front
            front = new Node(otherCurrent->c, nullptr, nullptr);
            current = front;
        } else {
            //if initalized, create new node and assign to current
            current->next = new Node(otherCurrent->c, nullptr, current);
            current = current->next;
        }
        //iterate to next node in the other list
        otherCurrent = otherCurrent->next;
        numSize++;
    }
    if(current){
        end = current;
    }
}

/*
 * name:      destructor!!!
 * purpose:   releases dynamically allocated memory
 * arguments: none
 * returns:   none
 * effects:   none
 */
CharLinkedList::~CharLinkedList() {
    clear();
}

/*
 * name:      clear
 * purpose:   empties the list
 * arguments: none
 * returns:   none
 * effects:   none
 */
void CharLinkedList::clear() {
    deleteList(front);
    front = nullptr;
    end = nullptr;
    numSize = 0;
}

/*
 * name:      deleteList
 * purpose:   helper function for destructor
 * arguments: node pointer
 * returns:   none
 * effects:   none
 */
void CharLinkedList::deleteList(Node *current) {
    if (current) {
        Node *nextNode = current->next;
        delete current;
        deleteList(current->next);
    }
}
 /*
 * name:      size
 * purpose:   empties the list
 * arguments: none
 * returns:   int size 
 * effects:   none
 */

int CharLinkedList::size() const {
        return numSize;
    }


/*
 * name:      toString
 * purpose:   adds the characters together to make string
 * arguments: none
 * returns:   a string that has the letters  of the linkedlist 
 * effects:   none
 */
std::string CharLinkedList::toString() const {
    std::stringstream ss;
    ss << "[CharLinkedList of size " << numSize << " <<";

    Node* current = front;
    while (current) {
        ss << current->c;
        current = current->next;

        if (current) {
            ss << ',';
        }
    }

    ss << ">>]";
    return ss.str();
}

/*
 * name:      toReverseString
 * purpose:   converts the characters of the list in reverse order to string 
 * arguments: none
 * returns:   [CharLinkedList of size SIZE <<REVERSED_CHARACTERS>>]
 * effects:   none
 */
 std::string CharLinkedList::toReverseString() const {
    std::stringstream ss;
    ss << "[CharLinkedList of size " << numSize << " <<";

    Node* current = end; // Start from the end of the list
    while (current) {
        ss << current->c; // Append the character to the stringstream
        current = current->prev; // Move to the previous node
    }

    ss << ">>]";
    return ss.str();
}

/*
 * name:      isEmpty
 * purpose:   checks if list is empty
 * arguments: none
 * returns:   true if size is 0 and false if size anything else
 * effects:   none
 */
bool CharLinkedList::isEmpty() const {
    return numSize == 0;
}

/*
 * name:      overloaded assignment operator
 * purpose:   checks if list is empty
 * arguments: reference to a linkedlist
 * returns:   a reference to front of current instance
 * effects:   none
 */
CharLinkedList &CharLinkedList::operator=(const CharLinkedList& other){
    if(this == &other){
        return *this;
    }
    //clear current data from current instance
    clear();

    Node *otherCurr = other.front;
    Node *curr = nullptr;

    while(otherCurr){
        if(!front){
            front = new Node(otherCurr->c, nullptr, nullptr);
            curr = front;
        } else {
            curr->next = new Node(otherCurr->c, nullptr, curr);
            curr = curr->next;
        }
        otherCurr = otherCurr->next;
        numSize++;
    }
    if(curr){
        end = curr;
    }
    return *this; //returns reference to current instance
}

/*
 * name:      first
 * purpose:   returns first element of list
 * arguments: none
 * returns:   inital element
 * effects:   none
 */
 char CharLinkedList::first() const {
    if (front == nullptr) {
        throw std::runtime_error("cannot get first of empty LinkedList");
    }
    return front->c;
}

/*
 * name:      last
 * purpose:   returns last element of list
 * arguments: none
 * returns:   last element
 * effects:   none
 */
 char CharLinkedList::last() const {
     if (!end) {
        throw std::runtime_error("Cannot get last of empty LinkedList");
    }
    return end->c;
}

/*
 * name:      elementAt
 * purpose:   returns element at specific index
 * arguments: int index
 * returns:   element at specific index
 * effects:   none
 */
 char CharLinkedList::elementAt(int index) const {
    if (index < 0 || index >= numSize) {
        std::string message = "index (" + std::to_string(index) + 
        ") not in range [0.." + std::to_string(numSize) + ")";
        throw std::range_error(message);
    }
    return elementAtHelper(front, index);
}

/*
 * name:      elementAtHelper
 * purpose:   recursivley iterates through list to get element at specific index 
 * arguments: node pointer, int index
 * returns:   element at specific index
 * effects:   none
 */
char CharLinkedList::elementAtHelper(Node* current, int index) const {
    if (index == 0) {
        return current->c;
    }
    if (!current->next) {
        throw std::range_error("index (" + std::to_string(index) + 
        ") not in range [0.." + std::to_string(numSize) + ")");
    }
    return elementAtHelper(current->next, index - 1);
}


/*
 * name:      pushAtBack
 * purpose:   inserts a new element at the end of the list
 * arguments: char c - the element to be inserted
 * returns:   none
 * effects:   modifies the linked list by inserting the new element at the end
 */
void CharLinkedList::pushAtBack(char c) {
    Node *newNode = new Node(c); 

    if (!front) { // If the list is empty, set the new node as the front and end
        front = newNode;
        end = newNode;
    } else {
        end->next = newNode; // Set the next pointer of the current 
                             //end node to the new node
        newNode->prev = end; // Set prev pointer of new node to current end node
        end = newNode; // Update the end pointer to the new node
    }
    numSize++; 
}

/*
 * name:      pushAtFront
 * purpose:   inserts a new element at the front of the list
 * arguments: char c 
 * returns:   none
 * effects:   modifies the linked list by inserting the new element at the front
 */
void CharLinkedList::pushAtFront(char c) {
    Node* newNode = new Node(c); 

    if (!front) { // If list is empty, set new node as the front and end
        front = newNode;
        end = newNode;
    } else {
        newNode->next = front; // Set next pointer of the new node to 
                                //curr front node
        front->prev = newNode; // Set prev pointer of current front node 
                                //to the new node
        front = newNode; // Update the front pointer to the new node
    }
    numSize++; 
}

/*
 * name:      pushFromFront
 * purpose:   removes element from front of list
 * arguments: none
 * returns:   none
 * effects:   removes element from front
 */
void CharLinkedList::popFromFront() {

     if (!front) { // If the list is empty, do nothing
        return;
    }

    Node* temp = front; 
    front = front->next; 
    if (front) { // If the list is not empty after removing the node
        front->prev = nullptr; // Set prev pointer of the new front node to null
    } else { 
        end = nullptr; 
    }
    delete temp; // Delete the old front node
    numSize--; // Decrement the size counter
}

/*
 * name:      pushFromBack
 * purpose:   removes element from back of list
 * arguments: none
 * returns:   none
 * effects:   none
 */
void CharLinkedList::popFromBack() {
    if (!end) { // If the list is empty, do nothing
        return;
    }

    Node* temp = end; 
    end = end->prev; // Move the end pointer to the previous node
    if (end) {
        end->next = nullptr; // Set the next pointer of the new end node to null
    } else { 
        front = nullptr; // Update the front pointer to null
    }
    delete temp; 
    numSize--; 
}

/*
 * name:      insertAt
 * purpose:   inserts new element at specified index
 * arguments: char c and int index 
 * returns:   none
 * effects:   none
 */
void CharLinkedList::insertAt(char c, int index) {
    if (index < 0 || index > numSize) {
        std::string message = "index (" + std::to_string(index) + 
                              ") not in range [0.." + std::to_string(numSize) 
                              + "]";
        throw std::range_error(message);
    }

    if (index == numSize) {
        pushAtBack(c);
    } else {
        Node* newNode = new Node(c);

        if (index == 0) {
            newNode->next = front;
            front->prev = newNode;
            front = newNode;
        } else {
            Node* current = front;
            for (int i = 0; i < index - 1; ++i) {
                current = current->next;
            }
            newNode->next = current->next;
            newNode->prev = current;
            current->next->prev = newNode;
            current->next = newNode;
        }

        numSize++;
    }
}

/*
 * name:      insertInOrder
 * purpose:   inserts given element into list in ASCII order
 * arguments: char c 
 * returns:   none
 * effects:   none
 */
void CharLinkedList::insertInOrder(char c) {
    Node* newNode = new Node(c);

    // If the list is empty or the new element is less than the first element
    if (!front || c < front->c) {
        newNode->next = front;
        if (front) {
            front->prev = newNode;
        }
        front = newNode;
    } else {
        Node* current = front;

        // iterate through list to find the position to insert the new element
        while (current->next && c >= current->next->c) {
            current = current->next;
        }

        // Insert the new element between current and current->next
        newNode->next = current->next;
        newNode->prev = current;
        if (current->next) {
            current->next->prev = newNode;
        }
        current->next = newNode;
    }

    numSize++;
}

/*
 * name:      removeAt
 * purpose:   removes element at specified index
 * arguments: int index
 * returns:   none
 * effects:   none
 */
void CharLinkedList::removeAt(int index) {
    // Check if the index is out of range
    if (index < 0 || index >= numSize) {
        std::string message = "index (" + std::to_string(index) + 
            ") not in range [0.." + std::to_string(numSize) + ")";
        throw std::range_error(message);
    }

    // If the index is 0, remove the first node
    if (index == 0) {
        Node* temp = front;
        front = front->next;
        if (front) {
            front->prev = nullptr;
        }
        delete temp;
    } else {
        Node* current = front;

        // iterate through to the node at the specified index
        for (int i = 0; i < index; ++i) {
            current = current->next;
        }

        // Remove the node at the specified index
        current->prev->next = current->next;
        if (current->next) {
            current->next->prev = current->prev;
        } else {
            end = current->prev;
        }
        delete current;
    }

    numSize--;
}

/*
 * name:      replaceAtHelper
 * purpose:   helper function for replaceAt
 * arguments: char c, int index, node pointer
 * returns:   none
 * effects:   none
 */
void CharLinkedList::replaceAtHelper(char c, int index, Node* current) {
    // Base case: If index is 0, replace the element
    if (index == 0) {
        current->c = c;
        return;
    }

    // Recursive case: iterate to the node at the specified index
    replaceAtHelper(c, index - 1, current->next);
}

/*
 * name:      replaceAt
 * purpose:   replaces element at specified index with new element
 * arguments: char c, int index
 * returns:   none
 * effects:   none
 */
 void CharLinkedList::replaceAt(char c, int index) {
    // Check if the index is out of range
    if (index < 0 || index >= numSize) {
        std::string message = "index (" + std::to_string(index) + 
            ") not in range [0.." + std::to_string(numSize) + ")";
        throw std::range_error(message);
    }

    // Call the private recursive helper function
    replaceAtHelper(c, index, front);
}

/*
 * name:      concatenate
 * purpose:   concatenates list pointed to by parameter to end of current list
 * arguments: pointer to list
 * returns:   none
 * effects:   none
 */
void CharLinkedList::concatenate(CharLinkedList *other) {
    // Check if the other list is empty
    if (other->isEmpty()) {
        return; 
    }

    // Make a copy of the other list
    CharLinkedList copy(*other);

    // If the list is empty, set front pointer to the front pointer of the copy
    if (isEmpty()) {
        front = copy.front;
    } else {
        // Traverse to the end of the current list
        Node* current = front;
        while (current->next != nullptr) {
            current = current->next;
        }
        // Append the copy of the other list to the end of the current list
        current->next = copy.front;
        copy.front->prev = current;
    }

    // Update the size of the current list
    numSize += copy.numSize;
}
/*
 *  CharLinkedList.h
 *  Nyapal Chuol
 *  01/30/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  my header files!
 *
 */

#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H
#include <string>

class CharLinkedList {

    public:
        CharLinkedList();
        ~CharLinkedList();
        char *arr;

        CharLinkedList(char c);
        CharLinkedList(char arr[], int size);
        CharLinkedList(const CharLinkedList &other);
        CharLinkedList &operator=(const CharLinkedList &other);
        

        void clear();
        int size() const;
        std::string toString() const;
        std::string toReverseString() const;
        char first() const;
        char last() const;
        bool isEmpty() const;
        void pushAtBack(char c);
        void pushAtFront(char c);
        void popFromBack();
        void popFromFront();
        void insertAt(char c, int index);
        void insertInOrder(char c);
        void removeAt(int index);
        char elementAt(int index) const;
        void replaceAt(char c, int index);
        void concatenate(CharLinkedList *other);
        

        

    private:

        struct Node{
            char c;
            Node *prev;
            Node *next;
            std::string toString() { 
                return std::string(1,c);
                }
            Node(char c, Node *next = nullptr, Node *prev = nullptr);
            };
        
        Node *front;
        Node *end;
        char elementAtHelper(Node *current, int index) const;
        void replaceAtHelper(char c, int index, Node *current);
        void deleteList(Node* current);
        int numSize;
};

#endif


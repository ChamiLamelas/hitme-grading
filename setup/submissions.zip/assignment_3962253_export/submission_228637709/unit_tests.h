/*
 *  unit_tests.h
 *  Nyapal Chuol
 *  01/30/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  testing testing tesing!
 *
 */


#include "CharLinkedList.h"
#include <cassert>
#include <string>



void dummyTest(){
    CharLinkedList();
}

//defualt constructor test if made
void testDefaultConstructor(){
    CharLinkedList list;
    assert(list.size() == 0);
}

//single constructor test if made
void testSingleConstructor(){
    CharLinkedList list('c');
    assert(list.size() == 1);
}

//single constructor test if character is expected
void testSingleConstructorChar(){
    char expectedChar = 'c';
    CharLinkedList list('c');
    assert(list.toString() == "[CharLinkedList of size 1 <<" 
    + std::string(1, expectedChar) + ">>]");
}



//copy constructor test if size match original
void testCopyConstructorSize(){
    CharLinkedList ogList('a');
    ogList.pushAtBack('b');
    ogList.pushAtBack('c');

    CharLinkedList copyList(ogList);

    assert(copyList.size() == ogList.size());
}

//copy constructor test if contents match original
void testCopyConstructorContents(){
    CharLinkedList ogList('a');
    ogList.pushAtBack('b');
    ogList.pushAtBack('c');

    CharLinkedList copyList(ogList);

    assert(copyList.toString() == ogList.toString());
}


//test clear function
void testClear(){
    CharLinkedList list('c');
    list.pushAtBack('a');
    list.pushAtBack('r');

    list.clear();

    assert(list.size() == 0);
}


//test size
void testSize(){
    CharLinkedList list('c');
    list.pushAtBack('a');
    list.pushAtBack('r');

    int size = list.size();
    assert(size == 3);
}


//test isEmpty
void testIsEmpty(){
    CharLinkedList emptyList;
    assert(emptyList.isEmpty() == true);

}

//test first empty
void testFirstIsEmpty(){
    try{
        CharLinkedList emptyList;
        emptyList.first();
        assert(false); //throw the exception
    } catch (const std::runtime_error &e){
        assert(true);
    }
}

//test first not empty -- not passing valgrind
void testFirstNotEmpty(){
    CharLinkedList list('c');
    assert(list.first() == 'c');

}

//test last empty
void testLastIsEmpty(){
    try {
        CharLinkedList emptyList;
        emptyList.last();
        assert(false); //throw the exception
    } catch (const std::runtime_error& e) {
        assert(true);
    }
}

//test last not empty -- not passing valgrind
void testLastIsNotEmpty(){
    CharLinkedList list('c');
    assert(list.last() == 'c');
}

//test pushAtBack
void testPushAtBack(){
CharLinkedList list;

    // Push some elements to the back of the list
    list.pushAtBack('a');
    list.pushAtBack('b');
    list.pushAtBack('c');

    // Print the list
    assert(list.toString() == "[CharLinkedList of size 3 <<a,b,c>>]");
}

//test if to reverse string works
void testToReverseString() {
    CharLinkedList list;
    assert(list.toReverseString() == "[CharLinkedList of size 0 <<>>]");

    list.pushAtBack('a');
    list.pushAtBack('b');
    list.pushAtBack('c');

    assert(list.toReverseString() == "[CharLinkedList of size 3 <<cba>>]");
}
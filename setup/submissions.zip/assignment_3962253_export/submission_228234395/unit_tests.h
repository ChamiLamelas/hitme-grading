/* 
*  unit_tests.h
*  Seth Gellman (sgellm01)
*  1/30/24
*
*  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
*
*  Uses the unit_test framework to test the CharLinkedList class.
*
*/

#include "CharLinkedList.h"
#include <cassert>

// Tests correct insertion into an empty AL.
// Afterwards, size should be 1 and element at index 0
// should be the element we inserted.
void insertAt_empty_correct() { 

    CharLinkedList test_list;
    test_list.insertAt('a', 0);
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.first() == 'a');

}

// Tests incorrect insertion into an empty AL.
// Attempts to call insertAt for index larger than 0.
// This should result in an std::range_error being raised.
void insertAt_empty_incorrect() {

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    // insertAt for out-of-range index
    test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
    // if insertAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    range_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0]");
    
}

// Tests correct insertAt for front of 1-element list.
void insertAt_front_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at front
    test_list.insertAt('b', 0);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'a');
    assert(test_list.last() == 'a');
    
}

// Tests correct insertAt for back of 1-element list.
void insertAt_back_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at back
    test_list.insertAt('b', 1);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    
}

// Tests calling insertAt for a large number of elements.
// Not only does this test insertAt, it also checks that
// array expansion works correctly.
void insertAt_many_elements() {
    
    CharLinkedList test_list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.insertAt('a', i);
    }

    assert(test_list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
    
}

// Tests insertion into front of a larger list
void insertAt_front_large_list() {
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    test_list.insertAt('y', 0);

    assert(test_list.size() == 10);
    assert(test_list.elementAt(0) == 'y');
    assert(test_list.toString() ==     "[CharLinkedList of"
                                       " size 10 <<yabczdefgh>>]");
    assert(test_list.toReverseString() == "[CharLinkedList of size 10"
                                          " <<hgfedzcbay>>]");

}

// Tests insertion into the back of a larger list
void insertAt_back_large_list() {

    char test_arr[10] = { 'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 10);  

    test_list.insertAt('x', 10);

    assert(test_list.size() == 11);
    assert(test_list.elementAt(10) == 'x');
    assert(test_list.toString() == 
    "[CharLinkedList of size 11 <<yabczdefghx>>]"); 

}

// Tests insertion into the middle of a larger list
void insertAt_middle_large_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.insertAt('z', 3);

    assert(test_list.size() == 9);
    assert(test_list.elementAt(3) == 'z');
    assert(test_list.toString() ==     "[CharLinkedList of"
                                       " size 9 <<abczdefgh>>]");

}

// Tests out-of-range insertion for a non-empty list.
void insertAt_nonempty_incorrect() {
   
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8]");
    
}

// test that the default constructor (and destructor through valgrind) work
void test_first_constructor() {
    CharLinkedList list;
    assert(list.size() == 0);
    assert(list.isEmpty());
}

// test elementAt at the arrSize (just out of bounds)
void test_elementAt_arrSize() {
    bool range_error_check = false;
    string error_message = "";
    CharLinkedList list('y');

    try {
        list.elementAt(1);
    }
    catch (const std::range_error &e) {
        range_error_check = true;
        error_message = e.what();
    }

    assert(range_error_check);
    assert(error_message == "index (1) not in range [0..1)");
}

// test elementAt in the middle (and edges) of the array
void elementAt_middle_correct() {
    char test_arr[9] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'y'};
    CharLinkedList test_list(test_arr, 9);

    assert(test_list.elementAt(5) == 'f');
    assert(test_list.elementAt(2) == 'c');
    assert(test_list.elementAt(8) == 'y');
}

// test removeAt in the middle of the list
void test_removeAt_correct() {
    char test_arr[9] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'y'};
    CharLinkedList list(test_arr, 9);

    list.removeAt(4);

    assert(list.size() == 8);
    assert(list.toString() == "[CharLinkedList of size 8 <<abcdfghy>>]");
    assert(list.toReverseString() == "[CharLinkedList of size 8 <<yhgfdcba>>]");
}

// test removeAt just above the upper limit in the range
void removeAt_arrSize() {
    char test_arr[9] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'y'};
    CharLinkedList list(test_arr, 9);

    bool range_error_check = false;
    std::string error_message = "";

    try {
        list.removeAt(9);
    }
    catch (const std::range_error &e) {
        range_error_check = true;
        error_message = e.what();
    }

    assert(range_error_check);
    assert(error_message == "index (9) not in range [0..9)");
}

// test removeAt with a negative number
void removeAt_negative_number() {
    char test_arr[9] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'y'};
    CharLinkedList list(test_arr, 9);

    bool range_error_check = false;
    std::string error_message = "";

    try {
        list.removeAt(-3);
    }
    catch (const std::range_error &e) {
        range_error_check = true;
        error_message = e.what();
    }

    assert(range_error_check);
    assert(error_message == "index (-3) not in range [0..9)");
}

// test removeAt in an empty list
void removeAt_empty_list() {
    CharLinkedList list;

    bool range_error_check = false;
    std::string error_message = "";

    try {
        list.removeAt(0);
    }
    catch (const std::range_error &e) {
        range_error_check = true;
        error_message = e.what();
    }

    assert(range_error_check);
    assert(error_message == "index (0) not in range [0..0)");
}

// test isEmpty with an empty list
void isEmpty_true() {
    CharLinkedList list('R');

    list.insertAt('x', 1);
    list.removeAt(0);
    list.removeAt(0);

    assert(list.isEmpty());
}

// test isEmpty when the list is not, in fact, empty
void isEmpty_false() {
    CharLinkedList list('L');

    assert(not list.isEmpty());
}

// test the size function of an empty list
void size_test_empty() {
    CharLinkedList list;

    assert(list.size() == 0);
}

// test the size function with one element
void size_test_1() {
    CharLinkedList list('c');

    assert(list.size() == 1);
}

// test the size function again
void size_test_2() {
    char test_arr[9] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'y'};
    CharLinkedList list(test_arr, 9);

    list.removeAt(2);

    assert(list.size() == 8);
}

// test insertInOrder in the middle of the array
void insertInOrder_correct() {
    char test_arr[7] = { 'a', 'b', 'c', 'e', 'f', 'g', 'h'};
    CharLinkedList list(test_arr, 7);

    list.insertInOrder('d');
    assert(list.toString() == "[CharLinkedList of size 8 <<abcdefgh>>]");
    assert(list.toReverseString() == "[CharLinkedList of size 8 <<hgfedcba>>]");
}

// test insertInOrder with a non letter char
void insertInOrder_non_letter_char() {
    char test_arr[6] = {'D', 'E', 'F', 'a', 'b', 'c'};;
    CharLinkedList list(test_arr, 6);

    list.insertInOrder('_');

    assert(list.toString() == "[CharLinkedList of size 7 <<DEF_abc>>]");
    assert(list.toReverseString() == "[CharLinkedList of size 7 <<cba_FED>>]");
}

// test insertInOrder with an empty list
void insertInOrder_empty_test() {
    CharLinkedList list;

    list.insertInOrder('H');

    assert(list.size() == 1);
    assert(list.elementAt(0) == 'H');
}

// test insertInOrder where the char should insert at the end
void insertInOrder_end() {
    char test_arr[7] = { 'a', 'b', 'c', 'e', 'f', 'g', 'h'};
    CharLinkedList list(test_arr, 7);

    list.insertInOrder('v');

    assert(list.toString() == "[CharLinkedList of size 8 <<abcefghv>>]");
    assert(list.toReverseString() == "[CharLinkedList of size 8 <<vhgfecba>>]");
}

// test insertInOrder where the char should insert as the first element
void insertInOrder_first_element() {
    char test_arr[7] = { 'a', 'b', 'c', 'e', 'f', 'g', 'h'};
    CharLinkedList list(test_arr, 7);

    list.insertInOrder('A');

    assert(list.toString() == "[CharLinkedList of size 8 <<Aabcefgh>>]");
    assert(list.toReverseString() == "[CharLinkedList of size 8 <<hgfecbaA>>]");
}

// make sure clear clears out an existing array
void clear_check() {
    char test_arr[7] = { 'a', 'b', 'c', 'e', 'f', 'g', 'h'};
    CharLinkedList list(test_arr, 7);

    list.clear();

    assert(list.size() == 0);
    assert(list.isEmpty());
}

// test clear on an empty list
void clear_if_empty() {
    CharLinkedList list;

    list.clear();

    assert(list.size() == 0);
    assert(list.isEmpty());
}

// test first in an empty list
void first_if_empty() {
    CharLinkedList list;

    bool runtime_error_present = false;
    std::string error_message = "";

    try {
        list.first();
    }
    catch (const std::runtime_error &e) {
        runtime_error_present = true;
        error_message = e.what();
    }

    assert(runtime_error_present);
    assert(list.size() == 0);
    assert(error_message == "cannot get first of empty LinkedList");
}

// test first in a normal array
void first_correct() {
    char test_arr[7] = { 'a', 'b', 'c', 'e', 'f', 'g', 'h'};
    CharLinkedList list(test_arr, 7);

    list.first();

    assert(list.elementAt(0) == 'a');
    assert(list.first() == 'a');
    assert(not list.isEmpty());
}

// test first with a one element list
void first_one_char() {
    CharLinkedList list('t');

    list.first();

    assert(list.first() == 't');
}

// test last in an empty array
void last_if_empty() {
    CharLinkedList list;

    bool runtime_error_present = false;
    std::string error_message = "";

    try {
        list.last();
    }
    catch (const std::runtime_error &e) {
        runtime_error_present = true;
        error_message = e.what();
    }

    assert(runtime_error_present);
    assert(list.size() == 0);
    assert(error_message == "cannot get last of empty LinkedList");
}

// test last in a full list
void last_correct() {
    char test_arr[7] = { 'a', 'b', 'c', 'e', 'f', 'g', 'h'};
    CharLinkedList list(test_arr, 7);

    assert(list.elementAt(6) == 'h');
    assert(list.last() == 'h');
    assert(not list.isEmpty());
    assert(list.toReverseString() == "[CharLinkedList of size 7 <<hgfecba>>]");
}

// test last with a one element list
void last_one_char() {
    CharLinkedList list('j');

    assert(list.elementAt(0) == 'j');
    assert(list.last() == 'j');
    assert(not list.isEmpty());
}

// test toString with an empty list
void toString_empty() {
    CharLinkedList list;

    assert(list.isEmpty());
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
    assert(list.toReverseString() == "[CharLinkedList of size 0 <<>>]");
}

// test toString with one element in a list
void toString_one_char() {
    CharLinkedList list('t');

    assert(list.toString() == "[CharLinkedList of size 1 <<t>>]");
    assert(list.toReverseString() == "[CharLinkedList of size 1 <<t>>]");
}

// test toString with a normal list
void toString_normal() {
    char test_arr[4] = {'s', 'e', 't', 'h'};
    CharLinkedList list(test_arr, 4);

    assert(list.toString() == "[CharLinkedList of size 4 <<seth>>]");
    assert(list.toReverseString() == "[CharLinkedList of size 4 <<htes>>]");
}

// test toReverseString with an empty list
void toReverseString_empty() {
    CharLinkedList list;

    assert(list.isEmpty());
    assert(list.toReverseString() == "[CharLinkedList of size 0 <<>>]");
}

// test toReverseString with a one character list
void toReverseString_one_char() {
    CharLinkedList list('H');

    assert(list.toReverseString() == "[CharLinkedList of size 1 <<H>>]");
}

// test toReverseString in a normal list
void toReverseString_normal() {
    char test_arr[4] = {'A', 'P', 'E', 'S'};
    CharLinkedList list(test_arr, 4);

    assert(list.toReverseString() == "[CharLinkedList of size 4 <<SEPA>>]");
}

// test pushAtBack in an empty list
void pushAtBack_empty() {
    CharLinkedList list;

    list.pushAtBack('g');
    assert(list.elementAt(0) == 'g');
}

// test pushAtBack in a full list
void pushAtBack_normal() {
    char test_arr[4] = {'l', 'a', 't', 'e'};
    CharLinkedList list(test_arr, 4);

    list.pushAtBack('T');

    assert(list.toString() == "[CharLinkedList of size 5 <<lateT>>]");
    assert(list.toReverseString() == "[CharLinkedList of size 5 <<Tetal>>]");
}

// test pushAtBack with a one char list
void pushAtBack_singleton() {
    CharLinkedList list('h');

    list.pushAtBack('L');

    assert(list.elementAt(1) == 'L');
    assert(list.toString() == "[CharLinkedList of size 2 <<hL>>]");
    assert(list.toReverseString() == "[CharLinkedList of size 2 <<Lh>>]");
}

// test pushAtFront in an empty list
void pushAtFront_empty() {
    CharLinkedList list;

    list.pushAtFront('B');

    assert(list.elementAt(0) == 'B');
    assert(list.toString() == "[CharLinkedList of size 1 <<B>>]");
    assert(list.toReverseString() == "[CharLinkedList of size 1 <<B>>]");
}

// test pushAtFront in a one char list
void pushAtFront_singleton() {
    CharLinkedList list('j');

    list.pushAtFront('v');

    assert(list.toString() == "[CharLinkedList of size 2 <<vj>>]");
    assert(list.toReverseString() == "[CharLinkedList of size 2 <<jv>>]");
}

// test pushAtFront in a normal list
void pushAtFront_normal() {
    char test_arr[5] = {'s', 'I', 'U', 'u', 'U'};
    CharLinkedList list(test_arr, 5);

    list.pushAtFront('G');

    assert(list.toString() == "[CharLinkedList of size 6 <<GsIUuU>>]");
    assert(list.toReverseString() == "[CharLinkedList of size 6 <<UuUIsG>>]");
}

// test popFromFront in an empty list
void popFromFront_empty() {
    CharLinkedList list;

    bool runtime_error_present = false;
    std::string error_message = "";

    try {
        list.popFromFront();
    }
    catch (const std::runtime_error &e) {
        runtime_error_present = true;
        error_message = e.what();
    }

    assert(runtime_error_present);
    assert(error_message == "cannot pop from empty LinkedList");
}

// test popFromFront in a one element list
void popFromFront_singleton() {
    CharLinkedList list('a');

    list.popFromFront();

    assert(list.isEmpty());
    assert(list.size() == 0);
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
    assert(list.toReverseString() == "[CharLinkedList of size 0 <<>>]");
}

// test popFromFront with a normal list
void popFromFront_full() {
    char test_arr[3] = {'y', 'e', 's'};
    CharLinkedList list(test_arr, 3);

    list.popFromFront();

    assert(list.toString() == "[CharLinkedList of size 2 <<es>>]");
    assert(list.toReverseString() == "[CharLinkedList of size 2 <<se>>]");
}

// test replceAt in an empty array list
void replaceAt_empty() {
    CharLinkedList list;

    bool range_error_present = false;
    std::string error_message = "";

    try {
        list.replaceAt('i', 0);
    }
    catch (const std::range_error &e){
        range_error_present = true;
        error_message = e.what();
    }

    assert(range_error_present);
    assert(error_message == "index (0) not in range [0..0)");
}

// test replaceAt in an index that is greater than the size of the list
void replaceAt_full_incorrect() {
    char test_arr[5] = {'s', 'I', 'U', 'u', 'U'};
    CharLinkedList list(test_arr, 5);

    bool range_error_present = false;
    std::string error_message = "";

    try {
        list.replaceAt('g', 9);
    }
    catch (const std::range_error &e) {
        range_error_present = true;
        error_message = e.what();
    }

    assert(range_error_present);
    assert(error_message == "index (9) not in range [0..5)");
}

// test replaceAt with a ton of elements
void replaceAt_many_elements() {
    CharLinkedList list;

    for(int i = 0; i < 1000; i++) {
        list.insertAt('B', i);
    }

    for(int i = 0; i < 1000; i++) {
        list.replaceAt('Y', i);
    }

    for(int i = 0; i < 1000; i++) {
        assert(list.elementAt(i) == 'Y');
    }
}

// test replaceAt with a one char list
void replaceAt_singleton_correct() {
    CharLinkedList list('v');

    list.replaceAt('g', 0);

    assert(list.size() == 1);
    assert(list.elementAt(0) == 'g');
}

// test replaceAt with an out of bounds index in a one element list
void replaceAt_singleton_incorrect() {
    CharLinkedList list('O');

    bool range_error_present = false;
    string error_message = "";

    try {
        list.replaceAt('f', 30);
    }
    catch (const std::range_error &e) {
        range_error_present = true;
        error_message = e.what();
    }

    assert(range_error_present);
    assert(error_message == "index (30) not in range [0..1)");
}

// test concatenate two lists with the second one being longer
void concatenate_second_longer() {
    char goat[4] = {'g', 'o', 'a', 't'};
    char zebra[5] = {'z', 'e', 'b', 'r', 'a'};
    CharLinkedList goatlist(goat, 4);
    CharLinkedList zebralist(zebra, 5);

    goatlist.concatenate(&zebralist);

    assert(goatlist.toString() == "[CharLinkedList of size 9 <<goatzebra>>]");
    assert(goatlist.toReverseString() == "[CharLinkedList of size "
                                         "9 <<arbeztaog>>]");
}

// test concatenate with two lists of the same size
void concatenate_same_size() {
    char arr[5] = {'f', 'r', 'a', 'u', 'd'};
    char arr2[5] = {'b', 'e', 'n', 'n', 'y'};

    CharLinkedList list(arr, 5);
    CharLinkedList list2(arr2, 5);

    list.concatenate(&list2);

    assert(list.toString() == "[CharLinkedList of size 10 <<fraudbenny>>]");
    assert(list.toReverseString() == "[CharLinkedList of size "
                                     "10 <<ynnebduarf>>]");
}

// test concatenate with two empty array lists
void concatenate_both_empty() {
    CharLinkedList list;
    CharLinkedList list2;

    list.concatenate(&list2);

    assert(list.isEmpty());
    assert(list.size() == 0);
}

// test concatenate with an empty array as the argument
void concatenate_second_empty() {
    char arr[5] = {'f', 'r', 'a', 'u', 'd'};

    CharLinkedList list(arr, 5);
    CharLinkedList list2;

    list.concatenate(&list2);

    assert(list.toString() == "[CharLinkedList of size 5 <<fraud>>]");
    assert(list.toReverseString() == "[CharLinkedList of size 5 <<duarf>>]");
}

// test concatenate with the first array being empty
void concatenate_first_empty() {
    char arr[5] = {'f', 'r', 'a', 'u', 'd'};

    CharLinkedList list;
    CharLinkedList list2(arr, 5);

    list.concatenate(&list2);

    assert(not list.isEmpty());
    assert(list.toString() == "[CharLinkedList of size 5 <<fraud>>]");
    assert(list.toReverseString() == "[CharLinkedList of size 5 <<duarf>>]");
}

// test concatenate with the first array being longer
void concatenate_first_longer() {
    char arr[4] = {'L', 'i', 'f', 'e'};
    char arr2[3] = {'t', 'e', 'a'};

    CharLinkedList list(arr, 4);
    CharLinkedList list2(arr2, 3);

    list.concatenate(&list2);

    assert(not list.isEmpty());
    assert(list.size() == 7);
    assert(list.toString() == "[CharLinkedList of size 7 <<Lifetea>>]");
    assert(list.toReverseString() == "[CharLinkedList of size 7 <<aetefiL>>]");
}

// test concatenate with two singleton lists
void concatenate_both_singleton() {
    CharLinkedList list('y');
    CharLinkedList list2('z');

    list.concatenate(&list2);

    assert(list.size() == 2);
    assert(list.toString() == "[CharLinkedList of size 2 <<yz>>]");
    assert(list.toReverseString() == "[CharLinkedList of size 2 <<zy>>]");
}

// test concatenate with a lists's own list
void concatenate_oneself() {
    char arr[3] = {'y', 'o', 'u'};
    CharLinkedList list(arr, 3);

    list.concatenate(&list);

    assert(list.toString() == "[CharLinkedList of size 6 <<youyou>>]");
    assert(list.toReverseString() == "[CharLinkedList of size 6 <<uoyuoy>>]");
}

// test that the deep copy constructor copies the list.
// also tests the copyHelper function since the deep copy constructor
// does nothing but call copyHelper
void deep_copy_constructor_and_copyHelper_test() {
    char test_arr[5] = {'S', 'a', 'r', 'a', 'h'};
    CharLinkedList list(test_arr, 5);
    CharLinkedList list2 = list;

    assert(list2.size() == 5);
    assert(list2.toString() == "[CharLinkedList of size 5 <<Sarah>>]");
    assert(list2.toReverseString() == "[CharLinkedList of size 5 <<haraS>>]");
}

// test that the assignment operator copies the list properly
void assignment_operator_test() {
    char test_arr[5] = {'S', 'a', 'r', 'a', 'h'};
    CharLinkedList list(test_arr, 5);
    CharLinkedList list2;
    list2 = list;

    assert(list2.size() == 5);
    assert(list2.toString() == "[CharLinkedList of size 5 <<Sarah>>]");
    assert(list2.toReverseString() == "[CharLinkedList of size 5 <<haraS>>]");
}

// test that the deep copy constructor copies the list.
// also tests the copyHelper function since the deep copy constructor
// does nothing but call copyHelper
void deep_copy_and_copyHelper_test() {
    char test_arr[4] = {'j', 'a', 'i', 'l'};
    CharLinkedList list(test_arr, 4);
    CharLinkedList list2(list);

    assert(list2.size() == 4);
    assert(list2.toString() == "[CharLinkedList of size 4 <<jail>>]");
    assert(list2.toReverseString() == "[CharLinkedList of size 4 <<liaj>>]");
}


/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/*                  Private helper function tests                  */
/*                                                                 */
/*                                                                 */
/*      These will be commented out, but I tested them all         */
/*      by making certain functions/variables public and they      */
/*      all passed                                                 */
/*                                                                 */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

/*
* Note for all private helper tests: I would make most if not all private
* variables/functions (depending on what was relevant) public to ensure
* that everything ran.
*/

// I also tested copyHelper in the two deep copy tests so that won't be
// tested much here

// destructorHelper tests are mainly to test valgrind (since the function
// should just delete the memory and do nothing else)

// // test destructorHelper with a full list
// void test_destructorHelper_full_list() {
//     char test_arr[4] = {'g', 'o', 'o', 'd'};
//     CharLinkedList list(test_arr, 4);

//     list.destructorHelper(list.CharLinkedList::front);
// }

// // test destructorHelper with an empty list
// void test_destructorHelper_empty_list() {
//     CharLinkedList list;

//     list.destructorHelper(list.CharLinkedList::front);
// }

// // test destructorHelper with a singleton list
// void test_destructorHelper_singleton() {
//     CharLinkedList list('g');

//     list.destructorHelper(list.CharLinkedList::front);
// }

// /*
// * Note: copyHelper alone will have valgrind issues (not deleting all
// * of the memory) if the original CharLinkedList is not empty. This is
// * why the edge case tests I can run are limited
// */
// void test_copyHelper_first_empty() {
//     char arr[6] = {'h', 'u', 'r', 'r', 'a', 'y'};
//     CharLinkedList list;
//     CharLinkedList list2(arr, 6);

//     list.copyHelper(list2);

//     assert(list.size() == 6);
//     assert(list.toString() == "[CharLinkedList of size 6 <<hurray>>]");
//     assert(list.toReverseString() == "[CharLinkedList of"
//                                      " size 6 <<yarruh>>]");
// }

// // test copyHelper with two empty lists
// void test_copyHelper_both_empty() {
//     CharLinkedList list;
//     CharLinkedList list2;

//     list.copyHelper(list2);

//     assert(list.isEmpty());
// }

// // test newNode
// void test_newNode() {
//     CharLinkedList list;

//     CharLinkedList::Node *test = list.newNode('g');

//     assert(test->character == 'g');
//     assert(test->next == nullptr);
//     assert(test->prev == nullptr);

//     delete test;
// }

// /* Note for reach index: will not work if called in an empty list,
// * the index is less than 0, or if the index is greater than or equal
// * to listSize, but it should never be called if any of those happen
// */

// // test reachIndex in the middle of a list
// void test_reachIndex_middle_of_list() {
//     char arr[6] = {'h', 'u', 'r', 'd', 'a', 'y'};
//     CharLinkedList list(arr, 6);

//     int index = 3;

//     CharLinkedList::Node *test =
//     list.reachIndex(list.CharLinkedList::front, index, 0);
    
//     assert(test->character == 'd');
//     assert(list.size() == 6);
// }

// // test reachIndex with a singleton list
// void test_reachIndex_first_singleton() {
//     CharLinkedList list('t');

//     int index = 0;

//     CharLinkedList::Node *test = 
//     list.reachIndex(list.CharLinkedList::front, index, 0);

//     assert(test->character == 't');
//     assert(list.size() == 1);
// }

// // test reachIndex at the last index
// void test_reachIndex_last_full() {
//     char arr[6] = {'h', 'u', 'r', 'd', 'a', 'y'};
//     CharLinkedList list(arr, 6);

//     int index = 5;

//     CharLinkedList::Node *test =
//     list.reachIndex(list.CharLinkedList::front, index, 0);

//     assert(test->character == 'y');
//     assert(list.toString() == "[CharLinkedList of size 6 <<hurday>>]");
//     assert(list.toReverseString() == "[CharLinkedList of size 6"
//                                      " <<yadruh>>]");
// }

// /*
// * Note for both range error functions: the listSize and index feature,
// * but neither number really matters because the error will be thrown either
// * way
// */

// // test the softRangeError function
// void test_softRangeError() {

//     bool range_error_thrown = false;

//     std::string error_message = "";
//     CharLinkedList list;

//     list.listSize = 5;

//     try {
//         list.softRangeError(8);
//     }
//     catch (const std::range_error &e) {
//         range_error_thrown = true;
//         error_message = e.what();
//     }

//     assert(range_error_thrown);
//     assert(error_message == "index (8) not in range [0..5)");
// }

// // test the hardRangeError function
// void test_hardRangeError() {

//     bool range_error_thrown = false;

//     std::string error_message = "";
//     CharLinkedList list;

//     list.listSize = 9;

//     try {
//         list.hardRangeError(11);
//     }
//     catch (const std::range_error &e) {
//         range_error_thrown = true;
//         error_message = e.what();
//     }

//     assert(range_error_thrown);
//     assert(error_message == "index (11) not in range [0..9]");
// }

// // test the runtimePopError function
// void test_runtimePopError() {
//     bool runtime_error_thrown = false;

//     std::string error_message = "";
//     CharLinkedList list;

//     try {
//         list.runtimePopMessage();
//     }
//     catch (const std::runtime_error &e) {
//         runtime_error_thrown = true;
//         error_message = e.what();
//     }

//     assert(runtime_error_thrown);
//     assert(error_message == "cannot pop from empty LinkedList");
// }

// // Note: emptyListHelper will fail valgrind under most tests
// // because it should only be called if the function is currently empty
// void test_emptyListHelper() {
//     CharLinkedList list;

//     list.emptyListHelper();

//     assert(list.size() == 0);
//     assert(list.isEmpty());
// }
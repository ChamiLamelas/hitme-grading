/*
*  CharLinkedList.cpp
*  Seth Gellman (sgellm01)
*  1/30/24
*
*  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
*
*  This file implements the CharLinkedList class.
*
*/

#include "CharLinkedList.h"
#include <string>
#include <sstream>

/*
* Name: default constructor
* Purpose: construct an empty linked list
* Arguments: none
* Returns: nothing
* Side Effects: sets front and back to nullptr, list size to 0
*/
CharLinkedList::CharLinkedList() {
    emptyListHelper();
}

/*
* Name: contructor
* Purpose: Construct a CharLinkedList with one char in it
* Arguments: a char to be the only element in the array
* Returns: nothing
* Side Effects: list size set to 1, front and back pointers set equal to
*               the one existing node
*/
CharLinkedList::CharLinkedList(char c) {
    listSize = 1;
    Node *new_node = newNode(c);
    front = new_node;
    back = new_node;
}

/*
* Name: constructor
* Purpose: Construct a CharLinkedList with any size
* Arguments: an array of chars, an integer representing the length of that
*            array
* Returns: nothing
* Side Effects: listSize reset, char array copied as nodes in the linked list,
*               front and back pointers set
*/
CharLinkedList::CharLinkedList(char arr[], int size) {
    listSize = size;
    Node *array[size];
    for(int i = 0; i < size; i++) {
        array[i] = newNode(arr[i]);
    }
    for(int i = 0; i < size; i++) {
        if (i != (size - 1)) {
            array[i]->next = array[i + 1];
        }
        if (i != 0) {
            array[i]->prev = array[i - 1];
        }
    }
    if (size > 0) {
        front = array[0];
        back = array[size - 1];
    } else {
        front = nullptr;
        back = nullptr;
    }
}

/*
* Name: constructor
* Purpose: make a deep copy of an instance of a CharLinkedList
* Arguments: the address of a CharLinkedList to be copied
* Returns: nothing
* Side Effects: listSize reset, char array copied as nodes in the linked list,
*               front and back pointers set
*/
CharLinkedList::CharLinkedList(const CharLinkedList &other) {
    copyHelper(other);
}

/*
* Name: destructor
* Purpose: recycle/delete all of the heap-allocated memory used in the class
* Arguments: none
* Returns: nothing
* Side Effects: done in recursive helper function
*/
CharLinkedList::~CharLinkedList() {
    destructorHelper(front);
}

/*
* Name: CharLinkedList assignment operator
* Purpose: defines an assignment operator
* Arguments: address of an instance of a CharLinkedList
* Returns: a pointer to a CharLinkedList equal to the one in the parameter
* Side Effects: recycles all previously existing heap-allocated memory before
*               essentially creating the new linked list
*/
CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other) {
    if (this == &other) {
        return *this;
    }
    destructorHelper(front);
    copyHelper(other);

    return *this;
}

/*
* Name: isEmpty
* Purpose: determine if the CharLinkedList is empty
* Arguments: none
* Returns: a boolean true if the linked list has 0 elements or false if
*          it has any elements in it
* Side Effects: none
*/
bool CharLinkedList::isEmpty() const {
    return listSize == 0;
}

/*
* Name: clear
* Purpose: delete the old array and create a new array (which will
*          inherently be empty)
* Arguments: none
* Returns: nothing
* Side Effects: delete/recycle memory from old list, set listSize to 0, 
*               and set front and back to null pointers
*/
void CharLinkedList::clear() {
    destructorHelper(front);
    emptyListHelper();
}

/*
* Name: size
* Purpose: return the size of the array
* Arguments: none
* Returns: an integer representing the size of the list
* Side Effects: none
*/
int CharLinkedList::size() const {
    return listSize;
}

/*
* Name: first
* Purpose: return the first element in the list
* Arguments: none
* Returns: the first element in the list
* Side Effects: if the list is empty, a runtime_error will be thrown
*/
char CharLinkedList::first() const {
    if (isEmpty()) {
        throw std::runtime_error("cannot get first of empty LinkedList");
    }
    return front->character;
}

/*
* Name: last
* Purpose: return the last element in the list
* Arguments: none
* Returns: the last element in the list
* Side Effects: if the list is empty, a runtime_error will be thrown
*/
char CharLinkedList::last() const {
    if (isEmpty()) {
        throw std::runtime_error("cannot get last of empty LinkedList");
    }
    return back->character;
}

/*
* Name: elementAt
* Purpose: return the element at a given index
* Arguments: an integer representing the index
* Returns: the element at a given index
* Side Effects: if the index is less than 0 or greater than or equal to
*               the list size, a range_error will be thrown; a recursive
*               helper function is used to find the node
*/
char CharLinkedList::elementAt(int index) const {
    if ((index < 0) or (index >= listSize)) {
        softRangeError(index);
    }
    Node *curr = reachIndex(front, index, 0);
    return curr->character;
}

/*
* Name: toString
* Purpose: string together all of the elements into
*          a standardized message
* Arguments: none
* Returns: a string with a message containing the size of the list
*          and all of the elements in order
* Side Effects: none
*/
std::string CharLinkedList::toString() const {
    std::stringstream ss;
    
    if (isEmpty()) {
        ss << "[CharLinkedList of size 0 <<>>]";
    } else {
        ss << "[CharLinkedList of size " << listSize << " <<";

        Node *curr = front;

        for(int i = 0; i < listSize; i++) {
            ss << curr->character;
            curr = curr->next;
        }
        ss << ">>]";
    }
    return ss.str();
}

/*
* Name: toReverseString
* Purpose: string together all of the elements in an array (in reverse order)
*          into a standardized message
* Arguments: none
* Returns: a string with a message containing the size of the list
*          and all of the elements in reverse order
* Side Effects: none
*/
std::string CharLinkedList::toReverseString() const {
    std::stringstream ss;

    if (isEmpty()) {
        ss << "[CharLinkedList of size 0 <<>>]";
    } else {
        ss << "[CharLinkedList of size " << listSize << " <<";

        Node *curr = back;

        for(int i = listSize - 1; i >= 0; i--) {
            ss << curr->character;
            curr = curr->prev;
        }
        ss << ">>]";
    }
    return ss.str();
}

/*
* Name: pushAtBack
* Purpose: add an element to the back of the list
* Arguments: a character that will be inserted into the back
*            of the list
* Returns: nothing
* Side Effects: will change back pointer and possibly front
*               (if empty beforehand), increments listSize
*/
void CharLinkedList::pushAtBack(char c) {
    Node *new_node = newNode(c);
    if (isEmpty()) {
        front = new_node;
        back = new_node;
    } else {
        new_node->prev = back;
        back->next = new_node;
        back = new_node;
    }
    listSize++;
}

/*
* Name: pushAtBack
* Purpose: add an element to the back of the list
* Arguments: a character that will be inserted into the back
*            of the list
* Returns: nothing
* Side Effects: will change front pointer and possibly back
*               (if empty beforehand), increments listSize
*/
void CharLinkedList::pushAtFront(char c) {
    Node *new_node = newNode(c);
    if (isEmpty()) {
        front = new_node;
        back = new_node;
    } else {
        new_node->next = front;
        front->prev = new_node;
        front = new_node;
    }
    listSize++;
}

/*
* Name: insertAt
* Purpose: insert an element at a given index
* Arguments: a char c as the element to be added and an integer representing
*            an index to find where it should be inserted
* Returns: nothing
* Side Effects: if index is less than 0 or greater than the listSize, a
*               range_error will be thrown. the front and back pointers might
*               be reset. the recursive helper function reachIndex is used to
*               find the Node at the given index. the next and prev pointers
*               for all invovled nodes will be reset
*/
void CharLinkedList::insertAt(char c, int index) {
    if (index < 0 or index > listSize) {
        hardRangeError(index);
    }

    if (index == 0) {
        pushAtFront(c);
    } else if (index == listSize) {
        pushAtBack(c);
    } else {
        Node *new_node = newNode(c);
        if (isEmpty()) {
            front = new_node;
            back = new_node;
        } else {
            Node *curr = reachIndex(front, index, 0);

            curr->prev->next = new_node;
            new_node->prev = curr->prev;
            new_node->next = curr;
            curr->prev = new_node;
        }
        listSize++;
    }
}

/*
* Name: insertInOrder
* Purpose: insert an element into the list in ASCII order
* Arguments: a char c as the element to be added
* Returns: nothing
* Side Effects: the list should already be in order according to the char's
*               ASCII values, and insertAt will be called when the list either
*               reaches the end or the inputted character is found to be
*               less than or equal to (by ASCII value) a char in the list.
*               since insertAt will be called no matter what, all side effects
*               from that function apply here as well
*/
void CharLinkedList::insertInOrder(char c) {
    bool continue_loop = true;

    Node *curr = front;

    for(int i = 0; continue_loop; i++) {
        if ((i == listSize) or (c <= curr->character)) {
            continue_loop = false;
            insertAt(c, i);
        } else {
            curr = curr->next;
        }
    }
}

/*
* Name: popFromFront
* Purpose: remove the first element in the list
* Arguments: none
* Returns: nothing
* Side Effects: if the list is empty, a runtime_error will be thrown.
*               the front (and possibly back) pointer(s) will be changed.
*               the old first node will be deleted and the next/prev pointers
*               will be reassigned for all relevant nodes
*/
void CharLinkedList::popFromFront() {
    if (isEmpty()) {
        runtimePopMessage();
    }

    if (listSize == 1) {
        delete front;
        front = nullptr;
        back = nullptr;
    } else {
        front = front->next;
        delete front->prev;
        front->prev = nullptr;
    }
    listSize--;
}

/*
* Name: popFromBack
* Purpose: remove the last element from the list
* Arguments: none
* Returns: nothing
* Side Effects: update back and possibly front pointers, delete
*               the memory allocated on the heap for the old last element
*/
void CharLinkedList::popFromBack() {
    if (isEmpty()) {
        runtimePopMessage();
    }

    if (listSize == 1) {
        delete back;
        back = nullptr;
        front = nullptr;
    } else {
        back = back->prev;
        delete back->next;
        back->next = nullptr;
    }
    listSize--;
}

/*
* Name: removeAt
* Purpose: remove an element at an inputted index in the list
* Arguments: an integer representing an index
* Returns: nothing
* Side Effects: If the index is less than 0 or greater than or equal to
*               the listSize, a range_error will be thrown. The front and
*               back pointers may be updated. The recursive helper function
*               reachIndex should be used to reach the spot in the list where
*               the element will eventually be removed. The memory from the
*               removed element will be deleted. All relevant next/prev
*               pointers will be updated. The listSize will decrease by one.
*/
void CharLinkedList::removeAt(int index) {
    if (index < 0 or index >= listSize) {
        softRangeError(index);
    }

    if (index == 0) {
        popFromFront();
    } else if (index == (listSize - 1)) {
        popFromBack();
    } else {
        Node *curr = reachIndex(front, index, 0);
        curr->prev->next = curr->next;
        curr->next->prev = curr->prev;
        delete curr;
        listSize--;
    }
}

/*
* Name: replaceAt
* Purpose: replace an element at an inputted index
* Arguments: a char c that will be inserted into the list
*            and an integer representing the index where the element
*            will be replacing the old one
* Returns: nothing
* Side Effects: If the index is less than 0 or greater than or equal to
*               the listSize, a range_error will be thrown. the recursive
*               helper function reachIndex is used to find the element at
*               the inputted index. updates all next/prev pointers to make
*               sure the list is in order, and the front/back pointers may
*               update depending on the index. the memory representing the
*               node that was replaced is deleted
*/
void CharLinkedList::replaceAt(char c, int index) {
    if (index < 0 or index >= listSize) {
        softRangeError(index);
    }

    Node *new_node = newNode(c);
    Node *curr = reachIndex(front, index, 0);

    // set all relevant next and previous pointers to put the new node
    // into the list
    new_node->prev = curr->prev;
    new_node->next = curr->next;
    if (curr->next != nullptr) {
        curr->next->prev = new_node;
    }
    if (curr->prev != nullptr) {
        curr->prev->next = new_node;
    }

    delete curr;

    if (index == (listSize - 1)) {
        back = new_node;
    }
    if (index == 0) {
        front = new_node;
    }
}

/*
* Name: concatenate
* Purpose: to add a copy of the inputted CharLinkedList to 
*          the end of the first CharLinkedList
* Arguments: a pointer to another CharLinkedList
* Returns: nothing
* Side Effects: listSize will be updated to include the sum of both list
*               sizes by the end of the function. It also calls pushAtBack
*               for each time that a new letter needs to be copied over
*               into the back of the old list.
*/
void CharLinkedList::concatenate(CharLinkedList *other) {
    int old_size = listSize;
    int new_size = listSize + other->size();
    Node *other_curr = other->front;

    for(int i = old_size; i < new_size; i++) {
        pushAtBack(other_curr->character);
        other_curr = other_curr->next;
    }
}

/*
* Name: newNode
* Purpose: create memory for a heap-allocated node
*          and initialize the empty node's members
* Arguments: a char that will be the character in the node
* Returns: a pointer to a node on the heap
* Side Effects: the argument char becomes the character member. The
*               next and prev members of the node will be set to nullptr
*/
CharLinkedList::Node *CharLinkedList::newNode(char c) {

    Node *new_node = new Node;
    new_node->character = c;
    new_node->next = nullptr;
    new_node->prev = nullptr;

    return new_node;
}

/*
* Name: reachIndex
* Purpose: find the node in the list at a given index recursively
* Arguments: a pointer to a Node (so that it can go through the list one by
*            one), an integer representing the index in the list, and an
*            integer count (which will always initially be 0)
* Returns: a pointer to a node (which should be the node at the index)
* Side Effects: every time the base case (count is equal to index) is not
*               true, count will increment and the function will call itself
*               again but with the next node in the list
*/
CharLinkedList::Node *CharLinkedList::reachIndex(Node *curr, 
                                                 int index, int count) const {
    if (count == index) {
        return curr;
    }
    count++;

    return reachIndex(curr->next, index, count);
}

/*
* Name: softRangeError
* Purpose: to throw a range_error exception with the given message
* Arguments: an integer representing the index
* Returns: nothing
* Side Effects: should only be called if a given index is out of the range
*               of a given function (such as replaceAt). Also it should be
*               noted that the message has a soft bracket on the end of the
*               error message
*/
void CharLinkedList::softRangeError(int index) const {
    std::stringstream ss;
    ss << "index (" << index << ") not in range [0.." << listSize << ")";
    throw std::range_error(ss.str());
}

/*
* Name: hardRangeError
* Purpose: to throw a range_error exception with the given message
* Arguments: an integer representing the index
* Returns: nothing
* Side Effects: should only be called if a given index is out of the range
*               of a given function (such as insertAt). Also it should be
*               noted that the message has a hard bracket on the end of the
*               error message
*/
void CharLinkedList::hardRangeError(int index) {
    std::stringstream ss;
    ss << "index (" << index << ") not in range [0.." << listSize << "]";
    throw std::range_error(ss.str());
}

/*
* Name: runtimePopMessage
* Purpose: to throw a runtime_error exception with the given message
* Arguments: none
* Returns: nothing
* Side Effects: only be called in the two functions that pop an element
*               (popFromBack and popFromFront)
*/
void CharLinkedList::runtimePopMessage() {
    throw std::runtime_error("cannot pop from empty LinkedList");
}

/*
* Name: destructorHelper
* Purpose: recurse through the list and delete each node until the base case
*          (the node is nullptr which means the end of the list was reached)
* Arguments: a pointer to a node (which will always start at the front)
* Returns: nothing
* Side Effects: front is updated if the base case isn't reached because it
*               will exist in the CharLinkedList either way instead of a local
*               variable that may not pass correctly
*/
void CharLinkedList::destructorHelper(Node *curr) {
    if (curr == nullptr) {
        return;
    }

    front = curr->next;
    delete curr;
    destructorHelper(front);
}

/*
* Name: copyHelper
* Purpose: a helper function for the deep copy constructor and assignment
*          operator to make a deep copy of a list
* Arguments: the address of another CharLinkedList
* Returns: nothing
* Side Effects: if the list in the parameter is empty, emptyListHelper will be
*               called. Otherwise, all aspects of the list (front, back, all
*               nodes and their members) will be updated to match the list
*               in the parameter. Finally, new memory is allocated on the heap
*               to each new node in the list
*/
void CharLinkedList::copyHelper(const CharLinkedList &other) {
    if (other.isEmpty()) {
        emptyListHelper();
    } else {
        listSize = other.listSize;
        Node *copy_curr = other.front;
        front = newNode(copy_curr->character);
        Node *curr = front;

        // after setting the front node, move through the entire list
        // while updating curr at the end of the loop each time
        while (copy_curr->next != nullptr) {
            copy_curr = copy_curr->next;
            curr->next = newNode(copy_curr->character);
            curr->next->prev = curr;
            curr = curr->next;
        }
        back = curr;
    }
}

/*
* Name: emptyListHelper
* Purpose: if the list is empty, set the values to acknowledge that
* Arguments: none
* Returns: nothing
* Side Effects: none
*/
void CharLinkedList::emptyListHelper() {
    listSize = 0;
    front = nullptr;
    back = nullptr;
}
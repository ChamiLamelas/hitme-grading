/*
*  CharLinkedList.h 
*  Seth Gellman (sgellm01)
*  1/30/24
*
*  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
*
*  Purpose: CharLinkedList is a class that represents an ordered list of
*           chars using a linked list. Users can modify the list by replacing,
*           inserting, and removing elements from the list.
*
*/

#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H

#include <string>
using namespace std;

class CharLinkedList {
public:

    CharLinkedList();
    CharLinkedList(char c);
    CharLinkedList(char arr[], int size);
    CharLinkedList(const CharLinkedList &other);

    ~CharLinkedList();

    CharLinkedList &operator=(const CharLinkedList &other);

    bool isEmpty() const;

    void clear();

    int size() const;

    char first() const;
    char last() const;

    char elementAt(int index) const;

    std::string toString() const;
    std::string toReverseString() const;

    void pushAtBack(char c);
    void pushAtFront(char c);

    void insertAt(char c, int index);
    void insertInOrder(char c);

    void popFromFront();
    void popFromBack();

    void removeAt(int index);

    void replaceAt(char c, int index);

    void concatenate(CharLinkedList *other);

private:

    struct Node {
        char character;
        Node *prev;
        Node *next;
    };

    int listSize;

    Node *front;
    Node *back;

    void destructorHelper(Node *curr);
    void copyHelper(const CharLinkedList &other);
    Node *newNode(char c);
    Node *reachIndex(Node *curr, int index, int count) const;

    void softRangeError(int index) const;
    void hardRangeError(int index);
    void runtimePopMessage();

    void emptyListHelper();
};

#endif

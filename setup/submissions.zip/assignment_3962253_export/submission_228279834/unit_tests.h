/*
 *  unit_tests.h
 *  Aadit Zaveri, azaver03
 *  02/05/23
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  Unit Testing: develop individual modules to test functions and 
    testing edge cases.
 *
 */

#include "CharLinkedList.h"
#include <cassert>

/*
 * constructor test 0
 * Make sure no fatal errors/memory leaks in the default constructor
 */
void constructor_test_0() {
    CharLinkedList list;
}

/*
 * constructor test 1
 * Make sure no items exist in the list upon construction
 */
void constructor_test_1() {
    CharLinkedList list; 
    assert(list.size() == 0);
}

/*
 * constructor test 2
 * Make sure constructor implements size 1 and character in LL correctly
 */
void constructor_test_2() {
    CharLinkedList list = CharLinkedList('a'); 
    assert(list.size() == 1);
}

/*
 * constructor test 3
 * Make sure constructor initializes list with values of array provided
 */
void constructor_test_3() {
    char temp_list[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list = CharLinkedList(temp_list, 5); 
    assert(list.size() == 5);
}

/*
 * clear and is_empty
 * Make sure clear and isempty true
 */
void clear_test() {
    char temp_list[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list = CharLinkedList(temp_list, 5); 
    list.clear();
    assert(list.size() == 0);
    assert(list.isEmpty());
}

/*
 * is_empty_true
 * Check empty list
 */
void empty_true_test() {
    CharLinkedList list;
    assert(list.size() == 0);
    assert(list.isEmpty());
}

/*
 * is_empty_false
 * Check empty list
 */
void empty_false_test() {
    char temp_list[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list = CharLinkedList(temp_list, 5); 
    assert(not (list.isEmpty()));
}

/*
 * elementAt_test
 * Make sure elementAt function working with pushAtBack
 */
void elementAt_test() {
    CharLinkedList list; 
    list.pushAtBack('a');
    list.pushAtBack('b');
    list.pushAtBack('c');
    list.pushAtBack('d');
    list.pushAtFront('f');
    list.pushAtBack('e');
    assert(list.elementAt(2) == 'b');
    assert(list.elementAt(0) == 'f');
    assert(list.size() == 6);
}

/*
 * pushAtBack
 * Make sure elementAt function working with pushAtBack
 */
void pushAtBack_test() {
    CharLinkedList list; 
    list.pushAtBack('a');
    list.pushAtBack('b');
    list.pushAtBack('c');
    //assert(list.elementAt(2) == 'c');
    assert(list.size() == 3);
}

/*
 * elementAt_test_fail
 * Make sure range error is handled and thrown
 */
void elementAt_test_fail() {
    //intializing LL
    char temp_list[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list = CharLinkedList(temp_list, 5); 
    assert(list.elementAt(0) == 'a');
    assert(list.size() == 5);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        // insertAt for out-of-range index
        list.elementAt(10);
    }
    catch (const std::range_error &e) {
        // if insertAt is correctly implemented, a range_error will be thrown,
        // and we will end up here
        range_error_thrown = true;
        error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (10) not in range [0..5)");
}

/*
 * pushAtBack_test_non_emptyLL
 * push back function working on non-empty LL
 */
void pushAtBack_test_non_emptyLL() {
    char temp_list[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list = CharLinkedList(temp_list, 5);

    list.pushAtBack('f');
    list.pushAtBack('z');

    assert(list.elementAt(5) == 'f');
    assert(list.elementAt(6) == 'z');
    assert(list.size() == 7);
}

/*
 * pushAtBack_test_emptyLL
 * push back function working on empty LL
 */
void pushAtBack_test_emptyLL() {
    CharLinkedList list;

    list.pushAtBack('f');
    list.pushAtBack('z');

    assert(list.elementAt(0) == 'f');
    assert(list.elementAt(1) == 'z');
    assert(list.size() == 2);    
}

/*
 * pushAtFront_test_non_emptyLL
 * push front function working on non-empty LL
 */
void pushAtFront_test_non_emptyLL() {
    char temp_list[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list = CharLinkedList(temp_list, 5);

    list.pushAtFront('f');
    list.pushAtFront('z');

    assert(list.elementAt(1) == 'f');
    assert(list.elementAt(0) == 'z');
    assert(list.size() == 7);
}

/*
 * pushAtFront_test_emptyLL
 * push front function working on empty LL
 */
void pushAtFront_test_emptyLL() {
    CharLinkedList list;

    list.pushAtFront('f');
    list.pushAtFront('z');

    assert(list.elementAt(1) == 'f');
    assert(list.elementAt(0) == 'z');
    assert(list.size() == 2);    
}

// Tests correct insertion into an empty AL.
// Afterwards, size should be 1 and element at index 0
// should be the element we inserted.
void insertAt_empty_correct() { 

    CharLinkedList test_list;
    test_list.insertAt('a', 0);
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');

}

// Tests incorrect insertion into an empty AL.
// Attempts to call insertAt for index larger than 0.
// This should result in an std::range_error being raised.
void insertAt_empty_incorrect() {

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    // insertAt for out-of-range index
    test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
    // if insertAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    range_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0]");
    
}

// Tests correct insertAt for front of 1-element list.
void insertAt_front_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at front
    test_list.insertAt('b', 0);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'a');
    
}

// Tests correct insertAt for back of 1-element list.
void insertAt_back_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at back
    test_list.insertAt('b', 1);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    
}

// Tests calling insertAt for a large number of elements.
// Not only does this test insertAt, it also checks that
// array expansion works correctly.
void insertAt_many_elements() {
    
    CharLinkedList test_list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.insertAt('a', i);
    }

    assert(test_list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
    
}

// Tests insertion into front of a larger list
void insertAt_front_large_list() {
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    test_list.insertAt('y', 0);

    assert(test_list.size() == 10);
    assert(test_list.elementAt(0) == 'y');
    assert(test_list.toString() ==     
    "[CharLinkedList of size 10 <<yabczdefgh>>]");

}

// Tests insertion into the back of a larger list
void insertAt_back_large_list() {

    char test_arr[10] = { 'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 10);  

    test_list.insertAt('x', 10);

    assert(test_list.size() == 11);
    assert(test_list.elementAt(10) == 'x');
    assert(test_list.toString() == 
    "[CharLinkedList of size 11 <<yabczdefghx>>]"); 

}

// Tests insertion into the middle of a larger list
void insertAt_middle_large_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.insertAt('z', 3);

    assert(test_list.size() == 9);
    assert(test_list.elementAt(3) == 'z');
    assert(test_list.toString() ==     
    "[CharLinkedList of size 9 <<abczdefgh>>]");

}

// Tests out-of-range insertion for a non-empty list.
void insertAt_nonempty_incorrect() {
   
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8]");
    
}

/*
 * popFromFront_test
 * check whether removes front element correctly
 */
void popFromFront_test() {
    char test_arr[5] = {'A', 'a', 'd', 'i', 't'};
    CharLinkedList test_list(test_arr, 5);

    test_list.popFromFront();
    assert(test_list.toString() == "[CharLinkedList of size 4 <<adit>>]");
    assert(test_list.elementAt(3) == 't');
}

/*
 * popFromFront_fail_test
 * check whether error message thrown
 */
void popFromFront_fail_test() {
    CharLinkedList test_list;

    // var to track whether range_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.popFromFront();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

/*
 * popFromBack_test
 * check whether removes front element correctly
 */
void popFromBack_test() {
    char test_arr[5] = {'A', 'a', 'd', 'i', 't'};
    CharLinkedList test_list(test_arr, 5);

    test_list.popFromBack();
    assert(test_list.toString() == "[CharLinkedList of size 4 <<Aadi>>]");
    assert(test_list.elementAt(3) == 'i');
    assert(test_list.size() == 4);
}

/*
 * popFromBack_fail_test
 * check whether error message thrown
 */
void popFromBack_fail_test() {
    CharLinkedList test_list;

    // var to track whether range_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.popFromBack();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

/*
 * elementAt_empty_fail
 * check if elementAt throws correct error when empty list
 */
void elementAt_empty_fail() {
    CharLinkedList test_list;

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.elementAt(0);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (0) not in range [0..0)");
}

/*
 * first_test
 * check if first element output correct
 */
void first_test() {
    char test_arr[5] = {'b', 'c', 'd', 'i', 't'};
    CharLinkedList test_list(test_arr, 5);

    assert(test_list.first() == 'b');
}

/*
 * last_test
 * check if last element output correct
 */
void last_test() {
    char test_arr[5] = {'b', 'c', 'd', 'i', 't'};
    CharLinkedList test_list(test_arr, 5);

    assert(test_list.last() == 't');
}

/*
 * first_test_fail
 * check if first element output error msg correct
 */
void first_test_fail() {
    CharLinkedList test_list;

    // var to track whether runtime_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.first();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot get first of empty LinkedList");
}

/*
 * last_test
 * check if last element output correct
 */
void last_test_fail() {
    CharLinkedList test_list;

    // var to track whether runtime_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.last();
    }

    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot get last of empty LinkedList");
}

/*
 * removeAt_front_test
 * check whether removes front element correctly
 */
void removeAt_front_test() {
    char test_arr[5] = {'A', 'a', 'd', 'i', 't'};
    CharLinkedList test_list(test_arr, 5);

    test_list.removeAt(0);
    assert(test_list.elementAt(3) == 't');
}

/*
 * removeAt_back_test
 * check whether removes last element correctly
 */
void removeAt_back_test() {
    char test_arr[5] = {'A', 'a', 'd', 'i', 't'};
    CharLinkedList test_list(test_arr, 5);

    test_list.removeAt(4);
    assert(test_list.elementAt(3) == 'i');
}

/*
 * removeAt_middle_test
 * check whether removes middle element correctly
 */
void removeAt_middle_test() {
    char test_arr[5] = {'A', 'a', 'd', 'i', 't'};
    CharLinkedList test_list(test_arr, 5);

    test_list.removeAt(2);
    assert(test_list.elementAt(3) == 't');
}

/*
 * removeAt_boundary_test
 * check whether error thrown
 */
void removeAt_boundary_fail_test() {
    char test_arr[5] = {'A', 'a', 'd', 'i', 't'};
    CharLinkedList test_list(test_arr, 5);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.removeAt(5);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (5) not in range [0..5)");
}

/*
 * insertInOrder_test1
 * check if element inserted correctly
 */
void insertInOrder_test1() {
    char test_arr[5] = {'a', 'a', 'd', 'i', 't'};
    CharLinkedList test_list(test_arr, 5);

    test_list.insertInOrder('b');
    assert(test_list.elementAt(2) == ('b'));
    assert(test_list.elementAt(3) == ('d'));
}

/*
 * insertInOrder_test1
 * check if element inserted correctly
 */
void insertInOrder_test2() {
    char test_arr[5] = {'a', 'a', 'd', 'i', 't'};
    CharLinkedList test_list(test_arr, 5);

    test_list.insertInOrder('k');
    assert(test_list.elementAt(1) == 'a');
    assert(test_list.elementAt(5) == 't');
    assert(test_list.elementAt(4) == 'k');
    assert(test_list.size() == 6);
}

/*
 * insertInOrder_front
 * check if element inserted in front correctly
 */
void insertInOrder_front() {
    char test_arr[5] = {'b', 'c', 'd', 'i', 't'};
    CharLinkedList test_list(test_arr, 5);

    test_list.insertInOrder('a');
    assert(test_list.elementAt(0) == 'a');
}

/*
 * insertInOrder_back
 * check if element inserted in back correctly
 */
void insertInOrder_back() {
    char test_arr[5] = {'b', 'c', 'd', 'i', 't'};
    CharLinkedList test_list(test_arr, 5);

    test_list.insertInOrder('z');
    assert(test_list.elementAt(5) == 'z');
}

/*
 * insertInOrder_back_2
 * check if element inserted in back as same letter correctly
 */
void insertInOrder_back_2() {
    char test_arr[5] = {'b', 'c', 'd', 'i', 't'};
    CharLinkedList test_list(test_arr, 5);

    test_list.insertInOrder('t');
    assert(test_list.elementAt(3) == 'i');
}

/*
 * concatenate_two_list
 * check whether concetenate works on two lists
 */
void concatenate_two_list() {
    char test_arr[5] = { 'A', 'a', 'd', 'i', 't'};
    CharLinkedList test_list(test_arr, 5);
    char test_arr_2[5] = { 'R', 'o', 'c', 'k', 's'};
    CharLinkedList test_list_2(test_arr_2, 5);

    test_list.concatenate(&test_list_2);
    assert(test_list.toString() == 
    "[CharLinkedList of size 10 <<AaditRocks>>]");
    assert(test_list.size() == 10);
    assert(test_list.elementAt(6) == 'o');
}

/*
 * concatenate_two_empty_list
 * check whether concetenate works on two empty lists
 */
void concatenate_two_empty_list() {
    char test_arr[5] = {};
    CharLinkedList test_list(test_arr, 0);
    char test_arr_2[5] = {};
    CharLinkedList test_list_2(test_arr_2, 0);

    test_list.concatenate(&test_list_2);
    assert(test_list.size() == 0);
}

/*
 * concatenate_second_empty_list
 * check whether concetenate works when second list is empty
 */
void concatenate_second_empty_list() {
    char test_arr[5] = {'A', 'a', 'd', 'i', 't'};
    CharLinkedList test_list(test_arr, 5);
    char test_arr_2[5] = {};
    CharLinkedList test_list_2(test_arr_2, 0);

    test_list.concatenate(&test_list_2);
    assert(test_list.size() == 5);
    assert(test_list.elementAt(1) == 'a');
}

/*
 * concatenate_first_empty_list
 * check whether concetenate works when first list is empty
 */
void concatenate_first_empty_list() {
    char test_arr[5] = {};
    CharLinkedList test_list(test_arr, 0);
    char test_arr_2[5] = { 'R', 'o', 'c', 'k', 's'};
    CharLinkedList test_list_2(test_arr_2, 3);

    test_list.concatenate(&test_list_2);
    assert(test_list.size() == 3);
    assert(test_list.elementAt(2) == 'c');
}

/*
 * to_string_test
 * check whether toString outputs correct message
 */
void to_string_test() {
    char test_arr[5] = { 'a', 'a', 'd', 'i', 't'};
    CharLinkedList test_list(test_arr, 5);
    std::string msg = test_list.toString();
    assert(msg == "[CharLinkedList of size 5 <<aadit>>]");
}

/*
 * to_string_empty_test
 * check whether toString outputs correct message on empty list
 */
void to_string_empty_test() {
    CharLinkedList test_list;
    std::string msg = test_list.toString();
    assert(msg == "[CharLinkedList of size 0 <<>>]");
}

/*
 * reverse_to_string_test
 * check whether toReverseString outputs correct message
 */
void reverse_to_string_test() {
    char test_arr[5] = { 'A', 'a', 'd', 'i', 't'};
    CharLinkedList test_list(test_arr, 5);
    std::string msg = test_list.toReverseString();
    assert(msg == "[CharLinkedList of size 5 <<tidaA>>]");
}

/*
 * reverse_to_string_empty_test
 * check whether toReverseString outputs correct message on empty list
 */
void reverse_to_string_empty_test() {
    CharLinkedList test_list;
    std::string msg = test_list.toReverseString();
    assert(msg == "[CharLinkedList of size 0 <<>>]");
}

/*
 * replaceAt_start_test
 * check whether replaceAt works on first element
 */
void replaceAt_start_test() {
    char test_arr[5] = {'A', 'a', 'd', 'i', 't'};
    CharLinkedList test_list(test_arr, 5);
    test_list.replaceAt('l', 0);

    assert(test_list.toString() == "[CharLinkedList of size 5 <<ladit>>]");
    assert(test_list.size() == 5);
    assert(test_list.elementAt(0) == 'l');
}

/*
 * replaceAt_middle_test
 * check whether replaceAt works on middle element
 */
void replaceAt_middle_test() {
    char test_arr[5] = {'A', 'a', 'd', 'i', 't'};
    CharLinkedList test_list(test_arr, 5);
    test_list.replaceAt('l', 3);

    assert(test_list.toString() == "[CharLinkedList of size 5 <<Aadlt>>]");
    assert(test_list.size() == 5);
    assert(test_list.elementAt(3) == 'l');
}

/*
 * replaceAt_end_test
 * check whether replaceAt works on last element
 */
void replaceAt_end_test() {
    char test_arr[5] = {'A', 'a', 'd', 'i', 't'};
    CharLinkedList test_list(test_arr, 5);
    test_list.replaceAt('l', 4);

    assert(test_list.toString() == "[CharLinkedList of size 5 <<Aadil>>]");
    assert(test_list.size() == 5);
    assert(test_list.elementAt(3) == 'i');
}

/*
 * replaceAt_fail_test
 * check whether replaceAt outputs correct error message on boundary, 
 * failed test
 */
void replaceAt_fail_test() {
    char test_arr[5] = {'A', 'a', 'd', 'i', 't'};
    CharLinkedList test_list(test_arr, 5);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.replaceAt('l', 5);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (5) not in range [0..5)");
}

/*
 * replaceAt_fail_test_2
 * check whether replaceAt outputs correct error message on failed test
 */
void replaceAt_fail_test_2() {
    char test_arr[5] = {'A', 'a', 'd', 'i', 't'};
    CharLinkedList test_list(test_arr, 5);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.replaceAt('l', 30);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (30) not in range [0..5)");
}

/*
 * replaceAt_fail_test_3
 * check whether replaceAt outputs correct error message on empty list test
 */
void replaceAt_fail_test_3() {
    CharLinkedList test_list;

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.replaceAt('l', 30);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (30) not in range [0..0)");
}

void insertInOrder_empty_list() {

}

// Tests copy constructor
void copy_constructor() {
    char test_arr[5] = {'A', 'a', 'd', 'i', 't'};
    CharLinkedList list(test_arr, 5);
    CharLinkedList test_list(list);

    assert(test_list.toString() == "[CharLinkedList of size 5 <<Aadit>>]");
    assert(list.toString() == "[CharLinkedList of size 5 <<Aadit>>]");
}

/*
 * size
 */
void size_test_1() {
    char test_arr[5] = {'A', 'a', 'd', 'i', 't'};
    CharLinkedList test_list(test_arr, 5);
    test_list.replaceAt('l', 4);

    assert(test_list.toString() == "[CharLinkedList of size 5 <<Aadil>>]");
    assert(test_list.size() == 5);
    assert(test_list.elementAt(3) == 'i');
}

/*
 * size_empty
 */
void size_test_2() {
    CharLinkedList test_list;
    assert(test_list.size() == 0);
}
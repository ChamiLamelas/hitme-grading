/*
 *  CharLinkedList.h
 *  Aadit Zaveri
 *  02/05/23
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Interface for a Linked List of Characters
 *
 */

#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H
using namespace std;
#include <string>

class CharLinkedList {
public:
    CharLinkedList();
    CharLinkedList(char c);
    CharLinkedList(char arr[], int size);
    CharLinkedList(const CharLinkedList &other);
    ~CharLinkedList();
    CharLinkedList &operator=(const CharLinkedList &other);
    int size() const;
    void pushAtBack(char c);
    void pushAtFront(char c);
    bool isEmpty() const;
    void clear();
    char first() const;
    char last() const;
    char elementAt(int index) const;
    void insertAt(char c, int index);
    void popFromFront();
    void popFromBack();
    void removeAt(int index);
    void insertInOrder(char c);
    void replaceAt(char c, int index);
    void concatenate(CharLinkedList *other);
    std::string toString() const;
    std::string toReverseString() const;

private:
    struct Node {
        char data;
        Node *next;
        Node *prev;
    };
    
    int currSize;
    Node *front;
    Node *back;

    CharLinkedList::Node *newNode(char c, Node *n, Node *p);
    CharLinkedList::Node *recurseElement(Node *curr_node, int i, int t) const;
    bool can_access_exclusive(int size, int index) const;
    bool can_access_inclusive(int size, int index) const;
    void destructorHelper(Node *curr);
};

#endif

/*
 *  CharLinkedList.cpp
 *  Aadit Zaveri
 *  02/05/23
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Purpose: Implementation for a Linked List of Characters
 *
 */

#include "CharLinkedList.h"
#include <stdexcept>
#include <string>
#include <iostream>
#include <sstream>
using namespace std;

/*
 * name:      CharLinkedList
 * purpose:   default constructor
 * arguments: none
 * returns:   no return type
 * effects:   intializes front node and size to 0
 */
CharLinkedList::CharLinkedList() {
    currSize = 0;
    front = nullptr;
    back = nullptr;
}

/*
 * name:      CharLinkedList
 * purpose:   constructor intializing one element
 * arguments: character 
 * returns:   no return type
 * effects:   intializes front node 
 */
CharLinkedList::CharLinkedList(char c) {
    currSize = 1;

    //creating a new node and setting its fields
    Node *new_node = newNode(c, nullptr, nullptr);

    //setting our front and back node variable to node created
    front = new_node;
    back = new_node;
}

/*
 * name:      CharLinkedList
 * purpose:   constructor intializing list with provided array and size
 * arguments: array and size 
 * returns:   no return type
 * effects:   intializes list
 */
CharLinkedList::CharLinkedList(char arr[], int size) {
    currSize = 0;

    for(int i = 0; i < size; i++) {
        pushAtBack(arr[i]);
    }
}

/*
 * name:      CharLinkedList
 * purpose:   copy constructor
 * arguments: address of CharLinkedList object
 * returns:   no return type
 * effects:   copies elements into class variables
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other) {
    Node *curr = new Node;
    Node *curr_prev = nullptr;
    Node *other_curr = other.front;
    front = curr;

    for(int i = 0; i < other.currSize - 1; i++) {
        curr->data = other_curr->data; 
        curr->prev = curr_prev;
        curr_prev = curr;
        curr->next = new Node; 
        curr = curr->next; 
        other_curr = other_curr->next;
    }

    back = curr;
    back->data = other_curr->data; 
    back->prev = curr_prev;
    back->next = nullptr;
    currSize = other.currSize;
}

/*
 * name:      ~CharLinkedList
 * purpose:   destructor
 * arguments: -
 * returns:   no return type
 */
CharLinkedList::~CharLinkedList(){
    destructorHelper(front);
}

/*
 * name:      operator=
 * purpose:   assignment operator, make a deep copy
 * arguments: address of CharLinkedList object
 * returns:   CharLinkedList object
 * effects:   copies elements into class variables
 */
CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other) {
    if(this == &other) {
        return *this;
    }
    
    if(other.isEmpty()) {
        clear(); 
        return *this;
    }

    Node *curr = new Node;
    Node *curr_prev = nullptr;
    Node *other_curr = other.front;
    front = curr;

    while(other_curr->next != nullptr) {
        curr->data = other_curr->data;
        curr->prev = curr_prev;
        curr_prev = curr;
        curr->next = new Node; 
        curr = curr->next;
        other_curr = other_curr->next;
    }

    back = curr;
    back->data = other_curr->data;
    back->prev = curr_prev;
    back->next = nullptr;
    currSize = other.currSize;
    
    return *this;
}

/*
 * name:      size
 * purpose:   return size of list
 * arguments: -
 * returns:   size as an int
 * effects:   -
 */
int CharLinkedList::size() const {
    return currSize;
}

/*
 * name:      pushAtBack
 * purpose:   add to end of linked list
 * arguments: character element 
 * returns:   -
 * effects:   -
 */
void CharLinkedList::pushAtBack(char c) {
    if(isEmpty()) {
        Node *new_node = newNode(c, nullptr, nullptr);
        front = new_node;
        back = new_node;
    } else {
        Node *new_node = newNode(c, nullptr, back);
        
        //updating previous backs's next pointer
        back->next = new_node;
        back = new_node;
    }
    
    currSize++;
}

/*
 * name:      pushAtFront
 * purpose:   add to start of linked list
 * arguments: character element 
 * returns:   -
 * effects:   -
 */
void CharLinkedList::pushAtFront(char c) {
    if(isEmpty()) {
        Node *new_node = newNode(c, nullptr, nullptr);
        front = new_node;
        back = new_node;
    } else {
        Node *new_node = newNode(c, front, nullptr);
    
        //updating previous front's back pointer
        front->prev = new_node;
        front = new_node;
    }

    currSize++;
}

/*
 * name:      isEmpty
 * purpose:   check if list is empty
 * arguments: -
 * returns:   boolean data
 * effects:   -
 */
bool CharLinkedList::isEmpty() const {
    if(currSize == 0 or front == nullptr) {
        return true;
    }

    return false;
}

/*
 * name:      first
 * returns:   first element of LL
 * effects:   run_time error when empty
 */
char CharLinkedList::first() const {
    if(isEmpty()) {
        //exception handling
        throw runtime_error("cannot get first of empty LinkedList");
        return 0;
    }
    
    return front->data;
}

/*
 * name:      last
 * returns:   last element of LL
 * effects:   run_time error when empty
 */
char CharLinkedList::last() const {
    if(isEmpty()) {
        //exception handling
        throw runtime_error("cannot get last of empty LinkedList");
        return 0;
    }
    
    return back->data;
}

/*
 * name:      clear
 * purpose:   make empty LL
 * returns:   -
 */
void CharLinkedList::clear() {
    destructorHelper(front);
    
    currSize = 0;
    front = nullptr;
    back = nullptr;
}

/*
 * name:      elementAt
 * purpose:   find element at index
 * arguments: index
 * returns:   character at element
 * effects:   range_error
*/
char CharLinkedList::elementAt(int index) const {
    if(can_access_exclusive(currSize, index)) {
        Node *nodeAt = recurseElement(front, index, 0);
        return nodeAt->data;
    } else {
        //error handling
        stringstream err;
        err << "index (" << index << ") not in range [0.." << currSize << ")";
        throw range_error(err.str());
        return 0;
    }
}

/*
 * name:      insertAt
 * purpose:   insert element at given index
 * arguments: index and character
 * returns:   -
 * effects:   range_error
*/
void CharLinkedList::insertAt(char c, int index) {
    if (isEmpty() and index == 0) {
        //empty list insert at 1st index
        Node *new_node = newNode(c, nullptr, nullptr);
        front = new_node;
        back = new_node;
        currSize++;
    } else if(can_access_inclusive(currSize, index)) {
        if(index == 0) {
            //insert at first index using pushAtFront
            pushAtFront(c);
        } else if (index == currSize) {
            //insert at last index using pushAtBack
            pushAtBack(c);
        } else {
            //insertion into middle of list
            Node *nodeAt = recurseElement(front, index, 0);
            Node *new_prev = recurseElement(front, index - 1, 0);
            Node *new_node = newNode(c, nodeAt, new_prev);

            //updating pointers
            new_prev->next = new_node;
            nodeAt->prev = new_node;
            currSize++;
        } 
    } else {
        //error handling
        stringstream err;
        err << "index (" << index << ") not in range [0.." << currSize << "]";
        throw range_error(err.str());
    }
}

/*
 * name:      insertInOrder
 * purpose:   insert element in order
 * arguments: character element
 * returns:   -
 * effects:   -
*/
void CharLinkedList::insertInOrder(char c) {
    if (isEmpty()) {
        Node *new_node = newNode(c, nullptr, nullptr);
        front = new_node;
        back = new_node;
        currSize++;
    } else if (c <= front->data) {
        pushAtFront(c);
    } else if (c > back->data) {
        pushAtBack(c);
    } else {
        bool inserted = false;

        for (int i = 0; i < currSize - 1; i++) {
            if(not(inserted)) {
                Node *node1 = recurseElement(front, i, 0);
                Node *node2 = recurseElement(front, i + 1, 0);
                if (c > node1->data and c <= node2->data) {
                    insertAt(c, i + 1);
                    inserted = true;
                }
            }
        }
    }
}

/*
 * name:      popFromFront
 * purpose:   remove element from front
 * arguments: -
 * returns:   -
 * effects:   runtime_error
*/
void CharLinkedList::popFromFront() {
    if(isEmpty()) {
        //exception handling
        throw runtime_error("cannot pop from empty LinkedList");
    }

    front = front->next;
    delete front->prev;
    front->prev = nullptr;

    currSize--;
}

/*
 * name:      popFromBack
 * purpose:   remove element from back
 * arguments: -
 * returns:   -
 * effects:   runtime_error
*/
void CharLinkedList::popFromBack() {
    if(isEmpty()) {
        //exception handling
        throw runtime_error("cannot pop from empty LinkedList");
    }

    back = back->prev;
    delete back->next;
    back->next = nullptr;

    currSize--;
}

/*
 * name:      removeAt
 * purpose:   remove element at given index
 * arguments: index 
 * returns:   -
 * effects:   range_error
*/
void CharLinkedList::removeAt(int index) {
    if(can_access_exclusive(currSize, index)) {
        if(index == 0) {
            //remove first index
            popFromFront();
        } else if (index == (currSize - 1)) {
            //remove last index
            popFromBack();
        } else {
            //remove from middle of list
            Node *nodeAt = recurseElement(front, index, 0);
            Node *new_prev = recurseElement(front, index - 1, 0);
            Node *new_next = recurseElement(front, index + 1, 0);

            //updating pointers
            delete nodeAt;
            new_prev->next = new_next;
            new_next->prev = new_prev;
            currSize--;
        } 
    } else {
        //error handling
        stringstream err;
        err << "index (" << index << ") not in range [0.." << currSize << ")";
        throw range_error(err.str());
    }
}

/*
 * name:      replaceAt
 * purpose:   remove element at given index and replace with given character
 * arguments: index and character
 * returns:   -
 * effects:   range_error
*/
void CharLinkedList::replaceAt(char c, int index) {
    if(can_access_exclusive(currSize, index)) {
        removeAt(index);
        insertAt(c, index);
    } else {
        stringstream err;
        err << "index (" << index << ") not in range [0.." << currSize << ")";
        throw range_error(err.str());
    }
}

/*
 * name:      concatenate
 * purpose:   combining two lists
 * arguments: pointer to a list
 * returns:   -
 * effects:   -
*/
void CharLinkedList::concatenate(CharLinkedList *other) {
    
    if(not (other->isEmpty())) {
        for(int i = 0; i < other->size(); i++) {
            pushAtBack(other->elementAt(i));
        }
    } 
}

/*
 * name:      toString
 * purpose:   printing list as string
 * arguments: -
 * returns:   string of characters
 * effects:   -
*/
std::string CharLinkedList::toString() const {
    stringstream to_string;
    to_string << "[CharLinkedList of size " << currSize << " <<";

    //traversing through list in order
    for (int i = 0; i < currSize; i++) {
        to_string << elementAt(i);
    }

    to_string << ">>]";

    return to_string.str();
}

/*
 * name:      toReverseString
 * purpose:   output characters as string in reverse order
 * arguments: -
 * returns:   string message with list of characters
 * effects:   -
 */
std::string CharLinkedList::toReverseString() const {
    stringstream to_string;
    to_string << "[CharLinkedList of size " << currSize << " <<";

    //traversing through list in reverse order
    for (int i = currSize - 1; i >= 0; i--) {
        to_string << elementAt(i);
    }

    to_string << ">>]";

    return to_string.str();
}


/*
 * name:      newNode
 * purpose:   helper function to intialize a new node
 * arguments: character data, address of next and prev nodes
 * returns:   CharLinkedList Node
 * effects:   -
 */
CharLinkedList::Node *CharLinkedList::newNode(char c, Node *n, Node *p) {
    Node *new_node = new Node;
    new_node->next = n;
    new_node->prev = p;
    new_node->data = c;

    return new_node;
}

/*
 * name:      recurseElement
 * purpose:   helper function to recurse through elements
 * arguments: current node
 * returns:   next node
 * effects:   -
 */
CharLinkedList::Node *CharLinkedList::
                recurseElement(Node *curr_node, int i, int t) const {
    if (curr_node == nullptr) {
        return nullptr;
    } else if(t == i) {
        return curr_node;
    } else {
        t++;
        return recurseElement(curr_node->next, i, t);
    }
}

/*
 * name:      can_access_exclusive
 * purpose:   helper function 
 * arguments: size and index
 * returns:   true or false
 * effects:   checks if index is within range
 */
bool CharLinkedList::can_access_inclusive(int size, int index) const {
    if (index < 0 or index > size) {
        return false;
    }

    return true;
}

/*
 * name:      can_access_inclusive
 * purpose:   helper function 
 * arguments: size and index
 * returns:   true or false
 * effects:   checks if index is within range
 */
bool CharLinkedList::can_access_exclusive(int size, int index) const {
    if (index < 0 or index >= size) {
        return false;
    }

    return true;
}


/*
 * name:      destructorHelper
 * purpose:   helper function 
 * arguments: current node
 * returns:   -
 * effects:   recursively deletes nodes
 */
void CharLinkedList::destructorHelper(Node *curr) {
    if(isEmpty()) {
        // delete b;
    } else if(curr == back) {
        delete back;
    } else {
        Node *next = curr->next;
        delete curr;
        return destructorHelper(next);
    }
}




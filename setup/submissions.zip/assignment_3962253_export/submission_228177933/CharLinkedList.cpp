/*
 *  CharLinkedList.cpp
 *  Kai Martell
 *  2/4/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Implementation of the CharLinkedList class
 *
 */

#include "CharLinkedList.h"
#include <iostream>
#include <sstream>
#include <string>
#include <stdexcept>


/*
 * name:      CharLinkedList
 * purpose:   default constructor
 * arguments: none
 * returns:   nothing
 * effects:   initializes head and tail to nullptr, numItems to 0
 */
CharLinkedList::CharLinkedList() {
    head = nullptr;
    tail = nullptr;
    numItems = 0;
}

/*
 * name:      CharLinkedList
 * purpose:   constructor with a single character
 * arguments: a single character
 * returns:   nothing
 * effects:   initializes head and tail to a new node with the given character
 */
CharLinkedList::CharLinkedList(char c) {
    Node *newNode = new Node;
    newNode->data = c;
    newNode->prev = nullptr;
    newNode->next = nullptr;
    head = newNode;
    tail = newNode;
    numItems = 1;
}

/*
 * name:      CharLinkedList
 * purpose:   constructor with an array of characters
 * arguments: an array and a length
 * returns:   nothing
 * effects:   initializes a list with the given array
 */
CharLinkedList::CharLinkedList(char* arr, int length) {
    head = nullptr;
    tail = nullptr;
    numItems = 0;
    for (int i = 0; i < length; i++) {
        pushAtBack(arr[i]);
    }
}

/*
 * name:      CharLinkedList
 * purpose:   constructor with another CharLinkedList
 * arguments: another LinkedList
 * returns:   nothing
 * effects:   initializes a list with the given list
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other) {
    head = nullptr;
    tail = nullptr;
    numItems = 0;
    copyFromOther(other);
}

/*
 * name:      CharLinkedList
 * purpose:   constructor with another CharLinkedList
 * arguments: another LinkedList
 * returns:   nothing
 * effects:   initializes a list with the given list using operator '='
 */
CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other) {
    if (this != &other) {
        clear();
        copyFromOther(other);
    }
    return *this;
}

/*
 * name:      ~CharLinkedList 
 * purpose:   destructor
 * arguments: none
 * returns:   nothing   
 * effects:   clears the list from memory
 */
CharLinkedList::~CharLinkedList() {
    clear();
}

/*
 * name:      createNode
 * purpose:   helper function to create a new node
 * arguments: a single character
 * returns:   the new node struct with the given character
 */
CharLinkedList::Node *CharLinkedList::createNode(char c) {
    Node *newNode = new Node;
    newNode->data = c;
    newNode->prev = nullptr;
    newNode->next = nullptr;
    return newNode;
}

/*
 * name:      throwRangeError1
 * purpose:   helper function to throw a range error
 * arguments: a given index
 * returns:   throws a range error ending with ')' 
 */
void CharLinkedList::throwRangeError1(int index) const{
    throw std::range_error(
        "index (" + std::to_string(index) + 
        ") not in range [0.." + std::to_string(numItems) + ")"
    );
}

/*
 * name:      throwRangeError2
 * purpose:   helper function to throw a range error
 * arguments: a given index
 * returns:   throws a range error ending with ']'
 */
void CharLinkedList::throwRangeError2(int index) const{
    throw std::range_error(
        "index (" + std::to_string(index) + 
        ") not in range [0.." + std::to_string(numItems) + "]"
    );
}

/*
 * name:      copyFromOther
 * purpose:   copy the given list to the current list
 * arguments: the address of another LinkedList
 * returns:   nothing
 */
void CharLinkedList::copyFromOther(const CharLinkedList &other) {
    Node *temp = other.head;
    while (temp != nullptr) {
        pushAtBack(temp->data);
        temp = temp->next;
    }
}

/*
 * name:      isEmpty
 * purpose:   returns true if the list is empty
 * arguments: none
 * returns:   true if the list is empty, false otherwise
 */
bool CharLinkedList::isEmpty() const {
    return numItems == 0;
}

/*
 * name:      clear
 * purpose:   clears the list from memory
 * arguments: none
 * returns:   nothing
 * effects:   removes all nodes from memory
 */
void CharLinkedList::clear() {
    while (head != nullptr) {
        Node *temp = head;
        head = head->next;
        delete temp;
    }
    tail = nullptr;
    numItems = 0;

}

/*
 * name:      size
 * purpose:   returns the number of elements in the list
 * arguments: none
 * returns:   numItems
 */
int CharLinkedList::size() const {
    return numItems;
}

/*
 * name:      first
 * purpose:   returns the first element in the list
 * arguments: none
 * returns:   the first element of the list, or error if the list is empty
 */
char CharLinkedList::first() const {
    if (isEmpty()) {
        throw std::runtime_error("cannot get first of empty LinkedList");
    }
    return head->data;
}

/*
 * name:      last
 * purpose:   returns the last element in the list
 * arguments: none
 * returns:   the last element of the list, or error if the list is empty
 * effects:   
 */
char CharLinkedList::last() const {
    if (isEmpty()) {
        throw std::runtime_error("cannot get last of empty LinkedList");
    }
    return tail->data;
}

/*
 * name:      elementAt
 * purpose:   returns the element at the given index
 * arguments: the given index
 * returns:   the data at given index, error if idx is out of range
 */
char CharLinkedList::elementAt(int index) const {
    if (index < 0 or index >= numItems) {  
        throwRangeError1(index);
    }
    Node *temp = head; // find the element at the given index
    for (int i = 0; i < index; i++) {
        temp = temp->next; 
    }
    return temp->data;
}

/*
 * name:      toString
 * purpose:   to show the list as a string
 * arguments: none
 * returns:   the list as a string in format [CharLinkedList of size x <<...>>]
 */
std::string CharLinkedList::toString() const {
    std::stringstream ss;
    Node *temp = head;
    ss << "[CharLinkedList of size " << numItems << " <<";
    while (temp != nullptr) {
        ss << temp->data;
        temp = temp->next;
    }
    ss << ">>]"; 
    return ss.str();
}

/*
 * name:      toReverseString
 * purpose:   to show the list as a string in reverse
 * arguments: none
 * returns:   the list in reverse as a string in format 
 *            [CharLinkedList of size x <<...>>]
 */
std::string CharLinkedList::toReverseString() const {
    std::stringstream ss;
    Node *temp = tail; 
    ss << "[CharLinkedList of size " << numItems << " <<";
    for (int i = 0; i < numItems; i++) {
        ss << temp->data;
        temp = temp->prev;
    }
    ss << ">>]";
    return ss.str();
}

/*
 * name:      pushAtBack
 * purpose:   add a new element to the back of the list
 * arguments: a given character
 * returns:   nothing
 * effects:   slots a new element into the back of the list
 */
void CharLinkedList::pushAtBack(char c) {
    Node *newNode = createNode(c);
    if (isEmpty()) {
        head = newNode;
    } else {
        tail->next = newNode;
        newNode->prev = tail;
    }
    tail = newNode;
    numItems++;
}

/*
 * name:      pushAtFront
 * purpose:   add a new element to the front of the list
 * arguments: a given character
 * returns:   nothing
 * effects:   slots a new element into the front of the list
 */
void CharLinkedList::pushAtFront(char c) {
    Node *newNode = createNode(c);
    newNode->next = head;
    if (head != nullptr) { 
        head->prev = newNode;  
    } else {
        tail = newNode; 
    }
    head = newNode;  
    numItems++;
}

/*
 * name:      insertAt
 * purpose:   add a new element at a given index
 * arguments: a given character and a given index
 * returns:   nothing
 * effects:   slots a new element into the list at the given index
 *            throw an error if the index is out of range
 */
void CharLinkedList::insertAt(char c, int index) {
    if (index < 0 or index > numItems) {
        throwRangeError2(index);
    }
    Node *newNode = createNode(c); // create a new node
    if (index == 0) { // insert at the front
        newNode->next = head;
        if (head != nullptr) {
            head->prev = newNode;
        }
        head = newNode; // set the head to the new node
        if (tail == nullptr) {
            tail = newNode;
        }
    } else { // insert at the given index
        Node *temp = head;
        for (int i = 0; i < index - 1; i++) {
            temp = temp->next;
        }
        newNode->next = temp->next; 
        newNode->prev = temp; // set the new node's next and prev
        if (temp->next != nullptr) {
            temp->next->prev = newNode;
        }
        temp->next = newNode;
        if (newNode->next == nullptr) {
            tail = newNode;
        }
    }
    numItems++;
}

/*
 * name:      insertInOrder
 * purpose:   add a new element to the list in order of ASCII value
 * arguments: a given character
 * returns:   nothing
 * effects:   slots a new element into the list in order of ASCII value
 */
void CharLinkedList::insertInOrder(char c) {
    Node *temp = head; 
    if (isEmpty() or c <= head->data) { // insert at the front
        pushAtFront(c);
    } else if (c >= tail->data) {  // insert at the back
        pushAtBack(c);
    } else {
        temp = head;
        int i = 0; // find the index to insert the new node
        while (temp != nullptr and c > temp->data) {
            temp = temp->next;
            i++;
        }
        insertAt(c, i);
    }
}

/*
 * name:      popFromFront
 * purpose:   remove the item at the front of the list
 * arguments: none
 * returns:   nothing
 * effects:   node at the front of the list is removed
 *            throw an error if the list is empty
 */
void CharLinkedList::popFromFront() {
    if (isEmpty()) {
        throw std::runtime_error("cannot pop from empty LinkedList");
    }
    Node *oldHead = head;
    head = oldHead->next;
    if (head != nullptr) {
        head->prev = nullptr;
    }
    delete oldHead; 
    numItems--;
}

/*
 * name:      popFromBack
 * purpose:   remove the item at the back of the list
 * arguments: none
 * returns:   nothing
 * effects:   node at the back of the list is removed
 *            throw an error if the list is empty
 */
void CharLinkedList::popFromBack() {
    if (isEmpty()) {
        throw std::runtime_error("cannot pop from empty LinkedList");
    }
    Node *oldTail = tail;
    if (tail->prev != nullptr) {
        tail = tail->prev; // remove the last node
        tail->next = nullptr; // set the new tail
    } else {
        head = nullptr;
        tail = nullptr;
    }
    delete oldTail;
    numItems--;
}

/*
 * name:      removeAt
 * purpose:   remove the item at a given index
 * arguments: the given index
 * returns:   nothing
 * effects:   node at the given index is removed
 *            throw an error if the index is out of range
 */
void CharLinkedList::removeAt(int index) {
    if (index < 0 or index >= numItems) {
        throwRangeError1(index);
    }
    if (index == 0) { 
        popFromFront();
    } else if (index == numItems - 1) {
        popFromBack();
    } else {
        Node *temp = head;
        for (int i = 0; i < index - 1; i++) {
            temp = temp->next; //find the node before the one to delete
        }
        Node *toDelete = temp->next; // delete the node
        temp->next = toDelete->next;
        if (toDelete->next != nullptr) {
            toDelete->next->prev = temp;  
        }
        delete toDelete;
        numItems--;
    }
}

/*
 * name:      replaceAt
 * purpose:   replace an element with another given element
 * arguments: a given character and a given index
 * returns:   nothing
 * effects:   one element is replaced with another
 *            throw an error if the index is out of range
 */
void CharLinkedList::replaceAt(char c, int index) {
    if (index < 0 or index >= numItems) {
        throwRangeError1(index);
    }
    Node *temp = head;
    for (int i = 0; i < index; i++) {
        temp = temp->next;
    }
    temp->data = c; // replace the element at the given index
}

/*
 * name:      concatenate
 * purpose:   combine two lists into one
 * arguments: a pointer to another list
 * returns:   nothing
 * effects:   strings the other list onto the end of the current list
 */
void CharLinkedList::concatenate(CharLinkedList *other) {
    if (other->head != nullptr) {
        copyFromOther(*other); // use helper function to copy the other list
    }
}
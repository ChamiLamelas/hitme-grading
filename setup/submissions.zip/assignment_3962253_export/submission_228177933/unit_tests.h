/*
 *  unit_tests.h
 *  Kai Martell
 *  2/5/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  Unit tests for CharLinkedList functions
 *
 */

#include "CharLinkedList.h"
#include <cassert>
#include <iostream>
#include <string>
#include <sstream>

using namespace std;

/* Tests for constructors
    * 1. Default constructor
    * 2. Single char constructor
    * 3. Array constructor
    * 4. Copy constructor
    * 5. Assignment operator
 */
// 1. Default constructor
// test for empty list
void testDefaultConstructor() {
    CharLinkedList list;
    assert(list.isEmpty());
    assert(list.size() == 0);
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
    cout << list.toString() << endl;
}

// test for single char
void testSingleCharConstructor() {
    CharLinkedList list('a');
    assert(not list.isEmpty());
    assert(list.size() == 1);
    assert(list.toString() == "[CharLinkedList of size 1 <<a>>]");
    cout << list.toString() << endl;
}

// test for non empty array
void testArrayConstructor() {
    char arr[] = {'k', 'a', 'i'};
    CharLinkedList list(arr, 3);
    assert(not list.isEmpty());
    assert(list.size() == 3);
    assert(list.toString() == "[CharLinkedList of size 3 <<kai>>]");
    cout << list.toString() << endl;
}

// test for the copy constructor using the array constructor
void testCopyConstructor() {
    char arr[] = {'k', 'a', 'i'};
    CharLinkedList list1(arr, 3);
    CharLinkedList list2(list1);
    assert(list1.toString() == list2.toString());
    cout << list2.toString() << endl;
    cout << list1.toString() << endl;
}

// test for the assignment operator using the array constructor
void testAssignmentOperator() {
    char arr[] = {'k', 'a', 'i'};
    CharLinkedList list1(arr, 3);
    CharLinkedList list2;
    list2 = list1;
    assert(list1.toString() == list2.toString());
    cout << list2.toString() << endl;
    cout << list1.toString() << endl;
}


/* Tests for characteristic functions
    * 1. isEmpty
    * 2. clear
    * 3. size
    * 4. first
    * 5. last
    * 6. elementAt
    * 7. toString
    * 8. toReverseString
 */
// test to see if the list is empty
void testisEmpty() {
    CharLinkedList list;
    assert(list.isEmpty());
    list.pushAtBack('a');
    assert(not list.isEmpty());
}

// test to see if the list is empty after clearing
void testClear() {
    CharLinkedList list;
    list.pushAtBack('k');
    list.pushAtBack('a');
    list.pushAtBack('i');
    assert(not list.isEmpty());
    list.clear();
    assert(list.isEmpty());
    assert(list.size() == 0);
}

// test to see if the size is correct
void testSize() {
    CharLinkedList list;
    assert(list.size() == 0);
    list.pushAtBack('k');
    assert(list.size() == 1);
    list.pushAtBack('a');
    assert(list.size() == 2);
    list.pushAtBack('i');
    assert(list.size() == 3);
}

// test to see if the first element is correct
void testFirst() {
    char array[] = {'k', 'a', 'i'};
    CharLinkedList list(array, 3);
    assert(list.first() == 'k');
}

// test for error case: empty list
void testFirst2() {
    CharLinkedList list;
    bool isError = false;
    std::string error;
    try {
        list.first();
    } catch (const runtime_error &e) {
        isError = true;
        cout << e.what();
        error = e.what();
    }
    assert(error == "cannot get first of empty LinkedList");
}

// test to see if the last element is correct
void testLast() {
    char array[] = {'k', 'a', 'i'};
    CharLinkedList list(array, 3);
    assert(list.last() == 'i');
}

// test for error case: empty list
void testLast2() {
    CharLinkedList list;
    bool isError = false;
    std::string error;
    try {
        list.last();
    } catch (const runtime_error &e) {
        isError = true;
        cout << e.what();
        error = e.what();
    }
    assert(error == "cannot get last of empty LinkedList");
}

// test to see if the element at the index is correct
void testElementAt() {
    char array[] = {'k', 'a', 'i'};
    CharLinkedList list(array, 3);
    assert(list.elementAt(0) == 'k');
    assert(list.elementAt(1) == 'a');
    assert(list.elementAt(2) == 'i');
}

// test for out of range: too big
// make sure error of format "index (IDX) not in range [0..SIZE)"
void testElementAt2() {
    char array[] = {'k', 'a', 'i'};
    CharLinkedList list(array, 3);
    bool isError = false;
    std::string error;
    try {
        list.elementAt(3);
    } catch (const range_error &e) {
        isError = true;
        cout << e.what();
        error = e.what();
    }
    assert(error == "index (3) not in range [0..3)");
}

// test for out of range: negative
// make sure error of format "index (IDX) not in range [0..SIZE)"
void testElementAt3() {
    char array[] = {'k', 'a', 'i'};
    CharLinkedList list(array, 3);
    bool isError = false;
    std::string error;
    try {
        list.elementAt(-1);
    } catch (const range_error &e) {
        isError = true;
        cout << e.what();
        error = e.what();
    }
    assert(error == "index (-1) not in range [0..3)");
}

// test for error case: empty list
// make sure error of format "index (IDX) not in range [0..SIZE)"
void testElementAt4() {
    CharLinkedList list;
    bool isError = false;
    std::string error;
    try {
        list.elementAt(0);
    } catch (const range_error &e) {
        isError = true;
        cout << e.what();
        error = e.what();
    }
    assert(error == "index (0) not in range [0..0)");
}

// test to see if printed string is correct
//Check for syntax on these "[CharLinkedList of size __ <<__>>]"
void testToString() {
    char array[] = {'k', 'a', 'i'};
    CharLinkedList list(array, 3);
    assert(list.toString() == "[CharLinkedList of size 3 <<kai>>]");
}

// test for printing of empty list, make sure no garbage value, no space <<>>
void testToString2() {
    CharLinkedList list;
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}

// test to see if printed reverse string is correct
void testToReverseString() {
    char array[] = {'k', 'a', 'i'};
    CharLinkedList list(array, 3);
    assert(list.size() == 3);
    cout << list.toReverseString() << endl;
    assert(list.toReverseString() == "[CharLinkedList of size 3 <<iak>>]");
}

// test for printing of empty list, make sure no garbage value, no space <<>>
void testToReverseString2() {
    CharLinkedList list;
    assert(list.toReverseString() == "[CharLinkedList of size 0 <<>>]");
}


/* Tests for action functions
    * 1. pushAtBack
    * 2. pushAtFront
    * 3. insertAt
    * 4. insertInOrder
    * 5. popFromFront
    * 6. popFromBack
    * 7. removeAt
    * 8. replaceAt
    * 9. concatenate
 */
// test to see if pushAtBack correctly adds to the end of the list
// add multiple to test for multiple pushes
void testPushAtBack() {
    CharLinkedList list;
    list.pushAtBack('k');
    assert(list.toString() == "[CharLinkedList of size 1 <<k>>]");
    list.pushAtBack('a');
    assert(list.toString() == "[CharLinkedList of size 2 <<ka>>]");
    list.pushAtBack('i');
    assert(list.toString() == "[CharLinkedList of size 3 <<kai>>]");
}

// test to see if pushatback correctly adds to the back of the full list
void testPushAtBack2() {
    char array[] = {'k', 'a', 'i'};
    CharLinkedList list(array, 3);
    list.pushAtBack('m');
    assert(list.size() == 4);
    assert(list.toString() == "[CharLinkedList of size 4 <<kaim>>]");
}

// test to see pushAtFront multiple times to front of list
void testPushAtFront() {
    CharLinkedList list;
    list.pushAtFront('i');
    assert(list.toString() == "[CharLinkedList of size 1 <<i>>]");
    list.pushAtFront('a');
    assert(list.toString() == "[CharLinkedList of size 2 <<ai>>]");
    list.pushAtFront('k');
    assert(list.toString() == "[CharLinkedList of size 3 <<kai>>]");
}

// test for pushatfront adding to the front of the full list
void testPushAtFront2() {
    char array[] = {'k', 'a', 'i'};
    CharLinkedList list(array, 3);
    list.pushAtFront('x');
    assert(list.size() == 4);
    assert(list.toString() == "[CharLinkedList of size 4 <<xkai>>]");
}

// test for segfault
void testpushAtFront() {
    CharLinkedList list;
    for (int i = 0; i < 3000; i++) {
        list.pushAtFront('a');
    }
    assert(list.size() == 3000);
}

// test for first pushing back then inserting
void testInsertAt() {
    CharLinkedList list;
    list.pushAtBack('k');
    list.pushAtBack('i');
    list.insertAt('a', 1);
    assert(list.toString() == "[CharLinkedList of size 3 <<kai>>]");
    assert(list.size() == 3);
}

// test to make sure insert works on empty list
void testInsertAt2() {
    CharLinkedList list;
    list.insertAt('k', 0);
    assert(list.toString() == "[CharLinkedList of size 1 <<k>>]");
    assert(list.size() == 1);
}

// test to see if insert works at end of list
void testInsertAt3() {
    char array[] = {'k', 'a', 'i'};
    CharLinkedList list(array, 3);
    list.insertAt('m', 3);
    assert(list.size() == 4);
    assert(list.toString() == "[CharLinkedList of size 4 <<kaim>>]");
}

// test for edge case: too big
// make sure error of format "index (IDX) not in range [0..SIZE]"
void testInsertAt4() {
    char array[] = {'k', 'a', 'i'};
    CharLinkedList list(array, 3);
    bool isError = false;
    std::string error;
    try {
        list.insertAt('m', 4);
    } catch (const range_error &e) {
        isError = true;
        cout << e.what();
        error = e.what();
    }
    assert(isError);
    assert(error == "index (4) not in range [0..3]");
}

// test for edge case: negative
// make sure error is of format "index (IDX) not in range [0..SIZE]"
void testInsertAt5() {
    char array[] = {'k', 'a', 'i'};
    CharLinkedList list(array, 3);
    bool isError = false;
    std::string error;
    try {
        list.insertAt('m', -1);
    } catch (const range_error &e) {
        isError = true;
        cout << e.what();
        error = e.what();
    }
    assert(isError);
    assert(error == "index (-1) not in range [0..3]");
}

// test to see if insertInOrder correctly adds to the list in order
// check ascii table for reference https://www.asciitable.com/
void testInsertInOrder() {
    char array[] = {'a', 'c', 'e'};
    CharLinkedList list(array, 3);
    list.insertInOrder('b');
    cout << list.toString() << endl;
    list.insertInOrder('d');
    cout << list.toString() << endl;
    list.insertInOrder('f');
    cout << list.toString() << endl;
    assert(list.size() == 6);
    assert(list.toString() == "[CharLinkedList of size 6 <<abcdef>>]");
}

// test for multiple insert in order
// also add in random characters not just letters
void testInsertInOrder2() {
    CharLinkedList list;
    list.insertInOrder('b');
    cout << list.toString() << endl;
    list.insertInOrder('a');
    cout << list.toString() << endl;
    list.insertInOrder('1');
    cout << list.toString() << endl;
    list.insertInOrder('(');
    cout << list.toString() << endl;
    list.insertInOrder(')');
    cout << list.toString() << endl;
    list.insertInOrder('{');
    cout << list.toString() << endl;
    list.insertInOrder('}');
    cout << list.toString() << endl;
    assert(list.size() == 7);
    assert(list.toString() == "[CharLinkedList of size 7 <<()1ab{}>>]");
}

// test size and print after removing first element
void testPopFromFront() {
    char array[] = {'k', 'a', 'i'};
    CharLinkedList list(array, 3);
    list.popFromFront();
    assert(list.size() == 2);
    assert(list.toString() == "[CharLinkedList of size 2 <<ai>>]");
}

// test for edge case: empty list
void testPopFromFront2() {
    CharLinkedList list;
    bool isError = false;
    std::string error;
    try {
        list.popFromFront();
    } catch (const runtime_error &e) {
        isError = true;
        cout << e.what();
        error = e.what();
    }
    assert(isError);
    assert(error == "cannot pop from empty LinkedList");
}

// test size and print after removing last element
void testPopFromBack() {
    char array[] = {'k', 'a', 'i'};
    CharLinkedList list(array, 3);  
    list.popFromBack();
    assert(list.size() == 2);
    assert(list.toString() == "[CharLinkedList of size 2 <<ka>>]");
}

// test for edge case: empty list
void testPopFromBack2() {
    CharLinkedList list;
    bool isError = false;
    std::string error;
    try {
        list.popFromBack();
    } catch (const runtime_error &e) {
        isError = true;
        cout << e.what();
        error = e.what();
    }
    assert(isError);
    assert(error == "cannot pop from empty LinkedList");
}

// test for edge case: single element
void testPopFromBack3() {
    CharLinkedList list('k');
    list.popFromBack();
    assert(list.isEmpty());
}

// test removing the middle element of full list
void testRemoveAt() {
    char array[] = {'k', 'a', 'i'};
    CharLinkedList list(array, 3);
    list.removeAt(1);
    assert(list.size() == 2);
    assert(list.toString() == "[CharLinkedList of size 2 <<ki>>]");
}

// testing for edge case: 0 in 0
// remove at should be [0..x)
void testRemoveAt2() {
    CharLinkedList list;
    bool isError = false;
    std::string error;
    try {
        list.removeAt(0);
    } catch (const range_error &e) {
        isError = true;
        cout << e.what();
        error = e.what();
    }
    assert(isError);
    assert(error == "index (0) not in range [0..0)");
}

// testing for edge case: negative
void testRemoveAt3() {
    CharLinkedList list('k');
    bool isError = false;
    std::string error;
    try {
        list.removeAt(-1);
    } catch (const range_error &e) {
        isError = true;
        cout << e.what();
        error = e.what();
    }
    assert(isError);
    assert(error == "index (-1) not in range [0..1)");
}

// testing for edge case: too big
void testRemoveAt4() {
    CharLinkedList list('k');
    bool isError = false;
    std::string error;
    try {
        list.removeAt(3);
    } catch (const range_error &e) {
        isError = true;
        cout << e.what();
        error = e.what();
    }
    assert(isError);
    assert(error == "index (3) not in range [0..1)");
}

// testing for edge case: single element
void testRemoveAt5() {
    CharLinkedList list('k');
    list.removeAt(0);
    assert(list.isEmpty());
}

// try replacing the last element
void testReplaceAt() {
    char array[] = {'k', 'a', 'i', 'x'};
    CharLinkedList list(array, 4);
    list.replaceAt('m', 3);
    assert(list.size() == 4);
    assert(list.toString() == "[CharLinkedList of size 4 <<kaim>>]");
}

// try replacing an element in the middle
void testReplaceAt2() {
    char array[] = {'k', 'a', 'i'};
    CharLinkedList list(array, 3);
    list.replaceAt('x', 1);
    assert(list.size() == 3);
    assert(list.toString() == "[CharLinkedList of size 3 <<kxi>>]");
}

// testing for edge case: 0 in 0
// replace at should be [0..x)
void testReplaceAt3() {
    CharLinkedList list;
    bool isError = false;
    std::string error;
    try {
        list.replaceAt('m', 0);
    } catch (const range_error &e) {
        isError = true;
        cout << e.what();
        error = e.what();
    }
    assert(isError);
    assert(error == "index (0) not in range [0..0)");
}

// test for edge case: negative
void testReplaceAt4() {
    CharLinkedList list('k');
    bool isError = false;
    std::string error;
    try {
        list.replaceAt('m', -1);
    } catch (const range_error &e) {
        isError = true;
        cout << e.what();
        error = e.what();
    }
    assert(isError);
    assert(error == "index (-1) not in range [0..1)");
}

// test for edge case: too big
void testReplaceAt5() {
    CharLinkedList list('k');
    bool isError = false;
    std::string error;
    try {
        list.replaceAt('m', 3);
    } catch (const range_error &e) {
        isError = true;
        cout << e.what();
        error = e.what();
    }
    assert(isError);
    assert(error == "index (3) not in range [0..1)");
}

// try replacing the last element, no change in size
void testReplaceAt6() {
    char array[] = {'k', 'a', 'i'};
    CharLinkedList list(array, 3);
    list.replaceAt('x', 2);
    assert(list.size() == 3);
    assert(list.toString() == "[CharLinkedList of size 3 <<kax>>]");
}

// try replacing the first element, no change in size
void testReplaceAt7() {
    char array[] = {'k', 'a', 'i'};
    CharLinkedList list(array, 3);
    list.replaceAt('x', 0);
    assert(list.size() == 3);
    assert(list.toString() == "[CharLinkedList of size 3 <<xai>>]");
}

// test to see if concatenate correctly adds the 
// second list to the end of the first, both full
void testConcatenate() {
    char array1[] = {'k', 'a', 'i'};
    char array2[] = {'m', 'a', 'r', 't', 'e', 'l', 'l'};
    CharLinkedList list1(array1, 3);
    CharLinkedList list2(array2, 7);
    list1.concatenate(&list2);
    assert(list1.size() == 10);
    assert(list1.toString() == "[CharLinkedList of size 10 <<kaimartell>>]");
    cout << list1.toString() << endl;
}

// test two empty list concatenations, should be empty
void testConcatenate2() {
    CharLinkedList list1;
    CharLinkedList list2;
    list1.concatenate(&list2);
    assert(list1.isEmpty());
    assert(list1.size() == 0);
    assert(list1.toString() == "[CharLinkedList of size 0 <<>>]");
}

// test to see one empty list one full list
void testConcatenate3() {
    char array1[] = {'k', 'a', 'i'};
    CharLinkedList list1(array1, 3);
    CharLinkedList list2;
    list1.concatenate(&list2);
    assert(list1.size() == 3);
    assert(list1.toString() == "[CharLinkedList of size 3 <<kai>>]");
}

// test to see adding other way around of empty and full
void testConcatenate4() {
    char array[] = {'k', 'a', 'i'};
    CharLinkedList list1(array, 3);
    CharLinkedList list;
    list.concatenate(&list1);
    assert(list1.size() == 3);
    assert(list1.toString() == "[CharLinkedList of size 3 <<kai>>]");
}

// test to see adding a single char to a full list
void testConcate5() {
    char array1[] = {'k', 'a', 'i'};
    CharLinkedList list1(array1, 3);
    CharLinkedList list2('a');
    list1.concatenate(&list2);
    assert(list1.size() == 4);
    assert(list1.toString() == "[CharLinkedList of size 4 <<kaia>>]");
}
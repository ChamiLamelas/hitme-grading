/*
 *  unit_tests.h
 *  YOUR NAME HERE
 *  DATE CREATED
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  FILE PURPOSE HERE
 *
 */

#include "CharLinkedList.h"
#include <cassert>

/*
 * constructor test 0
 * Make sure no fatal errors/memory leaks in the default constructor
 */
void constructor_test_0() {
    CharLinkedList list;
}

/*
 * size test 0
 * tests the size function outputs list_size for an empty list
 */
void size_test_0() {
    CharLinkedList list;
    assert(list.size() == 0);
}

/*
 * isEmpty test 0
 * tests that the isEmpty function works correctly for an empty list
 */
void isEmpty_test_0() {
    CharLinkedList list;
    assert(list.isEmpty());
}

/*
 * constructor test 1
 * Make sure no fatal errors/memory leaks in the second constructor, and that
 * the destructor works
 */
void constructor_test_1() {
    CharLinkedList list('a');
}

/*
 * size test 1
 * tests the size function outputs list_size for a list with one element
 */
void size_test_1() {
    CharLinkedList list('b');
    assert(list.size() == 1);
}

/*
 * isEmpty test 1
 * tests that the isEmpty function works correctly for a list with one element
 */
void isEmpty_test_1() {
    CharLinkedList list('c');
    assert(not list.isEmpty());
}

/*
 * last test 0
 * tests that the last function can return the last element of a list with 
 * only one element
 */
void last_test_0() {
    CharLinkedList list('y');
    assert(list.last() == 'y');
}

/*
 * last test 1
 * tests that the last function can return the error message when called on an 
 * empty list
 */
void last_test_1() {
    CharLinkedList list;
    bool runtime_error_thrown = false;
    std::string error_message = "";

    try {
        list.last();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot get last of empty LinkedList");
}

/*
 * pushAtBack test 0
 * tests that the right characters can be added at the back of an empty list
 */
void pushAtBack_test_0() {
    CharLinkedList list;
    list.pushAtBack('h');
    assert(list.last() == 'h');
    list.pushAtBack('i');
    assert(list.last() == 'i');
}

/*
 * constructor test 2
 * Make sure no fatal errors/memory leaks in the third constructor, and that
 * the destructor works
 */
void constructor_test_2() {
    char arr[3] = {'d', 'e', 'f'};
    CharLinkedList list(arr, 3);
    assert(list.last() == 'f');
}

/*
 * size test 2
 * tests the size function outputs list_size for an array with more than one 
 * element
 */
void size_test_2() {
    char arr[3] = {'g', 'h', 'i'};
    CharLinkedList list(arr, 3);
    assert(list.size() == 3);
}

/*
 * isEmpty test 2
 * tests that the isEmpty function works correctly for a list with more than 
 * one element
 */
void isEmpty_test_2() {
    char arr[3] = {'j', 'k', 'l'};
    CharLinkedList list(arr, 3);
    assert(not list.isEmpty());
}

/*
 * last test 2
 * tests that the last function can return the last element of a list with 
 * more than one element
 */
void last_test_2() {
    char arr[3] = {'v', 'w', 'x'};
    CharLinkedList list(arr, 3);
    assert(list.last() == 'x');
}

/*
 * toString test 0
 * tests that the toString function can turn a list of characters into a 
 * string
 */
void toString_test_0() {
    char arr[5] = {'h', 'e', 'l', 'l', 'o'};
    CharLinkedList list(arr, 5);
    assert(list.toString() == "[CharLinkedList of size 5 <<hello>>]");
}

/*
 * toString test 1
 * tests that the toString function will output the correct statement for an
 * empty list
 */
void toString_test_1() {
    CharLinkedList list;
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}

/*
 * toString test 2
 * tests that the toString function will output the correct statement for a list
 * with one element
 */
void toString_test_2() {
    CharLinkedList list('f');
    assert(list.toString() == "[CharLinkedList of size 1 <<f>>]");
}

/*
 * pushAtBack test 1
 * tests that the function works for when characters are added to a nonempty 
 * list
 */
void pushAtBack_test_1() {
    char arr[4] = {'b', 'i', 'r', 'd'};
    CharLinkedList list(arr, 4);
    list.pushAtBack('i');
    list.pushAtBack('e');
    assert(list.toString() == "[CharLinkedList of size 6 <<birdie>>]");
}

/* 
 * assign operator test 0
 * tests that the assign operator successfully makes a deep copy in an empty
 * list
 */
void assignOperator_test_0() {
    CharLinkedList list;
    char arr[4] = {'b', 'o', 'o', 'k'};
    CharLinkedList list1(arr, 4);
    list = list1;
    assert(list.toString() == "[CharLinkedList of size 4 <<book>>]");
    assert(list1.toString() == "[CharLinkedList of size 4 <<book>>]");
    list.pushAtBack('s');
    list1.pushAtBack('e');
    assert(list.toString() == "[CharLinkedList of size 5 <<books>>]");
    assert(list1.toString() == "[CharLinkedList of size 5 <<booke>>]");
}

/* 
 * assign operator test 1
 * tests that the assign operator successfully makes a deep copy in a populated
 * list
 */
void assignOperator_test_1() {
    char arr[4] = {'b', 'o', 'o', 'k'};
    CharLinkedList list(arr, 4);
    char arr1[4] = {'i', 'p', 'a', 'd'};
    CharLinkedList list1(arr1, 4);
    list = list1;
    assert(list.toString() == "[CharLinkedList of size 4 <<ipad>>]");
    assert(list1.toString() == "[CharLinkedList of size 4 <<ipad>>]");
    list.pushAtBack('s');
    list1.pushAtBack('e');
    assert(list.toString() == "[CharLinkedList of size 5 <<ipads>>]");
    assert(list1.toString() == "[CharLinkedList of size 5 <<ipade>>]");
}

/* 
 * assign operator test 2
 * tests that the assign operator successfully makes a deep copy of an empty 
 * list
 */
void assignOperator_test_2() {
    CharLinkedList list;
    char arr[4] = {'h', 'e', 'h', 'e'};
    CharLinkedList list1(arr, 4);
    list1 = list;
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
    assert(list1.toString() == "[CharLinkedList of size 0 <<>>]");
    list.pushAtBack('s');
    list1.pushAtBack('e');
    assert(list.toString() == "[CharLinkedList of size 1 <<s>>]");
    assert(list1.toString() == "[CharLinkedList of size 1 <<e>>]");
}

/*
 * copy constructor test 0
 * tests that the copy constructor works in creating a deep copy of a list and
 * that its memory is cleaned up with an empty list
 */
void copyConstructor_test_0() {
    CharLinkedList list;
    CharLinkedList list_copy(list);
}

/*
 * copy constructor test 1
 * tests that the copy constructor works in creating a deep copy of a list and
 * that its memory is cleaned up with a nonempty list
 */
void copyConstructor_test_1() {
    char arr[4] = {'b', 'i', 'r', 'd'};
    CharLinkedList list(arr, 4);
    CharLinkedList list_copy(list);
}

/*
 * first test 0
 * tests that the first function can return the first element of a list with 
 * more than one element
 */
void first_test_0() {
    char arr[3] = {'r', 's', 't'};
    CharLinkedList list(arr, 3);
    assert(list.first() == 'r');
}

/*
 * first test 1
 * tests that the first function can return the first element of a list with 
 * only one element
 */
void first_test_1() {
    CharLinkedList list('u');
    assert(list.first() == 'u');
}

/*
 * first test 2
 * tests that the first function can return the error message when called on a 
 * list with 0 elements
 */
void first_test_2() {
    CharLinkedList list;
    bool runtime_error_thrown = false;
    std::string error_message = "";

    try {
        list.first();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot get first of empty LinkedList");
}

/*
 * pushAtFront test 0
 * tests that the pushAtFront function can add a new element at the start of a 
 * nonempty list 
 */
void pushAtFront_test_0() {
    char arr[6] = {'b', 'a', 'n', 'a', 'n', 'a'};
    CharLinkedList list(arr, 6);
    list.pushAtFront('a');
    assert(list.toString() == "[CharLinkedList of size 7 <<abanana>>]");
}

/*
 * pushAtFront test 1
 * tests that the function can add elements successfully to an empty list
 */
void pushAtFront_test_1() {
    CharLinkedList list;
    list.pushAtFront('o');
    list.pushAtFront('y');
    assert(list.toString() == "[CharLinkedList of size 2 <<yo>>]");
}

/*
 * popFromFront test 0
 * tests that the popFromFront function successfully removes the first element 
 * of a list with more than one element
 */
void popFromFront_test_0() {
    char arr[6] = {'c', 'h', 'e', 'e', 's', 'e'};
    CharLinkedList list(arr, 6);
    list.popFromFront();
    assert(list.toString() == "[CharLinkedList of size 5 <<heese>>]");
}

/*
 * popFromFront test 1
 * tests that the function empties a list with only one element when called
 */
void popFromFront_test_1() {
    CharLinkedList list('w');
    list.popFromFront();
    assert(list.size() == 0);
}

/*
 * popFromFront test 2
 * tests that the function correctly throws the error message when called on an
 * already empty list
 */
void popFromFront_test_2() {
    CharLinkedList list;
    bool runtime_error_thrown = false;
    std::string error_message = "";

    try {
        list.popFromFront();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

/*
 * popFromBack test 0
 * tests that the popFromBack function successfully removes the last element of
 * a list with more than one element
 */
void popFromBack_test_0() {
    char arr[6] = {'c', 'h', 'e', 'e', 's', 'e'};
    CharLinkedList list(arr, 6);
    list.popFromBack();
    assert(list.toString() == "[CharLinkedList of size 5 <<chees>>]");
}

/*
 * popFromBack test 1
 * tests that the function empties a list with only one element when called
 */
void popFromBack_test_1() {
    CharLinkedList list('w');
    list.popFromBack();
    assert(list.size() == 0);
}

/*
 * popFromBack test 2
 * tests that the function correctly throws the error message when called on an
 * already empty list
 */
void popFromBack_test_2() {
    CharLinkedList list;
    bool runtime_error_thrown = false;
    std::string error_message = "";

    try {
        list.popFromBack();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

/*
 * toReverseString test 0
 * tests that the toReverseString function can turn a list of characters into 
 * a string backwards
 */
void toReverseString_test_0() {
    char arr[9] = {'b', 'a', 'c', 'k', 'w', 'a', 'r', 'd', 's'};
    CharLinkedList list(arr, 9);
    assert(list.toReverseString() == 
    "[CharLinkedList of size 9 <<sdrawkcab>>]");
}

/*
 * toReverseString test 1
 * tests that the toReverseString function will output the correct statement for
 * an empty list
 */
void toReverseString_test_1() {
    CharLinkedList list;
    assert(list.toReverseString() == "[CharLinkedList of size 0 <<>>]");
}

/*
 * toReverseString test 2
 * tests that the toReverseString function will output the correct statement for
 * a list with one element
 */
void toReverseString_test_2() {
    CharLinkedList list('r');
    assert(list.toReverseString() == "[CharLinkedList of size 1 <<r>>]");
}

/*
 * concatenate test 0
 * tests that the concatenate function can successfully insert one list's
 * characters into the other
 */
void concatenate_test_0() {
    char arr[4] = {'b', 'i', 'r', 'd'};
    CharLinkedList list(arr, 4);
    char arr1[4] = {'f', 'i', 's', 'h'};
    CharLinkedList list1(arr1, 4);
    CharLinkedList *list1_p = &list1;
    list.concatenate(list1_p);
    assert(list.toString() == "[CharLinkedList of size 8 <<birdfish>>]");
}

/*
 * concatenate test 1
 * tests that the concatenate function can successfully copy over other list's
 * characters into an initially empty list
 */
void concatenate_test_1() {
    CharLinkedList list;
    char arr[4] = {'f', 'i', 's', 'h'};
    CharLinkedList list1(arr, 4);
    CharLinkedList *list1_p = &list1;
    list.concatenate(list1_p);
    assert(list.toString() == "[CharLinkedList of size 4 <<fish>>]");
}

/*
 * concatenate test 2
 * tests that the concatenate function can successfully copy over an empty list
 * into a nonempty list, leaving it unchanged
 */
void concatenate_test_2() {
    char arr[4] = {'f', 'i', 's', 'h'};
    CharLinkedList list(arr, 4);
    CharLinkedList list1;
    CharLinkedList *list1_p = &list1;
    list.concatenate(list1_p);
    assert(list.toString() == "[CharLinkedList of size 4 <<fish>>]");
}

/*
 * concatenate test 3
 * tests that the concatenate function can successfully concatenate a list with
 * itself
 */
void concatenate_test_3() {
    char arr[4] = {'f', 'i', 's', 'h'};
    CharLinkedList list(arr, 4);
    CharLinkedList *list_p = &list;
    list.concatenate(list_p);
    assert(list.toString() == "[CharLinkedList of size 8 <<fishfish>>]");
}

/*
 * elementAt test 0
 * tests that the elementAt function correctly returns the element of a list 
 * at the given index
 */
void elementAt_test_0() {
    char arr[3] = {'z', 'a', 'b'};
    CharLinkedList list(arr, 3);
    assert(list.elementAt(1) == 'a');
}

/*
 * elementAt test 1
 * tests that the elementAt function outputs the correct error message when its
 * input is less than 0
 */
void elementAt_test_1() {
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList list(arr, 3);
    bool range_error_thrown = false;
    std::string error_message = "";

    try {
        list.elementAt(-4);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (-4) not in range [0..3)");
}

/*
 * elementAt test 2
 * tests that the elementAt function outputs the correct error message when its
 * input is greater than the list's size
 */
void elementAt_test_2() {
    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(arr, 5);
    bool range_error_thrown = false;
    std::string error_message = "";

    try {
        list.elementAt(10);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (10) not in range [0..5)");
}

/*
 * elementAt test 3
 * tests that the elementAt function outputs the correct error message when its
 * called on an empty list
 */
void elementAt_test_3() {
    CharLinkedList list;
    bool range_error_thrown = false;
    std::string error_message = "";

    try {
        list.elementAt(10);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (10) not in range [0..0)");
}

/*
 * clear test 0
 * tests that the clear function successfully empties a list with more than 1
 * element
 */
void clear_test_0() {
    char arr[5] = {'m', 'n', 'o', 'p', 'q'};
    CharLinkedList list(arr, 5);
    list.clear();
    assert(list.isEmpty());
    assert(list.size() == 0);
}

/*
 * clear test 1
 * tests that the clear function successfully empties an already empty list
 */
void clear_test_1() {
    CharLinkedList list;
    list.clear();
    assert(list.isEmpty());
    assert(list.size() == 0);
}

/*
 * replaceAt test 0
 * tests that the replaceAt function can replace the element at a specified
 * index with a specified character
 */
void replaceAt_test_0() {
    char arr[6] = {'c', 'h', 'e', 'e', 's', 'e'};
    CharLinkedList list(arr, 6);
    list.replaceAt('t', 5);
    assert(list.toString() == "[CharLinkedList of size 6 <<cheest>>]");
}

/*
 * replaceAt test 1
 * tests that the replaceAt function can throw the correct error message when it
 * receives an index that's out of bounds and less than 0
 */
void replaceAt_test_1() {
    char arr[3] = {'b', 'y', 'e'};
    CharLinkedList list(arr, 3);
    bool range_error_thrown = false;
    std::string error_message = "";

    try {
        list.replaceAt('q', -1);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (-1) not in range [0..3)");
}

/*
 * replaceAt test 2
 * tests that the replaceAt function can throw the correct error message when it
 * receives an index that's out of bounds and more than 1 minus its size
 */
void replaceAt_test_2() {
    char arr[5] = {'p', 'i', 'z', 'z', 'a'};
    CharLinkedList list(arr, 5);
    bool range_error_thrown = false;
    std::string error_message = "";

    try {
        list.replaceAt('e', 5);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (5) not in range [0..5)");
}

/*
 * replaceAt test 3
 * tests that the replaceAt function can throw the correct error message when it
 * is called on an empty array
 */
void replaceAt_test_3() {
    CharLinkedList list;
    bool range_error_thrown = false;
    std::string error_message = "";

    try {
        list.replaceAt('r', 0);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (0) not in range [0..0)");
}

// Tests correct insertion into an empty LL.
// Afterwards, size should be 1 and element at index 0
// should be the element we inserted.
void insertAt_empty_correct() { 

    CharLinkedList test_list;
    test_list.insertAt('a', 0);
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');

}

// Tests incorrect insertion into an empty LL.
// Attempts to call insertAt for index larger than 0.
// This should result in an std::range_error being raised.
void insertAt_empty_incorrect() {

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    // insertAt for out-of-range index
    test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
    // if insertAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    range_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0]");
    
}

// Tests correct insertAt for front of 1-element list.
void insertAt_front_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at front
    test_list.insertAt('b', 0);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'a');
    
}

// Tests correct insertAt for back of 1-element list.
void insertAt_back_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at back
    test_list.insertAt('b', 1);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    
}

// Tests calling insertAt for a large number of elements.
void insertAt_many_elements() {
    
    CharLinkedList test_list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.insertAt('a', i);
    }

    assert(test_list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
    
}

// Tests insertion into front of a larger list
void insertAt_front_large_list() {
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    test_list.insertAt('y', 0);

    assert(test_list.size() == 10);
    assert(test_list.elementAt(0) == 'y');
    assert(test_list.toString() == 
    "[CharLinkedList of size 10 <<yabczdefgh>>]");

}

// Tests insertion into the back of a larger list
void insertAt_back_large_list() {

    char test_arr[10] = { 'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 10);  

    test_list.insertAt('x', 10);

    assert(test_list.size() == 11);
    assert(test_list.elementAt(10) == 'x');
    assert(test_list.toString() == 
    "[CharLinkedList of size 11 <<yabczdefghx>>]"); 

}

// Tests insertion into the middle of a larger list
void insertAt_middle_large_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.insertAt('z', 3);

    assert(test_list.size() == 9);
    assert(test_list.elementAt(3) == 'z');
    assert(test_list.toString() == "[CharLinkedList of size 9 <<abczdefgh>>]");

}

// Tests out-of-range insertion for a non-empty list.
void insertAt_nonempty_incorrect() {
   
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8]");
    
}

/*
 * insertInOrder test 0
 * tests that the function can insert an element correctly at the front of the
 * linked list that isn't in alphabetical order
 */
void insertInOrder_test_0() {
    char arr[3] = {'Z', 'E', 'D'};
    CharLinkedList list(arr, 3);
    list.insertInOrder('A');
    assert(list.toString() == "[CharLinkedList of size 4 <<AZED>>]");
}

/*
 * insertInOrder test 1
 * tests that the function can insert an element correctly at the back of the
 * linked list in alphabetical order
 */
void insertInOrder_test_1() {
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList list(arr, 3);
    list.insertInOrder('z');
    assert(list.toString() == "[CharLinkedList of size 4 <<abcz>>]");
}

/*
 * insertInOrder test 2
 * tests that the function can insert an element correctly in the middle of the
 * linked list in alphabetical order
 */
void insertInOrder_test_2() {
    char arr[5] = {'A', 'B', 'D', 'E', 'F'};
    CharLinkedList list(arr, 5);
    list.insertInOrder('C');
    assert(list.toString() == "[CharLinkedList of size 6 <<ABCDEF>>]");
}

/*
 * insertInOrder test 3
 * tests that the function can insert an element correctly at the front of the
 * linked list that is in alphabetical order
 */
void insertInOrder_test_3() {
    char arr[3] = {'B', 'C', 'D'};
    CharLinkedList list(arr, 3);
    list.insertInOrder('A');
    assert(list.toString() == "[CharLinkedList of size 4 <<ABCD>>]");
}

/*
 * insertInOrder test 4
 * tests that the function can insert an element correctly at the back of the
 * linked list not in alphabetical order
 */
void insertInOrder_test_4() {
    char arr[3] = {'X', 'a', 'R'};
    CharLinkedList list(arr, 3);
    list.insertInOrder('z');
    assert(list.toString() == "[CharLinkedList of size 4 <<XaRz>>]");
}

/*
 * insertInOrder test 5
 * tests that the function can insert an element correctly in the middle of the
 * linked list not in alphabetical order
 */
void insertInOrder_test_5() {
    char arr[5] = {'D', 'B', 'L', 'P', 'A'};
    CharLinkedList list(arr, 5);
    list.insertInOrder('N');
    assert(list.toString() == "[CharLinkedList of size 6 <<DBLNPA>>]");
}

/*
 * insertInOrder test 6
 * tests that the function can insert an element correctly in the middle of the
 * linked list already holding that element in alphabetical order
 */
void insertInOrder_test_6() {
    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(arr, 5);
    list.insertInOrder('b');
    assert(list.toString() == "[CharLinkedList of size 6 <<abbcde>>]");
}

/*
 * insertInOrder test 7
 * tests that the function can insert an element correctly in the middle of the
 * linked list already holding that element not in alphabetical order
 */
void insertInOrder_test_7() {
    char arr[5] = {'c', 'b', 'h', 'e', 'i'};
    CharLinkedList list(arr, 5);
    list.insertInOrder('h');
    assert(list.toString() == "[CharLinkedList of size 6 <<cbhhei>>]");
}

/*
 * removeAt test 0
 * tests that the removeAt function can remove the element at a specified
 * index
 */
void removeAt_test_0() {
    char arr[6] = {'c', 'h', 'e', 'e', 's', 'e'};
    CharLinkedList list(arr, 6);
    list.removeAt(3);
    assert(list.toString() == "[CharLinkedList of size 5 <<chese>>]");
}

/*
 * removeAt test 1
 * tests that the removeAt function can throw the correct error message when it
 * receives an index that's out of bounds and less than 0
 */
void removeAt_test_1() {
    char arr[3] = {'b', 'y', 'e'};
    CharLinkedList list(arr, 3);
    bool range_error_thrown = false;
    std::string error_message = "";

    try {
        list.removeAt(-2);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (-2) not in range [0..3)");
}

/*
 * removeAt test 2
 * tests that the removeAt function can throw the correct error message when it
 * receives an index that's out of bounds and more than 1 minus its size
 */
void removeAt_test_2() {
    char arr[5] = {'p', 'i', 'z', 'z', 'a'};
    CharLinkedList list(arr, 5);
    bool range_error_thrown = false;
    std::string error_message = "";

    try {
        list.removeAt(5);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (5) not in range [0..5)");
}

/*
 * removeAt test 3
 * tests that the removeAt function can throw the correct error message when it
 * is called on an empty list
 */
void removeAt_test_3() {
    CharLinkedList list;
    bool range_error_thrown = false;
    std::string error_message = "";

    try {
        list.removeAt(0);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (0) not in range [0..0)");
}
/*
 *  CharLinkedList.cpp
 *  YOUR NAME HERE
 *  DATE CREATED
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Function declarations for the CharLinkedList class
 *
 */

#include "CharLinkedList.h"
#include <sstream>
#include <string>

/*
 * name:      CharLinkedList default constructor
 * purpose:   initialize an empty CharLinkedList
 * arguments: none
 * returns:   none
 * effects:   size to 0 (also updates front and back pointers)
 */
CharLinkedList::CharLinkedList() {
    front = nullptr;
    back = nullptr;
    list_size = 0;
}

/* 
 * name:      CharLinkedList second constructor
 * purpose:   initialize a CharLinkedList with a given letter
 * arguments: a character to insert in the list
 * returns:   none
 * effects:   size to 1 (also updates front pointer, back pointer, and creates
              a new node)
 */
CharLinkedList::CharLinkedList(char c) {
    Node *new_node = new Node;
    front = new_node;
    back = new_node;
    list_size = 1;
    new_node->letter = c;
    new_node->next = nullptr;
    new_node->prev = nullptr;
}

/* 
 * name:      CharLinkedList third constructor
 * purpose:   initialize a CharLinkedList with a given character array
 * arguments: a character array to copy and its size
 * returns:   none
 * effects:   size to the inputted size (also updates front pointer, back 
              pointer, and creates new nodes)
 */
CharLinkedList::CharLinkedList(char arr[], int size) {
    list_size = 0;
    for (int i = 0; i < size; i++) {
        pushAtBack(arr[i]);
    }
}

/* 
 * name:      CharLinkedList copy constructor
 * purpose:   initialize a CharLinkedList with a deep copy of a given 
 *            CharLinkedList
 * arguments: the address of a CharLinkedList
 * returns:   none
 * effects:   size to the given list's size (also updates front pointer, back 
              pointer, and creates new nodes)
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other) {
    list_size = other.list_size;
    if (other.list_size == 0) {
        front = nullptr;
        back = nullptr;
        list_size = 0;
    } else {
        construct_helper(other);
    }
}

/* 
 * name:      CharLinkedList destructor
 * purpose:   deletes the pointers to the nodes to clean up memory
 * arguments: none
 * returns:   none
 * effects:   no memory leaks
 */
CharLinkedList::~CharLinkedList() {
    destruct_helper(front);
}

/* 
 * name:      CharLinkedList destructor helper
 * purpose:   recursively cleans up memory when called in the destructor 
              function
 * arguments: a node pointer
 * returns:   none
 * effects:   no memory leaks
 */
void CharLinkedList::destruct_helper(Node *curr) {
    if (curr == nullptr) {
        return;
    } else {
        Node *next = curr->next;
        delete curr;
        destruct_helper(next);
    }
}

/* 
 * name:      CharLinkedList overloaded assignment operator
 * purpose:   overload the assignment operator (=) to make deep copies of the
 *            CharLinkedList class possible
 * arguments: the address of a CharLinkedList
 * returns:   a pointer to the new, updated CharLinkedList
 * effects:   a successful deep copy with no memeory leaks
 */
CharLinkedList & CharLinkedList::operator=(const CharLinkedList &other) {
    if (this == &other) {
        return *this;
    }
    destruct_helper(front);
    if (other.list_size == 0) {
        front = nullptr;
        back = nullptr;
        list_size = 0;
        return *this;
    }   
    construct_helper(other);
    return *this;
}

/* 
 * name:      CharLinkedList copy constructor helper
 * purpose:   helps the copy constructor function initialize a CharLinkedList 
 *            with a deep copy of a given CharLinkedList
 * arguments: the address of a CharLinkedList
 * returns:   none
 * effects:   a deep copy of the linked list
 */
void CharLinkedList::construct_helper(const CharLinkedList &other) {
    list_size = other.list_size;
    Node *first_node = new Node;
    front = first_node;
    first_node->letter = other.front->letter;
    Node *other_node = other.front->next;
    first_node->prev = nullptr;
    Node *curr = first_node;
    for (int i = 1; i < list_size; i++) {
        Node *new_node = new Node;
        new_node->letter = other_node->letter;
        new_node->prev = curr;
        curr->next = new_node;
        curr = new_node;
        other_node = other_node->next;
        if (i == list_size - 1) {
            back = new_node;
            new_node->next = nullptr;
        }
    }
}

/* 
 * name:      isEmpty
 * purpose:   evalutes if a character list has no characters or not
 * arguments: none
 * returns:   a boolean of whether a list is empty (true) or not (false)
 * effects:   none
 */
bool CharLinkedList::isEmpty() const {
    if (list_size == 0) {
        return true;
    } else {
        return false;
    }
}

/* 
 * name:      clear
 * purpose:   clears all the characters in a list, leaving it empty
 * arguments: none
 * returns:   none
 * effects:   a character list of size 0 (empty)
 */
void CharLinkedList::clear() {
    destruct_helper(front);
    front = nullptr;
    back = nullptr;
    list_size = 0;
}

/* 
 * name:      size
 * purpose:   gets the size of the list
 * arguments: none
 * returns:   the integer list_size, the number of elements in the list
 * effects:   none
 */
int CharLinkedList::size() const {
    return list_size;
}

/* 
 * name:      toString
 * purpose:   turns the list into a string and returns it
 * arguments: none
 * returns:   a string of the character list
 * effects:   none
 */
std::string CharLinkedList::toString() const {
    std::string s_list_size = std::to_string(list_size);
    std::string list_string = "[CharLinkedList of size " + s_list_size + " <<";

    for (Node *curr = front; curr != nullptr; curr = curr->next) {
        list_string += curr->letter;
    }

    list_string += ">>]";

    return list_string;
}

/* 
 * name:      toReverseString
 * purpose:   turns the list into a reversed string and returns it
 * arguments: none
 * returns:   a backwards string of the character list
 * effects:   none
 */
std::string CharLinkedList::toReverseString() const {
    std::string s_list_size = std::to_string(list_size);
    std::string list_string = "[CharLinkedList of size " + s_list_size + " <<";

    for (Node *curr = back; curr != nullptr; curr = curr->prev) {
        list_string += curr->letter;
    }

    list_string += ">>]";

    return list_string;
}

/* 
 * name:      first
 * purpose:   gets the first element of the list
 * arguments: none
 * returns:   the character of the front pointer of the list if it is not empty.
 *            If it is, the function throws an exception
 * effects:   none
 */
char CharLinkedList::first() const {
    if (list_size == 0) {
        throw std::runtime_error("cannot get first of empty LinkedList");
    } else {
        return front->letter;
    }
}

/* 
 * name:      last
 * purpose:   gets the last element of the list
 * arguments: none
 * returns:   the character of the back pointer of the list if it is not empty. 
 *            If it is, the function throws an exception
 * effects:   none
 */
char CharLinkedList::last() const {
    if (list_size == 0) {
        throw std::runtime_error("cannot get last of empty LinkedList");
    } else {
        return back->letter;
    }
}

/* 
 * name:      elementAt
 * purpose:   gets the element of the list at a specified index
 * arguments: an integer of the specific index
 * returns:   the character in the specified index of the list if it is in 
 *            range. If not, the function throws an exception
 * effects:   none
 */
char CharLinkedList::elementAt(int index) const {
    if (index >= list_size or index < 0) {
        //converts the integers index and list_size into strings for the error
        //messege
        std::string s_index = std::to_string(index);
        std::string s_list_size = std::to_string(list_size);
        std::string error = "index (" + s_index + ") not in range [0.." 
                            + s_list_size + ")";
        throw std::range_error(error);
    } else {
        int counter = 0;
        return elementAt_helper(front, index, counter);
    }
}

/* 
 * name:      elementAt helper
 * purpose:   recursively searches for the node at the specified index
 * arguments: a node pointer, the integer of the specified index, and an integer
 *            counter
 * returns:   the character in the specified index of the list
 * effects:   none
 */
char CharLinkedList::elementAt_helper(Node *curr, int index, int counter) const 
{
    if (counter == index) {
        return curr->letter;
    } else {
        return elementAt_helper(curr->next, index, counter + 1);
    }
}

/*
 * name:      pushAtBack
 * purpose:   push specified character onto the back of the list
 * arguments: a character to add to the back of the list
 * returns:   none
 * effects:   increases size of the list by one and adds the element to the
 *            list
 */
void CharLinkedList::pushAtBack(char c) {
    Node *new_node = new Node;
    new_node->letter = c;
    new_node->next = nullptr;
    if (list_size > 0) {
        new_node->prev = back;
        back->next = new_node;
    } else {
        new_node->prev = nullptr;
        front = new_node;
    }
    back = new_node;

    list_size++;
}

/*
 * name:      pushAtFront
 * purpose:   push specified character onto the front of the list
 * arguments: a character to add to the front of the list
 * returns:   none
 * effects:   increases size of the list by one and adds the element to the
 *            front of the list
 */
void CharLinkedList::pushAtFront(char c) {
    Node *new_node = new Node;
    new_node->letter = c;
    new_node->prev = nullptr;
    if (list_size > 0) {
        new_node->next = front;
        front->prev = new_node;
    } else {
        new_node->next = nullptr;
        back = new_node;
    }
    front = new_node;
    
    list_size++;
}

/*
 * name:      insertAt
 * purpose:   insert specified character into a specified index of the list
 * arguments: a character to add to the list, and the index of the list to add
 *            it to
 * returns:   none
 * effects:   increases size of the list by one and adds the element to the 
 *            list
 */
void CharLinkedList::insertAt(char c, int index) {
    if (index > list_size or index < 0) {
        //converts the integers index and arr_size into strings for the error
        //messege
        std::string s_index = std::to_string(index);
        std::string s_list_size = std::to_string(list_size);
        std::string error = "index (" + s_index + ") not in range [0.." 
                            + s_list_size + "]";
        throw std::range_error(error);
    } else if (index == 0) {
        pushAtFront(c);
    } else if (index == list_size) {
        pushAtBack(c);
    } else {
        int curr_index = 0;
        Node *curr = front;
        while (curr_index < index - 1) {
            curr = curr->next;
            curr_index++;
        }
        Node *prev_new = curr->next;
        Node *new_node = new Node;
        curr->next = new_node;
        prev_new->prev = new_node;
        new_node->letter = c;
        new_node->next = prev_new;
        new_node->prev = curr;
        list_size++;
    }
}

/*
 * name:      insertInOrder
 * purpose:   insert specified character into a list alphabetically based on
 *            the character's ascii number
 * arguments: a character to add to the list
 * returns:   none
 * effects:   increases size of the list by one and adds the element to the 
 *            list
 */
void CharLinkedList::insertInOrder(char c) {
    bool at_back = true;
    Node *new_node = new Node;
    new_node->letter = c;
    new_node->next = nullptr;

    new_node = order_helper(front, c, new_node);

    if (new_node->next == nullptr){
        new_node->prev = back;
        back->next = new_node;
        back = new_node;
    } else if (new_node->prev == nullptr) {
        front = new_node;
    }
    list_size++;
}

/*
 * name:      insertInOrder helper
 * purpose:   helps the function by updating the next and previous pointers of
 *            the node pointer new based on where it gets inserted in the list
 * arguments: a node pointer to the current list, a character to add to the
 *            list, and a node pointer to the new node to add to the list
 * returns:   a node pointer
 * effects:   updates the next and previous pointers of the new node and cur 
 *            node
 */
CharLinkedList::Node *CharLinkedList::order_helper(Node *cur, char c, Node *New)
{
    int counter = 0;
    while (cur != nullptr) {
        if (cur->letter > c or cur->letter == c) {
            if (counter == 0) {
                New->next = cur;
                cur->prev = New;
                New->prev = nullptr;
                cur = back;
            } else {
                Node *curr_prev = cur->prev;
                New->next = cur;
                New->prev = curr_prev;
                curr_prev->next = New;
                cur->prev = New;
                cur = back;
            }
        }
        cur = cur->next;
        counter++;
    }
    return New;
}

/*
 * name:      popFromFront
 * purpose:   remove the first element of the list
 * arguments: none
 * returns:   none
 * effects:   decreases size of the list by one and removes the first element 
 *            of the list
 */
void CharLinkedList::popFromFront() {
    if (list_size == 0) {
        throw std::runtime_error("cannot pop from empty LinkedList");
    } else if(list_size == 1) {
        delete front;
        front = nullptr;
        back = nullptr;
        list_size--;
    } else {
        Node *new_front = front->next;
        delete front;
        new_front->prev = nullptr;
        front = new_front;
        list_size--;
    }
}

/*
 * name:      popFromBack
 * purpose:   remove the last element of the list
 * arguments: none
 * returns:   none
 * effects:   decreases size of the list by one and removes the last element of
 *            the list
 */
void CharLinkedList::popFromBack() {
    if (list_size == 0) {
        throw std::runtime_error("cannot pop from empty LinkedList");
    } else if(list_size == 1) {
        delete front;
        front = nullptr;
        back = nullptr;
        list_size--;
    } else {
        Node *new_back = back->prev;
        delete back;
        new_back->next = nullptr;
        back = new_back;
        list_size--;
    }
}

/*
 * name:      removeAt
 * purpose:   remove the character at a specified index of the list
 * arguments: an index of the list to remove the element of
 * returns:   none
 * effects:   decreases size of the list by one and removes the element from 
 *            the list
 */
void CharLinkedList::removeAt(int index) {
    if (index >= list_size or index < 0) {
        //converts the integers index and arr_size into strings for the error
        //messege
        std::string s_index = std::to_string(index);
        std::string s_list_size = std::to_string(list_size);
        std::string error = "index (" + s_index + ") not in range [0.." 
                            + s_list_size + ")";
        throw std::range_error(error);
    } else if (index == 0) {
        popFromFront();
    } else if (index == list_size - 1) {
        popFromBack();
    } else {
        Node *curr = front;
        int curr_index = 0;
        while (curr_index < index) {
            curr = curr->next;
            curr_index++;
        }
        Node *prev_node = curr->prev;
        Node *next_node = curr->next;
        prev_node->next = next_node;
        next_node->prev = prev_node;
        delete curr;
        list_size--;
    }
}

/*
 * name:      concatenate
 * purpose:   add one list to the end of another
 * arguments: pointer to a linked list to add to the current list
 * returns:   none
 * effects:   a new linked list with the characters of both lists in one
 */
void CharLinkedList::concatenate(CharLinkedList *other) {
    CharLinkedList copy(*other);
    if (list_size == 0) {
        construct_helper(*other);
    } else if (copy.list_size == 0) {
        return;
    } else {
        Node *other_front_p = copy.front;
        other_front_p->prev = back;
        back->next = other_front_p;
        back = copy.back;
        list_size = list_size + copy.list_size;
        copy.front = nullptr;
    }
}

/*
 * name:      replaceAt
 * purpose:   replace a character at a specified index with a specified 
 *            character
 * arguments: a character to replace the old character with and the index of the
 *            list to replace it at
 * returns:   none
 * effects:   switches out one character for another specified one at any index
 */
void CharLinkedList::replaceAt(char c, int index) {
    if (index >= list_size or index < 0) {
        //converts the integers index and list_size into strings for the error
        //messege
        std::string s_index = std::to_string(index);
        std::string s_list_size = std::to_string(list_size);
        std::string error = "index (" + s_index + ") not in range [0.." 
                            + s_list_size + ")";
        throw std::range_error(error);
    } else {
        int count = 0;
        replaceAt_helper(front, index, count, c);
    }
}

/*
 * name:      replaceAt helper
 * purpose:   recursively searches for the index in the list and replaces its 
 *            letter with the specified one
 * arguments: a node pointer to the list, an integer of the specified index, an
 *            integer to the count of recursive loops, and the character to
 *            replace with
 * returns:   none
 * effects:   switches out one character for another specified one at any index
 */
void CharLinkedList::replaceAt_helper(Node *curr, int index, int count, char c)
{
        if (count == index) {
            curr->letter = c;
        } else {
            replaceAt_helper(curr->next, index, count + 1, c);
        }
}
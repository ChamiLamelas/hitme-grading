/*
 *  CharLinkedList.h
 *  Francesca Wan
 *  2/2/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Purpose: Definitions of each function.
 *
 */

#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H
#include <sstream>
#include <iostream>

class CharLinkedList {
public:
    //constructor
    CharLinkedList();
    CharLinkedList(char c);
    CharLinkedList(char arr[], int size);
    CharLinkedList(const CharLinkedList &other);
    //deconstructor
    ~CharLinkedList();
    //assignment operator
    CharLinkedList &operator=(const CharLinkedList &other);
    //functions
    bool isEmpty() const;
    void clear();
    int size();
    char first() const;
    char last() const;
    char elementAt(int index) const;
    std::string toString() const;
    std::string toReverseString() const;
    void pushAtBack(char c);
    void pushAtFront(char c);
    void insertAt(char c, int index);
    void insertInOrder(char c);
    void popFromFront();
    void popFromBack();
    void removeAt(int index);
    void replaceAt(char c, int index);
    void concatenate(CharLinkedList *other);
private:
    struct Node {
        Node *next;
        Node *prev;
        char letter;
    };

    Node *front;
    Node *back;
    int lsize;
    void helpDelete(Node* curr_node);
    Node *helpFind(int index, int count, Node* curr_node) const;
};

#endif

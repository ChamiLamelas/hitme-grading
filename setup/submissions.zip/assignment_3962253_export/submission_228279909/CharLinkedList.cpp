/*
 *  CharLinkedList.cpp
 *  Francesca Wan
 *  2/2/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Purpose: Create a list of methods that could be used by a client. Character
 *  linked lists are first initiate with an empty list. The client can then add
 *  and remove elements within the list.
 *
 */

#include "CharLinkedList.h"

/* Constructor to initialize CharLinkedList */
CharLinkedList::CharLinkedList() {
    lsize = 0;
    front = nullptr;
    back = nullptr;
}

/* Constructor that takes in a character */
CharLinkedList::CharLinkedList(char c) {
    lsize = 1;
    Node *newNode = new Node {nullptr, nullptr, c};
    front = newNode;
    back = newNode;
}

/* Constructor that takes in an array and a size */
CharLinkedList::CharLinkedList(char arr[], int size) {
    this->lsize = 0;
    this->front = nullptr;
    this->back = nullptr;

    for(int i = 0; i < size; i++) {
        pushAtBack(arr[i]);
    }
}

/* Copy Constructor */
CharLinkedList::CharLinkedList(const CharLinkedList &other) {
    lsize = 0;
    front = other.front;
    back = other.back;

    for(int i = 0; i < other.lsize; i++) {
        char nextLetter = other.elementAt(i);
        pushAtBack(nextLetter);
    }
}

/* Deconstructor */
CharLinkedList::~CharLinkedList() {
    //need a helper recursive function
    helpDelete(back);
}

/*
 * name:      helpDelete
 * purpose:   helper function to the deconstructor to delete nodes
 * arguments: a node pointer
 * returns:   none
 * effects:   nodes being deleted
 */
void CharLinkedList::helpDelete(Node* curr_node) {
    if(curr_node == front) {
        delete curr_node;
    } else { //make the new last node to delete
        Node *next_back = curr_node->prev;
        delete curr_node;
        helpDelete(next_back);
    }
}

/*
 * name:      operator=
 * purpose:   make a deep copy of the assignment operator
 * arguments: the address of a constant CharLinkedList called other
 * returns:   a list that has been deep copied from an inserted list
 * effects:   make a deep copy of an instance to another list
 */
CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other) {
    if(this == &other) { //if the array list is the same
        return *this;
    }
    //deep copy an array list to another array list
    lsize = 0;
    front = other.front;
    back = other.back;

    for(int i = 0; i < other.lsize; i++) {
        pushAtBack(other.elementAt(i));
    }

    return *this;
}

/*
 * name:      isEmpty
 * purpose:   return if list is empty or not
 * arguments: none
 * returns:   boolean value if list is empty
 * effects:   none
 */
bool CharLinkedList::isEmpty() const {
    if(lsize == 0) {
        return true;
    } else {
        return false;
    }
}

/*
 * name:      clear
 * purpose:   clear a list of elements
 * arguments: none
 * returns:   none
 * effects:   size is changed to zero
 */
void CharLinkedList::clear() {
    while(not isEmpty()) {
        popFromBack();
    }
}

/*
 * name:      size
 * purpose:   return an int that is the size of the linked list
 * arguments: none
 * returns:   int value that returns the size of the linked list
 * effects:   none
 */
int CharLinkedList::size() {
    return lsize;
}

/*
 * name:      first
 * purpose:   get the first element of the list
 * arguments: none
 * returns:   char first element in the linked list
 * effects:   Raises an error if it is an empty LinkedList
 */
char CharLinkedList::first() const {
    if(isEmpty()) { //if list is empty throw an error
        throw std::runtime_error("cannot get first of empty LinkedList");
    }
    //return first element in list
    return front->letter;
}

/*
 * name:      last
 * purpose:   get the last element of the list
 * arguments: none
 * returns:   the last element in the linked list
 * effects:   Raises an error if linked list is empty
 */
char CharLinkedList::last() const {
    if(isEmpty()) { //if list is empty throw an error
        throw std::runtime_error("cannot get last of empty LinkedList");
    }
    //return last element in lits
    return back->letter;
}

/*
 * name:      elementAt
 * purpose:   get the linked list element at a given index
 * arguments: an integer idex representing a linked list index
 * returns:   the character element at a given index
 * effects:   error raised if index is not in range
 */
char CharLinkedList::elementAt(int index) const {
    if(index >= lsize or index < 0) {
        throw std::range_error("index (" + std::to_string(index) 
                                + ") not in range [0.." + std::to_string(lsize)
                                + ")");
    }
    //use a helper function to recursively find an element
    int count = 0;
    Node *found = helpFind(index, count, front);
    //return the letter of the node
    return found->letter;
}

/*
 * name:      helpFind
 * purpose:   helper function that finds a node of a particular index
 * arguments: an integer index, an interger count, a node pointer
 * returns:   node pointer
 * effects:   none
 */
CharLinkedList::Node *CharLinkedList
              ::helpFind(int index, int count, Node* curr_node) const {
    if(count == index) { //return letter if the right index is found
        return curr_node;
    } else {
        curr_node = curr_node->next;
        count++;
        return helpFind(index, count, curr_node);
    }
}

/*
 * name:      toString
 * purpose:   convert array to string
 * arguments: none
 * returns:   string of elements in the list
 * effects:   Prints the size and string of the list
 */
std::string CharLinkedList::toString() const {
    //convert to string
    std::stringstream result;
    result << "[CharLinkedList of size " << lsize << " <<";
    for(int i = 0; i < lsize; i++) { //adds each element to the string
        result << elementAt(i);
    }
    result << ">>]";
    return result.str(); //return as string
}

/*
 * name:      toReverseString
 * purpose:   convert linked list to a reverse version the elements
 * arguments: none
 * returns:   the string element of elements in list
 * effects:   none
 */
std::string CharLinkedList::toReverseString() const {
    //convert to string
    std::stringstream result;
    result << "[CharLinkedList of size " << lsize << " <<";
    for(int i = lsize-1; i > -1; i--) { //adds each element to the string
        result << elementAt(i);
    }
    result << ">>]";
    return result.str(); //return as string
}

/*
 * name:      pushAtBack
 * purpose:   push an element to the back of the linked list
 * arguments: a char character
 * returns:   none
 * effects:   size of list increases
 */
void CharLinkedList::pushAtBack(char c) { //smth to do w *prev
    //only the first node becomes the front
    if(isEmpty()) {//create a node for an empty list
        Node *newNode = new Node {nullptr, nullptr, c};
        front = newNode;
        back = newNode;
    } else { //create a Node
        //create a node
        Node *lastNode = back;
        Node *newNode = new Node {nullptr, lastNode, c};
        lastNode->next = newNode;
        back = newNode;
    }
    //size increased
    lsize++;
}

/*
 * name:      pushAtFront
 * purpose:   insert element to the front of the character list
 * arguments: a character that is being inserted
 * returns:   none
 * effects:   size of list increases
 */
void CharLinkedList::pushAtFront(char c) {
    //if insert at the front of the list
    if(isEmpty()) {
        //if it is an empty array
        Node *newNode = new Node {nullptr, nullptr, c};
        front = newNode;
        back = newNode;
    } else {
        //if insert to the front of the list
        Node *first = front;
        Node *newNode = new Node {first, nullptr, c};
        front = newNode;
        first->prev = newNode;
    }
    //size increased
    lsize++;
}

/*
 * name:      insertAt
 * purpose:   insert an element at a given index
 * arguments: an integer index representing a linked list index, a character
 * returns:   none
 * effects:   Raises an error if element is out-of-bounds of the CharLinkedList,
 *            size increases
 */
void CharLinkedList::insertAt(char c, int index) {
    if(index > lsize or index < 0) { //error is thrown if given index is out of bounds
        throw std::range_error("index (" + std::to_string(index) 
                                + ") not in range [0.." + std::to_string(lsize)
                                + "]");
    }

    if(index == 0) { //if character is inserted to front of list
        pushAtFront(c);

    } else if(index == lsize) { //if character is inserted to back of list
        pushAtBack(c);

    } else { //if insert to middle of the list
        //find each node that will connect the node to the list
        int count = 0;
        Node *foundNext = helpFind(index, count, front);
        Node *foundPrev = foundNext->prev;
        //create the new node and adjust other nodes
        Node *newNode = new Node {foundNext, foundPrev, c};
        foundNext->prev = newNode;
        foundPrev->next = newNode;
        //size increases
        lsize++;
    }
}

/*
 * name:      insertInOrder
 * purpose:   insert new element into the element list in ASCII order
 * arguments: a character
 * returns:   none
 * effects:   size of element list increased
 */
void CharLinkedList::insertInOrder(char c) {
    //if it is an empty list
    if(isEmpty()) {
        pushAtFront(c);

    } else if(front->letter > c) { //if element is less than the first element
        pushAtFront(c);

    } else {
        //search through list
        for(int i = 0; i < lsize; i++) {
            int count = 0;
            Node *found = helpFind(i, count, front);
            //find when the letter is greater than c
            if(found->letter > c) {
                insertAt(c, i);
                return;
            }
        }
        //if it none of the elements in list are bigger
        pushAtBack(c);
    }
}

/*
 * name:      popFromFront
 * purpose:   remove the first element of the element list
 * arguments: none
 * returns:   none
 * effects:   Raises an error if array list is empty, size of element list is
 *            decreased
 */
void CharLinkedList::popFromFront() {
    if(isEmpty()) { //if the list is empty
        throw std::runtime_error("cannot pop from empty LinkedList");
    }

    if(lsize == 1) {
        //list of one element
        clear();

    } else {
        //set the new first element
        Node *firstNode = front;
        Node *newFront = firstNode->next;
        delete firstNode;
        //reset pointers
        front = newFront;
        newFront->prev = nullptr;
        lsize--;
    }
}

/*
 * name:      popFromBack
 * purpose:   remove last element form the linked list
 * arguments: none
 * returns:   none
 * effects:   Raises an error if the linked list is empty, size is decreased
 */
void CharLinkedList::popFromBack() {
    if(isEmpty()) { //error raised if element list is empty
        throw std::runtime_error("cannot pop from empty LinkedList");
    }

    if(lsize == 1) {
        //list of one element
        Node *lastNode = back;
        delete lastNode;
        //set pointers
        back = nullptr;
        front = nullptr;
        lsize--;

    } else {
        //set the new last element
        Node *lastNode = back;
        Node *newBack = lastNode->prev;
        delete lastNode;
        //set pointers
        back = newBack;
        newBack->next = nullptr;
        lsize--;
    }
}

/*
 * name:      removeAt
 * purpose:   remove character at given index
 * arguments: an integer idex
 * returns:   none
 * effects:   Raises an error if idex is out-of-bounds of the element list,
 *            size is decreased
 */
void CharLinkedList::removeAt(int index) {
    if(index >= lsize or index < 0) {//if index is out of range
        throw std::range_error("index (" + std::to_string(index) 
                                + ") not in range [0.." + std::to_string(lsize)
                                + ")");
    }
    //if size is one
    if(lsize == 1) {
        //change the pointers
        Node *found = front;
        delete found;
        back = nullptr;
        front = nullptr;
        lsize--;

    } else if(index == 0) {
        popFromFront();

    } else if(index == lsize-1) {
        popFromBack();    

    } else {
        //find the Node
        int count = 0;
        Node *found = helpFind(index, count, front);
        //change the pointers
        Node *next = found->next;
        Node *prev = found->prev;
        next->prev = prev;
        prev->next = next;
        delete found;
        lsize--;
    }
}

/*
 * name:      replaceAt
 * purpose:   replace character at a given index
 * arguments: a character and an int index
 * returns:   none
 * effects:   Raises an error if idex is out-of-bounds of the element list
 */
void CharLinkedList::replaceAt(char c, int index) {
    //if index is out of range
    if(index >= lsize or index < 0) {
        throw std::range_error("index (" + std::to_string(index) 
                                + ") not in range [0.." + std::to_string(lsize)
                                + ")");
    }
    //find node where to replace
    int count = 0;
    Node *found = helpFind(index, count, front);
    //replace character
    found->letter = c;
}

/*
 * name:      concatenate
 * purpose:   add one array list to the end of another
 * arguments: an inserted array list
 * returns:   none
 * effects:   none
 */
void CharLinkedList::concatenate(CharLinkedList *other){
    // add all second list to back of first list
    for(int i = 0; i < other->lsize; i++) {
        pushAtBack(other->elementAt(i));
    }
}

/*
 *  CharLinkedList.cpp
 *  Soofia Valdebenito
 *  2/7/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  This file contains an implementation of the 
 *  CharLinkedList class. There is a memory bug which
    has prevented me from utilizing the unit tests I have
    for the rest of my functions that I did not finish
    implementing. 
 *
 */

#include "CharLinkedList.h"
#include <sstream>
#include <iostream>
#include <string>

using namespace std;

/*
 * name:      CharLinkedList default constructor
 * purpose:   initialize an empty charLinkedList
 * arguments: none
 * returns:   none
 * effects:   LL to 0.
 */
CharLinkedList::CharLinkedList() {
    Node *front = nullptr;
    Node *back = nullptr;
}

/*
 * name:      new node helper function
 * purpose:   creates a new node on the heap
 * arguments: char newData, Node *next
 * returns:   newNode
 * effects:   LL increases.
 */
//helper function that will create a new node on the heap with
// data newData and next node as given next. Recognize that the 
//return type needs scope resolution operator "::" to know that
//Node comes from the CharLinkedList class. The parameter does not!
CharLinkedList::Node *CharLinkedList::newNode(char newData, Node *next) {
    Node *newNode = new Node;
    newNode->data = newData;
    newNode->next = next;

    return newNode;
}

/*
 * name:      CharLinkedList second constructor
 * purpose:   takes in a single character as a parameter and creates
 *            one node LL containing that char.
 * arguments: none
 * returns:   none
 * effects:   LL with one node is created.
 */
CharLinkedList::CharLinkedList(char c) {
    Node *newNode = new Node;
    front = newNode;
    back = newNode;

}

/*
 * name:      CharLinkedList third constructor
 * purpose:   takes in a int size and array size as
              a parameters and creates a LL
 *             containing the char list of that size.
 * arguments: none
 * returns:   none
 * effects:   LL with multiple nodes is created.
 */
CharLinkedList::CharLinkedList(char arr[], int size) {}


/*
 * name: CharLinkedList(const CharLinkedList &other)
 * purpose: copy constructor
 * arguments: none
 * returns:  none
 * effects:  makes a shallow copy of CharLinkedList from scratch
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other) {}

/*
 * name: destructor
 * purpose: deletes pre-exising data
 * arguments: none
 * returns:  none
 * effects:  makes sure no memory is leaked.
 */
CharLinkedList::~CharLinkedList() {
    recycleRecursive(front);
}

/*
 * name: destructor helper function
 * purpose: recursive function that recycles memory
 * arguments: *currNode
 * returns:  none
 * effects:  makes sure no memory is leaked.
 */
void CharLinkedList::recycleRecursive(Node *currNode) {
    if (currNode == nullptr) {
        return;
    }
    else {
        Node *next = currNode->next;
        Node *prev = currNode->prev;
        delete currNode;
        recycleRecursive(next);
    }
}


/*
 * name: &CharLinkedList::operator=(const CharLinkedList &other)
 * purpose: overload assignment operator.
 * arguments: none
 * returns:  none
 * effects:  makes a deep copy of CharLinkedList from existing list.
 */
CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other) {
    if (this == &other) {
        return *this;
    }
   Node *otherCurrent = other.front;
    while (otherCurrent != nullptr) {
        Node *newNode = new Node;
        if (front == nullptr) {
            front = newNode;
            back = newNode;
        } else {
            back->next = newNode;
            newNode->prev = back;
            back = newNode;
        }
        otherCurrent = otherCurrent->next;
    }
    return *this;
}

/*
 * name:      isEmpty() const
 * purpose:   determine whether the LL is empty or not.
 * arguments: none
 * returns:   true or false statement if LL is 0.
 * effects:   none
 */
bool CharLinkedList::isEmpty() const {
    if (front == nullptr and 
    back == nullptr) {
        return true;
    }
    return false;
}

/*
 * name:      clear()
 * purpose:   empties linked list
 * arguments: none
 * returns:   none
 * effects:   LL list of any size is reduced to 0
 */
void CharLinkedList::clear() {
    Node *currNode = front;
    while (currNode != nullptr) {
        Node *next = currNode->next;
        delete currNode;
        currNode = next;
    }
    front = nullptr;
    back = nullptr;
}

/*
 * name:      size()
 * purpose:   determine the number of items in the LinkedList
 * arguments: none
 * returns:   number of elements currently stored in the LinkedList (int)
 * effects:   none
 */
int CharLinkedList::size() const {
    return currSize;
 // this below was my other method  
    // int currSize = 0;
    // Node *currNode = front; 
    // while (currNode != nullptr) { 
    //    currSize++; 
    //    currNode = currNode->next; 
    // } 
    // return currSize; 
}

/*
 * name:      first
 * purpose:   retrieves first element
 * arguments: none
 * returns:   a char (element)
 * effects:   none
 */
char CharLinkedList::first() const {
    if (isEmpty()) {
        throw std::runtime_error("cannot get first of empty LinkedList");
    }
    return front->data;
}

/*
 * name:      last
 * purpose:   retrieves last element
 * arguments: none
 * returns:   a char (element)
 * effects:   none
 */
char CharLinkedList::last() const {
    if (isEmpty()) {
        throw std::runtime_error("cannot get last of empty LinkedList");
    }
    return back->data; 
}

/*
 * name:      elementAt
 * purpose:   determine the number of items in the LinkedList
 * arguments: int index (position of LL)
 * returns:   a char (element)
 * effects:   makes LL bigger
 */
char CharLinkedList::elementAt(int index) const {
      if (isEmpty()) { 
    throw std::range_error("index (" + to_string(index) +
   ") not in range [0.." + to_string(currSize) + ")");
      }
    return currNode->data;
}

/*
 * name:      toString
 * purpose:   creates a string of the LL
 * arguments: none
 * returns:   string
 * effects:   LL is a string
 */
string CharLinkedList::toString() const {
    std::stringstream ss;
    ss << "[CharLinkedList of size " << size() << " <<";
    for(int i = 0; i < size(); i++) {
        ss << elementAt(i);
    }
    ss << ">>]";
    return ss.str();
}

/*
 * name:      toReverseString
 * purpose:   reverses LL order and makes it a string
 * arguments: none
 * returns:   string 
 * effects:   reverses order
 */
string CharLinkedList::toReverseString() const {}

/*
 * name:      pushAtBack
 * purpose:   puts char in LL at the back
 * arguments: char c (element being put in)
 * returns:   none
 * effects:   none
 */
void CharLinkedList::pushAtBack(char c) {}

/*
 * name:      pushAtFront
 * purpose:   puts char in LL at the front
 * arguments: char c (element being put in)
 * returns:   none
 * effects:   makes LL longer
 */
void CharLinkedList::pushAtFront(char c) {}

/*
 * name:      insertAt
 * purpose:   insert an element into an LL
 * arguments: char c (element being put in), int index (position of LL)
 * returns:   none
 * effects:   makes LL longer
 */
void CharLinkedList::insertAt(char c, int index) {}

/*
 * name:      insertInOrder
 * purpose:   inserts an element in ASCII order
 * arguments: char c (element client wants to insert)
 * returns:   none
 * effects:   makes LL longer
 */
void CharLinkedList::insertInOrder(char c) {}

/*
 * name:      popFromFront
 * purpose:   deletes element from front of LL
 * arguments: none
 * returns:   none
 * effects:   makes LL shorter
 */
void CharLinkedList::popFromFront() {}

/*
 * name:      popFromBack
 * purpose:   deletes element from back of LL
 * arguments: none
 * returns:   none
 * effects:   makes LL shorter
 */
void CharLinkedList::popFromBack() {}

/*
 * name:      removeAt
 * purpose:   removes element at client chosen index of LL.
 * arguments: int index (position of LL)
 * returns:   none
 * effects:   makes LL shorter
 */
void CharLinkedList::removeAt(int index) {}

/*
 * name:      replaceAt
 * purpose:   replaces element at client chosen index of LL.
 * arguments: char c (element being put in), int index (position of LL)
 * returns:   none
 * effects:   none
 */
void CharLinkedList::replaceAt(char c, int index) {}

/*
 * name:      concatenate
 * purpose:   concatenates connects two linked lists.
 * arguments: *other, obtains the address of the another list
 to add to the end of a linked list.
 * returns:   none
 * effects:   array list is longer by currSize of first array list
 + currSize of second array list.
 */
void CharLinkedList::concatenate(CharLinkedList *other) {}


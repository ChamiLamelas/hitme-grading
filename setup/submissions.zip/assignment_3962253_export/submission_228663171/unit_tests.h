/*
 *  unit_tests.h
 *  YOUR NAME HERE
 *  DATE CREATED
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  This file uses the implementations from the .cpp file
 *  to test the framework of them.
 *
 */

#include "CharLinkedList.h"
#include <cassert>
#include <string>

// Test default constructor and isEmpty
void CurrSizeIsZero() {
    CharLinkedList test_list;
    assert(test_list.size() == 0);
    assert(test_list.isEmpty());
}

//2nd constructor test. checking if Linkedlist has
// a capacity of 1
void singleCharCheck() {
    CharLinkedList test_list('a');
    assert(test_list.size() == 1);
}

//3rd constructor; tests if Linkedlist has a capacity >1.
void LinkedCharCheck() {
    char test_arr[5] = { 's', 'o', 'f', 'i', 'a' };
    CharLinkedList test_list(test_arr, 5);
    assert(test_list.size() == 5);
}

//copy constructor unit test
void copyTestMultipleElt() {
    char test_arr[5] = { 's', 'o', 'f', 'i', 'a' };
    CharLinkedList test1(test_arr, 5);
    CharLinkedList test2(test1);
    assert(test1.size() == test2.size());
}

void copyTestEmptyArr() {
    CharLinkedList test1(0);
    CharLinkedList test2(test1);
    assert(test1.size() == test2.size());
}

void copyTestOneElt() {
    CharLinkedList test1(1);
    CharLinkedList test2(test1);
    assert(test1.size() == test2.size());
}

// asserting that the deep copy works
void assignmentTestMultipleElt() {
    char test_arr[5] = { 's', 'o', 'f', 'i', 'a' };
    CharLinkedList test1(test_arr, 5);
    char test_arr2[6] = { 's', 'o', 'f', 'i', 'a', 'e'};
    CharLinkedList test2(test_arr2, 6);
    test1 = test2;
    assert(test1.size() == test2.size());
}

//asserting if the right hand side is copied
void assignmentEmptyTest() {
    char test_arr[5] = { 's', 'o', 'f', 'i', 'a' };
    CharLinkedList test1(test_arr, 5);
    char test_arr2[0] = { };
    CharLinkedList test2(test_arr2, 0);
    test1 = test2;
    assert(test1.size() == test2.size());
}

//asserting if the size changes from a big linked list to a small one
void assignmentOneElt() {
    char test_arr[5] = { 's', 'o', 'f', 'i', 'a' };
    CharLinkedList test1(test_arr, 5);
    char test_arr2[1] = {'s'};
    CharLinkedList test2(test_arr2, 1);
    test1 = test2;
    assert(test1.size() == test2.size());
}

//checks if element selection matches for
// two different strings of the same linked list
//also tests elementAt into middle of a large linked list
void matchingElements() {
    char test_arr[5] = { 's', 'o', 'f', 'i', 'a' };
    CharLinkedList test1(test_arr, 5);
    char test_arr2[5] = {'s', 'o', 'f', 'i', 'a' };
    CharLinkedList test2(test_arr2, 5);
    assert(test1.elementAt(2) == test2.elementAt(2));
}

//checks if element selection matches for
// two different strings of different linked list
void matchingElementsForDiffLinkedLists() {
    char test_arr[5] = { 's', 'o', 'f', 'i', 'a' };
    CharLinkedList test1(test_arr, 5);
    char test_arr2[4] = {'f', 'n', 'a', 'f' };
    CharLinkedList test2(test_arr2, 4);
    assert(test1.elementAt(2) == test2.elementAt(3));
}

//checks if elements do not match from the same linked list
void notMatchingElements() {
    char test_arr[5] = { 's', 'o', 'f', 'i', 'a' };
    CharLinkedList test1(test_arr, 5);
    char test_arr2[5] = {'s', 'o', 'f', 'i', 'a' };
    CharLinkedList test2(test_arr2, 5);
    assert(test1.elementAt(4) != test2.elementAt(2));
}

// out of range test for empty linked list
void emptyLinkedElementTest() {
    
    bool rangeErrorThrown = false;

    std::string error_message = "";

    CharLinkedList test_list;

    try {
        test_list.elementAt(20);
    }
    catch (const std::range_error &e) {
        rangeErrorThrown = true;
        error_message = e.what();
    }
    
    assert(rangeErrorThrown);
    assert(error_message == "index (20) not in range [0..0)");
}

// Tests out of range insertion for a non-empty list.
//bug here
void incorrectMultElementAt() {
   
    CharLinkedList test_list(8);

    bool rangeErrorThrown = false;

    std::string error_message = "";

    try {
        test_list.elementAt(93);
    }
    catch (const std::range_error &e) {
        rangeErrorThrown = true;
        error_message = e.what();
    } 
    assert(rangeErrorThrown);
    assert(error_message == "index (93) not in range [0..8)");
}

// Tests correct ElementAt for 1-element list.
void elementAtFrontSingletonList() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // element selection
    test_list.elementAt(0);

    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');
}

//elementAt in front of list
void elementAtFrontMultList() {
   char test_arr[5] = {'s', 'o', 'f', 'i', 'a' };
    CharLinkedList test(5);
    assert(test.elementAt(0));
}

//elementAt in back of list
//bug here
void elementAtBackMultList() {
   char test_arr[5] = {'s', 'o', 'f', 'i', 'a' };
    CharLinkedList test(5);
    assert(test.elementAt(4));
}

// Tests correct insertion into an empty AL.
// Afterwards, size should be 1 and element at index 0
// should be the element we inserted.
void insertAt_empty_correct() { 

    CharLinkedList test_list;
    test_list.insertAt('a', 0);
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');
}

// Tests incorrect insertion into an empty AL.
// Attempts to call insertAt for index larger than 0.
// This should result in an std::range_error being raised.
void insertAt_empty_incorrect() {

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    // insertAt for out-of-range index
    test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
    // if insertAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    range_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0]");
    
}

// Tests correct insertAt for front of 1-element list.
void insertAt_front_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at front
    test_list.insertAt('b', 0);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'a');
    
}

// Tests correct insertAt for back of 1-element list.
void insertAt_back_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at back
    test_list.insertAt('b', 1);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    
}

// Tests reverse string
//there is a bug here but I can't seem to find it 
void multEltReverse() {
    char test_arr[3] = { 'c', 'a', 't' };
    CharLinkedList test_list(test_arr, 3);
    assert(test_list.toReverseString() ==
    "[CharLinkedList of size 3 <<tab>>>]");
}
// Tests calling insertAt for a large number of elements.
// Not only does this test insertAt, it also checks that
// linked list expansion works correctly.
void insertAt_many_elements() {
    
    CharLinkedList test_list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.insertAt('a', i);
    }

    assert(test_list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
    
}

// Tests insertion into front of a larger list
void insertAt_front_large_list() {
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    test_list.insertAt('y', 0);

    assert(test_list.size() == 10);
    assert(test_list.elementAt(0) == 'y');
    assert(test_list.toString() == 
    "[CharLinkedList of size 10 <<yabczdefgh>>]");

}

// Tests insertion into the back of a larger list
void insertAt_back_large_list() {

    char test_arr[10] = { 'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 10);  

    test_list.insertAt('x', 10);

    assert(test_list.size() == 11);
    assert(test_list.elementAt(10) == 'x');
    assert(test_list.toString() == 
    "[CharLinkedList of size 11 <<yabczdefghx>>]"); 

}

// Tests insertion into the middle of a larger list
void insertAt_middle_large_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.insertAt('z', 3);

    assert(test_list.size() == 9);
    assert(test_list.elementAt(3) == 'z');
    assert(test_list.toString() == 
    "[CharLinkedList of size 9 <<abczdefgh>>]");

}

// Tests out-of-range insertion for a non-empty list.
void insertAt_nonempty_incorrect() {
   
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8]");
    
}

//verifies that linked list size doesn't change
void clearsEmptyLinkedList() {
    char test_arr[0] = { };
    CharLinkedList test_list(test_arr, 0);
    test_list.clear();
    assert(test_list.isEmpty());

}

//verifies that one element linked list is cleared
void clearsOneEltLinked() {
    char test_arr[1] = { 't' };
    CharLinkedList test_list(test_arr, 1);
    test_list.clear();
    assert(test_list.isEmpty());

}

//verifies that mult elt arrray is cleared
void clearsMultEltLinked() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);
    test_list.clear();
    assert(test_list.isEmpty());
}

//tests incorrect use of first command (empty linked list)
void emptyFirstLinked() {
    bool rangeErrorThrown = false;
    
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    test_list.first();
    }
    catch (const std::runtime_error &e) {
        rangeErrorThrown = true;
        error_message = e.what();
    }
    assert(rangeErrorThrown);
    assert(error_message == "cannot get first of empty LinkedList");
}

//tests incorrect use of last command (empty linked list)
void emptyLastLinked() {
    bool rangeErrorThrown = false;
    
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    test_list.last();
    }
    catch (const std::runtime_error &e) {
        rangeErrorThrown = true;
        error_message = e.what();
    }
    assert(rangeErrorThrown);
    assert(error_message == "cannot get last of empty LinkedList");
}

//tests pushAtBack on empty linked list
void emptyPushAtBackLinkedList() {
    char test_arr[0] = { };
    CharLinkedList test_list(test_arr, 0);
    test_list.pushAtBack('z');

    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'z');
    assert(test_list.toString() == 
    "[CharLinkedList of size 1 <<z>>]"); 
}

//tests pushAtFront on empty list
void emptyPushAtFrontLinkedList() {
    char test_arr[0] = { };
    CharLinkedList test_list(test_arr, 0);
    test_list.pushAtBack('q');

    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'q');
    assert(test_list.toString() == 
    "[CharLinkedList of size 1 <<q>>]"); 
}

//tests insertInOrder in big linked 
void inOrderMultEltLinkedList () {
    char test_arr[7] = { 'a', 'b', 'c', 'd', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 7);
    test_list.insertInOrder('e');
    assert(test_list.size() == 8);
    assert(test_list.toString() == 
    "[CharLinkedList of size 8 <<abcdefgh>>]"); 
}

//tests removeAt in big linked
void removeAtMultEltLinked () {
    char test_arr[5] = { 's', 'o', 'f', 'i', 'a' };
    CharLinkedList test_list(test_arr, 5);
    test_list.removeAt(3);
    assert(test_list.size() == 4);
    assert(test_list.toString() == 
    "[CharLinkedList of size 4 <<sofa>>]");
    
}

//tests empty Linked for popfromfront
void emptyPopFromFrontLinkedList() {
    bool rangeErrorThrown = false;
    
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    test_list.popFromFront();
    }
    catch (const std::runtime_error &e) {
        rangeErrorThrown = true;
        error_message = e.what();
    }
    assert(rangeErrorThrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

//tests empty Linked for popfromback
void emptyPopFromBackLinkedList() {
    bool rangeErrorThrown = false;
    
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    test_list.popFromBack();
    }
    catch (const std::runtime_error &e) {
        rangeErrorThrown = true;
        error_message = e.what();
    }
    assert(rangeErrorThrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

//tests empty Linked out-of-range replacing
void emptyLinkedReplaceAt() {

    bool range_error_thrown = false;

    std::string error_message = "";

    CharLinkedList test_list;
    try {
    test_list.replaceAt('k', 43);
    }
    catch (const std::range_error &e) {
    range_error_thrown = true;
    error_message = e.what();
    }

   assert(range_error_thrown);
   assert(error_message == "index (43) not in range [0..0)");
}

//testing two different tests
void concatenatingTwoDiffTests() {
    char test_arr[4] = { 's', 'n', 'o', 'w' };
    CharLinkedList test1(test_arr, 4);
    char test_arr2[3] = { 'm', 'a', 'n' };
    CharLinkedList test2(test_arr2, 3);
    test1.concatenate(&test2);
}

//testing two different tests (one with empty linked list)
void concatenatingEmptyTest() {
    char test_arr[4] = { 's', 'n', 'o', 'w' };
    CharLinkedList test1(test_arr, 4);
    char test_arr2[0] = { };
    CharLinkedList test2(test_arr2, 0);
    test1.concatenate(&test2);
}

//concatenating the Linked list itself
void concatenatingSingleTest() {
    char test_arr[4] = { 's', 'n', 'o', 'w' };
    CharLinkedList test1(test_arr, 4);
    test1.concatenate(&test1);
}

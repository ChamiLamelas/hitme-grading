/*
 *  CharLinkedList.h
 *  Carly Cohen
 *  1/31/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 * Program purpose:
 * This is an interface file that contains the functions for the 
 * CharLinkedList Class. 
 * You can use these functions to add characters at the front, back and
 * middle of lists. You can erase and and insert at any index as well as in 
 * order and you can print in reverse as well as in the correct order. Needs
 * are best met by this class for inserting and removing at the beginning and 
 * end of the list because you can easily rearrange the pointers in the list. 
 *
 */

#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H
#include <string>

class CharLinkedList {
    public:
        CharLinkedList();
        CharLinkedList(char c);
        CharLinkedList(char arr[], int size);
        CharLinkedList(const CharLinkedList &other);
        CharLinkedList &operator=(const CharLinkedList &other);
        ~CharLinkedList();
        void pushAtFront(char c);
        void pushAtBack(char c);
        std::string toString() const;
        int size() const;
        bool isEmpty() const;
        void clear();
        char first() const;
        char last() const;
        char elementAt(int index) const;
        std::string toReverseString() const;
        void insertAt(char c, int index);
        void insertInOrder(char c);
        void popFromFront();
        void popFromBack();
        void removeAt(int index);
        void replaceAt(char c, int index);
        void concatenate(CharLinkedList *other);

    private:
        struct Node{
            char info;
            Node *next;
            Node *previous;
        };

        Node *front;
        Node *back;
        int numItems;
       
        Node *create_node(char c, Node *previous, Node *next);
        void help_destruct(Node *node);
        void help_replace(Node *curr, int counter, int index, char c);
        Node *elementAt_helper(Node *curr, int index, int counter) const;
        void reserve_more();
        void help_remove(int index);
        
};

#endif
/*
 *  CharLinkedList.cpp
 *  Carly Cohen
 *  1/31/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 * Program Purpose:
 * This file contains an implementation of the CharLinkedList class.
 * This list is implemented using a linked list, and therefore makes it
 * easy to replace individual elements, especially at the front or back of 
 * the list
 *
 */

#include "CharLinkedList.h"
#include <sstream>
#include <string>
#include <iostream>

using namespace std;


/* name: CharLinkedList
 * Purpose: initialize an empty linked list
 * arguments: none
 * returns: None
 */
CharLinkedList::CharLinkedList() {
    front = nullptr;
    numItems= 0;
    back = nullptr;
}

/* name: CharLinkedList
 * Purpose: initialize an linked list with one char
 * arguments: a char to put in the list
 * returns: None
 */
CharLinkedList::CharLinkedList(char c){
    Node *new_node;
    new_node = create_node(c, nullptr, nullptr);
    front = new_node;
    back = new_node;
    numItems = 1;
}

/* name: CharLinkedList
 * Purpose: initialize a linked list with multiple chars
 * arguments: an linked list of chars and a size of the linked list
 * returns: None
 */
CharLinkedList::CharLinkedList(char arr[], int size){
    numItems = 0;
    front = nullptr;
    back = nullptr;
    for (int i = 0; i < size; i++){
        pushAtBack(arr[i]);
    }
}

/* name: CharLinkedList
 * Purpose: make a deep copy of a linked list
 * arguments: address of list you want to copy
 * returns: None
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other){
    numItems = 0;
    front = nullptr;
    back = nullptr;
    Node *curr;
    curr = other.front;
    //read in info from other list
    while (curr != nullptr){
        pushAtBack(curr->info);
        curr = curr->next;
    } 
}

/* name: Char linked list destructor
 * Purpose: Free heap-allocated memory of 'this'
 * arguments: none
 * returns: None
 * effects: deletes memory that was allocated for the linked list
 */
CharLinkedList::~CharLinkedList() {
    help_destruct(front);
}

/* name: help_destructor
 * Purpose: delete each node in a recursive manner
 * arguments: a front node to delete it's list
 * returns: None
 * effects: deletes memory that was allocated for the linked list
 */
void CharLinkedList::help_destruct(Node *node){
    if (node == nullptr){
        return;
    }
    help_destruct(node->next);
    delete node;
}

/*
 * name: &operator
 * purpose: define an operator that takes the deletes the list on the left
 * and puts the list on the right into it
 * arguments: address of new linked list
 * returns: address of new linked list
 * effects: recycles memory of left and puts right into it
 */
CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other){
    if (this == &other){
        return *this;
    }
    clear();
    Node *curr;
    curr = other.front;
    //read in info from other list
    while (curr != nullptr){
        pushAtBack(curr->info);
        curr = curr->next;
    } 
    return *this;
}

/* name: size
 * Purpose: return the size of a linked list
 * arguments: none
 * returns: the size of the list in an int
 */
int CharLinkedList::size() const{
    return numItems;
}

/*
 * name:      clear
 * purpose:   sets linkedlist to have nothing in it
 * arguments: none
 * returns:   none
 * effects:   deletes everything in the list
 */
void CharLinkedList::clear() {
    help_destruct(front);
    numItems = 0;
    front = nullptr;
    back = nullptr;
}

/* name: create_node
 * Purpose: create a new node
 * arguments: the info as a char, a pointer to previous and next nodes
 * returns: None
 * effects: creates a new node
 */
CharLinkedList::Node *CharLinkedList::
create_node(char c, Node *previous, Node *next){
    Node *new_node = new Node();
    new_node->info = c;
    new_node->next = next;
    new_node->previous = previous;
    return new_node;
}

/* name: toString
 * Purpose: Report the state of the list as a string
 * arguments: none
 * returns: a string saying the size and contents of the list
 * effects: makes a string with the sstate of the list
 */
std::string CharLinkedList::toString() const {
    std::stringstream ss;
    ss << "[CharLinkedList of size " << numItems;
    ss << " <<" ;
    Node *curr = front;
    while (curr != nullptr) {
        ss << curr->info;
        curr = curr->next;
    }
    ss << ">>]";

    return ss.str();
}

/*
 * name:      toReverseString
 * purpose:   turns the linked list into a string of the 
 * elements in reverse order
 * arguments: none
 * returns:   a string of the elements in the reverse order
 * effects:   none
 */
std::string CharLinkedList:: toReverseString() const{
    std::stringstream ss;
    ss << "[CharLinkedList of size " << numItems;
    ss << " <<" ;
    Node *curr = back;
    while (curr != nullptr) {
        ss << curr->info;
        curr = curr->previous;
    }
    ss << ">>]";

    return ss.str();
}


/* 
 * pushAtFront
 * Purpose: Adds a char to the front of the list
 * Arguments: a char to add to the front
 * Returns: None
 */
void CharLinkedList::pushAtFront(char c) {
    //if list is empty, create a new node
    if (numItems == 0){
        Node *new_node = create_node(c, nullptr, nullptr);
        front = new_node;
        back = new_node;
        numItems = 1;
    } 

    //if list is not empty, set a new front
    else {
        Node *new_node = create_node(c, nullptr, front);
        front->previous = new_node;
        new_node->next = front;
        front = new_node;
        numItems++;
    }
}

/*
 * pushAtBack
 * Purpose: Adds a char to the back of the list
 * Parameters: The char to be added to the list
 * Returns: None
 */
void CharLinkedList::pushAtBack(char c) {
    //if list is empty, create a new linked list
    if (numItems == 0){
        Node *new_node;
        new_node = create_node(c, nullptr, nullptr);
        front = new_node;
        back = new_node;
        numItems = 1;
        return;
    } 
    //if list is not empty, set a new back
    else{ 
        Node *new_node;;
        new_node = create_node(c, back, nullptr);
        back->next = new_node;
        new_node->previous = back;
        back = new_node;
        numItems++;
    }
}

/* name: isEmpty
 * Purpose: Report if a list is empty or not
 * arguments: none
 * returns: a boolean value stating if the list is empty or not
 * effects: checks if a list is empty
 */
bool CharLinkedList::isEmpty() const {
    if (numItems == 0){
        return true;
    }
    return false;
}

/* name: first
 * Purpose: get the first element in the list
 * arguments: none
 * returns: the first char in the list
 */
char CharLinkedList::first() const{
    if (numItems == 0){
        throw runtime_error("cannot get first of empty LinkedList");
    }
    else{
        return front->info;
    }
}

/*
 * name:      last
 * purpose:   return last element in linked list
 * arguments: none
 * returns:   last element in linked list
 * effects:   none
 */
char CharLinkedList::last() const {
    if (numItems == 0){
        throw runtime_error("cannot get last of empty LinkedList");
    }
    else{
        return back->info;
    }
}

/*
 * name: elementAt
 * purpose:   return requested element in the linkedlist
 * arguments: index of requested element
 * returns:   requested element
 * effects:   none
*/
char CharLinkedList:: elementAt(int index) const {
    if (index > numItems - 1 or index < 0){
        throw range_error("index (" + to_string(index)+ 
        ") not in range [0.." + to_string(numItems) + ")");
    }
    int counter = 0;
    Node *curr = front;
    return elementAt_helper(curr, index, counter)-> info;
    
}

/*
 * name: elementAt_helper
 * purpose:   return a pointer to the node at requested spot in the linkedlist
 * arguments: Node that starts at front, index of requested element, counter to
 * track spot in list
 * returns:   pointer to node at requested element
 * effects:   none
*/
CharLinkedList::Node* CharLinkedList::
elementAt_helper(Node *curr, int index, int counter) const{
    if (counter == index){
        return curr;
    }
    counter++;
    return elementAt_helper(curr->next, index, counter);
}

/*
 * name:  insertAt
 * purpose:  insert a new element into the linked list
 * arguments: an element and the index to insert it at
 * returns:   none
 * effects:   inserts a new element at desired index
 */
void CharLinkedList::insertAt(char c, int index){
    //if it's out of range throw a range error
    if (index > numItems or index < 0){
        throw range_error ("index (" + to_string(index) +  
        ") not in range [0.." + to_string(numItems) + "]");
    }
    //if putting the node at the front or back, use those functions
    if (index == 0){
        pushAtFront(c);
        return;
    }
    if (index == numItems){
        pushAtBack(c);
        return;
    }
    //otherwise, make a node and an index to keep track of the element
    Node *curr = front;
    int curr_index = 0;
    //loop through until curr is the node before the index we're inserting at 
    while(curr_index < index -1){
        curr = curr->next;
        curr_index++;
    }
    //create that new node and put it in the list
    curr->next = create_node(c, curr, curr->next);
    numItems++;
}

/*
 * name:  insertInOrder
 * purpose: insert a new element into the linked list in ASCII order
 * arguments: an element to insert into the linked list
 * returns: none
 */
void CharLinkedList::insertInOrder(char c){
    //if it's an empty list insert it
    if (numItems == 0){
        pushAtFront(c);
        return;
    }
    //if it's less than the first element, insert it at beginning
    if (c <= front->info){
        pushAtFront(c);
        return;
    } 
    Node *curr = front;
    bool inserted = false;
    int index = -1;
    //check the char against the chars in each node and insert appropriately
    while (curr != nullptr){
        //use the index variable to keep track of what node you're on
        index++;
        if (c <= curr->info){
            insertAt(c, index);
            inserted = true;
            return;
        }
        curr = curr->next;
    }
    //if variable goes at back of list push it to the back
    if (not inserted and c > back->info){
        pushAtBack(c);
    }
}

/*
 * name:  popFromFront
 * purpose:  remove the first element from the linked list
 * arguments: none
 * returns:   none
 */
void CharLinkedList::popFromFront(){
    //if list is empty, throw error
    if (numItems == 0){
        throw runtime_error ("cannot pop from empty LinkedList");
    }
    help_remove(0);
}

/*
 * name: popFromBack
 * purpose:  remove the last element from the linked list
 * arguments: none
 * returns:   none
 */
void CharLinkedList::popFromBack(){
    //if list is empty, throw error
    if (numItems == 0){
        throw runtime_error ("cannot pop from empty LinkedList");
    }

    if(numItems == 1){
        clear();
        return;
    }
    Node *new_back = back->previous;
    delete back;
    back = new_back;
    back->next = nullptr;
    numItems--;
}

/*
 * name: removeAt
 * purpose:  catches the out of range and front and back cases for removing
 * an element
 * arguments: an index to remove an element at
 * returns:   none
 * effects: throws error messages or removes element from requested index
 */
void CharLinkedList::removeAt(int index){
    //if list is empty do range error
    if (numItems == 0){
        throw range_error ("index (" + to_string(index) +  
        ") not in range [0..0)");
    }
    //if it's out of range throw a range error
    if (index >= numItems or index < 0){
        throw range_error ("index (" + to_string(index) +  
        ") not in range [0.." + to_string(numItems) + ")");
    }
    //if they are removing from back, call popFromBack
    if (index == numItems - 1){
        popFromBack();
        return;
    }
    help_remove(index);
}

/*
 * name: help_remove
 * purpose:  remove an element from a requested index
 * arguments: an index to remove an element at
 * returns:   none
 * effects:   removes an element at desired index
 */
void CharLinkedList:: help_remove(int index){
    //make a new node called curr and set it to the front
    Node *curr = front;
    int curr_index = 0; 
    //remove the first element
    if (index == 0){
        Node *new_front = front->next;
        delete front;
        front = new_front;
        numItems--;
        return;
    }
    //loop through until curr is the node before the index we're deleting at
    while(curr_index < index - 1){
        curr = curr->next;
        curr_index++;
    }

    //set the node before it to point to new node and point that new node to 
    //the old curr's next
    Node *new_next = curr->next->next;
    delete curr->next;
    curr->next = new_next;
    new_next->previous = curr;
    numItems--;
}


/*
 * name:  replaceAt
 * purpose:  replace an element in the linked list with a new element
 * arguments: an element and the index to replace the element at
 * returns:   none
 * effects:   replaces an element with a new one at desired index
 */
void CharLinkedList::replaceAt(char c, int index){
    //if there are 0 tems throw a range error
    if (numItems == 0){
        throw range_error ("index (" + to_string(index) +
        ") not in range [0..0)");
    }
    //if it's out of range throw a range error
    if (index >= numItems or index < 0){
        throw range_error ("index (" + to_string(index) +
        ") not in range [0.." + to_string(numItems) + ")");
    }
    int counter = 0;
    Node *curr = front;
    help_replace(curr, counter, index, c);
}

/*
 * name: help_replace
 * purpose:  replace an element in the linked list with a new element
 * arguments: a node pointing to the front of the list,
 *   an int to count the index, the index to replace the element at, the
 *   element to insert
 * returns:   none
 * effects:   replaces an element with a new one at desired index
 */
void CharLinkedList::help_replace(Node *curr, int counter, int index, char c){
    //if you're at the right index, replace the element and return
    if (counter == index){
        curr->info = c;
        return;
    }
    (counter)++;
    help_replace(curr->next, counter, index, c);
}


/*
 * name:  concatenate
 * purpose:  combine two char linked lists
 * arguments: a pointer to another linked list
 * returns:   none
 * effects:   adds a copy of the linked list to the end of the linked list
 */
void CharLinkedList::concatenate(CharLinkedList *other){
    //if it's concatenating itself, use copy constructor and pushAtBack
    if (other == this){
        CharLinkedList new_list(*other);
        Node *curr = new_list.front;
        int counter = 0;
        while (counter < new_list.size()){
            pushAtBack(new_list.elementAt(counter));
            counter++;
        }
        return;    
    }
    //if it's not pointing to itself, push the other elements onto the back
    Node *curr = other->front;
    int counter = 0;
    while (counter < other->size()){
        pushAtBack(other->elementAt(counter));
        counter++;
    }
}


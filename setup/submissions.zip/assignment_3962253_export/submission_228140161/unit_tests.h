/*
 *  unit_tests.h
 *  Carly Cohen
 *  1/31/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 * Program Purpose: 
 * This file is used to test various functions for the CharLinkedList class
 *
 */
 #include <iostream>
 #include <cassert>
 #include "CharLinkedList.h"
 #include <string>


/*
 * constructor test 0
 * Make sure no fatal errors/memory leaks in the default constructor
 */
void charlinkedlist_constructor_test0() {
    CharLinkedList list;
    assert(list.size() == 0);
}

/*
* constructor test 2
* Make a list that has one character in it
*/
void constructor_test_1(){
    CharLinkedList list('c');
    assert(list.size() == 1);
    assert(list.toString() == "[CharLinkedList of size 1 <<c>>]" );
    assert(list.first() == 'c');
    assert(list.last() == 'c');
}

/*
* constructor with linked list test
* test a constructor that takes in a linked list
*/
void constructor_greaterthan1_test(){
    char test_arr[3] = {'a', 'b', 'c'};
    CharLinkedList list(test_arr, 3);
    assert(list.size() == 3);
    assert(list.toString() == "[CharLinkedList of size 3 <<abc>>]");
    assert(list.first() == 'a');
    assert(list.last() == 'c');
}

/*
* constructor with empty linked list test
* test a constructor that takes in an empty linked list
*/
void constructor_emptylinkedlist(){
    char test_arr[0];
    CharLinkedList list(test_arr, 0);
    assert(list.size() == 0);
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]" );
}


/*
*copy constructor test
make a list, then copy the contentst of that list into another list called 
"copy"
*/
void copy_constructor_test(){
    char test_arr[2] = {'y', 'z'};
    CharLinkedList list(test_arr, 2);
    CharLinkedList listcopy(list);
    assert(listcopy.toString() == "[CharLinkedList of size 2 <<yz>>]");
}

/*
* copy an empty list
*/
void copy_constructor_empty(){
    CharLinkedList list1;
    CharLinkedList list1copy(list1);
    assert(list1copy.toString() == "[CharLinkedList of size 0 <<>>]");
}

/*
*assignment operator test
*make 2 linked lists, then move the contents from list 2 into list 1
*/
void assignment_operator_test(){

    char test_arr1[2] = {'x', 'y'};
    CharLinkedList list1(test_arr1, 2);
    char test_arr2[2] = {'a', 'b'};
    CharLinkedList list2(test_arr2, 2);
    list1 = list2;
    assert(list1.first() == 'a');
    assert(list1.last() == 'b');

}

/*
* test the transfer with lists of different sizes and changing one but not 
* the other
*/
void transferr_linkedlist_test1(){

    char test_arr1[2] = {'x', 'y'};
    CharLinkedList list1(test_arr1, 2);
    char test_arr2[4] = {'a', 'b', 'c', 'd'};
    CharLinkedList list2(test_arr2, 4);
    list1 = list2;
    assert(list1.size() == 4);
    assert(list1.first() == 'a');
    list2.pushAtBack('w');
    //assert that making a change to the original won't change the deep copy
    assert(list1.last() == 'd');

}

/*
 * isEmpty test
 * Make an empty list and test that it's empty
 */
void isEmpty_test1() {
    CharLinkedList list;
    assert(list.isEmpty());
}

/*
* make a list with one variable and test that it's not empty
*/
void isEmpty_test2() {
    CharLinkedList list('c');
    assert(not list.isEmpty());
}

/*
* to string of size 1 test
*/
void tostring_many_test(){
    char test_arr[2] = {'y', 'z'};
    CharLinkedList list(test_arr, 2);
    assert(list.size() == 2);
    assert(list.toString() == "[CharLinkedList of size 2 <<yz>>]" );
}

/*
*to string more than one
*/
void tostring_one_test(){
    CharLinkedList list('c');
    assert(list.size() == 1);
    assert(list.toString() == "[CharLinkedList of size 1 <<c>>]" );
}

/*
* reverse string test
* have it print out reverse of string
*/
void toreversestring_test(){
    char test_arr[5] = {'c', 'a', 'r', 'l', 'y'};
    CharLinkedList list1(test_arr, 5);
    std:: cout << list1.toReverseString() << std::endl;
    assert (list1.toReverseString() == "[CharLinkedList of size 5 <<ylrac>>]");
}

/*
* toreverse string empty test
*/
void toreversestring_empty_test(){
    CharLinkedList list1;
    std:: cout << list1.toReverseString() << std::endl;
    assert (list1.toReverseString() == "[CharLinkedList of size 0 <<>>]");
}

/*
* clear test
* make a non empty linked list, clear it, and check if it it's empty after
*/
void clear_test(){
    CharLinkedList list('c');
    assert(not list.isEmpty());
    list.clear();
    assert(list.isEmpty());
}

/*
* check that pushing back one character onto an empty list works
*/
void pushAtBack_one(){
    CharLinkedList test_list;
    test_list.pushAtBack('a');
    std::cout << test_list.toString() << std::endl;
    assert (test_list.toString() == "[CharLinkedList of size 1 <<a>>]");
    assert(test_list.size() == 1);
}

/*
* push back multiple characters
*/
void pushAtBack_many(){
    CharLinkedList test_list('a');
    test_list.pushAtBack('b');
    test_list.pushAtBack('c');
    test_list.pushAtBack('d');
    assert (test_list.toString() == "[CharLinkedList of size 4 <<abcd>>]");
    assert(test_list.size() == 4);
    assert(test_list.first() == 'a');
    assert(test_list.last() == 'd');
}

/*
* push one character onto an empty list
*/
void pushAtFront_one(){
    CharLinkedList test_list;
    test_list.pushAtFront('a');
    std::cout << test_list.toString();
    assert (test_list.toString() == "[CharLinkedList of size 1 <<a>>]");
    assert(test_list.first()== 'a');
    assert(test_list.last()== 'a') ;
}

/*
* push many characters onto a list that isnt empty
*/
void pushAtFront_many(){
    CharLinkedList test_list('a');
    test_list.pushAtFront('b');
    test_list.pushAtFront('c');
    test_list.pushAtFront('d');

    assert (test_list.toString() == "[CharLinkedList of size 4 <<dcba>>]");
    assert(test_list.first() == 'd');
    assert(test_list.last() == 'a');
}

/*
* test push at front using the array constructor
*/
void pushAtFront_constructor(){
    char test_arr[3] = {'a', 'b','c'};
    CharLinkedList test_list(test_arr, 3);
    test_list.pushAtFront('c');
    test_list.pushAtFront('b');
    test_list.pushAtFront('a');
    assert (test_list.toString() == "[CharLinkedList of size 6 <<abcabc>>]");
    assert(test_list.first() == 'a');
    assert(test_list.last() == 'c');
}

/*
* last test
* make an linked list and check that it accurately gives the last char
*/
void last_test(){
    char test_arr[2] = {'x', 'y'};
    CharLinkedList list1(test_arr, 2);
    assert(list1.last() == 'y');
}

/*
* last test 2
* make a long linked list and check that it accurately gives last char
*/
void last_test2(){
    char test_arr[7] = {'x', 'y', 'x', 'a', 'b', 'c', 'd'};
    CharLinkedList list1(test_arr, 7);
    assert(list1.last() == 'd');
}

/*
* test last with an an empty list
*/
void last_outofrange(){
    CharLinkedList list1;
    std::string error_message;
    bool error_thrown = false;
    try {
        list1.last();
    }
    catch (const std:: runtime_error &e){
        error_thrown = true;
        error_message = e.what();
    }
    assert(error_thrown);
    assert(error_message == "cannot get last of empty LinkedList");
}

/*
* first test
* make an linked list with two variables and see if it 
* correctly retrieves the first
*/
void first_test(){
    char test_arr[2] = {'x', 'y'};
    CharLinkedList list1(test_arr, 2);
    assert(list1.first() == 'x');
}

/*
first out of range test
*/
void first_outofrange(){
    CharLinkedList list1;
    std::string error_message;
    bool error_thrown = false;
    try {
        list1.first();
    }
    catch (const std:: runtime_error &e){
        error_thrown = true;
        error_message = e.what();
    }
    assert(error_thrown);
    assert(error_message == "cannot get first of empty LinkedList");
}


// Tests correct insertAt for front of 1-element list.
void insertAt_front_single_list(){
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at front
    test_list.insertAt('b', 0);

    assert(test_list.size() == 2);
    assert(test_list.toString() == "[CharLinkedList of size 2 <<ba>>]");
    assert(test_list.first() == 'b');
    assert(test_list.last() == 'a');
    
}

// Tests correct insertAt for back of list.
void insertAt_back_multiple_list(){
    
    char test_arr[3] = {'t', 'x', 'y'};
    CharLinkedList list1(test_arr, 3);

    // insert at back
    list1.insertAt('b', 3);

    assert(list1.size() == 4);
    assert(list1.toString() == "[CharLinkedList of size 4 <<txyb>>]");
    assert(list1.first() == 't');
    assert(list1.last() == 'b');
    
}

/*
*insert an element in an empty list
*/
void insertAt_empty_correct() {
    CharLinkedList test_list;
    test_list.insertAt('a', 0);
    assert(test_list.size() == 1);
    assert(test_list.toString() == "[CharLinkedList of size 1 <<a>>]");
}

/*
insert an element that is at an index that is too large
*/
void insertAtabove(){
    char test_arr[2] = {'x', 'y'};
    CharLinkedList list1(test_arr, 2);
    bool error_thrown = false;
    std::string error_message;
    try {
        list1.insertAt('c', 3);
    }
    catch (const std:: range_error &e){
        error_thrown = true;
        error_message = e.what();
    }
    std::cout << error_message << std::endl;
    assert(error_thrown);
    assert(error_message == "index (3) not in range [0..2]");
}

/*
* insert an element at an index that is too low
*/
void insertAtbelow(){
    char test_arr[2] = {'x', 'y'};
    CharLinkedList list1(test_arr, 2);
    bool error_thrown = false;
    std::string error_message;
    try {
        list1.insertAt('c', -1);
    }
    catch (const std:: range_error &e){
        error_thrown = true;
        error_message = e.what();
    }
    std::cout << error_message << std::endl;
    assert(error_thrown);
    assert(error_message == "index (-1) not in range [0..2]");
}


/*
* tests that it will insert the element if the list is empty
*/
void insertInOrder_empty_correct(){

    CharLinkedList test_list;
    test_list.insertInOrder('a');
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');

}

/*
* tests that it will insert an element 
in the correct order with lowercase letters
*/
void insertInOrder_correct(){
    //initialize a 4 element list
    char test_arr[4] = {'a', 'd', 'f', 'g'};
    CharLinkedList test_list(test_arr, 4);  
    test_list.insertInOrder('c');
 
    assert(test_list.size() == 5);
    // assert(test_list.elementAt(1) == 'c');
    std::cout << test_list.toString() << std::endl;
    assert(test_list.toString() == "[CharLinkedList of size 5 <<acdfg>>]");
    
}

/*
* tests that it will insert an element in the 
correct order with capitol letters
*/
void insertInOrder_capitals_correct(){
    //initialize a 3 element list
    char test_arr[3] = {'Z', 'E', 'D'};
    CharLinkedList test_list(test_arr, 3);  

    test_list.insertInOrder('A');
    std::cout << test_list.toString() << std::endl;
    assert(test_list.size() == 4);
    assert(test_list.elementAt(0) == 'A');
    assert(test_list.toString() == "[CharLinkedList of size 4 <<AZED>>]");
    
}

/*
*test inserting lowercase into uppercase list
*/
void insertInOrder_mixed_capitols(){
    //initialize a 4 element list
    char test_arr[3] = {'A', 'B', 'C'};
    CharLinkedList test_list(test_arr, 3);  

    test_list.insertInOrder('a');
    std::cout << test_list.toString() << std::endl;
    assert(test_list.size() == 4);
    assert(test_list.elementAt(3) == 'a');
    assert(test_list.toString() == "[CharLinkedList of size 4 <<ABCa>>]");
    assert(test_list.last() == 'a');
    assert(test_list.first() == 'A');
    
}

/*
try to pop an element off the front of an empty list
*/
void popFromFront_empty(){
    // var to track whether range_error is thrown
    bool runtime_error_thrown = false;
    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    // insertAt for out-of-range index
    test_list.popFromFront();
    }
    catch (const std::runtime_error &e) {
    // if insertAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    runtime_error_thrown = true;
    error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");

}

/*
* pop from a non empty linked list
*/
void popFromFront_nonempty_test(){

    char test_arr[3] = {'Z', 'E', 'D'};
    CharLinkedList test_list(test_arr, 3);  
    test_list.popFromFront();
    std::cout << test_list.toString() << std::endl;
    assert(test_list.size() == 2);
    assert(test_list.toString() == "[CharLinkedList of size 2 <<ED>>]");
    assert(test_list.first() == 'E');
    assert(test_list.last() == 'D');
}

/*
* pop from the front of a long list
*/
void popFromFront_longlist(){

    char test_arr[10] = {'Z', 'E', 'D', 'F', 'Q', 'Z', 'E', 'D', 'F', 'Q'};
    CharLinkedList test_list(test_arr, 10);  
    test_list.popFromFront();
    std::cout << test_list.toString() << std::endl;
    assert(test_list.size() == 9);
    assert(test_list.toString() == "[CharLinkedList of size 9 <<EDFQZEDFQ>>]");

}

/*
* pop from the back of an empty list
*/
void popFromBack_empty(){
    // var to track whether range_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    // insertAt for out-of-range index
    test_list.popFromBack();
    }
    catch (const std::runtime_error &e) {
    // if insertAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    runtime_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

/*
* pop from the back of a non empty list
*/
void popFromBack_nonempty_test(){

    char test_arr[3] = {'Z', 'E', 'D'};
    CharLinkedList test_list(test_arr, 3);  
    test_list.popFromBack();
    std::cout << test_list.toString() << std:: endl;
    assert(test_list.size() == 2);
    assert(test_list.toString() == "[CharLinkedList of size 2 <<ZE>>]");

}

/*
* pop from the back of a long list
*/
void popFromBack_longlist(){

    char test_arr[10] = {'Z', 'E', 'D', 'F', 'Q', 'Z', 'E', 'D', 'F', 'Q'};
    CharLinkedList test_list(test_arr, 10);  
    test_list.popFromBack();
    assert(test_list.size() == 9);
    assert(test_list.toString() == "[CharLinkedList of size 9 <<ZEDFQZEDF>>]");

}


/*
* remove an element in an empty linked list
*/
void removeAt_empty(){
    bool runtime_error_thrown = false;
    std::string error_message = "";
    CharLinkedList test_list;

    try{
        test_list.removeAt(0);
    }
    catch (const std:: runtime_error &e){
        runtime_error_thrown = true;
        error_message = e.what();
    }
    std:: cout << error_message << std::endl;
    assert(runtime_error_thrown);
    assert(error_message == "index (0) not in range [0..0)");
}

/*
* remove an element at an index that is out of bounds
*/
void removeAt_negative(){
    bool runtime_error_thrown = false;
    std::string error_message = "";
    CharLinkedList test_list;

    try{
        test_list.removeAt(-1);
    }
    catch (const std:: runtime_error &e){
        runtime_error_thrown = true;
        error_message = e.what();
    }
    std:: cout << error_message << std::endl;
    assert(runtime_error_thrown);
    assert(error_message == "index (-1) not in range [0..0)");
}

/*
* remove an element at an index that is above bounds
*/
void removeAt_above(){
    bool runtime_error_thrown = false;
    std::string error_message = "";

    char test_arr[3] = {'Z', 'E', 'D'};
    CharLinkedList test_list(test_arr, 3);  

    try{
        test_list.removeAt(3);
    }
    catch (const std:: runtime_error &e){
        runtime_error_thrown = true;
        error_message = e.what();
    }
    std:: cout << error_message << std::endl;
    assert(runtime_error_thrown);
    assert(error_message == "index (3) not in range [0..3)");
}

/*
* remove an element from a short list
*/
void removeAt_shortlist(){
    char test_arr[3] = {'Z', 'E', 'D'};
    CharLinkedList test_list(test_arr, 3);  
    test_list.removeAt(1);
    assert(test_list.size() == 2);
    assert(test_list.elementAt(1) == 'D');
    assert(test_list.toString() == "[CharLinkedList of size 2 <<ZD>>]");

}

/*
* remove an element from a one item list
*/
void removeAt_one(){
    CharLinkedList test_list('c');
    test_list.removeAt(0);
   assert(test_list.size() == 0);
}

/*
* remove an element from a long list
*/
void removeAt_long(){
    char test_arr[10] = {'Z', 'E', 'D', 'F', 'Q', 'Z', 'E', 'D', 'F', 'Q'};
    CharLinkedList test_list(test_arr, 10);  
    test_list.removeAt(9);
    assert(test_list.size() == 9);
    assert(test_list.toString() == "[CharLinkedList of size 9 <<ZEDFQZEDF>>]");
    assert(test_list.last() == 'F');
}

/*
* remove an element from the front and back of a list
*/
void removeAt_front(){
    char test_arr[10] = {'Z', 'E', 'D', 'F', 'Q', 'Z', 'E', 'D', 'F', 'Q'};
    CharLinkedList test_list(test_arr, 10);
    test_list.removeAt(0);
    assert(test_list.size() == 9);
    assert(test_list.toString() == "[CharLinkedList of size 9 <<EDFQZEDFQ>>]");
}

/*
* remove an element from the back of the list
*/
void removeAt_back(){
    char test_arr[10] = {'Z', 'E', 'D', 'F', 'Q', 'Z', 'E', 'D', 'F', 'Q'};
    CharLinkedList test_list(test_arr, 10);
    test_list.removeAt(9);
    assert(test_list.size() == 9);
    assert(test_list.toString() == "[CharLinkedList of size 9 <<ZEDFQZEDF>>]");
}

/*
*help remove at 0 test
*/
void help_removeAt_front(){
    char test_arr[3] = {'Z', 'E', 'D'};
    CharLinkedList test_list(test_arr, 3);
    test_list.help_remove(0);
    assert(test_list.toString() == "[CharLinkedList of size 2 <<ED>>]");
}

/*
* try to replace an element at an empty index
*/
void replaceAtempty(){
    CharLinkedList list1;
    bool error_thrown = false;
    try {
        list1.replaceAt('c', 1);
    }
    catch (const std:: runtime_error){
        error_thrown = true;
    }
    assert(error_thrown);
}

/*
* try to replace an element in a one item list
*/
void replaceAt_one(){
    CharLinkedList test_list('c');
    test_list.replaceAt('c', 0);
    assert(test_list.size() == 1);
    assert(test_list.toString() == "[CharLinkedList of size 1 <<c>>]");
}

/*
* replace an item in a long list
*/
void replaceAt_long(){
    char test_arr[10] = {'Z', 'E', 'D', 'F', 'Q', 'Z', 'E', 'D', 'F', 'Q'};
    CharLinkedList test_list(test_arr, 10);  
    test_list.replaceAt('c', 3);
    assert(test_list.size() == 10);
    assert(test_list.toString() == 
    "[CharLinkedList of size 10 <<ZEDcQZEDFQ>>]");
}

/*
* ELement at test 1
* try to access an element that is out of bounds above
*/
void ElementAt_out_of_rangeabove(){
    char test_arr[2] = {'x', 'y'};
    CharLinkedList list1(test_arr, 2);
    bool error_thrown = false;
    std::string error_message;
    try {
        list1.elementAt(2);
    }
    catch (const std:: range_error &e){
        error_thrown = true;
        error_message = e.what();
    }
    std::cout << error_message << std::endl;
    assert(error_thrown);
    assert(error_message == "index (2) not in range [0..2)");
}

/*
* Element at out of range below
* Make sure that you can't access an element that is out of range below
*/
void ElementAt_out_of_rangebelow(){
    char test_arr[2] = {'x', 'y'};
    CharLinkedList list1(test_arr, 2);
    bool error_thrown = false;
    std::string error_message;
    try {
        list1.elementAt(-1);
    }
    catch (const std:: range_error &e){
        error_thrown = true;
        error_message = e.what();
    }
    std::cout << error_message << std::endl;
    assert(error_thrown);
    assert(error_message == "index (-1) not in range [0..2)");
}

/*
* make sure you can't access an element on an empty list
*/
void elementAt_emptylist(){
    bool range_error_thrown =  false;
    std::string error_message = "";
    CharLinkedList list;
    try {
        list.elementAt(0);
    }
    catch (const std::range_error &e){
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert (error_message == "index (0) not in range [0..0)");
    
}

/*
* ElementAt test in bounds
* try to get an element that is in bounds
*/
void ElementAt_test_in_bounds(){
    char test_arr[4] = {'a', 'b', 'c', 'd'};
    CharLinkedList list1(test_arr, 4);
    assert (list1.elementAt(1) == 'b');
}

/*
* remove the last element inthe list
*/
void ElementAt_test_in_back_bounds(){
    char test_arr[4] = {'a', 'b', 'c', 'd'};
    CharLinkedList list1(test_arr, 4);
    assert (list1.elementAt(3) == 'd');
}

/*
* remove the first element in the list
*/
void ElementAt_test_in_front_bounds(){
    char test_arr[4] = {'a', 'b', 'c', 'd'};
    CharLinkedList list1(test_arr, 4);
    assert (list1.elementAt(0) == 'a');
}

/*
* try to concatenate lists of two different sizes
*/
void concatenate_test1(){
    char test_arr1[3] = {'b', 'i', 'g'};
    CharLinkedList test_list1(test_arr1, 3);
    char test_arr2[4] = {'c', 'a', 'r', 's'};
    CharLinkedList test_list2(test_arr2, 4);

    test_list1.concatenate(&test_list2);
    std::cout << test_list1.toString() << std::endl;
    assert(test_list1.size() == 7);
    assert(test_list1.toString() == "[CharLinkedList of size 7 <<bigcars>>]");
}

/*
* concatenate the same word
*/
void concatenate_doubleword(){
    char test_arr1[3] = {'D', 'O', 'G'};
    CharLinkedList test_list1(test_arr1, 3);
    char test_arr2[3] = {'D', 'O', 'G'};
    CharLinkedList test_list2(test_arr2, 3);

    test_list1.concatenate(&test_list2);

    assert(test_list1.size() == 6);
    assert(test_list1.toString() == "[CharLinkedList of size 6 <<DOGDOG>>]");
}

/*
* concatenate a list with an empty list
*/
void concatenate_empty_list(){
    char test_arr1[3] = {'D', 'O', 'G'};
    CharLinkedList test_list1(test_arr1, 3);
    CharLinkedList test_list2;

    test_list1.concatenate(&test_list2);

    assert(test_list1.size() == 3);
    assert(test_list1.toString() == "[CharLinkedList of size 3 <<DOG>>]");
}

/*
* concatenate two empty lists
*/
void concatenate_two_empty_lists(){
    CharLinkedList test_list1;
    CharLinkedList test_list2;

    test_list1.concatenate(&test_list2);

    assert(test_list1.size() == 0);
    assert(test_list1.toString() == "[CharLinkedList of size 0 <<>>]");
}

/*
* concatenate itself
*/
void concatenate_itself(){
    char test_arr1[3] = {'D', 'O', 'G'};
    CharLinkedList test_list1(test_arr1, 3);
    // CharLinkedList test_list2(test_arr1, 3);

    test_list1.concatenate(&test_list1);
    assert(test_list1.toString() == "[CharLinkedList of size 6 <<DOGDOG>>]");
    assert(test_list1.first() == 'D');
    assert(test_list1.last() == 'G');
}


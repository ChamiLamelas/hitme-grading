/*
 *  unit_tests.h
 *  Logan Yuan
 *  2/3/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  Tests thoroughly all functions implemented.
 *   Tests for each function include tests on lists of 
 * size 0, trying to reach indexes just out of bounds,
 * etc..
 *
 */

#include "CharLinkedList.h"
#include <string>
#include <cassert>
#include <stdexcept>

using namespace std;
/*
//tests if i can create a new node
void createNodeTest(){

    CharLinkedList list;
    CharLinkedList::Node* test = list.createNode('d', nullptr, nullptr);

    assert(test->data == 'd');
    assert(test->next == nullptr);

    delete test;
}

//tests constructor with a character given
void CharLinkedListTest(){

    CharLinkedList list('c');

    assert(list.size() == 1);
    assert(list.elementAt(0) == 'c');
}



// tests if we can turn a char[] into a linked list
void conArr()
{
    char a[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(a, 5);

    assert(list.size() == 5);
    assert(list.elementAt(0) == 'a');
    assert(list.elementAt(1) == 'b');
    assert(list.elementAt(2) == 'c');
    assert(list.elementAt(3) == 'd');
    assert(list.elementAt(4) == 'e');
}

//tests the third constructor with large list
void conPointer()
{
    char a[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(a, 5);

    CharLinkedList list1(list);
    assert(list1.size() == 5);
    assert(list1.elementAt(0) == 'a');
    assert(list1.elementAt(1) == 'b');
    assert(list1.elementAt(2) == 'c');
    assert(list1.elementAt(3) == 'd');
    assert(list1.elementAt(4) == 'e');
}

//tests third constructor with one item list
void conPointer1(){
    CharLinkedList list('a');
    CharLinkedList list1(list);

    assert(list.size() == 1);
    assert(list.elementAt(0) == 'a');
}


//tests equals constructor with 5 items
void conEquals()
{
    char a[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(a, 5);

    CharLinkedList list1;
    list1 = list;
    assert(list1.size() == 5);
    assert(list1.elementAt(0) == 'a');
    assert(list1.elementAt(1) == 'b');
    assert(list1.elementAt(2) == 'c');
    assert(list1.elementAt(3) == 'd');
    assert(list1.elementAt(4) == 'e');
}

//tests equals constructor with 1 item
void conEquals1(){
    CharLinkedList list;

    CharLinkedList list1;

    list1 = list;

    assert(list1.size() == 0);
}


//tests isEMpty on non-empty list
void isEmptyTest(){
    CharLinkedList list('a');
    assert(not list.isEmpty());
}

//tests isEmpty on empty list
void isEmptyTest1(){
    CharLinkedList list;
    assert(list.isEmpty());
}

//makes a list and clears it
void clearTest(){
    char a[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(a, 5);

    list.clear();

    assert(list.size() == 0);

    bool thr = false;
    string msg = "";

    try{
        char d = list.elementAt(2);
    }
    catch(const std::range_error &e){
        thr = true;
        msg = e.what();
    }
    assert(thr);
    assert(msg == "index (2) not in range [0..0)");
}

//tests size of 1
void sizeTest(){
    CharLinkedList list('a');
    assert(list.size() == 1);
}

//tests size of 0
void sizeTest1(){
    CharLinkedList list;
    assert(list.size() == 0);
}

//tests size of 5
void sizeTest2(){
    char a[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(a, 5);
    assert(list.size() == 5);
}

//tests first on empty list
void firstTest(){
    CharLinkedList list;

    bool thr = false;
    string msg = "";

    try{
        char d = list.first();
    }
    catch(const std::runtime_error &e){
        thr = true;
        msg = e.what();
    }
    assert(thr);
    assert(msg == "cannot get first of empty LinkedList");
}

//tests first on non-empty list
void firstTest1(){
    CharLinkedList list('a');

    assert(list.first() == 'a');
}


//last with 1 element
void lastTest(){
    CharLinkedList list('a');
    assert(list.last() == 'a');
}

//last with mult. elements
void lastTest1(){
    char a[] = {'a', 'b', 'c'};
    CharLinkedList list(a, 3);
    assert(list.last() == 'c');
}

//last with 0 elements
void lastTest2(){
    CharLinkedList list;
    string error_message;
    bool runtime_error_thrown = false;
    try{
        list.last();
    }
    catch(const std::runtime_error &e){
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot get last of empty LinkedList");
}




//elementAtTest of 1 sized list
void elementAtTest2(){
    CharLinkedList list('a');
    assert(list.elementAt(0) == 'a');
}


//elementAtTest on 3 elements
void elementAtTest3(){
    CharLinkedList list('a');
    list.pushAtBack('b');
    list.pushAtBack('c');
    assert(list.elementAt(0) == 'a');
    assert(list.elementAt(1) == 'b');
    assert(list.elementAt(2) == 'c');
}


//toStringTest on 1 item
void toStringTest(){
    CharLinkedList list('a');
    assert(list.toString() == "[CharLinkedList of size 1 <<a>>]");
}

//toStringTest on multiple items
void toStringTest1(){
    char a[] = {'a', 'b', 'c', 'd', 'e', 'f'};
    CharLinkedList list(a, 6);
    assert(list.toString() == "[CharLinkedList of size 6 <<abcdef>>]");
}

//toStringTest on empty list
void toStringTest2(){
    CharLinkedList list;
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}

//toStringTest on 1 sized list
void toReverseStringTest(){
    CharLinkedList list('a');
    assert(list.toReverseString() == "[CharLinkedList of size 1 <<a>>]");
}

//reverseString on multiple items
void toReverseStringTest1(){
    char a[] = {'a', 'b', 'c', 'd', 'e', 'f'};
    CharLinkedList list(a, 6);
    assert(list.toReverseString() == "[CharLinkedList of size 6 <<fedcba>>]");
}

//reverseString on 0 items
void toReverseStringTest2(){
    CharLinkedList list;
    assert(list.toReverseString() == "[CharLinkedList of size 0 <<>>]");
}


//pushes at front of empty list
void pushAtFrontTest(){
    CharLinkedList list;
    list.pushAtFront('a');
    assert(list.size() == 1);
    assert(list.elementAt(0) == 'a');
}

//adding multiple items
void pushAtFrontTest1(){
    CharLinkedList list;
    list.pushAtFront('a');
    list.pushAtFront('b');
    assert(list.size() == 2);
    assert(list.elementAt(0) == 'b');
    assert(list.elementAt(1) == 'a');
}

//pushes to back of empty list
void pushAtBackTest(){
    CharLinkedList list;
    list.pushAtBack('a');
    assert(list.size() == 1);
    assert(list.elementAt(0) == 'a');
}

//pushes to back for non-empty list
void pushAtBackTest1(){
    char a[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(a, 5);
    list.pushAtBack('a');
    assert(list.size() == 6);
    assert(list.elementAt(5) == 'a');
}


//inserting into empty
void insertAtTest(){
    CharLinkedList list;
    list.insertAt('c', 0);
    assert(list.size() == 1);
    assert(list.elementAt(0) == 'c');
}

//inserting into empty list at invalid index
void insertAtTest1(){
    bool thrown = false;
    string msg = "";
    CharLinkedList list;
    try{
        list.insertAt('c', 1);
    }
    catch(const std::range_error &e){
        thrown = true;
        msg = e.what();
    }

    assert(thrown);
    assert(msg == "index (1) not in range [0..0]");
}

//inserts at beginning
void insertAtTest2(){
    CharLinkedList list;
    list.pushAtBack('b');
    list.insertAt('c', 0);
    assert(list.size() == 2);
    assert(list.elementAt(0) == 'c');
}

//inserts at middle
void insertAtTest3(){
    CharLinkedList list;
    list.pushAtBack('a');
    list.pushAtBack('b');
    list.pushAtBack('c');
    list.insertAt('b', 1);
    assert(list.toString() == "[CharLinkedList of size 4 <<abbc>>]");
}

//inserts at very end
void insertAtTest4(){
    CharLinkedList list;
    list.pushAtBack('a');
    list.pushAtBack('b');
    list.pushAtBack('c');
    list.insertAt('b', 3);
    assert(list.toString() == "[CharLinkedList of size 4 <<abcb>>]");
}

//inserts in order into empty list
void insertInOrderTest(){
    CharLinkedList list;
    list.insertInOrder('a');
    assert(list.elementAt(0) == 'a');
}

//inserts in order into middle
void insertInOrderTest1(){
    char a[] = {'A', 'B', 'D', 'E', 'F'};
    CharLinkedList list(a, 5);
    list.insertInOrder('C');
    assert(list.toString() == "[CharLinkedList of size 6 <<ABCDEF>>]");
    assert(list.first() == 'A');
}

//inserts in order at very end
void insertInOrderTest3(){
    char a[] = {'A', 'B', 'D', 'E', 'F'};
    CharLinkedList list(a, 5);
    list.insertInOrder('Z');
    assert(list.toString() == "[CharLinkedList of size 6 <<ABDEFZ>>]");
}


//removes from 1 item list
void popFromFrontTest(){
    CharLinkedList list;
    list.pushAtBack('a');
    list.popFromFront();
    assert(list.size() == 0);
}

//removes from multiple item list
void popFromFrontTest1(){
    CharLinkedList list;
    list.pushAtBack('a');
    list.pushAtBack('b');
    list.popFromFront();
    assert(list.size() == 1);
    assert(list.elementAt(0) == 'b');
}

//removes from front of empty list
void popFromFrontTest2(){
    CharLinkedList list;
    bool thrown = false;
    string msg;
    try{
        list.popFromFront();
    }
    catch(const std::runtime_error &e){
        thrown = true;
        msg = e.what();
    }

    assert(thrown);
    assert(msg == "cannot pop from empty LinkedList");
}



//pop from back with no items
void popFromBackTest2(){
    CharLinkedList list;
    bool thrown = false;
    string msg;
    try{
        list.popFromBack();
    }
    catch(const std::runtime_error &e){
        thrown = true;
        msg = e.what();
    }
    assert(thrown);
    assert(msg == "cannot pop from empty LinkedList");
}


//removes at invalid index of 0-sized list
void removeAtTest(){
    CharLinkedList list;
    bool thrown = false;
    string msg;
    try{
        list.removeAt(0);
    }
    catch(const std::range_error &e){
        thrown = true;
        msg = e.what();
    }
    assert(thrown);
    assert(msg == "index (0) not in range [0..0)");
}

//removes at invalid index of 1 size list
void removeAtTest1(){
    CharLinkedList list;
    list.pushAtBack('a');
    bool thrown = false;
    string msg;
    try{
        list.removeAt(5);
    }
    catch(const std::range_error &e){
        thrown = true;
        msg = e.what();
    }
    assert(thrown);
    assert(msg == "index (5) not in range [0..1)");
}

//remove negative index
void removeAtTest2(){
    CharLinkedList list;
    bool thrown = false;
    string msg;
    try{
        list.removeAt(-1);
    }
    catch(const std::range_error &e){
        thrown = true;
        msg = e.what();
    }
    assert(thrown);
    assert(msg == "index (-1) not in range [0..0)");
}

//remove from beginning of list
void removeAtTest3(){
    CharLinkedList list('a');
    list.pushAtBack('b');
    list.pushAtBack('c');
    list.removeAt(0);
    assert(list.size() == 2);
    assert(list.elementAt(0) == 'b');
    assert(list.elementAt(1) == 'c');
}

// Tests correct insertion into an empty AL.
// Afterwards, size should be 1 and element at index 0
// should be the element we inserted.
void insertAt_empty_correct() {

    CharLinkedList test_list;
    test_list.insertAt('a', 0);
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');

}

// Tests incorrect insertion into an empty AL.
// Attempts to call insertAt for index larger than 0.
// This should result in an std::range_error being raised.
void insertAt_empty_incorrect() {

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    // insertAt for out-of-range index
    test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
    // if insertAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    range_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0]");

}

// Tests correct insertAt for front of 1-element list.
void insertAt_front_singleton_list() {

    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at front
    test_list.insertAt('b', 0);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'a');

}

// Tests correct insertAt for back of 1-element list.
void insertAt_back_singleton_list() {

    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at back
    test_list.insertAt('b', 1);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');

}

// Tests calling insertAt for a large number of elements.
// Not only does this test insertAt, it also checks that
// array expansion works correctly.
void insertAt_many_elements() {

    CharLinkedList test_list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.insertAt('a', i);
    }

    assert(test_list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }

}



// Tests insertion into the back of a larger list
void insertAt_back_large_list() {

    char test_arr[10] = { 'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 10);

    test_list.insertAt('x', 10);

    assert(test_list.size() == 11);
    assert(test_list.elementAt(10) == 'x');
    assert(test_list.toString() ==
    "[CharLinkedList of size 11 <<yabczdefghx>>]");

}



// Tests out-of-range insertion for a non-empty list.
void insertAt_nonempty_incorrect() {

    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8]");

}


//checks equals on larger lists
void equals_operator5(){
    CharLinkedList list;
    list.pushAtBack('a');
    list.pushAtBack('a');
    list.pushAtBack('a');
    list.pushAtBack('a');
    list.pushAtBack('a');
    list.pushAtBack('a');
    list.pushAtBack('a');
    CharLinkedList list1; //tests larger list
    list1 = list;
    assert(list1.toString() == "[CharLinkedList of size 7 <<aaaaaaa>>]");
}

void insertInOrderLast6(){
    CharLinkedList list('a');
    list.insertInOrder('b'); //sees if it can add to end
    assert(list.elementAt(1) == 'b');
}

void removeAttest7(){
    CharLinkedList list('a');
    list.removeAt(0); //tries removing the first
    assert(list.isEmpty());
}

void insertAtTest8(){
    CharLinkedList list('a');
    list.insertAt('b', 1); //tries inserting at end
    assert(list.elementAt(1) == 'b');
}


// Tests insertion into front of a larger list
void insertAt_front_large_list() {
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    test_list.insertAt('y', 0);

    cout << test_list.toString() << endl;

    assert(test_list.size() == 10);
    assert(test_list.elementAt(0) == 'y');
    assert(test_list.toString() =="[CharLinkedList of size 10 <<yabczdefgh>>]");

}

//Tests insertion into the middle of a larger list
void insertAt_middle_large_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.insertAt('z', 3);

    cout << test_list.toString() << endl;
    assert(test_list.size() == 9);
    assert(test_list.elementAt(3) == 'z');
    assert(test_list.toString() == "[CharLinkedList of size 9 <<abczdefgh>>]");

}


//pop from back with 1 item
void popFromBackTest(){
    CharLinkedList list;
    list.pushAtBack('a');
    cout << list.toString() << endl;
    list.popFromBack();
    cout << list.toString() << endl;
    assert(list.size() == 0);
}

//pop from back with 2 items
void popFromBackTest1(){
    CharLinkedList list;
    list.pushAtBack('a');
    list.pushAtBack('b');
    cout << list.toString() << endl;
    list.popFromBack();
    assert(list.size() == 1);
    assert(list.elementAt(0) == 'a');
}


//elementAtTest of invalid index
void elementAtTest(){
    CharLinkedList list;
    bool range_error = false;
    string error_message;
    try{
        list.elementAt(5);
    } catch(const std::range_error &e){
        range_error = true;
        error_message = e.what();
    }

    cout << error_message << endl;

    assert(range_error);
    assert(error_message == "index (5) not in range [0..0)");
}

//elementAtTest of empty list
void elementAtTest1(){
    CharLinkedList list;
    bool range_error = false;
    string error_message;
    try{
        list.elementAt(0);
    } catch(const std::range_error &e){
        range_error = true;
        error_message = e.what();
    }

    cout << error_message << endl;
    assert(range_error);
    assert(error_message == "index (0) not in range [0..0)");
}

//makes a list and clears it
void clearTest3(){
    char a[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(a, 5);

    list.clear();

    assert(list.size() == 0);

    bool thr = false;
    string msg = "";

    try{
        char d = list.elementAt(2);
    }
    catch(const std::range_error &e){
        thr = true;
        msg = e.what();
    }
    assert(thr);
    assert(msg == "index (2) not in range [0..0)");
}


//replace on an empty list
void replaceAtTest(){
    CharLinkedList list;
    bool thrown = false;
    string msg;
    try{
        list.replaceAt('a', 0);
    }
    catch(const std::range_error &e){
        thrown = true;
        msg = e.what();
    }
    assert(thrown);
    assert(msg == "index (0) not in range [0..0)");
}

//replace on a list with 2 items
void replaceAtTest1(){
    CharLinkedList list;
    list.pushAtBack('a');
    list.replaceAt('b', 0);
    assert(list.elementAt(0) == 'b');
}



//tests insertion at end
void insertInOrderTest9(){
    CharLinkedList list('a');
    list.insertInOrder('b');
    assert(list.size() == 2);
    assert(list.elementAt(1) == 'b');
}

//tests insertion at beginning
void insertInOrderTest91(){
    CharLinkedList list('b');
    list.insertInOrder('a');
    assert(list.size() == 2);
    assert(list.elementAt(1) == 'b');
}

//replace just out of bounds at beginning
void replaceAtTest3()
{
    char a[] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i'};
    CharLinkedList list(a, 9);
    bool thr;
    string msg;

    try{
        list.replaceAt('d', 9);
    }
    catch(const std::range_error &e){
        thr = true;
        msg = e.what();
    }
    assert(thr);
    assert(msg == "index (9) not in range [0..9)");
}

//replace just beyond the end
void replaceAtTest4()
{
    char a[] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i'};
    CharLinkedList list(a, 9);
    bool thr;
    string msg;

    try{
        list.replaceAt('d', -1);
    }
    catch(const std::range_error &e){
        thr = true;
        msg = e.what();
    }
    assert(thr);
    assert(msg == "index (-1) not in range [0..9)");
}

*/
//tests a list against itself

//concatenate two lists with 1 item
void concatTest(){
    char a[] = {'a'};
    CharLinkedList list(a, 1);
    char b[] = {'f'};
    CharLinkedList list1(b, 1);
    list.concatenate(&list1);
    assert(list.toString() == "[CharLinkedList of size 2 <<af>>]");
}

//concatenate two lists where one is empty
void concatTest1(){
    CharLinkedList list('a');
    CharLinkedList list1;
    list.concatenate(&list1);
    assert(list.toString() == "[CharLinkedList of size 1 <<a>>]");
}

//concatenate two lists where both are empty
void concatTest2(){
    CharLinkedList list1('a');
    CharLinkedList list;
    list.concatenate(&list1);
    assert(list.toString() == "[CharLinkedList of size 1 <<a>>]");
}
//concatenate on two empty lists
void concatTest3(){
    CharLinkedList list;
    CharLinkedList list1;
    list.concatenate(&list1);
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}

void concatTest4(){
    CharLinkedList list('a');
    list.concatenate(&list);
    assert(list.toString() == "[CharLinkedList of size 2 <<aa>>]");
}

//tests a larger concatenate list
void concatTest5(){
    char a[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(a, 5);
    char b[] = {'f', 'g', 'h', 'i'};
    CharLinkedList list1(b, 4);
    list.concatenate(&list1);
    assert(list.toString() == "[CharLinkedList of size 9 <<abcdefghi>>]");
}

//tests conctenate on itself with empty list
void concatTest6(){
    CharLinkedList list;
    list.concatenate(&list);
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}

//concats list onto an empty list
void concatTest7(){
    CharLinkedList list;
    char a[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list1(a, 5);
    list.concatenate(&list1);
    assert(list.toString() == "[CharLinkedList of size 5 <<abcde>>]");
}
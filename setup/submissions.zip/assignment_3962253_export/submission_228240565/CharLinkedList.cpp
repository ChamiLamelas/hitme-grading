/*
 *  CharLinkedList.cpp
 *  Logan Yuan
 *  2/3/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Implementation for all the functions in the .h file
 * This includes the code that will create new nodes,
 * allocate appropriate memory, deallocate memory,
 * linking together nodes, and basically everything
 * needed to make the ADT work
 *
 */

#include "CharLinkedList.h"


#include <string>
#include "CharLinkedList.h"
#include <stdexcept>
#include <iostream>

using namespace std;

CharLinkedList::Node *CharLinkedList::createNode(char c, Node *next, Node *prev)
{
    Node *newNode = new Node;
    newNode->data = c;
    newNode->next = next;
    newNode->prev = prev;
    return newNode;
}
/*
name: CharLinkedList()
input/output: nothing
desc: constructor for a CharLinkedList with zero items
*/
CharLinkedList::CharLinkedList()
{
    num = 0;
    front = nullptr;
    back = nullptr;
}

/*
name: CharLinkedList()
input/output: input is char c
desc: constructor for a CharLinkedList with one item
*/
CharLinkedList::CharLinkedList(char c)
{
    Node *newNode = createNode(c, nullptr, nullptr);
    front = newNode;
    back = newNode;
    num = 1;
}

/*
name: CharLinkedList()
input/output: char arr[], int size
desc: constructor that turns a char[] into a CharLinkedList
*/
CharLinkedList::CharLinkedList(char arr[], int size)
{
    num = size;
    front = nullptr;
    back = nullptr;
    Node *previous = front;
    for (int i = 0; i < size; i++)
    {
        Node *newNode = createNode(arr[i], nullptr, nullptr); // create new node

        if (front == nullptr)
        {
            front = newNode;
        }
        else
        {
            newNode->prev = previous; // sets current node's prev to previous 
            previous->next = newNode; // update previous node's pointer
        }

        previous = newNode; // update previous

        back = newNode;
    }
}

/*
name: CharLinkedList()
input/output: input is a pointer to another CharLinkedList
desc: constructor that creates a deep copy of another LinkedList
*/
CharLinkedList::CharLinkedList(const CharLinkedList &other)
{
    num = 0;
    front = nullptr;
    Node *curr = other.front;
    Node *prev = nullptr;
    back = nullptr;
    while (curr != nullptr)
    {
        Node *newNode = createNode(curr->data, nullptr, prev);
        if (front == nullptr) // if empty list
        {
            front = newNode; // set front to newnode
        }
        else
        {
            prev->next = newNode; // assigns previous node's next to current
        }
        prev = newNode;    // resets prev
        curr = curr->next; // resets curr
        num++;
        back = newNode;
    }
}

/*
name: ~CharLinkedList()
input/output: nothing
desc: destructor that frees all memory used
*/
CharLinkedList::~CharLinkedList()
{
    destructorHelper(front);
}

/*
name: destructorHelper()
input/output: initial node
desc: helper function that helps delete[] all nodes
*/
void CharLinkedList::destructorHelper(Node *node)
{
    while (node != nullptr)
    {
        Node *nextNode = node->next; // finds next node
        delete node;                 // deletes memory
        node = nextNode;             // traverses to next node
    }
}

/*
name: CharLinkedList()::operator=
input/output: input is a pointer to another char AL
desc: makes a deep copy of the AL
*/
CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other)
{
    Node *curr = other.front;
    num = other.num;
    front = nullptr;
    back = nullptr;
    Node *prev = nullptr;
    while (curr != nullptr)
    {
        Node *newNode = createNode(curr->data, nullptr, prev);
        if (front == nullptr)
        {
            front = newNode;
        }
        else
        {
            prev->next = newNode;
        }
        prev = newNode;
        curr = curr->next;
        back = newNode;
    }

    return *this;
}

/*
name: isEmpty()
input/output: returns a boolean
desc: returns true if AL is empty, otherwise returns false
*/
bool CharLinkedList::isEmpty() const
{
    return num == 0;
}

/*
name: clear()
input/output: nothing
desc: empties all values in the array
*/
void CharLinkedList::clear()
{
    destructorHelper(front);
    front = nullptr;
    back = nullptr;
    num = 0;
}

/*
name: size()
input/output: outputs an int
desc: returns number of items
*/
int CharLinkedList::size() const
{
    return num;
}

/*
name: first()
input/output: outputs a char
desc: returns the first char in the LinkedList
*/
char CharLinkedList::first() const
{
    if (num == 0) // checks if its empty
    {
        throw std::runtime_error("cannot get first of empty LinkedList");
    }
    else
    {
        return front->data;
    }
}

/*
name: last()
input/output: outputs a char
desc: returns the last char in the LinkedList
*/
char CharLinkedList::last() const
{
    if (num == 0) // checks if its empty
    {
        throw std::runtime_error("cannot get last of empty LinkedList");
    }
    else
    {
        return back->data;
    }
}

/*
name: elementAt()
input/output: takes in an index, outputs a char
desc: returns the char at index
*/
char CharLinkedList::elementAt(int index) const{
    if(index >= 0 and index < num){ //checks the bounds
        return elemAtRecursive(front, index);
    }
    else{ //throws error
        throw std::range_error("index (" + std::to_string(index) 
        + ") not in range [0.." + std::to_string(num) + ")");
    }
}

/*
name:elemAtRecursive()
input/output: takes in a node pointer and an index
desc: outputs a char at the index
 */ 
char CharLinkedList::elemAtRecursive(Node *curr, int index) const{
    if (curr == nullptr){ //goes out of bounds
        throw std::range_error("index (" + std::to_string(index) 
        + ") not in range [0.." + std::to_string(num) + ")");
    }
    if (index == 0){ //if you find the node
        return curr->data; 
    }
    //if you don't find the node, go to next node
    return elemAtRecursive(curr->next, index - 1);
}

/*
name: toString()
input/output: outputs a string
desc: converts the AL into a readable string
*/
std::string CharLinkedList::toString() const
{
    string ans = "[CharLinkedList of size ";
    ans += std::to_string(num); // converts num to num as string
    ans += " <<";
    for (Node *i = front; i != nullptr; i = i->next) // goes thru each node
    {
        ans += i->data; // adds data end
    }
    ans += ">>]";
    return ans;
}

/*
name: toReverseString()
input/output: outputs a string
desc: converts the AL into a readable string reversed
*/
std::string CharLinkedList::toReverseString() const
{
    string ans = "[CharLinkedList of size ";
    ans += std::to_string(num); // converts num to num as string
    ans += " <<";
    string reversedString = "";
    for (Node *i = front; i != nullptr; i = i->next) // goes thru each node
    {
        reversedString = i->data + reversedString; // adds data to beginning
    }
    ans += reversedString;
    ans += ">>]";
    return ans;
}

/*
name: pushAtBack()
input/output: char c
desc: pushs a char to the back of array
*/
void CharLinkedList::pushAtBack(char c)
{
    if (front == nullptr) // if empty list, then make a first
    {
        Node *newNode = createNode(c, nullptr, nullptr);
        front = newNode;
        back = newNode;
    }
    else
    {
        Node* newNode = createNode(c, nullptr, back);
        back->next = newNode;
        back = newNode;
    }
    num++;
}

/*
name: pushAtFront()
input/output: char c
desc: pushes a char to the front of array
*/
void CharLinkedList::pushAtFront(char c)
{
    if (front == nullptr)
    {
        front = createNode(c, nullptr, nullptr); // creates front if no front
    }
    else
    {
        Node *newNode = createNode(c, front, nullptr); // creates new node
        front->prev = newNode;              // sets front's previous to newnode
        front = newNode;                            // front to newnode
    }
    num++;
}

/*
name: insertAt()
input/output: char c, int index
desc: places a character at the index specified, moves everything down
*/
void CharLinkedList::insertAt(char c, int index)
{
    if (index <= num and index >= 0) // checks within bounds
    {
        if (index == 0) // if empty list or inserting at beginning
        {
            Node *newNode = createNode(c, front, nullptr);
            front = newNode;
        }
        else {
            // if non-empty list
            Node *curr = front;
            for (int i = 0; i < index - 1; ++i) {
                curr = curr->next; // go to index's node
            }

            Node *newNode = createNode(c, curr->next, curr); // creates node
            curr->next = newNode;            // points index's node to new node

            if (newNode->next != nullptr) // properly adds to end
            {
                newNode->next->prev = newNode;
            }
        }
        num++;
    }
    else {
        throw std::range_error("index (" + std::to_string(index) 
        + ") not in range [0.." + std::to_string(num) + "]");
    }
}

/*
name: insertInOrder()
input/output: char c
desc: places a character in alphabetical order
*/
void CharLinkedList::insertInOrder(char c)
{
    if (num == 0) {
        Node *newNode = createNode(c, front, nullptr);
        front = newNode;
    } else {
        Node *curr = front; // if non-empty list
        Node *prev = nullptr;
        while (curr != nullptr and c > curr->data) {
            prev = curr;
            curr = curr->next; // go to index's node
        }

        Node *newNode = createNode(c, curr, prev); // creates node

        if (prev != nullptr) { // if non-empty list and not at beginning
            prev->next = newNode;
        } else { // if non-empty list and at beginning
            front->prev = newNode;
            front = newNode;
        }

        if (curr != nullptr) {
            curr->prev = newNode;
        } else{
            back = newNode;
        }
    }
    num++;
}

/*
name: popFromFront()
input/output: nothing
desc: removes the first item
*/
void CharLinkedList::popFromFront()
{
    if (num == 0)
    {
        throw std::runtime_error("cannot pop from empty LinkedList");
    }
    else
    {
        if (num == 1)
        { // if list has one item
            delete front;
            front = nullptr;
        }
        else
        {                           // if it has multiple items
            Node *oldFront = front; // keep track of where old front is
            front = front->next;    // forward the next front
            delete oldFront;        // delete past front bc it won't deconstruct
        }
    }
    num--;
}

/*
name: popFromFront()
input/output: nothing
desc: removes the last item
*/
void CharLinkedList::popFromBack()
{
    if (num == 0)
    {
        throw std::runtime_error("cannot pop from empty LinkedList");
    }
    else if(num == 1){ //in case there's one item
        delete front; //delete front
        front = nullptr; 
        back = nullptr;
    }
    else{
        Node* newBack = back->prev; //find where new back is
        newBack->next = nullptr; //unlink from back
        delete back; //delete
        back = newBack; //reset
    }
    num--;
}

/*
name: removeAt()
input/output: int index
desc: removes the char at specified index
*/
void CharLinkedList::removeAt(int index)
{
    if (index < 0 or index >= num) // if within bounds
    {                              // check bounds
        throw std::range_error("index (" + std::to_string(index) 
        + ") not in range [0.." + std::to_string(num) + ")");
    }
    else {
        if (index == 0) // if removing at beginning
        {
            Node *oldFront = front;
            front = front->next; //'forward' the front
            delete oldFront;
        }
        else {
            // if non-empty list
            Node *curr = front;
            Node *prev;
            for (int i = 0; i < index - 1; ++i) {
                prev = curr;       // finds previous node of index
                curr = curr->next; // finds index's node
            }

            prev->next = curr->next; // links previous to next
            curr->prev = prev;       // links next to previous

            delete curr; // deletes memory
        }
        num--;
    }
}

/*
name: replaceAt()
input/output: char c, int index
desc: replaces the char at specified index with c
*/
void CharLinkedList::replaceAt(char c, int index)
{
    if (num == 0 or index < 0 or index >= num)
    { // check if empty and bounds
        throw std::range_error("index (" + std::to_string(index) 
        + ") not in range [0.." + std::to_string(num) + ")");
    }
    else
    {
        replaceAtHelper(front, c, index, 0);
    }
}

//helper function for above method
void CharLinkedList::replaceAtHelper(Node *current, char c, int index, int ci)
{ //ci means current index, i just couldn't fit it in the 80 char limit
    if (current == nullptr)
    {
        throw std::range_error("index (" + std::to_string(index) +
                ") not in range [0.." + std::to_string(num) + ")");
    }

    if (ci == index) //checks if you're at the index
    {
        current->data = c;
        return;
    }

    replaceAtHelper(current->next, c, index, ci + 1); //runs it on next node
}

/*
name: concatenate()
input/output: pointer to another CharLinkedList
desc: adds the second AL to the end of the first
*/
void CharLinkedList::concatenate(CharLinkedList *other)
{
    if (this == other) {
        CharLinkedList copy(*this); // makes a deep copy of this list
        // uses the code behind the 'else' statement to add nodes
        concatenate(&copy);
    }
    else {
        Node *curr = other->front;

        while(curr != nullptr){
            pushAtBack(curr->data);
            curr = curr->next;
        }
    }
}

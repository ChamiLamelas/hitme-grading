/*
 *  CharLinkedList.h
 *  Logan Yuan
 *  2/3/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Create a list that can change size using nodes.
 * This will help with the speed in removing and inserting data.
 *
 */
#include <string>

#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H

class CharLinkedList
{
public:
    CharLinkedList();
    CharLinkedList(char c);
    CharLinkedList(char arr[], int size);
    CharLinkedList(const CharLinkedList &other);

    ~CharLinkedList();
    CharLinkedList &operator=(const CharLinkedList &other);

    bool isEmpty() const;
    void clear();
    int size() const;
    char first() const;
    char last() const;
    char elementAt(int index) const;
    std::string toString() const;
    std::string toReverseString() const;

    void pushAtBack(char c);
    void pushAtFront(char c);
    void insertAt(char c, int index);
    void insertInOrder(char c);
    void popFromFront();
    void popFromBack();
    void removeAt(int index);
    void replaceAt(char c, int index);
    void concatenate(CharLinkedList *other);

private:
    struct Node
    {
        char data;
        Node *next;
        Node *prev;
    };

    Node *front;
    Node* back;
    int num;

    Node *createNode(char c, Node *nextNode, Node *prev);
    void destructorHelper(Node *node);
    char elemAtRecursive(Node *curr, int index) const;
    void replaceAtHelper(Node* curr, char c, int index, int ci);
};

#endif

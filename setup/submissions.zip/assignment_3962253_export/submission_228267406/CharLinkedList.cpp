/*
 *  CharLinkedList.cpp
 *  Vishal Romero
 *  2/4/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Contains the implementation for the CharLinkedList class
 *
 */

#include "CharLinkedList.h"
#include <sstream>
#include <stdexcept>

using namespace std;

/*
name: CharLinkedList
purpose: default constructor that creates a blank LinkedList
arguments: none
returns: none
effects: blank LinkedList object is created
*/
CharLinkedList::CharLinkedList(){
    front = nullptr;
    back = nullptr;
    numItems = 0;
}

/*
name: CharLinkedList
purpose: constructor that creates a list with one element
arguments: the first character of the list
returns: none
effects: list with one element is created
*/
CharLinkedList::CharLinkedList(char c){
    front = newNode(c, nullptr, nullptr);
    back = front;
    numItems = 1;
}

/*
name: CharLinkedList
purpose: constructor that creates a LinkedList with a given array
    of elements
arguments: an array with the desired array of elements and its size
returns: none
effects: list with the specified size and contents is created
*/
CharLinkedList::CharLinkedList(char arr[], int size){
    front = nullptr;
    back = nullptr;
    numItems = 0;
    for (int i = 0; i < size; i++){
        pushAtBack(arr[i]);
    }
}

/*
name: CharLinkedList
purpose: copy constructor that creates a deep copy of another list
arguments: another LinkedList
returns: none
effects: a new list is created as a copy of the other list
*/
CharLinkedList::CharLinkedList(const CharLinkedList &other){
    front = nullptr;
    back = nullptr;
    numItems = 0;
    for (int i = 0; i < other.size(); i++){
        pushAtBack(other.elementAt(i));
    }
}

/*
name: ~CharLinkedList
purpose: destructor
arguments: none
returns: none
effects: all allocated memory is freed
*/
CharLinkedList::~CharLinkedList(){
    //calls a recursive function to delete all the data
    destruct(front);
}

/*
assignment operator
purpose: allows a deep copy to be made when assigning the value
    of one LinkedList to another
arguments: another LinkedList to be copied
returns: a deep copy of the other LinkedList
effects: value of another list is assigned to the current one 
*/
CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other){
    if (this == &other){
        return *this;
    }
    clear();
    for (int i = 0; i < other.size(); i++){
        pushAtBack(other.elementAt(i));
    }
    return *this;
}

/*
name: isEmpty
purpose: tells whether the list is an empty list
arguments: none
returns: a bool indicating whether the list is empty
effects: none
*/
bool CharLinkedList::isEmpty() const{
    return numItems == 0;
}

/*
name: clear
purpose: makes the current list an empty list
arguments: none
returns: none
effects: the list is emptied and all previously used memory is freed
*/
void CharLinkedList::clear(){
    //calls the helper function to free all memory
    destruct(front);
    //resets the private variables of the list
    front = nullptr;
    back = nullptr;
    numItems = 0;
}

/*
name: size
purpose: allows the client to access the size of the list
arguments: none
returns: an int with the size of the list
effects: none
*/
int CharLinkedList::size() const{
    return numItems;
}

/*
name: first
purpose: allows access to the first element of the list
arguments: none
returns: the char that is first in the list
effects: none
*/
char CharLinkedList::first() const{
    //throws an exception if the list is empty
    if (isEmpty()){
        throw std::runtime_error("cannot get first of empty LinkedList");
    } else {
        return front->c;
    }
}

/*
name: last
purpose: allows access to the last element of the list
arguments: none
returns: the char at the back of the list
effects: none
*/
char CharLinkedList::last() const{
    //throws an exception if the list is empty
    if (isEmpty()){
        throw std::runtime_error("cannot get last of empty LinkedList");
    } else {
        return back->c;
    }
}

/*
name: elementAt
purpose: provides the element at a desired index in the list
arguments: an int with the desired index to access in the list
returns: the char at the desired index
effects: none
*/
char CharLinkedList::elementAt(int index) const{
    //throws an exception if the index is invalid
    if (index < 0 or index >= numItems){
        std::stringstream ss;
        ss << "index (" << index << ") not in range [0..";
        ss << numItems << ")";
        throw std::range_error(ss.str());
    } else {
        Node *currNode = find(front, index);
        return currNode->c;
    }
}

/*
name: toString
purpose: creates a string in a specific format containing the contents
    of the list
arguments: none
returns: a string with the contents of the list
effects: none
*/
std::string CharLinkedList::toString() const{
    std::stringstream ss;
    ss << "[CharLinkedList of size " << numItems;
    ss << " <<";
    Node *currNode = front;
    for (int i = 0; i < numItems; i++){
        ss << currNode->c;
        currNode = currNode->next;
    }
    ss << ">>]";
    return ss.str();
}

/*
name: toReverseString
purpose: creates a string with the reversed contents of the list in
    a specific format
arguments: none
returns: a string with the reversed contents of the list
effecst: none
*/
std::string CharLinkedList::toReverseString() const{
    std::stringstream ss;
    ss << "[CharLinkedList of size " << numItems;
    ss << " <<";
    Node *currNode = back;
    for (int i = 0; i < numItems; i++){
        ss << currNode->c;
        currNode = currNode->last;
    }
    ss << ">>]";
    return ss.str();
}

/*
name: pushAtBack
purpose: to add a given char to the back of the list
arguments: the char to be added to the list
returns: none
effects: the new char is added and the size of the list increases accordingly
*/
void CharLinkedList::pushAtBack(char c){
    if (isEmpty()){ //creates the first element if the list is empty
        front = newNode(c, nullptr, nullptr);
        back = front;
    } else {
        back->next = newNode(c, nullptr, back);
        back = back->next;
    }
    numItems++;
}

/*
name: pushAtFront
purpose: adds a desired char to the front of the list
arguments: the char to be added
returns: none
effects: the new char is at the front of the list and the size increases
*/
void CharLinkedList::pushAtFront(char c){
    if (isEmpty()){ //creates the first element if the list is empty
        front = newNode(c, nullptr, nullptr);
        back = front;
    } else {
        front->last = newNode(c, front, nullptr);
        front = front->last;
    }
    numItems++;
}

/*
name: insertAt
purpose: insert a new char into the list at a desired index
arguments: the new char and the desired index
returns: none
effects: the new char is added and the size increases
*/
void CharLinkedList::insertAt(char c, int index){
    //throws an exception if the index is invalid
    if (index < 0 or index > numItems){
        std::stringstream ss;
        ss << "index (" << index << ") not in range [0..";
        ss << numItems << "]";
        throw std::range_error(ss.str());
    } else if (index == numItems) {
        //adds to the back of the list if the index is behind the list
        pushAtBack(c);
    } else if (index == 0) {
        //if the index is the front, adds to the front
        pushAtFront(c);
    } else { //adds the char if surrounded by other elements
        Node *leftNode = find(front, index - 1);
        Node *rightNode = leftNode->next;
        Node *currNode = newNode(c, rightNode, leftNode);
        leftNode->next = currNode;
        rightNode->last = currNode;
        numItems++;
    }
}

/*
name: insertInOrder
purpose: inserst a new element in the list in ASCII order
arguments: the char to be added
returns: none
effects: inserts the new char in order and the size increases
*/
void CharLinkedList::insertInOrder(char c){
    for (int i = 0; i < numItems; i++){
        if (elementAt(i) > c){ //finds where there is a greater ASCII element
            insertAt(c, i);
            return;
        }
    }
    //adds to the back if no greater element is found
    pushAtBack(c);
}

/*
name: popFromFront
purpose: removes the first element of the list
arguments: none
returns: none
effects: the first element is removed and the size decreases
*/
void CharLinkedList::popFromFront(){
    if (isEmpty()){ //throws an exception if the list is empty
        throw std::runtime_error("cannot pop from empty LinkedList");
    } else if (numItems == 1) { //clears the list if there is one element
        clear();
    } else { //deletes the first element and adjusts the new front markers
        front = front->next;
        delete front->last;
        front->last = nullptr;
        numItems--;
    }
}

/*
name: popFromBack
purpose: removes the last element of the list
arguments: none
returns: none
effects: the last element is removed and the size decreases
*/
void CharLinkedList::popFromBack(){
    if (isEmpty()){ //throws an exception if the list is empty
        throw std::runtime_error("cannot pop from empty LinkedList");
    } else if (numItems == 1) { //clears the list if there is only one element
        clear();
    } else { //deletes the last element
        back = back->last;
        delete back->next;
        back->next = nullptr;
        numItems--;
    }
}

/*
name: removeAt
purpose: removes the element at a given index
arguments: the index to be removed
returns: none
effects: the given index is removed and the size decreases
*/
void CharLinkedList::removeAt(int index){
    //throws an exception if the index is invalid
    if (index < 0 or index >= numItems){
        std::stringstream ss;
        ss << "index (" << index << ") not in range [0..";
        ss << numItems << ")";
        throw std::range_error(ss.str());
    } else if (index == 0) { //removes the first element
        popFromFront();
    } else if (index == numItems - 1) { //removes the last element
        popFromBack();
    } else { //removes the element if the index is within the list
        Node *currNode = find(front, index);
        currNode->last->next = currNode->next;
        currNode->next->last = currNode->last;
        delete currNode;
        numItems--;
    }
}

/*
name: replaceAt
purpose: replaces a desired index with a new char
arguments: the new char and the int containing the desired index
returns: none
effects: the char at the given index is altered
*/
void CharLinkedList::replaceAt(char c, int index){
    //throws an exception if the index is invalid
    if (index < 0 or index >= numItems){
        std::stringstream ss;
        ss << "index (" << index << ") not in range [0..";
        ss << numItems << ")";
        throw std::range_error(ss.str());
    } else { //finds the given Node and changes its char
        Node *currNode = find(front, index);
        currNode->c = c;
    }
}

/*
name: concatenate
purpose: combines the list with another LinkedList
arguments: a pointer to anothe LinkedList
returns: none
effects: the current list has the other list's contents added
*/
void CharLinkedList::concatenate(CharLinkedList *other){
    int otherSize = other->size();
    for (int i = 0; i < otherSize; i++){
        pushAtBack(other->elementAt(i));
    }
}

/*
name: destruct
purpose: recursively frees all of the memory in the list
arguments: a pointer to the current Node
returns: none
effects: all of the allocated memory is freed
*/
void CharLinkedList::destruct(Node *currNode){
    //base case: ends if the current pointer is null
    if (currNode == nullptr){
        return;
    } else {
        //calls the function on the next element and delete this one
        destruct(currNode->next);
        delete currNode;
    }
}

/*
name: newNode
purpose: create a new Node struct and initialize its members
arguments: the new char, a pointer to the next, and a pointer to the last node
returns: a pointer to the newly created Node
effects: a new Node is created on the heap
*/
CharLinkedList::Node *CharLinkedList::newNode(char d, Node *n, Node *l){
    Node *currNode = new Node;
    currNode->c = d;
    currNode->next = n;
    currNode->last = l;
    return currNode;
}

/*
name: find
purpose: recursively finds a node at a specific index of the list
arguments: the first node of the list and the desired index
returns: a pointer to a Node in the list
effects: none
*/
CharLinkedList::Node *CharLinkedList::find(Node *currNode, int index) const{
    if (index == 0){ //base: returns the front node if the index is 0
        return currNode;
    }
    if (index == 1){ //base: returns the next node
        return currNode->next;
    }
    else{ //calls the function again with the next node and a decreased index
        return find(currNode->next, index - 1);
    }
}

/*
 *  unit_tests.h
 *  Vishal Romero
 *  2/4/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  Contains the unit tests for the CharLinkedList class
 *
 */

#include "CharLinkedList.h"
#include <cassert>
#include <stdexcept>

 void constructor_test(){
    CharLinkedList list1;
 }

 void toString_test_0(){
    CharLinkedList list1;
    assert(list1.toString() == "[CharLinkedList of size 0 <<>>]");
}

//tests to see if the single char constructor produces the right size
void constructor_test_1(){
    CharLinkedList list1('c');
    assert(list1.size() == 1);
}

void constructor_test_2(){
    CharLinkedList list1('c');
    assert(list1.toString() == "[CharLinkedList of size 1 <<c>>]");
}

//tests the validity of isEmpty on an empty list
void is_empty_test0(){
    CharLinkedList list1;
    assert(list1.isEmpty());
}

//tests to see if pushAtBack correctly adds the char
void push_back_test(){
    CharLinkedList list1('c');
    list1.pushAtBack('d');
    assert(list1.toString() == "[CharLinkedList of size 2 <<cd>>]");
}

void push_back_test2(){
    CharLinkedList list1;
    list1.pushAtBack('c');
    list1.pushAtBack('d');
    assert(list1.toString() == "[CharLinkedList of size 2 <<cd>>]");
}

//tests to see if the third constructor produces a list of the right size
void constructor_test_3(){
    char arr[] = {'a','b','c','d'};
    CharLinkedList list1(arr, 4);
    assert(list1.toString() == "[CharLinkedList of size 4 <<abcd>>]");
}

//tests to see if pushAtFront correctly adds the char
void push_front_test(){
    CharLinkedList list1('c');
    list1.pushAtFront('d');
    assert(list1.toString() == "[CharLinkedList of size 2 <<dc>>]");
}

//tests the validity of the clear function and provides an additional
//test for isEmpty
void clear_test(){
    char arr[] = {'a','b','c','d'};
    CharLinkedList list1(arr, 4);
    list1.clear();
    assert(list1.isEmpty());
}

//tests whether first correctly pulls the first element
void first_test_0(){
    CharLinkedList list1('c');
    char c = list1.first();
    assert(c == 'c');
}

//tests first in a situation whether an exception is thrown
void first_test_exception(){
    CharLinkedList list1;
    bool failed = false;
    try {
        char c = list1.first();
    }
    catch (const std::runtime_error& e){
        failed = true;
    }
    assert(failed);
}

//tests last in a valid situation
void last_test_0(){
    CharLinkedList list1('c');
    char c = list1.last();
    assert(c == 'c');
}

//tests last in a situation where an exception is thrown
void last_test_exception(){
    CharLinkedList list1;
    bool failed = false;
    try {
        char c = list1.last();
    }
    catch(const std::runtime_error& e){
        failed = true;
    }
    assert(failed);
}

//checks whether elementAt returns the correct char value
void element_at_test0(){
    char arr[] = {'a','b','c','d'};
    CharLinkedList list1(arr, 4);
    assert(list1.elementAt(2) == 'c');
}

//checks elementAt in a situation where an exception is thrown
void element_at_exception(){
    char arr[] = {'a','b','c','d'};
    CharLinkedList list1(arr, 4);
    bool failed = false;
    try {
        char c = list1.elementAt(-1);
    }
    catch(const std::range_error& e){
        failed = true;
    }
    assert(failed);
}

//checks if toReverseString produces the correct output with a blank list
void reverse_string_test0(){
    CharLinkedList list1;
    assert(list1.toReverseString() == "[CharLinkedList of size 0 <<>>]");
}

//checks if toReverseString produces the correct output with a non-empty list
void reverse_string_test1(){
    char arr[] = {'a','b','c','d'};
    CharLinkedList list1(arr, 4);
    assert(list1.toReverseString() == "[CharLinkedList of size 4 <<dcba>>]");
}

// Tests correct insertion into an empty AL.
// Afterwards, size should be 1 and element at index 0
// should be the element we inserted.
void insertAt_empty_correct() { 

    CharLinkedList test_list;
    test_list.insertAt('a', 0);
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');

}

// Tests incorrect insertion into an empty AL.
// Attempts to call insertAt for index larger than 0.
// This should result in an std::range_error being raised.
void insertAt_empty_incorrect() {

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    // insertAt for out-of-range index
    test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
    // if insertAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    range_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0]");
    
}

// Tests correct insertAt for front of 1-element list.
void insertAt_front_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at front
    test_list.insertAt('b', 0);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'a');
    
}

// Tests correct insertAt for back of 1-element list.
void insertAt_back_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at back
    test_list.insertAt('b', 1);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    
}

// Tests calling insertAt for a large number of elements.
// Not only does this test insertAt, it also checks that
// array expansion works correctly.
void insertAt_many_elements() {
    
    CharLinkedList test_list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.insertAt('a', i);
    }

    assert(test_list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
    
}

// Tests insertion into front of a larger list
void insertAt_front_large_list() {
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList list1(test_arr, 9);

    list1.insertAt('y', 0);

    assert(list1.size() == 10);
    assert(list1.elementAt(0) == 'y');
    assert(list1.toString() == "[CharLinkedList of size 10 <<yabczdefgh>>]");

}

// Tests insertion into the middle of a larger list
void insertAt_middle_large_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.insertAt('z', 3);

    assert(test_list.size() == 9);
    assert(test_list.elementAt(3) == 'z');
    assert(test_list.toString() == "[CharLinkedList of size 9 <<abczdefgh>>]");

}

// Tests out-of-range insertion for a non-empty list.
void insertAt_nonempty_incorrect() {
   
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8]");
    
}

//tests insertInOrder with a list that is in order
void insert_order_sorted(){
    char arr[5] = {'A','B','D','E','F'};
    CharLinkedList list1(arr, 5);
    list1.insertInOrder('C');
    assert(list1.toString() == "[CharLinkedList of size 6 <<ABCDEF>>]");
}

//tests insertInOrder with the spec's example of a disordered list
void insert_order_unsorted(){
    char arr[3] = {'Z','E','D'};
    CharLinkedList list1(arr, 3);
    list1.insertInOrder('A');
    assert(list1.toString() == "[CharLinkedList of size 4 <<AZED>>]");
}

//tests popFromFront with a valid list
void pop_front_nonempty(){
    char arr[4] = {'a','b','c','d'};
    CharLinkedList list1(arr, 4);
    list1.popFromFront();
    assert(list1.toString() == "[CharLinkedList of size 3 <<bcd>>]");
}

//tests popFromFront when an exception should be thrown
void pop_front_empty(){
    CharLinkedList list1;
    std::string errorMessage = "";
    bool failed = false;
    try {
        list1.popFromFront();
    }
    catch (const std::runtime_error &e){
        errorMessage = e.what();
        failed = true;
    }
    assert(failed);
    assert(errorMessage == "cannot pop from empty LinkedList");
}

//tests popFromFront when there is one element in the list
void pop_front_single(){
    CharLinkedList list1('c');
    list1.popFromFront();
    assert(list1.toString() == "[CharLinkedList of size 0 <<>>]");
}

//tests the validity of popFromBack with a non-empty list
void pop_back_nonempty(){
    char arr[4] = {'a','b','c','d'};
    CharLinkedList list1(arr, 4);
    list1.popFromBack();
    assert(list1.toString() == "[CharLinkedList of size 3 <<abc>>]");
}

//tests the validity of popFromBack with an empty list
void pop_back_empty(){
    CharLinkedList list1;
    std::string errorMessage = "";
    bool failed = false;
    try {
        list1.popFromBack();
    }
    catch (const std::runtime_error &e){
        errorMessage = e.what();
        failed = true;
    }
    assert(failed);
    assert(errorMessage == "cannot pop from empty LinkedList");
}

//tests popFromBack with one element in the list
void pop_back_single(){
    CharLinkedList list1('c');
    list1.popFromBack();
    assert(list1.toString() == "[CharLinkedList of size 0 <<>>]");
}

//tests removeAt with a valid list and index
void remove_at_correct(){
    char arr[4] = {'a','b','c','d'};
    CharLinkedList list1(arr, 4);
    list1.removeAt(2);
    assert(list1.toString() == "[CharLinkedList of size 3 <<abd>>]");
}

//tests removeAt with an invalid index
void remove_at_incorrect(){
    char arr[4] = {'a','b','c','d'};
    CharLinkedList list1(arr, 4);
    std::string errorMessage = "";
    bool failed = false;
    try {
        list1.removeAt(4);
    }
    catch (const std::range_error &e){
        failed = true;
        errorMessage = e.what();
    }
    assert(failed);
    assert(errorMessage == "index (4) not in range [0..4)");
}

//tests replaceAt with a correct index
void replace_at_correct(){
    char arr[4] = {'a','b','c','d'};
    CharLinkedList list1(arr, 4);
    list1.replaceAt('e', 3);
    assert(list1.toString() == "[CharLinkedList of size 4 <<abce>>]");
}

//tests replaceAt with an invalid index where an exception is thrown
void replace_at_incorrect(){
    char arr[4] = {'a','b','c','d'};
    CharLinkedList list1(arr, 4);
    std::string errorMessage = "";
    bool failed = false;
    try {
        list1.replaceAt('e', 7);
    }
    catch(const std::range_error &e){
        failed = true;
        errorMessage = e.what();
    }
    assert(failed);
    assert(errorMessage == "index (7) not in range [0..4)");
}

//tests concatenate with two non-empty lists
void concatenate_double_word(){
    char arr1[4] = {'a','b','c','d'};
    CharLinkedList list1(arr1, 4);
    char arr2[3] = {'e','f','g'};
    CharLinkedList list2(arr2, 3);
    list1.concatenate(&list2);
    assert(list1.toString() == "[CharLinkedList of size 7 <<abcdefg>>]");
}

//tests concatenate where the first list is empty
void concatenate_blank_first(){
    CharLinkedList list1;
    char arr[4] = {'a','b','c','d'};
    CharLinkedList list2(arr, 4);
    list1.concatenate(&list2);
    assert(list1.toString() == list2.toString());
}

//tests concatenate where the second list is empty
void concatenate_blank_second(){
    char arr[4] = {'a','b','c','d'};
    CharLinkedList list1(arr, 4);
    CharLinkedList list2;
    list1.concatenate(&list2);
    assert(list1.toString() == "[CharLinkedList of size 4 <<abcd>>]");
}

//tests concatenate where one list is added to itself
void concatenate_self(){
    char arr[4] = {'a','b','c','d'};
    CharLinkedList list1(arr, 4);
    list1.concatenate(&list1);
    assert(list1.toString() == "[CharLinkedList of size 8 <<abcdabcd>>]");
}

//tests the validity of the copy constructor
void copy_constructor(){
    char arr[4] = {'a','b','c','d'};
    CharLinkedList list1(arr, 4);
    CharLinkedList list2(list1);
    assert(list2.toString() == "[CharLinkedList of size 4 <<abcd>>]");
}

//tests the validity of the assignment operator
void assignment_operator(){
    char arr[4] = {'a','b','c','d'};
    CharLinkedList list1(arr, 4);
    CharLinkedList list2('e');
    list1 = list2;
    assert(list1.toString() == "[CharLinkedList of size 1 <<e>>]");
}
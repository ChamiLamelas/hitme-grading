/*
 *  CharLinkedList.h
 *  Vishal Romero
 *  2/6/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  This class creates instances of doubly linked LinkedLists, which uses 
 *      incongruous heap memory storage to make a list that can grow or shrink
 *      as elements are added to it. Its use of structs and pointers to 
 *      adjacent elements makes insertion very quick, especially from the 
 *      front and back. However, it is less efficent in accessing elements
 *      because it is not an instant-access array.
 *
 */

#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H

#include <string>
#include <iostream>

class CharLinkedList {
    public:
        CharLinkedList();
        CharLinkedList(char c);
        CharLinkedList(char arr[], int size);
        CharLinkedList(const CharLinkedList &other);
        ~CharLinkedList();
        CharLinkedList &operator=(const CharLinkedList &other);

        bool isEmpty() const;
        void clear();
        int size() const;
        char first() const;
        char last() const;
        char elementAt(int index) const;

        std::string toString() const;
        std::string toReverseString() const;

        void pushAtBack(char c);
        void pushAtFront(char c);
        void insertAt(char c, int index);
        void insertInOrder(char c);
        void popFromFront();
        void popFromBack();
        void removeAt(int index);
        void replaceAt(char c, int index);
        void concatenate(CharLinkedList *other);
    
    private:
        struct Node{
            char c;
            Node *next;
            Node *last;
        };

        Node *front;
        Node *back;
        int numItems;

        void destruct(Node *currNode);
        Node *newNode(char newChar, Node *newNext, Node *newLast);
        Node *find(Node *currNode, int index) const;
};

#endif

/*
 *  CharLinkedList.cpp
 *  Jonathan Guzman(jguzma04)
 *  1/31/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Implementation of the CharLinkedList class.
 *
 */

#include "CharLinkedList.h"
#include <string>
#include <sstream>
#include <stdexcept>

/*
 * name: CharLinkedList
 * purpose: Default constructor of CharLinkedList object
 * arguments: none
 * returns: none
 * effects: Initializes an empty linked list
 */
CharLinkedList::CharLinkedList()
{
    listSize = 0;
    front = nullptr;
    back = nullptr;
}

/*
 * name: CharLinkedList
 * purpose: Alternative constructor that creates a CharLinkedList with 1 char
 * arguments: Char variable that stores what will be inerserted into the list
 * returns: none
 * effects: Initializes a linked list with 1 element
 */
CharLinkedList::CharLinkedList(char c)
{
    Node *node = new Node();
    node->character = c;
    node->next = nullptr;
    node->previous = nullptr;
    front = node;
    back = node;
    listSize = 1;
}

/*
 * name: CharLinkedList
 * purpose: Alternative constructor that creates a linked list with multiple 
 * chars
 * arguments: A char array containing the elements that will be stored, int 
 * variable indicating the size of the array
 * returns: none
 * effects: Initialize a CharLinkedList that has multiple elements
 */
CharLinkedList::CharLinkedList(char arr[], int size)
{
    listSize = 0;
    front = nullptr;
    back = nullptr;

    for (int i = 0; i < size; i++)
    {
        pushAtBack(arr[i]);
    }    
}

/*
 * name: CharLinkedList
 * purpose: Makes a deep copy of a given CharLinkedList instance
 * arguments: Address of CharLinkedList named other
 * returns: none
 * effects: Creates a deep copy of a given instance
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other)
{
    front = nullptr;
    back = nullptr;
    listSize = 0;

    if (other.front != nullptr)
    {
        Node *currOther = other.front;
        while (currOther != nullptr)
        {
            pushAtBack(currOther->character);
            currOther = currOther->next;
        }
    }
}

/*
 * name: CharLinkedList operator=
 * purpose: An assignment operator that redefines "=" to include the 
 * CharLinkedList class
 * arguments: CharLinkedList object on the right of the operator
 * returns: An address to the CharLinkedList object that will be assigned
 * to the instance on the left of the operator
 * effects: Allows the user to assign and reassign CharLinkedList objects
 * as if they are ordinary variables
 */
CharLinkedList& CharLinkedList::operator=(const CharLinkedList &other)
{
    if (this == &other)
    {
        return *this;
    }

    clear();

    if (other.front != nullptr)
    {
        Node *currOther = other.front;

        while (currOther != nullptr)
        {
            pushAtBack(currOther->character);
            currOther = currOther->next;
        }
    }

    return *this;
}

/*
 * name: ~CharLinkedList
 * purpose: Deallocates all heap memory once instance is out of scope
 * arguments: none
 * returns: none
 * effects: Storage used by instance is recycled
 */
CharLinkedList::~CharLinkedList()
{
    destructor_helper(front);
}

/*
 * name: destructor_helper
 * purpose: Recursive function that recycles each node of the list that
 * has been stored on the heap
 * arugments: A pointer to Node that traverses through nodes of the list
 * returns: none
 * effects: Storage used by instance is recycled
 */
void CharLinkedList::destructor_helper(Node *current)
{
    if (current == nullptr)
    {
        return;
    }
    else
    {
        destructor_helper(current->next);
        delete current;
    }
}

/*
 * name: size
 * purpose: Retrieves the current size of the CharLinkedList
 * arguments: none
 * returns: int variable that holds the size of the list
 * effects: none
 */
int CharLinkedList::size() const
{
    return listSize;
}

/*
 * name: size
 * purpose: Indicates whether or not a CharLinkedList is empty
 * arguments: none
 * returns: Boolean that checks whether the size of a list is zero
 * effects: none
 */
bool CharLinkedList::isEmpty()
{
    return listSize == 0;
}

/*
 * name: toString
 * purpose: Displays how large the list is and what it contains as a string
 * arguments: none
 * returns: String that contains the characters of the CharLinkedList
 * effects: none
 */
std::string CharLinkedList::toString() const
{
    int count = 0;
    std::string output;
    char tempArr[listSize];
    Node *current = front;

    while (count < listSize and current != nullptr)
    {
        tempArr[count] = toString_helper(current);
        current = current->next;
        count++;
    }

    std::string chars(tempArr, tempArr + listSize);
    std::stringstream convert;
    convert << listSize;
    std::string intString = convert.str();

    output = "[CharLinkedList of size " + intString + " <<" + chars + ">>]";
    return output;
}

/*
 * name: toString_helper
 * purpose: A helper function that traverses through the list to find each char
 * arguments: A node pointer that traverses through the list
 * returns: A char that is inserting into an array
 * effects: none
 */
char CharLinkedList::toString_helper(Node *current) const
{
    return current->character;
}

/*
 * name: toReverseString
 * purpose: Displays the characters of the CharLinkedList in reverse order
 * arguments: none
 * returns: String that contains the characters of the list in reverse order
 * effects: none
 */
std::string CharLinkedList::toReverseString() const
{
    int count = 0;
    std::string output;
    char tempArr[listSize];
    Node *current = back;

    while (count < listSize and current != nullptr)
    {
        tempArr[count] = toString_helper(current);
        current = current->previous;
        count++;
    }

    std::string chars(tempArr, tempArr + listSize);
    std::stringstream convert;
    convert << listSize;
    std::string intString = convert.str();

    output = "[CharLinkedList of size " + intString + " <<" + chars + ">>]";
    return output;
}

/*
 * name: clear
 * purpose: Makes a given instance of a CharLinkedList empty
 * arguments: none
 * returns: none
 * effects: Result in an empty CharLinkedList
 */
void CharLinkedList::clear()
{
    clear_helper(front);
    front = nullptr;
    back = nullptr;
    listSize = 0;
}

/*
 * name: clear_helper
 * purpose: A helper funtion for clear that recycles all all of the nodes 
 * in the list
 * arguments: A node pointer that traverses through each node of the list
 * returns: none
 * effects: Results in an empty CharLinkedList
 */
void CharLinkedList::clear_helper(Node *current)
{
    if (current != nullptr)
    {
        clear_helper(current->next);
        delete current;
    }
}

/*
 * name: first
 * purpose: Retrieves the first character in the CharLinkedList
 * arguments: none
 * returns: A char variable with the character at the first index
 * effects: none
 */
char CharLinkedList::first() const
{
    if (listSize == 0)
    {
        throw std::runtime_error("cannot get first of empty LinkedList");
    }
    else
    {
        return front->character;
    }
}

/*
 * name: last
 * purpose: Retrieves the last character in the CharLinkedList
 * arguments: none
 * returns: A char variable with the character at the last index
 * effects: none
 */
char CharLinkedList::last() const
{
    if (listSize == 0)
    {
        throw std::runtime_error("cannot get last of empty LinkedList");
    }
    else
    {
        return back->character;
    }
}

/*
 * name: elementAt
 * purpose: Retrieves the character in the list at the indicated index
 * arguments: An int variable holding the index of the list that will be 
 * searched for
 * returns: A char variable with the character at the indicated index
 * effects: none
 */
char CharLinkedList::elementAt(int index) const
{
    if (index < 0 or index >= listSize)
    {
        range_error_throw(index);
    }
    else
    {
        int count = 0;
        char element = elementAt_helper(front, count, index);
        return element;
    }
}

/*
 * name: elementAt_helper
 * purpose: Recursive helper function traverses through the list to find the
 * character at the given index
 * arguments: A node pointer for traversing through the list, an int that 
 * keeps track of how many nodes have been traversed, and the given index
 * returns: A char varibale with the character at the indicated index
 * effects: none
 */
char CharLinkedList::elementAt_helper(Node *curr, int count, int index) const
{
    if (count != index)
    {
        curr = curr->next;
        return elementAt_helper(curr, count + 1, index);
    }
    else
    {
        return curr->character;
    }
}

/*
 * name: pushAtBack
 * purpose: Allows for adding a char to the back of the list
 * arguments: char variable holding what will be pushed to back of the list
 * returns: none
 * effects: Size of CharLinkedList increments by 1
 */
void CharLinkedList::pushAtBack(char c)
{
    Node *newNode = new Node();
    newNode->character = c;
    newNode->next = nullptr;

    if (front == nullptr)
    {
        newNode->previous = nullptr;
        front = newNode;
        back = newNode;
    }
    else
    {
        newNode->previous = back;
        back->next = newNode;
        back = newNode;
    }
    listSize++;
}

/*
 * name: pushAtFront
 * purpose: Allows for adding a char to the front of the list
 * arguments: char variable that holds what will be push to the front of the 
 * list
 * returns: none
 * effect: Size of CharLinkedList increments by 1
 */
void CharLinkedList::pushAtFront(char c)
{
    Node *newNode = new Node();
    newNode->character = c;
    newNode->previous = nullptr;

    if (front == nullptr)
    {
        newNode->next = nullptr;
        front = newNode;
        back = newNode;
    }
    else
    {
        newNode->next = front;
        front->previous = newNode;
        front = newNode;
    }
    listSize++;
}

/*
 * name: insertAt
 * purpose: Inserts a given a char at an indicated index
 * arguments: char to be inserted and an int indicating at which index
 * returns: none
 * effects: A new element is inserted at a specific index and the list is 
 * one element larger
 */
void CharLinkedList::insertAt(char c, int index)
{
    std::stringstream convert;
    std::stringstream convert2;
    convert << index;
    convert2 << listSize;
    std::string intString = convert.str();
    std::string size = convert2.str();
    std::string error_message = 
    "index (" + intString + ") not in range [0.." + size + "]";
    if (index == 0)
    {
        pushAtFront(c);
    }
    else if (index == listSize)
    {
        pushAtBack(c);
    }
    else if (index < 0 or index > listSize)
    {
        throw std::range_error(error_message);
    }
    else
    {
        insertAt_helper(c, index);
    }
}

/*
 * name: insertAt_helper
 * purpose: A helper function that manages the creation of the node and 
 * integration of the new node into the list
 * arguments: char variable to be inserted and an int indicating at which index
 * returns: none
 * effect:  A new element is inserted at a specific index and the list is 
 * one element larger
 */
void CharLinkedList::insertAt_helper(char c, int index)
{
    Node *newNode = new Node();
    newNode->character = c;

    int count = 0;
    Node *curr = front;
    while (count != index)
    {
        curr = curr->next;
        count++;
    }

    newNode->previous = curr->previous;
    newNode->next = curr;
    curr->previous->next = newNode;
    curr->previous = newNode;
    listSize++; 
}

/*
 * name: insertInOrder
 * purpose: Inserts a char based on what its ASCII value is
 * arguments: Char to be inserted into the list
 * returns: none
 * effect: New char is inserted based on ASCII value and the size is 
 * incremented by one
 */
void CharLinkedList::insertInOrder(char c)
{
    int count = 0;
    Node *curr = front;

    if (front == nullptr)
    {
        pushAtFront(c);
        return;
    }

    while (curr != nullptr and c > curr->character)
    {
        curr = curr->next;
        count++;
    }

    if (count == 0)
    {
        pushAtFront(c);
    }
    else if (count == listSize)
    {
        pushAtBack(c);
    }
    else
    {
        insertAt(c, count);
    }
}

/*
 * name: popFromFront
 * purpose: Removes the first element of a CharLinkedList
 * arguments: none
 * returns: none
 * effects: The first element is removed and the size is decremented by one
 */
void CharLinkedList::popFromFront()
{
    if (front == nullptr)
    {
        throw std::runtime_error("cannot pop from empty LinkedList");
    }

    if (front->next == nullptr)
    {
        delete front;
        front = nullptr;
        back = nullptr;
        listSize = 0;
        return;
    }

    Node *second = front->next;
    delete front;
    front = second;
    front->previous = nullptr;
    listSize--;
}

/*
 * name: popFromBack
 * purpose: Removes the last element of a CharLinkedList
 * arguments: none
 * returns: none
 * effects: The last element is removed and the size decrements by one
 */
void CharLinkedList::popFromBack()
{
    if (front == nullptr)
    {
        throw std::runtime_error("cannot pop from empty LinkedList");
    }

    if (front->next == nullptr)
    {
        delete front;
        front = nullptr;
        back = nullptr;
        listSize = 0;
        return;
    }

    Node *secondToLast = back->previous;
    delete back;
    back = secondToLast;
    back->next = nullptr;
    listSize--;
}

/*
 * name: removeAt
 * purpose: Removes a character at the given index of the list
 * arguments: Int variable that indicates at which index the character will
 * be removed
 * returns: none
 * effects: CharLinkedList size is decremented by one
 */
void CharLinkedList::removeAt(int index)
{
    if (front != nullptr and index == 0)
    {
        popFromFront();
    }
    else if (front != nullptr and index == listSize - 1)
    {
        popFromBack();
    }
    else if (index < 0 or index >= listSize or front == nullptr)
    {
        range_error_throw(index);
    }
    else
    {
        removeAt_helper(index);
    }
}

/*
 * name: removeAt_helper
 * purpose: A helper function for remove at that handles the deletion of the 
 * node at the given index and ensures that the list remains linked
 * arguments: Int variable that indicates at which index the character will be
 * removed
 * returns: none
 * effects: CharLinkedList size is decremented by one
 */
void CharLinkedList::removeAt_helper(int index)
{
    int count = 0;
    Node *curr = front;
    while (count != index)
    {
        curr = curr->next;
        count++;
    }

    curr->previous->next = curr->next;
    curr->next->previous = curr->previous;
    delete curr;
    listSize--;
}

/*
 * name: range_error_throw
 * purpose: Private function that is called whenever a function produces a 
 * range error
 * arguments: Index of the list currently being searched for
 * returns: none
 * effects: none
 */
void CharLinkedList::range_error_throw(int index) const
{
    std::stringstream convert;
    std::stringstream convert2;
    convert << index;
    convert2 << listSize;
    std::string intString = convert.str();
    std::string size = convert2.str();
    std::string error_message = 
    "index (" + intString + ") not in range [0.." + size + ")";

    throw std::range_error(error_message);
}

/*
 * name: replaceAt
 * purpose: Replaces character at a given index with a new character
 * arguments: New character to be inserted and index of where it will
 * replace
 * returns: none
 * effects: Given character replaces the old character at the provided index
 */
void CharLinkedList::replaceAt(char c, int index)
{
    if (index < 0 or index >= listSize or front == nullptr)
    {
        range_error_throw(index);
    }
    else
    {
        removeAt(index);
        insertAt(c, index);
    }
}

/*
 * name: concatenate
 * purpose: combines two linked lists
 * arguments: A pointer to another CharLinkedList
 * returns: none
 * effects: Two CharLinkedLists are combined into a single list
 */
void CharLinkedList::concatenate(CharLinkedList *other)
{
    CharLinkedList otherCopy(*other);
    Node *currCopy = otherCopy.front;

    while (currCopy != nullptr)
    {
        pushAtBack(currCopy->character);
        currCopy = currCopy->next;
    }
}
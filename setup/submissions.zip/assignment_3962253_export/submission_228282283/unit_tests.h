/*
 *  unit_tests.h
 *  Jonathan Guzman (jguzma04)
 *  1/31/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  Unit tests for CharLinkedList class.
 *
 */
#include "CharLinkedList.h"
#include <cassert>
#include <stdexcept>
#include <string>


// Tests that class is syntactically correct
void dummy_test()
{
    return;
}

// Tests that the default constructor initalizes an empty list
void default_contructor_test()
{
    CharLinkedList list;
    assert(list.size() == 0);
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
    assert(list.isEmpty());
}

// Tests that the second contructor creates a 1 element list
void second_constructor_test()
{
    CharLinkedList list('a');
    assert(list.size() == 1);
    assert(list.toString() == "[CharLinkedList of size 1 <<a>>]");
}

// Tests whether the third constructor can create a multi-element list
void third_constructor_test1()
{
    char test_arr[8] = {'J', 'o', 'n', 'a', 't', 'h', 'a', 'n'};
    CharLinkedList list(test_arr, 8);

    assert(list.size() == 8);
    assert(list.toString() == "[CharLinkedList of size 8 <<Jonathan>>]");

}

// Tests whether the third constructor can create a list with a variety
// of types of characters
void third_contructor_test2()
{
    char test_arr[4] = {'*', '5', 'a', '$'};
    CharLinkedList list(test_arr, 4);
    
    assert(list.size() == 4);
    assert(list.toString() == "[CharLinkedList of size 4 <<*5a$>>]");
}

// Tests third constructor with a lot of chars
void third_constructor_test3()
{
    char test_arr[100];
    for (int i = 0; i < 100; i++)
    {
        test_arr[i] = 'a';
    }
    CharLinkedList list(test_arr, 100);

    assert(list.size() == 100);

    for (int i = 0; i < 100; i++)
    {
        assert(list.elementAt(i) == 'a');
    }
}

// Tests third constructor with 1 char
void third_constructor_test4()
{
    char test_arr[1] = {'h'};
    CharLinkedList list(test_arr, 1);

    assert(list.size() == 1);
    assert(list.toString() == "[CharLinkedList of size 1 <<h>>]");
}

// Tests copy constructor with multiple element list
void copy_constructor_test1()
{
    char test_arr[8] = {'J', 'o', 'n', 'a', 't', 'h', 'a', 'n'};
    CharLinkedList list1(test_arr, 8);
    CharLinkedList list2(list1);

    assert(list1.size() == 8);
    assert(list1.toString() == "[CharLinkedList of size 8 <<Jonathan>>]");
    assert(list2.size() == 8);
    assert(list2.toString() == "[CharLinkedList of size 8 <<Jonathan>>]");
}

// Tests copy contructor with an emptylist
void copy_constructor_test2()
{  
    CharLinkedList list1;
    CharLinkedList list2(list1);

    assert(list1.size() == 0);
    assert(list1.isEmpty());
    assert(list1.toString() == "[CharLinkedList of size 0 <<>>]");
    assert(list2.size() == 0);
    assert(list2.isEmpty());
    assert(list2.toString() == "[CharLinkedList of size 0 <<>>]");
}

void copy_constructor_test3()
{
    CharLinkedList list1('a');
    CharLinkedList list2(list1);

    assert(list1.size() == 1);
    assert(not list1.isEmpty());
    assert(list1.toString() == "[CharLinkedList of size 1 <<a>>]");
    assert(list2.size() == 1);
    assert(not list2.isEmpty());
    assert(list2.toString() == "[CharLinkedList of size 1 <<a>>]");
}

// Tests operator with two different lists
void operator_test1()
{
    char test_arr1[5] = {'H', 'e', 'l', 'l', 'o'};
    CharLinkedList list1(test_arr1, 5);
    char test_arr2[8] = {'J', 'o', 'n', 'a', 't', 'h', 'a', 'n'};
    CharLinkedList list2(test_arr2, 8);

    list2 = list1;
    assert(list2.size() == 5);
    assert(list2.toString() == "[CharLinkedList of size 5 <<Hello>>]");
}

// Tests operator with 1 non-empty and an empty list
void operator_test2()
{
    CharLinkedList list1;
    char test_arr2[8] = {'J', 'o', 'n', 'a', 't', 'h', 'a', 'n'};
    CharLinkedList list2(test_arr2, 8);

    list2 = list1;
    assert(list2.size() == 0);
    assert(list2.toString() == "[CharLinkedList of size 0 <<>>]");
}

// Tests operator with 1 non-empty and an empty list
void operator_test3()
{
    CharLinkedList list1;
    char test_arr2[8] = {'J', 'o', 'n', 'a', 't', 'h', 'a', 'n'};
    CharLinkedList list2(test_arr2, 8);

    list1 = list2;
    assert(list1.size() == 8);
    assert(list1.toString() == "[CharLinkedList of size 8 <<Jonathan>>]");
}

// Tests operator with two identical lists
void operator_test4()
{
    char test_arr1[8] = {'J', 'o', 'n', 'a', 't', 'h', 'a', 'n'};
    CharLinkedList list1(test_arr1, 8);
    char test_arr2[8] = {'J', 'o', 'n', 'a', 't', 'h', 'a', 'n'};
    CharLinkedList list2(test_arr2, 8);

    list1 = list2;
    assert(list1.size() == 8);
    assert(list1.toString() == "[CharLinkedList of size 8 <<Jonathan>>]");
}

// Tests whether size can detect an empty list
void size_test1()
{
    CharLinkedList list;
    assert(list.size() == 0);
}

// Tests whether size can detect a non-empty list
void size_test2()
{
    char test_arr[5] = {'H', 'e', 'l', 'l', 'o'};
    CharLinkedList list(test_arr, 5);

    assert(list.size() == 5);
}

// Tests whether isEmpty can detect an empty list
void isEmpty_test1()
{
    CharLinkedList list;
    assert(list.isEmpty());
}

// Tests whether isEmpty can detect a non-empty list
void isEmpty_test2()
{
    CharLinkedList list('a');
    assert(not list.isEmpty());
}

// Tests toString with 5 char list
void toString_test1()
{
    char test_arr[5] = {'H', 'e', 'l', 'l', 'o'};
    CharLinkedList list(test_arr, 5);

    assert(list.toString() == "[CharLinkedList of size 5 <<Hello>>]");
}

// Tests toString with a variety of characters
void toString_test2()
{
    char test_arr[4] = {'*', '5', 'a', '$'};
    CharLinkedList list(test_arr, 4);

    assert(list.toString() == "[CharLinkedList of size 4 <<*5a$>>]");
}

// Tests toString with 1 char list
void toString_test3()
{
    CharLinkedList list('a');

    assert(list.toString() == "[CharLinkedList of size 1 <<a>>]");
}

// Tests toString with empty list
void toString_test4()
{
    CharLinkedList list;

    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}

// Tests clear with multiple elements
void clear_test1()
{
    char test_arr[8] = {'J', 'o', 'n', 'a', 't', 'h', 'a', 'n'};
    CharLinkedList list(test_arr, 8);
    list.clear();

    assert(list.isEmpty());
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}

// Tests clear with empty list
void clear_test2()
{
    CharLinkedList list;
    list.clear();

    assert(list.isEmpty());
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}

// Tests clear with list containing many chars
void clear_test3()
{
    char test_arr[100];
    for (int i = 0; i < 99; i++)
    {
        test_arr[i] = 'a';
    }
    CharLinkedList list(test_arr, 100);
    list.clear();

    assert(list.isEmpty());
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}

// Tests toReverseString with 5 char list
void toReverseString_test1()
{
    char test_arr[5] = {'H', 'e', 'l', 'l', 'o'};
    CharLinkedList list(test_arr, 5);

    assert(list.toReverseString() == "[CharLinkedList of size 5 <<olleH>>]");
}

// Tests toReverseString with a variety of characters
void toReverseString_test2()
{
    char test_arr[4] = {'*', '5', 'a', '$'};
    CharLinkedList list(test_arr, 4);

    assert(list.toReverseString() == "[CharLinkedList of size 4 <<$a5*>>]");
}

// Tests toReverseString with 1 char list
void toReverseString_test3()
{
    CharLinkedList list('a');

    assert(list.toReverseString() == "[CharLinkedList of size 1 <<a>>]");
}

// Tests toReverseString with an empty list
void toReverseString_test4()
{
    CharLinkedList list;
    
    assert(list.toReverseString() == "[CharLinkedList of size 0 <<>>]");
}

// Test first with multiple chars in list
void first_test1()
{
    char test_arr[8] = {'J', 'o', 'n', 'a', 't', 'h', 'a', 'n'};
    CharLinkedList list(test_arr, 8);

    assert(list.first() == 'J');
}

// Test first with variety of chars
void first_test2()
{
    char test_arr[4] = {'*', '5', 'a', '$'};
    CharLinkedList list(test_arr, 4);

    assert(list.first() == '*');
}

// Tests first with empty list
void first_test3()
{
    CharLinkedList list;
    bool runtimeErrorThrown = false;
    std::string error_message = "";
    try
    {
        list.first();
    }
    catch(const std::runtime_error& e)
    {
        runtimeErrorThrown = true;
        error_message = e.what();
    }
    
    assert(runtimeErrorThrown);
    assert(error_message == "cannot get first of empty LinkedList");
}

// Tests last with multiple chars
void last_test1()
{
    char test_arr[8] = {'J', 'o', 'n', 'a', 't', 'h', 'a', 'n'};
    CharLinkedList list(test_arr, 8);

    assert(list.last() == 'n');
}

// Tests last with a variety of chars
void last_test2()
{
    char test_arr[4] = {'*', '5', 'a', '$'};
    CharLinkedList list(test_arr, 4);

    assert(list.last() == '$');
}

// Tests last with 1 char
void last_test3()
{
    CharLinkedList list('a');

    assert(list.last() == 'a');
}

// Tests last with an empty list
void last_test4()
{
    CharLinkedList list;
    bool runtimeErrorThrown = false;
    std::string error_message = "";
    try
    {
        list.last();
    }
    catch(const std::runtime_error& e)
    {
        runtimeErrorThrown = true;
        error_message = e.what();
    }
    
    assert(runtimeErrorThrown);
    assert(error_message == "cannot get last of empty LinkedList");
}

// Tests elementAt with idx in the middle
void elementAt_test1()
{
    char test_arr[8] = {'J', 'o', 'n', 'a', 't', 'h', 'a', 'n'};
    CharLinkedList list(test_arr, 8);

    assert(list.elementAt(3) == 'a');
    assert(list.elementAt(4) == 't');
}

// Tests elementAt with front idx
void elementAt_test2()
{
    char test_arr[5] = {'H', 'e', 'l', 'l', 'o'};
    CharLinkedList list(test_arr, 5);

    assert(list.elementAt(0) == 'H');
}

// Tests elementAt with last idx
void elementAt_test3()
{
    char test_arr[8] = {'J', 'o', 'n', 'a', 't', 'h', 'a', 'n'};
    CharLinkedList list(test_arr, 8);

    assert(list.elementAt(7) == 'n');
}

// Tests elementAt with empty list
void elementAt_test4()
{
    CharLinkedList list;
    bool runtimeErrorThrown = false;
    std::string error_message = "";
    try
    {
        list.elementAt(4);
    }
    catch(const std::runtime_error& e)
    {
        runtimeErrorThrown = true;
        error_message = e.what();
    }
    
    assert(runtimeErrorThrown);
    assert(error_message == "index (4) not in range [0..0)");
}

// Tests elementAt with out of range indx
void elementAt_test5()
{
    char test_arr[8] = {'J', 'o', 'n', 'a', 't', 'h', 'a', 'n'};
    CharLinkedList list(test_arr, 8);

    bool runtimeErrorThrown = false;
    std::string error_message = "";
    try
    {
        list.elementAt(100);
    }
    catch(const std::runtime_error& e)
    {
        runtimeErrorThrown = true;
        error_message = e.what();
    }

    assert(runtimeErrorThrown);
    assert(error_message == "index (100) not in range [0..8)");
}

// Test pushAtBack with a list of multiple chars
void pushAtBack_test1()
{
    char test_arr[8] = {'J', 'o', 'n', 'a', 't', 'h', 'a', 'n'};
    CharLinkedList list(test_arr, 8);
    list.pushAtBack('a');

    assert(list.elementAt(8) == 'a');
    assert(list.toString() == "[CharLinkedList of size 9 <<Jonathana>>]");
}

// Tests pushAtBack with a list of one element
void pushAtBack_test2()
{
    CharLinkedList list('a');
    list.pushAtBack('b');
    list.pushAtBack('c');

    assert(list.toString() == "[CharLinkedList of size 3 <<abc>>]");
}

// Tests pushAtBack with an empty list
void pushAtBack_test3()
{
    CharLinkedList list;
    list.pushAtBack('a');

    assert(list.toString() == "[CharLinkedList of size 1 <<a>>]");
}

// Tests pushAtBack with many chars
void pushAtBack_test4()
{
    CharLinkedList list;
    char test_arr[100];

    for (int i = 0; i < 100; i++)
    {
        test_arr[i] = 'a';
    }

    for (int i = 0; i < 100; i++)
    {
        list.pushAtBack(test_arr[i]);
    }

    assert(list.size() == 100);
    
    for (int i = 0; i < 100; i++)
    {
        assert(list.elementAt(i) == 'a');
    } 
}

// Tests push at front with a list of 
void pushAtFront_test1()
{
    char test_arr[8] = {'J', 'o', 'n', 'a', 't', 'h', 'a', 'n'};
    CharLinkedList list(test_arr, 8);
    list.pushAtFront('a');

    assert(list.elementAt(0) == 'a');
    assert(list.toString() == "[CharLinkedList of size 9 <<aJonathan>>]");
}

// Tests pushAtBack with a list of one element
void pushAtFront_test2()
{
    CharLinkedList list('a');
    list.pushAtFront('b');
    list.pushAtFront('c');

    assert(list.toString() == "[CharLinkedList of size 3 <<cba>>]");
}

// Tests pushAtBack with an empty list
void pushAtFront_test3()
{
    CharLinkedList list;
    list.pushAtFront('a');

    assert(list.toString() == "[CharLinkedList of size 1 <<a>>]");
}

// Tests pushAtBack with many chars
void pushAtFront_test4()
{
    CharLinkedList list;
    char test_arr[100];

    for (int i = 0; i < 100; i++)
    {
        test_arr[i] = 'a';
    }

    for (int i = 0; i < 100; i++)
    {
        list.pushAtFront(test_arr[i]);
    }

    assert(list.size() == 100);
    
    for (int i = 0; i < 100; i++)
    {
        assert(list.elementAt(i) == 'a');
    } 
}

// Tests inserting a char at the front of the list
void insertAt_test1()
{
    char test_arr[5] = {'H', 'e', 'l', 'l', 'o'};
    CharLinkedList list(test_arr, 5);

    list.insertAt('a', 0);
    assert(list.toString() == "[CharLinkedList of size 6 <<aHello>>]");
}

// Tests inserting a char at the back of the list
void insertAt_test2()
{
    char test_arr[5] = {'H', 'e', 'l', 'l', 'o'};
    CharLinkedList list(test_arr, 5);

    list.insertAt('a', 5);
    assert(list.toString() == "[CharLinkedList of size 6 <<Helloa>>]");
} 

// Tests inserting a char into the middle of list
void insertAt_test3()
{
    char test_arr[8] = {'J', 'o', 'n', 'a', 't', 'h', 'a', 'n'};
    CharLinkedList list(test_arr, 8);

    list.insertAt('e', 3);
    list.insertAt('e', 3);
    assert(list.elementAt(3) == 'e');
    assert(list.toString() == "[CharLinkedList of size 10 <<Joneeathan>>]");

}

// Tests inserting non-alphabetical chars
void insertAt_test4()
{
    char test_arr[4] = {'*', '^', '#', '!'};
    CharLinkedList list(test_arr, 4);

    list.insertAt('$', 2);
    assert(list.elementAt(2) == '$');
    assert(list.toString() == "[CharLinkedList of size 5 <<*^$#!>>]");
}

// Tests inserting many chars
void insertAt_test5()
{
    char test_arr[100];
    for (int i = 0; i < 100; i++)
    {
        test_arr[i] = 'a';
    }

    CharLinkedList list;

    for (int i = 0; i < 100; i++)
    {
        list.insertAt(test_arr[i], i);
    }

    assert(list.size() == 100);
    for (int i = 0; i < 100; i++)
    {
        assert(list.elementAt(i) == 'a');
    }
}

// Tests inserting at an out of range index
void insertAt_test6()
{
    char test_arr[8] = {'J', 'o', 'n', 'a', 't', 'h', 'a', 'n'};
    CharLinkedList list(test_arr, 8);

    bool runtimeErrorThrown = false;
    std::string error_message = "";
    try
    {
        list.insertAt('g', 12);
    }
    catch(const std::range_error& e)
    {
        runtimeErrorThrown = true;
        error_message = e.what();
    }

    assert(runtimeErrorThrown);
    assert(error_message == "index (12) not in range [0..8]");
}   

// Tests insertInOrder with char that needs to be inserted in middle
void insertInOrder_test1()
{
    char test_arr[5] = {'A', 'B', 'D', 'E', 'F'};
    CharLinkedList list(test_arr, 5);

    list.insertInOrder('C');
    assert(list.toString() == "[CharLinkedList of size 6 <<ABCDEF>>]");
}

// Tests insertInOrder with char that needs to be inserted at the front
void insertInOrder_test2()
{
    char test_arr[3] = {'Z', 'E', 'D'};
    CharLinkedList list(test_arr, 3);

    list.insertInOrder('A');
    list.insertInOrder('a');
    assert(list.toString() == "[CharLinkedList of size 5 <<AZEDa>>]");
}

// Tests insertInorder that needs to be inserted at the back
void insertInOrder_test3()
{
    char test_arr[5] = {'h', 'e', 'l', 'l', 'o'};
    CharLinkedList list(test_arr, 5);

    list.insertInOrder('z');
    assert(list.toString() == "[CharLinkedList of size 6 <<helloz>>]");
}

// Tests insertInOrder on an initially empty list
void insertInOrder_test4()
{
    CharLinkedList list;

    list.insertInOrder('a');
    assert(list.toString() == "[CharLinkedList of size 1 <<a>>]");
}

// Tests popFromFront with non-empty list
void popFromFront_test1()
{
    char test_arr[8] = {'J', 'o', 'n', 'a', 't', 'h', 'a', 'n'};
    CharLinkedList list(test_arr, 8);

    list.popFromFront();
    assert(list.toString() == "[CharLinkedList of size 7 <<onathan>>]");
}

// Tests popFromFront with empty list
void popFromFront_test2()
{
    CharLinkedList list;
    bool runtimeErrorThrown = false;
    std::string error_message = "";
    try
    {
        list.popFromFront();
    }
    catch(const std::runtime_error& e)
    {
        runtimeErrorThrown = true;
        error_message = e.what();
    }

    assert(runtimeErrorThrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

// Tests popFromFront on list containing 1 char
void popFromFront_test3()
{
    CharLinkedList list('a');
    list.popFromFront();

    assert(list.isEmpty());
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}

// Tests popFromBack on a non empty list
void popFromBack_test1()
{
    char test_arr[8] = {'J', 'o', 'n', 'a', 't', 'h', 'a', 'n'};
    CharLinkedList list(test_arr, 8);

    list.popFromBack();
    assert(list.toString() == "[CharLinkedList of size 7 <<Jonatha>>]");
}

// Tests popFromBack on an empty list
void popFromBack_test2()
{
    CharLinkedList list;
    bool runtimeErrorThrown = false;
    std::string error_message = "";
    try
    {
        list.popFromBack();
    }
    catch(const std::runtime_error& e)
    {
        runtimeErrorThrown = true;
        error_message = e.what();
    }

    assert(runtimeErrorThrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

// Tests popFromBack on a list containing only 1 char
void popFromBack_test3()
{
    CharLinkedList list('a');
    list.popFromFront();

    assert(list.isEmpty());
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}

// Tests remove at by removing chars in the middle of a list
void removeAt_test1()
{
    char test_arr[8] = {'J', 'o', 'n', 'a', 't', 'h', 'a', 'n'};
    CharLinkedList list(test_arr, 8);

    list.removeAt(2);
    list.removeAt(2);
    list.removeAt(4);

    assert(list.toString() == "[CharLinkedList of size 5 <<Jothn>>]");
}

// Tests removeAt by removing a chars from front of list
void removeAt_test2()
{
    char test_arr[8] = {'J', 'o', 'n', 'a', 't', 'h', 'a', 'n'};
    CharLinkedList list(test_arr, 8);

    list.removeAt(0);
    list.removeAt(0);

    assert(list.toString() == "[CharLinkedList of size 6 <<nathan>>]");
}

// Tests removeAt by removing chars from back of list
void removeAt_test3()
{
    char test_arr[8] = {'J', 'o', 'n', 'a', 't', 'h', 'a', 'n'};
    CharLinkedList list(test_arr, 8);

    list.removeAt(7);
    list.removeAt(6);

    assert(list.toString() == "[CharLinkedList of size 6 <<Jonath>>]");
}

// Tests removeAt by attempting to remove chars from empty list
void removeAt_test4()
{
    CharLinkedList list;
    bool rangeErrorThrown = false;
    std::string error_message = "";
    try
    {
        list.removeAt(5);
    }
    catch(const std::range_error &e)
    {
        rangeErrorThrown = true;
        error_message = e.what();
    }
    
    assert(rangeErrorThrown);
    assert(error_message == "index (5) not in range [0..0)");
}

// Tests removeAt by giving it an out of bounds index
void removeAt_test5()
{
    char test_arr[8] = {'J', 'o', 'n', 'a', 't', 'h', 'a', 'n'};
    CharLinkedList list(test_arr, 8);

    bool rangeErrorThrown = false;
    std::string error_message = "";
    try
    {
        list.removeAt(8);
    }
    catch(const std::range_error &e)
    {
        rangeErrorThrown = true;
        error_message = e.what();
    }
    
    assert(rangeErrorThrown);
    assert(error_message == "index (8) not in range [0..8)");
}

// Tests removeAt on an empty list
void removeAt_test6()
{
    CharLinkedList list;

    bool rangeErrorThrown = false;
    std::string error_message = "";
    try
    {
        list.removeAt(0);
    }
    catch(const std::range_error &e)
    {
        rangeErrorThrown = true;
        error_message = e.what();
    }
    
    assert(rangeErrorThrown);
    assert(error_message == "index (0) not in range [0..0)");

}

// Tests replaceAt by replacing char in the middle of the list
void replaceAt_test1()
{
    char test_arr[8] = {'J', 'o', 'n', 'a', 't', 'h', 'a', 'n'};
    CharLinkedList list(test_arr, 8);

    list.replaceAt('b', 3);
    assert(list.toString() == "[CharLinkedList of size 8 <<Jonbthan>>]");
    list.replaceAt('c', 3);
    assert(list.toString() == "[CharLinkedList of size 8 <<Joncthan>>]");

}

// Test replaceAt by replacing char at front of the list
void replaceAt_test2()
{
    char test_arr[8] = {'J', 'o', 'n', 'a', 't', 'h', 'a', 'n'};
    CharLinkedList list(test_arr, 8);

    list.replaceAt('c', 0);
    assert(list.toString() == "[CharLinkedList of size 8 <<conathan>>]");
    list.replaceAt('a', 0);
    assert(list.toString() == "[CharLinkedList of size 8 <<aonathan>>]");
}

// Tests replaceAt by replacing char at the back of the list
void replaceAt_test3()
{
    char test_arr[8] = {'J', 'o', 'n', 'a', 't', 'h', 'a', 'n'};
    CharLinkedList list(test_arr, 8);

    list.replaceAt('c', 7);
    assert(list.toString() == "[CharLinkedList of size 8 <<Jonathac>>]");
    list.replaceAt('a', 7);
    assert(list.toString() == "[CharLinkedList of size 8 <<Jonathaa>>]");

}

// Tests replaceAt with an empty list
void replaceAt_test4()
{
    CharLinkedList list;

    bool rangeErrorThrown = false;
    std::string error_message = "";
    try
    {
        list.replaceAt('a', 0);
    }
    catch(const std::range_error& e)
    {
        rangeErrorThrown = true;
        error_message = e.what();
    }

    assert(rangeErrorThrown);
    assert(error_message == "index (0) not in range [0..0)");
}

// Tests replaceAt with an out of range index
void replaceAt_test5()
{
    char test_arr[8] = {'J', 'o', 'n', 'a', 't', 'h', 'a', 'n'};
    CharLinkedList list(test_arr, 8);

    bool rangeErrorThrown = false;
    std::string error_message = "";
    try
    {
        list.replaceAt('a', 8);
    }
    catch(const std::range_error& e)
    {
        rangeErrorThrown = true;
        error_message = e.what();
    }

    assert(rangeErrorThrown);
    assert(error_message == "index (8) not in range [0..8)");
}

//Tests replaceAt with a list with a of chars
void replaceAt_test6()
{
    char test_arr[100];
    for (int i = 0; i < 100; i++)
    {
        test_arr[i] = 'a';
    }
    
    CharLinkedList list(test_arr, 100);
    for (int i = 0; i < 100; i++)
    {
        list.replaceAt('b', i);
    }

    assert(list.size() == 100);

    for (int i = 0; i < 100; i++)
    {
        assert(list.elementAt(i) == 'b');
    }
}

// Tests concatenating an empty list with a non-empty list
void concatenate_test1()
{
    CharLinkedList list1;
    char test_arr[3] = {'c', 'a', 't'};
    CharLinkedList list2(test_arr, 3);

    list1.concatenate(&list2);

    assert(list1.size() == 3);
    assert(list1.toString() == "[CharLinkedList of size 3 <<cat>>]");
}

// Tests concatenating a list with an empty list
void concatenate_test2()
{
    char test_arr[3] = {'c', 'a', 't'};
    CharLinkedList list1(test_arr, 3);
    CharLinkedList list2;

    list1.concatenate(&list2);

    assert(list1.size() == 3);
    assert(list1.toString() == "[CharLinkedList of size 3 <<cat>>]");
}

// Tests concatenate when second list is larger than the first
void concatenate_test3()
{
    char test_arr1[3] = {'c', 'a', 't'};
    CharLinkedList list1(test_arr1, 3);
    char test_arr2[8] = {'C', 'H', 'E', 'S', 'H', 'I', 'R', 'E'};
    CharLinkedList list2(test_arr2, 8);

    list1.concatenate(&list2);

    assert(list1.size() == 11);
    assert(list1.toString() == "[CharLinkedList of size 11 <<catCHESHIRE>>]");
    assert(list2.size() == 8);
    assert(list2.toString() == "[CharLinkedList of size 8 <<CHESHIRE>>]");
}

// Tests concatenate when first list is larger than the second
void concatenate_test4()
{
    char test_arr1[8] = {'C', 'H', 'E', 'S', 'H', 'I', 'R', 'E'};
    CharLinkedList list1(test_arr1, 8);
    char test_arr2[3] = {'c', 'a', 't'};
    CharLinkedList list2(test_arr2, 3);

    list1.concatenate(&list2);

    assert(list1.size() == 11);
    assert(list1.toString() == "[CharLinkedList of size 11 <<CHESHIREcat>>]");
    assert(list2.size() == 3);
    assert(list2.toString() == "[CharLinkedList of size 3 <<cat>>]");
}

void concatenate_test5()
{
    char test_arr1[8] = {'C', 'H', 'E', 'S', 'H', 'I', 'R', 'E'};
    CharLinkedList list1(test_arr1, 8);

    list1.concatenate(&list1);

    assert(list1.size() == 16);
    assert(list1.toString() == 
    "[CharLinkedList of size 16 <<CHESHIRECHESHIRE>>]");
}

/*
 *  unit_tests.h
 *  Author: Larry Qiu (lqiu01)
 *  Date: 2/4/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  Unit tests for CharLinkedList class. Each function defined in the
 *  CharLinkedList class is tested here. Based on unit tests for CharArrayList.
 *
 */
#include "CharLinkedList.h"
#include <cassert>


// Tests the default constructor.
void default_constructor_test() {
    CharLinkedList test_list;
    assert(test_list.size() == 0);
}

// Tests the single-char constructor.
void single_char_constructor_test() {
    CharLinkedList test_list('a');
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');
}

// Tests the char array constructor.
void char_array_constructor_test() {
    char test_arr[3] = { 'a', 'b', 'c' };
    CharLinkedList test_list(test_arr, 3);
    assert(test_list.size() == 3);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    assert(test_list.elementAt(2) == 'c');
}

// Tests the char array constructor with an empty array.
void char_array_constructor_empty_test() {
    char test_arr[0] = {};
    CharLinkedList test_list(test_arr, 0);
    assert(test_list.size() == 0);
}

// Tests the copy constructor.
void copy_constructor_test() {
    char test_arr[3] = { 'a', 'b', 'c' };
    CharLinkedList test_list(test_arr, 3);
    CharLinkedList test_list_copy(test_list);
    assert(test_list_copy.size() == 3);
    assert(test_list_copy.elementAt(0) == 'a');
    assert(test_list_copy.elementAt(1) == 'b');
    assert(test_list_copy.elementAt(2) == 'c');
}

// Tests the copy constructor with an empty list.
void copy_constructor_empty_test() {
    CharLinkedList test_list;
    CharLinkedList test_list_copy(test_list);
    assert(test_list_copy.size() == 0);
}

// Tests the assignment operator.
void assignment_operator_test() {
    char test_arr[3] = { 'a', 'b', 'c' };
    CharLinkedList test_list(test_arr, 3);
    CharLinkedList test_list_copy;
    test_list_copy.pushAtBack('d');
    test_list_copy.pushAtBack('e');
    test_list_copy = test_list;
    assert(test_list_copy.size() == 3);
    assert(test_list_copy.elementAt(0) == 'a');
    assert(test_list_copy.elementAt(1) == 'b');
    assert(test_list_copy.elementAt(2) == 'c');
}

// Tests the assignment operator with an empty list.
void assignment_operator_empty_test() {
    CharLinkedList test_list;
    CharLinkedList test_list_copy;
    test_list_copy.pushAtBack('a');
    test_list_copy = test_list;
    assert(test_list_copy.size() == 0);
}

// Tests the isEmpty function.
void isEmpty_test() {
    CharLinkedList test_list;
    assert(test_list.isEmpty());

    test_list.pushAtBack('a');
    assert(not test_list.isEmpty());
}

// Tests the clear function.
void clear_test() {
    CharLinkedList test_list;
    test_list.pushAtBack('a');
    test_list.pushAtBack('b');
    test_list.pushAtBack('c');
    test_list.clear();
    assert(test_list.size() == 0);

    test_list.clear();
    assert(test_list.size() == 0);
}

// Tests the size function.
void size_test() {
    CharLinkedList test_list;
    assert(test_list.size() == 0);

    test_list.pushAtBack('a');
    test_list.pushAtBack('b');
    test_list.pushAtBack('c');
    assert(test_list.size() == 3);
}

// Tests the first, last, and elementAt function.
void first_last_elementAt_test() {
    CharLinkedList test_list;
    test_list.pushAtBack('a');
    test_list.pushAtBack('b');
    test_list.pushAtBack('c');
    assert(test_list.first() == 'a');
    assert(test_list.last() == 'c');
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    assert(test_list.elementAt(2) == 'c');
}

// Tests the first and last function with an empty list.
void first_last_empty_test() {
    CharLinkedList test_list;
    try {
        test_list.first();

        throw std::logic_error("first() should have thrown a runtime_error");
    } catch (const std::runtime_error &e) {
        cout << e.what() << endl;
        assert(e.what() == std::string("cannot get first of empty LinkedList"));
    }

    try {
        test_list.last();

        throw std::logic_error("last() should have thrown a runtime_error");
    } catch (const std::runtime_error &e) {
        assert(e.what() == std::string("cannot get last of empty LinkedList"));
    }
}


// Tests the elementAt function with an out-of-range index.
void elementAt_out_of_range_test() {
    CharLinkedList test_list;
    test_list.pushAtBack('a');
    test_list.pushAtBack('b');
    test_list.pushAtBack('c');
    try {
        test_list.elementAt(3);

        throw std::logic_error("elementAt() should have thrown a range_error");
    } catch (const std::range_error &e) {
        assert(e.what() == std::string("index (3) not in range [0..3)"));
    }
}

// Tests the toString and toReverseString function.
void toString_test() {
    CharLinkedList test_list;
    assert(test_list.toString() == "[CharLinkedList of size 0 <<>>]");
    assert(test_list.toReverseString() == "[CharLinkedList of size 0 <<>>]");

    test_list.pushAtBack('a');
    assert(test_list.toString() == "[CharLinkedList of size 1 <<a>>]");
    assert(test_list.toReverseString() == "[CharLinkedList of size 1 <<a>>]");

    test_list.pushAtBack('b');
    assert(test_list.toString() == "[CharLinkedList of size 2 <<ab>>]");
    assert(test_list.toReverseString() == "[CharLinkedList of size 2 <<ba>>]");

    test_list.pushAtBack('c');
    assert(test_list.toString() == "[CharLinkedList of size 3 <<abc>>]");
    assert(test_list.toReverseString() == "[CharLinkedList of size 3 <<cba>>]");
}

// Tests the pushAtBack and pushAtFront function.
void pushAtBack_pushAtFront_test() {
    CharLinkedList test_list;
    test_list.pushAtBack('a');
    test_list.pushAtBack('b');
    test_list.pushAtBack('c');
    assert(test_list.toString() == "[CharLinkedList of size 3 <<abc>>]");

    test_list.pushAtFront('d');
    test_list.pushAtFront('e');
    test_list.pushAtFront('f');
    assert(test_list.toString() == "[CharLinkedList of size 6 <<fedabc>>]");
}

// Tests the insertInOrder function.
void insertInOrder_test() {
    CharLinkedList test_list;
    test_list.insertInOrder('c');
    test_list.insertInOrder('a');
    test_list.insertInOrder('b');
    cout << test_list.toString() << endl;
    assert(test_list.toString() == "[CharLinkedList of size 3 <<abc>>]");

    test_list.insertInOrder('f');
    test_list.insertInOrder('d');
    test_list.insertInOrder('e');
    assert(test_list.toString() == "[CharLinkedList of size 6 <<abcdef>>]");
}

// Tests the popFromFront and popFromBack function.
void popFromFront_popFromBack_test() {
    CharLinkedList test_list;
    test_list.pushAtBack('a');
    test_list.pushAtBack('b');
    test_list.pushAtBack('c');
    assert(test_list.toString() == "[CharLinkedList of size 3 <<abc>>]");

    test_list.popFromFront();
    assert(test_list.toString() == "[CharLinkedList of size 2 <<bc>>]");

    test_list.popFromBack();
    assert(test_list.toString() == "[CharLinkedList of size 1 <<b>>]");

    test_list.popFromFront();
    assert(test_list.toString() == "[CharLinkedList of size 0 <<>>]");
}

// Tests the popFromFront and popFromBack function with an empty list.
void popFromFront_popFromBack_empty_test() {
    CharLinkedList test_list;
    try {
        test_list.popFromFront();

        throw std::logic_error("popFromFront() should have thrown a "
                               "runtime_error");
    } catch (const std::runtime_error &e) {
        assert(e.what() == std::string("cannot pop from empty LinkedList"));
    }

    try {
        test_list.popFromBack();

        throw std::logic_error("popFromBack() should have thrown a "
                               "runtime_error");
    } catch (const std::runtime_error &e) {
        assert(e.what() == std::string("cannot pop from empty LinkedList"));
    }
}


// Tests the removeAt function.
void removeAt_test() {
    CharLinkedList test_list;
    test_list.pushAtBack('a');
    test_list.pushAtBack('b');
    test_list.pushAtBack('c');
    assert(test_list.toString() == "[CharLinkedList of size 3 <<abc>>]");

    test_list.removeAt(1);
    assert(test_list.toString() == "[CharLinkedList of size 2 <<ac>>]");

    test_list.removeAt(0);
    assert(test_list.toString() == "[CharLinkedList of size 1 <<c>>]");

    test_list.removeAt(0);
    assert(test_list.toString() == "[CharLinkedList of size 0 <<>>]");
}

// Tests the removeAt function with an out-of-range index.
void removeAt_out_of_range_test() {
    CharLinkedList test_list;
    test_list.pushAtBack('a');
    test_list.pushAtBack('b');
    test_list.pushAtBack('c');
    try {
        test_list.removeAt(3);

        throw std::logic_error("removeAt() should have thrown a range_error");
    } catch (const std::range_error &e) {
        assert(e.what() == std::string("index (3) not in range [0..3)"));
    }
}

// Tests the replaceAt function.
void replaceAt_test() {
    CharLinkedList test_list;
    test_list.pushAtBack('a');
    test_list.pushAtBack('b');
    test_list.pushAtBack('c');
    assert(test_list.toString() == "[CharLinkedList of size 3 <<abc>>]");

    test_list.replaceAt('d', 1);
    assert(test_list.toString() == "[CharLinkedList of size 3 <<adc>>]");

    test_list.replaceAt('e', 0);
    assert(test_list.toString() == "[CharLinkedList of size 3 <<edc>>]");

    test_list.replaceAt('f', 2);
    assert(test_list.toString() == "[CharLinkedList of size 3 <<edf>>]");
}

// Tests the replaceAt function with an out-of-range index.
void replaceAt_out_of_range_test() {
    CharLinkedList test_list;
    test_list.pushAtBack('a');
    test_list.pushAtBack('b');
    test_list.pushAtBack('c');
    try {
        test_list.replaceAt('d', 3);

        throw std::logic_error("replaceAt() should have thrown a range_error");
    } catch (const std::range_error &e) {
        assert(e.what() == std::string("index (3) not in range [0..3)"));
    }
}

// Tests the concatenate function.
void concatenate_test() {
    CharLinkedList test_list;
    test_list.pushAtBack('a');
    test_list.pushAtBack('b');
    test_list.pushAtBack('c');

    CharLinkedList test_list2;
    test_list2.pushAtBack('d');
    test_list2.pushAtBack('e');
    test_list2.pushAtBack('f');

    test_list.concatenate(&test_list2);
    assert(test_list.toString() == "[CharLinkedList of size 6 <<abcdef>>]");
}

// Tests the concatenate function with an empty list.
void concatenate_empty_test() {
    CharLinkedList test_list;
    CharLinkedList test_list2;
    test_list2.pushAtBack('a');
    test_list2.pushAtBack('b');
    test_list2.pushAtBack('c');

    test_list.concatenate(&test_list2);
    assert(test_list.toString() == "[CharLinkedList of size 3 <<abc>>]");
}

// Tests the concatenate function with self.
void concatenate_self_test() {
    CharLinkedList test_list;
    test_list.pushAtBack('a');
    test_list.pushAtBack('b');
    test_list.pushAtBack('c');

    test_list.concatenate(&test_list);
    assert(test_list.toString() == "[CharLinkedList of size 6 <<abcabc>>]");
}

// Tests correct insertion into an empty AL.
// Afterwards, size should be 1 and element at index 0
// should be the element we inserted.
void insertAt_empty_correct() { 

    CharLinkedList test_list;
    test_list.insertAt('a', 0);

    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');

}

// Tests incorrect insertion into an empty AL.
// Attempts to call insertAt for index larger than 0.
// This should result in an std::range_error being raised.
void insertAt_empty_incorrect() {

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    // insertAt for out-of-range index
    test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
    // if insertAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    range_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0]");
    
}

// Tests correct insertAt for front of 1-element list.
void insertAt_front_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at front
    test_list.insertAt('b', 0);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'a');
    
}

// Tests correct insertAt for back of 1-element list.
void insertAt_back_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at back
    test_list.insertAt('b', 1);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    
}

// Tests calling insertAt for a large number of elements.
// Not only does this test insertAt, it also checks that
// array expansion works correctly.
void insertAt_many_elements() {
    
    CharLinkedList test_list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.insertAt('a', i);
    }

    assert(test_list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
    
}

// Tests insertion into front of a larger list
void insertAt_front_large_list() {
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    test_list.insertAt('y', 0);

    assert(test_list.size() == 10);
    assert(test_list.elementAt(0) == 'y');
    assert(test_list.toString() == 
           "[CharLinkedList of size 10 <<yabczdefgh>>]");

}

// Tests insertion into the back of a larger list
void insertAt_back_large_list() {

    char test_arr[10] = { 'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 10);  

    test_list.insertAt('x', 10);

    assert(test_list.size() == 11);
    assert(test_list.elementAt(10) == 'x');
    assert(test_list.toString() == 
    "[CharLinkedList of size 11 <<yabczdefghx>>]"); 

}

// Tests insertion into the middle of a larger list
void insertAt_middle_large_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.insertAt('z', 3);

    assert(test_list.size() == 9);
    assert(test_list.elementAt(3) == 'z');
    assert(test_list.toString() == "[CharLinkedList of size 9 <<abczdefgh>>]");

}

// Tests out-of-range insertion for a non-empty list.
void insertAt_nonempty_incorrect() {
   
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8]");
    
}

/*
 *  CharLinkedList.cpp
 *  Larry Qiu (lqiu01)
 *  2/4/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Implementation of CharLinkedList class. Each function listed in the
 *  declaration file is implemented here.
 *
 */

#include "CharLinkedList.h"
#include <stdexcept>
#include <sstream>
#include <string>
#include <iostream>

using namespace std;

/**
 * CharLinkedList default constructor
 * purpose: initialize an empty CharLinkedList
 * arguments: none
 * returns: none
 * effects: numItems = 0, list is empty
*/
CharLinkedList::CharLinkedList(){
    front = nullptr;
    back = nullptr;
    numItems = 0;
}

/**
 * CharLinkedList constructor w/ single char
 * purpose: initialize a CharLinkedList with a single char
 * arguments: the character to initialize the list with
 * returns: none
 * effects: numItems = 1, list has one element c
*/
CharLinkedList::CharLinkedList(char c){
    front = nullptr;
    back = nullptr;
    numItems = 0;
    
    pushAtBack(c);
}

/**
 * CharLinkedList constructor w/ char array
 * purpose: initialize a CharLinkedList with a char array
 * arguments: the array to initialize the list with, the size of the array
 * returns: none
 * effects: numItems = arrSize, list has elements from arr
*/
CharLinkedList::CharLinkedList(char arr[], int arrSize){
    front = nullptr;
    back = nullptr;
    numItems = 0;

    for (int i = 0; i < arrSize; i++){
        pushAtBack(arr[i]);
    }
}

/**
 * CharLinkedList copy constructor
 * purpose: initialize a CharLinkedList using another CharLinkedList
 * arguments: the CharLinkedList to copy
 * returns: none
 * effects: numItems = other.numItems, list has elements from other
*/
CharLinkedList::CharLinkedList(const CharLinkedList &other) {
    front = nullptr;
    back = nullptr;
    numItems = 0;
    
    (*this) = other;
}

/**
 * CharLinkedList destructor
 * purpose: deallocate memory for the CharLinkedList
 * arguments: none
 * returns: none
 * effects: all memory associated with the CharLinkedList is freed
 * note: this function is calls the recursive clear function
*/
CharLinkedList::~CharLinkedList() {
    clear(front);
}

/**
 * CharLinkedList assignment operator
 * purpose: assign a CharLinkedList to another CharLinkedList
 * arguments: the CharLinkedList to assign
 * returns: the assigned CharLinkedList
 * effects: the current CharLinkedList is cleared and then filled with 
 *          the elements of other
*/
CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other) {
    if (this != &other) {
        clear();
        for (int i = 0; i < other.size(); i++) {
            pushAtBack(other.elementAt(i));
        }
    }
    return *this;
}

/**
 * isEmpty
 * purpose: check if the CharLinkedList is empty
 * arguments: none
 * returns: true if the list is empty, false otherwise
 * effects: none
*/
bool CharLinkedList::isEmpty() const {
    return numItems == 0;
}

/**
 * clear
 * purpose: clear the CharLinkedList
 * arguments: none
 * returns: none
 * effects: all memory associated with the CharLinkedList is freed
 * note: this function is calls the recursive clear function
*/
void CharLinkedList::clear() {
    clear(front);

    front = nullptr;
    back = nullptr;
    numItems = 0;
}

/**
 * clear
 * purpose: private helper function to clear the CharLinkedList
 * arguments: the current node to clear
 * returns: none
 * effects: the node and all subsequent nodes are deleted
 * note: this function is recursive
*/
void CharLinkedList::clear(Node *curr) {
    if (curr != nullptr) {
        Node* next = curr->next;
        delete curr;
        clear(next);
    }
}

/**
 * size
 * purpose: get the size of the CharLinkedList
 * arguments: none
 * returns: the size of the list
 * effects: none
*/
int CharLinkedList::size() const {
    return numItems;
}

/**
 * first
 * purpose: get the first element of the CharLinkedList
 * arguments: none
 * returns: the first element of the list
 * effects: none
 * note: throws runtime_error if the list is empty
*/
char CharLinkedList::first() const {
    if (isEmpty()) {
        throw runtime_error("cannot get first of empty LinkedList");
    }
    return front->c;
}

/**
 * last
 * purpose: get the last element of the CharLinkedList
 * arguments: none
 * returns: the last element of the list
 * effects: none
 * note: throws runtime_error if the list is empty
*/
char CharLinkedList::last() const {
    if (isEmpty()) {
        throw runtime_error("cannot get last of empty LinkedList");
    }
    return back->c;
}

/**
 * elementAt
 * purpose: get the element at a specific index of the CharLinkedList
 * arguments: the index of the element to get
 * returns: the element at the index
 * effects: none
 * note: throws range_error if the index is out of range. uses the recursive
 *       nodeAt function to find the node at the index
*/
char CharLinkedList::elementAt(int index) const {
    if (index < 0 or index >= numItems) {
        string error = "index (" + to_string(index) + ") not in range [0.."
                       + to_string(numItems) + ")";
        throw range_error(error);
    }
    return nodeAt(index, front) -> c;
}

/**
 * nodeAt
 * purpose: private helper function to get the node at a specific index
 * arguments: the number of nodes to hop, the current node
 * returns: the node after hopping "index" times
 * effects: none
 * note: this function is recursive
*/
CharLinkedList::Node* CharLinkedList::nodeAt(int index, Node *curr) const {
    if (index == 0) {
        return curr;
    }
    return nodeAt(index - 1, curr->next);
}

/**
 * toString
 * purpose: get a string representation of the CharLinkedList
 * arguments: none
 * returns: a string representation of the list
 * effects: none
*/
string CharLinkedList::toString() const {
    stringstream ss;
    ss << "[CharLinkedList of size " << numItems << " <<";

    Node *curr = front;
    while (curr != nullptr) {
        ss << curr->c;
        curr = curr->next;
    }
    ss << ">>]";

    return ss.str();
}

/**
 * toReverseString
 * purpose: get a string representation of the CharLinkedList in reverse
 * arguments: none
 * returns: a string representation of the list in reverse
 * effects: none
*/
string CharLinkedList::toReverseString() const {
    stringstream ss;
    ss << "[CharLinkedList of size " << numItems << " <<";

    Node *curr = back;
    while (curr != nullptr) {
        ss << curr->c;
        curr = curr->prev;
    }
    ss << ">>]";

    return ss.str();
}

/**
 * pushAtBack
 * purpose: add an item to the end of the CharLinkedList
 * arguments: char c
 * returns: none
 * effects: list has c inserted at end
*/
void CharLinkedList::pushAtBack(char c) {
    insertAfter(c, back);
}

/**
 * pushAtFront
 * purpose: add an item to the front of the CharLinkedList
 * arguments: char c
 * returns: none
 * effects: list has c inserted at front
*/
void CharLinkedList::pushAtFront(char c) {
    insertAfter(c, nullptr);
}

/**
 * insertAt
 * purpose: insert an item at a specific index of the CharLinkedList
 * arguments: char c, the index to insert at
 * returns: none
 * effects: list has c inserted at index
*/
void CharLinkedList::insertAt(char c, int index){
    if (index < 0 or index > numItems) {
        string error = "index (" + to_string(index) + ") not in range [0.."
                       + to_string(numItems) + "]";
        throw range_error(error);
    }
    
    if (index == 0) {
        pushAtFront(c);
    } else {
        insertAfter(c, nodeAt(index - 1, front));
    }
}

/**
 * insertAfter
 * purpose: private helper function to insert an item after a specific node
 * arguments: char c, the node to insert after
 * returns: none
 * effects: list has c inserted after curr
 * note: if curr is nullptr, c is inserted at the front of the list
*/
void CharLinkedList::insertAfter(char c, Node *curr){
    Node *next = curr == nullptr ? front : curr->next;

    Node *newNode = new Node();
    newNode->c = c;
    newNode->next = next;
    newNode->prev = curr;
    if (curr != nullptr) {
        curr->next = newNode;
    } else {
        front = newNode;
    }
    if (next != nullptr) {
        next->prev = newNode;
    } else {
        back = newNode;
    }
    numItems++;
}

/**
 * insertInOrder
 * purpose: insert an item into the CharLinkedList in order
 * arguments: char c
 * returns: none
 * effects: list has c inserted in order
 * note: this function assumes the list is already in order
*/
void CharLinkedList::insertInOrder(char c) {
    Node *curr = front;
    while (curr != nullptr and c > curr->c) {
        curr = curr->next;
    }

    if (curr == nullptr) {
        pushAtBack(c);
    } else {
        insertAfter(c, curr->prev);
    }
}

/**
 * popFromFront
 * purpose: remove an item from the front of the CharLinkedList
 * arguments: none
 * returns: none
 * effects: list has first element removed
 * note: throws runtime_error if the list is empty
*/
void CharLinkedList::popFromFront() {
    if (isEmpty()) {
        throw runtime_error("cannot pop from empty LinkedList");
    }
    removeNode(front);
}

/**
 * popFromBack
 * purpose: remove an item from the back of the CharLinkedList
 * arguments: none
 * returns: none
 * effects: list has last element removed
 * note: throws runtime_error if the list is empty
*/
void CharLinkedList::popFromBack() {
    if (isEmpty()) {
        throw runtime_error("cannot pop from empty LinkedList");
    }
    removeNode(back);
}

/**
 * removeAt
 * purpose: remove an item at a specific index of the CharLinkedList
 * arguments: the index to remove
 * returns: none
 * effects: list has element at index removed
 * note: throws range_error if the index is out of range, uses the
 *       recursive nodeAt function to find the node at the index
*/
void CharLinkedList::removeAt(int index) {
    if (index < 0 or index >= numItems) {
        string error = "index (" + to_string(index) + ") not in range [0.."
                       + to_string(numItems) + ")";
        throw range_error(error);
    }
    removeNode(nodeAt(index, front));
}

/**
 * removeNode
 * purpose: private helper function to remove a specific node from the list
 * arguments: the node to remove
 * returns: none
 * effects: list has curr removed
*/
void CharLinkedList::removeNode(Node *curr) {
    Node *next = curr->next;
    Node *prev = curr->prev;
    if (prev != nullptr) {
        prev->next = next;
    } else {
        front = next;
    }
    if (next != nullptr) {
        next->prev = prev;
    } else {
        back = prev;
    }
    delete curr;
    numItems--;
}

/**
 * replaceAt
 * purpose: replace an item at a specific index of the CharLinkedList
 * arguments: char c, the index to replace
 * returns: none
 * effects: list has element at index replaced with c
 * note: throws range_error if the index is out of range, uses the
 *       recursive nodeAt function to find the node at the index
*/
void CharLinkedList::replaceAt(char c, int index) {
    if (index < 0 or index >= numItems) {
        string error = "index (" + to_string(index) + ") not in range [0.."
                       + to_string(numItems) + ")";
        throw range_error(error);
    }
    nodeAt(index, front)->c = c;
}

/**
 * concatenate
 * purpose: concatenate another CharLinkedList to the end of this CharLinkedList
 * arguments: CharLinkedList *other
 * returns: none
 * effects: other is appended to the end of this CharLinkedList
 * note: if this and the other list are the same, the list is appended to itself
*/
void CharLinkedList::concatenate(CharLinkedList *other) {
    int otherSize = other->size();
    for (int i = 0; i < otherSize; i++) {
        pushAtBack(other->elementAt(i));
    }
}


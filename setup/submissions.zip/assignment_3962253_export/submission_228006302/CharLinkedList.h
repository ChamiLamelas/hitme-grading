/*
 *  CharLinkedList.h
 *  Larry Qiu (lqiu01)
 *  2/4/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  This file declares the CharLinkedList class. Each function listed in the
 *  homework assignment is implemented in this file. Additionally, additional
 *  private helper functions are declared that are used to implement the
 *  public functions. 
 */

#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H

#include <string>

using namespace std;

class CharLinkedList {
public:
    CharLinkedList();
    CharLinkedList(char c);
    CharLinkedList(char arr[], int size);
    CharLinkedList(const CharLinkedList &other);

    ~CharLinkedList();

    CharLinkedList &operator=(const CharLinkedList &other);

    bool isEmpty() const;
    void clear();
    int size() const;
    char first() const;
    char last() const;
    char elementAt(int index) const;
    string toString() const;
    string toReverseString() const;

    void pushAtBack(char c);
    void pushAtFront(char c);
    void insertAt(char c, int index);
    void insertInOrder(char c);
    void popFromFront();
    void popFromBack();
    void removeAt(int index);
    void replaceAt(char c, int index);
    void concatenate(CharLinkedList *other);

private:
    struct Node {
        char c;
        Node *next;
        Node *prev;
    };

    Node *front;
    Node *back;
    int numItems;

    void clear(Node *curr);
    Node *nodeAt(int index, Node *curr) const;
    void insertAfter(char c, Node *curr);
    void removeNode(Node *curr);
};

#endif

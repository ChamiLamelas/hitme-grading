/*
 *  unit_tests.h
 *  Erica Huang
 *  2/1/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  FILE PURPOSE HERE
 *
 */

#include "CharLinkedList.h"
#include <cassert>

using namespace std;

// /*
//  * dafult constructor leak test
//  * Make sure no leaks or errors in the default constructor
//  */
// void default_constructor_leak(){
//     CharLinkedList list;
// }

// /*
//  * dafult constructor size test
//  * Make sure all size is correct
// */
// void default_constructor_size(){
//     CharLinkedList list;
//     assert(list.size() == 0);
// }

// /*
//  * dafult constructor isEmpty test
//  * Make sure all size is correct
// */
// void default_constructor_isEmpty(){
//     CharLinkedList list;
//     assert(list.isEmpty());
// }










// /*
//     * char constructor leak test
//     * Make sure no leaks or errors in constructor 
//     * that takes in one character
// */
// void char_constructor_leak(){
//     CharLinkedList list('a');
// }

// /*
//     * char constructor size test
//     * Make sure correct size
// */
// void char_constructor_size(){
//     CharLinkedList list('a');
//     assert(list.size() == 1);
// }


// /*
//     * char constructor correct char test
//     * Makes sure char in Linked list is same as input
// */
// void char_constructor_correct_char(){
//     CharLinkedList list('a');
//     assert(list.first() == 'a');
// }








// /*
//     * arr constructor leak test
//     * Make sure no leaks or errors in constructor 
//     * that takes in arr of characters and size of arr
// */
// void arr_constructor_leak(){
//     char arr[4] = {'a', 'b', 'c', 'd'};
//     CharLinkedList list(arr, 4);
// }

// /*
// * arr constructor correct copy test
// * Makes arr[] is copied correctly into the linked list
// */
// void arr_constructor_correct_copy(){
//     char arr[3] = {'c', 'a', 't'};
//     CharLinkedList list(arr, 3);

//     for (int i = 0; i < 3; i++){
//         assert(list.toString() == "[CharLinkedList of size 3 <<cat>>]");
//     }
// }








// /*
// * copy constructor copy test multiple char
// * Makes sure list is copied correctly
// */
// void copy_constructor_multiple_char(){
//     char arr[3] = {'c', 'a', 't'};
//     CharLinkedList list1(arr, 3);
//     CharLinkedList list2(list1);
//     // cout << list2.size() << endl;
//     // cout << list2.getCapacity() << endl;
//     // cout << list2.toString() << endl;
//     assert(list1.toString() == list2.toString());
// }


// /*
// * copy constructor copy test one char
// * Makes sure list is copied correctly
// */
// void copy_constructor_one_char(){
//     CharLinkedList list1('a');
//     CharLinkedList list2(list1);
//     assert(list1.toString() == list2.toString());
// }

// /*
// * copy constructor empty list
// * Makes sure list is copied correctly
// */
// void copy_constructor_empty(){
//     CharLinkedList list1;
//     CharLinkedList list2(list1);
//     cout << list1.toString() << endl;
//     cout << list2.toString() << endl;
//     assert(list1.isEmpty());
//     assert(list1.size() == list2.size());
// }






// /*
// * operator 1st list empty 2nd full
// * Makes sure list is copied correctly
// */
// void operator_first_empty_second_full(){
//     CharLinkedList list1;
//     char arr[3] = {'c', 'a', 't'};
//     CharLinkedList list2(arr, 3);
//     list1 = list2;

//     assert(list1.toString() == list2.toString());
// }

// /*
// * operator 1st list full 2nd empty
// * Makes sure list is copied correctly
// */
// void operator_first_full_second_empty(){
//     char arr[3] = {'c', 'a', 't'};
//     CharLinkedList list1(arr, 3);
//     CharLinkedList list2;
//     list1 = list2;

//     assert(list1.toString() == list2.toString());
// }

// /*
// * operator both lists full
// * Makes sure list is copied correctly
// */
// void operator_both_full(){
//     char arr1[3] = {'c', 'a', 't'};
//     CharLinkedList list1(arr1, 3);
//     char arr2[3] = {'b', 'd', 'v'};
//     CharLinkedList list2(arr2, 3);
//     list1 = list2;

//     assert(list1.toString() == list2.toString());
// }

// /*
// * operator both lists empty
// * Makes sure list is copied correctly
// */
// void operator_both_empty(){
//     CharLinkedList list1;
//     CharLinkedList list2;
//     list1 = list2;

//     assert(list1.toString() == list2.toString());
// }

// /*
// * operator first list bigger than second
// * Makes sure list is copied correctly
// */
// void operator_first_bigger_than_second(){
//     char arr1[5] = {'c', 'a', 't', 'd', 'f'};
//     CharLinkedList list1(arr1, 3);
//     char arr2[4] = {'b', 'd', 'v', '1'};
//     CharLinkedList list2(arr2, 4);
//     list1 = list2;
    
//     assert(list1.toString() == list2.toString());
// }

// /*
// * operator first list smaller than second
// * Makes sure list is copied correctly
// */
// void operator_first_smaller_than_second(){
//     char arr1[2] = {'c', 'a'};
//     CharLinkedList list1(arr1, 3);
//     char arr2[4] = {'b', 'd', 'v', '1'};
//     CharLinkedList list2(arr2, 4);
//     list1 = list2;
    
//     assert(list1.toString() == list2.toString());
// }







// /*
//  * isEmpty empty Linked
//  * makes sure isEmpty returns true with a new (empty) Linked list
//  */
//  void isEmpty_empty(){
//     CharLinkedList list;
//     cout << list.size() << endl;
//     assert(list.isEmpty());
//  }

// /*
//  * isEmpty full Linked (no pushback)
//  * makes sure isEmpty returns false with full Linked
//  */
// void isEmpty_full(){
//     CharLinkedList list('d');
//     assert(not list.isEmpty());
// }

// /*
//  * isEmpty pushback onto empty linked list
//  * makes sure isEmpty returns false
//  */
// void isEmpty_pushAtBack_onto_empty(){
//     CharLinkedList list;
//     list.pushAtBack('f');
//     assert(not list.isEmpty());
// }

// /*
//  * isEmpty pushback onto full linked list
//  * makes sure isEmpty returns false
//  */
// void isEmpty_pushAtBack_onto_full(){
//     char arr[4] = {'s', 'x', 'd', 'h'};
//     CharLinkedList list(arr, 4);
//     list.pushAtBack('d');
//     assert(not list.isEmpty());
// }

// /*
//  * isEmpty popFromBack multiple char
//  * makes sure isEmpty returns false
//  */
// void isEmpty_popFromBack_multiple_char(){
//     char arr[4] = {'s', 'x', 'd', 'h'};
//     CharLinkedList list(arr, 4);
//     list.popFromBack();
//     assert(not list.isEmpty());
// }

// /*
//  * isEmpty popFromBack one char
//  * makes sure isEmpty returns true
//  */
// void isEmpty_popFromBack_one_char(){
//     CharLinkedList list('f');
//     list.popFromBack();
//     assert(list.isEmpty());
// }







// /*
//  * size mulitple pushbacks
//  * Make sure size is correct when list is
//  * pushed back multiple times
// */
// void size_multiple_pushBack_(){
//     CharLinkedList list;
//     list.pushAtBack('a');
//     list.pushAtBack('a');
//     list.pushAtBack('a');
//     list.pushAtBack('a');
//     assert(list.size() == 4);
// }

// /*
//  * size with 4 elements
//  * Make sure size is correct when list is filled
// */
// void size_four_elements(){
//     char arr[4] = {'s', 'x', 'd', 'h'};
//     CharLinkedList list(arr, 4);
//     assert(list.size() == 4);
// }

// /*
//  * size after pushAtBack
//  * Make sure size is correct after adding elements to back
// */
// void size_pushAtBack(){
//     char arr[4] = {'s', 'x', 'd', 'h'};
//     CharLinkedList list(arr, 4);
//     list.pushAtBack('p');
//     assert(list.size() == 5);
// }

// /*
//  * size after pushAtFront
//  * Make sure size is correct after adding elements to front
// */
// void size_pushAtFront(){
//     char arr[7] = {'s', 'x', 'd', 'h', 'f', '2', 's'};
//     CharLinkedList list(arr, 7);
//     list.pushAtFront('p');
//     assert(list.size() == 8);
// }

// /*
//  * size after clearing
//  * Make sure size is correct when list is clear
// */
// void size_clear(){
//     char arr[4] = {'s', 'x', 'd', 'h'};
//     CharLinkedList list(arr, 4);
//     list.clear();
//     assert(list.size() == 0);
// }

// /*
//  * size after inserting elements
//  * Make sure size is correct when list is clear
// */
// void size_insertAt(){
//     char arr[4] = {'s', 'x', 'd', 'h'};
//     CharLinkedList list(arr, 4);
//     list.insertAt('p', 2);
//     assert(list.size() == 5);
// }

// /*
//  * size after removing elements
//  * Make sure size is correct when list is clear
// */
// void size_removing(){
//     char arr[4] = {'s', 'x', 'd', 'h'};
//     CharLinkedList list(arr, 4);
//     cout << list.size() << endl;
//     list.removeAt(3);
//     cout << list.size() << endl;
//     assert(list.size() == 3);
// }

// /*
//  * size after adding then removing elements
//  * Make sure size is correct when list is clear
// */
// void size_adding_and_removing(){
//     char arr[4] = {'s', 'x', 'd', 'h'};
//     CharLinkedList list(arr, 4);
//     list.insertAt('p', 2);
//     cout << list.toString() << endl;
//     list.removeAt(4);
//     cout << list.toString() << endl;
//     cout << list.size() << endl;
//     assert(list.size() == 4);
// }




// /*
//  * pushAtBack empty list
//  * makes sure character is pushed correctly
//  */
// void pushAtBack_empty_list(){
//     CharLinkedList list;
//     list.pushAtBack('a');
//     assert(list.first() == 'a');
// }


// /*
//  * pushAtBack full list
//  * makes sure character is pushed correctly
//  */
// void pushAtBack_full_list(){
//     char arr[4] = {'a', 'b', 'c', 'd'};
//     CharLinkedList list(arr, 4);
//     list.pushAtBack('e');
//     cout << list.first() << endl;
//     cout << list.last() << endl;
//     cout << list.size() << endl;
//     assert(list.last() == 'e');
// }


// /*
//  * pushAtBack multiple times
//  * makes sure pushes at very end each time not j at end of 
//  * og list
//  */
// void pushAtBack_multiple_times(){
//     char arr[4] = {'a', 'b', 'c', 'd'};
//     CharLinkedList list(arr, 4);
//     //push back once to double capacity
//     list.pushAtBack('e');
//     list.pushAtBack('f');
//     list.pushAtBack('g');
//     assert(list.toString() == "[CharLinkedList of size 7 <<abcdefg>>]");
// }

// /*
//  * pushAtBack after clearing
//  * makes sure character is pushed correctly
//  */
// void pushAtBack_after_clearing(){
//     char arr[4] = {'a', 'b', 'c', 'd'};
//     CharLinkedList list(arr, 4);
//     list.clear();
//     //push back once to double capacity
//     list.pushAtBack('e');
//     assert(list.toString() == "[CharLinkedList of size 1 <<e>>]");
// }







// /*
//  * pushAtFront empty list
//  * makes sure character is pushed correctly
//  */
// void pushAtFront_empty_list(){
//     CharLinkedList list;
//     list.pushAtFront('g');
//     assert(list.first() == 'g');
// }

// /*
//  * pushAtFront full list
//  * makes sure can push front onto full list 
//  * (capacity needs to increase)
//  */
// void pushAtFront_full_list(){
//     char arr[4] = {'a', 'b', 'c', 'd'};
//     CharLinkedList list(arr, 4);
//     list.pushAtFront('e');
//     assert(list.first() == 'e');
// }


// /*
//  * pushAtFront multiple times
//  * makes sure pushes at very end each time not j at end of 
//  * og list
//  */
// void pushAtFront_multiple_times(){
//     char arr[4] = {'a', 'b', 'c', 'd'};
//     CharLinkedList list(arr, 4);
//     //push back once to double capacity
//     list.pushAtFront('3');
//     list.pushAtFront('2');
//     list.pushAtFront('1');
//     assert(list.toString() == "[CharLinkedList of size 7 <<123abcd>>]");
// }

// /*
//  * pushAtFront after clearing
//  * makes sure character is pushed correctly
//  */
// void pushAtFront_after_clearing(){
//     char arr[4] = {'a', 'b', 'c', 'd'};
//     CharLinkedList list(arr, 4);
//     list.clear();
//     //push back once to double capacity
//     list.pushAtFront('e');
//     assert(list.toString() == "[CharLinkedList of size 1 <<e>>]");
// }




// /*
//  * toString test no pushing elements onto list
//  * makes sure toString works with an list made with the list 
//  * constructor
//  * (no pushbacks)
//  */

// void toString_no_pushing_elements(){
//     char arr[4] = {'a', 'b', 'c', 'd'};
//     CharLinkedList list(arr, 4);
//     string s = list.toString();
//     cout << s << endl;
//     assert(s == "[CharLinkedList of size 4 <<abcd>>]");
// }



// /*
//  * toString test push back elements onto list
//  * makes sure toString works after pushing elements onto back 
//  * of list
//  */

// void toString_pushAtBack(){
//     char arr[4] = {'a', 'b', 'c', 'd'};
//     CharLinkedList list(arr, 4);
//     list.pushAtBack('e');
//     string s = list.toString();
//     cout << s << endl;
//     assert(s == "[CharLinkedList of size 5 <<abcde>>]");
// }



// /*
//  * toString test push front elements onto list
//  * makes sure toString works after pushing elements onto front 
//  * of list
//  */

// void toString_pushAtFront(){
//     char arr[4] = {'a', 'b', 'c', 'd'};
//     CharLinkedList list(arr, 4);
//     list.pushAtFront('e');
//     string s = list.toString();
//     cout << s << endl;
//     assert(s == "[CharLinkedList of size 5 <<eabcd>>]");
// }

// /*
//  * toString test empty list
//  * makes sure toString works with empty list
//  */
// void toString_empty_list(){
//     CharLinkedList list;
//     string s = list.toString();
//     assert(s == "[CharLinkedList of size 0 <<>>]");
// }










// /*
//  * insertAt once in middle
//  * makes sure inserts correct character into correct place
//  */
// void insertAt_once_middle(){
//     char arr[4] = {'a', 'b', 'c', 'd'};
//     CharLinkedList list(arr, 4);
//     cout << list.toString() << endl;
//     list.insertAt('z', 2);
//     cout << list.toString() << endl;
//     assert(list.toString() == "[CharLinkedList of size 5 <<abzcd>>]");
// }

// /*
//  * insertAt once in front
//  * makes sure inserts correct character into correct place
//  */
// void insertAt_once_front(){
//     char arr[4] = {'a', 'b', 'c', 'd'};
//     CharLinkedList list(arr, 4);
//     list.insertAt('z', 0);
//     assert(list.first() == 'z');
// }

// /*
//  * insertAt once in back
//  * makes sure inserts correct character into correct place
//  */
// void insertAt_once_back(){
//     char arr[4] = {'a', 'b', 'c', 'd'};
//     CharLinkedList list(arr, 4);
//     list.insertAt('z', 4);
//     assert(list.toString() == "[CharLinkedList of size 5 <<abcdz>>]");
// }

// /*
//  * insertAt multiple in middle
//  * makes sure inserts correct characters into correct place
//  */
// void insertAt_multiple_middle(){
//     char arr[4] = {'a', 'b', 'c', 'd'};
//     CharLinkedList list(arr, 4);
//     cout << list.toString() << endl;
//     list.insertAt('z', 2);
//     cout << list.toString() << endl;
//     list.insertAt('y', 2);
//     cout << list.toString() << endl;
//     list.insertAt('x', 2);
//     cout << list.toString() << endl;
//     assert(list.toString() == "[CharLinkedList of size 7 <<abxyzcd>>]");
// }

// /*
//  * insertAt multiple in front
//  * makes sure inserts correct characters into correct place
//  */
// void insertAt_multiple_front(){
//     char arr[4] = {'a', 'b', 'c', 'd'};
//     CharLinkedList list(arr, 4);
//     list.insertAt('z', 0);
//     list.insertAt('y', 0);
//     list.insertAt('x', 0);
//     assert(list.toString() == "[CharLinkedList of size 7 <<xyzabcd>>]");
// }

// /*
//  * insertAt multiple in back
//  * makes sure inserts correct characters into correct place
//  */
// void insertAt_multiple_back(){
//     char arr[4] = {'a', 'b', 'c', 'd'};
//     CharLinkedList list(arr, 4);
//     list.insertAt('x', 4);
//     list.insertAt('y', 5);
//     list.insertAt('z', 6);
//     assert(list.toString() == "[CharLinkedList of size 7 <<abcdxyz>>]");
// }

// /*
//  * insertAt out of range (invalid above)
//  * makes sure it throws range error
//  */
// void insertAt_invalid_above(){
//     bool range_error_thrown = false;
//     string error_message = "";

//     char arr[4] = {'a', 'b', 'c', 'd'};
//     try {
//         CharLinkedList list(arr, 4);
//         list.insertAt('z', 5);
//     } 
//     catch (const range_error &e){
//         range_error_thrown = true;
//         error_message = e.what();
//     }  
//     assert(range_error_thrown);
//     assert(error_message == "index (5) not in range [0..4]");
// }

// /*
//  * insertAt out of range (invalid below)
//  * makes sure it throws range error
//  */
// void insertAt_invalid_below(){
//     bool range_error_thrown = false;
//     string error_message = "";

//     char arr[4] = {'a', 'b', 'c', 'd'};
//     try {
//         CharLinkedList list(arr, 4);
//         list.insertAt('z', -1);
//     } 
//     catch (const range_error &e){
//         range_error_thrown = true;
//         error_message = e.what();
//     }  
//     assert(range_error_thrown);
//     assert(error_message == "index (-1) not in range [0..4]");
// }

// /*
//  * insertAt after last element
//  * makes sure it adds character to very end of arary list
//  */
// void insertAt_back(){
//     char arr[4] = {'a', 'b', 'c', 'd'};
//     CharLinkedList list(arr, 4);
//     list.insertAt('e', 4);
    
//     assert(list.toString() == "[CharLinkedList of size 5 <<abcde>>]");
// }

// /*
//  * insertAt empty list
//  * makes sure it adds character to very end of arary list
//  */
// void insertAt_empty_list(){
//     CharLinkedList list;
//     list.insertAt('e', 0);
    
//     assert(list.toString() == "[CharLinkedList of size 1 <<e>>]");
// }

// /*
//  * insertAt after clearing
//  * makes sure character is pushed correctly
//  */
// void insertAt_after_clearing(){
//     char arr[4] = {'a', 'b', 'c', 'd'};
//     CharLinkedList list(arr, 4);
//     list.clear();
//     //push back once to double capacity
//     list.insertAt('e', 0);
//     assert(list.toString() == "[CharLinkedList of size 1 <<e>>]");
// }







// /*
//  * clear 4 char list
//  * makes sure isEmpty is true after calling clear()
//  */
// void clear_four_char_list(){
//     char arr[4] = {'a', 'b', 'c', 'd'};
//     CharLinkedList list(arr, 4);
//     list.clear();
//     assert(list.isEmpty());
// }

// /*
//  * clear 1 char list
//  * makes sure isEmpty is true after calling clear()
//  */
// void clear_one_char_list(){
//     CharLinkedList list('d');
//     list.clear();
//     assert(list.isEmpty());
// }

// /*
//  * clear empty list
//  * makes sure isEmpty is true after calling clear()
//  */
// void clear_empty_list(){
//     CharLinkedList list;
//     list.clear();
//     assert(list.isEmpty());
// }

// /*
//  * clear push back and front list
//  * makes sure isEmpty is true after calling clear()
//  */
// void clear_push_back_and_front_list(){
//     CharLinkedList list;
//     list.pushAtBack('b');
//     list.pushAtFront('a');
//     list.clear();
//     assert(list.isEmpty());
// }










// /*
//  * elementAt 1 element list
//  * makes sure it returns correct character in a 1 element list
//  */
// void elementAt_one_char_list(){
//     CharLinkedList list('c');
//     assert(list.elementAt(0) == 'c');
// }

// /*
//  * elementAt 4 element list valid
//  * makes sure it gets correct element at given index
//  */
// void elementAt_four_element_list_valid(){
//     CharLinkedList list;
//     list.pushAtBack('a');
//     list.pushAtBack('b');
//     list.pushAtBack('c');
//     list.pushAtBack('d');
//     assert(list.elementAt(2) == 'c');
// }

// /*
//  * elementAt 4 element list invalid above
//  * makes sure elementAt() throws an error
//  */
// void elementAt_four_element_list_invalid_above(){
//     bool range_error_thrown = false;
//     string error_message = "";

//     char arr[4] = {'a', 'b', 'c', 'd'};
//     try {
//         CharLinkedList list(arr, 4);
//         assert(list.elementAt(5) == 'd');
//     } 
//     catch (const range_error &e){
//         range_error_thrown = true;
//         error_message = e.what();
//     }  
//     assert(range_error_thrown);
//     assert(error_message == "index (5) not in range [0..4)");
// }

// /*
//  * elementAt 4 element list invalid below
//  * makes sure elementAt() throws an error
//  */
// void elementAt_four_element_list_invalid_below(){
//     bool range_error_thrown = false;
//     string error_message = "";

//     char arr[4] = {'a', 'b', 'c', 'd'};
//     try {
//         CharLinkedList list(arr, 4);
//         assert(list.elementAt(-1) == 'd');
//     } 
//     catch (const range_error &e){
//         range_error_thrown = true;
//         error_message = e.what();
//     }  
//     assert(range_error_thrown);
//     assert(error_message == "index (-1) not in range [0..4)");
// }

// /*
//  * elementAt empty list invalid
//  * makes sure elementAt() throws an error
//  */
// void elementAt_empty_list_invalid(){
//     bool range_error_thrown = false;
//     string error_message = "";

//     try {
//         CharLinkedList list;
//         assert(list.elementAt(0) == 'd');
//     } 
//     catch (const range_error &e){
//         range_error_thrown = true;
//         error_message = e.what();
//     }  
//     assert(range_error_thrown);
//     assert(error_message == "index (0) not in range [0..0)");
// }








// /*
//  * pop from front empty list
//  * makes sure throws error
//  */
// void popFromFront_empty_list(){
//     bool runtime_error_thrown = false;
//     string error_message = "";

//     try {
//         CharLinkedList list;
//         list.popFromFront();
//     } 
//     catch (const runtime_error &e){
//         runtime_error_thrown = true;
//         error_message = e.what();
//     }  
    
//     assert(runtime_error_thrown);
//     assert(error_message == "cannot pop from empty LinkedList");
// }

// /*
//  * pop from front one char list
//  * makes sure list empty afterward
//  */
// void popFromFront_one_char_list(){
//     CharLinkedList list('a');
//     list.popFromFront();
//     assert(list.isEmpty());
// }


// /*
//  * pop from front mulitple char list
//  * makes sure erases correct char
//  */
// void popFromFront_multiple_chars_list(){
//     char arr[4] = {'a', 'b', 'c', 'd'};
//     CharLinkedList list(arr, 4);
//     cout << list.toString() << endl;
//     list.popFromFront();
//     cout << list.toString() << endl;
//     assert(list.first() == 'b');
// }











// /*
//  * pop from back empty list
//  * makes sure throws error
//  */
// void popFromBack_empty_list(){
//     bool runtime_error_thrown = false;
//     string error_message = "";

//     try {
//         CharLinkedList list;
//         list.popFromBack();
//     } 
//     catch (const runtime_error &e){
//         runtime_error_thrown = true;
//         error_message = e.what();
//     }  
//     assert(runtime_error_thrown);
//     assert(error_message == "cannot pop from empty LinkedList");
// }

// /*
//  * pop from back one char list
//  * makes sure list empty afterward
//  */
// void popFromBack_one_char_list(){
//     CharLinkedList list('a');
//     list.popFromBack();
//     assert(list.isEmpty());
// }

// /*
//  * pop from back mulitple char list
//  * makes sure erases correct char
//  */
// void popFromBack_multiple_chars_list(){
//     char arr[4] = {'a', 'b', 'c', 'd'};
//     CharLinkedList list(arr, 4);
//     list.popFromBack();
//     assert(list.last() == 'c');
// }







// /*
//  * removeAt test empty list
//  * makes sure it throws error bc cant remove from empty list
//  */
// void removeAt_empty_list(){
//     bool range_error_thrown = false;
//     string error_message = "";

//     try {
//         CharLinkedList list;
//         list.removeAt(0);
//     } 
//     catch (const range_error &e){
//         range_error_thrown = true;
//         error_message = e.what();
//     }  
//     assert(range_error_thrown);
//     assert(error_message == "index (0) not in range [0..0)");
// }

// /*
//  * removeAt test one char list
//  * makes sure it removes char so list is empty
//  */
// void removeAt_one_char_list(){
//     CharLinkedList list('a');
//     list.removeAt(0);
//     assert(list.isEmpty());
// }

// /*
//  * removeAt test multiple char list
//  * makes sure it removes correct char from list
//  */
// void removeAt_multiple_char_list_valid(){
//     char arr[4] = {'a', 'b', 'c', 'd'};
//     CharLinkedList list(arr, 4);
//     list.removeAt(2);
//     cout << list.toString() << endl;
//     assert(list.toString() == "[CharLinkedList of size 3 <<abd>>]");
// }

// /*
//  * removeAt test invalid range above
//  * makes sure it throws error
//  */
// void removeAt_invalid_range_above(){
//     bool range_error_thrown = false;
//     string error_message = "";

//     char arr[4] = {'a', 'b', 'c', 'd'};
//     try {
//         CharLinkedList list(arr, 4);
//         list.removeAt(5);
//     } 
//     catch (const range_error &e){
//         range_error_thrown = true;
//         error_message = e.what();
//     }  
//     assert(range_error_thrown);
//     assert(error_message == "index (5) not in range [0..4)");
// }

// /*
//  * removeAt test invalid range below
//  * makes sure it throws error
//  */
// void removeAt_invalid_range_below(){
//     bool range_error_thrown = false;
//     string error_message = "";

//     char arr[4] = {'a', 'b', 'c', 'd'};
//     try {
//         CharLinkedList list(arr, 4);
//         list.removeAt(-1);
//     } 
//     catch (const range_error &e){
//         range_error_thrown = true;
//         error_message = e.what();
//     }  
//     assert(range_error_thrown);
//     assert(error_message == "index (-1) not in range [0..4)");
// }









// /*
//  * replaceAt empty list
//  * makes sure it throws error
//  */
// void replaceAt_empty_list(){
//     bool range_error_thrown = false;
//     string error_message = "";
//     try {
//         CharLinkedList list;
//         list.replaceAt('z', 0);
//     } 
//     catch (const range_error &e){
//         range_error_thrown = true;
//         error_message = e.what();
//     }  
//     assert(range_error_thrown);
//     assert(error_message == "index (0) not in range [0..0)");
// }

// /*
//  * replaceAt test invalid range above
//  * makes sure it throws error
//  */
// void replaceAt_invalid_range_above(){
//     bool range_error_thrown = false;
//     string error_message = "";

//     char arr[4] = {'a', 'b', 'c', 'd'};
//     try {
//         CharLinkedList list(arr, 4);
//         list.replaceAt('z', 5);
//     } 
//     catch (const range_error &e){
//         range_error_thrown = true;
//         error_message = e.what();
//     }  
//     assert(range_error_thrown);
//     assert(error_message == "index (5) not in range [0..4)");
// }

// /*
//  * replaceAt test invalid range below
//  * makes sure it throws error
//  */
// void replaceAt_invalid_range_below(){
//     bool range_error_thrown = false;
//     string error_message = "";

//     char arr[4] = {'a', 'b', 'c', 'd'};
//     try {
//         CharLinkedList list(arr, 4);
//         list.replaceAt('z', -2);
//     } 
//     catch (const range_error &e){
//         range_error_thrown = true;
//         error_message = e.what();
//     }  
//     assert(range_error_thrown);
//     assert(error_message == "index (-2) not in range [0..4)");
// }

// /*
//  * replaceAt one char list
//  * makes sure replaces the char with the correct char
//  */
// void replaceAt_one_char_list(){
//     CharLinkedList list('a');
//     list.replaceAt('z', 0);
//     assert(list.toString() == "[CharLinkedList of size 1 <<z>>]");
// }

// /*
//  * replaceAt multiple char list
//  * makes sure replaces the char at correct index
//  * with the correct char
//  */
// void replaceAt_multiple_char_list(){
//     char arr[4] = {'a', 'b', 'c', 'd'};
//     CharLinkedList list(arr, 4);
//     list.replaceAt('z', 3);
//     assert(list.toString() == "[CharLinkedList of size 4 <<abcz>>]");
// }

// /*
//  * replaceAt multiple char list
//  * makes sure replaces the char at correct index
//  * with the correct char
//  */
// void replaceAt_multiple_times_char_list(){
//     char arr[4] = {'a', 'b', 'c', 'd'};
//     CharLinkedList list(arr, 4);
//     list.replaceAt('z', 3);
//     list.replaceAt('g', 0);
//     list.replaceAt('q', 2);
//     list.replaceAt('p', 3);
//     assert(list.toString() == "[CharLinkedList of size 4 <<gbqp>>]");
// }








// /*
//  * toReverseString test no pushing elements onto list
//  * makes sure toReverseString works with an list made 
//  * with the list constructor
//  * (no pushbacks)
//  */

// void toReverseString_no_pushing_elements(){
//     char arr[4] = {'a', 'b', 'c', 'd'};
//     CharLinkedList list(arr, 4);
//     string s = list.toReverseString();
//     //cerr << s << endl;
//     assert(s == "[CharLinkedList of size 4 <<dcba>>]");
// }

// /*
//  * toReverseString test push back elements onto list
//  * makes sure toReverseString works after pushing elements 
//  * onto back of list
//  */

// void toReverseString_pushAtBack(){
//     char arr[4] = {'a', 'b', 'c', 'd'};
//     CharLinkedList list(arr, 4);
//     list.pushAtBack('e');
//     string s = list.toReverseString();
//     //cerr << s << endl;
//     assert(s == "[CharLinkedList of size 5 <<edcba>>]");
// }

// /*
//  * toReverseString test push front elements onto list
//  * makes sure toReverseString works after pushing elements onto 
//  * front of list
//  */

// void toReverseString_pushAtFront(){
//     char arr[4] = {'a', 'b', 'c', 'd'};
//     CharLinkedList list(arr, 4);
//     list.pushAtFront('e');
//     string s = list.toReverseString();
//     //cerr << s << endl;
//     assert(s == "[CharLinkedList of size 5 <<dcbae>>]");
// }

// /*
//  * toReverseString test push back elements onto list
//  * makes sure toReverseString works after pushing elements onto 
//  * back of list
//  */

// void toReverseString_insertAt(){
//     char arr[4] = {'a', 'b', 'c', 'd'};
//     CharLinkedList list(arr, 4);
//     list.insertAt('e', 2);
//     string s = list.toReverseString();
//     //cerr << s << endl;
//     assert(s == "[CharLinkedList of size 5 <<dceba>>]");
// }

/*
 * toReverseString test pop from back
 * makes sure toReverseString works after removing element from 
 * back of list
 */

void toReverseString_popFromBack(){
    char arr[4] = {'a', 'b', 'c', 'd'};
    CharLinkedList list(arr, 4);
    list.popFromBack();
    string s = list.toReverseString();
    //cerr << s << endl;
    assert(s == "[CharLinkedList of size 3 <<cba>>]");
}

// /*
//  * toReverseString test pop from front
//  * makes sure toReverseString works after removing element 
//  * from front of list
//  */

// void toReverseString_popFromFront(){
//     char arr[4] = {'a', 'b', 'c', 'd'};
//     CharLinkedList list(arr, 4);
//     list.popFromFront();
//     string s = list.toReverseString();
//     assert(s == "[CharLinkedList of size 3 <<dcb>>]");
// }

// /*
//  * toReverseString test removeAt
//  * makes sure toReverseString works after removing element from 
//  * given index of list
//  */
// void toReverseString_removeAt(){
//     char arr[4] = {'a', 'b', 'c', 'd'};
//     CharLinkedList list(arr, 4);
//     list.removeAt(1);
//     string s = list.toReverseString();
//     assert(s == "[CharLinkedList of size 3 <<dca>>]");
// }


// /*
//  * toReverseString test clear
//  * makes sure toReverseString works after clearing list
//  */

// void toReverseString_clear(){
//     char arr[4] = {'a', 'b', 'c', 'd'};
//     CharLinkedList list(arr, 4);
//     list.clear();
//     string s = list.toReverseString();
//     assert(s == "[CharLinkedList of size 0 <<>>]");
// }

// /*
//  * toReverseString test empty list
//  * makes sure toString works with empty list
//  */
// void toReverseString_empty_list(){
//     CharLinkedList list;
//     string s = list.toReverseString();
//     assert(s == "[CharLinkedList of size 0 <<>>]");
// }








// /*
//  * concatenate deep copy list
//  * makes sure concatenates correcntly
//  */
// void concatenate_deep_copy_list(){
//     char arr[3] = {'c', 'a', 't'};
//     CharLinkedList list1(arr, 3);
//     CharLinkedList list2 = list1;
//     list1.concatenate(&list2);
//     assert(list1.toString() == "[CharLinkedList of size 6 <<catcat>>]");
// }

// /*
//  * concatenate same list
//  * makes sure concatenates correcntly
//  */
// void concatenate_same_list(){
//     char arr[3] = {'c', 'a', 't'};
//     CharLinkedList list1(arr, 3);
//     CharLinkedList list2(arr, 3);
//     cout << list1.size() << endl;
//     list1.concatenate(&list1);
//     cout << list1.toString() << endl;
//     assert(list1.toString() == "[CharLinkedList of size 6 <<catcat>>]");
// }

// /*
//  * concatenate different lists 
//  * makes sure concatenates correcntly
//  */
// void concatenate_different_lists(){
//     char arr1[3] = {'c', 'a', 't'};
//     CharLinkedList list1(arr1, 3);
//     char arr2[5] = {'a', 'b', 'c', 'd', 'e'};
//     CharLinkedList list2(arr2, 5);
//     list1.concatenate(&list2);
//     assert(list1.toString() == "[CharLinkedList of size 8 <<catabcde>>]");
// }

// /*
//  * concatenate first list empty
//  * makes sure concatenates correcntly
//  */
// void concatenate_first_empty_list(){
//     CharLinkedList list1;
//     char arr[3] = {'c', 'a', 't'};
//     CharLinkedList list2(arr, 3);
//     list1.concatenate(&list2);
//     assert(list1.toString() == "[CharLinkedList of size 3 <<cat>>]");
// }

// /*
//  * concatenate second list empty
//  * makes sure concatenates correcntly
//  */
// void concatenate_second_empty_list(){
//     char arr[3] = {'c', 'a', 't'};
//     CharLinkedList list1(arr, 3);
//     CharLinkedList list2;
//     list1.concatenate(&list2);
//     assert(list1.toString() == "[CharLinkedList of size 3 <<cat>>]");
// }

// /*
//  * concatenate both lists empty
//  * makes sure concatenates correcntly
//  */
// void concatenate_both_empty_list(){
//     CharLinkedList list1;
//     CharLinkedList list2;
//     list1.concatenate(&list2);
//     assert(list1.toString() == "[CharLinkedList of size 0 <<>>]");
// }










// /*
//  * insertInOrder four char list middle
//  * makes sure insert char in correct order
//  */
// void insertInOrder_four_char_middle(){
//     char arr[4] = {'b', 'h', 'w', 'y'};
//     CharLinkedList list(arr, 4);
//     list.insertInOrder('k');
//     assert(list.toString() == "[CharLinkedList of size 5 <<bhkwy>>]");
// }

// /*
//  * insertInOrder four char list end
//  * makes sure insert char in correct order
//  */
// void insertInOrder_four_char_end(){
//     char arr[4] = {'a', 'b', 'c', 'd'};
//     CharLinkedList list(arr, 4);
//     list.insertInOrder('e');
//     assert(list.toString() == "[CharLinkedList of size 5 <<abcde>>]");
// }

// /*
//  * insertInOrder four char list beginning
//  * makes sure insert char in correct order
//  */
// void insertInOrder_four_char_beginning(){
//     char arr[4] = {'n', 'p', 'x', 'y'};
//     CharLinkedList list(arr, 4);
//     list.insertInOrder('g');
//     assert(list.toString() == "[CharLinkedList of size 5 <<gnpxy>>]");
// }

// /*
//  * insertInOrder one char before
//  * makes sure insert char in correct order
//  */
// void insertInOrder_one_char_before(){
//     CharLinkedList list('x');
//     list.insertInOrder('a');
//     assert(list.toString() == "[CharLinkedList of size 2 <<ax>>]");
// }

// /*
//  * insertInOrder one char after
//  * makes sure insert char in correct order
//  */
// void insertInOrder_one_char_after(){
//     CharLinkedList list('g');
//     list.insertInOrder('m');
//     assert(list.toString() == "[CharLinkedList of size 2 <<gm>>]");
// }

// /*
//  * insertInOrder one char same char
//  * makes sure insert char in correct order
//  */
// void insertInOrder_one_char_same_char(){
//     CharLinkedList list('g');
//     list.insertInOrder('g');
//     assert(list.toString() == "[CharLinkedList of size 2 <<gg>>]");
// }

// /*
//  * insertInOrder multiple char same char
//  * makes sure insert char in correct order
//  */
// void insertInOrder_multiple_char_same_char(){
//     char arr[4] = {'n', 'p', 'x', 'y'};
//     CharLinkedList list(arr, 4);
//     list.insertInOrder('x');
//     assert(list.toString() == "[CharLinkedList of size 5 <<npxxy>>]");
// }

// /*
//  * insertInOrder empty list
//  * makes sure insert char in correct order
//  */
// void insertInOrder_empty_list(){
//     CharLinkedList list;
//     list.insertInOrder('r');
//     assert(list.toString() == "[CharLinkedList of size 1 <<r>>]");
// }


// // Tests correct insertion into an empty AL.
// // Afterwards, size should be 1 and element at index 0
// // should be the element we inserted.
// void insertAt_empty_correct() { 

//     CharLinkedList test_list;
//     test_list.insertAt('a', 0);
//     assert(test_list.size() == 1);
//     assert(test_list.elementAt(0) == 'a');

// }

// // Tests incorrect insertion into an empty AL.
// // Attempts to call insertAt for index larger than 0.
// // This should result in an std::range_error being raised.
// void insertAt_empty_incorrect() {

//     // var to track whether range_error is thrown
//     bool range_error_thrown = false;

//     // var to track any error messages raised
//     std::string error_message = "";

//     CharLinkedList test_list;
//     try {
//     // insertAt for out-of-range index
//     test_list.insertAt('a', 42);
//     }
//     catch (const std::range_error &e) {
//     // if insertAt is correctly implemented, a range_error will be thrown,
//     // and we will end up here
//     range_error_thrown = true;
//     error_message = e.what();
//     }

//     // out here, we make our assertions
//     assert(range_error_thrown);
//     assert(error_message == "index (42) not in range [0..0]");
    
// }

// // Tests correct insertAt for front of 1-element list.
// void insertAt_front_singleton_list() {
    
//     // initialize 1-element list
//     CharLinkedList test_list('a');

//     // insert at front
//     test_list.insertAt('b', 0);

//     assert(test_list.size() == 2);
//     assert(test_list.elementAt(0) == 'b');
//     assert(test_list.elementAt(1) == 'a');
    
// }

// // Tests correct insertAt for back of 1-element list.
// void insertAt_back_singleton_list() {
    
//     // initialize 1-element list
//     CharLinkedList test_list('a');

//     // insert at back
//     test_list.insertAt('b', 1);

//     assert(test_list.size() == 2);
//     assert(test_list.elementAt(0) == 'a');
//     assert(test_list.elementAt(1) == 'b');
    
// }

// // Tests calling insertAt for a large number of elements.
// // Not only does this test insertAt, it also checks that
// //  inserts correctly.
// void insertAt_many_elements() {
    
//     CharLinkedList test_list;

//     // insert 1000 elements
//     for (int i = 0; i < 1000; i++) {
//         // always insert at the back of the list
//         test_list.insertAt('a', i);
//     }

//     assert(test_list.size() == 1000);

//     for (int i = 0; i < 1000; i++) {
//         assert(test_list.elementAt(i) == 'a');
//     }
    
// }

// // Tests insertion into front of a larger list
// void insertAt_front_large_list() {
//     char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
//     CharLinkedList test_list(test_arr, 9);

//     test_list.insertAt('y', 0);

//     assert(test_list.size() == 10);
//     assert(test_list.elementAt(0) == 'y');
//     assert(test_list.toString() == 
//     "[CharLinkedList of size 10 <<yabczdefgh>>]");

// }

// // Tests insertion into the back of a larger list
// void insertAt_back_large_list() {

//     char test_arr[10] = { 'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
//     CharLinkedList test_list(test_arr, 10);  

//     test_list.insertAt('x', 10);

//     assert(test_list.size() == 11);
//     assert(test_list.elementAt(10) == 'x');
//     assert(test_list.toString() == 
//     "[CharLinkedList of size 11 <<yabczdefghx>>]"); 

// }

// // Tests insertion into the middle of a larger list
// void insertAt_middle_large_list() {
//     char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
//     CharLinkedList test_list(test_arr, 8);

//     test_list.insertAt('z', 3);

//     assert(test_list.size() == 9);
//     assert(test_list.elementAt(3) == 'z');
//     assert(test_list.toString() == 
//     "[CharLinkedList of size 9 <<abczdefgh>>]");

// }

// // Tests out-of-range insertion for a non-empty list.
// void insertAt_nonempty_incorrect() {
   
//     char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
//     CharLinkedList test_list(test_arr, 8);

//     // var to track whether range_error is thrown
//     bool range_error_thrown = false;

//     // var to track any error messages raised
//     std::string error_message = "";

//     try {
//         test_list.insertAt('a', 42);
//     }
//     catch (const std::range_error &e) {
//         range_error_thrown = true;
//         error_message = e.what();
//     }

//     assert(range_error_thrown);
//     assert(error_message == "index (42) not in range [0..8]");
    
// }










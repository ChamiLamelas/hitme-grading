/*
 *  CharLinkedList.cpp
 *  Erica Huang
 *  2/1/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  CharLinkedList.cpp contains the implementation of 
 *  the CharLinkedList class
 *
 */

#include "CharLinkedList.h"
#include <stdexcept>

using namespace std;

/*
 * name:      CharLinkedList()
 * purpose:   initialize an empty linked list
 * arguments: none
 * returns:   none
 * effects:   numItems to 0 and front to nullptr
 */
CharLinkedList::CharLinkedList() {
    front = nullptr;
    numItems  = 0;
}

/*
 * name:      CharLinkedList(char c)
 * purpose:   initialize a 1 element linked list with element 
 *            being char c
 * arguments: char c
 * returns:   none
 * effects:   numItems to 1 and front becomes char's node
 */
CharLinkedList::CharLinkedList(char c) {
    numItems = 1;

    //new node and initialize variables
    Node *curr = new Node;
    curr->next = nullptr;
    curr->previous = nullptr;
    curr->c = c;
    
    //set as front node
    front = curr;
}

/*
 * name:      CharLinkedList(char arr[], int size)
 * purpose:   initialize linked list with given num of 
 *            elements. each element in linked list is
 *            an element of given list
 * arguments: char arr[] and int size
 * returns:   none
 * effects:   numItems to size, creates linked list from arr[]
 */
CharLinkedList::CharLinkedList(char arr[], int size) {
    numItems = size;

    //make first node
    Node *prev = new Node;
    prev->previous = nullptr;
    prev->next = nullptr;
    prev->c = arr[0];
    front = prev;

    //use same strategy as pushAtBack to add elements
    //to end of list
    
    for(int i = 1; i < size; i++){
        Node *curr = new Node;
        curr->previous = prev;
        curr->next = nullptr;
        curr->c = arr[i];
        prev->next = curr;

        prev = curr;
    }
}

/*
 * name:      CharLinkedList(const CharLinkedList &other)
 * purpose:   make a copy of given charLinkedList 
 * arguments: CharLinkedList &other
 * returns:   none
 * effects:   makes deep copy of &other so the CharLinkedList
 *            we're working with will have own memory but same values
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other) {
    numItems = other.size();

    if(other.isEmpty()){
        front = nullptr;
        return;
    }

    //create front node
    //make first node
    Node *prev = new Node;
    prev->previous = nullptr;
    prev->next = nullptr;
    prev->c = other.first();
    front = prev;

    //use same strategy as pushAtBack to add elements
    //to end of list
    for(int i = 1; i < other.size(); i++){
        Node *curr = new Node;
        curr->previous = prev;
        curr->next = nullptr;
        curr->c = other.elementAt(i);
        prev->next = curr;

        prev = curr;
    }
}

 /*
 * name:      destructor
 * purpose:   Free heap-allocated memory of 'this' 
 * arguments: nothing
 * returns:   nothing
 * effects:   Free heap-allocated memory of 'this' 
 */
CharLinkedList::~CharLinkedList() {
    destruct(front);
}

/*
 * name:      destruct()
 * purpose:   Free heap-allocated memory of 'this'
 * arguments: Node to delete
 * returns:   none
 * effects:   removes linked list from memory
 */
void CharLinkedList::destruct(Node *curr){
    if(curr == nullptr){
        return;
    }

    if(curr->next == nullptr){
        delete curr;
    } else{
        Node *next = curr->next;
        delete curr;
        destruct(next);
    }
}

/*
 * name:      CharLinkedList operator
 * purpose:   copy over information from given CharLinkedList
 *             to working CharLinkedList
 * arguments: CharLinkedList &other
 * returns:   address of copied CharLinkedList
 * effects:   makes deep copy of &other
 */
CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other) {
    //free memory
    destruct(front);

    if(other.isEmpty()){
        front = nullptr;
        numItems = 0;
        return *this;
    }
    
    numItems = other.size();

    //create front node
    //make first node
    Node *prev = new Node;
    prev->previous = nullptr;
    prev->next = nullptr;
    prev->c = other.first();
    front = prev;

    //use same strategy as pushAtBack to add elements
    //to end of list
    for(int i = 1; i < other.size(); i++){
        Node *curr = new Node;
        curr->previous = prev;
        curr->next = nullptr;
        curr->c = other.elementAt(i);
        prev->next = curr;

        prev = curr;
    }

    return *this;
}

/*
 * name:      isEmpty()
 * purpose:   determines if linked list is empty
 * arguments: none
 * returns:   true if numItems = 0, false otherwise
 * effects:   none
 */
bool CharLinkedList::isEmpty() const{
    return size() == 0;
}

/*
 * name:      size()
 * purpose:   returns number of elements in linked list
 * arguments: none
 * returns:   integer representing num of elements in linked list
 * effects:   none
 */
int CharLinkedList::size() const{
    return numItems;
}

/*
 * name:      clear
 * purpose:   empties linked list
 * arguments: none
 * returns:   none
 * effects:   deletes all elements in linked list and sets size to 0
 */
void CharLinkedList::clear(){
    numItems = 0;
    destruct(front);
    front = nullptr;
}

/*
 * name:      pushAtBack()
 * purpose:   adds element to end of existing 
 *            elements of the linked list
 * arguments: char c. the element you want to add
 * returns:   none
 * effects:   adds char c to end of elements in linked list
 */
void CharLinkedList::pushAtBack(char c) {
    numItems++;

    //if empty list
    if(front == nullptr){
        Node *new_n = new Node;
        front = new_n;
        new_n->next = nullptr;
        new_n->previous = nullptr;
        new_n->c = c;
        return;
    }

    //get to last node of list
    Node *curr = front;
    while(curr->next != nullptr){
        curr = curr->next;
    }
    
    //add new node to end of list
    Node *new_n = new Node;
    new_n->previous = curr;
    new_n->next = nullptr;
    new_n->c = c;
    curr->next = new_n;
}

/*
 * name:      pushAtFront()
 * purpose:   adds element to front of existing 
 *            elements of the linked list
 * arguments: char c. the element you want to add
 * returns:   none
 * effects:   adds char c to front of elements in linked list
 */
void CharLinkedList::pushAtFront(char c) {
    numItems++;

    //if empty list
    if(front == nullptr){
        Node *new_n = new Node;
        front = new_n;
        new_n->next = nullptr;
        new_n->previous = nullptr;
        new_n->c = c;
        return;
    }
    
    //add new node to front of list
    Node *new_n = new Node;
    new_n->previous = nullptr;
    new_n->next = front;
    new_n->c = c;
    front->previous = new_n;

    front = new_n;
}

/*
 * name:      insertAt
 * purpose:   adds element to given index in list. 
 * arguments: char c. the element you want to push
 *            int index. The index you want to insert it at.
 * returns:   none
 * effects:   adds char c to [index] in linked list
 */
void CharLinkedList::insertAt(char c, int index){
    //error if index is invalid
    if (index > numItems or index < 0) {
        throw range_error("index (" + to_string(index) + ") not in range [0.." 
                            + to_string(numItems) + "]");
    }

    if(index == 0){
        pushAtFront(c);
        return;
    }

    if(index == numItems){
        pushAtBack(c);
        return;
    }

    //get object before the new Node
    Node *prev = front;
    for(int i = 0; i < index - 1; i++){
        prev = prev->next;
    }


    //get object after the new Node
    Node *next = prev->next;

    //create new Node in between prev and next
    createNode(prev, next, c);
    numItems++;
}

/*
 * name:      first()
 * purpose:   finds first element in linked list
 * arguments: none
 * returns:   first element in linked list
 * effects:   none
 */
char CharLinkedList::first() const{
    //error if list is empty
    if (isEmpty()) {
        throw runtime_error("cannot get first of empty LinkedList");
    }
    return front->c;
}

/*
 * name:      last()
 * purpose:   finds last element in linked list
 * arguments: none
 * returns:   last element in linked list
 * effects:   none
 */
char CharLinkedList::last() const{
    if (isEmpty()) {
        throw runtime_error("cannot get last of empty LinkedList");
    }
    
    //get to last node of list
    Node *curr = front;
    while(curr->next != nullptr){
        curr = curr->next;
    }

    return curr->c;
}

/*
 * name:      toString
 * purpose:   converts LinkedList of characters into one string
 * arguments: none
 * returns:   message saying how long the linkedlist is and the string
 * effects:   none
 */
std::string CharLinkedList::toString() const{
    string s;
    //concatenate each char to string s
    Node *curr = front;
    for (int i = 0; i < numItems; i++) {
        s = s + curr->c;
        curr = curr->next;
    }
    return "[CharLinkedList of size " + to_string(size()) + " <<" + s + ">>]";
}

/*
 * name:      toReverseString
 * purpose:   converts LinkedList of characters into one string
 *             where last element is first char -> first element last char
 *             of the string
 * arguments: none
 * returns:   message saying how long the linked list is and the string
 * effects:   none
 */
std::string CharLinkedList::toReverseString() const{
    string s;
    
    if(isEmpty()){
        return "[CharLinkedList of size 0 <<>>]";
    }

    //get to back of the list
    Node *curr = front;
    while(curr->next != nullptr){
        curr = curr->next;
    }
    
    //concatenate each char to string s starting at end of list going left
    for (int i = numItems - 1; i >= 0; i--) {
        s += curr->c;
        curr = curr->previous;
    }
    return "[CharLinkedList of size " + to_string(size()) + " <<" + s + ">>]";
}


/*
 * name:      createNode
 * purpose:   creates Node
 * arguments: back pointer, front pointer, char c
 * returns:   nothing
 * effects:   inserts new node in between prev and next nodes
 */
void CharLinkedList::createNode(Node *prev, Node *next, char c){
    Node *curr = new Node;

    //if a node comes before the one you want to insert
    if(prev != nullptr){
        prev->next = curr;
    } else{
        front = curr;
    }

    //if a node comes after the one you want to insert
    if(next != nullptr){
        next->previous = curr;
    }

    curr->previous = prev;
    curr->next = next;
    curr->c = c;
}

/*
 * name:      elementAt
 * purpose:   finds element at given index
 * arguments: int index. the index of the element you want
 * returns:   char at given index
 * effects:   none
 */
char CharLinkedList::elementAt(int index) const{
    //error if invalid index or empty list
    if (index >= numItems or index < 0 or isEmpty()) {
        throw range_error("index (" + to_string(index) + ") not in range [0.." 
                                + to_string(numItems) + ")");
    }

    return elementAt_helper(index, front, 0);
}

/*
 * name:      elementAt_helper
 * purpose:   finds char of the node at given index
 * arguments: int index. the index of the element you want
 *            Node *curr, the node you're currently at
 *            int count. How many nodes you've passed over
 * returns:   char at given index
 * effects:   none
 */
char CharLinkedList::elementAt_helper(int index, Node *curr, int count) const{
    //base case
    if(count == index){
        return curr->c;
    } else{
        count++;
        curr = curr->next;
        return elementAt_helper(index, curr, count);
    }

}

/*
 * name:      popFromBack()
 * purpose:   removes last element in list
 * arguments: none
 * returns:   none
 * effects:   removes last element in list 
 *            list and updates numItems
 */
void CharLinkedList::popFromBack() {
    //error if list is empty
    if (isEmpty()) {
        throw runtime_error("cannot pop from empty LinkedList");
    }
    
    if(numItems == 1){
        clear();
        return;
    }

    removeAt(size() - 1);
}

/*
 * name:      popFromFront()
 * purpose:   removes first element in list
 * arguments: none
 * returns:   none
 * effects:   removes first element in list 
 *            and updates numItmes
 */
void CharLinkedList::popFromFront() {
    //error if list is empty
    if (isEmpty()) {
        throw runtime_error("cannot pop from empty LinkedList");
    }

    if(numItems == 1){
        clear();
        return;
    }

    removeAt(0);
}

/*
 * name:      removeAt
 * purpose:   removes element at given index in linked list
 * arguments: index of element to remove
 * returns:   none
 * effects:   removes element at given index in linked list
 */
void CharLinkedList::removeAt(int index) {
   //error if invalid index or empty list
   if (index >= numItems or index < 0 or isEmpty()) {
        throw range_error("index (" + to_string(index) + ") not in range [0.." 
                            + to_string(numItems) + ")");
    }

    if(numItems == 1){
        clear();
        return;
    }


    //get to index in list
    Node *curr = front;

    if(index == 0){
        curr->next->previous = nullptr;
        front = curr->next;
        delete curr;
        numItems--;
        return;
    }

    for(int i = 0; i < index; i++){
        curr = curr->next;
    }

    curr->previous->next = curr->next;
    if(curr->next != nullptr){
        curr->next->previous = curr->previous;
    }
    delete curr;

    numItems--;
}

/*
 * name:      replaceAt
 * purpose:   replaces element at given index in linked list
 *            with given character c
 * arguments: char to replace with and index of element being replaces
 * returns:   none
 * effects:   replaces element at given index in linked list with given char
 */
void CharLinkedList::replaceAt(char c, int index) {
    //error if invalid index or empty list
    if (index >= numItems or index < 0 or isEmpty()) {
        throw range_error("index (" + to_string(index) + ") not in range [0.." 
                            + to_string(numItems) + ")");
    }
    
    replaceAt_helper(index, front, 0, c);
    
}

/*
 * name:      replaceAt_helper
 * purpose:   finds char of the node at given index
 *            and replaces the char w the given char
 * arguments: int index. the index of the element you want
 *            Node *curr, the node you're currently at
 *            int count. How many nodes you've passed over
 *            char c. the char to replace it with
 * returns:   none
 * effects:   replaces current char with given char
 */
void CharLinkedList::replaceAt_helper(int idx, Node *curr, int count, char c) {
    //base case
    if(count == idx){
        curr->c = c;
    } else{
        count++;
        curr = curr->next;
        replaceAt_helper(idx, curr, count, c);
    }
}

/*
 * name:      concatenate
 * purpose:   concatenates given CharLinkedList to end of
 *            CharLinkedList calling the function
 * arguments: CharLinkedList to concatenate
 * returns:   none
 * effects:   concatenates CharLinkedList calling the function
 */
void CharLinkedList::concatenate(CharLinkedList *other) {
    //make copy of other incase other == this
    CharLinkedList list(*other);
    int size = list.size();
    for (int i = 0; i < size; i++) {
        pushAtBack(list.elementAt(i));
    }
}

/*
 * name:      insertInOrder
 * purpose:   inserts given char in alphabetically sorted
 *            list inserts so list stays alphabetically 
 *            sorted
 * arguments: char to insert
 * returns:   none
 * effects:   inserts element at alphabetical position
 */
void CharLinkedList::insertInOrder(char c) {
    //edge case empty list
    if (isEmpty()) {
        pushAtFront(c);
        return;
    }
    
    //edge case char c should be first element alphabetically
    if (c <= elementAt(0)) {
        pushAtFront(c);
        return;
    }
    
    //edge case char c should be last element alphabetically
    if (c >= elementAt(numItems - 1)) {
        pushAtBack(c);
        return;
    }

    for (int i = 0; i < numItems - 2; i++) {
        //if c comes before or is equal to current element
        if (c >= elementAt(i)) {
            //if c comes after or is equal to prev element
            if (c <= elementAt(i + 1)) {
                insertAt(c, i + 1);
                return;
            }
        }
    } 
}
/*
 *  CharLinkedList.h
 *  Erica Huang
 *  2/1/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - 
 *  Time to get linked up in Fur
 *
 *  CharLinkedList is a class that represents a 
 *  list data structure where the elements are characters. 
 *  Lists can begin empty, with one character, with multiple 
 *  characters, or as a copy of another list. Clients can 
 *  then insert, remove, and replace elements in the list. 
 *  They can also turn it into a string, a reverse string and
 *  concatenate two lists.
 *
 *  CharLinkedList.h contains the class definition and function
 *  definitions for the CharLinkedList class
 *
 */

#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H

#include <string>

class CharLinkedList {
public:
    //constructors
    CharLinkedList();
    CharLinkedList(char c);
    CharLinkedList(char arr[], int size);
    CharLinkedList(const CharLinkedList &other);

    //operator function
    CharLinkedList &operator=(const CharLinkedList &other);

    //destructors
    ~CharLinkedList();


    //constants
    bool isEmpty() const;
    int size() const;
    char first() const;
    char last() const;
    char elementAt(int index) const;

    //adding elements
    void pushAtBack(char c);
    void pushAtFront(char c);
    void insertAt(char c, int index);
    void concatenate(CharLinkedList *other);
    void insertInOrder(char c);

    //removing elements
    void clear();
    void popFromFront();
    void popFromBack();
    void removeAt(int index);

    //replacing elements
    void replaceAt(char c, int index);

    //string functions
    std::string toString() const;
    std::string toReverseString() const;


private:
    struct Node {
        char c;
        Node *next;
        Node *previous;
    };

    Node *front;
    int numItems;


    void destruct(Node *curr);
    void createNode(Node *prev, Node *next, char c);
    char elementAt_helper(int index, Node *curr, int count) const;
    void replaceAt_helper(int idx, Node *curr, int count, char c);
};

#endif

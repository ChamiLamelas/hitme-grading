/*
 *  CharLinkedList.cpp
 *  Jiaqi Liu (Jack)
 *  31st Jan. 2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Defines the methods in the CharLinkedList class
 *
 */

#include "CharLinkedList.h"
#include "sstream"

using namespace std;

/*
 * name: CharLinkedList Default Constructor
 * purpose: to construct an object in the CharLinkedList class
 * arguments: none
 * returns: none
 * effects: none
 */
CharLinkedList::CharLinkedList() {
    num = 0;
    front = nullptr;
    back = nullptr;
}

/*
 * name: CharLinkedList Single Element Constructor
 * purpose: to construct an object in the CharLinkedList class with a single
 * element
 * arguments: The data in the first element
 * returns: none
 * effects: none
 */
CharLinkedList::CharLinkedList(char c) {
    num = 1;
    Node *newelem = newnode(c);

    front = newelem;
    back = newelem;
}

/*
 * name: CharLinkedList Array Constructor
 * purpose: to construct an object in the CharLinkedList class with an array
 * of element
 * arguments: An array of characters and the size of the array
 * returns: none
 * effects: none
 */
CharLinkedList::CharLinkedList(char arr[], int size) {
    num = size;

    //Defines the first element of the list and updates front pointer
    Node *newelem = newnode(arr[0]);
    front = newelem;

    //Defines every element of the list after, updating the prev and next 
    //pointers accordingly
    for (int i = 1; i < size; i++) {
        newelem->next = newnode(arr[i]);
        newelem->next->prev = newelem;
        newelem = newelem->next;
    }

    //Updates back pointer
    back = newelem;
}

/*
 * name: CharLinkedList Copy Constructor
 * purpose: Creates a deep copy of a linked list
 * arguments: The address of a linked list
 * returns: none
 * effects: none
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other) {
    num = 0;
    front = nullptr;
    back = nullptr;

    //copies data from other over for a deep copy
    for (int i = 0; i < other.num; i++) {
        pushAtBack(other.elementAt(i));
    }
}

/*
 * name: ~CharLinkedList
 * purpose: Destructs an object in the CharLinkedList class
 * arguments: none
 * returns: none
 * effects: none
 */
CharLinkedList::~CharLinkedList() {
    if (num == 0) {
        return;
    }

    dealloc(front);
}

/*
 * name: CharLinkedList Assignment Operator
 * purpose: Defines assignemnt operator and creates a deep copy
 * arguments: The address of a linked list
 * returns: The address of the current linked list
 * effects: none
 */
CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other) {
    if (this == &other) {
        return *this;
    }

    //Clears data and copies data from other over for a deep copy
    clear();
    for (int i = 0; i < other.num; i++) {
        Node *temp = other.front;
        pushAtBack(findnode(0, i, temp)->data);
    }

    return  *this;
}

/*
 * name: isEmpty
 * purpose: Clears the elements in a linked list, recylcing all memory
 * arguments: none
 * returns: true is the list is empty and false otherwise
 * effects: none
 */
bool CharLinkedList::isEmpty() const {
    if (num == 0) {
        return true;
    }

    return false;
}

/*
 * name: clear
 * purpose: Clears the elements in a linked list, recylcing all memory
 * arguments: none
 * returns: none
 * effects: sets num to zero
 */
void CharLinkedList::clear() {
    if (num == 0) {
        return;
    }
    
    dealloc(front);
    num = 0;
}

/*
 * name: size
 * purpose: gives the size of the linked list
 * arguments: none
 * returns: the integer value of the size of the linked list
 * effects: none
 */
int CharLinkedList::size() const {
    return num;
}

/*
 * name: first
 * purpose: accesses the data at the first element of the linked list
 * arguments: none
 * returns: the char at the first place of the list
 * effects: throws error if the list is empty
 */
char CharLinkedList::first() const {
    if (num == 0) {
        //Creates stringstream for error statement
        std::stringstream ss;
        ss << "cannot get first of empty LinkedList";
        throw runtime_error(ss.str());
    }

    return front->data; 
}

/*
 * name: last
 * purpose: accesses the data at the last element of the linked list
 * arguments: none
 * returns: the char at the last place of the list
 * effects: throws error if the list is empty
 */
char CharLinkedList::last() const {
    if (num == 0) {
        //Creates stringstream for error statement
        std::stringstream ss;
        ss << "cannot get last of empty LinkedList";
        throw runtime_error(ss.str());
    }

    return back->data;
}

/*
 * name: elementAt
 * purpose: accesses the data at a specific index of the linked list
 * arguments: an integer for the index
 * returns: the char at the given index of the list
 * effects: throws error if the index is out of bounds
 */
char CharLinkedList::elementAt(int index) const {
    if (index < 0 or index >= num) {
        //Creates stringstream for error statement
        std::stringstream ss;
        ss << "index (" << index << ") not in range [0.." << num << ")";
        throw range_error(ss.str());
    }

    //Obtains the pointer to the element at the given index
    Node *temp = front;
    for (int i = 0; i < index; i++) {
        temp = temp->next;
    }

    return temp->data;
}

/*
 * name: toString
 * purpose: converts the linked list into a string
 * arguments: none
 * returns: the linked list as a string statement
 * effects: none
 */
std::string CharLinkedList::toString() const { 
    Node *curr = front;
    std::stringstream ss;

    ss << "[CharLinkedList of size ";
    ss << num;
    ss << " <<";

    //Inputs all data into stringstream variable
    for (int i = 0; i < num; i++) {
        ss << curr->data;
        curr = curr->next;
    }

    ss << ">>]";

    return ss.str();
}

/*
 * name: toReverseString
 * purpose: converts the reverse of the linked list into a string
 * arguments: none
 * returns: the reverse of the linked list as a string statement
 * effects: none
 */
std::string CharLinkedList::toReverseString() const { 
    Node *curr = back;
    std::stringstream ss;

    ss << "[CharLinkedList of size ";
    ss << num;
    ss << " <<";
    //Inputs all data in linked list to stringstream variable in reverse
    for (int i = 0; i < num; i++) {
        ss << curr->data;
        curr = curr->prev;
    }

    ss << ">>]";

    return ss.str();
}

/*
 * name: pushAtFront
 * purpose: adds an element at the front of the list
 * arguments: a character to be put at the front of the list
 * returns: none
 * effects: increments num by one
 */
void CharLinkedList::pushAtFront(char c) {
    if (num == 0) {
        //Creates new node and updates pointers accordingly
        Node *newelem = newnode(c);
        front = newelem;
        back = newelem;

        num++;
        return;
    }
    
    //Creates new node and updates pointers accordingly
    Node *newelem = newnode(c);
    front->prev = newelem;
    newelem->next = front;
    front = newelem;

    num++;
}

/*
 * name: pushAtBack
 * purpose: adds an element at the back of the list
 * arguments: a character to be put at the back of the list
 * returns: none
 * effects: increments num by one
 */
void CharLinkedList::pushAtBack(char c) {
    if (num == 0) {
        //Creates new node and updates pointers accordingly
        Node *newelem = newnode(c);
        front = newelem;
        back = newelem;

        num++;
        return;
    }
    
    //Creates new node and updates pointers accordingly
    Node *newelem = newnode(c);
    back->next = newelem;
    newelem->prev = back;
    back = newelem;

    num++;
}

/*
 * name: insertAt
 * purpose: adds an element at a given index of the list
 * arguments: a character to be put at a given of the list
 * returns: none
 * effects: increments num by one
 */
void CharLinkedList::insertAt(char c, int index) {
    if (index < 0 or index > num) {
        //Creates stringstream for error statement
        std::stringstream ss;
        ss << "index (" << index << ") not in range [0.." << num << "]";
        throw range_error(ss.str());
    }
    
    if (index == 0) {
        pushAtFront(c);
    } else if (index == num) {
        pushAtBack(c);
    } else {
        //Creates new node and locates the index
        Node *newelem = newnode(c);
        Node *temp = front;
        for (int i = 0; i < index - 1; i++) {
            temp = temp->next;
        }

        //Updates the pointers to include the new node
        newelem->prev = temp;
        newelem->next = temp->next;
        temp->next->prev = newelem;
        temp->next = newelem;

        num++;
    }
}

/*
 * name: insertInOrder
 * purpose: adds an element in ASCII order
 * arguments: a character to be put in ASCII order
 * returns: none
 * effects: increments num by one
 */
void CharLinkedList::insertInOrder(char c) {
    Node *temp = front;

    if (num == 0) {
        pushAtFront(c);
    }

    //Finds the first element that is greater than the inputted char
    for (int i = 0; i < num; i++) {
        if (temp->data < c) {
            temp = temp->next;
            continue;
        } else {
            //Inserts the char at the correct index
            insertAt(c, i);
            return;
        }
    }

    //Inserts the char at the end otherwise
    pushAtBack(c);
}

/*
 * name: popFromFront
 * purpose: removes the first element
 * arguments: none
 * returns: none
 * effects: decrements num by one
 */
void CharLinkedList::popFromFront() {
    if (num == 0) {
        //Creates stringstream for error statement
        std::stringstream ss;
        ss << "cannot pop from empty LinkedList";
        throw runtime_error(ss.str());
    }

    //Stores the address of the second element, then deletes and updates front
    Node *temp = front->next;
    delete front;
    front = temp;

    //Updates prev
    if (num != 1) {
        front->prev = nullptr;
    }

    num--;

}

/*
 * name: popFromBack
 * purpose: removes the last element
 * arguments: none
 * returns: none
 * effects: decrements num by one
 */
void CharLinkedList::popFromBack() {
    if (num == 0) {
        //Creates stringstream for error statement
        std::stringstream ss;
        ss << "cannot pop from empty LinkedList";
        throw runtime_error(ss.str());
    }

    //Stores the address of the second to last element, then deletes and 
    //updates back
    Node *temp = back->prev;
    delete back;
    back = temp;
    
    //Updates next
    if (num != 1) {
        back->next = nullptr;
    }

    num--;
}

/*
 * name: removeAt
 * purpose: removes a certain index
 * arguments: an integer index
 * returns: none
 * effects: decrements num by one
 */
void CharLinkedList::removeAt(int index) {
    if (index < 0 or index >= num) {
        //Creates stringstream for error statement
        std::stringstream ss;
        ss << "index (" << index << ") not in range [0.." << num << ")";
        throw range_error(ss.str());
    }

    if (index == 0) {
        popFromFront();
    } else if (index == num - 1) {
        popFromBack();
    } else {
        //Creates temp pointer to locate relevant index
        Node *temp = front;
        for (int i = 0; i < index - 1; i++) {
            temp = temp->next;
        }

        //Updates prev, next, and deletes removed data
        temp->next->next->prev = temp;
        Node *placeholder = temp->next->next;
        delete temp->next;
        temp->next = placeholder;

        num--;
    }
}

/*
 * name: replaceAt
 * purpose: replaces the data at a certain index
 * arguments: a char to replace with and an integer index
 * returns: none
 * effects: none
 */
void CharLinkedList::replaceAt(char c, int index) {
    if (index < 0 or index >= num) {
        //Creates stringstream for error statement
        std::stringstream ss;
        ss << "index (" << index << ") not in range [0.." << num << ")";
        throw range_error(ss.str());
    }
    
    //Finds the relevant node recursively
    Node *temp = front;
    Node *replace = findnode(0, index, temp);

    //Updates the data
    replace->data = c;
}

/*
 * name: concatenate
 * purpose: chains a second list after a linked list
 * arguments: a pointer to the second list
 * returns: none
 * effects: increments the size by the size of the second list
 */
void CharLinkedList::concatenate(CharLinkedList *other) {
    int other_num = other->size();
    
    Node *temp = other->front;

    //Adds the data of the other list at the back of list
    for (int i = 0; i < other_num; i++) {
        pushAtBack(temp->data);
        temp = temp->next;
    }
}

/*
 * name: findnode
 * purpose: finds the node pointer to at a given index in the list
 * arguments: a counter i, a target integer, and a temporary pointer
 * returns: A pointer to the node at the target index
 * effects: none
 */
CharLinkedList::Node *CharLinkedList::findnode(int i, int target, Node *temp) {
    if (i == target) {
        return temp;
    } else {
        return findnode(i + 1, target, temp->next);
    }
}

/*
 * name: newnode
 * purpose: creates a new node in the linked list
 * arguments: a char c for data
 * returns: A pointer to the new node
 * effects: none
 */
CharLinkedList::Node *CharLinkedList::newnode(char c) {
    Node *newelem = new Node;

    //Sets relevant data of a node accordingly
    newelem->data = c;
    newelem->prev = nullptr;
    newelem->next = nullptr;

    return newelem;
}

/*
 * name: dealloc
 * purpose: recursively deallocates the entire list and frees heap memory
 * arguments: a pointer to a node
 * returns: none
 * effects: none
 */
void CharLinkedList::dealloc(Node *temp) {
    if (temp->next == nullptr) {
        delete temp;
        return;
    }

    dealloc(temp->next);
    delete temp;
}
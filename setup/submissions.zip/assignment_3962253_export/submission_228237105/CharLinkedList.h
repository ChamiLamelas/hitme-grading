/*
 *  CharLinkedList.h
 *  Jiaqi Liu (Jack)
 *  31st Jan. 2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  To create an ADT for a doubly linked list which can be altered as needed
 *  by the user. Being composed of individual Nodes, accessing the middle
 *  element may be slow. 
 *
 */

#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H

#include <string>

class CharLinkedList {
    public:
        CharLinkedList();
        CharLinkedList(char c);
        CharLinkedList(char arr[], int size);
        CharLinkedList(const CharLinkedList &other);
        ~CharLinkedList();

        CharLinkedList &operator=(const CharLinkedList &other);

        void clear();
        void pushAtBack(char c);
        void pushAtFront(char c);
        void insertAt(char c, int index);
        void insertInOrder(char c);
        void popFromFront();
        void popFromBack();
        void removeAt(int index);
        void replaceAt(char c, int index);
        void concatenate(CharLinkedList *other);

        bool isEmpty() const;
        int size() const;
        char first() const;
        char last() const;
        char elementAt(int index) const;
        std::string toString() const;
        std::string toReverseString() const;

    private:
        struct Node {
            char data;
            Node *prev;
            Node *next;
        };

        Node *front;
        Node *back;
        int num;
        
        void dealloc(Node *curr);
        Node *findnode(int count, int target, Node *temp);
        Node *newnode(char c);
};

#endif

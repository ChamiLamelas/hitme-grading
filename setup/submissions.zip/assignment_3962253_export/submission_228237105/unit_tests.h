/*
 *  unit_tests.h
 *  Jiaqi Liu (Jack)
 *  31st Jan. 2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  Tests designed for the methods in the CharLinkedList class (defined in 
 *  CharLinkedList.cpp)
 *
 */

#include "CharLinkedList.h"
#include <cassert>

using namespace std;

//Tests the default constructor
void construct_test1() {
    CharLinkedList list;
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}

//Tests the single element constructor
void construct_test2() {
    CharLinkedList list('a');
    assert(list.toString() == "[CharLinkedList of size 1 <<a>>]");
}

//Tests the array constructor
void construct_test3() {
    char arr [8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList list(arr, 8);
    assert(list.toString() == "[CharLinkedList of size 8 <<abcdefgh>>]");
}

//Tests the copy constructor
void construct_test4() {
    char arr [8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList list(arr, 8);
    CharLinkedList list2(list);
    assert(list.toString() == list2.toString());
}

//Tests the assignment operator
void operator_test() {
    char arr [8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList list(arr, 8);
    CharLinkedList list2;
    list2 = list;

    assert(list.toString() == list2.toString());
}

//Tests isEmpty for empty
void emptytest1() {
    CharLinkedList list1;
    assert(list1.isEmpty());
}

//Tests isEmpty for nonempty list
void emptytest2() {
    CharLinkedList list('a');
    assert(not list.isEmpty());
}

//Tests clear for empty
void cleartest() {
    CharLinkedList list;
    list.clear();
    assert(list.isEmpty());
}

//Tests clear for nonempty list
void cleartest2() {
    CharLinkedList list;
    list.pushAtBack('a');
    list.clear();
    assert(list.isEmpty());
}

//Tests size for a growing list
void sizetest() {
    CharLinkedList list;
    for (int i = 0; i < 100; i++) {
        list.pushAtBack('a');
        assert(list.size() == i + 1);
    }
}

//Tests valid first
void validfirst() {
    CharLinkedList list;
    for (int i = 0; i < 100; i++) {
        list.pushAtBack('a');
    }

    list.pushAtBack('b');
    assert(list.first() == 'a');
}

//Tests valid last
void validlast() {
    CharLinkedList list;
    for (int i = 0; i < 100; i++) {
        list.pushAtBack('a');
    }

    list.pushAtBack('b');
    assert(list.last() == 'b');
}

//Tests invalid first
void invalidfirst() {
    //Creates variables for error message
    bool runtime_error_thrown = false;
    std::string error_message = "";

    CharLinkedList list;
    
    //Trys to catch thrown error
    try {
        list.first();
    } catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot get first of empty LinkedList");
}

//Tests invalid last
void invalidlast() {
    //Creates variables for error message
    bool runtime_error_thrown = false;
    std::string error_message = "";

    CharLinkedList list;
    //Trys to catch thrown error
    try {
        list.last();
    } catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot get last of empty LinkedList");
}

//Tests elementAt for a large list
void validelem() {
    CharLinkedList list;
    for (int i = 0; i < 26; i++) {
        list.pushAtBack('a' + i);
    }

    assert(list.elementAt(0) == 'a');
    assert(list.elementAt(25) == 'z');
}

//Tests invalid elementAt
void invalidelem() {
    //Creates variables for error message
    bool range_error_thrown = false;
    std::string error_message = "";

    CharLinkedList list('n');
    //Trys to catch thrown error
    try {
        list.elementAt(2);
    } catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (2) not in range [0..1)");
}

//Tests toString of an empty list
void emptystring() {
    CharLinkedList list;
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}

//Tests toString of a non empty list
void nonemptystring() {
    char arr [8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList list(arr, 8);
    assert(list.toString() == "[CharLinkedList of size 8 <<abcdefgh>>]");
}

//Tests toReverseString of an empty list
void emptyreverse() {
    CharLinkedList list;
    assert(list.toReverseString() == "[CharLinkedList of size 0 <<>>]");
}

//Tests toReverseString of a non empty list
void nonemptyreverse() {
    char arr [8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList list(arr, 8);
    assert(list.toReverseString() == "[CharLinkedList of size 8 <<hgfedcba>>]");
}

//Tests pushAtFront of an empty list
void emptypushfront() {
    CharLinkedList list;
    list.pushAtFront('a');
    assert(list.toString() == "[CharLinkedList of size 1 <<a>>]");
}

//Tests pushAtFront of a non empty list
void nonemptypushfront() {
    CharLinkedList list('b');
    list.pushAtFront('a');
    assert(list.toString() == "[CharLinkedList of size 2 <<ab>>]");
}

//Tests pushAtFront of a large list
void largepushfront() {
    char arr [8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList list(arr, 8);
    list.pushAtFront('a');
    assert(list.toString() == "[CharLinkedList of size 9 <<aabcdefgh>>]");
}

//Tests pushAtBack of an empty list
void emptypushback() {
    CharLinkedList list;
    list.pushAtBack('a');
    assert(list.toString() == "[CharLinkedList of size 1 <<a>>]");
}

//Tests pushAtBack of a non empty list
void nonemptypushback() {
    CharLinkedList list('b');
    list.pushAtBack('a');
    assert(list.toString() == "[CharLinkedList of size 2 <<ba>>]");
}

//Tests pushAtBack of a large list
void largepushback() {
    char arr [8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList list(arr, 8);
    list.pushAtBack('a');
    assert(list.toString() == "[CharLinkedList of size 9 <<abcdefgha>>]");
}

//Tests insertAt for an empty list
void emptyinsert() {
    CharLinkedList list;
    list.insertAt('a', 0);
    assert(list.toString() == "[CharLinkedList of size 1 <<a>>]");
}

//Tests insertAt for a non empty list
void nonemprtinsert() {
    char arr [8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList list(arr, 8);
    list.insertAt('a', 0);
    assert(list.toString() == "[CharLinkedList of size 9 <<aabcdefgh>>]");

    list.insertAt('b', 5);
    assert(list.toString() == "[CharLinkedList of size 10 <<aabcdbefgh>>]");

    list.insertAt('c', 10);
    assert(list.toString() == "[CharLinkedList of size 11 <<aabcdbefghc>>]");
}

//Tests invalid insertAt
void invalidinsert() {
    //Creates variables to store error message
    bool range_error_thrown = false;
    std::string error_message = "";

    char arr [8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList list(arr, 8);
    
    //Trys to catch thrown error
    try {
        list.insertAt('a', 20);
    } catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (20) not in range [0..8]");
}

//Tests insertInOrder for a large list
void insertorder() {
    char arr1 [7] = {'a', 'b', 'c', 'e', 'f', 'g', 'h'};
    CharLinkedList list1(arr1, 7);

    list1.insertInOrder('d');
    assert(list1.toString() == "[CharLinkedList of size 8 <<abcdefgh>>]");

    char arr2 [7] = {'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList list2(arr2, 7);

    list2.insertInOrder('a');
    assert(list2.toString() == "[CharLinkedList of size 8 <<abcdefgh>>]");

    char arr3 [7] = {'a', 'b', 'c', 'd', 'e', 'f', 'g'};
    CharLinkedList list3(arr3, 7);

    list3.insertInOrder('h');
    assert(list3.toString() == "[CharLinkedList of size 8 <<abcdefgh>>]");
}

//Tests popFromFront for a single element list
void validsinglepopfront() {
    CharLinkedList list('a');
    assert(list.toString() == "[CharLinkedList of size 1 <<a>>]");

    list.popFromFront();
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}

//Tests popFromFront for a large list
void validlargepopfront() {
    char arr [8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList list(arr, 8);

    list.popFromFront();
    assert(list.toString() == "[CharLinkedList of size 7 <<bcdefgh>>]");
}

//Tests popFromBack for a single element list
void validsinglepopback() {
    CharLinkedList list('a');
    assert(list.toString() == "[CharLinkedList of size 1 <<a>>]");

    list.popFromBack();
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}

//Tests popFromBack for a large list
void validlargepopback() {
    char arr [8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList list(arr, 8);

    list.popFromBack();
    assert(list.toString() == "[CharLinkedList of size 7 <<abcdefg>>]");
}

//Tests invalid popFromFront
void invalidpopfront() {
    bool runtime_error_thrown = false;
    std::string error_message = "";

    CharLinkedList list;
    //Trys to catch thrown error
    try {
        list.popFromFront();
    } catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

//Tests invalid popFromBack
void invalidpopback() {
    bool runtime_error_thrown = false;
    std::string error_message = "";

    CharLinkedList list;
    //Trys to catch thrown error
    try {
        list.popFromFront();
    } catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

//Tests removeAt for the first element
void removeatfront() {
    char arr [8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList list(arr, 8);

    list.removeAt(0);
    assert(list.toString() == "[CharLinkedList of size 7 <<bcdefgh>>]");
}

//Tests removeAt for the last element
void removeatback() {
    char arr [8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList list(arr, 8);

    list.removeAt(7);
    assert(list.toString() == "[CharLinkedList of size 7 <<abcdefg>>]");
}

//Tests removeAt for the middle elements
void removemiddle() {
    char arr [8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList list(arr, 8);

    list.removeAt(2);
    assert(list.toString() == "[CharLinkedList of size 7 <<abdefgh>>]");

    list.removeAt(5);
    assert(list.toString() == "[CharLinkedList of size 6 <<abdefh>>]");
}

//Replaces the first element
void replacefront() {
    char arr [8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList list(arr, 8);

    list.replaceAt('z', 0);
    assert(list.toString() == "[CharLinkedList of size 8 <<zbcdefgh>>]");
}

//Tests invalid remove
void invalidremove() {
    bool range_error_thrown = false;
    std::string error_message = "";

    CharLinkedList list;
    //Trys to catch thrown error
    try {
        list.removeAt(0);
    } catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (0) not in range [0..0)");
}

//Replaces the last element
void replaceback() {
    char arr [8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList list(arr, 8);

    list.replaceAt('z', 7);
    assert(list.toString() == "[CharLinkedList of size 8 <<abcdefgz>>]");
}

//Replaces the middle elements
void replacemid() {
    char arr [8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList list(arr, 8);

    list.replaceAt('z', 2);
    assert(list.toString() == "[CharLinkedList of size 8 <<abzdefgh>>]");

    list.replaceAt('z', 5);
    assert(list.toString() == "[CharLinkedList of size 8 <<abzdezgh>>]");
}

//Tests invalid replace
void invalidreplace() {
    bool range_error_thrown = false;
    std::string error_message = "";

    CharLinkedList list;
    //Trys to catch thrown error
    try {
        list.replaceAt('a', 0);
    } catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (0) not in range [0..0)");
}

//Concatenates two lists
void concat() {
    char arr1 [4] = {'a', 'b', 'c', 'd'};
    CharLinkedList list1(arr1, 4);

    char arr2 [4] = {'e', 'f', 'g', 'h'};
    CharLinkedList list2(arr2, 4);

    list1.concatenate(&(list2));
    assert(list1.toString() == "[CharLinkedList of size 8 <<abcdefgh>>]");
}

//Concatenates a list with itself
void concatself() {
    char arr1 [4] = {'a', 'b', 'c', 'd'};
    CharLinkedList list1(arr1, 4);

    list1.concatenate(&(list1));
    assert(list1.toString() == "[CharLinkedList of size 8 <<abcdabcd>>]");
}

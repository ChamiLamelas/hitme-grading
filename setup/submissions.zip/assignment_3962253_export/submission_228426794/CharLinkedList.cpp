/*
 *  CharLinkedList.cpp
 *  Arbert Xu
 *  2/3/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 * This file implements many different functions for the CharLinkedList class.
 * The class can only store chars. The class is quite space efficient 
 * compared to ArrayLists because it doesn't need to double the size when 
 * adding more elements. This class is also more efficient at adding an item
 * at the front and removing an item at the front.
 *
 */

#include "CharLinkedList.h"
#include <stdexcept>
#include <iostream>

using namespace std;
/* CharLinkedList::Node *CharLinkedList
::newNode(char c, Node *next, Node *previous)
Purpose: Initializes a node pointer with a char c and a pointer to the next
and previous node
Parameters: A char c which is the data of the node, a pointer next which 
the current node points to, and a previous node which the current node will 
point to
Return: returns an initialized node with next and previous pointers and data 
char c 
*/
CharLinkedList::Node *CharLinkedList
::newNode(char c, Node *next, Node *previous)
{
    Node *new_node = new Node;
    new_node->data = c;
    new_node->next = next;
    new_node->previous = previous;
    return new_node;
}
/* CharLinkedList::Node *CharLinkedList
::newNode(char c)
Purpose: Initializes a node pointer with a char c and null pointers to next
and previous
Parameters: A char c which is the data of the node,
Return: returns an initialized node with data char c 
*/
CharLinkedList::Node *CharLinkedList::newNode(char c)
{
    Node *new_node = new Node;
    new_node->data = c;
    new_node->next = nullptr;
    new_node->previous = nullptr;
    return new_node;
}
/* CharLinkedList()
Purpose: Initialize an empty LinkedList
Parameters: N/A
Return: Returns an empty LinkedList
*/
CharLinkedList::CharLinkedList()
{
    numItems = 0;
    front = nullptr;
    back = nullptr;
}
/* CharLinkedList(char c)
Purpose: Initialize a LinkedList with one node that contains the char c 
and set the LinkedList front and back pointers to the node
Parameters: char c which will be the data of the new node
Return: Returns a LinkedList with one node which contains the char c
*/
CharLinkedList::CharLinkedList(char c)
{
    numItems = 1;
    front = newNode(c, nullptr, nullptr);
    back = front;
}
/* CharLinkedList(char arr[], int size)
Purpose: Initialize an LinkedList with a given array of chars and a given size 
of how many items the LinkedList should have. Creates a LinkedList based on 
the given size and copies all of the chars from the given char array.
Parameters: List of chars and an int of size for how many numItems the 
LinkedList has. Int size will be how large the LinkedList will be initialized 
and Array of chars will fill up the LinkedList
Return: returns a LinkedList which will be have size numItems and will be 
filled with the chars from the char array arr.
*/
CharLinkedList::CharLinkedList(char arr[], int size)
{
    numItems = 0;
    front = nullptr;
    back = nullptr;
    for(int i = 0; i < size; i++)
    {
       pushAtBack(arr[i]);
    }
}
/* CharLinkedList(const CharLinkedList &other)
Purpose: Copy a CharLinkedList and all of its data into another CharLinkedList 
and initialize it. 
Parameters: const CharLinkedList &other. Peform a deep copy on given 
CharLinkedList to CharLinkedList user wants to initialize. All data and private 
info is copied over
Return: Returns an identical CharLinkedList to the one given
*/
CharLinkedList::CharLinkedList(const CharLinkedList &other)
{
    front = nullptr;
    back = nullptr;
    numItems = 0;
    Node *curr = other.front;
    while(curr != nullptr)
    {
        pushAtFront(curr->data);
        curr = curr->next;
    }
}
/* char CharLinkedList::first() const
Purpose: to return the very first char in the CharLinkedList. Will return 
an error if CharLinkedList is empty
Parameters: N/A
Return: the very first char in the CharLinkedList
*/ 
char CharLinkedList::first() const
{
    if(numItems == 0)
    {
        throw std::runtime_error("cannot get first of empty LinkedList");
    }
    return front->data;
}
/* char CharLinkedList::last() const
Purpose: to return the very last char in the CharLinkedList. Will return 
an error if CharLinkedList is empty
Parameters: N/A
Return: the very last char in the CharLinkedList
*/ 
char CharLinkedList::last() const
{
    if(numItems == 0)
    {
        throw std::runtime_error("cannot get last of empty LinkedList");
    }
    return back->data;
}
/* CharLinkedList::~CharLinkedList()
Purpose: clean up CharLinkedList. Make sure all heap memory is deleted. Calls 
recursive deconstruct function to delete all nodes
Parameters: N/A
Return: N/A
*/ 
CharLinkedList::~CharLinkedList()
{
    deconstructRecursive(front);
}
/* CharLinkedList::deconstructRecursive(Node *curr)
    Purpose: clean up CharLinkedList. Recursively iterates through the
    LinkedList and deletes each node as it goes through.
    Parameters: Node *curr which is the Node which the functions starts 
    deleting from
    Return: N/A
*/
void CharLinkedList::deconstructRecursive(Node *curr)
{
    if(curr == nullptr)
    {
        return;
    } else
    {
        Node *next = curr->next;
        delete curr;
        deconstructRecursive(next);
    }
}
/* CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other)
Purpose: create an equal operator which will allow the = sign to peform a deep
copy of a CharLinkedList
Parameters: const CharLinkedList &other. Will peform a deep copy of the given
CharLinkedList and assign all of its values and data to the CharLinkedList this 
function was called upon.
Return: Returns a CharLinkedList identical to the one given
*/ 
CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other)
{
    if(this == &other)
    {
        return *this;
    }
    clear();
    numItems = other.numItems;
    if(numItems == 0)
    {
        return *this;
    }
    front = newNode(other.front->data, nullptr, nullptr);
    Node *curr = front;
    Node *new_curr = other.front->next;
    while(new_curr != nullptr)
    {
        curr->next = newNode(new_curr->data, nullptr, curr);
        curr = curr->next;
        new_curr = new_curr->next;
    }
    back = elementAtHelper(numItems - 1, front);
    return *this;
}
/* int CharLinkedList::size() const
Purpose: to calculate and return the size of the CharLinkedList this function 
was called upon
Parameters: N/A
Return: Returns an int of the size of the LinkedList
*/ 
int CharLinkedList::size() const
{
    return numItems;
}
/* bool CharLinkedList::isEmpty() const
Purpose: checks to see if the CharLinkedList has zero items inside of it
Parameters: N/A
Return: bool true if CharLinkedList is empty and false if it isn't
*/ 
bool CharLinkedList::isEmpty() const
{
    if(numItems == 0)
    {
        return true;
    }
    return false;
}
/* char CharLinkedList::elementAt(int index) const
Purpose: Find and return char at given index. If given index is not in range 
of CharLinkedList, will return and error
Parameters: int index of position of element
Return: char of node at given index
*/ 
char CharLinkedList::elementAt(int index) const
{
    if(isEmpty())
    {
        throw std::range_error("index (" + std::to_string(index) + 
        ") not in range [0.." + std::to_string(numItems) + ")");
    }
    if(index < 0 or index >= numItems)
    {
        throw std::range_error("index (" + std::to_string(index) + 
        ") not in range [0.." + std::to_string(numItems) + ")");
    }
    return elementAtHelper(index, front)->data;
}
CharLinkedList::Node *CharLinkedList::elementAtHelper
(int index, Node *curr) const
{
    if(index == 0)
    {
        return curr;
    }
    else
    {
        curr = curr->next;
        return elementAtHelper(index - 1, curr);
    }
}
/* void CharLinkedList::pushAtFront(char c)
Purpose: push a character at the front of the CharLinkedList and adjust 
the necessary pointers of front and the previous pointer of the previous 
front node
Parameters: char c of node that will be pushed to the front of the 
CharLinkedList 
Return: n/a
*/ 
void CharLinkedList::pushAtFront(char c)
{
    if(isEmpty())
    {
        front = newNode(c, nullptr, nullptr);
        numItems++;
        back = front;
        return;
    }
    Node *front_node = newNode(c, front, nullptr);
    front->previous = front_node;
    front = front_node;
    if(numItems == 1)
    {
        back = front->next;
    }
    numItems++;
}
/* void CharLinkedList::pushAtBack(char c)
Purpose: push a character at the back of the CharLinkedList. Adjust pointers 
of previous back Node's next pointer and LinkedList back pointer to new
Node
Parameters: char c of node that will be pushed to the back of the 
CharLinkedList
Return: N/A
*/ 
void CharLinkedList::pushAtBack(char c)
{
    if(isEmpty())
    {
        front = newNode(c, nullptr, nullptr);
        numItems++;
        back = front;
        return;
    }
    Node *back_node = newNode(c);
    back->next = back_node;
    back_node->previous = elementAtHelper(numItems - 1, front);
    back = back_node;
    numItems++;
}
/* void CharLinkedList::insertAt(char c, index)
Purpose: Inserts a char at the given index and readjusts all the pointers 
of the Node "in front" of the new pointer and "behind" the new pointer
Parameters: char c of Node that will be inserted at the given int index
Return: N/A
*/ 
void CharLinkedList::insertAt(char c, int index)
{
    if(index < 0 or index > numItems)
    {
        throw std::range_error("index (" + std::to_string(index) + 
        ") not in range [0.." + std::to_string(numItems) + "]");
    }
    if(index == 0) //if insert at front
    {
        pushAtFront(c);
        return;
    }
    if(index == numItems) //if insert at end
    {
        pushAtBack(c);
        return;
    }
    Node *curr = elementAtHelper(index, front);
    if(curr)
    {
        Node *new_node = newNode(c);
        new_node->previous = curr->previous;
        new_node->next = curr;
        curr->previous->next = new_node;
        curr->previous = new_node;
        numItems++; 
    }
}
/* void CharLinkedList::removeAt(int index)
Purpose: remove a node at given index. Adjusts linking of nodes behind and
in front of node that was removed
Parameters: int index of position to remove node
Return: N/A
*/ 
void CharLinkedList::removeAt(int index)
{
    if(isEmpty())
    {
        throw std::range_error("index (" + std::to_string(index) + 
        ") not in range [0.." + std::to_string(numItems) + ")");
    }
    if(index < 0 or index >= numItems)
    {
        throw std::range_error("index (" + std::to_string(index) + 
        ") not in range [0.." + std::to_string(numItems) + ")");
    }
    Node *curr_node = elementAtHelper(index, front);
    if(index == 0) //remove front
    {
        front = elementAtHelper(index, front)->next;
        delete curr_node;
        numItems--;
        return;
    }
    if(index == numItems - 1) //remove back
    {
        back = elementAtHelper(index - 1, front);
        back->next = nullptr;
        delete curr_node;
        numItems--;
        return;
    }
    elementAtHelper(index - 1, front)->next = 
    elementAtHelper(index + 1, front);
    delete curr_node;
    numItems--; 
}
/* void CharLinkedList::popFromFront()
Purpose: remove the very first node from the CharLinkedList. Will give an error 
if CharLinkedList is empty.
Parameters: N/A
Return: N/A
*/ 
void CharLinkedList::popFromFront()
{
    if(isEmpty())
    {
        throw std::runtime_error("cannot pop from empty LinkedList");
    }
    removeAt(0);
}
/* void CharLinkedList::popFromFront()
Purpose: remove the very last node from the CharLinkedList. Will give an error 
if CharLinkedList is empty.
Parameters: N/A
Return: N/A
*/ 
void CharLinkedList::popFromBack()
{
    if(isEmpty())
    {
        throw std::runtime_error("cannot pop from empty LinkedList");
    }
    removeAt(numItems - 1);
}
/* void CharLinkedList::replaceAt(char c, int index)
Purpose: replaces the char at the given index with the given char. Will throw 
an error if index given is not in range of CharLinkedList
Parameters: char c that will replace the current char at the given int index
Return: N/A
*/ 
void CharLinkedList::replaceAt(char c, int index)
{
    if(isEmpty())
    {
        throw std::range_error("index (" + std::to_string(index) + 
        ") not in range [0.." + std::to_string(numItems) + ")");
    }
    if(index < 0 or index >= numItems)
    {
        throw std::range_error("index (" + std::to_string(index) + 
        ") not in range [0.." + std::to_string(numItems) + ")");
    }
    elementAtHelper(index, front)->data = c;
}
/* void CharLinkedList::clear()
Purpose: clears all nodes inside of CharLinkedList. Essentially makes it so
CharLinkedList is empty
Parameters: N/A
Return: N/A
*/ 
void CharLinkedList::clear()
{
    if(not(isEmpty()))
    {
        int staticNumItems = numItems;
        for(int i = 0; i < staticNumItems; i++)
        {
            popFromBack();
        }
    }
}
/* std::string CharLinkedList::toString() const
Purpose: turn the CharLinkedList into a string. Combines all of the chars
and puts them into a string. Calls special recursive function which accesses
the data of all of the nodes
Parameters: N/A
Return: a string of the CharLinkedList
*/ 
std::string CharLinkedList::toString() const
{
    string toString = "[CharLinkedList of size ";
    toString += std::to_string(numItems);
    toString += " <<";
    if(numItems > 0)
    {
        std::string word;
        toString += printRecersive(front, word);    
    }
    toString += ">>]";
    return toString;
}
/*std::string CharLinkedList::printRecursive
(Node *curr, std::string word) const
Purpose: Recursively travles through the LinkedList, taking the char from each
node and adding it to a string
Parameters: Node *curr where the iterating should start, string of 
current message written
Return: a string of the CharLinkedLIst
*/ 
std::string CharLinkedList::printRecersive(Node *curr, std::string word) const
{
    if(curr == nullptr)
    {
        return word;
    } else
    {
        word += curr->data;
        return printRecersive(curr->next, word);
    }
}
/*std::string CharLinkedList::printRecursiveBack
(Node *curr, std::string word) const
Purpose: Recursively travels through the LinkedList backwards, 
taking the char from each node and adding it to a string
Parameters: Node *curr where the iterating should start, string of 
current message written
Return: a string of the CharLinkedLIst backwards
*/ 
std::string CharLinkedList::printRecersiveBack
(Node *curr, std::string word) const
{
    if(curr == nullptr)
    {
        return word;
    } else
    {
        word += curr->data;
        return printRecersiveBack(curr->previous, word);
    }
}
/* std::string CharLinkedList::toReverseString() const
Purpose: turn the CharLinkedList into a string in reverse. 
Combines all of the chars and puts them into a string. 
Calls special recursive function which accesses the data of all of the nodes
from the back and goes to the front
Parameters: N/A
Return: a reversed string of the CharLinkedList
*/ 
std::string CharLinkedList::toReverseString() const
{
    string toString = "[CharLinkedList of size ";
    toString += std::to_string(numItems);
    toString += " <<";
    if(numItems > 0)
    {
        std::string word;
        toString += printRecersiveBack(back, word);    
    }
    toString += ">>]";
    return toString;
}
/* void CharLinkedList::concatenate(CharLinkedList *other)
Purpose: Concatenates two CharLinkedLists. Adds the given CharLinkedLists chars 
to the CharLinkedList which called the function. 
Parameters: CharLinkedList *other who's values will be added to the 
CharLinkedList which called the function.
Return: N/A
*/ 
void CharLinkedList::concatenate(CharLinkedList *other)
{
    if(this == other)
    {
        Node *curr_back = other->back;
        Node *curr = other->front;
        while(curr != curr_back)
        {
            pushAtBack(curr->data);
            curr = curr->next;
        }
        pushAtBack(curr->data);
        return;
    }
    Node *curr = other->front;
    while(curr != nullptr)
    {
        pushAtBack(curr->data);
        curr = curr->next;
    }
}
/* void CharLinkedList::insertInOrder(char c)
Purpose: inserts a char based on the given chars ASCII value as compared to 
the CharLinkedLists values' ASCII values. If the given char's ASCII value is 
less than or equal to the value in the CharLinkedList, the given char will be 
inserted at that index and the surrounding Nodes' pointers will be 
adjusted
Parameters: a char c which will be compared to the chars in the CharLinkedList
Return: N/A
*/ 
void CharLinkedList::insertInOrder(char c)
{
    Node *curr = front;
    int index = 0;
    while(index != numItems) // checks to see if char c has been inserted
    {
        if(c <= curr->data)
        {
            insertAt(c, index);
            return;
        }
        curr = curr->next;
        index++;
    }
    if(index == numItems) // inserts char c at end if no matches
        {
            pushAtBack(c);
        }
}
/*
 *  unit_tests.h
 *  YOUR NAME HERE
 *  DATE CREATED
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  FILE PURPOSE HERE
 *
 */
#include "CharLinkedList.h"
#include <cassert>
void test_simple_constructor()
{
    CharLinkedList List;
    assert(List.size() == 0);
}
void test_second_constructor()
{
    CharLinkedList List('c');
    assert(List.first() == 'c');
    assert(List.size() == 1);
    assert(List.last() == 'c');
}
void test_equal_operator()
{
    CharLinkedList List('c');
    CharLinkedList List2('a');
    List = List2;
    assert(List.first() == 'a');
    assert(List.last() == 'a');
}
void test_empty()
{
    CharLinkedList List;
    assert(List.isEmpty());
}
void test_empty_2()
{
    CharLinkedList List('c');
    assert(not List.isEmpty());
}
void test_element_at()
{
    CharLinkedList List('c');
    assert(List.elementAt(0) == 'c');
}
void test_insert_at_front()
{
    CharLinkedList List;
    List.pushAtFront('a');
    List.pushAtFront('b');
    List.pushAtFront('c');
    List.pushAtFront('a');
    List.pushAtFront('b');
    List.pushAtFront('c');
    List.pushAtFront('a');
    List.pushAtFront('b');
    List.pushAtFront('c');
    List.pushAtFront('a');
    List.pushAtFront('b');
    List.pushAtFront('c');
    List.pushAtFront('a');
    List.pushAtFront('b');
    List.pushAtFront('c');
    List.pushAtFront('a');
    List.pushAtFront('b');
    List.pushAtFront('c');
    List.pushAtFront('a');
    List.pushAtFront('b');
    List.pushAtFront('c');
    assert(not List.isEmpty());
    assert(List.last() == 'a');
}
void test_remove_at()
{
    CharLinkedList List;
    List.pushAtFront('a');
    List.pushAtFront('c');
    List.pushAtFront('a');
    List.pushAtFront('b');
    List.removeAt(2);
    assert(List.size() == 3);
    assert(List.elementAt(2) == 'a');
}
void test_remove_at_2()
{
    CharLinkedList List;
    List.pushAtFront('a');
    List.pushAtFront('c');
    List.pushAtFront('a');
    List.pushAtFront('b');
    List.removeAt(0);
    assert(List.size() == 3);
    assert(List.elementAt(0) == 'a');
}
void test_remove_at_3()
{
    CharLinkedList List;
    List.pushAtFront('a');
    List.pushAtFront('c');
    List.pushAtFront('a');
    List.pushAtFront('b');
    for(int i = 0; i < 4; i++)
    {
        List.removeAt(0);
    }
    assert(List.isEmpty());
}
void test_pop_from_front()
{
    CharLinkedList List;
    List.pushAtFront('a');
    List.pushAtFront('c');
    List.pushAtFront('a');
    List.pushAtFront('b');
    for(int i = 0; i < 4; i++)
    {
        List.popFromFront();
    }
    assert(List.isEmpty());
}
void test_pop_from_back()
{
    CharLinkedList List;
    List.pushAtFront('a');
    List.pushAtFront('c');
    List.pushAtFront('a');
    List.pushAtFront('b');
    for(int i = 0; i < 4; i++)
    {
        List.popFromBack();
    }
    assert(List.isEmpty());
}
void test_replace_at()
{
    CharLinkedList List;
    List.pushAtFront('a');
    List.pushAtFront('c');
    List.pushAtFront('a');
    List.pushAtFront('b');
    for(int i = 0; i < 4; i++)
    {
        List.replaceAt('z', i);
    }
    assert(List.first() == 'z');
    assert(List.elementAt(1) == 'z');
    assert(List.last() == 'z');
}
void test_insert_at()
{
    CharLinkedList List;
    List.pushAtFront('a');
    List.pushAtFront('c');
    List.pushAtFront('b');
    List.insertAt('z', 1);
    assert(List.elementAt(1) == 'z');
}
void test_insert_at_1()
{
    CharLinkedList List;
    List.pushAtFront('a');
    List.pushAtFront('c');
    List.pushAtFront('b');
    List.insertAt('z', 0);
    List.insertAt('g', 4);
    List.pushAtBack('g');
    assert(List.elementAt(0) == 'z');
    assert(List.last() == 'g');
}
void test_clear()
{
    CharLinkedList List;
    List.pushAtFront('a');
    List.pushAtFront('c');
    List.pushAtFront('b');
    List.insertAt('z', 0);
    List.insertAt('g', 4);
    List.pushAtBack('g');
    List.clear();
    assert(List.isEmpty());
}
void test_equal_operator_2() {
    CharLinkedList List;
    CharLinkedList List2;
    List.pushAtFront('a');
    List.pushAtFront('c');
    List.pushAtFront('b');
    List = List2;
    assert(List.isEmpty());
    assert(List.size() == 0);
    assert(List.toString() == "[CharLinkedList of size 0 <<>>]");
    assert(List2.size() == 0);
    assert(List2.toString() == "[CharLinkedList of size 0 <<>>]");
}
void test_equal_operator_1() {
    CharLinkedList List;
    CharLinkedList List2;
    List.pushAtFront('a');
    List.pushAtFront('c');
    List.pushAtFront('b');
    List2.pushAtFront('c');
    List2.pushAtBack('a');
    List2.pushAtBack('t');
    List = List2;
    assert(List.size() == 3);
    assert(List.toString() == "[CharLinkedList of size 3 <<cat>>]");
    assert(List2.size() == 3);
    assert(List2.toString() == "[CharLinkedList of size 3 <<cat>>]");
}
void test_concatenatett() {
    CharLinkedList List;
    CharLinkedList List2;
    List.pushAtFront('a');
    List.pushAtFront('c');
    List.pushAtFront('b');
    List2.pushAtFront('c');
    List2.pushAtBack('a');
    List2.pushAtBack('t');
    List.concatenate(&List2);
    assert(List.toString() == "[CharLinkedList of size 6 <<bcacat>>]");
}
void test_concatenatett_2() {
    CharLinkedList List;
    CharLinkedList List2;
    List.pushAtFront('a');
    List.pushAtFront('c');
    List.pushAtFront('b');
    List2.pushAtFront('c');
    List2.pushAtBack('a');
    List2.pushAtBack('t');
    List2.concatenate(&List2);
    assert(List2.toString() == "[CharLinkedList of size 6 <<catcat>>]");
}
void test_concatenatett_3() {
    CharLinkedList List;
    CharLinkedList List2;
    List2.pushAtFront('c');
    List2.pushAtBack('a');
    List2.pushAtBack('t');
    List.concatenate(&List2);
    assert(List.toString() == "[CharLinkedList of size 3 <<cat>>]");
}
void test_concatenatett_4() {
    CharLinkedList List;
    CharLinkedList List2;
    List2.pushAtFront('c');
    List2.pushAtBack('a');
    List2.pushAtBack('t');
    List2.concatenate(&List);
    assert(List2.toString() == "[CharLinkedList of size 3 <<cat>>]");
}
void test_reverse_to_string()
{
    CharLinkedList List;
    for(int i = 0; i < 6; i++)
    {
        List.pushAtFront('a');
    }
    List.pushAtFront('z');
    assert(List.toReverseString() == "[CharLinkedList of size 7 <<aaaaaaz>>]");
}
void test_to_reverse_string_2() {
    CharLinkedList List;
    CharLinkedList List2;
    List.pushAtFront('a');
    List.pushAtFront('c');
    List.pushAtFront('b');
    List = List2;
    assert(List.isEmpty());
    assert(List.size() == 0);
    assert(List.toReverseString() == "[CharLinkedList of size 0 <<>>]");
    assert(List2.size() == 0);
    assert(List2.toReverseString() == "[CharLinkedList of size 0 <<>>]");
}
void test_insert_in_order() {
    CharLinkedList List;
    List.pushAtFront('a');
    List.pushAtFront('c');
    List.pushAtFront('b');
    List.insertInOrder('!');
    assert(List.size() == 4);
    assert(List.first() == '!');
}
void test_insert_in_order_2() {
    CharLinkedList List;
    List.pushAtFront('a');
    List.pushAtFront('c');
    List.pushAtFront('b');
    List.insertInOrder('!');
    List.insertInOrder('a');
    assert(List.size() == 5);
    assert(List.elementAt(0) == '!');
    assert(List.elementAt(1) == 'a');
}
void test_insert_in_order_2_CAPS() {
    char test_arr[10] = { 'a', 'A', 'b', 'C', 'Z', 'D', 'e', 'F', 'g', 'h' };
    CharLinkedList test_list(test_arr, 10);  

    test_list.insertInOrder('x');
    assert(test_list.size() == 11);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(10) == 'x');
    assert(test_list.toString() == 
    "[CharLinkedList of size 11 <<aAbCZDeFghx>>]"); 
}
void test_insert_at_middle()
{
    char test_arr[10] = { 'A', 'A', 'b', 'C', 'Z', 'D', 'e', 'F', 'g', 'h' };
    CharLinkedList test_list(test_arr, 10);  
    test_list.insertAt('a', 10);
    assert(test_list.size() == 11);
}

void test_empty_first() {
    CharLinkedList List;

    // var to track whether range_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";
    try {
        List.first();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "cannot get first of empty LinkedList");
}
void test_empty_last() {
    CharLinkedList List;

    // var to track whether range_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";
    try {
        List.last();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "cannot get last of empty LinkedList");
}
void elementtAt_nonempty_incorrect() {
   
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.elementAt(42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8)");
}
void test_empty_pop_from_front() {
    CharLinkedList List;

    // var to track whether range_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";
    try {
        List.popFromFront();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}
void test_empty_pop_from_back() {
    CharLinkedList List;

    // var to track whether range_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";
    try {
        List.popFromBack();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}
void removeAt_nonempty_incorrect() {
   
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.removeAt(42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8)");
}
void replaceAt_nonempty_incorrect() {
   
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.replaceAt('c', -1);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (-1) not in range [0..8)");
}
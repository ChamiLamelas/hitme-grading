/*
 *  CharLinkedList.h
 *  YOUR NAME HERE
 *  DATE CREATED
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  FILE PURPOSE HERE
 *
 */

#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H
#include <string>

class CharLinkedList {
public:
    CharLinkedList(); // 
    CharLinkedList(char c); //
    CharLinkedList(char arr[], int size); //
    CharLinkedList(const CharLinkedList &other); //
    ~CharLinkedList(); // 
    CharLinkedList &operator=(const CharLinkedList &other); // 
    bool isEmpty() const; // 
    void clear(); //
    int size() const; // 
    char first() const; //
    char last() const; // 
    char elementAt(int index) const; //
    std::string toString() const; //
    std::string toReverseString() const; //
    void pushAtBack(char c); //
    void pushAtFront(char c); //
    void insertAt(char c, int index); //
    void insertInOrder(char c); 
    void popFromFront(); //
    void popFromBack(); //
    void removeAt(int index); //
    void replaceAt(char c, int index); //
    void concatenate(CharLinkedList *other); //
private:
    struct Node
    {
        char data;
        Node *next;
        Node *previous;
    };
    Node *front;
    Node *back;
    int numItems;
    Node *newNode(char data, Node *next, Node *previous);
    Node *newNode(char data); //
    void deconstructRecursive(Node *curr); //
    std::string printRecersive(Node *curr, std::string word) const;
    std::string printRecersiveBack(Node *curr, std::string word) const;
    Node *elementAtHelper(int index, Node *curr) const;
};

#endif

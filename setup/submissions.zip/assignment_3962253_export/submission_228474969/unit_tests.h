/*
 *  unit_tests.h
 *  Shepard Rodgers (srodge01)
 *  2/1/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Uses the unit_test framework to test the CharLinkedList class.
 *
 */

#include "CharLinkedList.h"
#include <cassert>

using namespace std;

/********************************************************************\
*                       CHAR LINKED LIST TESTS                        *
\********************************************************************/

// Empty test to make sure class has been properly defined
void class_definition_test() {}

///////////////////// Constructors/Destructor /////////////////////////

// Make sure default constructor has no fatal errors/memory leaks
void default_constructor_call() {
    CharLinkedList list;
}

// Make sure default constructor correctly updates size
void default_constructor_size() {
    CharLinkedList list;
    assert(list.size() == 0);
}

// Make sure singleton constructor has no fatal errors/memory leaks
void singleton_constructor_call() {
    CharLinkedList list('a');
}

// Make sure singleton constructor correctly updates size
void singleton_constructor_size() {
    CharLinkedList list('a');
    assert(list.size() == 1);
}

// Make sure the array constructor has no fatal errors/memory leaks
void array_constructor_call() {
    char arr[5] = {'A','l','i','c','e'};
    CharLinkedList list(arr, 5);
}

// Make sure array constructor correctly updates size
void array_constructor_size() {
    char arr[5] = {'A','l','i','c','e'};
    CharLinkedList list(arr, 5);
    assert(list.size() == 5);
}

// Make sure array constructor properly initializes list with a large array.
void array_constructor_large() {
    char arr[5] = {'A','l','i','c','e'};
    CharLinkedList list(arr, 5);
    assert(list.toString() == "[CharLinkedList of size 5 <<Alice>>]");
}

// Make sure array constructor properly initializes list with an empty.
void array_constructor_empty() {
    char arr[0] = {};
    CharLinkedList list(arr, 0);
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}

// Make sure copy constructor has no fatal errors/mem leaks
void copy_constructor_call() {
    char arr[5] = {'A','l','i','c','e'};
    CharLinkedList list(arr, 5);

    CharLinkedList copied_list(list);
}

// Make sure copy constructor correctly copies a populated list
void copy_constructor_populated() {
    char arr[5] = {'A','l','i','c','e'};
    CharLinkedList list(arr, 5);

    CharLinkedList copied_list(list);
    assert(copied_list.toString() == "[CharLinkedList of size 5 <<Alice>>]");
}

// Make sure copy constructor correctly copies a singleton list
void copy_constructor_singleton() {
    char arr[5] = {'a'};
    CharLinkedList list(arr, 1);

    CharLinkedList copied_list(list);
    assert(copied_list.toString() == "[CharLinkedList of size 1 <<a>>]");
}

// Make sure copy constructor correctly copies an empty list
void copy_constructor_empty() {
    char arr[0] = {};
    CharLinkedList list(arr, 0);

    CharLinkedList copied_list(list);
    assert(copied_list.toString() == "[CharLinkedList of size 0 <<>>]");
}

// Make sure destructor properly handles an empty list w/o memory errors
void destructor_empty() {
    CharLinkedList list;
}

// Make sure destructor properly frees memory for a list of size 1.
void destructor_singleton() {
    CharLinkedList list('a');
}

// Make sure destructor properly frees memory for a small list.
void destructor_small() {
    char arr[2] = {'a','b'};
    CharLinkedList list(arr, 2);
}

// Make sure destructor properly frees memory for a large list.
void destructor_large() {
    char arr[12] = {'A','l','i','c','e',' ','R','a','b','b','i','t'};
    CharLinkedList list(arr, 12);
}

// Make sure assignment operator correctly assigns a populated list 
// to a populated list
void assignment_operator_full_full() {
    char arr1[5] = {'A','l','i','c','e'};
    CharLinkedList list1(arr1, 5);

    char arr2[10] = {'W','o','n','d','e','r','l','a','n','d'};
    CharLinkedList list2(arr2, 10);

    list1 = list2;
    assert(list1.toString() == 
    "[CharLinkedList of size 10 <<Wonderland>>]");
}

// Make sure assignment operator correctly assigns a populated list 
// to an empty list
void assignment_operator_full_empty() {
    char arr1[0] = {};
    CharLinkedList list1(arr1, 0);

    char arr2[10] = {'W','o','n','d','e','r','l','a','n','d'};
    CharLinkedList list2(arr2, 10);

    list1 = list2;
    assert(list1.toString() == 
    "[CharLinkedList of size 10 <<Wonderland>>]");
}

// Make sure assignment operator correctly assigns an empty list 
// to a populated list
void assignment_operator_empty_full() {
    char arr1[0] = {};
    CharLinkedList list1(arr1, 0);

    char arr2[10] = {'W','o','n','d','e','r','l','a','n','d'};
    CharLinkedList list2(arr2, 10);

    list2 = list1;
    assert(list2.toString() == 
    "[CharLinkedList of size 0 <<>>]");
}

// Make sure assignment operator correctly assigns an empty list 
// to an empty list
void assignment_operator_empty_empty() {
    char arr1[0] = {};
    CharLinkedList list1(arr1, 0);

    char arr2[0] = {};
    CharLinkedList list2(arr2, 0);

    list2 = list1;
    assert(list2.toString() == 
    "[CharLinkedList of size 0 <<>>]");
}

// Make sure assignment operator correctly links assignment operations
void assignment_operator_linked() {
    char arr1[5] = {'A','l','i','c','e'};
    CharLinkedList list1(arr1, 5);

    char arr2[2] = {'I','n'};
    CharLinkedList list2(arr2, 2);

    char arr3[10] = {'W','o','n','d','e','r','l','a','n','d'};
    CharLinkedList list3(arr3, 10);

    list1 = list2 = list3;
    assert(list1.toString() == 
    "[CharLinkedList of size 10 <<Wonderland>>]");
}

///////////////////////// Get Functions /////////////////////////

// Make sure we report an empty list correctly.
void isEmpty_empty() {
    CharLinkedList list;
    assert(list.isEmpty());
}

// Make sure we report an non-empty list correctly.
void isEmpty_not_empty() {
    char arr[5] = {'A','l','i','c','e'};
    CharLinkedList arr_list(arr, 5);
    
    assert(not(arr_list.isEmpty()));
}

// Makes sure the size function correctly returns for populated list
void size_test_populated() {
    CharLinkedList list;
    list.insertAt('a', 0);
    list.insertAt('c', 1);
    list.insertAt('b', 1);

    assert(list.size() == 3);
}

// Makes sure the size function correctly returns for empty list
void size_test_empty() {
    CharLinkedList list;

    assert(list.size() == 0);
}

// Makes sure the first function correctly returns the first element in a 
// populated list
void first_test_populated() {
    CharLinkedList list;
    list.insertAt('a', 0);
    list.insertAt('c', 1);
    list.insertAt('b', 1);

    assert(list.first() == 'a');
}

// Makes sure the first function correctly throws an error when used on an
// empty list.
void first_test_empty() {
    CharLinkedList list;
    
    // var to track whether range_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    string error_message = "";

    try {
    // first for empty list
    list.first();
    }
    catch (const runtime_error &e) {
    // if first is correctly implemented, a range_error will be thrown,
    // and we will end up here
    runtime_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(runtime_error_thrown);
    assert(error_message == "cannot get first of empty LinkedList");
}

// Makes sure the last function correctly returns for a populated list
void last_test_populated() {
    CharLinkedList list;
    list.insertAt('a', 0);
    list.insertAt('c', 1);
    list.insertAt('b', 1);

    assert(list.last() == 'c');
}

// Makes sure the last function correctly throws an error when used on an
// empty list.
void last_test_empty() {
    CharLinkedList list;
    
    // var to track whether range_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    string error_message = "";

    try {
    // last for empty list
    list.last();
    }
    catch (const runtime_error &e) {
    // if first is correctly implemented, a range_error will be thrown,
    // and we will end up here
    runtime_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(runtime_error_thrown);
    assert(error_message == "cannot get last of empty LinkedList");
}

// Make sure elementAt function has no fatal errors/mem leaks
void elementAt_call() {
    CharLinkedList list('a');
    list.elementAt(0);
}

// Make sure elementAt function correctly returns element in a single-item list
void elementAt_singleton_correct() {
    CharLinkedList list('a');
    assert(list.elementAt(0) == 'a');
}

// Make sure elementAt function correctly throws an error when called on an
// empty list
void elementAt_empty_incorrect() {
    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    string error_message = "";

    CharLinkedList list;
    try {
        // elementAt in empty list
        list.elementAt(0);
    }
    catch (const range_error &e) {
        // if elementAt is correctly implemented, a range_error will be thrown
        range_error_thrown = true;
        error_message = e.what();
    }

    // make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (0) not in range [0..0)");
}

// Make sure elementAt function correctly throws an error when called with an
// out-of-range index for a nonempty list
void elementAt_singleton_incorrect() {
    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    string error_message = "";

    CharLinkedList list('a');
    try {
        // elementAt w/ out of range index
        list.elementAt(6);
    }
    catch (const range_error &e) {
        // if elementAt is correctly implemented, a range_error will be thrown
        range_error_thrown = true;
        error_message = e.what();
    }

    // make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (6) not in range [0..1)");
}

// Make sure elementAt function correctly returns element in a single-item list
void elementAt_large() {
    char arr[5] = {'A','l','i','c','e'};
    CharLinkedList list(arr, 5);
    assert(list.elementAt(3) == 'c');
}

// Make sure toString function has no fatal errors/mem leaks
void toString_call() {
    CharLinkedList list('a');
    list.toString();
}

// Make sure toString function correctly ouputs list data for empty list
void toString_empty() {
    CharLinkedList list;
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}

// Make sure toString function correctly ouputs list data for singleton list
void toString_singleton() {
    CharLinkedList list('a');
    assert(list.toString() == "[CharLinkedList of size 1 <<a>>]");
}

// Make sure toString function correctly ouputs list data for larger list
void toString_large() {
    char test_arr[9] = { 'A', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList list(test_arr, 9);
    assert(list.toString() == "[CharLinkedList of size 9 <<Abczdefgh>>]");
}

// Make sure toReverseString function has no fatal errors/mem leaks
void toReverseString_call() {
    CharLinkedList list('a');
    list.toReverseString();
}

// Make sure toReverseString function correctly ouputs data for empty list
void toReverseString_empty() {
    CharLinkedList list;
    assert(list.toReverseString() == "[CharLinkedList of size 0 <<>>]");
}

// Make sure toReverseString function correctly ouputs list data for singleton 
// list
void toReverseString_singleton() {
    CharLinkedList list('a');
    assert(list.toReverseString() == "[CharLinkedList of size 1 <<a>>]");
}

// Make sure toReverseString function correctly ouputs list data for larger list
void toReverseString_large() {
    char test_arr[9] = { 'A', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList list(test_arr, 9);
    assert(list.toReverseString() == 
        "[CharLinkedList of size 9 <<hgfedzcbA>>]");
}

///////////////////////// Add Functions /////////////////////////

// Make sure pushAtBack correctly inserts at the "back" of an empty list
void pushAtBack_empty() {
    CharLinkedList list;
    list.pushAtBack('a');

    assert(list.size() == 1);
    assert(list.elementAt(0) == 'a');
}

// Make sure pushAtBack correctly inserts at the back of a single-element list
void pushAtBack_singleton() {
    CharLinkedList list('a');
    list.pushAtBack('b');

    assert(list.size() == 2);
    assert(list.elementAt(1) == 'b');
}

// Make sure pushAtBack correctly inserts many elements at the back of a list
void pushAtBack_many_elements() {
    CharLinkedList list;

    // push 1000 elements
    for (int i = 0; i < 1000; i++) {
        list.pushAtBack('a');
    }

    list.pushAtBack('b');

    // Assert statements
    assert(list.size() == 1001);

    for (int i = 0; i < 1000; i++) {
        assert(list.elementAt(i) == 'a');
    }

    assert(list.elementAt(1000) == 'b');
}

// Make sure pushAtFront correctly inserts at the "front" of an empty list
void pushAtFront_empty() {
    CharLinkedList list;
    list.pushAtFront('a');

    assert(list.size() == 1);
    assert(list.elementAt(0) == 'a');
}

//Make sure pushAtFront correctly inserts at the front of a single-element list
void pushAtFront_singleton() {
    CharLinkedList list('a');
    list.pushAtFront('b');

    assert(list.size() == 2);
    assert(list.elementAt(0) == 'b');
}

// Make sure pushAtFront correctly inserts many elements at the front of a list
void pushAtFront_many_elements() {
    CharLinkedList list;

    // push 1000 elements
    for (int i = 0; i < 1000; i++) {
        list.pushAtFront('a');
    }

    list.pushAtFront('b');

    // Assert statements
    assert(list.size() == 1001);

    for (int i = 1; i < 1001; i++) {
        assert(list.elementAt(i) == 'a');
    }

    assert(list.elementAt(0) == 'b');
}

// Make sure insertAt function has no fatal errors/memory leaks
void insertAt_call() {
    CharLinkedList list;
    list.insertAt('a', 0);
}

// Make sure insertAt function correctly inserts into an empty list
void insertAt_empty_correct() {
    CharLinkedList list;
    
    list.insertAt('a', 0);
    assert(list.size() == 1);
    assert(list.elementAt(0) == 'a');
}

// Make sure insertAt function correctly throws a range error when attempting
// to insert at out-of-range index
void insertAt_empty_incorrect() {
    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    string error_message = "";

    CharLinkedList list;
    try {
        // insertAt for out-of-range index
        list.insertAt('a', 42);
    }
    catch (const range_error &e) {
        // if insertAt is correctly implemented, a range_error will be thrown
        range_error_thrown = true;
        error_message = e.what();
    }

    // make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0]");
}

// Tests correct insertAt for front of 1-element list.
void insertAt_front_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList list('a');

    // insert at front
    list.insertAt('b', 0);

    assert(list.size() == 2);
    assert(list.elementAt(0) == 'b');
    assert(list.elementAt(1) == 'a');
}

// Tests correct insertAt for back of 1-element list.
void insertAt_back_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList list('a');

    // insert at back
    list.insertAt('b', 1);

    assert(list.size() == 2);
    assert(list.elementAt(0) == 'a');
    assert(list.elementAt(1) == 'b');
    
}

// Tests insertion into front of a larger list
void insertAt_front_large_list() {
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList list(test_arr, 9);

    list.insertAt('y', 0);

    assert(list.size() == 10);
    assert(list.elementAt(0) == 'y');
    assert(list.toString() == "[CharLinkedList of size 10 <<yabczdefgh>>]");

}

// Tests insertion into the back of a larger list
void insertAt_back_large_list() {

    char test_arr[10] = { 'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList list(test_arr, 10);  

    list.insertAt('x', 10);

    assert(list.size() == 11);
    assert(list.elementAt(10) == 'x');
    assert(list.toString() == 
    "[CharLinkedList of size 11 <<yabczdefghx>>]"); 

}

// Tests insertion into the middle of a larger list
void insertAt_middle_large_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList list(test_arr, 8);

    list.insertAt('z', 3);

    assert(list.size() == 9);
    assert(list.elementAt(3) == 'z');
    assert(list.toString() == "[CharLinkedList of size 9 <<abczdefgh>>]");

}

// Tests out-of-range insertion for a non-empty list.
void insertAt_nonempty_incorrect() {
   
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    string error_message = "";

    try {
        list.insertAt('a', 42);
    }
    catch (const range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8]");
}

// Tests calling insertAt for a large number of elements.
void insertAt_many_elements() {
    
    CharLinkedList list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        list.insertAt('a', i);
    }

    assert(list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(list.elementAt(i) == 'a');
    }
}

///////////////////////// Remove Functions /////////////////////////

// Makes sure the insertInOrder function correctly inserts a character at 
// the correct sorted ASCII position in a sorted list
void insertInOrder_alphabetical() {
    CharLinkedList list;
    list.pushAtFront('F');
    list.pushAtFront('E');
    list.pushAtFront('D');
    list.pushAtFront('B');
    list.pushAtFront('A');

    list.insertInOrder('C');
    
    assert(list.toString() == "[CharLinkedList of size 6 <<ABCDEF>>]");
}

// Makes sure the insertInOrder function correctly inserts a number character
// at the correct sorted ASCII position in a  list
void insertInOrder_number() {
    CharLinkedList list;
    list.pushAtFront('d');
    list.pushAtFront('c');
    list.pushAtFront('b');
    list.pushAtFront('a');

    list.insertInOrder('7');
    
    assert(list.toString() == "[CharLinkedList of size 5 <<7abcd>>]");
}

// Makes sure the insertInOrder function correctly inserts a character at 
// the correct sorted ASCII position in an unsorted list
void insertInOrder_random() {
    CharLinkedList list;
    list.pushAtFront('D');
    list.pushAtFront('E');
    list.pushAtFront('Z');

    list.insertInOrder('A');
    
    assert(list.toString() == "[CharLinkedList of size 4 <<AZED>>]");
}

// Makes sure the insertInOrder function correctly inserts a character into
// an empty list
void insertInOrder_empty() {
    CharLinkedList list;

    list.insertInOrder('a');
    
    assert(list.toString() == "[CharLinkedList of size 1 <<a>>]");
}

// Make sure concatenate function correctly adds a populated list 
// to a populated list
void concatenate_full_full() {
    char arr1[5] = {'A','l','i','c','e'};
    CharLinkedList list1(arr1, 5);

    char arr2[10] = {'W','o','n','d','e','r','l','a','n','d'};
    CharLinkedList list2(arr2, 10);

    list1.concatenate(&list2);
    assert(list1.toString() == 
    "[CharLinkedList of size 15 <<AliceWonderland>>]");
}

// Make sure concatenate function correctly adds a populated list 
// to an empty list
void concatenate_full_empty() {
    char arr1[0] = {};
    CharLinkedList list1(arr1, 0);

    char arr2[10] = {'W','o','n','d','e','r','l','a','n','d'};
    CharLinkedList list2(arr2, 10);

    list1.concatenate(&list2);
    assert(list1.toString() == 
    "[CharLinkedList of size 10 <<Wonderland>>]");
}

// Make sure concatenate function correctly adds an empty list 
// to a populated list
void concatenate_empty_full() {
    char arr1[0] = {};
    CharLinkedList list1(arr1, 0);

    char arr2[10] = {'W','o','n','d','e','r','l','a','n','d'};
    CharLinkedList list2(arr2, 10);

    list2.concatenate(&list1);
    assert(list2.toString() == 
    "[CharLinkedList of size 10 <<Wonderland>>]");
}

// Make sure concatenate function correctly adds an empty list 
// to an empty list
void concatenate_empty_empty() {
    char arr1[0] = {};
    CharLinkedList list1(arr1, 0);

    char arr2[0] = {};
    CharLinkedList list2(arr2, 0);

    list1.concatenate(&list2);
    assert(list1.toString() == 
    "[CharLinkedList of size 0 <<>>]");
}

// Make sure concatenate function correctly adds a list 
// to itself
void concatenate_self() {
    char arr[10] = {'W','o','n','d','e','r','l','a','n','d'};
    CharLinkedList list(arr, 10);

    list.concatenate(&list);
    assert(list.toString() == 
    "[CharLinkedList of size 20 <<WonderlandWonderland>>]");
}

// Make sure replaceAt function correctly throws a range error when attempting
// to remove from an empty list
void replaceAt_empty() {
    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    string error_message = "";

    CharLinkedList list;
    try {
        // replaceAt for empty list
        list.replaceAt('z', 0);
    }
    catch (const range_error &e) {
        // if removeAt is correctly implemented, a range_error will be thrown
        range_error_thrown = true;
        error_message = e.what();
    }

    // make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (0) not in range [0..0)");
}


// Make sure replaceAt function correctly throws a range error when attempting
// to remove at an out-of-range index
void replaceAt_incorrect() {
    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    string error_message = "";

    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList list(test_arr, 8);

    try {
        // replaceAt out of range
        list.replaceAt('z', 47);
    }
    catch (const range_error &e) {
        // if removeAt is correctly implemented, a range_error will be thrown
        range_error_thrown = true;
        error_message = e.what();
    }

    // make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (47) not in range [0..8)");
}

// Make sure replaceAt function correctly replaces the first char in a list
void replaceAt_front() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList list(test_arr, 8);

    list.replaceAt('z', 0);
    assert(list.toString() == "[CharLinkedList of size 8 <<zbcdefgh>>]");
}

// Make sure replaceAt function correctly replaces the last char in a list
void replaceAt_back() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList list(test_arr, 8);

    list.replaceAt('z', 7);
    assert(list.toString() == "[CharLinkedList of size 8 <<abcdefgz>>]");
}

// Make sure replaceAt function correctly replaces in the middle of a list
void replaceAt_middle() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList list(test_arr, 8);

    list.replaceAt('z', 3);
    assert(list.toString() == "[CharLinkedList of size 8 <<abczefgh>>]");
}

// Make sure clear function correctly handles an empty list
void clear_empty() {
    CharLinkedList list;

    list.clear();
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}

// Make sure clear function correctly handles a populated list
void clear_populated() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList list(test_arr, 8);

    list.clear();
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}


// Makes sure the popFromFront function correctly removes the first element
// from a populated list
void popFromFront_populated_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList list(test_arr, 8);

    list.popFromFront();
    
    assert(list.toString() == "[CharLinkedList of size 7 <<bcdefgh>>]");
}

// Makes sure the popFromFront function correctly removes many elements
// from a large list
void popFromFront_many() {
    CharLinkedList list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        list.insertAt('a', i);
    }

    // pop 1000 elements
    for (int i = 0; i < 1000; i++) {
        // pop all elements from the front
        list.popFromFront();
    }
    
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}

// Makes sure the popFromFront function correctly throws an error
// when called on an empty list.
void popFromFront_empty() {
    CharLinkedList list;
    
    // var to track whether range_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    string error_message = "";

    try {
        // popFromFront with empty list
        list.popFromFront();
    }
    catch (const runtime_error &e) {
        // if elementAt is correctly implemented, a range_error will be thrown,
        // and we will end up here
        runtime_error_thrown = true;
        error_message = e.what();
    }

    // out here, we make our assertions
    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

// Makes sure the popFromBack function correctly removes the last element
// from a populated list
void popFromBack_populated_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList list(test_arr, 8);

    list.popFromBack();
    
    assert(list.toString() == "[CharLinkedList of size 7 <<abcdefg>>]");
}

// Makes sure the popFromBack function correctly removes many elements
// from a large list
void popFromBack_many() {
    CharLinkedList list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        list.insertAt('a', i);
    }

    // pop 1000 elements
    for (int i = 0; i < 1000; i++) {
        // pop all elements from the front
        list.popFromBack();
    }
    
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}

// Makes sure the popFromBack function correctly throws an error
// when called on an empty list.
void popFromBack_empty() {
    CharLinkedList list;
    
    // var to track whether range_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    string error_message = "";

    try {
        // popFromFront with empty list
        list.popFromBack();
    }
        catch (const runtime_error &e) {
        // if elementAt is correctly implemented, a range_error will be thrown,
        // and we will end up here
        runtime_error_thrown = true;
        error_message = e.what();
    }

    // out here, we make our assertions
    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

// Make sure removeAt function has no fatal errors/memory leaks
void removeAt_call() {
    CharLinkedList list('a');
    list.removeAt(0);
}

// Make sure removeAt function correctly throws a range error when attempting
// to remove from an empty list
void removeAt_empty() {
    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    string error_message = "";

    CharLinkedList list;
    try {
        // removeAt for empty list
        list.removeAt(0);
    }
    catch (const range_error &e) {
        // if removeAt is correctly implemented, a range_error will be thrown
        range_error_thrown = true;
        error_message = e.what();
    }

    // make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (0) not in range [0..0)");
}

// Tests correct removeAt for 1-element list.
void removeAt_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList list('a');

    // remove element
    list.removeAt(0);

    list.toString();

    assert(list.size() == 0);
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}

// Tests removal from front of a larger list
void removeAt_front_large_list() {
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList list(test_arr, 9);

    list.removeAt(0);

    assert(list.size() == 8);
    assert(list.elementAt(0) == 'b');
    assert(list.toString() == "[CharLinkedList of size 8 <<bczdefgh>>]");

}

// Tests removal from the back of a larger list
void removeAt_back_large_list() {
    char test_arr[10] = { 'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList list(test_arr, 10);  

    list.removeAt(9);

    assert(list.size() == 9);
    assert(list.elementAt(8) == 'g');
    assert(list.toString() == "[CharLinkedList of size 9 <<yabczdefg>>]"); 

}

// Tests removal from the middle of a larger list
void removeAt_middle_large_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList list(test_arr, 8);

    list.removeAt(3);

    assert(list.size() == 7);
    assert(list.elementAt(3) == 'e');
    assert(list.toString() == "[CharLinkedList of size 7 <<abcefgh>>]");

}

// Tests out-of-range removal for a non-empty list.
void removeAt_nonempty_incorrect() {
   
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    string error_message = "";

    try {
        list.removeAt(42);
    }
    catch (const range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8)");
}

// Tests calling removeAt for a large number of elements after inserting.
void removeAt_many_elements() {
    
    CharLinkedList list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // insert at the back of the list
        list.insertAt('a', i);
    }

    for (int i = 0; i < 500; i++) {
        // remove from the front of the list
        list.removeAt(0);
    }

    assert(list.size() == 500);

    for (int i = 0; i < 500; i++) {
        assert(list.elementAt(i) == 'a');
    }
}

///////////////////////// Helper Functions /////////////////////////
// Helper functions were moved from private to public for testing //
////////////////////////////////////////////////////////////////////

// // Make sure newNode has no fatal errors/memory leaks
// void newNode_call() {
//     CharLinkedList list;
//     CharLinkedList::Node *newNode = list.newNode('a', nullptr, nullptr);
//     delete newNode;
// }

// // Make sure newNode correctly creates a node with the inputted char
// void newNode_data() {
//     CharLinkedList list;
//     CharLinkedList::Node *newNode = list.newNode('a', nullptr, nullptr);
//     assert(newNode->data == 'a');
//     delete newNode;
// }

// // Make sure newNode correctly creates a node with the inputted "next" and
// // "previous" Node pointer values
// void newNode_pointers() {
//     CharLinkedList list;
//     CharLinkedList::Node *newNode = list.newNode('a', nullptr, nullptr);
//     assert(newNode->next == nullptr);
//     assert(newNode->previous == nullptr);
//     delete newNode;
// }

// // Make sure findNode correctly returns the Node address at the front
// void findNode_front() {
//     char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
//     CharLinkedList list(test_arr, 8);

//     assert(list.findNode(0)->data == 'a');
// }

// // Make sure findNode correctly returns the Node address at the back
// void findNode_back() {
//     char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
//     CharLinkedList list(test_arr, 8);

//     assert(list.findNode(7)->data == 'h');
// }

// // Make sure findNode correctly returns the Node address in the middle
// void findNode_middle() {
//     char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
//     CharLinkedList list(test_arr, 8);

//     assert(list.findNode(4)->data == 'e');
// }
/*
 *  CharLinkedList.cpp
 *  Shepard Rodgers (srodge01)
 *  2/1/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 * This file contains an implementation of the CharLinkedList class.
 *
 */

#include "CharLinkedList.h"
#include <sstream>
#include <iostream>

using namespace std;

///////////////////// Constructors/Destructor /////////////////////////

/*
* name:      CharLinkedList default constructor
* purpose:   initialize an empty CharLinkedList
* arguments: none
* returns:   none
* effects:   currSize to 0 (also updates front and back pointers)
*/
CharLinkedList::CharLinkedList() {
    currSize = 0;
    front = back = nullptr;
}

/*
* name:      CharLinkedList character constructor
* purpose:   initialize a CharLinkedList with a given character
* arguments: none
* returns:   none
* effects:   currSize to 1 (also updates data and front/back pointers)
*/
CharLinkedList::CharLinkedList(char c) {
    currSize = 1;
    front = back = newNode(c, nullptr, nullptr);
}

/*
* name:      CharLinkedList array constructor
* purpose:   initialize a CharLinkedList with the elements of a given array
* arguments: none
* returns:   none
* effects:   currSize to array size (also updates data and front/back pointers)
*/
CharLinkedList::CharLinkedList(char arr[], int size) {
    currSize = 0;
    // Insert elements sequentially when array size > 0;
    if (size != 0) {
        for (int i = 0; i < size; i++) {
            pushAtBack(arr[i]);
        }
    } else {
        front = back = nullptr;
    }
}

/*
* name:      CharLinkedList copy constructor
* purpose:   Create a CharLinkedList from a deep copy of another CharLinkedList
* arguments: none
* returns:   none
* effects:   currSize, data, and pointers set to match
*/
CharLinkedList::CharLinkedList(const CharLinkedList &other) {
    currSize = 0;

    if (other.currSize == 0) {
        front = back = nullptr;
    } else {
        Node *currNode = other.front;
        // Iterate through other list and push each element at back
        while (currNode->next != nullptr) {
            pushAtBack(currNode->data);
            currNode = currNode->next;
        }
        // push last element at back
        pushAtBack(currNode->data);
    }
}

/*
* name:      CharLinkedList destructor
* purpose:   Clear any memory allocated for the CharLinkedList
* arguments: none
* returns:   none
* effects:   Deletes the Nodes of the list.
*/
CharLinkedList::~CharLinkedList() {
    if (currSize == 0) {
        return;
    } else {
        // destructorRecursive() deletes all elements after the first, so we 
        // delete first node last
        destructorRecursive(front);
        delete front;
    }
}

/*
* name:      Overloaded Assignment Operator
* purpose:   Set the '=' assignment operator to make a deep copy of the 
*            right-hand CharLinkedList and assign it to the left-hand list
* arguments: none
* returns:   The address of the reassigned CharLinkedList
* effects:   Sets deep copy of right-hand side list to left-hand side list
*/
CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other) {
    // Empty this list before copying elements from other list
    clear();
    if (other.currSize != 0) {
        Node *currNode = other.front;
        // Iterate through other list and copy each element
        while (currNode->next != nullptr) {
            pushAtBack(currNode->data);
            currNode = currNode->next;
        }
        // Copy last element
        pushAtBack(currNode->data);
    }

    return *this;
}

///////////////////////// Get Functions /////////////////////////

/*
* name:      isEmpty
* purpose:   determines if the CharLinkedList is empty or not
* arguments: none
* returns:   true if CharLinkedList contains no elements, false otherwise
* effects:   none
*/
bool CharLinkedList::isEmpty() const {
    return currSize == 0;
}

/*
* name:      size
* purpose:   Determine the number of items in the CharLinkedList
* arguments: none
* returns:   number of elements currently stored in the CharLinkedList
* effects:   none
*/
int CharLinkedList::size() const {
    return currSize;
}

/*
* name:      first
* purpose:   Get the first element in the CharLinkedList
* arguments: none
* returns:   the first element in the CharLinkedList
* effects:   none
*/
char CharLinkedList::first() const {
    // Throw a runtime error if first is called on empty list
    if (isEmpty()) {
        throw runtime_error("cannot get first of empty LinkedList");
    }
    return elementAt(0);
}

/*
* name:      last
* purpose:   Get the last element in the CharLinkedList
* arguments: none
* returns:   the last element in the CharLinkedList
* effects:   none
*/
char CharLinkedList::last() const {
    // Throw a runtime error if last is called on empty list
    if (isEmpty()) {
        throw runtime_error("cannot get last of empty LinkedList");
    }
    return elementAt(currSize - 1);
}

/*
* name:      elementAt
* purpose:   Get the element at the specified index in the CharLinkedList
* arguments: an index at which to get an element
* returns:   The element at the specified index in the CharLinkedList
* effects:   none
*/
char CharLinkedList::elementAt(int index) const {
    // Throw error if index is out of list range 
    if (index < 0 or index >= currSize) {
        throw range_error ("index (" + to_string(index) + ") not in range " 
        + "[0.." + to_string(currSize) + ")");
    }
    // Use recursive helper to find element
    return elementAtRecursive(front, 0, index);
}

/*
* name:      toString
* purpose:   turns the Linked into a string, and returns it
* arguments: none
* returns:   a string representation of the character Linked
* effects:   none
*/
std::string CharLinkedList::toString() const {
    Node *currNode = front;
    
    // Start string stream
    stringstream ss;
    ss << "[CharLinkedList of size " << currSize << " <<";
    
    if (currNode != nullptr) {
        // Add each element of the CharLinkedList to the stringstream
        while (currNode->next != nullptr) {
            ss << currNode->data;
            currNode = currNode->next;
        }
        // Add last element to the stringstream
        ss << currNode->data;
    }
    ss << ">>]";
    
    return ss.str();
}

/*
* name:      toReverseString
* purpose:   turns the Linked into a string in reverse, and returns it
* arguments: none
* returns:   a string which contains the characters of the CharLinkedList 
*            in reverse.
* effects:   none
*/
std::string CharLinkedList::toReverseString() const {
    Node *currNode = back;
    
    // Start string stream
    stringstream ss;
    ss << "[CharLinkedList of size " << currSize << " <<";
    
    if (currNode != nullptr) {
        // Add each element of the CharLinkedList to the stringstream,
        // starting from the back.
        while (currNode->previous != nullptr) {
            ss << currNode->data;
            currNode = currNode->previous;
        }
        // Add last element to the stringstream
        ss << currNode->data;
    }
    ss << ">>]";
    
    return ss.str();
}

///////////////////////// Add Functions /////////////////////////

/*
* name:      pushAtBack
* purpose:   push the provided character into the back of the CharLinkedList
* arguments: a character to add to the back of the list
* returns:   none
* effects:   increases size of CharLinkedList by 1,
*            adds element to list
*/
void CharLinkedList::pushAtBack(char c) {
    insertAt(c, currSize);
}

/*
* name:      pushAtFront
* purpose:   Insert the provided character into the front of the CharLinkedList
* arguments: a character to add to the front of the list
* returns:   none
* effects:   increases size of CharLinkedList by 1,
*            adds element to list
*/
void CharLinkedList::pushAtFront(char c) {
    insertAt(c, 0);
}

/*
 * name:      insertAt
 * purpose:   Insert the provided character into the CharLinkedList at the
 *            specified index.
 * arguments: a character to add to the list and an index to insert it at.
 * returns:   none
 * effects:   increases size of CharLinkedList by 1,
 *            adds element to list at specified index
 */
void CharLinkedList::insertAt(char c, int index) {
    // Throw error if index is out of list range 
    if (index < 0 or index > currSize) {
        throw range_error ("index (" + to_string(index) + ") not in range " 
            + "[0.." + to_string(currSize) + "]");
    }

    if (currSize == 0) { // Handle insertion to an empty list
        front = back = newNode(c, nullptr, nullptr);
    } else if (index == 0) { // Handle insertion into front of list
        front->next->previous = front = newNode(c, front, nullptr);
    } else {
        // Find the node directly before insertion index
        Node *currNode = findNode(index - 1);
        
        if (index == currSize) { // Handle insertion at back of list
            currNode->next = back = newNode(c, nullptr, currNode);

        } else { // Handle insertion in the middle of a list
            Node *tempNode = newNode(c, currNode->next, currNode);
            currNode->next = tempNode;
            tempNode->next->previous = tempNode;
        }
    }
    currSize++;
}

/*
 * name:      insertInOrder
 * purpose:   Insert the provided character into the CharLinkedList at the
 *            correct ASCII position, assuming it is sorted.
 * arguments: a character to add to the list.
 * returns:   none
 * effects:   increases size of CharLinkedList by 1,
 *            adds element to list at ASCII position
 */
void CharLinkedList::insertInOrder(char c) {
    // Account for empty list
    if (currSize == 0) {
        insertAt(c, 0);
        return;
    }

    Node *currNode = front;
    int indexCount = 0;

    // Find the spot in the list where the given character fits in 
    // ASCII order
    while (indexCount < currSize) {
        if (c <= currNode->data) {
            insertAt(c, indexCount);
            return;
        }
        currNode = currNode->next;
        indexCount++;
    }
}

/*
 * name:      concatenate
 * purpose:   Add the contents of another CharLinkedList to the end of this one
 * arguments: Pointer to a CharLinkedList to concatenate at the end of 
 *            this list.
 * returns:   none
 * effects:   adds to the end of this list and updates size
 */
void CharLinkedList::concatenate(CharLinkedList *other) {
    if (other->currSize != 0) {
        // Set size first to avoid infinite loop when concatenating self
        int size = other->currSize;
        Node *currNode = other->front;
        
        // Push each element of the other list to the back of this list.
        for (int i = 0; i < size; i++) {
            pushAtBack(currNode->data);
            currNode = currNode->next;
        }
    }
}

/*
 * name:      replaceAt
 * purpose:   Insert the provided character into the CharLinkedList in the place
 *            of the provided index, replacing the existing element.
 * arguments: a character to add to the list and in index to replace
 * returns:   none
 * effects:   swaps an element in the list
 */
void CharLinkedList::replaceAt(char c, int index) {
    // Throw error if index is out of list range 
    if (index < 0 or index >= currSize) {
        throw range_error ("index (" + to_string(index) + ") not in range " 
            + "[0.." + to_string(currSize) + ")");
    }

    // Use recursive helper function to recursivelty find node at index
    Node *currNode = replaceAtRecursive(front, 0, index);
    // Update node data
    currNode->data = c;
}

///////////////////////// Remove Functions /////////////////////////

/*
 * name:      clear
 * purpose:   Makes instance into an empty CharLinkedList
 * arguments: none
 * returns:   none
 * effects:   removes all nodes and sets size to 0.
 */
void CharLinkedList::clear() {
    if (currSize != 0) {
        
        // Essentially destruct linked list
        destructorRecursive(front);
        delete front;
        
        // Reconstruct front, back pointers and size to keep list functional
        front = back = nullptr;
        currSize = 0;
    }
}

/*
 * name:      popFromFront
 * purpose:   Removes first element in CharLinkedList
 * arguments: none
 * returns:   none
 * effects:   Reduces size of list by one.
 */
void CharLinkedList::popFromFront() {
    // Throw runtime error if popFromFront is called on an empty list
    if (isEmpty()) {
        throw runtime_error("cannot pop from empty LinkedList");
    }
    
    removeAt(0);
}

/*
 * name:      popFromBack
 * purpose:   Removes last element in CharLinkedList
 * arguments: none
 * returns:   none
 * effects:   Reduces size of list by one.
 */
void CharLinkedList::popFromBack() {
    // Throw runtime error if popFromBack is called on an empty list
    if (isEmpty()) {
        throw runtime_error("cannot pop from empty LinkedList");
    }
    
    removeAt(currSize - 1);
}

/*
 * name:      removeAt
 * purpose:   Removes an element in CharLinkedList at the specified index.
 * arguments: an index at which to remove an element
 * returns:   none
 * effects:   Reduces size of list by one.
 */
void CharLinkedList::removeAt(int index) {
    // Throw error if index is out of list range 
    if (index < 0 or index >= currSize) {
        throw range_error ("index (" + to_string(index) + ") not in range " 
            + "[0.." + to_string(currSize) + ")");
    }
    
    if (currSize == 1) { //Removal for single element list
        // Just delete single item, then reset front & back pointers
        delete front;
        front = back = nullptr;
    } else if (index == 0) { // Removal at front of list
        // front points to element 2, then delete element 1 with "previous"
        front = front->next;
        delete front->previous;
        front->previous = nullptr;
    } else if (index == currSize - 1) { // Removal at back of list
        // back points to second to last element,
        // then delete last element with "next" 
        back = back->previous;
        delete back->next;
        back->next = nullptr;
    } else { // Removal at middle of list
        Node *currNode = findNode(index - 1);
        // Node before index points to node after index, then we delete
        currNode->next = currNode->next->next;
        delete currNode->next->previous;
        currNode->next->previous = currNode;
    }
    currSize--;
}

///////////////////////// Helper Functions /////////////////////////

/*
 * name:      newNode
 * purpose:   Creates a new node to be inserted into CharLinkedList
 * arguments: a character to put into list, and node pointers for the node's 
 *            "next" and "previous" pointers
 * returns:   a node pointer to the newly created node
 * effects:   none
 */
CharLinkedList::Node *CharLinkedList::newNode(char newData, Node *next, 
Node *previous) {
    // Create and return a new node on the heap with specified information
    Node *newNode = new Node;
    newNode->data = newData;
    newNode->next = next;
    newNode->previous = previous;
    
    return newNode;
}

/*
 * name:      findNode
 * purpose:   Finds a node in the list at given index
 * arguments: the index of the node to retrieve
 * returns:   a node pointer to the node after locating it
 * effects:   none
 */
CharLinkedList::Node *CharLinkedList::findNode(int index) { 
    Node *currNode;

    if (index == 0) { // Handle front
        currNode = front;
    } else if (index == currSize - 1) { // Handle back
        currNode = back;
    } else { // Handle middle
        int indexCount = 0;
        // Determine whether to start at front or back
        if (index < currSize/2) {
            // Iterate through linked list from front
            currNode = front;
            while (indexCount < index) {
                currNode = currNode->next;
                indexCount++;
            }
        } else { 
            // Iterate through linked list from back
            currNode = back;
            while (indexCount < currSize - 1 - index) {
                currNode = currNode->previous;
                indexCount++;
            }
        }
    }

    return currNode;
}

/*
 * name:      elementAtRecursive
 * purpose:   Recursively iterates through list to find a character
 * arguments: A "current node" pointer (should first be called w/ front node),
 *            a count to keep track of current position, and a target index.
 * returns:   the character at the provided index
 * effects:   none
 */
char CharLinkedList::elementAtRecursive
(Node *curr, int count, int index) const {
    // Base case: we have iterated to provided index
    if (count == index) {
        return curr->data;
    }
    
    // call itself with next node and incremented count
    return elementAtRecursive(curr->next, ++count, index);
}

/*
 * name:      destructorRecursive
 * purpose:   Recursively iterates through list, then deletes all nodes
 * arguments: A "current node" pointer (should first be called w/ front node)
 * returns:   none
 * effects:   Deletes all nodes in list after the node first used to call func
 */
void CharLinkedList::destructorRecursive(Node *curr) {
    // Base case: we have reached the end of the list
    if (curr->next == nullptr) {
        return;
    }

    // After recursively iterating to end of list, delete each consecutive node
    // as we return
    destructorRecursive(curr->next);
    delete curr->next;
    return;
}

/*
 * name:      replaceAtRecursive
 * purpose:   Recursively iterates through list to find a Node
 * arguments: A "current node" pointer, a count to keep track of current 
 *            position, and a target index
 * returns:   the node at the provided index
 * effects:   none
 */
CharLinkedList::Node *CharLinkedList::replaceAtRecursive
(Node *curr, int count, int index) {
    
    // Base case: we have reached the provided index
    if (count == index) {
        return curr;
    }
    
    // call itself with the next node and incremented count
    return replaceAtRecursive(curr->next, ++count, index);
}
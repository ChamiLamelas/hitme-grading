/*
 *  CharLinkedList.h
 *  Shepard Rodgers (srodge01)
 *  2/1/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  This is a class declaration for a CharLinkedList, which represents an 
 *  expandable ordered list of characters. Every new CharLinkedList begins
 *  empty and characters can be added, removed, or printed out.
 *
 */

#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H

#include <sstream>

class CharLinkedList {
public:
    // Constuctors
    CharLinkedList();
    CharLinkedList(char c);
    CharLinkedList(char arr[], int size);
    CharLinkedList(const CharLinkedList &other); // Copy Constructor

    // Destructor
    ~CharLinkedList();

    // Overloaded Assignment Operator
    CharLinkedList &operator=(const CharLinkedList &other);

    // Getting LinkedList information
    bool isEmpty() const;
    int size() const;
    char first() const;
    char last() const;
    char elementAt(int index) const;
    std::string toString() const;
    std::string toReverseString() const;
    
    // Add elements
    void pushAtBack(char c);
    void pushAtFront(char c);
    void insertAt(char c, int index);
    void insertInOrder(char c);
    void concatenate(CharLinkedList *other);
    void replaceAt(char c, int index);
    
    // Remove elements
    void clear();
    void popFromFront();
    void popFromBack();
    void removeAt(int index);

private:
    // Node struct to store data and link to other nodes
    struct Node {
        char data;
        Node *next;
        Node *previous;
    };

    // Member variables
    int currSize;
    Node *front;
    Node *back;

    // Helper functions
    Node *newNode(char newData, Node *next, Node *previous);
    Node *findNode(int index);
    void destructorRecursive(Node *curr);
    char elementAtRecursive(Node *curr, int count, int index) const;
    Node *replaceAtRecursive(Node *curr, int count, int index);
};

#endif

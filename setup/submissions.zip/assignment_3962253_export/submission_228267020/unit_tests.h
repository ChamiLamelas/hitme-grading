/*
 *  unit_tests.h
 *  Brianna Taborda
 *  02/03
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  Tests for each of the functions implemented in a CharLinkedList class which
 *  in most cases tests a CharLinkedList on an empty list, a list with one char,
 *  and a list with mutliple chars.
 *
 */
#include "CharLinkedList.h"
#include <cassert>
#include <iostream>
#include <string>
#include <stdexcept>

/*
 * nothing
 * Dummy test to check if the class definition is syntactically correct
 */
void nothing() {
    //nothing
}

/*
 * constructor1 test0
 * Make sure no fatal errors/memory leaks in the default constructor
 */
void constructor1_test0(){
    CharLinkedList test;
    assert(test.isEmpty());
}

/*
 * constructor1 test1
 * Make sure no items exist in the list upon construction
 */
void constructor1_test1() {
    CharLinkedList test;
    assert(test.size() == 0);
}

/*
 * constructor2 test
 * Checks the second constructor correctly initializes a LL of 1 element
 * with a size of one
*/
void constructor2_test() {
    CharLinkedList test('b');
    assert(test.size() == 1);
}

/*
 * constructor3 test
 * Checks the third constructor correctly intializes a LL of multiple elements
*/
void constructor3_test() {
    char arr[3] = { 'b', 'r', 'i'};
    CharLinkedList test(arr, 3);
    assert(test.size() == 3);
}

/*
 * constructor4 test
 * checks that a deep copy is made when something is changed
*/
void constructor4_test() {
    char arr[3] = {'d', 'o', 'g'};
    CharLinkedList test(arr, 3);
    CharLinkedList list(test);
    assert(test.toString() == "[CharLinkedList of size 3 <<dog>>]");
    assert(test.toString() == "[CharLinkedList of size 3 <<dog>>]");
}

/*
 * constructor5 test
 * assignment operator test to check if a deep copy is made when there's change
*/
void constructor5_test() {
    char arr[3] = {'d', 'o', 'g'};
    CharLinkedList test(arr, 3);
    CharLinkedList list;
    list = test;
    assert(test.toString() == "[CharLinkedList of size 3 <<dog>>]");
    assert(list.toString() == "[CharLinkedList of size 3 <<dog>>]");
}

/*
 * size tests
 * Make sure the size if being accurately reported
*/
//check that size is accurately reported for a test of one char
void size_single_test() {
    CharLinkedList test('b');
    assert(test.size() == 1);
}

//check that size is accurately reproted for a test of multiple characters
void size_multiple_test() {
    char arr[4] = {'m', 'a', 't', 'h'};
    CharLinkedList test(arr, 4);
    assert(test.size() == 4);
}

/*
 * isEmpty test
 * Make sure we report an empty list correctly.
 */
void isEmpty_test() {
    CharLinkedList test;
    assert(test.size() == 0);
    assert(test.isEmpty());
}

/*
 * clear tests
 * Make sure that the LL is cleared
*/
void clear_empty_test() {
    CharLinkedList test;
    assert(test.size() == 0);
    assert(test.isEmpty());

}

//checks that a LL with one character is cleared
void clear_single_test() {
    CharLinkedList test('a');
    test.clear();
    assert(test.size() == 0);
    assert(test.isEmpty());
}

//checks to see if a LL of multiple characters is cleared
void clear_multiple_test() {
    char arr[5] = {'S', 'a', 'm', 'm', 'y'};
    CharLinkedList test(arr, 5);
    test.clear();
    assert(test.size() == 0);
    assert(test.isEmpty());
}


/*
 * first tests
 * Makes sure the first char of the LL is properly returned
*/
void first_empty_test() {
    CharLinkedList test;
    bool runtime_error_thrown = false;
    std::string error_message = "";

    try {
        test.first();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    std::cerr << error_message << std::endl;
    assert(error_message == "cannot get first of empty LinkedList");
}

//checks that first character is returned in a list of one char
void first_single_test() {
    CharLinkedList test('f');
    assert(test.first() == 'f');
}

//check that first char is returned in a list of multiple chars
void first_multiple_test() {
    char arr[5] = {'s', 'a', 'm', 'm', 'y'};
    CharLinkedList test(arr, 5);
    assert(test.first() == 's');
}

/*
 * last tests
 * Make sure that last char of an LL is being properly returned
*/
void last_empty_test() {
    bool runtime_error_thrown = false;
    std::string error_message = "";
    CharLinkedList test;

    try {
        test.last();
    }
    catch (const std::runtime_error &e) {
    runtime_error_thrown = true;
    error_message = e.what();
    }

    assert(runtime_error_thrown);
    std::cerr << error_message << std::endl;
    assert(error_message == "cannot get last of empty LinkedList");
}

//checks that last character is returned in a list of one char
void last_single_test() {
    CharLinkedList test('f');
    assert(test.last() == 'f');
}

//check that last char is returned in a list of multiple chars
void last_multiple_test() {
    char arr[5] = {'s', 'a', 'm', 'm', 'y'};
    CharLinkedList test(arr, 5);
    assert(test.last() == 'y');
}

/*
 * toString tests
 * Checks that the given list is as we expect it to be
*/
//checks what is produced by an empty LinkedList
void toString_empty_test() {
    CharLinkedList test;
    assert(test.toString() == "[CharLinkedList of size 0 <<>>]");
}

//checks what is produced by an LinkedList with one character
void toString_single_test() {
    CharLinkedList test('a');
    assert(test.toString() == "[CharLinkedList of size 1 <<a>>]");
}

//checks what is produced by an Linked with multiple characters
void toString_multiple_test() {
    char arr[7] = {'B', 'r', 'i', 'a', 'n', 'n', 'a'};
    CharLinkedList test(arr, 7);
    assert(test.toString() == "[CharLinkedList of size 7 <<Brianna>>]");
}

/*
 * toReverseString tests
 * Checks that the given list is as we expect it to be - reversed
*/
//checks what is produced by an empty Linked
void toReverseString_empty_test() {
    CharLinkedList test;
    assert(test.toReverseString() == "[CharLinkedList of size 0 <<>>]");
}

//checks what is produced by an Linked with one character
void toReverseString_single_test() {
    CharLinkedList test('a');
    assert(test.toReverseString() == "[CharLinkedList of size 1 <<a>>]");
}

//checks what is produced by an Linked with multiple characters
void toReverseString_multiple_test() {
    char arr[7] = {'B', 'r', 'i', 'a', 'n', 'n', 'a'};
    CharLinkedList test(arr, 7);
    assert(test.toReverseString() == "[CharLinkedList of size 7 <<annairB>>]");
}

/*
 * pushAtBack tests
 * Makes sure the char is being properly added to back of the CharLinkedList
*/
//checks that an empty list is being correctly added to
void pushAtBack_empty_test() {
    CharLinkedList test;
    test.pushAtBack('a');
    assert(test.size() == 1);
    assert(test.toString() == "[CharLinkedList of size 1 <<a>>]");
}

//checks that a list of one char is being correctly added to
void pushAtBack_single_test() {
    CharLinkedList test('b');
    test.pushAtBack('t');
    assert(test.size() == 2);
    assert(test.toString() == "[CharLinkedList of size 2 <<bt>>]");
}

//checks that a list of multiple of chars is being correctly added to
void pushAtBack_multiple_test() {
    char arr[5] = {'b', 'r', 'i', 'a', 'n',};
    CharLinkedList test(arr, 5);
    test.pushAtBack('n');
    test.pushAtBack('a');
    assert(test.size() == 7);
    assert(test.toString() == "[CharLinkedList of size 7 <<brianna>>]");
}

/*
 * popFromFront tests
 * make sure that a char is properly being removed from the front of an LL
*/
//check that runtime error is thrown when LL is empty
void popFromFront_empty_test() {
    CharLinkedList test;
    bool runtime_error_thrown = false;
    std::string error_message = "";

    try {
        test.popFromFront();
    }
    catch (const std::runtime_error &e) {
    runtime_error_thrown = true;
    error_message = e.what();
    }
    
    assert(runtime_error_thrown);
    std::cerr << error_message << std::endl;
    assert(error_message == "cannot pop from empty LinkedList");
}

//check that a char can be removed from an LL of one character
void popFromFront_single_test() {
    CharLinkedList test('b');
    test.popFromFront();
    assert(test.isEmpty());
    assert(test.toString() == "[CharLinkedList of size 0 <<>>]");
}

//check that a char can be removed from an LL of multiple characters
void popFromFront_multiple_test() {
    char arr[7] = {'b', 'r', 'i', 'a', 'n', 'n', 'a'};
    CharLinkedList test(arr, 7);
    test.popFromFront();
    assert(test.toString() == "[CharLinkedList of size 6 <<rianna>>]");
}

/*
 * popFromBack tests
 * test that the last element of an LL is being properly removed
*/
//check that an empty LL throws a runtime error
void popFromBack_empty_test() {
    CharLinkedList test;
    bool runtime_error_thrown = false;
    std::string error_message = "";

    try {
        test.popFromBack();
    }
    catch (const std::runtime_error &e) {
    runtime_error_thrown = true;
    error_message = e.what();
    }
    
    assert(runtime_error_thrown);
    std::cerr << error_message << std::endl;
    assert(error_message == "cannot pop from empty LinkedList");
}

//check that an Linked list of a single char is correctly popped back
void popFromBack_single_test() {
    CharLinkedList test('b');
    test.popFromBack();
    assert(test.isEmpty());
    assert(test.toString() == "[CharLinkedList of size 0 <<>>]");
}

//check that an Linked list of multiple characters is correctly popped back
void popFromBack_multiple_test() {
    char arr[7] = {'b', 'r', 'i', 'a', 'n', 'n', 'a'};
    CharLinkedList test(arr, 7);
    test.popFromBack();
    assert(test.toString() == "[CharLinkedList of size 6 <<briann>>]");
}

/*
 * insertAt tests
 * Checks that function correctly inserts characters in different situations
*/
void insertAt_empty_correct() { 
    CharLinkedList test_list;
    test_list.insertAt('a', 0);
    assert(test_list.size() == 1);
    //assert(test_list.elementAt(0) == 'a');
}

// Tests incorrect insertion into an empty LL.
// Attempts to call insertAt for index larger than 0.
// This should result in an std::range_error being raised.
void insertAt_empty_incorrect() {
    bool range_error_thrown = false;
    std::string error_message = "";

    CharLinkedList test_list;
    try {
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    std::cerr << error_message << std::endl;
    assert(error_message == "index (42) not in range [0..0]");
}

// Tests correct insertAt for front of 1-element list.
void insertAt_front_singleton_list() {
    CharLinkedList test_list('a');
    test_list.insertAt('b', 0);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'a');
    
}

// Tests correct insertAt for back of 1-element list.
void insertAt_back_singleton_list() {
    CharLinkedList test_list('a');
    test_list.insertAt('b', 1);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    
}

// Tests calling insertAt for a large number of elements.
// Not only does this test insertAt, it also checks that
// Linked expansion works correctly.
void insertAt_many_elements() {
    
    CharLinkedList test_list;
    for (int i = 0; i < 1000; i++) {
        test_list.insertAt('a', i);
    }

    assert(test_list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
    
}

// Tests insertion into front of a larger list
void insertAt_front_large_list() {
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    test_list.insertAt('y', 0);

    assert(test_list.size() == 10);
    assert(test_list.elementAt(0) == 'y');
    assert(test_list.toString() == 
    "[CharLinkedList of size 10 <<yabczdefgh>>]");
}

// Tests insertion into the back of a larger list
void insertAt_back_large_list() {

    char test_arr[10] = { 'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 10);  

    test_list.insertAt('x', 10);

    assert(test_list.size() == 11);
    assert(test_list.elementAt(10) == 'x');
    assert(test_list.toString() == 
    "[CharLinkedList of size 11 <<yabczdefghx>>]"); 

}

// Tests insertion into the middle of a larger list
void insertAt_middle_large_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.insertAt('z', 3);

    assert(test_list.size() == 9);
    assert(test_list.elementAt(3) == 'z');
    assert(test_list.toString() == "[CharLinkedList of size 9 <<abczdefgh>>]");
}

// Tests out-of-range insertion for a non-empty list.
void insertAt_nonempty_incorrect() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);
    bool range_error_thrown = false;
    std::string error_message = "";

    try {
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    std::cerr << error_message << std::endl;
    assert(error_message == "index (42) not in range [0..8]");
}

/*
 * elementAt tests
 * Make sure that correct char is being returned at a certain index
 * Ensure that a range error is thrown correctly if index is out of range
*/
//check how element works on an empty list
void elementAt_empty_test() {
    CharLinkedList test;
    bool range_error_thrown = false;
    std::string error_message = "";

    try {
        test.elementAt(0);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    std::cerr << error_message << std::endl;
    assert(error_message == "index (0) not in range [0..0)");
}
//check that element greater than 0 is out of range
void elementAt_outOfRange_test() {
    char arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test(arr, 8);
    bool range_error_thrown = false;
    std::string error_message = "";

    try {
        test.elementAt(42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    std::cerr << error_message << std::endl;
    assert(error_message == "index (42) not in range [0..8)");
}

//check that elementAt works when index is less than 0
void elementAt_outOfRange1_test() {
    char arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test(arr, 8);
    bool range_error_thrown = false;
    std::string error_message = "";

    try {
        test.elementAt(-23);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    std::cerr << error_message << std::endl;
    assert(error_message == "index (-23) not in range [0..8)");
}

//check that elementAt works when an index works
void elementAt_test() {
    char arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test(arr, 8);
    assert(test.elementAt(3) == 'd');
}

/*
 * insertInOrder tests
 * ensures insertInOrder correctly inserts the char according to ASCII order
*/
//make sure a char is correctly inserted in an empty list
void insertInOrder_empty_test() {
    CharLinkedList test;
    test.insertInOrder('j');
    assert(test.toString() == "[CharLinkedList of size 1 <<j>>]");
}

//make sure a further character is placed after an earlier one
void insertInOrder_singleFront_test() {
    CharLinkedList test('b');
    test.insertInOrder('t');
    assert(test.toString() == "[CharLinkedList of size 2 <<bt>>]");
}

//make sure an earlier character is placed before a later one
void insertInOrder_singleBack_test() {
    CharLinkedList test('t');
    test.insertInOrder('b');
    assert(test.toString() == "[CharLinkedList of size 2 <<bt>>]");
}

//make sure a char is correctly placed in an LL of multiple elements
void insertInOrder_multiple_test() {
    char arr[5] = {'f', 'u', 's', 's', 'y'};
    CharLinkedList test(arr, 5);
    test.insertInOrder('x');
    assert(test.toString() == "[CharLinkedList of size 6 <<fussxy>>]");
}

/*
 * removeAt tests
 * make sure that characters are being properly removed
*/
//check that a range error is thrown when range greater than LL size
void removeAt_outOfRange_test() {
    char arr[5] = {'S', 'a', 'm', 'm', 'y'};

    CharLinkedList test(arr, 5);
    bool range_error_thrown = false;
    std::string error_message = "";

    try {
        test.removeAt(6);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    std::cerr << error_message << std::endl;
    assert(error_message == "index (6) not in range [0..5)");
}

//check that a range error is thrown when range is less than LL size
void removeAt_outOfRange1_test() {
    char arr[5] = {'S', 'a', 'm', 'm', 'y'};

    CharLinkedList test(arr, 5);
    bool range_error_thrown = false;
    std::string error_message = "";

    try {
        test.removeAt(-234);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    std::cerr << error_message << std::endl;
    assert(error_message == "index (-234) not in range [0..5)");
}

//check that a range error is thrown for an empty list list
void removeAt_empty_test() {
    CharLinkedList test;
    bool range_error_thrown = false;
    std::string error_message = "";

    try {
        test.removeAt(0);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    
    assert(range_error_thrown);
    std::cerr << error_message << std::endl;
    assert(error_message == "index (0) not in range [0..0)");
}

//check that a character can be removed from an LL of one character
void removeAt_single_test() {
    CharLinkedList test('b');
    test.removeAt(0);
    assert(test.isEmpty());
    assert(test.toString() == "[CharLinkedList of size 0 <<>>]");
}

//check that a character can be removed from an LL of mulitple characters
void removeAt_multiple_test() {
    char arr[7] = {'b', 'r', 'i', 'a', 'n', 'n', 'a'};
    CharLinkedList test(arr, 7);
    test.removeAt(2);
    assert(test.toString() == "[CharLinkedList of size 6 <<branna>>]");
}

/*
 * replaceAt tests
 * Makes sure that characters are being properly replaced
*/
//checks that range error is thrown with an empty list
void replaceAt_empty_test() {
    CharLinkedList test;
    bool runtime_error_thrown = false;
    std::string error_message = "";

    try {
        test.replaceAt('b', 0);
    }
    catch (const std::runtime_error &e) {
    runtime_error_thrown = true;
    error_message = e.what();
    }
    
    assert(runtime_error_thrown);
    std::cerr << error_message << std::endl;
    assert(error_message == "index (0) not in range [0..0)");
}

//checks that range error is thrown when greater than size of list
void replaceAt_outOfRange_test() {
    char arr[5] = {'S', 'a', 'm', 'm', 'y'};

    CharLinkedList test(arr, 5);
    bool range_error_thrown = false;
    std::string error_message = "";

    try {
        test.replaceAt('b', 6);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    std::cerr << error_message << std::endl;
    assert(error_message == "index (6) not in range [0..5)");
}

//check that range error is thrown when less than 0
void replaceAt_outOfRange1_test() {
    char arr[5] = {'S', 'a', 'm', 'm', 'y'};

    CharLinkedList test(arr, 5);
    bool range_error_thrown = false;
    std::string error_message = "";

    try {
        test.replaceAt('b', -34);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    std::cerr << error_message << std::endl;
    assert(error_message == "index (-34) not in range [0..5)"); 
}

//check that letter is properly replaced in an LL of one character
void replaceAt_single_test() {
    CharLinkedList test('b');
    test.replaceAt('t', 0);
    assert(test.toString() == "[CharLinkedList of size 1 <<t>>]");
}

//check that letter is properly replaced in LL of multiple characters
void replaceAt_multiple_test() {
    char arr[5] = {'S', 'a', 'm', 'm', 'y'};
    CharLinkedList test(arr, 5);
    test.replaceAt('s', 2);
    test.replaceAt('s', 3);
    assert(test.toString() == "[CharLinkedList of size 5 <<Sassy>>]");
}

/*
 * concatenate tests
 * check that array lists are being properly concatenated
*/
//check how empty array concatenates with second array
void concatenate_empty1_test() {
    CharLinkedList test;
    char arr[3] = {'d', 'o', 'g'};
    CharLinkedList list(arr, 3);
    test.concatenate(&list);
    assert(test.toString() == "[CharLinkedList of size 3 <<dog>>]");
}

//check how an array with multiple characters concatenates with an empty array
void concatenate_empty2_test() {
    char arr[3] = {'d', 'o', 'g'};
    CharLinkedList test(arr, 3);
    CharLinkedList list;
    test.concatenate(&list);
    assert(test.toString() == "[CharLinkedList of size 3 <<dog>>]");
}

//check how an LL of a single char concatenates with an LL of multiple chars
void concatenate_single1_test() {
    char arr[3] = {'d', 'o', 'g'};
    CharLinkedList test(arr, 3);
    CharLinkedList list('B');
    test.concatenate(&list);
    assert(test.toString() == "[CharLinkedList of size 4 <<dogB>>]");
}

//check how an LL of multiple chars concatenated with an LL of a single char
void concatenate_single2_test() {
    char arr[3] = {'d', 'o', 'g'};
    CharLinkedList test(arr, 3);
    CharLinkedList list('B');
    list.concatenate(&test);
    assert(list.toString() == "[CharLinkedList of size 4 <<Bdog>>]");
}

//check how an LL of multiple chars interacts with another LL of multiple chars
void concatenate_multiple_test() {
    char arr[3] = {'d', 'o', 'g'};
    char arr1[4] = {'g', 'i', 'e', 's'};
    CharLinkedList test(arr, 3);
    CharLinkedList list(arr1, 4);
    test.concatenate(&list);
    assert(test.toString() == "[CharLinkedList of size 7 <<doggies>>]");
}

//check how an LL of multiple characters concatenates with itself
void concatenate_same_test() {
    char arr[3] = {'d', 'o', 'g'};
    CharLinkedList test(arr, 3);
    test.concatenate(&test);
    assert(test.toString() == "[CharLinkedList of size 6 <<dogdog>>]");
}
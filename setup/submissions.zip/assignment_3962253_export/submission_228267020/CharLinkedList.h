/*
 *  CharLinkedList.h
 *  Brianna Taborda (btabor01)
 *  02/03
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Interface for a CharLinkedList class that allows a client to create and
 *  manipulate a linked list of characters. Each linked list has private 
 *  recursive helper functions that are called in order to make the
 *  corresponding functions more concise and comprehensive in the .cpp file. 
 *
 */

#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H

#include <iostream>
#include <string>

class CharLinkedList {
    public:
    CharLinkedList();
    CharLinkedList(char c); 
    CharLinkedList(char arr[], int size); 
    CharLinkedList(const CharLinkedList &other);
    CharLinkedList &operator=(const CharLinkedList &other);
    ~CharLinkedList();

    bool isEmpty() const; 
    void clear(); 
    int size() const; 
    char first() const; 
    char last() const; 
    char elementAt(int index) const;
    std::string toString() const;
    std::string toReverseString() const; 
    void pushAtBack(char c);
    void pushAtFront(char c);
    void insertAt(char c, int index); 
    void insertInOrder(char c); 
    void popFromFront();
    void popFromBack(); 
    void removeAt(int index);
    void replaceAt(char c, int index);
    void concatenate(CharLinkedList *other); 

private:
    struct Node {
        char data;
        Node *next;
        Node *prev;
    };
    
    Node *front;
    Node *back;
    Node *new_node;

    void recursiveHelper(Node *curr_node);
    Node *newNode(char c, Node *next, Node *prev);
    Node *recursiveElementAt(int index, int counter, Node *curr) const;
    void recursReplaceAt(char c, int index, int count, Node *curr);

    int currSize;
}; 

#endif


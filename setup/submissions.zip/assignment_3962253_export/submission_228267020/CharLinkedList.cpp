/*
 *  CharLinkedList.cpp
 *  Brianna Taborda (btabor01)
 *  02/03
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  This holds the implementation of the CharLinkedList class which uses a 
 *  doubly linked list to perform different operations on a list of characters.
 *  The functions can manipulate the list in many different ways such as
 *  clearing it, printing out the list of characters, and replacing and removing
 *  specificed characters.
 *
 */

#include "CharLinkedList.h"
#include <sstream>

/*
 * name:      CharLinkedList default constructor
 * purpose:   initialize e an empty LL 
 * arguments: none
 * returns:   none
 * effects:   creation of an empty LL
 */
CharLinkedList::CharLinkedList() {
    front = nullptr;
    back = front;
    currSize = 0;
}

/*
 * name:      CharLinkedList second constructor
 * purpose:   create a LL with one char and an initiLL capacity of 1
 * arguments: one character
 * returns:   none
 * effects:   creation of a LL with one char and a capacity of 1
 */
CharLinkedList::CharLinkedList(char c) {
    Node *new_node = newNode(c, nullptr, nullptr);
    front = new_node;
    back = new_node;
    currSize = 1;
}

/*
 * name:      CharLinkedList third constructor
 * purpose:   create a LL with an Linked of chars and an given capacity
 * arguments: a character Linked, an integer representing the size of the Linked
 * returns:   none
 * effects:   creation of a LL with the chars and the size given
 */
CharLinkedList::CharLinkedList(char arr[], int size) {
    currSize = 0;
    front = nullptr;

    for (int i = 0; i < size; i++) {
        pushAtBack(arr[i]);
    }
}

/*
 * name:      CharLinkedList copy constructor
 * purpose:   copy constructor makes a deep copy of a given instance
 * arguments: a linked list and a pointer to another
 * returns:   none
 * effects:   makes a deep copy of a given instance
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other) {
    currSize = 0;
    front = nullptr;
    Node *curr = other.front;
    for (int i = 0; i < other.size(); i++) {
        pushAtBack(curr->data);
        curr = curr->next;
    }
}

/*
 * name:      CharLinkedList assignment operator
 * purpose:   recycles storage associated with the instance on the left of the
              assignment & makes a deep copy of the instance on the RH into LH
 * arguments: pointer to a char linked list
 * returns:   none
 * effects:   recycles storage of LH & makes a deep copy of RH instance into LH
 */
CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other) {
    if (this == &other) {
        return *this;
    }
    clear();
    Node *curr = other.front;
    for (int i = 0; i < other.size(); i++) {
        pushAtBack(curr->data);
        curr = curr->next;
    }

    return *this;
}

/*
 * name:      newNode
 * purpose:   create a new node
 * arguments: a character, pointers to the next and previous node
 * returns:   none
 * effects:   create a new node so it can be added to the linked lsit
 */
CharLinkedList::Node *CharLinkedList::newNode(char c, Node *next, Node *prev) {
    Node *new_node = new Node;
    new_node->data = c;
    new_node->next = next;
    new_node->prev = prev;

    return new_node;
}

/*
 * name:      isEmpty
 * purpose:   determines if the CharLinkedList is empty or not
 * arguments: none
 * returns:   true if CharLinkedList contains no elements, false otherwise
 * effects:   none
 */
bool CharLinkedList::isEmpty() const {
    if (front == nullptr) {
        return true;
    } else {
        return false;
    }
}

/*
 * name:      clear
 * purpose:   make instance into an empty LL
 * arguments: none
 * returns:   none
 * effects:   clears the instance
 */
void CharLinkedList::clear() {
    recursiveHelper(front);
    front = nullptr;
    currSize = 0;
}

/*
 * name:      size
 * purpose:   determine the number of items in the LL
 * arguments: none
 * returns:   number of elements currently stored in the LL
 * effects:   none
 */
int CharLinkedList::size() const {
    return currSize;
}

/*
 * name:      first
 * purpose:   return the first character in a linked list
 * arguments: none
 * returns:   the first character in the LL
 * effects:   returns the first character in a LL
 */
char CharLinkedList::first() const {
    if (isEmpty()) {
            throw std::runtime_error("cannot get first of empty LinkedList");
    } else {
        return front->data;
    }
}

/*
 * name:      last
 * purpose:   return the last character in a linked list
 * arguments: none
 * returns:   the last character in the LL
 * effects:   returns the last character in a LL
 */
char CharLinkedList::last() const {
    if (isEmpty()) {
        throw std::runtime_error("cannot get last of empty LinkedList");
    }
    return back->data;
}

/*
 * name:      elementAt 
 * purpose:   returns the character in the specificed index
 * arguments: an integer representing the index
 * returns:   character at specified index
 * effects:   throws a range error exception if the index isn't in Linked
 */
char CharLinkedList::elementAt(int index) const {
    if (index < 0 or index > currSize - 1) {
        std::stringstream ss;
        ss << "index (" << index << ") not in range [0.." << currSize << ")";
        throw std::range_error(ss.str());
    } else {
        Node *curr;
        int counter = 0;
        curr = recursiveElementAt(index, counter, front);
        return curr->data;
    }
}

/*
 * name:      recursiveElementAt
 * purpose:   find the element at a given idex
 * arguments: int representing an index, an int to count through the index, and
              a pointer to the current node
 * returns:   node at the index
 * effects:   locates an element
 */
CharLinkedList::Node *CharLinkedList::recursiveElementAt(int index, int counter,
                                                            Node *curr) const {
    if (counter == index) {
        return curr;
    } else {
        counter++;
        return recursiveElementAt(index, counter, curr->next);
    }
}

/*
 * name:      toString
 * purpose:   turns the LL into a string, and returns it
 * arguments: none
 * returns:   a string representation of the LL
 * effects:   none
 */
std::string CharLinkedList::toString() const {
    Node *curr = front;
    std::stringstream ss;
    if (isEmpty()) {
        ss << "[CharLinkedList of size 0 <<>>]";
        } else {
        ss << "[CharLinkedList of size " << currSize << " <<";
        while (curr != nullptr) {
            ss << curr->data;
            curr = curr->next;
        }
        ss << ">>]";
    }
    return ss.str();
}

/*
 * name:      toReverseString()
 * purpose:   turns the LL into a string that is reversed in order
 * arguments: none
 * returns:   reverse string representation of the linked list
 * effects:   none
 */
std::string CharLinkedList::toReverseString() const {
    Node *curr = back;
    std::stringstream ss;
    if (isEmpty()) {
        ss << "[CharLinkedList of size 0 <<>>]";
    } else {
        ss << "[CharLinkedList of size " << currSize << " <<";
        while (curr != nullptr) {
            ss << curr->data;
            curr = curr->prev;
        }
        ss << ">>]";
    }
    return ss.str();
}

/*
 * name:      pushAtBack
 * purpose:   takes a char and inserts it at the end of the list
 * arguments: one character
 * returns:   none
 * effects:   inserts a given char at the end of the linked list
 */
void CharLinkedList::pushAtBack(char c) {
    if (front == nullptr) {
        front = newNode(c, nullptr, nullptr);
        back = front;
    } else {
        back = newNode(c, nullptr, back);
        back->prev->next = back;
    }
    currSize++;
}

/*
 * name:      pushAtFront
 * purpose:   push the provided char into the front of the CharLinkedList
 * arguments: a char to add to the front of the list
 * returns:   none
 * effects:   increases currSize of CharLinkedList by 1,
 *            adds element to list
 */
void CharLinkedList::pushAtFront(char c) {
    if (front == nullptr) {
        front = newNode(c, nullptr, nullptr);
        back = front;
    } else {
        front = newNode(c, front, nullptr);
        front->next->prev = front;
    }
    currSize++;
}

/*
 * name:      insertAt
 * purpose:   inserts new element at given index 
 * arguments: a char and an integer representing the index the char will go
 * returns:   none
 * effects:   inserts a character in the LL at the specified index
 */
void CharLinkedList::insertAt(char c, int index) {
    if (index > currSize or index < 0) {
        std::stringstream ss;
        ss << "index (" << index << ") not in range [0.." << currSize << "]";
        throw std::range_error(ss.str());
    } else if (index == 0) {
        pushAtFront(c);
    } else if (index == currSize) {
        pushAtBack(c);
    } else {
        Node *curr = front;
        int counter = 0;
        while (counter != index) {
            curr = curr->next;
            counter++;
        }
        new_node = newNode(c, curr, curr->prev);
        curr->prev->next = new_node;
        curr->prev = new_node;
        currSize++;
    }
}

/*
 * name:      insertInOrder
 * purpose:   inserts new element into LL in ASCII order 
 * arguments: a character to be inserted
 * returns:   none
 * effects:   inserts a character in the LL in ASCII order
 */
void CharLinkedList::insertInOrder(char c) {
    Node *curr = front;
    int currIndex = 0;
    bool order = false;
    while (curr != nullptr and (not order)) {
        if (c > curr->data) {
            curr = curr->next;
            currIndex++;
        } else {
            order = true;
        }
    }
    insertAt(c, currIndex);
}

/*
 * name:      popFromFront
 * purpose:   remove first element from LL 
 * arguments: none
 * returns:   none
 * effects:   removes the first character from the LL
 */
void CharLinkedList::popFromFront() {
    if (isEmpty()) {
        throw std::runtime_error("cannot pop from empty LinkedList");
    } else if (size() == 1) {
        delete front; 
        front = nullptr;
        back = nullptr;
        currSize = 0;
    } else {
        front = front->next;
        delete front->prev;
        front->prev = nullptr;
        currSize--;
    }
}

/*
 * name:      popFromFront
 * purpose:   remove first element from LL 
 * arguments: none
 * returns:   none
 * effects:   removes the first character from the LL
 */
void CharLinkedList::popFromBack() {
    if (isEmpty()) {
        throw std::runtime_error("cannot pop from empty LinkedList");
    } else if (size() == 1) {
        delete back; 
        front = nullptr;
        back = nullptr;
        currSize = 0;
    } else {
        back = back->prev;
        delete back->next;
        back->next = nullptr;
        currSize--;
    }
}

/*
 * name:      removeAt
 * purpose:   remove element at index 
 * arguments: an integer representing the index
 * returns:   none
 * effects:   removes the character from the LL at the specified index
 */
void CharLinkedList::removeAt(int index) {
    if (index < 0 or index >= currSize) {
        std::stringstream ss;
        ss << "index (" << index << ") not in range [0.." << currSize << ")";
        throw std::range_error(ss.str());
    } else if (index == 0) {
        popFromFront();
        return;
    } else if (index == currSize - 1) {
        popFromBack();
        return;
    } else {
        int counter = 0;
        Node *curr = front;
        while (counter != index) {
            curr = curr->next;
            counter++;
        }
        curr->prev->next = curr->next;
        curr->next->prev = curr->prev;
        delete curr;
        currSize--;
    }
}

/*
 * name:      replaceAt
 * purpose:   replace a character with another one 
 * arguments: a character to replace with, the index specifying where
 * returns:   none
 * effects:   replaces a character at specified index with a given one
 */
void CharLinkedList::replaceAt(char c, int index) {
    int counter = 0;
    if (index < 0 or index >= currSize) {
        std::stringstream ss;
        ss << "index (" << index << ") not in range [0.." << currSize << ")";
        throw std::range_error(ss.str());
    }
    recursReplaceAt(c, index, counter, front);
}

/*
 * name:      recursiveReplaceAt
 * purpose:   replace a character at a given index
 * arguments: a character to replace with, an integer counter, an integer
              representing the index specifying where, and a pointer to the 
              current node
 * returns:   none
 * effects:   replaces a char in the linked list at the index specified
 */
void CharLinkedList::recursReplaceAt(char c, int index, int count, Node *curr) {
    if (count == index) {
        curr->data = c;
    } else {
        count++;
        recursReplaceAt(c, index, count, curr->next);
    }
}

/*
 * name:      concatenate
 * purpose:   adds a copy of one linked list to another
 * arguments: a character linked list and a pointer to a different character LL
 * returns:   none
 * effects:   adds a copy of the linked list pointed to by the parameter value 
              to the end of the linked list the function was called from
 */
void CharLinkedList::concatenate(CharLinkedList *other) {
    Node *curr = other->front;
    int counter = other->size();
    if (other->isEmpty()) {
        return;
    } else {
        while (counter != 0) {
            pushAtBack(curr->data);
            curr = curr->next;
            counter--;
        }
    }
}

/*
 * name:      recursiveHelper
 * purpose:   delete memory LLlocated on the heap from the linked list
 * arguments: a pointer to the current node
 * returns:   none
 * effects:   none
 */
void CharLinkedList::recursiveHelper(Node *curr_node) {
    if (curr_node == nullptr) {
        return;
    } else {
        recursiveHelper(curr_node->next);
        delete curr_node;
    }
}

/*
 * name:      ~CharLinkedList
 * purpose:   delete memory LLlocated on the heap in the linked lsit
 * arguments: none
 * returns:   none
 * effects:   none
 */
CharLinkedList::~CharLinkedList() {
    recursiveHelper(front);
}

/*
 *  CharLinkedList.h
 *  Andrea Cabochan
 *  02/01/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Define the CharLinkedList class is designed to represent a linked list of 
 *  characters in C++. It provides a dynamic and efficient way to manage a 
 *  sequence of characters
 */

#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H

#include <string>

class CharLinkedList {

public:
    CharLinkedList();
    CharLinkedList(char c);
    CharLinkedList(char arr[], int size);
    CharLinkedList(const CharLinkedList &other);
    ~CharLinkedList();

    bool isEmpty() const;
    void clear();
    int size() const;
    char first() const;
    char last() const;
    char elementAt(int index) const;
    std::string toString() const;
    std::string toReverseString() const;
    void pushAtFront(char c);
    void pushAtBack(char c);
    void insertAt(char c, int index);
    void insertInOrder(char c);
    void popFromFront();
    void popFromBack();
    void removeAt(int index);
    void replaceAt(char c, int index);
    void concatenate(CharLinkedList *other);

    CharLinkedList& operator=(const CharLinkedList &other);

private:
    struct Node {
        std::string data;
        Node *next;
        Node *prev;
    };

    Node *front;
    int listSize;   

    Node *newNode(std::string newData, Node *next);
    void recycleRecursive(Node *curr);
    char elementAtRecursive(Node* current, int index) const;
    std::string toReverseStringRecursive(Node* current) const;
    void replaceAtRecursive(Node* current, char newChar, int index);
};

#endif

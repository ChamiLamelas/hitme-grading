/*
 *  CharLinkedList.cpp
 *  Andrea Cabochan
 *  02/01/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  The purpose of this file is to implement a linked list data structure 
 *  specifically designed for storing and manipulating sequences of characters 
 *  (strings). The program aims to offer a versatile and 
 *  efficient tool for managing sequences of characters in a dynamic and 
 *  flexible manner.
 *
 */

#include "CharLinkedList.h"
#include <iostream> 
#include <string>

/*
 * name:      CharLinkedList
 * purpose:   Constructor for CharLinkedList class, initializes member 
              variables.
 * arguments: None
 * returns:   N/A
 * effects:   Initializes front and listSize
 */
CharLinkedList::CharLinkedList() {
    front = nullptr;
    listSize = 0;
}

/*
 * name:      CharLinkedList
 * purpose:   Constructor for CharLinkedList class, initializes with a single 
              character.
 * arguments: c - the character to initialize the array with
 * returns:   N/A
 * effects:   Initializes a new node and listSize with a single variable.
 */
CharLinkedList::CharLinkedList(char c) {
    front = newNode(std::string(1, c), nullptr);
    listSize = 1;
}

/*
 * name:      CharLinkedList
 * purpose:   Constructor for CharLinkedList class, initializes with a character
              array.
 * arguments: arr - pointer to the character array, size - size of the 
              character array
 * returns:   N/A
 * effects:   Initializes a new node, listSize, and a linked list with nodes
 */
CharLinkedList::CharLinkedList(char arr[], int size) {
    front = nullptr;
    Node *current = nullptr;

    for (int i = 0; i < size; i++) {
        Node *newNode = new Node{std::string(1, arr[i]), nullptr};

        if (not front) {
            front = newNode;
            current = front;
        } else {
            current->next = newNode;
            current = newNode;
        }
    }

    this->listSize = size;
}

/*
 * name:      CharLinkedList
 * purpose:   Copy constructor for CharLinkedList class, initializes with the 
 *            contents of another CharLinkedList.
 * arguments: other - reference to the CharLinkedList to be copied
 * returns:   N/A
 * effects:   Initializes a new node, listSize, and a linked list with nodes
              based on the contents of the provided CharLinkedList.
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other) {
    front = nullptr;
    Node *otherCurrent = other.front;
    Node *current = nullptr;

    while (otherCurrent) {
        Node *newNode = new Node{otherCurrent->data, nullptr};

        if (not front) {
            front = newNode;
            current = front;
        } else {
            current->next = newNode;
            current = newNode;
        }

        otherCurrent = otherCurrent->next;
    }

    listSize = other.listSize;
}

/*
 * name:      ~CharLinkedList
 * purpose:   Destructor for CharLinkedList class, recursively destroys the 
 *            linked list.
 * arguments: N/A
 * returns:   N/A
 * effects:   Frees the memory allocated for each node in the linked list.
 */
CharLinkedList::~CharLinkedList() {
    recycleRecursive(front);
}

/*
 * name:      operator=
 * purpose:   Assignment operator for CharLinkedList class, assigns the contents
              of another CharLinkedList.
 * arguments: other - reference to the CharLinkedList to be assigned
 * returns:   Reference to the modified CharLinkedList
 * effects:   Clears the current linked list and initializes a new one based on
              the contents of the provided CharLinkedList.
 */
CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other) {
    if (this != &other) {
        recycleRecursive(front);

        listSize = other.listSize;
        front = nullptr;

        Node *otherCurrent = other.front;
        Node *current = nullptr;

        while (otherCurrent) {
            Node *newNode = new Node{otherCurrent->data, nullptr};

            if (not front) {
                front = newNode;
                current = front;
            } else {
                current->next = newNode;
                current = newNode;
            }

            otherCurrent = otherCurrent->next;
        }
    }

    return *this;
}

/*
 * name:      newNode
 * purpose:   Creates a new node with the given data and next pointer.
 * arguments: newData - string data for the new node, next - pointer to the
 *            next node
 * returns:   Pointer to the newly created node
 * effects:   Allocates memory for a new node with the provided data and next 
 *            pointer.
 */
CharLinkedList::Node *CharLinkedList::newNode(std::string newData, Node *next) {
    return new Node{newData, next};
}

/*
 * name:      recycleRecursive
 * purpose:   Recursively destroys the linked list.
 * arguments: curr - pointer to the current node being processed
 * returns:   N/A
 * effects:   Frees the memory allocated for each node in the linked list.
 */
void CharLinkedList::recycleRecursive(Node *curr) {
    if (curr) {
        recycleRecursive(curr->next);
        delete curr;
    }
}

/*
 * name:      isEmpty
 * purpose:   Checks if the linked list is empty.
 * arguments: N/A
 * returns:   true if the linked list is empty, false otherwise
 * effects:   N/A
 */
bool CharLinkedList::isEmpty() const {
    return listSize == 0;
}

/*
 * name:      clear
 * purpose:   Clears the linked list, freeing memory for all nodes.
 * arguments: N/A
 * returns:   N/A
 * effects:   Frees the memory allocated for each node in the linked list
 *            and sets listSize to 0.
 */
void CharLinkedList::clear() {
    while(front != nullptr) {
        Node* temp = front->next;
        delete front;
        front = temp;
    }
    listSize = 0;
}

/*
 * name:      size
 * purpose:   Returns the size of the linked list.
 * arguments: N/A
 * returns:   Integer representing the number of nodes in the linked list
 * effects:   N/A
 */
int CharLinkedList::size() const {
    return listSize;
}

/*
 * name:      first
 * purpose:   Returns the first character in the linked list.
 * arguments: N/A
 * returns:   The first character in the linked list
 * effects:   Throws a runtime_error if the linked list is empty.
 */
char CharLinkedList::first() const {
    if (isEmpty()) {
        throw std::runtime_error("cannot get first of empty LinkedList");
    }
    return front->data[0];
}

/*
 * name:      last
 * purpose:   Returns the last character in the linked list.
 * arguments: N/A
 * returns:   The last character in the linked list
 * effects:   Throws a runtime_error if the linked list is empty.
 */
char CharLinkedList::last() const {
    if (isEmpty()) {
        throw std::runtime_error("cannot get last of empty LinkedList");
    }

    Node* current = front;
    while (current->next) {
        current = current->next;
    }

    return current->data.back(); 
}

/*
 * name:      elementAt
 * purpose:   Retrieves the character at the specified index in the linked list.
 * arguments: index - the index of the character to retrieve
 * returns:   The character at the specified index
 * effects:   Throws a range_error if the index is out of bounds [0, listSize).
 */
char CharLinkedList::elementAt(int index) const {
    if (index < 0 or index >= listSize) {
        throw std::range_error("index (" + std::to_string(index) +
                               ") not in range [0.." + std::to_string(listSize)
                                + ")");
    }
    return elementAtRecursive(front, index);
}

/*
 * name:      elementAtRecursive
 * purpose:   Retrieves the character at the specified index recursively.
 * arguments: current - pointer to the current node, index - the index of the
 *            character to retrieve
 * returns:   The character at the specified index
 * effects:   N/A
 */
char CharLinkedList::elementAtRecursive(Node* current, int index) const {
    if (index == 0) {
        return current->data[0];
    }

    return elementAtRecursive(current->next, index - 1);
}

/*
 * name:      toString
 * purpose:   Returns a string representation of the linked list.
 * arguments: N/A
 * returns:   String representation of the linked list
 * effects:   N/A
 */
std::string CharLinkedList::toString() const {
    std::string result = "[CharLinkedList of size " + std::to_string(listSize)
                         + " <<";

    Node* current = front;
    while (current) {
        result += current->data;
        current = current->next;
    }

    result += ">>]";
    return result;
}

/*
 * name:      toReverseString
 * purpose:   Returns a reversed string representation of the linked list.
 * arguments: N/A
 * returns:   Reversed string representation of the linked list
 * effects:   N/A
 */
std::string CharLinkedList::toReverseString() const {
    return "[CharLinkedList of size " + std::to_string(listSize) + " <<" + 
            toReverseStringRecursive(front) + ">>]";
}

/*
 * name:      toReverseStringRecursive
 * purpose:   Recursively constructs a reversed string representation of the 
 *            linked list.
 * arguments: current - pointer to the current node
 * returns:   Reversed string representation of the linked list
 * effects:   N/A
 */
std::string CharLinkedList::toReverseStringRecursive(Node* current) const {
    if (not current) {
        return "";
    }

    std::string result = toReverseStringRecursive(current->next);
    result += current->data;

    return result;
}

/*
 * name:      pushAtBack
 * purpose:   Adds a new character to the back of the linked list.
 * arguments: c - the character to be added
 * returns:   N/A
 * effects:   Modifies the linked list by adding a new node to the end.
 */
void CharLinkedList::pushAtBack(char c) {
    Node* newElement = newNode(std::string(1, c), nullptr);
    if (not front) {
        front = newElement;
    } else {
        Node* current = front;
        while (current->next) {
            current = current->next;
        }
        current->next = newElement;
        newElement->prev = current;
    }
    listSize++;
}

/*
 * name:      pushAtFront
 * purpose:   Adds a new character to the front of the linked list.
 * arguments: c - the character to be added
 * returns:   N/A
 * effects:   Modifies the linked list by adding a new node to the front.
 */
void CharLinkedList::pushAtFront(char c) {
    Node* newElement = newNode(std::string(1, c), front);
    if (front) {
        front->prev = newElement;
    }
    front = newElement;
    listSize++;
}

/*
 * name:      insertAt
 * purpose:   Inserts a new character at the specified index in the linked list.
 * arguments: c - the character to be inserted, index - the index at which to 
 *            insert
 * returns:   N/A
 * effects:   Modifies the linked list by inserting a new node at the specified 
 *            index.
 *            Throws a range_error if the index is out of bounds [0, listSize].
 */
void CharLinkedList::insertAt(char c, int index) {
    if (index < 0 or index > listSize) {
        throw std::range_error("index (" + std::to_string(index) + 
                               ") not in range [0.." + std::to_string(listSize)
                                + "]");
    }

    if (index == 0) { pushAtFront(c); return; }
    if (index == listSize) { pushAtBack(c); return; }

    Node* newElement = newNode(std::string(1, c), nullptr);
    Node* current = front;

    for (int i = 0; i < index - 1; ++i) { current = current->next; }

    newElement->next = current->next;
    newElement->prev = current;
    current->next->prev = newElement;
    current->next = newElement;

    listSize++;
}

/*
 * name:      insertInOrder
 * purpose:   Inserts a new character in ascending order in the linked list.
 * arguments: c - the character to be inserted
 * returns:   N/A
 * effects:   Modifies the linked list by inserting a new node in ascending 
 *            order.
 */
void CharLinkedList::insertInOrder(char c) {
    Node* newElement = newNode(std::string(1, c), nullptr);

    if (front == nullptr or front->data >= newElement->data) {
        newElement->next = front;
        if (front != nullptr) {
            front->prev = newElement;
        }
        front = newElement;
    } else {
        Node* current = front;

        while (current->next != nullptr and current->next->data < 
               newElement->data) {
            current = current->next;
        }

        newElement->next = current->next;
        newElement->prev = current;
        if (current->next != nullptr) {
            current->next->prev = newElement;
        }
        current->next = newElement;
    }
    listSize++;
}

/*
 * name:      popFromFront
 * purpose:   Removes the first character from the linked list.
 * arguments: N/A
 * returns:   N/A
 * effects:   Modifies the linked list by removing the first node.
 *            Throws a runtime_error if the linked list is empty.
 */
void CharLinkedList::popFromFront() {
    if (isEmpty()) {
        throw std::runtime_error("cannot pop from empty LinkedList");
    }

    Node* temp = front;
    front = front->next;

    if (front != nullptr) {
        front->prev = nullptr;
    }

    delete temp;
    listSize--;
}

/*
 * name:      popFromBack
 * purpose:   Removes the last character from the linked list.
 * arguments: N/A
 * returns:   N/A
 * effects:   Modifies the linked list by removing the last node.
 *            Throws a runtime_error if the linked list is empty.
 */
void CharLinkedList::popFromBack() {
    if (isEmpty()) {
        throw std::runtime_error("cannot pop from empty LinkedList");
    }

    Node* current = front;
    Node* prev = nullptr;

    while (current->next != nullptr) {
        prev = current;
        current = current->next;
    }

    if (prev != nullptr) {
        prev->next = nullptr;
    } else {
        front = nullptr;
    }

    delete current;
    listSize--;
}

/*
 * name:      removeAt
 * purpose:   Removes the character at the specified index from the linked list.
 * arguments: index - the index of the character to be removed
 * returns:   N/A
 * effects:   Modifies the linked list by removing the node at the specified 
 *            index.
 *            Throws a range_error if the index is out of bounds [0, listSize).
 */
void CharLinkedList::removeAt(int index) {
    if (index < 0 or index >= listSize) {
        throw std::range_error("index (" + std::to_string(index) + 
                               ") not in range [0.." + std::to_string(listSize)
                               + ")");
    }

    if (index == 0) {
        Node* temp = front;
        front = front->next;

        if (front != nullptr) {
            front->prev = nullptr;
        }

        delete temp;
    } else {
        Node* current = front;
        Node* prev = nullptr;

        for (int i = 0; i < index; ++i) {
            prev = current;
            current = current->next;
        }

        prev->next = current->next;

        if (current->next != nullptr) {
            current->next->prev = prev;
        }

        delete current;
    }

    listSize--;
}

/*
 * name:      replaceAt
 * purpose:   Replaces the character at the specified index with a new 
 *            character.
 * arguments: c - the character to replace with, index - the index to replace
 * returns:   N/A
 * effects:   Modifies the linked list by replacing the character at the 
 *            specified index.
 *            Throws a range_error if the index is out of bounds [0, listSize).
 */
void CharLinkedList::replaceAt(char c, int index) {
    if (index < 0 or index >= listSize) {
        throw std::range_error("index (" + std::to_string(index) + 
                               ") not in range [0.." + std::to_string(listSize)
                               + ")");
    }

    replaceAtRecursive(front, c, index);
}

/*
 * name:      replaceAtRecursive
 * purpose:   Recursively replaces the character at the specified index with a
 *            new character.
 * arguments: current - pointer to the current node, c - the character to 
 *            replace with,
 *            index - the index to replace
 * returns:   N/A
 * effects:   Modifies the linked list by replacing the character at the 
 *            specified index.
 */
void CharLinkedList::replaceAtRecursive(Node* current, char c, int index) {
    if (index == 0) {
        current->data = std::string(1, c);
    } else {
        replaceAtRecursive(current->next, c, index - 1);
    }
}

/*
 * name:      concatenate
 * purpose:   Concatenates the contents of another CharLinkedList to the end of
 *            this linked list.
 * arguments: other - pointer to the CharLinkedList to be concatenated
 * returns:   N/A
 * effects:   Modifies the linked list by adding the contents of the other 
 *            linked list to the end.
 *            Does nothing if the provided linked list is empty or nullptr.
 */
void CharLinkedList::concatenate(CharLinkedList* other) {
    if (other == nullptr or other->front == nullptr) {
        return; 
    }

    if (front == nullptr) {
        front = newNode(other->front->data, nullptr);
        Node* current = front;
        Node* otherCurrent = other->front->next;

        while (otherCurrent != nullptr) {
            current->next = newNode(otherCurrent->data, nullptr);
            current->next->prev = current;
            current = current->next;
            otherCurrent = otherCurrent->next;
        }
    } else {
        Node* current = front;
        while (current->next != nullptr) {
            current = current->next;
        }

        Node* otherCurrent = other->front;
        while (otherCurrent != nullptr) {
            current->next = newNode(otherCurrent->data, nullptr);
            current->next->prev = current;
            current = current->next;
            otherCurrent = otherCurrent->next;
        }
    }

    listSize += other->listSize;
}

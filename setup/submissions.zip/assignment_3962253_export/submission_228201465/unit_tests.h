/*
 *  unit_tests.h
 *  Andrea Cabochan
 *  02/01/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  To test the CharLinkedList class
 *
 */

#include "CharLinkedList.h"
#include <cassert>

void testConstructor() {
    CharLinkedList list1;
    assert(list1.size() == 0);

}

void testConstructor_2() {
    CharLinkedList list2("Hello", 5);
    assert(list2.size() == 5);
}

void testCopyOperator() {
    CharLinkedList original('A');
    original.pushAtBack('B');
    original.pushAtBack('C');

    CharLinkedList assigned;
    assigned = original;

    assert(original.size() == assigned.size());

    assert(original.toString() == assigned.toString());
}

void testIsEmpty() {
    CharLinkedList emptyList;
    assert(emptyList.isEmpty());
}

void testIsNonEmpty() {
    CharLinkedList nonEmptyList('a');
    assert(not nonEmptyList.isEmpty());
}

void testClearEmptyList() {
    CharLinkedList emptyList;
    emptyList.clear();
    assert(emptyList.isEmpty());
    assert(emptyList.size() == 0);
}

void testClearNonEmptyList() {
    CharLinkedList nonEmptyList("Hello", 5);
    nonEmptyList.clear();
    assert(nonEmptyList.isEmpty());
    assert(nonEmptyList.size() == 0);
}

void testFirst_nonEmptyList() {
    char arr[] = {'a', 'b', 'c'};
    CharLinkedList charList(arr, 3);

    assert(charList.first() == 'a');
}

void testFirst_nonEmptyListDebug() {
    char arr[] = {'a', 'b', 'c'};
    CharLinkedList charList(arr, 3);

    std::cout << "List size: " << charList.size() << std::endl;

    char firstChar = charList.first();
    std::cout << "First character: " << firstChar << std::endl;
    assert(firstChar == 'a');
}

void testFirst_EmptyList () {
    CharLinkedList emptyList;
    try {
        char result = emptyList.first();  
        assert(false);
    } catch (const std::runtime_error& e) {
        assert(std::string(e.what()) == "cannot get first of empty LinkedList");
    }
}

void testLast_emptyList() {
    CharLinkedList emptyList;
    try {
        emptyList.last();
        assert(false && "Expected exception for empty list");
    } catch (const std::runtime_error& e) {
        assert(true);
    }
}

void testLast_nonEmptyList() {
    char arr[] = {'a', 'b', 'c'};
    CharLinkedList charList(arr, 3);

    char lastChar = charList.last();
    assert(lastChar == 'c');
}

void testElementAt_validIndex() {
    char arr[] = {'a', 'b', 'c'};
    CharLinkedList charList(arr, 3);

    char element = charList.elementAt(1);
    assert(element == 'b');
}

void testElementAt_invalidIndex() {
    char arr[] = {'a', 'b', 'c'};
    CharLinkedList charList(arr, 3);

    try {
        charList.elementAt(6);  // Index out of range (list size is 3)
        assert(false && "Expected exception for invalid index");
    } catch (const std::range_error& e) {
        assert(true);
    }
}

void testToString_emptyList() {
    CharLinkedList emptyList;
    assert(emptyList.toString() == "[CharLinkedList of size 0 <<>>]");
}

void testToString_nonEmptyList() {
    char arr[] = {'a', 'b', 'c'};
    CharLinkedList charList(arr, 3);

    assert(charList.toString() == "[CharLinkedList of size 3 <<abc>>]");
}

void testToString_singleElementList() {
    CharLinkedList charList('x');

    assert(charList.toString() == "[CharLinkedList of size 1 <<x>>]");
}

void testToReverseString_Empty() {
    CharLinkedList emptyList;
    assert(emptyList.toReverseString() == "[CharLinkedList of size 0 <<>>]");
}

void testToReverseString_SpecialCharacters() {
    CharLinkedList special("!@#$", 4);
    assert(special.toReverseString() == "[CharLinkedList of size 4 <<$#@!>>]");
}

void testToReverseString_Numbers() {
    CharLinkedList numbers("1234", 4);
    assert(numbers.toReverseString() == "[CharLinkedList of size 4 <<4321>>]");
}

void testToReverseString_Mixed() {
    CharLinkedList mixed("A1b2C", 5);
    assert(mixed.toReverseString() == "[CharLinkedList of size 5 <<C2b1A>>]");
}

void testPushAtBack_Empty() {
    CharLinkedList charList;
    assert(charList.toString() == "[CharLinkedList of size 0 <<>>]");
}
void testPushAtBack(){
    CharLinkedList charList;
    charList.pushAtBack('A');
    assert(charList.toString() == "[CharLinkedList of size 1 <<A>>]");

    charList.pushAtBack('B');
    assert(charList.toString() == "[CharLinkedList of size 2 <<AB>>]");

    charList.pushAtBack('C');
    assert(charList.toString() == "[CharLinkedList of size 3 <<ABC>>]");
}

void testPushAtFront() {
    CharLinkedList charList;
    assert(charList.toString() == "[CharLinkedList of size 0 <<>>]");

    charList.pushAtFront('A');
    assert(charList.toString() == "[CharLinkedList of size 1 <<A>>]");

    charList.pushAtFront('B');
    assert(charList.toString() == "[CharLinkedList of size 2 <<BA>>]");

    charList.pushAtFront('C');
    assert(charList.toString() == "[CharLinkedList of size 3 <<CBA>>]");
}

void testInsertAt_InsertAtEnd() {
    CharLinkedList charList;
    charList.pushAtBack('A');
    charList.pushAtBack('B');
    charList.pushAtBack('C');

    charList.insertAt('D', 3);
    assert(charList.toString() == "[CharLinkedList of size 4 <<ABCD>>]");
}
void testInsertAt_OutOfRangeIndex() {
    CharLinkedList charList;

    try {
        charList.insertAt('A', 1);
        assert(false);
    } catch (const std::range_error& e) {
        assert(std::string(e.what()) == "index (1) not in range [0..0]");
    }
}

void insertInOrder_emptyList_test() {
    CharLinkedList list;
    list.insertInOrder('B');
    assert(list.toString() == "[CharLinkedList of size 1 <<B>>]");
}

void insertInOrder_singleElementFront_test() {
    CharLinkedList list("A", 1);
    list.insertInOrder('B');
    assert(list.toString() == "[CharLinkedList of size 2 <<AB>>]");
}

void insertInOrder_singleElementBack_test() {
    CharLinkedList list("B", 1);
    list.insertInOrder('A');
    assert(list.toString() == "[CharLinkedList of size 2 <<AB>>]");
}

void insertInOrder_ascendingOrder_test() {
    CharLinkedList list("ABC", 3);
    list.insertInOrder('B');
    assert(list.toString() == "[CharLinkedList of size 4 <<ABBC>>]");
}

void insertInOrder_descendingOrder_test() {
    CharLinkedList list("CBA", 3);
    list.insertInOrder('B');
    assert(list.toString() == "[CharLinkedList of size 4 <<BCBA>>]");
}

void insertInOrder_repeatedElements_test() {
    CharLinkedList list("ABB", 3);
    list.insertInOrder('A');
    assert(list.toString() == "[CharLinkedList of size 4 <<AABB>>]");
}

void insertInOrder_largeASCIIValues_test() {
    CharLinkedList list("XYZ", 3);
    list.insertInOrder('W');
    assert(list.toString() == "[CharLinkedList of size 4 <<WXYZ>>]");
}

void testPopFromFrontEmptyList() {
    CharLinkedList list;
    try {
        list.popFromFront();
        assert(false);
    } catch (const std::runtime_error& e) {
        assert(true);
    }
}

void testPopFromBackEmptyList() {
    CharLinkedList list;
    try {
        list.popFromBack();
        assert(false);
    } catch (const std::runtime_error& e) {
        assert(true);
    }
}

void testPopFromFrontSingleElement() {
    CharLinkedList list('A');
    list.popFromFront();
    assert(list.isEmpty());
    assert(list.size() == 0);
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}

void testPopFromBackSingleElement() {
    CharLinkedList list('A');
    list.popFromBack();
    assert(list.isEmpty());
    assert(list.size() == 0);
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}

void testPopFromFrontMultipleElements() {
    CharLinkedList list;
    list.pushAtBack('A');
    list.pushAtBack('B');
    list.pushAtBack('C');
    list.popFromFront();
    assert(list.size() == 2);
    assert(list.first() == 'B');
    assert(list.last() == 'C');
    assert(list.toString() == "[CharLinkedList of size 2 <<BC>>]");
}

void testPopFromBackMultipleElements() {
    CharLinkedList list;
    list.pushAtBack('A');
    list.pushAtBack('B');
    list.pushAtBack('C');
    list.popFromBack();
    assert(list.size() == 2);
    assert(list.first() == 'A');
    assert(list.last() == 'B');
    assert(list.toString() == "[CharLinkedList of size 2 <<AB>>]");
}

void testRemoveAtEmptyList() {
    CharLinkedList list;
    try {
        list.removeAt(0);
        assert(false);
    } catch (const std::range_error& e) {
        assert(true);
        assert(std::string(e.what()) == "index (0) not in range [0..0)");
    }
}

void testRemoveAtOutOfRange() {
    CharLinkedList list;
    list.pushAtBack('A');
    list.pushAtBack('B');
    try {
        list.removeAt(2);
        assert(false);
    } catch (const std::range_error& e) {
        assert(true);
        assert(std::string(e.what()) == "index (2) not in range [0..2)");
    }
}

void testRemoveAtFront() {
    CharLinkedList list;
    list.pushAtBack('A');
    list.pushAtBack('B');
    list.pushAtBack('C');
    list.removeAt(0);
    assert(list.size() == 2);
    assert(list.first() == 'B');
    assert(list.last() == 'C');
    assert(list.toString() == "[CharLinkedList of size 2 <<BC>>]");
}

void testRemoveAtMiddle() {
    CharLinkedList list;
    list.pushAtBack('A');
    list.pushAtBack('B');
    list.pushAtBack('C');
    list.removeAt(1);
    assert(list.size() == 2);
    assert(list.first() == 'A');
    assert(list.last() == 'C');
    assert(list.toString() == "[CharLinkedList of size 2 <<AC>>]");
}

void testRemoveAtBack() {
    CharLinkedList list;
    list.pushAtBack('A');
    list.pushAtBack('B');
    list.pushAtBack('C');
    list.removeAt(2);
    assert(list.size() == 2);
    assert(list.first() == 'A');
    assert(list.last() == 'B');
    assert(list.toString() == "[CharLinkedList of size 2 <<AB>>]");
}

void removeAt_nonEmptyValidIndex_test() {
    CharLinkedList list("ABC", 3);
    list.removeAt(1);
    assert(list.toString() == "[CharLinkedList of size 2 <<AC>>]");
}

void removeAt_nonEmptyOutOfRangeIndex_test() {
    CharLinkedList list("ABC", 3);
    try {
        list.removeAt(3);
    } catch (const std::range_error& e) {
        assert(std::string(e.what()) == "index (3) not in range [0..3)");
    }
}

void removeAt_emptyList_test() {
    CharLinkedList list;
    try {
        list.removeAt(0);
    } catch (const std::range_error& e) {
        assert(std::string(e.what()) == "index (0) not in range [0..0)");
    }
}

void replaceAt_validIndex_test() {
    CharLinkedList list("ABC", 3);
    list.replaceAt('X', 1);
    assert(list.toString() == "[CharLinkedList of size 3 <<AXC>>]");
}

void replaceAt_indexZero_test() {
    CharLinkedList list("ABC", 3);
    list.replaceAt('X', 0);
    assert(list.toString() == "[CharLinkedList of size 3 <<XBC>>]");
}

void replaceAt_lastIndex_test() {
    CharLinkedList list("ABC", 3);
    list.replaceAt('X', 2);
    assert(list.toString() == "[CharLinkedList of size 3 <<ABX>>]");
}

void replaceAt_outOfRangeIndex_test() {
    CharLinkedList list("ABC", 3);
    try {
        list.replaceAt('X', 5);
    } catch (const std::range_error& e) {
        assert(std::string(e.what()) == "index (5) not in range [0..3)");
    }
}

void testConcatenate() {
    CharLinkedList ListOne("cat", 3);

    CharLinkedList ListTwo("CHESHIRE", 8);

    ListOne.concatenate(&ListTwo);

    assert(ListOne.last() == 'E');
    assert(ListOne.size() == 11);
}

void testConcatenateWithEmptyList() {
    CharLinkedList ListOne("cat", 3);
    CharLinkedList ListTwo("", 0);
    ListOne.concatenate(&ListTwo);
    assert(ListOne.last() == 't');
    assert(ListOne.size() == 3);
    assert(ListTwo.size() == 0); 
}






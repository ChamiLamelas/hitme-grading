/*
 *  CharLinkedList.h
 *  Sara AbuHamra
 *  2/3/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  This file contains the declaration of the class CharLinkedList and its
 *  methods and variables
 *
 */

#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H

#include <sstream>
#include <iostream>
#include <cstring>

class CharLinkedList {
    public:

    CharLinkedList();
    CharLinkedList(char c);
    CharLinkedList(char arr[], int size);
    CharLinkedList(const CharLinkedList &other);
    ~CharLinkedList();
    int size() const;
    char first() const;
    char last() const;
    void clear();
    std::string toString() const;
    void pushAtBack(char c);
    std::string toReverseString() const;
    bool isEmpty() const;
    void pushAtFront(char c);
    char elementAt(int index) const;
    void insertAt(char c, int index);
    void insertInOrder(char c);
    void removeAt(int index);
    void replaceAt(char c, int index);
    void popFromBack();
    void popFromFront();
    CharLinkedList &operator=(const CharLinkedList &other);
    void concatenate(CharLinkedList *other);

    private:
    struct Node {
        char data;
        Node *next;
        Node *previous;
    };

    Node *front;
    int numItems;
    Node *back;

    void eraseList(Node* curr);
    char elementAtHelper(Node* curr, int index) const;
    Node *getNode(int index) const;
};

#endif

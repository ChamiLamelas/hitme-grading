/*
 *  CharLinkedList.cpp
 *  Sara AbuHamra
 *  2/3/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  This file contains the implementations of class CharLinkedList functions
 *
 */

#include "CharLinkedList.h"
#include <sstream>
#include <iostream>
#include <cstring>
#include <string>
#include <ostream>

/*
 * name:      CharLinkedList (default constructor)
 * purpose:   constructs an empty CharLinkedList with zero elements
 * arguments: none
 * returns:   none
 * effects:   constructs a new CharLinkedList with no elements
 */
CharLinkedList::CharLinkedList() {
    front = nullptr;
    back = nullptr;
    numItems = 0;
}

/*
 * name:      CharLinkedList (single-character constructor)
 * purpose:   constructs a CharLinkedList with a single character
 * arguments: c - the character to be added to the list
 * returns:   none
 * effects:   constructs a new CharLinkedList with one element containing the 
 character c
 */
CharLinkedList::CharLinkedList(char c) {
    Node *newNode = new Node;
    newNode->data = c;
    newNode->next = nullptr;
    newNode->previous = nullptr;
    front = newNode;
    back = newNode;
    numItems = 1;
}

/*
 * name:      CharLinkedList (array constructor)
 * purpose:   constructs a CharLinkedList from an array of characters
 * arguments: arr - the array of characters
 *            size - the size of the array
 * returns:   none
 * effects:   constructs a new CharLinkedList with elements from the array
 */
CharLinkedList::CharLinkedList(char arr[], int size) {
    numItems = 0;
    front = nullptr;
    back = nullptr;

    for (int i = 0; i < size; i++) {
        pushAtBack(arr[i]);
    }
    
    back->next = nullptr;
    front->previous = nullptr;
}

/*
 * name:      CharLinkedList (copy constructor)
 * purpose:   constructs a deep copy of another CharLinkedList
 * arguments: other - the CharLinkedList to be copied
 * returns:   none
 * effects:   constructs a new CharLinkedList with elements copied from the 
 other list
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other) {
    front = nullptr;
    numItems = 0;
    back = nullptr;

    Node* otherCurr = other.front;

    while (otherCurr != nullptr) {
       pushAtBack(otherCurr->data);
       otherCurr = otherCurr->next;
    }
}

/*
 * name:      pushAtBack
 * purpose:   adds a character to the end of the list
 * arguments: c - the character to be added
 * returns:   none
 * effects:   increases the size of the list by one and adds the character to
 the end
 */
void CharLinkedList::pushAtBack(char c) {
    Node* newNode = new Node;
    newNode->data = c;
    newNode->next = nullptr;
    newNode->previous = nullptr;

    if (front == nullptr) {
        front = newNode;
        back = front;
    } else {
        back->next = newNode;
        newNode->previous = back;
        back = newNode;
        back->next = nullptr;
    }

    numItems++;
}

/*
 * name:      pushAtFront
 * purpose:   adds a character to the beginning of the list
 * arguments: c - the character to be added
 * returns:   none
 * effects:   increases the size of the list by one and adds the character to
 the front
 */
 
void CharLinkedList::pushAtFront(char c) {
    Node* newNode = new Node;
    newNode->data = c;
    newNode->next = nullptr;
    newNode->previous = nullptr;

    if(front == nullptr) {
        front = newNode;
        back = front;
    } else {
        newNode->next = front;
        front->previous = newNode;
        front = newNode;
    }

    numItems++;
}

/*
 * name:      toString
 * purpose:   generates a string representation of the list
 * arguments: none
 * returns:   a string representing the contents of the list
 * effects:   none
 */
std::string CharLinkedList::toString() const {
    std::stringstream ss;
    ss << "[CharLinkedList of size " << numItems << " <<";

    Node* curr = front;
    while (curr != nullptr) {
        ss << curr->data;
        curr = curr->next;
    }

    ss << ">>]";
   
    return ss.str();
}

/*
 * name:      ~CharLinkedList (destructor)
 * purpose:   deallocates memory occupied by the list
 * arguments: none
 * returns:   none
 * effects:   deallocates memory occupied by the list and its elements
 */
CharLinkedList::~CharLinkedList() {
    if (front != nullptr) {
        eraseList(front);
    }
}


void CharLinkedList::eraseList(Node* curr) {
    if (curr == nullptr) {
        //delete current;
        return;
    } else {
        Node* next = curr->next;
        delete curr;
        numItems--;
        eraseList(next);
    }
}

/*
 * name:      clear
 * purpose:   removes all elements from the list
 * arguments: none
 * returns:   none
 * effects:   removes all elements from the list and deallocates memory
 */
void CharLinkedList::clear() {
    Node* current = front;
    Node* nextNode;

    while (current != nullptr) {
        nextNode = current->next;
        delete current;
        current = nextNode;
    }

    front = nullptr;
    back = nullptr;
    numItems = 0;
}

/*
 * name:      size
 * purpose:   returns the number of elements in the list
 * arguments: none
 * returns:   the number of elements in the list
 * effects:   none
 */
int CharLinkedList::size() const {
    return numItems;
}

/*
 * name:      first
 * purpose:   returns the first element in the list
 * arguments: none
 * returns:   the first character in the list
 * effects:   none
 */
char CharLinkedList::first() const {
    if (front == nullptr) {
        throw std::runtime_error("cannot get first of empty LinkedList");
    } else {
        return (front->data);
    }
 }

/*
 * name:      last
 * purpose:   returns the last element in the list
 * arguments: none
 * returns:   the last character in the list
 * effects:   none
 */
char CharLinkedList::last() const {
    if (front == nullptr) {
        throw std::runtime_error("cannot get last of empty LinkedList");
    } else {
        return (back->data);
    }
}

/*
 * name:      toReverseString
 * purpose:   generates a string representation of the list in reverse order
 * arguments: none
 * returns:   a string representing the contents of the list in reverse order
 * effects:   none
 */
 std::string CharLinkedList::toReverseString() const {
    std::stringstream ss;
    ss << "[CharLinkedList of size " << numItems << " <<";

    Node* curr = back;
    while (curr != nullptr) {
        ss << curr->data;
        curr = curr->previous;
    }

    ss << ">>]";
   
    return ss.str();
}

/*
 * name:      isEmpty
 * purpose:   checks if the list is empty
 * arguments: none
 * returns:   true if the list is empty, false otherwise
 * effects:   none
 */
bool CharLinkedList::isEmpty() const {
    return numItems == 0;
}

/*
 * name:      elementAt
 * purpose:   returns the character at the specified index
 * arguments: index - the index of the character to retrieve
 * returns:   the character at the specified index
 * effects:   none
 * requires:  index is a valid index within the bounds of the list
 */
char CharLinkedList::elementAt(int index) const {
    if (index < 0 or index >= numItems) {
        throw std::range_error("index (" + std::to_string(index) +
                     ") not in range [0.." + std::to_string(numItems) + ")");
    }

    return elementAtHelper(front, index);
}


char CharLinkedList::elementAtHelper(Node* curr, int index) const {
    if (index == 0) {
        // Base case: reached the desired index
        return curr->data;
    }
    // Recursive case: move to the next node
    return elementAtHelper(curr->next, index - 1);
}

/*
 * name:      insertAt
 * purpose:   inserts a character at the specified index
 * arguments: c - the character to insert
 *            index - the index at which to insert the character
 * returns:   none
 * effects:   increases the size of the list by one and inserts the character
 at the specified index
 * requires:  index is a valid index within the bounds of the list
 */
void CharLinkedList::insertAt(char c, int index) {
    if (index < 0 or index > numItems) {
        throw std::range_error("index (" + std::to_string(index) + 
                    ") not in range [0.." + std::to_string(numItems) + "]");
    }

    if(index == numItems) {
        pushAtBack(c);
        return;
    } else if (index == 0) {
        pushAtFront(c);
        return;
    }

    Node* previousNode = nullptr;
    if (index > 0) {
        previousNode = getNode(index - 1);
    }

    Node *newNode = new Node;
    newNode->data = c;

    if (previousNode != nullptr) {
        newNode->next = previousNode->next;
        previousNode->next = newNode;
    }

    numItems++;
}

/*
 * name:      getNode
 * purpose:   retrieves the node at the specified index
 * arguments: index - the index of the node to retrieve
 * returns:   a pointer to the node at the specified index
 * effects:   none
 * requires:  index is a valid index within the bounds of the list
 */
 CharLinkedList::Node* CharLinkedList::getNode(int index) const {
    if (index < 0 or index >= numItems) {
        throw std::range_error("index (" + std::to_string(index) + 
                    ") not in range [0.." + std::to_string(numItems) + ")");
    }

    Node* curr = front;
    for (int i = 0; i < index; ++i) {
        curr = curr->next;
    }

    return curr;
}

/*
 * name:      insertInOrder
 * purpose:   inserts a character into the list in ascending order
 * arguments: c - the character to insert
 * returns:   none
 * effects:   inserts the character into the list in ascending order
 */
void CharLinkedList::insertInOrder(char c) {
    if (isEmpty() or c >= back->data) {
        pushAtBack(c);
        return;
    }

    if (c <= front->data) {
        // If c is less than or equal to the first element, insert at beginning
        pushAtFront(c);
        return;
    }

     // Traverse the list to find the correct position to insert c
     Node* curr = front;
     Node*  prev = nullptr;
     int index = 0;
    while (curr != nullptr and c > curr->data) {
        prev = curr;
        curr = curr->next;
        index++;
    }

    // Insert c after the current node
    insertAt(c, index);
}

/*
 * name:      removeAt
 * purpose:   removes the character at the specified index
 * arguments: index - the index of the character to remove
 * returns:   none
 * effects:   decreases the size of the list by one and removes the the
 * character at a specific index
 */
void CharLinkedList::removeAt(int index) {
    if (index < 0 or index >= numItems) {
        throw std::range_error("index (" + std::to_string(index) + 
                    ") not in range [0.." + std::to_string(numItems) + ")");
    }

    //if list is empty
    if(isEmpty()) {
        return;
    }

    //removing first element
    if (index == 0) {
        Node* temp = front;
        front = front->next;
        delete temp;
        numItems--;
        return;
    }    

    // Find the node before the one to be removed
    Node* prev = getNode(index - 1);

    // Get the node to be removed
    Node* curr = prev->next;
    prev->next = curr->next;
    delete curr;

    numItems--;
}

/*

name: replaceAt
purpose: replaces the character at the specified index with a new character
arguments: c - the new character to replace with
returns: none
effects: replaces the character at the specified index with the new character

*/
void CharLinkedList::replaceAt(char c, int index) {
    if (index < 0 or index >= numItems) {
        throw std::range_error("index (" + std::to_string(index) + 
                    ") not in range [0.." + std::to_string(numItems) + ")");
    }

    // Find the node at the specified index and update it
    Node* nodeToReplace = getNode(index);
    nodeToReplace->data = c;

}

/*

name: popFromBack
purpose: removes the last character from the list
arguments: none
returns: none
effects: decreases the size of the list by one and removes the last character
*/
void CharLinkedList::popFromBack() {
    if (isEmpty()) {
        throw std::runtime_error("cannot pop from empty LinkedList");
    }

    removeAt(numItems - 1);
}

/*

name: popFromFront
purpose: removes the first character from the list
arguments: none
returns: none
effects: decreases the size of the list by one and removes the first character
*/
void CharLinkedList::popFromFront() {
    if (isEmpty()) {
        throw std::runtime_error("cannot pop from empty LinkedList");
    }

    removeAt(0);
}

/*

name: operator=
purpose: assigns the contents of another CharLinkedList to this CharLinkedList
arguments: other - the CharLinkedList to copy from
returns: a reference to this CharLinkedList
effects: replaces the contents of this CharLinkedList with the contents of the 
other CharLinkedList
*/
CharLinkedList& CharLinkedList:: operator=(const CharLinkedList &other) {
    if (this == &other) {
        return *this;
    }

    clear();

    for (int i = 0; i < other.numItems; i++) {
        this->pushAtBack(other.elementAt(i));
    }
    
    return *this;
}

/*

name: concatenate
purpose: concatenates the contents of another CharLinkedList to this
CharLinkedList
arguments: other - a pointer to the CharLinkedList to concatenate
returns: none
effects: concatenates the contents of the other CharLinkedList to the end of
this CharLinkedList
*/
void CharLinkedList::concatenate(CharLinkedList *other) {
    if (other->isEmpty()) {
        return;
    }

    int index = other->numItems;

    for (int i = 0; i < index; i++) {
        this->pushAtBack(other->elementAt(i));
    }
}
/*
 *  CharLinkedList.h
 *  Milo Goldstein
 *  2/2/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  This file will declare the CharLinkedList class
 *
 */



#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H

#include <stdexcept>
#include <string>

class CharLinkedList {
public:
    // constructors
    CharLinkedList();
    CharLinkedList(char c);
    CharLinkedList(char arr[], int size);

    // Copy constructor
    CharLinkedList(const CharLinkedList &other);

    // Assignment operator to overload "="
    CharLinkedList &operator=(const CharLinkedList &other);

    // destructor
    ~CharLinkedList();

    //getters
    char first() const;
    char last() const;
    int size() const;
    char elementAt(int index) const;

    // category
    bool isEmpty() const;

    //setters
    void pushAtBack(char c);
    void pushAtFront(char c);
    void insertAt(char c, int index);
    void replaceAt(char c, int index);
    std::string toString() const;
    std::string toReverseString() const;
    void clear();
    void removeAt(int index);
    void popFromBack();
    void popFromFront();
    void insertInOrder(char c);
    void concatenate(CharLinkedList *other);


private:

    //node struct
    struct Node {
        char c;
        Node *next;
        Node *prev;
    };


    // private members
    Node *front;
    int listSize;

    // private methods
    Node* makeNewNode(char C);
    Node* findLastNode(Node *front) const;
    Node* findNode(int index, Node* front) const;
    void recursiveDelete();
    std::string makeString(Node *front, std::string list) const;
    std::string makeReverse(Node *front, std::string list) const;
    int compareChars(char c) const;
    
};

#endif



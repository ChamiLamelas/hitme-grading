/*
 *  unit_tests.h
 *  YOUR NAME HERE
 *  DATE CREATED
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  My unit testing file to test my program
 *
 */
#include <cassert>
#include <string>

#include "CharLinkedList.h"

void dummyTest(){
}

void defaultConstructorNoElements(){
    CharLinkedList list;
}

void constructorOneElementCheckElement(){
    char c = 'c';
    CharLinkedList list(c);
    assert(list.first() == 'c');
}

void constructorArrayDummyTest(){
    char arr[4] = {'M', 'i', 'l', 'o'};
    CharLinkedList list(arr, 4);
}

void firstNoElementsErrorCatch(){
    // create and initialize teting vars
    CharLinkedList list;
    std::string error_message = " ";
    bool runtime_error_thrown = false;

    // try and (hopefully) catch our error
    try { 
        assert(list.first());
    } 
    catch (std::runtime_error &e) {
        // if we can catch our error without crashing, we end up here
        runtime_error_thrown = true;
        error_message = e.what();
    }

    // run asserts
    assert(runtime_error_thrown);
    assert(error_message == "cannot get first of empty LinkedList");
}

void firsChangedFirstElement(){
    // use our array constructor
    char arr[4] = {'M', 'i', 'l', 'o'};
    CharLinkedList list(arr, 4);
    list.popFromFront();
    assert(list.first() == 'i');

}

void firstManyElements(){
    // use our array constructor
    char arr[4] = {'M', 'i', 'l', 'o'};
    CharLinkedList list(arr, 4);
    assert(list.first() == 'M');
}

void lastOneElement(){
    char c = 'c';
    CharLinkedList list(c);
    assert(list.last() == 'c');
}

void lastNoElementsErrorCatch(){
    // create and initialize teting vars
    CharLinkedList list;
    std::string error_message = " ";
    bool runtime_error_thrown = false;

    // try and (hopefully) catch our error
    try { 
        assert(list.last());
    } 
    catch (std::runtime_error &e) {
        // if we can catch our error without crashing, we end up here
        runtime_error_thrown = true;
        error_message = e.what();
    }

    // run asserts
    assert(runtime_error_thrown);
    assert(error_message == "cannot get last of empty LinkedList");
}

void lastManyElements(){
    char arr[4] = {'M', 'i', 'l', 'o'};
    CharLinkedList list(arr, 4);
    assert(list.last() == 'o');
}

void lastManyElementsFalse(){
    char arr[4] = {'M', 'i', 'l', 'o'};
    CharLinkedList list(arr, 4);
    assert(!(list.last() != 'o'));
}

void lastChangedlastElement(){
    // use our array constructor
    char arr[4] = {'M', 'i', 'l', 'o'};
    CharLinkedList list(arr, 4);
    list.pushAtBack('g');
    assert(list.last() == 'g');
}


void checkEmptyTrue(){
    CharLinkedList list;
    assert(list.isEmpty());
}

void checkEmptyFalse(){
    char c = 'c';
    CharLinkedList list(c);
    assert(!(list.isEmpty()));
}
void checkEmptyChanges(){
    char c = 'c';
    CharLinkedList list(c);
    list.clear();
    assert(list.isEmpty());
}

void pushAtBackFirstElementDefaultLast(){
    CharLinkedList list;
    list.pushAtBack('c');
    assert(list.last() == 'c');
}

void pushAtBackFirstElementDefaultFirst(){
    CharLinkedList list;
    list.pushAtBack('c');
    assert(list.first() == 'c');
}

void pushAtBackManyElements(){
    // use our array constructor
    char arr[4] = {'M', 'i', 'l', 'o'};
    CharLinkedList list(arr, 4);
    list.pushAtBack('c');
    assert(list.last() == 'c');
}

void pushAtFrontSingleton(){
    CharLinkedList list('c');
    list.pushAtFront('c');
    assert(list.first() == 'c');
}

void pushAtFrontEmptyList(){
    CharLinkedList list;
    list.pushAtFront('c');
    assert(list.first() == 'c');
}

void pushAtFrontManyElements(){
    // use our array constructor
    char arr[4] = {'M', 'i', 'l', 'o'};
    CharLinkedList list(arr, 4);
    list.pushAtFront('c');
    assert(list.first() == 'c');
}

void insertAt_empty_correct() {
    CharLinkedList test_list;
    test_list.insertAt('a', 0);
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');
}

// Tests incorrect insertion into an empty AL.
// Attempts to call insertAt for index larger than 0.
// This should result in an std::range_error being raised.
void insertAt_empty_incorrect() {
    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
        // insertAt for out-of-range index
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        // if insertAt is correctly implemented, a range_error will be thrown,
        // and we will end up here
        range_error_thrown = true;
        error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0]");
}

// Tests correct insertAt for front of 1-element list.
void insertAt_front_singleton_list() {
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at front
    test_list.insertAt('b', 0);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'a');
}

// Tests correct insertAt for back of 1-element list.
void insertAt_back_singleton_list() {
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at back
    test_list.insertAt('b', 1);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
}

// Tests calling insertAt for a large number of elements.
// Not only does this test insertAt, it also checks that
// array expansion works correctly.
void insertAt_many_elements() {
    CharLinkedList test_list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.insertAt('a', i);
    }

    assert(test_list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
}

// Tests insertion into front of a larger list
void insertAt_front_large_list() {
    char test_arr[9] = {'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(test_arr, 9);

    test_list.insertAt('y', 0);

    assert(test_list.size() == 10);
    assert(test_list.elementAt(0) == 'y');
    assert(test_list.toString() == 
                    "[CharLinkedList of size 10 <<yabczdefgh>>]");
}

// Tests insertion into the back of a larger list
void insertAt_back_large_list() {
    char test_arr[10] = {'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(test_arr, 10);

    test_list.insertAt('x', 10);

    assert(test_list.size() == 11);
    assert(test_list.elementAt(10) == 'x');
    assert(test_list.toString() ==
           "[CharLinkedList of size 11 <<yabczdefghx>>]");
}

// Tests insertion into the middle of a larger list
void insertAt_middle_large_list() {
    char test_arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(test_arr, 8);

    test_list.insertAt('z', 3);

    assert(test_list.size() == 9);
    assert(test_list.elementAt(3) == 'z');
    assert(test_list.toString() == "[CharLinkedList of size 9 <<abczdefgh>>]");
}

// Tests out-of-range insertion for a non-empty list.
void insertAt_nonempty_incorrect() {
    char test_arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.insertAt('a', 42);
    } catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8]");
}


void deepCopyTestAssignmentOperatorNochangesNotEmpty(){
     // use our array constructor
    char arr[4] = {'M', 'i', 'l', 'o'};
    CharLinkedList list(arr, 4);
    CharLinkedList list2;
    list2 = list;
    assert(list2.toString() == "[CharLinkedList of size 4 <<Milo>>]");
}


void CopyConstructorNoChangesNotempty(){
     // use our array constructor
    char arr[4] = {'M', 'i', 'l', 'o'};
    CharLinkedList list(arr, 4);
    CharLinkedList list2 = list;
    assert(list2.toString() == "[CharLinkedList of size 4 <<Milo>>]");
}


void insertInOrderNotEmpty(){
     // use our array constructor
    char arr[4] = {'A', 'B', 'D'};
    CharLinkedList list(arr, 3);
    list.insertInOrder('C');
    assert(list.toString() == "[CharLinkedList of size 4 <<ABCD>>]");
}

//void insertInOrderNotEmptyRepeats(){}
//void insertInOrderNotEmptyLastIndex(){}
//void insertInOrderEmpty(){}
//void insertInOrderTwoInARow(){}

void concatenateTwoNonEmpty(CharLinkedList *other){
    // use our array constructor
    char arr[4] = {'M', 'i', 'l', 'o'};
    CharLinkedList list(arr, 4);
    // use our array constructor
    CharLinkedList list2(arr, 4);
    list.concatenate(&list2);
    assert(list.toString() == "[CharLinkedList of size 8 <<MiloMilo>>]");
}

void concatenateFirstEmpty(CharLinkedList *other){
    CharLinkedList list;
    // use our array constructor
    char arr[4] = {'M', 'i', 'l', 'o'};
    CharLinkedList list2(arr, 4);
    
    list.concatenate(&list2);
    assert(list.toString() == "[CharLinkedList of size 4 <<Milo>>]");
}

void concatenateSecondEmpty(CharLinkedList *other){
    // use our array constructor
    char arr[4] = {'M', 'i', 'l', 'o'};
    CharLinkedList list(arr, 4);
    CharLinkedList list2;
    
    list.concatenate(&list2);
    assert(list.toString() == "[CharLinkedList of size 4 <<Milo>>]");
}

void concatenateBothEmpty(CharLinkedList *other){

    CharLinkedList list;
    CharLinkedList list2;
    
    list.concatenate(&list2);
    assert(list.isEmpty() && list2.isEmpty());
}











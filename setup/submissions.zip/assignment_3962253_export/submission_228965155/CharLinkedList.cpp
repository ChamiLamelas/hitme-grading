/*
 *  CharLinkedList.cpp
 *  Milo Goldstein
 *  2/2/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  This file will define the CharLinkedList class's methods
 * CharLinkedList::
 */

#include "CharLinkedList.h"

/*
 * name:      CharLinkedList
 * purpose:   initialize and empty LinkedList
 * arguments: none
 * returns:   an initializes LinkedList Object
 * effects:   front and listSize are initialized
 */
CharLinkedList::CharLinkedList(){
    front = nullptr;
    listSize  = 0;
}


/*
 * name:      CharLinkedList  
 * purpose:   initialize a size 1 LinkedList
 * arguments: a character to be the first element
 * returns:   a size 1 linked list
 * effects:   listSize = 1, a new node is created on the heap
 */
CharLinkedList::CharLinkedList(char c){
    front = makeNewNode(c);
    listSize = 1;
}



/*
 * name:      CharLinkedList
 * purpose:   initialize a linked list of a specified size
 * arguments: an array of characters and its size
 * returns:   linked list with "size" element(s)
 * effects:   "size" Node(s) are created on the heap, front points to the first
 */
CharLinkedList::CharLinkedList(char arr[], int size){
    // initialize
    front = makeNewNode(arr[0]);
    this->listSize = size;
    //we've already set our 0th element
    for(int i = 1; i < size; i++){
        Node *last = findLastNode(front);
        Node *newNode = makeNewNode(arr[i]);
        last->next = newNode;
        newNode->prev = last;
    }
}

/*
 * name:      operator= (operator assignent overloader)
 * purpose:   Overload the "=" operator to make deep, instead of shallow, copies
 * arguments: another linked list (reference)
 * returns:   a Reference to the copied information
 * effects:   Creates new deep copy on the heap using more memory
 */
CharLinkedList& CharLinkedList::operator=(const CharLinkedList &other){
    // If the instance is already equal to the rhs, were done.
    if(this == &other){
        return *this;
    }
    this->clear();
    //else, we'll reach this point and skip the above if statement
    //make deep copies of our pointers, regular copies of everything else.
    Node *temp = other.front;
     while(temp != nullptr){
        this->pushAtBack(temp->c);
         temp = temp->next;
    }
    this->listSize = other.listSize;
    return *this;
}

/*
 * name:      CharLinkedList (Cpy Constructor)
 * purpose:   Create deep copies of an object when copy constructor  operations
 *            are called
 * arguments: a reference to a new CharlinkedList object
 * returns:   a Reference to a deep copy
 * effects:   Creates new Object on heap—memory use
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other){
    //initialize
    this->front = nullptr;
    this->listSize = 0;

    //Copy
    Node *temp = other.front;
     while(temp != nullptr){
        this->pushAtBack(temp->c);
         temp = temp->next;
    }
    this->listSize = other.listSize;
}

/*
 * name:      ~CharLinkedList
 * purpose:   recursively deallocatre all heap data when object goes out of 
 *            scope
 * arguments: none
 * returns:   none
 * effects:   Memory in use is freed.
 */
CharLinkedList::~CharLinkedList() {
    recursiveDelete();
}

/*
 * name:      first
 * purpose:   find the first character in an object
 * arguments: none
 * returns:   the first character in an object, runtim error if object is empty
 * effects:   const
 */
char CharLinkedList::first() const{
    // make sure there are elements, else throw an error
    if(listSize > 0){
        return front->c;
    }else{
        throw std::runtime_error("cannot get first of empty LinkedList");
    }
   
}

/*
 * name:      last
 * purpose:   find the last character in an object
 * arguments: none
 * returns:   the last character in an object, runtim error if object is empty
 * effects:   const
 */
char CharLinkedList::last() const{
    // recursively find and return the last node
    Node *currLast = findLastNode(this->front);
    if (currLast != nullptr) return currLast->c;
    //if we haven't returned anything, then our list is empty, throw error
    throw std::runtime_error("cannot get last of empty LinkedList");
}

/*
 * name:      size
 * purpose:   tell us our list's size
 * arguments: none
 * returns:   the integer value of our list's size
 * effects:   const
 */
int CharLinkedList::size() const{
        return listSize;
}

/*
 * name:      elementAt
 * purpose:   find the element at any given index
 * arguments: an index of our List
 * returns:   the element at any given index, range error if impossible index 
 *            given
 * effects:   const
 */
char CharLinkedList::elementAt(int index) const{
    // check if our index is valid
    if(index >= 0 && index < listSize){
        //use recursive helper function to find node and return its character
       Node *found = findNode(index, front);
       return found->c;
    }else{
        //throw error if an invalid index was given
        std::string IDX = std::to_string(index);
        std::string SIZE = std::to_string(this->listSize);
        std::string err = "index (" + IDX + ") not in range [0.." + SIZE + ")";
        throw std::range_error(err);
    }       
    
}

/*
 * name:      isEmpty
 * purpose:   Tell client weather or not their linked list is empty
 * arguments: none
 * returns:   a boolean indicating if the list is empty
 * effects:   const
 */
bool CharLinkedList::isEmpty() const{

    //we are only empty if our size is 0
    if(listSize == 0) return true;
    return false;

}

/*
 * name:      pushAtBack
 * purpose:   add a node with given character data to the end of the list
 * arguments: a character to be appended
 * returns:   none
 * effects:   Creates new heap node, listSize incrimented, last 2 nodes' prev
              and Next nodes point at each other appropriately
 *            
 */
void CharLinkedList::pushAtBack(char c){

    // make a new node for c with a helper function
    Node *newNode = makeNewNode(c);
    //find our last node with a recursive helper function
    Node *oldLast = findLastNode(this->front);
    //assign the correct prev and next's
    if(oldLast != nullptr){
        oldLast->next = newNode;
        newNode->prev = oldLast;
    }else{
        front = newNode;
    }
    //incriment list size
    listSize++;
}

/*
 * name:      pushAtFront
 * purpose:   Add a node with given character data to the front of the list
 * arguments: a character, c
 * returns:   none
 * effects:   Creates a new node on the heap, incriments listSize, changes
 *            front pointer to point to our new node, new->next is our old front
 */
void CharLinkedList::pushAtFront(char c){
    //use a helper function to create a new node with c's data
    Node *newFront = makeNewNode(c);

    // appropriately reset front and back pointers
    newFront->next = front;
    if(listSize > 0) front->prev = newFront;
    front = newFront;

    //incriment list size
    listSize++;
}

/*
 * name:      insertAt
 * purpose:   adds a new node at a specified index
 * arguments: a character, c, and and integer index of our list
 * returns:   Throws error if index is invalid
 * effects:   new heap node is created, prev and next pointers surrounding our
 *            new node are properly set/reset
 */
void CharLinkedList::insertAt(char c, int index){
    if(index == 0){
        pushAtFront(c);
    }else if(index > 0 && index < listSize){
        Node *newNode = makeNewNode(c);
        Node *curr = front;
        // find the node before our index 
        // start at one since assigning curr to front is already our "0th" step
        for(int i = 1; i < index; i++){
             curr = curr->next;
        }
        //reset pointers correctly
        Node *temp = curr->next;
        curr->next = newNode;
        newNode->prev = curr;
        newNode->next = temp;
        temp->prev = newNode;
        //incriment list size
        listSize++;
    }else if(index == listSize){
        // if we are at our upper boud, we're just appending to the back
        pushAtBack(c);
    }else{
        // error case (invalid index)
        std::string IDX = std::to_string(index);
        std::string SIZE = std::to_string(this->listSize);
        std::string err = "index (" + IDX + ") not in range [0.." + SIZE + "]";
        throw std::range_error(err);
    }
}

/*
 * name:      replaceAt
 * purpose:   replace the data of a node at a given index
 * arguments: the character that will replace the old data, the index to replace
 *            at
 * returns:   throws error if invalid index is given
 * effects:   front and listSize are initialized
 */
void CharLinkedList::replaceAt(char c, int index){
    if(index >= 0 && index < listSize){
        //use recursive helper function to find the node we need
        Node *found = findNode(index, front);
        found->c = c;
    }else{
        // error case (invalid index)
        std::string IDX = std::to_string(index);
        std::string SIZE = std::to_string(this->listSize);
        std::string err = "index (" + IDX + ") not in range [0.." + SIZE + ")";
        throw std::range_error(err);
    }   
}

/*
 * name:      toString
 * purpose:   print the list as a string with its size information as well
 * arguments: none
 * returns:   a string of our list with size information
 * effects:   const
 */
std::string CharLinkedList::toString() const{

    std::string contents = "";
    std::string size = std::to_string(this->size());
    // use recursive helper function to make a string out of JUST our list
    contents = makeString(front, contents);
    contents = "[CharLinkedList of size " + size + " <<" + contents + ">>]";
    return contents;
}

/*
 * name:      toReverseString
 * purpose:   print the list as a Revrsestring with its size information as well
 * arguments: none
 * returns:   a a string of our list in reverse order with size information
 * effects:   const
 */
std::string CharLinkedList::toReverseString() const{
    std::string contents = "";
    std::string size = std::to_string(this->size());
    //use helper reverse function
    contents = makeReverse(front, contents);
    contents = "[CharLinkedList of size " + size + " <<" + contents + ">>]";
    return contents;
}

/*
 * name:      clear
 * purpose:   delete this instance's contents
 * arguments: none
 * returns:   none
 * effects:   frees any used heap data
 */
void CharLinkedList::clear(){
    //use helper function to free heap memory
    recursiveDelete();
    //reinitialize private member values to that of an empty list
    front = nullptr;
    listSize = 0;
}

/*
 * name:      removeAt
 * purpose:   removes an element of our list at a specified index
 * arguments: an index in our list
 * returns:   throws range error for impossible indexes
 * effects:   frees heap memory, decreases listSize, resets prev and next's
 */
void CharLinkedList::removeAt(int index){
     if(index >= 0 && index < listSize){
        //use recursive helper function to find the node we want to delete
        Node *found = findNode(index, front);
        // reset next and prev's
        if(listSize > 1) found->prev->next = found->next;
        if(index < listSize - 1)found->next->prev = found->prev;
        // delete our node
        delete found;
        //decriment our list's size
        listSize--;
    }else{
        //error case (invalid index)
        std::string IDX = std::to_string(index);
        std::string SIZE = std::to_string(this->listSize);
        std::string err = "index (" + IDX + ") not in range [0.." + SIZE + ")";
        throw std::range_error(err);
    }   
}

/*
 * name:      popFromBack
 * purpose:   remove the last element of an object
 * arguments: none
 * returns:   Throws an error if the list is empty
 * effects:   frees heap space, sets newLast element's next to nullptr
 */
void CharLinkedList::popFromBack(){
    //use recursive helper function
    Node *currLast = findLastNode(front);
    //The findLastNode function only returns nullptr if the list is empty
    if (currLast != nullptr){
        //reset the newLast's next pointer
        currLast->prev->next = nullptr;
        //free heap memory for the old last element
        delete currLast;
        // decrease list's size
        listSize--;
    }else{
        //if we haven't returned anything, then the list is empty, throw error 
        throw std::runtime_error("cannot pop from empty LinkedList");
    }
}

/*
 * name:      popFromFront
 * purpose:   remove the first element of an object
 * arguments: none
 * returns:   Throws an error if the list is empty
 * effects:   frees heap space, sets the newFirst's prev pointer to nullptr
 */
void CharLinkedList::popFromFront(){
    Node *currFront = front;
    // if our list is not empty, then pop the front
    if (currFront != nullptr){
        // reset the newFront's ptr
        currFront->next->prev = nullptr;
        //reset the object's front pointer
        front = currFront->next;
        //free the heap
        delete currFront;
        //decrease the lists size
        listSize--;
    }else{
         //if we haven't returned anything, then the list is empty, throw error 
        throw std::runtime_error("cannot pop from empty LinkedList");
    }
}


/*
 * name:      insertInOrder
 * purpose:   correctly inserts a character into a sorted list
 * arguments: a character to be inserted
 * returns:   none
 * effects:   a new element is initialized on the heap
 */
void CharLinkedList::insertInOrder(char c){
    int index = compareChars(c);
    insertAt(c, index);
}

/*
 * name:      concatenate
 * purpose:   appends one list to the end of another
 * arguments: the list whose contents will be appended onto the first
 * returns:   none
 * effects:   the first list now has the information of the second
 */
void CharLinkedList::concatenate(CharLinkedList *other){
    //we don't do anything if we are concatenating an empty list
    if(other->size() != 0){
        if(this->isEmpty()){
            // if its empty, make a copy of other (dereference this and other bc
            // of how our overload assignmnet operator passes objects in)
            *this = *other;
        }else{
            //if both lists are not empty, loop through other and make new nodes
            // with identicle list data and order
            Node *copyCurr = other->front;
            while(copyCurr != nullptr){
                this->pushAtBack(copyCurr->c);
                copyCurr = copyCurr->next;
            }
        }
    }
}




// 
/*
 * name:      makeNewNode
 * purpose:   helper function that makes and initializes a new node
 * arguments: the character data for the new node
 * returns:   a pointer to our new node
 * effects:   reserves new heap data
 */
CharLinkedList::Node* CharLinkedList::makeNewNode(char c){
    Node *newNode = new Node;
    newNode->c = c;
    newNode->next = nullptr;
    newNode->prev = nullptr;
    return newNode;
}


/*
 * name:      CharLinkedList
 * purpose:   helper function that returns a pointer to the last node of a list 
 *            starting at any point if size == 0 , returns nullptr NOTE: this 
 *            function does NOT keep track of the last node, it simply finds it 
 *            once
 * arguments: A pointer to the first node in our list
 * returns:   a pointer to the last node 
 * effects:   const
 */
CharLinkedList::Node* CharLinkedList::findLastNode(Node *start) const{
    //Base cases: we're at a null pointer, or the next node is a null pointer
    if(start == nullptr){
        return start;
    }else if(start->next == nullptr){
        return start;
    }else{
        //recursive case
        return findLastNode(start->next);
    }
}

/*
 * name:      findNode
 * purpose:   helper function that take a pointer pointing to the front of the 
 *            list and the index we want assumes valid index
 * arguments: a pointer pointing to the front of the 
 *            list and the index we want
 * returns:   a pointer to the node at that index
 * effects:   const
 */
CharLinkedList::Node* CharLinkedList::findNode(int index, Node *front) const{
    if(index == 0){
        return front;
    }else{
        return findNode((index - 1), front->next);
    }
}

/*
 * name:      recursiveDelete
 * purpose:   free all heap space being used by elements
 * arguments: none
 * returns:   none
 * effects:   frees all heap data used in our object currently
 */
void CharLinkedList::recursiveDelete(){
    Node *curr = front;
    // recursively loop until we're past the end of our list
    if(curr != nullptr){
        front = curr->next;
        delete curr;
        recursiveDelete();
    }
}
 
/*
 * name:      makeString
 * purpose:   Make our list's contents into a string
 * arguments: a pointer to the front of our list and the string to put our 
 *            list's information in
 * returns:   a string of only our list's contents
 * effects:   cosnt
 */
std::string CharLinkedList::makeString(Node *front, std::string list) const{
    //base case, we're at the end of our list already
    if(front == nullptr){
        return list;
    }else{
        //recursive case, add this "step's" letter to the end, and recurse on!
        list = list + front->c;
        return makeString(front->next, list);
    }
}
 
/*
 * name:      makeReverse
 * purpose:   Make our list's contents into a reversed string (toReverseString
 *            helper)
 * arguments: a pointer to the front of our list and the string to put our 
 *            list's information in
 * returns:   a string of only our list's contents in reverse order
 * effects:   const
 */
std::string CharLinkedList::makeReverse(Node *front, std::string list) const{
    // base case: we are at the end of our list
    if(front == nullptr){
        return list;
    }else{
        //add current letter to the front of current string, recurse on
        list = front->c + list;
        return makeReverse(front->next, list);
    }
}

/*
 * name:      CharLinkedList
 * purpose:   helper function for insertInOrder, returns the correct index to 
 *            add 'c' to
 * arguments: the character given to insertInOrder
 * returns:   the integer index in our list where c shoudl be inserted
 * effects:   const
 */
int CharLinkedList::compareChars(char c) const{
    int index = 0;
    Node *temp = front;
    // if its empty, we rturn index 0
    if(listSize == 0) return index;
    while(c > temp->c){
        index++;
        temp = temp->next;
        //if we've reached the end of list, temp will be nullptr, return size
        if(temp == nullptr){
            return listSize;
        }
    }
    return index;
}



/*
 *  CharLinkedList.h
 *  Eli Newman
 *  1/31/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Creates a linked list class for characters. Clients can add in elements
    and perform various operations on the elements of the list.
 *
 */

#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H

#include <string>
#include <stdexcept>

class CharLinkedList {
    public:
    // CONSTRUCTORS

    // Empty list Constructor
    CharLinkedList();
    // One char Constructor
    CharLinkedList(char c);
    // List of Chars Constructor
    CharLinkedList(char arr[], int size);
    // Copy Constructor
    CharLinkedList(const CharLinkedList &other);

    // DESTRUCTOR
    ~CharLinkedList();

    // REST OF PUBLIC FUNTIONS
    CharLinkedList &operator=(const CharLinkedList &other);
    bool isEmpty() const;
    void clear();
    int size() const;
    char first() const;
    char last() const;
    char elementAt(int index) const;
    std::string toString() const;
    std::string toReverseString() const;
    void pushAtBack(char c);
    void pushAtFront(char c);
    void insertAt(char c, int index);
    void insertInOrder(char c);
    void popFromFront();
    void popFromBack();
    void removeAt(int index);
    void replaceAt(char c, int index);
    void concatenate(CharLinkedList *other);

private:
    struct Node{
        char data;
        Node *before;
        Node *next;
    };
    int length;
    Node *front;
    void recursive_delete(Node *deleted) const;
    Node *recursive_node_mover(int target, int current, Node *curr_node) const;
    Node *node_mover(int index) const;
    Node *nodes_maker(int target, int curr);
    void before_populator();
    void node_inserter(int index);
    void node_remover(int index);
};

#endif

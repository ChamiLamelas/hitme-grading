/*
 *  unit_tests.h
 *  Eli Newman
 *  2/1/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  This document exists to test the individual functions of CharLinkedList.cpp
 *
 */

#include "CharLinkedList.h"
#include <cassert>

// EMPTY TESTS

// Tests to make sure that the syntax of the class is correct
void nothing_test() {

}

// EMPTY CONSTRUCTOR TESTS

// Tests to make sure the code compiles when an empty list is constructed
void empty_constructor_compile() {
    CharLinkedList list;
}

// SINGLE CHAR CONSTRUCTOR TESTS

void char_constructor_compile() {
    CharLinkedList list('c');
}

void char_constructor_check() {
    CharLinkedList list('c');
    assert(list.first() == 'c');
}

void char_constructor_check_back() {
    CharLinkedList list('c');
    assert(list.last() == 'c');
}

// ARRAY CHAR CONSTRUCTOR TESTS
void one_char_constructor() {
    char arr[1] = {'a'};
    CharLinkedList list(arr, 1);
    //assert(list.first() ==  'a');
    //assert(list.last() == 'a');
    //assert(list.elementAt(0) == 'a');
}

void two_char_constructor() {
    char arr[2] = {'a', 'b'};
    CharLinkedList list(arr, 2);
    assert(list.first() ==  'a');
    assert(list.last() == 'b');
    assert(list.elementAt(1) == 'b');
}

void several_char_constructor() {
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList list(arr, 3);
    assert(list.first() ==  'a');
    assert(list.last() == 'c');
    assert(list.elementAt(1) == 'b');
}

// COPY CONSTRUCTOR TESTS

// Constructs an array list from a pre-existing array list. 
// Makes sure the elements and size of both arrays are identical.
void copy_constructor_normal() {
    char char_arr[5] = {'h', 'e', 'l', 'l', 'o'};
    CharLinkedList list = CharLinkedList(char_arr, 5);
    CharLinkedList second = CharLinkedList(list);
    assert(second.size() == 5);
    assert(second.toString() == "[CharLinkedList of size 5 <<hello>>]");
}

// ASSIGNMENT OPERATOR TESTS

// Sets two lists equal to each other.
// Tests to see if both lists match and that one list can be changed without
// changing the other. 
// Also testing size and toString function
void assignment_test() {
    char char_arr[5] = {'h', 'e', 'l', 'l', 'o'};
    CharLinkedList list = CharLinkedList(char_arr, 5);
    CharLinkedList second;
    second = list;
    assert(second.size() == 5);
    assert(second.toString() == "[CharLinkedList of size 5 <<hello>>]");
    list.clear();
    assert(second.size() == 5);
    assert(second.toString() == "[CharLinkedList of size 5 <<hello>>]");
}

// isEmpty TESTS

// Checks if an empty list is empty.
void empty_test() {
    CharLinkedList list;
    assert(list.isEmpty() == true);
}

// Checks to see if a full list is empty.
void full_test() {
    CharLinkedList list = CharLinkedList('x');
    assert(list.isEmpty() == false);
}

// clear TESTS

// Checks to see if a previously non-empty list is empty after clearing it.
void clear_test() {
    char char_arr[3] = {'x', 'y', 'z'};
    CharLinkedList list = CharLinkedList(char_arr, 3);
    assert(list.isEmpty() == false);
    list.clear();
    assert(list.isEmpty() == true);
}

// Checks to see if clearing an empty list doesn't break things
void empty_clear_test_edge() {
    CharLinkedList list;
    assert(list.isEmpty() == true);
    list.clear();
    assert(list.isEmpty() == true);
}

// size TESTS

// Checks to make sure that an empty list has size 0.
void empty_size_test() {
    CharLinkedList list;
    assert(list.size() == 0);
}

// Checks to make sure that a one character list has size 1.
void one_char_size_test() {
    CharLinkedList list = CharLinkedList('f');
    assert(list.size() == 1);
}

// Checks to make sure that multiple elements in a list results in the correct
// size being outputed.
void array_size_test() {
    char char_arr[3] = {'x', 'y', 'z'};
    CharLinkedList list = CharLinkedList(char_arr, 3);
    assert(list.size() == 3);
}

// first TESTS

// Tests to see if the proper error is thrown when trying to find the first
// element of an empty array list.
void first_error_test() {
    CharLinkedList list;
    // var to track whether range_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";
    try {
        list.first();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "cannot get first of empty LinkedList"); 
}

// last TESTS

// Tests to see if the proper error is thrown when trying to find the last
// element of an empty linked list.
void last_error_test() {
    CharLinkedList list;
    // var to track whether range_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";
    try {
        list.last();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "cannot get last of empty LinkedList"); 
}

// elementAt TESTS

// Tests to see if the proper error is thrown when trying to find the element
// at a given index of an empty list.
void element_at_error_nullptr_test() {
    CharLinkedList list;
    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";
    try {
        list.elementAt(2);
    }
    catch (const std::runtime_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (2) not in range [0..0)"); 
}

// Tests to see if the proper error is thrown when trying to find the element
// at an index less than 0.
void element_at_error_too_small_test() {
    char char_arr[3] = {'x', 'y', 'z'};
    CharLinkedList list = CharLinkedList(char_arr, 3);
    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";
    try {
        list.elementAt(-1);
    }
    catch (const std::runtime_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (-1) not in range [0..3)");
}

// Tests to see if the proper error is thrown when trying to find the element
// at an index greater than numItems - 1.
void element_at_error_too_big_test() {
    char char_arr[3] = {'x', 'y', 'z'};
    CharLinkedList list = CharLinkedList(char_arr, 3);
    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";
    try {
        list.elementAt(3);
    }
    catch (const std::runtime_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (3) not in range [0..3)");
}

// toString TESTS 

// Tests to see if toString results in the proper output with a non-empty
// array list.
void full_to_string_test() {
    char char_arr[4] = {'x', 'y', 'z', 'a'};
    CharLinkedList list = CharLinkedList(char_arr, 4);
    assert(list.toString() == "[CharLinkedList of size 4 <<xyza>>]");
}

// Tests to see if toString results in the proper output with an empty array
// list.
void empty_to_string_test() {
    CharLinkedList list;
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}

// toReverseString TESTS

// tests to make sure that toReverseString prints out the proper output with
// a non-empty array list.
void full_to_reverse_string_test() {
    char char_arr[4] = {'x', 'y', 'z', 'a'};
    CharLinkedList list = CharLinkedList(char_arr, 4);
    assert(list.toReverseString() == "[CharLinkedList of size 4 <<azyx>>]");
}

// tests to make sure that toReverseString prints out the proper output with
// a empty array list.
void empty_to_reverse_string_test() {
    CharLinkedList list;
    assert(list.toReverseString() == "[CharLinkedList of size 0 <<>>]");
}

// pushAtBack TESTS

// Tests to make sure that pushing a character to the back of a non-empty array
// list results in the expected behavior in regards to size of the list and the
// last element of the array.
void normal_push_back() {
    char char_arr[3] = {'x', 'y', 'z'};
    CharLinkedList list = CharLinkedList(char_arr, 3);
    list.pushAtBack('a');
    assert(list.size() == 4);
    assert(list.last() == 'a');
    assert(list.elementAt(3) == 'a');
}

// Tests to make sure that pushing back a character onto an empty array list
// results in an array with one element (the element pushed back onto
// the list).
void empty_push_back() {
    CharLinkedList list;
    list.pushAtBack('a');
    assert(list.size() == 1);
    assert(list.last() == 'a');
    assert(list.elementAt(0) == 'a');
}

// Tests to make sure that the pushing two elements one after another results
// in the expected behavior.
void double_push_back() {
    char char_arr[3] = {'x', 'y', 'z'};
    CharLinkedList list = CharLinkedList(char_arr, 3);
    list.pushAtBack('a');
    assert(list.size() == 4);
    assert(list.last() == 'a');
    assert(list.elementAt(3) == 'a'); 
    list.pushAtBack('B');
    assert(list.size() == 5);
    assert(list.last() == 'B');
    assert(list.elementAt(3) == 'a');
}

// pushAtFront TESTS

// Makes sure that pushing a character to the front of a non-empty array
// list results in the expected behavior in regards to size of the list, the
// first element of the array, and the shift of all elements one index to the
// right.
void normal_push_front() {
    char char_arr[3] = {'x', 'y', 'z'};
    CharLinkedList list = CharLinkedList(char_arr, 3);
    list.pushAtFront('a');
    assert(list.size() == 4);
    assert(list.first() == 'a');
    assert(list.elementAt(1) == 'x');
    assert(list.toString() == "[CharLinkedList of size 4 <<axyz>>]");
}

// Tests to make sure that pushing a character to the front of an empty array 
// list results in a list with one element.
void empty_push_front() {
    CharLinkedList list;
    list.pushAtFront('a');
    assert(list.size() == 1);
    assert(list.first() == 'a');
}

// Tests to make sure that two pushAtFront applications results in the expected
// behavior.
void double_push_front() {
    char char_arr[3] = {'x', 'y', 'z'};
    CharLinkedList list = CharLinkedList(char_arr, 3);
    list.pushAtFront('a');
    assert(list.size() == 4);
    assert(list.first() == 'a');
    assert(list.elementAt(3) == 'z'); 
    list.pushAtFront('B');
    assert(list.size() == 5);
    assert(list.first() == 'B');
    assert(list.elementAt(3) == 'y');
}

// insertAt TESTS


// Tests correct insertion into an empty AL.
// Afterwards, size should be 1 and element at index 0
// should be the element we inserted.
void insertAt_empty_correct() { 

    CharLinkedList test_list;
    test_list.insertAt('a', 0);
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');

}

// Tests incorrect insertion into an empty AL.
// Attempts to call insertAt for index larger than 0.
// This should result in an std::range_error being raised.
void insertAt_empty_incorrect() {

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    // insertAt for out-of-range index
    test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
    // if insertAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    range_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0]");
    
}

// Tests correct insertAt for front of 1-element list.
void insertAt_front_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at front
    test_list.insertAt('b', 0);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'a');
    
}

// Tests correct insertAt for back of 1-element list.
void insertAt_back_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at back
    test_list.insertAt('b', 1);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    
}

// Tests calling insertAt for a large number of elements.
// Not only does this test insertAt, it also checks that
// array expansion works correctly.
void insertAt_many_elements() {
    
    CharLinkedList test_list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.insertAt('a', i);
    }

    assert(test_list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
    
}

// Tests insertion into front of a larger list
void insertAt_front_large_list() {
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    test_list.insertAt('y', 0);

    assert(test_list.size() == 10);
    assert(test_list.elementAt(0) == 'y');
    assert(test_list.toString() ==     
    "[CharLinkedList of size 10 <<yabczdefgh>>]");

}

// Tests insertion into the back of a larger list
void insertAt_back_large_list() {

    char test_arr[10] = { 'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 10);  

    test_list.insertAt('x', 10);

    assert(test_list.size() == 11);
    assert(test_list.elementAt(10) == 'x');
    assert(test_list.toString() == 
    "[CharLinkedList of size 11 <<yabczdefghx>>]"); 

}

// Tests insertion into the middle of a larger list
void insertAt_middle_large_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.insertAt('z', 3);

    assert(test_list.size() == 9);
    assert(test_list.elementAt(3) == 'z');
    assert(test_list.toString() == 
    "[CharLinkedList of size 9 <<abczdefgh>>]");

}

// Tests out-of-range insertion for a non-empty list.
void insertAt_nonempty_incorrect() {
   
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8]"); 
}

// Large test to make sure insert function works as intended ignoring
// the edge cases.
void insert_normal() {
    char char_arr[3] = {'x', 'y', 'z'};
    CharLinkedList list = CharLinkedList(char_arr, 3);
    list.insertAt('a', 1);
    assert(list.elementAt(1) == 'a');
    assert(list.elementAt(0) == 'x');
    assert(list.elementAt(2) == 'y');
    assert(list.size() == 4);
    assert(list.elementAt(3) == 'z');
    assert(list.toString() == "[CharLinkedList of size 4 <<xayz>>]");
    list.insertAt('b', 0);
    assert(list.toString() == "[CharLinkedList of size 5 <<bxayz>>]");
    list.insertAt('c', 5);
    assert(list.toString() == "[CharLinkedList of size 6 <<bxayzc>>]");
}

// Test to make sure that inserting into an empty list results in an array
// list with a single element.
void insert_from_empty() {
    CharLinkedList list;
    list.insertAt('a', 0);
    assert(list.toString() == "[CharLinkedList of size 1 <<a>>]");
}

// Test to make sure that the proper error is thrown if there is an insertion
// at an index less than 0.
void insert_at_error_too_small_test() {
    char char_arr[3] = {'x', 'y', 'z'};
    CharLinkedList list = CharLinkedList(char_arr, 3);
    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";
    try {
        list.insertAt('a', -1);
    }
    catch (const std::runtime_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (-1) not in range [0..3]");
}

// Test to make sure that the proper error is thrown if there is an insertion
// at an index greater than numItems.
void insert_at_error_too_big_test() {
    char char_arr[3] = {'x', 'y', 'z'};
    CharLinkedList list = CharLinkedList(char_arr, 3);
    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";
    try {
        list.insertAt('a', 4);
    }
    catch (const std::runtime_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (4) not in range [0..3]");
}

// insertInOrder TESTS

// Tests to make sure the function follows the expected behavior for an
// alphabetical case.
void ordered_insert_easy() {
    char char_arr[3] = {'w', 'x', 'z'};
    CharLinkedList list = CharLinkedList(char_arr, 3);
    list.insertInOrder('y');
    assert(list.toString() == "[CharLinkedList of size 4 <<wxyz>>]");
}

// Tests to make sure that the function follows the expected behavior for
// a non-alphabetical case.
void ordered_insert_standard() {
    char char_arr[3] = {'z', 'a', 'x'};
    CharLinkedList list = CharLinkedList(char_arr, 3);
    list.insertInOrder('c');
    assert(list.first() == 'c');
}

// Checks to make sure that the function follows the expected behavior for a 
// case in which all elements are the same.
void ordered_insert_same() {
    char char_arr[3] = {'a', 'a', 'a'};
    CharLinkedList list = CharLinkedList(char_arr, 3);
    list.insertInOrder('a');
    assert(list.toString() == "[CharLinkedList of size 4 <<aaaa>>]");
}

// Checks to make sure that the function follows the expected behavior for a 
// case in which some elements are the same.
void ordered_insert_almost_same() {
    char char_arr[3] = {'a', 'b', 'b'};
    CharLinkedList list = CharLinkedList(char_arr, 3);
    list.insertInOrder('b');
    assert(list.toString() == "[CharLinkedList of size 4 <<abbb>>]");
}

// Tests to make sure that the function follows the expected behavior for
// a capital alphabetical case.
void ordered_insert_capital_easy() {
    char char_arr[3] = {'W', 'X', 'Z'};
    CharLinkedList list = CharLinkedList(char_arr, 3);
    list.insertInOrder('Y');
    assert(list.toString() == "[CharLinkedList of size 4 <<WXYZ>>]");
}

// Tests to make sure that the function follows the expected behavior for
// a case in which all elements are the same and the inserted letter is after 
// the elements in the array. 
void ordered_insert_back() {
    char char_arr[3] = {'a', 'a', 'a'};
    CharLinkedList list = CharLinkedList(char_arr, 3);
    list.insertInOrder('c');
    assert(list.toString() == "[CharLinkedList of size 4 <<aaac>>]");
}

// popFromFront TESTS

// Tests to make sure that popFromFront works as intended on a standard,
// non-edge case.
void front_pop_normal() {
    char char_arr[3] = {'a', 'b', 'c'};
    CharLinkedList list = CharLinkedList(char_arr, 3);
    list.popFromFront();
    assert(list.toString() == "[CharLinkedList of size 2 <<bc>>]");
}

// Tests to make sure that we are left with an empty list after popping an 
// element off of a single element array list.
void front_pop_single() {
    CharLinkedList list = CharLinkedList('a');
    list.popFromFront();
    assert(list.size() == 0);
}

// Tests to make sure that the proper error message is thrown when trying to
// pop an element off of an empty list.
void front_pop_error() {
    CharLinkedList list;
    // var to track whether range_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";
    try {
        list.popFromFront();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(list.size() == 0);
    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

// popFromBack TESTS

// Tests to make sure that popFromBack works as intended on a standard,
// non-edge case.
void back_pop_normal() {
    char char_arr[3] = {'a', 'b', 'c'};
    CharLinkedList list = CharLinkedList(char_arr, 3);
    list.popFromBack();
    assert(list.toString() == "[CharLinkedList of size 2 <<ab>>]");
}

// Tests to make sure that we are left with an empty list after popping an 
// element off of a single element array list.
void back_pop_single() {
    CharLinkedList list = {'a'};
    list.popFromBack();
    assert(list.size() == 0);
}

// Tests to make sure that the proper error message is thrown when trying to
// pop an element off of an empty list.
void back_pop_error() {
    CharLinkedList list;
    // var to track whether range_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";
    try {
        list.popFromBack();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(list.size() == 0);
    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

// removeAt TESTS

// Tests to make sure that removeAt works as intended for a removal in the 
// middle of a non-empty list.
void middle_removal() {
    char char_arr[3] = {'a', 'b', 'c'};
    CharLinkedList list = CharLinkedList(char_arr, 3);
    list.removeAt(1);
    assert(list.size() == 2);
    assert(list.toString() == "[CharLinkedList of size 2 <<ac>>]");
}

// Tests to make sure that removeAt works as intended at the end of a list.
void end_removal() {
    char char_arr[3] = {'a', 'b', 'c'};
    CharLinkedList list = CharLinkedList(char_arr, 3);
    list.removeAt(2);
    assert(list.toString() == "[CharLinkedList of size 2 <<ab>>]");
}

// Tests to make sure that removeAt works as intended at the beginning 
// of a list
void beginning_removal() {
    char char_arr[3] = {'a', 'b', 'c'};
    CharLinkedList list = CharLinkedList(char_arr, 3);
    list.removeAt(0);
    assert(list.toString() == "[CharLinkedList of size 2 <<bc>>]");
}

// Tests to make sure that an error is thrown when trying to remove an element
// at an index in an empty array list.
void remove_at_error_empty() {
    CharLinkedList list;
    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";
    try {
        list.removeAt(0);
    }
    catch (const std::runtime_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(list.size() == 0);
    assert(range_error_thrown);
    assert(error_message == "index (0) not in range [0..0)");
}

// Tests to make sure that an error is thrown when trying to remove an element
// at an index that is less than 0.
void remove_at_error_too_small() {
    char char_array[3] = {'a', 'b', 'c'};
    CharLinkedList list = CharLinkedList(char_array, 3);
    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";
    try {
        list.removeAt(-1);
    }
    catch (const std::runtime_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (-1) not in range [0..3)");
}

// Tests to make sure that an error is thrown when trying to remove an element 
// at an index that is less than 0.
void remove_at_error_too_big() {
    char char_array[3] = {'a', 'b', 'c'};
    CharLinkedList list = CharLinkedList(char_array, 3);
    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";
    try {
        list.removeAt(3);
    }
    catch (const std::runtime_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (3) not in range [0..3)");
}

//replaceAt TESTS

// Tests to make sure that the replacement function works as intended for 
// a non-empty list in which the middle element is being replaced.
void middle_replace() {
    char char_arr[3] = {'a', 'b', 'c'};
    CharLinkedList list = CharLinkedList(char_arr, 3);
    list.replaceAt('z', 1);
    assert(list.toString() == "[CharLinkedList of size 3 <<azc>>]");
}

// Tests to make sure that the replacement function works as intended for 
// a non-empty list in which the last element is being replaced.
void end_replace() {
    char char_arr[3] = {'a', 'b', 'c'};
    CharLinkedList list = CharLinkedList(char_arr, 3);
    list.replaceAt('z', 2);
    assert(list.toString() == "[CharLinkedList of size 3 <<abz>>]");
}

// Tests to make sure that the replacement function works as intended for 
// a non-empty list in which the first element is being replaced.
void beginning_replace() {
    char char_arr[3] = {'a', 'b', 'c'};
    CharLinkedList list = CharLinkedList(char_arr, 3);
    list.replaceAt('z', 0);
    assert(list.toString() == "[CharLinkedList of size 3 <<zbc>>]");
}

void replace_error_empty() {
    CharLinkedList list;
    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";
    try {
        list.replaceAt('z', 0);
    }
    catch (const std::runtime_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (0) not in range [0..0)");
}

void replace_error_too_small() {
    char char_array[3] = {'a', 'b', 'c'};
    CharLinkedList list = CharLinkedList(char_array, 3);
    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";
    try {
        list.replaceAt('z', -1);
    }
    catch (const std::runtime_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (-1) not in range [0..3)");
}

void replace_error_too_big() {
    char char_array[3] = {'a', 'b', 'c'};
    CharLinkedList list = CharLinkedList(char_array, 3);
    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";
    try {
        list.replaceAt('z', 3);
    }
    catch (const std::runtime_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (3) not in range [0..3)");
}

// concatenate TESTS

// Tests to make sure that two non-empty array lists can be concatenated and
// will yield the expected result.
void simple_concatenate() {
    char char_arr[3] = {'a', 'b', 'c'};
    CharLinkedList list = CharLinkedList(char_arr, 3);
    char char_arr_two[3] = {'x', 'y', 'z'};
    CharLinkedList list_two = CharLinkedList(char_arr_two, 3);
    list.concatenate(&list_two);
    assert(list.size() == 6);
    assert(list_two.size() == 3);
    assert(list.elementAt(0) == 'a');
    assert(list.elementAt(4) == 'y');
    assert(list.toString() == "[CharLinkedList of size 6 <<abcxyz>>]");
}

// Tests to make sure that an empty array list can be concatenated with a 
// non-empty array list and the result will be the non-empty array list.
void front_empty_concatenate() {
    CharLinkedList list;
    char char_arr_two[3] = {'x', 'y', 'z'};
    CharLinkedList list_two = CharLinkedList(char_arr_two, 3);
    list.concatenate(&list_two);
    assert(list.size() == 3);
    assert(list.toString() == "[CharLinkedList of size 3 <<xyz>>]");
}

// Tests to make sure that a non-empty array list can be concatenated with 
// an empty array list and the result will be the non-empty array list.
void back_empty_concatenate() {
    char char_arr[3] = {'x', 'y', 'z'};
    CharLinkedList list = CharLinkedList(char_arr, 3);
    CharLinkedList list_two;
    list.concatenate(&list_two);
    assert(list.size() == 3);
    assert(list.toString() == "[CharLinkedList of size 3 <<xyz>>]");
}


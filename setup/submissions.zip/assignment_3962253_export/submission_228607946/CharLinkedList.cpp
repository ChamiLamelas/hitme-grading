/*
 *  CharLinkedList.cpp
 *  Eli Newman
 *  1/31/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Implements the CharLinkedList class
 *
 */

#include "CharLinkedList.h"

/*
NAME: CharLinkedList
PURPOSE: Constructs an empty linked list
ARGUMENTS: None
RETURNS: None
EFFECTS: Creates an empty linked list.
*/
CharLinkedList::CharLinkedList() {
    front = nullptr;
    length = 0;
}

/*
NAME: CharLinkedList
PURPOSE: Constructs a linked list with one character in it
ARGUMENTS: The character to put in the linked list
RETURNS: None
EFFECTS: A linked list is created with one character in it
*/
CharLinkedList::CharLinkedList(char c) {
    Node *new_node = new Node();
    new_node -> data = c;
    new_node -> before = nullptr;
    new_node -> next = nullptr;

    front = new_node;
    length = 1;
}

/*
NAME: nodes_maker
PURPOSE: Constructs a linked set of empty nodes.
ARGUMENTS: The number of nodes to be in the set and the current node that
the function is making.
RETURNS: A node to the front of the set of linked nodes
EFFECTS: A linked set of empty nodes is made
*/
CharLinkedList::Node *CharLinkedList::nodes_maker(int target, int curr) {
    if (curr == target) {
        Node *base_node = new Node();
        base_node -> next = nullptr;
        return base_node;
    }
    else {
        Node *recursive_node = new Node();
        recursive_node -> next = nodes_maker(target, curr + 1);
        return recursive_node;
    }
}

/*
NAME: before_populator
PURPOSE: Populates the "before" field of the linked set of empty nodes
ARGUMENTS: None
RETURNS: None
EFFECTS: Nodes can be traversed in reverse now
*/
void CharLinkedList::before_populator() {
    front -> before = nullptr;
    for (int i = 1; i < length; i++) {
        recursive_node_mover(i, 0, front) -> before = 
        recursive_node_mover(i - 1, 0, front);
    }
}


/*
NAME: CharLinkedList
PURPOSE: Constructs a linked list with several characters in it
ARGUMENTS: An array of characters to put in the linked list
RETURNS: None
EFFECTS: A linked list is created with several characters in it
*/
CharLinkedList::CharLinkedList(char arr[], int size) {
    length = size;
    front = nodes_maker(size - 1, 0);
    before_populator();
    for (int i = 0; i < size; i++) {
        recursive_node_mover(i, 0, front) -> data = arr[i];
    }
}

/*
NAME: CharLinkedList
PURPOSE: Constructs a linked list by copying a linked list
ARGUMENTS: The linked list to be copied
RETURNS: None
EFFECTS: A linked list is created that is a copy of another linked list
*/
CharLinkedList::CharLinkedList(const CharLinkedList &other) {
    length = other.size();
    front = nodes_maker(length - 1, 0);
    before_populator();
    for (int i = 0; i < length; i++) {
        recursive_node_mover(i, 0, front) -> data = other.elementAt(i);
    }
}

/*
NAME: CharLinkedList &operator
PURPOSE: Sets one linked list equal to another linked list
ARGUMENTS: The linked list to be copied
RETURNS: None
EFFECTS: A linked list is set to be another linked list
*/
CharLinkedList& CharLinkedList::operator=(const CharLinkedList &other) {
    length = other.size();
    front = nodes_maker(length - 1, 0);
    before_populator();
    for (int i = 0; i < length; i++) {
        recursive_node_mover(i, 0, front) -> data = other.elementAt(i);
    }
    return *this;
}

/*
NAME: recursive_delete
PURPOSE: A recursive function that deletes each node in the linked list
ARGUMENTS: The node that will be deleted by the function
RETURNS: None
EFFECTS: The nodes of the linked list are deleted
*/
void CharLinkedList::recursive_delete(Node *deleted) const {
    if (deleted -> next == nullptr) {
        delete deleted;
        return;
    }
    else {
        recursive_delete(deleted -> next);
        delete deleted;
        return;
    }
}

/*
NAME: ~CharLinkedList
PURPOSE: Deletes a linked list from memory
ARGUMENTS: None
RETURNS: None
EFFECTS: The linked list is deleted
*/
CharLinkedList::~CharLinkedList() {
    if (front == nullptr) {
        return;
    }
    recursive_delete(front);
}

/*
NAME: isEmpty
PURPOSE: Determines whether the linked list is empty or not
ARGUMENTS: None
RETURNS: True if the list is empty and false if it isn't empty.
EFFECTS: None
*/
bool CharLinkedList::isEmpty() const {
    if (length == 0) {
        return true;
    } else {
        return false;
    }
}

/*
NAME: first
PURPOSE: Gets the first character in the list
ARGUMENTS: None
RETURNS: The first character in the linked list
EFFECTS: None
*/
char CharLinkedList::first() const {
    if(front != nullptr) {
        return front -> data;
    }
    else {
        throw std::runtime_error("cannot get first of empty LinkedList");
    }
}

/*
NAME: recursive_node_mover
PURPOSE: Recursively moves to a node in the linked list determined by an index
ARGUMENTS: The index of the node being moved to, the current index, and the
node at the current index
RETURNS: The node at the index
EFFECTS: None
*/
CharLinkedList::Node *CharLinkedList::recursive_node_mover(int target, 
int current, Node *recursive_node) const{
    if (current == target) {
        return recursive_node;
    } else {
        return recursive_node_mover(target, current + 1, 
        recursive_node -> next);
    }
}

/*
NAME: last
PURPOSE: Returns the last character in the list.
ARGUMENTS: None
RETURNS: The last character in the list
EFFECTS: None
*/
char CharLinkedList::last() const {
    if (front != nullptr) {
        return recursive_node_mover(length - 1, 0, front) -> data;
    } else {
        throw std::runtime_error("cannot get last of empty LinkedList");
    }
}

/*
NAME: elementAt
PURPOSE: Returns the character at a given index.
ARGUMENTS: The index of the node
RETURNS: The character at a certain index
EFFECTS: None
*/
char CharLinkedList::elementAt(int index) const {
    if (index >= 0 and index < length and front != nullptr) {
        return recursive_node_mover(index, 0, front) -> data;
    } else {
        throw std::range_error("index (" + std::to_string(index) + 
        ") not in range [0.." + std::to_string(length) + ")");
    }
}

/*
NAME: clear
PURPOSE: Erases all of the data and nodes in the list
ARGUMENTS: None
RETURNS: None
EFFECTS: The list becomes empty
*/
void CharLinkedList::clear() {
    if (front == nullptr) {
        return;
    }
    recursive_delete(front);
    front = nullptr;
    length = 0;
}

/*
NAME: size
PURPOSE: Returns the length of the list
ARGUMENTS: None
RETURNS: the length of the list
EFFECTS: None
*/
int CharLinkedList::size() const {
    return length;
}

/*
NAME: toString
PURPOSE: Returns a string of character in the list
ARGUMENTS: None
RETURNS: a string of characters in the list
EFFECTS: None
*/
std::string CharLinkedList::toString() const {
    std::string contents = "";
    for (int i = 0; i < length; i++) {
        contents += recursive_node_mover(i, 0, front) -> data;
    }
    return "[CharLinkedList of size " + std::to_string(length) +
    " <<" + contents + ">>]";
}

/*
NAME: toReverseString
PURPOSE: Returns a string of character in the list in reverse order
ARGUMENTS: None
RETURNS: a string of characters in the list in reverse order
EFFECTS: None
*/
std::string CharLinkedList::toReverseString() const {
    std::string contents = "";
    for (int i = 1; i < length + 1; i++)
    {
        contents += recursive_node_mover(length - i, 0, front) -> data;
    }
    return "[CharLinkedList of size " + std::to_string(length) +
    " <<" + contents + ">>]";
}

/*
NAME: pushAtBack
PURPOSE: Adds a character to the end of the list
ARGUMENTS: A character 'c'
RETURNS: None
EFFECTS: The list has one more character in the back
*/
void CharLinkedList::pushAtBack(char c) {
    if (front == nullptr) {
        front = nodes_maker(0, 0);
        front -> before = nullptr;
        front -> next = nullptr;
        front -> data = c;
        length++;
    } else {
        Node *new_node = new Node();
        new_node -> before = recursive_node_mover(length - 1, 0, front);
        recursive_node_mover(length - 1, 0, front) -> next = new_node;
        new_node -> data = c;
        length++;
    }
}

/*
NAME: pushAtFront
PURPOSE: Adds a character to the front of the list
ARGUMENTS: A character 'c'
RETURNS: None
EFFECTS: The list has one more character in the front
*/
void CharLinkedList::pushAtFront(char c) {
    if (front == nullptr) {
       front = nodes_maker(0, 0);
        front -> before = nullptr;
        front -> next = nullptr;
        front -> data = c;
        length++; 
    } else {
        Node *new_node = new Node();
        new_node -> next = front;
        front -> before = new_node;
        front = new_node;
        front -> before = nullptr;
        front -> data = c;
        length++;
    }
}

/*
NAME: node_inserter
PURPOSE: Inserts a node into an index in the list and all other nodes are
shifted back accordingly
ARGUMENTS: The index of insertion
RETURNS: None
EFFECTS: The list has one more empty node in it at an index
*/
void CharLinkedList::node_inserter(int index) {
    Node *new_node = new Node();
    if (index == 0) {
        new_node -> next = front;
        front -> before = new_node;
        new_node -> before = nullptr;
        front = new_node;
    } else if (index == length) {
        new_node -> next = recursive_node_mover(index, 0, front);
        recursive_node_mover(index - 1, 0, front) -> next = new_node;
        new_node -> before = recursive_node_mover(index - 1, 0, front);
    } else {
        new_node -> next = recursive_node_mover(index, 0, front);
        recursive_node_mover(index - 1, 0, front) -> next = new_node;
        new_node -> before = recursive_node_mover(index - 1, 0, front);
        recursive_node_mover(index + 1, 0, front) -> before = new_node;
    }
    length++;
}

/*
NAME: insertAt
PURPOSE: Adds a character at an index in the list
ARGUMENTS: A character 'c' and an index
RETURNS: None
EFFECTS: The list has one more character at an index in the list
*/
void CharLinkedList::insertAt(char c, int index) {
    if (index < 0 or index > length) {
         throw std::range_error("index (" + std::to_string(index) + 
        ") not in range [0.." + std::to_string(length) + "]");
    } else {
        if (front == nullptr) {
            front = nodes_maker(0,0);
            front -> before = nullptr;
            front -> next = nullptr;
            front -> data = c;
            length++;
        } else {
            node_inserter(index);
            recursive_node_mover(index, 0, front) -> data = c;
        }

    }
}

/*
NAME: insertInOrder
PURPOSE: Adds a character in alphabetical order to the list
ARGUMENTS: A character 'c'
RETURNS: None
EFFECTS: The list has another character inserted alphabetically
*/
void CharLinkedList::insertInOrder(char c) {
    for (int i = 0; i < length; i++) {
        if (recursive_node_mover(i, 0, front) -> data > c) {
            insertAt(c, i);
            return;
        }
    }
    pushAtBack(c);
}

/*
NAME: popFromFront
PURPOSE: Removes a character from the front of the list
ARGUMENTS: None
RETURNS: None
EFFECTS: The list has one less character in the front
*/
void CharLinkedList::popFromFront() {
    if (length == 0) {
        throw std::runtime_error("cannot pop from empty LinkedList");
    } else if (length == 1) {
        delete front;
        front = nullptr;
        length--;
    } else {
        front = recursive_node_mover(1, 0, front);
        delete front -> before;
        front -> before = nullptr;
        length--;
    }
}

/*
NAME: popFromBack
PURPOSE: Removes a character from the back of the list
ARGUMENTS: None
RETURNS: None
EFFECTS: The list has one less character in the back
*/
void CharLinkedList::popFromBack() {
    if (length == 0) {
        throw std::runtime_error("cannot pop from empty LinkedList");
    } else if (length == 1) {
        delete front;
        front = nullptr;
        length--;
    } else {
        delete recursive_node_mover(length - 1, 0, front);
        recursive_node_mover(length - 2, 0, front) -> next = nullptr;
        length--;
    }
}

/*
NAME: node_remover
PURPOSE: Removes a node at a certain index
ARGUMENTS: The index of the node to be removed
RETURNS: None
EFFECTS: The list has one less node in it
*/
void CharLinkedList::node_remover(int index) {
    recursive_node_mover(index - 1, 0, front) -> next = 
    recursive_node_mover(index + 1, 0, front);

    delete recursive_node_mover(index, 0, front) -> before;

    recursive_node_mover(index, 0, front) -> before = 
    recursive_node_mover(index - 1, 0, front);
}

/*
NAME: removeAt
PURPOSE: Removes a character from the list
ARGUMENTS: The index of the node to be removed
RETURNS: None
EFFECTS: The list has one less character in it at a certain index
*/
void CharLinkedList::removeAt(int index) {
    if (index >= length or index < 0 or length == 0) {
        throw std::range_error("index (" + std::to_string(index) + 
        ") not in range [0.." + std::to_string(length) + ")");
    }
    if (index == 0) {
        popFromFront();
        return;
    }
    if (index == length - 1) {
        popFromBack();
        return;
    }

    node_remover(index);
    length--;
}

/*
NAME: replaceAt
PURPOSE: Replaces a character with another character at a certain index
ARGUMENTS: The index of the node to be removed and the character to be put in
RETURNS: None
EFFECTS: The list has one different character in it
*/
void CharLinkedList::replaceAt(char c, int index) {
    if (index >= length or index < 0 or length == 0) {
        throw std::range_error("index (" + std::to_string(index) + 
        ") not in range [0.." + std::to_string(length) + ")");
    }
    recursive_node_mover(index, 0, front) -> data = c;
}

/*
NAME: concatenate
PURPOSE: Concatenates two linked lists
ARGUMENTS: The link list to append
RETURNS: None
EFFECTS: The list has another list appended to its back
*/
void CharLinkedList::concatenate(CharLinkedList *other) {
    if (length == 0) {
        length = other -> size();
        front = nodes_maker(length - 1, 0);
        before_populator();
        for (int i = 0; i < length; i++) {
            recursive_node_mover(i, 0, front) -> data = other -> elementAt(i);
        }
        return;
    }
    if (other -> size() == 0) {
        return;
    }
    for (int i = 0; i < other -> size(); i++) {
        pushAtBack(other -> elementAt(i));
    }
}

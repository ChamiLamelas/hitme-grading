/*
 *  unit_tests.h
 *  YOUR NAME HERE
 *  DATE CREATED
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  FILE PURPOSE HERE
 *
 */

#include "CharLinkedList.h"
#include <cassert>

//empty list creation
void create_lists_empty(){
    CharLinkedList test1;

    assert(test1.size() == 0);

    CharLinkedList test2;

    assert(test2.size() == 0);
}
//singleton list creation
void create_lists_singleton(){
    CharLinkedList test1('a');

    assert(test1.size() == 1);
    assert(test1.elementAt(0) == 'a');

    CharLinkedList test2('b');

    assert(test2.size() == 1);
    assert(test2.elementAt(0) == 'b');
}
//list creation using empty array
void create_lists_with_arr_empty(){
    char test_list[0] = {};
    CharLinkedList test1(test_list, 0);

    assert(test1.size() == 0);

    bool range_error_thrown = false;

    std::string error_message = "";

    char testElemAt;
    try {
    testElemAt = test1.elementAt(0);
    }
    catch (const std::range_error &e) {
    range_error_thrown = true;
    error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (0) not in range [0..0)");
    
}
//list creation using empy linked list
void create_lists_with_linked_list_empty(){
    char test_list[0] = {};
    CharLinkedList test1(test_list, 0);

    CharLinkedList test2(test1);

    assert(test2.size() == 0);

    bool range_error_thrown = false;

    std::string error_message = "";

    char testElemAt;
    try {
    testElemAt = test2.elementAt(0);
    }
    catch (const std::range_error &e) {
    range_error_thrown = true;
    error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (0) not in range [0..0)");
}
//list creation with populated linked list
void create_lists_with_linked_list_full(){
    char test_list[9] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i' };
    CharLinkedList test1(test_list, 9);

    CharLinkedList test2(test1);

    assert(test2.size() == 9);

    bool range_error_thrown = false;

    std::string error_message = "";

    char testElemAt;
    try {
    testElemAt = test2.elementAt(10);
    }
    catch (const std::range_error &e) {
    range_error_thrown = true;
    error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (10) not in range [0..9)");
}
//linked list equals self
void equals_op_itself(){
    char test_list[9] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i' };
    CharLinkedList test1(test_list, 9);

    test1 = test1;

    assert(test1.size() == 9);
    assert(test1.elementAt(0) == 'a');
    assert(test1.elementAt(5) == 'f');
    assert(test1.elementAt(8) == 'i');
    assert(test1.toString() == "[CharLinkedList of size 9 <<abcdefghi>>]");
}
//linked list equals other list
void equals_op_other(){
    char test_list[9] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i' };
    CharLinkedList test1(test_list, 9);

    char test_list2[1] = {'a'};
    CharLinkedList test2(test_list2, 1);

    test1 = test2;

    assert(test1.size() == 1);
    assert(test1.elementAt(0) == 'a');
    assert(test1.toString() == "[CharLinkedList of size 1 <<a>>]");
}
//element at test at beginning of list
void element_at_test_beginning(){
    char test_list[9] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i' };
    CharLinkedList test1(test_list, 9);

    assert(test1.elementAt(0) == 'a');
}
//element at test at middle of list
void element_at_test_mid(){
    char test_list[9] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i' };
    CharLinkedList test1(test_list, 9);
    assert(test1.elementAt(5) == 'f');
}
//element at test at end of list
void element_at_test_end(){
    char test_list[9] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i' };
    CharLinkedList test1(test_list, 9);

    assert(test1.elementAt(8) == 'i');
}
//element at test when index is out of bounds
void element_at_edge(){
    char test_list[9] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i' };
    CharLinkedList test1(test_list, 9);

    bool range_error_thrown = false;

    std::string error_message = "";

    char testElemAt;
    try {
    testElemAt = test1.elementAt(9);
    }
    catch (const std::range_error &e) {
    range_error_thrown = true;
    error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (9) not in range [0..9)");
}
//element at test when index is out of bounds and negative
void element_at_edge_below(){
    char test_list[9] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i' };
    CharLinkedList test1(test_list, 9);

    bool range_error_thrown = false;

    std::string error_message = "";

    char testElemAt;
    try {
    testElemAt = test1.elementAt(-1);
    }
    catch (const std::range_error &e) {
    range_error_thrown = true;
    error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (-1) not in range [0..9)");
}
//convert linked list to string when empty
void toString_none(){
    CharLinkedList test1;

    assert(test1.toString() == "[CharLinkedList of size 0 <<>>]");
}
//convert linked list to string
void toString_long(){
    char test_list[9] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i' };
    CharLinkedList test1(test_list, 9);

    assert(test1.toString() == "[CharLinkedList of size 9 <<abcdefghi>>]");
}
//convert empty linked list to string and reverse order
void toRevString_none(){
    CharLinkedList test1;

    assert(test1.toReverseString() == "[CharLinkedList of size 0 <<>>]");
}
//convert linked list to string and reverse order
void toRevString_long(){
    char test_list[9] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i' };
    CharLinkedList test1(test_list, 9);

    assert(test1.toReverseString() == 
    "[CharLinkedList of size 9 <<ihgfedcba>>]");
}
//first element in empty linked list (error)
void firstTest_none(){
    CharLinkedList test1;

    bool runtime_error_thrown = false;

    std::string error_message = "";

    char testElemAt;
    try {
    testElemAt = test1.first();
    }
    catch (const std::runtime_error &e) {
    runtime_error_thrown = true;
    error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot get first of empty LinkedList");
}
//first element in linked list
void firstTest_full(){
    char test_list[9] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i' };
    CharLinkedList test1(test_list, 9);

    assert(test1.first() == 'a');
}
//last element in empty linked list (error)
void lastTest_none(){
    CharLinkedList test1;

    bool runtime_error_thrown = false;

    std::string error_message = "";

    char testElemAt;
    try {
    testElemAt = test1.last();
    }
    catch (const std::runtime_error &e) {
    runtime_error_thrown = true;
    error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot get last of empty LinkedList");
}
//last element in full linked list
void lastTest_full(){
    char test_list[9] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i' };
    CharLinkedList test1(test_list, 9);

    assert(test1.last() == 'i');
}
//add element to end of empty linked list
void pushBackTest_empty(){
    CharLinkedList test1;
    test1.pushAtBack('z');

    assert(test1.elementAt(0) == 'z');
    assert(test1.size() == 1);
}
//add element to end of populated linked list
void pushBackTest_full(){
    char test_list[9] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i' };
    CharLinkedList test1(test_list, 9);

    test1.pushAtBack('z');

    assert(test1.elementAt(9) == 'z');
    assert(test1.size() == 10);
}
//add element to front of empty linked list
void pushFrontTest_empty(){
    CharLinkedList test1;
    test1.pushAtFront('z');

    assert(test1.elementAt(0) == 'z');
    assert(test1.size() == 1);
}
//add element to front of populated linked list
void pushFrontTest_full(){
    char test_list[9] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i' };
    CharLinkedList test1(test_list, 9);

    test1.pushAtFront('z');

    assert(test1.elementAt(0) == 'z');
    assert(test1.size() == 10);

    assert(test1.toString() == "[CharLinkedList of size 10 <<zabcdefghi>>]");
}
//insert element to empty linked list
void insert_empty(){
    CharLinkedList test1;
    test1.insertAt('z', 0);

    assert(test1.elementAt(0) == 'z');
    assert(test1.size() == 1);
}
//insert element to beginning of linked list
void insertFull_beg(){
    char test_list[9] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i' };
    CharLinkedList test1(test_list, 9);
    test1.insertAt('z', 0);
    
    assert(test1.elementAt(0) == 'z');
    assert(test1.size() == 10);
    assert(test1.toString() == "[CharLinkedList of size 10 <<zabcdefghi>>]");
    assert(test1.toReverseString() == 
    "[CharLinkedList of size 10 <<ihgfedcbaz>>]");
}
//insert element to middle of linked list
void insertFull_mid(){
    char test_list[9] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i' };
    CharLinkedList test1(test_list, 9);
    test1.insertAt('z', 4);
    
    assert(test1.elementAt(4) == 'z');
    assert(test1.size() == 10);
    assert(test1.toString() == "[CharLinkedList of size 10 <<abcdzefghi>>]");
    assert(test1.toReverseString() == 
    "[CharLinkedList of size 10 <<ihgfezdcba>>]");
}
//insert element to end of linked list
void insertFull_end(){
    char test_list[9] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i' };
    CharLinkedList test1(test_list, 9);
    test1.insertAt('z', 9);
    
    assert(test1.elementAt(9) == 'z');
    assert(test1.size() == 10);
    assert(test1.toString() == "[CharLinkedList of size 10 <<abcdefghiz>>]");
    assert(test1.toReverseString() == 
    "[CharLinkedList of size 10 <<zihgfedcba>>]");
}
//insert element to out of bounds index
void insertFull_edge(){
    char test_list[9] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i' };
    CharLinkedList test1(test_list, 9);
    
    bool range_error_thrown = false;

    std::string error_message = "";

    try {
        test1.insertAt('z', 10);
    }
        catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (10) not in range [0..9]");
}
//insert in order element to empty linked list
void insertInOrder_empty(){
    CharLinkedList test1;
    test1.insertInOrder('z');

    assert(test1.elementAt(0) == 'z');
    assert(test1.size() == 1);
}
//insert in order element to linked list at back
void insertInOrder_full_back(){
    char test_list[9] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i' };
    CharLinkedList test1(test_list, 9);

    test1.insertInOrder('z');

    assert(test1.elementAt(9) == 'z');
    assert(test1.size() == 10);
    assert(test1.toString() == "[CharLinkedList of size 10 <<abcdefghiz>>]");
}
//insert in order element to linked list at middle
void insertInOrder_full_mid(){
    char test_list[9] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i' };
    CharLinkedList test1(test_list, 9);

    test1.insertInOrder('b');

    assert(test1.elementAt(1) == 'b');
    assert(test1.elementAt(2) == 'b');
    assert(test1.size() == 10);
    assert(test1.toString() == "[CharLinkedList of size 10 <<abbcdefghi>>]");
}
//insert in order element to front of  linked list
void insertInOrder_full_front(){
    char test_list[9] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i' };
    CharLinkedList test1(test_list, 9);

    test1.insertInOrder('a');

    assert(test1.elementAt(0) == 'a');
    assert(test1.elementAt(1) == 'a');
    assert(test1.size() == 10);
    assert(test1.toString() == "[CharLinkedList of size 10 <<aabcdefghi>>]");
}
//insert in order when many repeating, out of order letters
void insertInOrder_full_repeats(){
    char test_list[9] = { 'a', 'c', 'b', 'c', 'c', 'h', 'z', 'h', 'i' };
    CharLinkedList test1(test_list, 9);

    test1.insertInOrder('f');

    assert(test1.elementAt(5) == 'f');
    assert(test1.elementAt(6) == 'h');
    assert(test1.size() == 10);
    assert(test1.toString() == "[CharLinkedList of size 10 <<acbccfhzhi>>]");
}
//remove from singleton
void remove_singleton(){
    CharLinkedList test1;
    test1.insertInOrder('a');

    assert(test1.elementAt(0) == 'a');
    assert(test1.size() == 1);

    test1.removeAt(0);
    assert(test1.size() == 0);
}
//remove from front in long list
void remove_longer_front(){
    char test_list[9] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i' };
    CharLinkedList test1(test_list, 9);

    test1.removeAt(0);
    assert(test1.size() == 8);
    test1.removeAt(0);
    assert(test1.size() == 7);
    test1.removeAt(0);
    assert(test1.size() == 6);
    test1.removeAt(0);
    assert(test1.size() == 5);

    std::cout << test1.toString() << std::endl;
    assert(test1.toString() == "[CharLinkedList of size 5 <<efghi>>]");
}
//remove from back in long list
void remove_longer_back(){
    char test_list[9] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i' };
    CharLinkedList test1(test_list, 9);

    test1.removeAt(8);
    assert(test1.size() == 8);
    test1.removeAt(7);
    assert(test1.size() == 7);
    test1.removeAt(6);
    assert(test1.size() == 6);
    test1.removeAt(5);
    assert(test1.size() == 5);

    assert(test1.toString() == "[CharLinkedList of size 5 <<abcde>>]");
}
//remove from middle in long list
void remove_longer_mid_rep(){
    char test_list[9] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i' };
    CharLinkedList test1(test_list, 9);

    test1.removeAt(4);
    assert(test1.size() == 8);
    test1.removeAt(4);
    assert(test1.size() == 7);
    test1.removeAt(4);
    assert(test1.size() == 6);
    test1.removeAt(4);
    assert(test1.size() == 5);

    assert(test1.toString() == "[CharLinkedList of size 5 <<abcdi>>]");
}
//remove from front in long list
void remove_longer_mid_dif(){
    char test_list[9] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i' };
    CharLinkedList test1(test_list, 9);

    test1.removeAt(2);
    assert(test1.size() == 8);
    test1.removeAt(4);
    assert(test1.size() == 7);
    test1.removeAt(6);
    assert(test1.size() == 6);
    test1.removeAt(5);
    assert(test1.size() == 5);
    test1.removeAt(1);
    assert(test1.size() == 4);

    assert(test1.toString() == "[CharLinkedList of size 4 <<adeg>>]");
}
//remove from front
void popFrontSingle(){
    char test_list[9] = {'a'};
    CharLinkedList test1(test_list, 1);

    test1.popFromFront();
    assert(test1.size() == 0);
}
//remove from front in long list many times
void popFrontMany(){
    char test_list[9] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i' };
    CharLinkedList test1(test_list, 9);

    test1.popFromFront();
    test1.popFromFront();
    test1.popFromFront();

    assert(test1.size() == 6);
    assert(test1.toString() == "[CharLinkedList of size 6 <<defghi>>]");
}
//pop front edge
void popFrontEmpty(){
    CharLinkedList test1;

    bool runtime_error_thrown = false;

    std::string error_message = "";

    try {
        test1.popFromFront();
    }
        catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}
//pop back edge
void popBackEmpty(){
    CharLinkedList test1;

    bool runtime_error_thrown = false;

    std::string error_message = "";

    try {
        test1.popFromBack();
    }
        catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}
//remove from back in long list
void popBackSingle(){
    char test_list[9] = {'a'};
    CharLinkedList test1(test_list, 1);

    test1.popFromBack();
    assert(test1.size() == 0);
}
//remove from back in long list many times
void popBackMany(){
    char test_list[9] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i' };
    CharLinkedList test1(test_list, 9);

    test1.popFromBack();
    test1.popFromBack();
    test1.popFromBack();

    assert(test1.size() == 6);
    assert(test1.toString() == "[CharLinkedList of size 6 <<abcdef>>]");
}
//remove element out of bounds
void removeAtEdgeLongList(){
    char test_list[9] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i' };
    CharLinkedList test1(test_list, 9);

    bool range_error_thrown = false;

    std::string error_message = "";

    try {
        test1.removeAt(10);
    }
        catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (10) not in range [0..9)");
}
//remove from out of bounds short list
void removeAtEdgeShortList(){
    char test_list[9] = {'a'};
    CharLinkedList test1(test_list, 1);

    bool range_error_thrown = false;

    std::string error_message = "";

    try {
        test1.removeAt(-5);
    }
        catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (-5) not in range [0..1)");
}
//remove from out of bounds empty list
void removeAtEdgeEmpty(){
    CharLinkedList test1;

    bool range_error_thrown = false;

    std::string error_message = "";

    try {
        test1.removeAt(0);
    }
        catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (0) not in range [0..0)");
}
//replace singleton
void replaceAtSingleton(){
    CharLinkedList test1('a');

    test1.replaceAt('b', 0);
    assert(test1.size() == 1);
    assert(test1.elementAt(0) == 'b');
}
//replace element in long list at front
void replaceAtLongFront(){
    char test_list[9] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i' };
    CharLinkedList test1(test_list, 9);

    test1.replaceAt('b', 0);
    assert(test1.size() == 9);
    assert(test1.elementAt(0) == 'b');
    assert(test1.toString() == "[CharLinkedList of size 9 <<bbcdefghi>>]");
}
//replace element in long list at back
void replaceAtLongBack(){
    char test_list[9] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i' };
    CharLinkedList test1(test_list, 9);

    test1.replaceAt('b', 8);
    assert(test1.size() == 9);
    assert(test1.elementAt(8) == 'b');
    assert(test1.toString() == "[CharLinkedList of size 9 <<abcdefghb>>]");
}
//replace element in long list at middle
void replaceAtLongMid(){
    char test_list[9] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i' };
    CharLinkedList test1(test_list, 9);

    test1.replaceAt('b', 6);
    assert(test1.size() == 9);
    assert(test1.elementAt(6) == 'b');
    assert(test1.toString() == "[CharLinkedList of size 9 <<abcdefbhi>>]");
}
//replace element out of bounds
void replaceAtLongEdge(){
    char test_list[9] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i' };
    CharLinkedList test1(test_list, 9);

    bool range_error_thrown = false;

    std::string error_message = "";

    try {
        test1.replaceAt('b', 30);
    }
        catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (30) not in range [0..9)");
}
//replace element out of bounds in short list
void replaceAtShortEdge(){
    char test_list[1] = {'a'};
    CharLinkedList test1(test_list, 1);

    bool range_error_thrown = false;

    std::string error_message = "";

    try {
        test1.replaceAt('b', 1);
    }
        catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (1) not in range [0..1)");
}
//concatenate two long lists
void concatLongOther(){
    char test_list[9] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i' };
    CharLinkedList test1(test_list, 9);

    char test_list2[9] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i' };
    CharLinkedList test2(test_list2, 9);

    test1.concatenate(&test2);

    assert(test1.size() == 18);
    assert(test1.toString() == 
    "[CharLinkedList of size 18 <<abcdefghiabcdefghi>>]");
}
//concatenate two short lists
void concatShortOther(){
    char test_list[1] = {'a'};
    CharLinkedList test1(test_list, 1);

    char test_list2[1] = {'b'};
    CharLinkedList test2(test_list2, 1);

    test1.concatenate(&test2);

    assert(test1.size() == 2);
    assert(test1.toString() == "[CharLinkedList of size 2 <<ab>>]");
}

void cleartest(){
    char test_list[9] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i' };
    CharLinkedList test1(test_list, 9);

    test1.clear();
    assert(test1.size() == 0);
    assert(test1.toString() == "[CharLinkedList of size 0 <<>>]");
}

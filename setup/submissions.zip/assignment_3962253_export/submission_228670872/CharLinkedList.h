/*
 *  CharLinkedList.h
 *  Massimo Bottari
 *  2/3/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  CharLinkedList.h represents a list doubly linked list. The linked list
 * has a variety of features that facilitate organization of data linearly
 *
 */

#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H
#include <string>
#include <stdexcept>
#include <iostream>

class CharLinkedList {
    public:
        CharLinkedList();
        CharLinkedList(char c);
        CharLinkedList(char arr[], int size);
        CharLinkedList(const CharLinkedList &other);

        ~CharLinkedList();

        CharLinkedList &operator=(const CharLinkedList &other);
        bool isEmpty() const;
        void clear();
        int size() const;
        char first() const;
        char last() const;
        char elementAt(int index) const;

        std::string toString() const;
        std::string toReverseString() const;

        void pushAtBack(char c);
        void pushAtFront(char c);
        void insertAt(char c, int index);
        void insertInOrder(char c);
        void popFromFront();
        void popFromBack();
        void removeAt(int index);
        void replaceAt(char c, int index);
        void concatenate(CharLinkedList *other);

    private:
        struct Node {
        char info;
        Node *next;
        Node *before;
        };

        Node *front;
        int listSize;

        void deleteNode(Node *nNode);
        char findChar(Node *nNode, int index, int currIndex) const;
        void replaceChar(Node *nNode, int index, int currIndex, 
        char newInfo) const;
};

#endif

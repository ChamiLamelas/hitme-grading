/*
 *  CharLinkedList.cpp
 *  Massimo Bottari
 *  2/3/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  This file contains the implementation of the CharLinkedList class
 *
 */

#include "CharLinkedList.h"
/*
 * name:      CharLinkedList
 * purpose:   create instance of an empty linked list
 * arguments: none
 * returns:   none
 * effects:   sets list size to 0 and makes front a nullptr
 */
CharLinkedList::CharLinkedList(){
    listSize = 0;
    front = nullptr;
}

/*
 * name:      CharLinkedList
 * purpose:   create instance of an singleton linked list
 * arguments: none
 * returns:   none
 * effects:   sets list size to 1, makes front a node containing c
 */
CharLinkedList::CharLinkedList(char c){
    listSize = 0;
    front = nullptr;
    pushAtBack(c);
}
/*
 * name:      CharLinkedList
 * purpose:   create instance of a linked list containing contents of an array
 * arguments: none
 * returns:   none
 * effects:   sets list size to size
 * of array and makes Node for each data point
 */
CharLinkedList::CharLinkedList(char arr[], int size){
    listSize = 0;
    for(int i = 0; i < size; i++){
        pushAtBack(arr[i]);
    }
}
/*
 * name:      CharLinkedList
 * purpose:   create instance of an empty linked list with contents of another
 * linked list
 * arguments: none
 * returns:   none
 * effects:   sets list size to size of other linked list and makes Nodes for
 * each data point in the other linked list
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other){
    listSize = 0;
    for(int i = 0; i < other.size(); i++){
        pushAtBack(other.elementAt(i));
    }
}
/*
 * name:      ~CharLinkedList
 * purpose:   deletes all Nodes in linked list
 * arguments: none
 * returns:   none
 * effects:   clears out data for when program is terminated
 */
CharLinkedList::~CharLinkedList(){
    if(listSize != 0){
        deleteNode(front);
    }
}
/*
 * name:      deleteNode
 * purpose:   assists CharLinkedList
 * arguments: starting Node
 * returns:   none
 * effects:   deletes every Node in linked list recursively
 */
void CharLinkedList::deleteNode(Node *nNode){
    if(nNode->next != nullptr){
        deleteNode(nNode->next);
    }
    
    if(nNode != nullptr){
        delete nNode;
    }
}
/*
 * name:      operator=
 * purpose:   Allows for linked lists to be set to one another using =
 * arguments: linked list that will be copied to linked list on right of =
 * returns:   none
 * effects:   copies contents of linked list to left of = over to linked list
 * right of =
 */
CharLinkedList& CharLinkedList::operator=(const CharLinkedList &other){
    if(this != &other){
        deleteNode(front);
        listSize = 0;

        for(int i = 0; i < other.size(); i++){
            pushAtBack(other.elementAt(i));
        }
    }
    return *this;
}
/*
 * name:      isEmpty
 * purpose:   facilitates determining if linked list is empty or not
 * arguments: none
 * returns:   true or false
 * effects:   Returns value that indicates state of the linked list
 * right of =
 */
bool CharLinkedList::isEmpty() const{
    return (listSize == 0);
}
/*
 * name:      clear
 * purpose:   facilitate removing all data in linked list
 * arguments: none
 * returns:   none
 * effects:   Turns linked list into an empty list
 */
void CharLinkedList::clear(){
    deleteNode(front);
    listSize = 0;
}
/*
 * name:      size
 * purpose:   facilitate finding the size of linked list
 * arguments: none
 * returns:   size of linked list
 * effects:   returns value that indicates the amount of nodes in linked list
 */
int CharLinkedList::size() const{
    return listSize;
}
/*
 * name:      first
 * purpose:   facilitates finding the first data point in linked list
 * arguments: none
 * returns:   info of first node
 * effects:   finds and returns info within the first node in linked list
 */
char CharLinkedList::first() const{
    if(listSize == 0){
        throw std::runtime_error("cannot get first of empty LinkedList");
    }else{
        return front->info;
    }
}
/*
 * name:      last
 * purpose:   facilitates finding the last data point in linked list
 * arguments: none
 * returns:   info of last node
 * effects:   finds and returns info within the last node in linked list
 */
char CharLinkedList::last() const{  
    if(listSize == 0){
        throw std::runtime_error("cannot get last of empty LinkedList");
    }else{
        Node *lastNode = front;
        while(lastNode->next != nullptr){
            lastNode = lastNode->next;
        }
        return lastNode->info;
    }
}
/*
 * name:      elementAt
 * purpose:   facilitates finding any info within a node in a linked list
 * arguments: specified index of node to retrieve data from
 * returns:   info of specified node
 * effects:   finds and returns info within a specified node in linked list
 */
char CharLinkedList::elementAt(int index) const{
    if(index < 0 or index >= listSize){
        throw std::range_error("index (" + std::to_string(index) + 
        ") not in range [0.." + std::to_string(listSize) + ")");
    }

    char selectedChar = findChar(front, index, 0);

    return selectedChar;
}
/*
 * name:      findChar
 * purpose:   facilitates getting access to the specified node from elementAt
 * arguments: current node, specified index, current index at which the pointer
 * has access to
 * returns:   info of specified node
 * effects:   finds and returns info within a specified node in linked list,
 * assists goal of elementAt
 */
char CharLinkedList::findChar(Node *nNode, int index, int currIndex) const{
    if(index != currIndex){
        currIndex++;
        return findChar(nNode->next, index, currIndex);
    }else{
        return nNode->info;
    }
}
/*
 * name:      toString
 * purpose:   facilitates printing the elements of linked list in a concise
 * manner
 * arguments: none
 * returns:   string composed of all chars in linked list
 * effects:   constructs a string by concatenating the chars of linked list
 */
std::string CharLinkedList::toString() const{
    std::string list = "";
    Node *nNode = front;
    for(int i = 0; i < listSize; i++){
        list += nNode->info;
        nNode = nNode->next;
    }
    return "[CharLinkedList of size " + std::to_string(listSize) +
    " <<" + list + ">>]";
}
/*
 * name:      toReverseString
 * purpose:   facilitates printing the elements of linked list in a concise
 * manner in reverse
 * arguments: none
 * returns:   string composed of all chars in linked list in reverse
 * effects:   constructs a string by concatenating the chars of linked list
 * backwards
 */
std::string CharLinkedList::toReverseString() const{
    std::string list = "";
    if(front != nullptr){
        Node *nNode = front;
        while(nNode->next != nullptr){
            nNode = nNode->next;
        }
        for(int i = 0; i < listSize; i++){
            list += nNode->info;
            if(nNode->before != nullptr){
                nNode = nNode->before;
            }else{
            }
        }
    }
    return "[CharLinkedList of size " + std::to_string(listSize) +
    " <<" + list + ">>]";
}
/*
 * name:      pushAtBack
 * purpose:   facilitates adding an element to the end of linked list
 * arguments: specific char to add
 * returns:   none
 * effects:   adds a new node to the end of the linked list and increases its
 * size
 */
void CharLinkedList::pushAtBack(char c){
    Node *newNode = new Node;
    newNode->info = c;
    newNode->next = nullptr;
    newNode->before = nullptr;
    if(listSize == 0){
        front = newNode;
    }else{
        Node *attached = front;
        while(attached->next != nullptr){
            attached = attached->next;
        }
        attached->next = newNode;
        attached->next->before = attached;
    
    }
    listSize++;
}
/*
 * name:      pushAtFront
 * purpose:   facilitates adding an element to the front of linked list
 * arguments: specific char to add
 * returns:   none
 * effects:   adds a new node to the front of the linked list and increases its
 * size
 */
void CharLinkedList::pushAtFront(char c){
    Node *newNode = new Node;
    newNode->info = c;
    newNode->next = front;
    newNode->before = nullptr;

    front = newNode;
    if(listSize != 0){
        front->next->before = front;
    }

    listSize++;
}
/*
 * name:      insertAt
 * purpose:   facilitates adding an element at any index of linked list
 * arguments: specific char to add, index at which to add
 * returns:   none
 * effects:   adds a new node to at any
 * index of the linked list and increases its size, accounts for rerouting
 * of next and before for affected nodes
 */
void CharLinkedList::insertAt(char c, int index){
    if(index < 0 or index > listSize){
        throw std::range_error("index (" + std::to_string(index) + 
        ") not in range [0.." + std::to_string(listSize) + "]");
    }
    if(index == 0){
        pushAtFront(c);
    }else if(index == listSize){
        pushAtBack(c);
    }else{
        Node *newNode = new Node;
        newNode->info = c;

        Node *nNode = front;
        for(int i = 0; i < index; i++){
            nNode = nNode->next;
        }
        newNode->next = nNode;
        newNode->before = nNode->before;
        nNode->before->next = newNode;
        nNode->before = newNode;
        listSize++;
    }
}
/*
 * name:      insertInOrder
 * purpose:   facilitates adding an element in alphabetic order of linked list
 * arguments: specific char to add
 * returns:   none
 * effects:   adds a new node at index where char would be in alphabetic order,
 * accounts for rerouting of next and before for affected nodes
 */
void CharLinkedList::insertInOrder(char c){
    
    if(listSize != 0){
        Node *nNode = front;
        bool inserted = false;
        int count = 0;
        while((count < listSize) and (!inserted)){
            if(c <= nNode->info){
                insertAt(c, count);
                inserted = true;
            }else{
                nNode = nNode->next;
                count++;
            }
        }
        if(!inserted)
            pushAtBack(c);
    }else{
        pushAtBack(c);
    }
}
/*
 * name:      popFromFront
 * purpose:   facilitates removing an element at the front of linked list
 * arguments: none
 * returns:   none
 * effects:   Makes second to first node the front and deletes the original
 * front
 */
void CharLinkedList::popFromFront(){
    if(listSize == 0){
        throw std::runtime_error("cannot pop from empty LinkedList");
    }
    if(listSize == 1){
        delete front;
    }else{
        Node *nNode = front;
        front = front->next;
        front->before = nullptr;
        delete nNode;
    }
    listSize--;
}
/*
 * name:      popFromBack
 * purpose:   facilitates removing an element at the back of linked list
 * arguments: none
 * returns:   none
 * effects:   Makes second to last node the end and deletes the original
 * front
 */
void CharLinkedList::popFromBack(){
    if(listSize == 0){
        throw std::runtime_error("cannot pop from empty LinkedList");
    }
    if(listSize == 1){
        delete front;
    }else{
        Node *nNode = front;
        while(nNode->next != nullptr){
            nNode = nNode->next;
        }
        nNode->before->next = nullptr;
        delete nNode;
    }
    listSize--;
}
/*
 * name:      removeAt
 * purpose:   facilitates removing an element at any index of linked list
 * arguments: index at which to remove
 * returns:   none
 * effects:   Deletes specified node after rerouting before and next of
 * affected adjacent nodes
 * front
 */
void CharLinkedList::removeAt(int index){
    if((index < 0) or (index >= listSize)){
        throw std::range_error("index (" + std::to_string(index) + 
        ") not in range [0.." + std::to_string(listSize) + ")");
    }

    if(index == 0){
        popFromFront();
    }else if(index == listSize - 1){
        popFromBack();
    }else{
        Node *nNode = front;
        for(int i = 0; i < index; i++){
            nNode = nNode->next;
        }
        nNode->before->next = nNode->next;
        nNode->next->before = nNode->before;
        delete nNode;
        listSize--;
    }

}
/*
 * name:      replaceAt
 * purpose:   facilitates replacing the info within a specified node
 * arguments: char that will replace info in node, index of node being replaced
 * returns:   none
 * effects:   exchanges info within specified node to new info from argument
 * front
 */
void CharLinkedList::replaceAt(char c, int index){
    if((index < 0) or (index >= listSize)){
        throw std::range_error("index (" + std::to_string(index) + 
        ") not in range [0.." + std::to_string(listSize) + ")");
    }

    replaceChar(front, index, 0, c);
}
/*
 * name:      replaceChar
 * purpose:   assists replaceAt in the process of finding the specified node
 * arguments: current node, specified index, current index, replacement info
 * returns:   none
 * effects:   finds specified node and replaces old info with new info
 * front
 */
void CharLinkedList::replaceChar(Node *nNode, int index, int currIndex,
char newInfo) const{
    if(index != currIndex){
        replaceChar(nNode->next, index, currIndex + 1, newInfo);
    }else{
        nNode->info = newInfo;
        return;
    }
}
/*
 * name:      concatenate
 * purpose:   facilitates process of taking contents of one list and adding
 * the contents to another list
 * arguments: linked list
 * returns:   none
 * effects:   appends contents of list from argument to list that this function
 * was called on
 */
void CharLinkedList::concatenate(CharLinkedList *other){
    int concatSize = other->size();
    for(int i = 0; i < concatSize; i++){
        this->pushAtBack(other->elementAt(i));
    }
}

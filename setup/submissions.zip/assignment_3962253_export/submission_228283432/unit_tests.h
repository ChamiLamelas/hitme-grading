/*
 *  unit_tests.h
 *  Jean Pascal Cyusa Shyaka
 *  Feb 4, 2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  Different tests for the CharLinkedList class methods
 *
 */

#include <cassert>
#include <iostream>

#include "CharLinkedList.h"

// tests first constructor
void constructor1Test() {
    CharLinkedList a = CharLinkedList();
    assert(a.isEmpty());
}

// tests second constructor
void constructor2Test() {
    CharLinkedList a = CharLinkedList('a');
    assert(not a.isEmpty());
}

// tests third constructor
void constructor3Test() {
    char arr[] = {'a', 'b', 'c'};
    CharLinkedList a = CharLinkedList(arr, 3);
    assert(not a.isEmpty());
}

// tests fourth constructor
void constructor4Test() {
    CharLinkedList a = CharLinkedList('a');
    CharLinkedList b = CharLinkedList(a);
    assert(not b.isEmpty());
}

// tests destructor by checking if the list is empty
void destructorTest() {
    CharLinkedList a = CharLinkedList('a');
    a.~CharLinkedList();
    assert(a.isEmpty());
}

void assignmentOperatorTest() {
    CharLinkedList a = CharLinkedList('a');
    CharLinkedList b = CharLinkedList('b');
    b = a;
    assert(not b.isEmpty());
}

// Test for correct insertion into an empty linked list.
void insertAt_empty_correct() {
    CharLinkedList test_list;
    test_list.insertAt('a', 0);

    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');
}

void insertAt_out_of_range_index() {
    CharLinkedList test_list;
    test_list.pushAtBack('a');

    try {
        test_list.insertAt('b', 2);
    } catch (const std::range_error& e) {
        assert(true);
        return;
    }

    assert(false);
}

void pushAtBack_multiple_elements() {
    CharLinkedList test_list;
    test_list.pushAtBack('a');
    test_list.pushAtBack('b');
    test_list.pushAtBack('c');

    assert(test_list.size() == 3);
    assert(test_list.last() == 'c');
}

// Test for removing elements from the front of the linked list.
void popFromFront_after_push() {
    CharLinkedList test_list;
    test_list.pushAtBack('a');
    test_list.pushAtBack('b');
    test_list.pushAtBack('c');

    test_list.popFromFront();

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'b');
}

void popFromBack_after_push() {
    CharLinkedList test_list;
    test_list.pushAtBack('a');
    test_list.pushAtBack('b');
    test_list.pushAtBack('c');
    test_list.popFromBack();

    assert(test_list.size() == 2);
    assert(test_list.last() == 'b');
}

void clear_nonempty_list() {
    CharLinkedList test_list;
    test_list.pushAtBack('a');
    test_list.pushAtBack('b');
    test_list.clear();

    assert(test_list.size() == 0);
    assert(test_list.isEmpty());
}

void replaceAt_valid_index() {
    CharLinkedList test_list;
    test_list.pushAtBack('a');
    test_list.pushAtBack('b');
    test_list.replaceAt('c', 1);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(1) == 'c');
}

void replaceAt_out_of_range_index() {
    CharLinkedList test_list;
    test_list.pushAtBack('a');

    try {
        test_list.replaceAt('b', 1);
    } catch (const std::range_error& e) {
        assert(true);
        return;
    }

    assert(false);
}

void concatenate_nonempty_lists() {
    CharLinkedList list1;
    list1.pushAtBack('a');
    list1.pushAtBack('b');

    CharLinkedList list2;
    list2.pushAtBack('c');
    list2.pushAtBack('d');

    list1.concatenate(&list2);

    assert(list1.size() == 4);
    assert(list1.elementAt(2) == 'c');
}

void insertInOrder_unord_elements() {
    CharLinkedList test_list;
    test_list.insertInOrder('c');
    test_list.insertInOrder('a');
    test_list.insertInOrder('b');

    assert(test_list.size() == 3);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    assert(test_list.elementAt(2) == 'c');
}

void insertInOrder_ordered_elements() {
    CharLinkedList test_list;
    test_list.insertInOrder('a');
    test_list.insertInOrder('b');
    test_list.insertInOrder('c');

    assert(test_list.size() == 3);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    assert(test_list.elementAt(2) == 'c');
}

void assign_oprtr_empty_to_nonempty() {
    CharLinkedList list1;
    list1.pushAtBack('a');
    list1.pushAtBack('b');

    CharLinkedList list2;
    list2 = list1;

    assert(list1.size() == 2);
    assert(list2.size() == 2);

    assert(list1.elementAt(0) == 'a');
    assert(list2.elementAt(0) == 'a');
    assert(list1.elementAt(1) == 'b');
    assert(list2.elementAt(1) == 'b');

    list1.pushAtBack('c');
    assert(list1.size() == 3);
    assert(list2.size() == 2);
}

void assign_oprtr_nonempty_to_empty() {
    CharLinkedList list1;
    list1.pushAtBack('a');
    list1.pushAtBack('b');

    CharLinkedList list2;
    list2 = list1;

    assert(list1.size() == 2);
    assert(list2.size() == 2);

    assert(list1.elementAt(0) == 'a');
    assert(list2.elementAt(0) == 'a');
    assert(list1.elementAt(1) == 'b');
    assert(list2.elementAt(1) == 'b');

    list1.pushAtBack('c');
    assert(list1.size() == 3);
    assert(list2.size() == 2);
}

void assign_oprtr_empty_to_empty() {
    CharLinkedList list1;
    CharLinkedList list2;
    list2 = list1;

    assert(list1.size() == 0);
    assert(list2.size() == 0);

    list1.pushAtBack('a');
    assert(list1.size() == 1);
    assert(list2.size() == 0);
}

void assign_oprtr_self_assignment() {
    CharLinkedList list1;
    list1.pushAtBack('a');
    list1.pushAtBack('b');

    list1 = list1;

    assert(list1.size() == 2);
    assert(list1.elementAt(0) == 'a');
    assert(list1.elementAt(1) == 'b');
}

void elementAt_valid_index() {
    CharLinkedList test_list;
    test_list.pushAtBack('a');
    test_list.pushAtBack('b');
    test_list.pushAtBack('c');

    assert(test_list.elementAt(1) == 'b');
}

void elementAt_out_of_range_index() {
    CharLinkedList test_list;
    test_list.pushAtBack('a');

    try {
        test_list.elementAt(1);
    } catch (const std::range_error& e) {
        assert(true);
        return;
    }

    assert(false);
}

void toString_nonempty_list() {
    CharLinkedList test_list;
    test_list.pushAtBack('a');
    test_list.pushAtBack('b');
    test_list.pushAtBack('c');

    std::string str = test_list.toString();
    assert(str == "[CharLinkedList of size 3 <<abc>>]");
}

void toString_empty_list() {
    CharLinkedList test_list;

    std::string str = test_list.toString();
    assert(str == "[CharLinkedList of size 0 <<>>]");
}

void size_empty_list() {
    CharLinkedList test_list;

    assert(test_list.size() == 0);
}

void size_nonempty_list() {
    CharLinkedList test_list;
    test_list.pushAtBack('a');
    test_list.pushAtBack('b');
    test_list.pushAtBack('c');

    assert(test_list.size() == 3);
}

void first_nonempty_list() {
    CharLinkedList test_list;
    test_list.pushAtBack('a');
    test_list.pushAtBack('b');
    test_list.pushAtBack('c');

    assert(test_list.first() == 'a');
}

void first_empty_list() {
    CharLinkedList test_list;

    try {
        char firstElement = test_list.first();
        assert(false);
    } catch (const std::runtime_error& e) {
        assert(true);
    }
}

void last_nonempty_list() {
    CharLinkedList test_list;
    test_list.pushAtBack('a');
    test_list.pushAtBack('b');
    test_list.pushAtBack('c');

    assert(test_list.last() == 'c');
}

void last_empty_list() {
    CharLinkedList test_list;

    try {
        char lastElement = test_list.last();
        assert(false);
    } catch (const std::runtime_error& e) {
        assert(true);
    }
}

void isEmpty_empty_list() {
    CharLinkedList test_list;

    assert(test_list.isEmpty());
}

void isEmpty_nonempty_list() {
    CharLinkedList test_list;
    test_list.pushAtBack('a');

    assert(not test_list.isEmpty());
}

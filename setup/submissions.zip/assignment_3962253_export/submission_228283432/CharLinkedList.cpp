/*
 *  CharLinkedList.cpp
 *  Jean Pascal Cyusa Shyaka
 *  Feb 4, 2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Implementation of CharLinkedList class
 *
 */

#include "CharLinkedList.h"

#include <iostream>
#include <string>

/*
 * Name: CharLinkedList (default constructor)
 * Purpose: To initialize a linekdlist array with no elements
 * Arguments: None
 * Returns: None
 * Effects: numItems to 0 (also updates capacity and char array)
 */
CharLinkedList::CharLinkedList() {
    head = nullptr;
    tail = nullptr;
    numItems = 0;
}

/*
 * Name: CharLinkedList (constructor with char)
 * Purpose: To initialize a linkedlist array with one element
 * Arguments: char c
 * Returns: None
 * Effects: numItems and capacity to 1 (also updates char array)
 */
CharLinkedList::CharLinkedList(char c) {
    head = nullptr;
    tail = nullptr;
    numItems = 0;
    pushAtBack(c);
}

/*
 * Name: charLinkedList third constructor
 * Purpose: To initialize a linkedlist array with elements from a char array
 * Arguments: char array and its size
 * Returns: None
 * Effects: numItems and capacity (also updates char array)
 */
CharLinkedList::CharLinkedList(char arr[], int size) {
    head = nullptr;
    tail = nullptr;
    numItems = 0;
    for (int i = 0; i < size; i++) {
        pushAtBack(arr[i]);
    }
}

/*
 * Name: CharLinkedList (copy constructor)
 * Purpose: To initialize a linkedlist array with elements from another
 *          linkedlist
 * Arguments: another linkedlist
 * Returns: None
 * Effects: numItems and capacity (also updates char array)
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other) {
    head = nullptr;
    tail = nullptr;
    numItems = 0;
    Node *temp = other.head;
    while (temp != nullptr) {
        pushAtBack(temp->data);
        temp = temp->next;
    }
}

/*
 * Name: ~CharLinkedList (destructor)
 * Purpose: To delete the linkedlist array
 * Arguments: None
 * Returns: None
 * Effects: numItems and capacity to 0 (also updates char array)
 */
CharLinkedList::~CharLinkedList() {
    cleanMemory();
}

/*
 * Name: operator=
 * Purpose: To assign the linkedlist array to another linkedlist
 * Arguments: another linkedlist
 * Returns: None
 * Effects: numItems and capacity (also updates char array)
 */
CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other) {
    if (this != &other) {
        clear();
        Node *temp = other.head;
        while (temp != nullptr) {
            pushAtBack(temp->data);
            temp = temp->next;
        }
    }
    return *this;
}

/*
 * Name: isEmpty
 * Purpose: To check if the linkedlist array is empty
 * Arguments: None
 * Returns: bool
 * Effects: None
 */
bool CharLinkedList::isEmpty() const {
    return numItems == 0;
}

/*
 * Name: clear
 * Purpose: To clear the linkedlist array
 * Arguments: None
 * Returns: None
 * Effects: numItems and capacity to 0 (also updates char array)
 */
void CharLinkedList::clear() {
    while (head != nullptr) {
        popFromFront();
    }
}

/*
 * Name: size
 * Purpose: To get the size of the linkedlist array
 * Arguments: None
 * Returns: int
 * Effects: None
 */
int CharLinkedList::size() const {
    return numItems;
}

/*
 * Name: first
 * Purpose: To get the first element of the linkedlist array
 * Arguments: None
 * Returns: char
 * Effects: None
 */
char CharLinkedList::first() const {
    if (isEmpty()) {
        throw std::runtime_error("cannot get first of empty LinkedList");
    }
    return head->data;
}

/*
 * Name: last
 * Purpose: To get the last element of the linkedlist array
 * Arguments: None
 * Returns: char
 * Effects: None
 */
char CharLinkedList::last() const {
    if (isEmpty()) {
        throw std::runtime_error("cannot get last of empty LinkedList");
    }
    return tail->data;
}

/*
 * Name: elementAt
 * Purpose: To get the element at a given index of the linkedlist array
 * Arguments: index
 * Returns: char
 * Effects: None
 */
char CharLinkedList::elementAt(int index) const {
    if (index < 0 or index >= numItems) {
        throw std::range_error("index (" + std::to_string(index) +
                               ") not in range [0.." +
                               std::to_string(numItems) + ")");
    }

    // call helper starting from head
    return elementAtHelper(head, index);
}

/*
 * Name: toString
 * Purpose: To get the string representation of the linkedlist array
 * Arguments: None
 * Returns: string
 * Effects: None
 */
std::string CharLinkedList::toString() const {
    std::string result = "[CharLinkedList of size " +
                         std::to_string(numItems) + " <<";
    Node *temp = head;
    while (temp != nullptr) {
        result += temp->data;
        temp = temp->next;
    }
    result += ">>]";
    return result;
}

/*
 * Name: toReverseString
 * Purpose: To get the reverse string representation of the linkedlist array
 * Arguments: None
 * Returns: string
 * Effects: None
 */
std::string CharLinkedList::toReverseString() const {
    int counter = 0;
    Node *current = tail;

    std::string result = "[CharLinkedList of size " +
                         std::to_string(numItems) + " <<";

    while (counter != numItems) {
        result = result + current->data;
        current = current->prev;
        counter++;
    }

    return result += ">>]";
}

/*
 * Name: pushAtBack
 * Purpose: To add an element at the end of the linkedlist array
 * Arguments: char
 * Returns: None
 * Effects: numItems and capacity (also updates char array)
 */
void CharLinkedList::pushAtBack(char c) {
    Node *temp = new Node;
    temp->data = c;
    temp->next = nullptr;
    if (isEmpty()) {
        head = temp;
        tail = temp;
    } else {
        tail->next = temp;
        tail = temp;
    }
    numItems++;
}

/*
 * Name: pushAtFront
 * Purpose: To add an element at the beginning of the linkedlist array
 * Arguments: char
 * Returns: None
 * Effects: numItems and capacity (also updates char array)
 */
void CharLinkedList::pushAtFront(char c) {
    Node *temp = new Node;
    temp->data = c;
    temp->next = head;
    head = temp;
    if (isEmpty()) {
        tail = temp;
    }
    numItems++;
}

/*
 * Name: insertAt
 * Purpose: To add an element at a given index of the linkedlist array
 * Arguments: char and index
 * Returns: None
 * Effects: numItems and capacity (also updates char array)
 */
void CharLinkedList::insertAt(char c, int index) {
    if (index < 0 or index > numItems) {
        throw std::range_error("index (" + std::to_string(index) +
                               ") not in range [0.." +
                               std::to_string(numItems) + "]");
    }
    if (index == 0) {
        pushAtFront(c);
    } else if (index == numItems) {
        pushAtBack(c);
    } else {
        Node *temp = head;
        for (int i = 0; i < index - 1; i++) {
            temp = temp->next;
        }
        Node *newNode = new Node;
        newNode->data = c;
        newNode->next = temp->next;
        temp->next = newNode;
        numItems++;
    }
}

/*
 * Name: insertInOrder
 * Purpose: To add an element in order in the linkedlist array
 * Arguments: char
 * Returns: None
 * Effects: numItems and capacity (also updates char array)
 */
void CharLinkedList::insertInOrder(char c) {
    Node *temp = head;
    Node *prev = nullptr;
    while (temp != nullptr and temp->data < c) {
        prev = temp;
        temp = temp->next;
    }
    if (prev == nullptr) {
        pushAtFront(c);
    } else if (temp == nullptr) {
        pushAtBack(c);
    } else {
        Node *newNode = new Node;
        newNode->data = c;
        newNode->next = temp;
        prev->next = newNode;
        numItems++;
    }
}

/*
 * Name: popFromFront
 * Purpose: To remove an element from the beginning of the linkedlist array
 * Arguments: None
 * Returns: None
 * Effects: numItems and capacity (also updates char array)
 */
void CharLinkedList::popFromFront() {
    if (isEmpty()) {
        throw std::runtime_error("cannot pop from empty LinkedList");
    }
    Node *temp = head;
    head = head->next;
    delete temp;
    numItems--;
    if (isEmpty()) {
        tail = nullptr;
    }
}

/*
 * Name: popFromBack
 * Purpose: To remove an element from the end of the linkedlist array
 * Arguments: None
 * Returns: None
 * Effects: numItems and capacity (also updates char array)
 */
void CharLinkedList::popFromBack() {
    if (isEmpty()) {
        throw std::runtime_error("cannot pop from empty LinkedList");
    }
    if (numItems == 1) {
        popFromFront();
    } else {
        Node *temp = head;
        while (temp->next != tail) {
            temp = temp->next;
        }
        delete tail;
        tail = temp;
        tail->next = nullptr;
        numItems--;
    }
}

/*
 * Name: removeAt
 * Purpose: To remove an element at a given index of the linkedlist array
 * Arguments: index
 * Returns: None
 * Effects: numItems and capacity (also updates char array)
 */
void CharLinkedList::removeAt(int index) {
    if (index < 0 or index >= numItems) {
        throw std::range_error("index (" + std::to_string(index) +
                               ") not in range [0.." +
                               std::to_string(numItems) + ")");
    }
    if (index == 0) {
        popFromFront();
    } else if (index == numItems - 1) {
        popFromBack();
    } else {
        Node *temp = head;
        for (int i = 0; i < index - 1; i++) {
            temp = temp->next;
        }
        Node *toDelete = temp->next;
        temp->next = toDelete->next;
        delete toDelete;
        numItems--;
    }
}

/*
 * Name: replaceAt
 * Purpose: To replace an element at a given index of the linkedlist array
 * Arguments: char and index
 * Returns: None
 * Effects: numItems and capacity (also updates char array)
 */
void CharLinkedList::replaceAt(char c, int index) {
    if (index < 0 or index >= numItems) {
        throw std::range_error("index (" + std::to_string(index) +
                               ") not in range [0.." +
                               std::to_string(numItems) + ")");
    }

    replaceAtHelper(head, c, index);
}

/*
 * Name: concatenate
 * Purpose: To concatenate the linkedlist array with another linkedlist
 * Arguments: another linkedlist
 * Returns: None
 * Effects: numItems and capacity (also updates char array)
 */
void CharLinkedList::concatenate(CharLinkedList *other) {
    Node *temp = other->head;
    while (temp != nullptr) {
        pushAtBack(temp->data);
        temp = temp->next;
    }
}

/* Helper functions Implemeted here*/

/*
 * Name: elementAtHelper
 * Purpose: To get the element at a given index of the linkedlist array
 * Arguments: Node pointer and index
 * Returns: char
 * Effects: None
 */
char CharLinkedList::elementAtHelper(Node *current, int index) const {
    if (current == nullptr) {
        throw std::range_error("index (" + std::to_string(index) +
                               ") not in range [0.." +
                               std::to_string(numItems) + ")");
    }

    if (index == 0) {
        return current->data;
    }

    return elementAtHelper(current->next, index - 1);
}

/*
 * Name: replaceAtHelper
 * Purpose: To replace an element at a given index of the linkedlist array
 * Arguments: Node pointer, char and index
 * Returns: None
 * Effects: None
 */
void CharLinkedList::replaceAtHelper(Node *current, char c, int index) {
    if (index == 0) {
        current->data = c;
    } else {
        replaceAtHelper(current->next, c, index - 1);
    }
}

/*
 * Name: cleanMemory
 * Purpose: To delete the linkedlist array
 * Arguments: None
 * Returns: None
 * Effects: numItems and capacity to 0 (also updates char array)
 */
void CharLinkedList::cleanMemory() {
    while (head != nullptr) {
        popFromFront();
    }
}

/*
 *  CharLinkedList.h
 *  Jean Pascal Cyusa Shyaka
 *  Feb 4, 2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Definition for CharLinkedList class
 *
 */

#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H

#include <string>

class CharLinkedList {
   private:
    struct Node {
        char data;
        Node *prev;
        Node *next;
    };
    Node *head;
    Node *tail;
    int numItems;

    // helper functions
    char elementAtHelper(Node *current, int index) const;
    void replaceAtHelper(Node *current, char c, int index);
    void cleanMemory();

   public:
    // default constructors
    CharLinkedList();
    CharLinkedList(char c);
    CharLinkedList(char arr[], int size);
    CharLinkedList(const CharLinkedList &other);
    // destructor
    ~CharLinkedList();
    CharLinkedList &operator=(const CharLinkedList &other);
    bool isEmpty() const;
    void clear();
    int size() const;
    char first() const;
    char last() const;
    char elementAt(int index) const;
    std::string toString() const;
    std::string toReverseString() const;
    void pushAtBack(char c);
    void pushAtFront(char c);
    void insertAt(char c, int index);
    void insertInOrder(char c);
    void popFromFront();
    void popFromBack();
    void removeAt(int index);
    void replaceAt(char c, int index);
    void concatenate(CharLinkedList *other);
};

#endif

/*
 *  CharLinkedList.h
 *  Rigoberto Rodriguez-Anton
 *  2/4/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  This is a class declaration for the CharLinkedList class for hw2 of CS15.
 *
 */

#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H
#include <iostream>

class CharLinkedList {
public:
    CharLinkedList();
    CharLinkedList(char c);
    CharLinkedList(char arr[], int size);
    CharLinkedList(const CharLinkedList &other);
    ~CharLinkedList();
    CharLinkedList &operator=(const CharLinkedList &other);

    bool isEmpty() const;
    void clear();
    int size() const;
    char first() const;
    char last() const;
    char elementAt(int index) const;
    std::string toString() const;
    std::string toReverseString() const;

    void pushAtBack(char c);
    void pushAtFront(char c);
    void insertAt(char c, int index);
    void insertInOrder(char c);

    void popFromFront();
    void popFromBack();
    void removeAt(int index);
    void replaceAt(char c, int index);

    void concatenate(CharLinkedList *other);

private:
struct Node {
        char info;
        Node *next = nullptr, *previous = nullptr;
    };

    Node *head = nullptr, *tail = nullptr;
    int numItems = 0;

    void recursionDelete(Node *front);
    char elementSearch(Node *front, int index) const;
    std::string getChars(Node *first) const;
    std::string getReversedChars(Node *last) const;
    void recursionReplace(char c, int index, Node *front);
};

#endif

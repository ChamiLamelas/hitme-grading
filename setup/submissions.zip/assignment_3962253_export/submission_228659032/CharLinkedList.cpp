/*
 *  CharLinkedList.cpp
 *  Rigoberto Rodriguez-Anton {rrodri08}
 *  2/4/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Function definitions for the CharLinkedList class. 
 *
 */

#include "CharLinkedList.h"
#include <iostream>
#include <sstream>
#include <string>

/*
 * name:      CharLinkedList default constructor
 * purpose:   Initializes an empty CharLinkedList
 * arguments: none
 * returns:   none
 * effects:   none
 */
CharLinkedList::CharLinkedList() {
    head = nullptr;
    tail = nullptr;
}

/*
 * name:      CharLinkedList singleton constructor
 * purpose:   Initializes a singleton CharLinkedList
 * arguments: A character
 * returns:   none
 * effects:   numItems is set to 1, creates a singleton linked list
 */
CharLinkedList::CharLinkedList(char c) {
    head = new Node;
    tail = head;
    head->info = c;
    numItems++;
}

/*
 * name:      CharLinkedList array constructor
 * purpose:   Initializes a CharLinkedList using elements from arr
 * arguments: An array of characters, the size of that array
 * returns:   none
 * effects:   numItems to size, creates a linked list
 */
CharLinkedList::CharLinkedList(char arr[], int size) {
    for (int i = 0; i < size; i++) {
        pushAtBack(arr[i]);
    }
}

/*
 * name:      CharLinkedList copy constructor
 * purpose:   Makes a deep copy of a CharLinkedList
 * arguments: Another CharLinkedList
 * returns:   none
 * effects:   Makes a deep copy.
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other) {
    Node *curr = other.head;
    // Iterates through other and pushes at back the values to the linked list.
    for (int i = 0; i < other.numItems; i++) {
        pushAtBack(curr->info);
        curr = curr->next;
    }
}

/*
 * name:      CharLinkedList destructor
 * purpose:   Frees the memory of the linked list
 * arguments: none
 * returns:   none
 * effects:   deletes the linked list
 */
CharLinkedList::~CharLinkedList() {
    // Helper function
    recursionDelete(head);
}

/*
 * name:      recursionDelete
 * purpose:   Frees the memory of the linked list using recursion
 * arguments: A pointer to the begining of the list
 * returns:   none
 * effects:   deletes the linked list
 */
void CharLinkedList::recursionDelete(Node *front) {
    // This will recurse to the last element before deleting anything.
    if (numItems > 0) {
        numItems--;
        recursionDelete(front->next);
        delete front;
    }
}

/*
 * name:      CharLinkedList assignment operator
 * purpose:   Makes a deep copy of a CharLinkedList
 * arguments: Another CharLinkedList
 * returns:   none
 * effects:   Makes a deep copy.
 */
CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other) {
    // Just in case we are starting with a non empty list.
    recursionDelete(head);
    Node *curr = other.head;
    // Same as the copy constructor.
    for (int i = 0; i < other.numItems; i++) {
        pushAtBack(curr->info);
        curr = curr->next;
    }
    return *this;
}

/*
 * name:      isEmpty
 * purpose:   Checks if the CharLinkedList is empty
 * arguments: none
 * returns:   Whether the linked list is empty or not
 * effects:   none
 */
bool CharLinkedList::isEmpty() const {
    return numItems == 0;
}

/*
 * name:      clear
 * purpose:   Empties the linked list
 * arguments: none
 * returns:   none
 * effects:   Frees memory and sets numItems to 0
 */
void CharLinkedList::clear() {
    // Uses the destructor helper function.
    recursionDelete(head);
}

/*
 * name:      size
 * purpose:   Finds the size of the linked list
 * arguments: none
 * returns:   numItems
 * effects:   none
 */
int CharLinkedList::size() const {
    // numItems getter
    return numItems;
}

/*
 * name:      first
 * purpose:   Returns the first element of the list
 * arguments: none
 * returns:   head->info
 * effects:   none
 */
char CharLinkedList::first() const {
    // Error thrower
    if (isEmpty()) {
        throw std::runtime_error("cannot get first of empty LinkedList");
    } else {
        // head->info getter
        return head->info;
    }
}

/*
 * name:      last
 * purpose:   Returns the last element of the list
 * arguments: none
 * returns:   tail->info
 * effects:   none
 */
char CharLinkedList::last() const {
    // Error thrower
    if (isEmpty()) {
        throw std::runtime_error("cannot get last of empty LinkedList");
    } else {
        // tail->info getter
        return tail->info;
    }
}

/*
 * name:      elementAt
 * purpose:   Returns the requested element of the list
 * arguments: Index of the desired element
 * returns:   The character at the given index
 * effects:   none
 */
char CharLinkedList::elementAt(int index) const {
    // Range error check
    if (index >= numItems or index < 0) {
        std::stringstream ss;
        ss << "index (" << index << ") not in range [0.." << numItems << ")";
        throw std::range_error(ss.str());
    } else if (index == 0) {
        // If the requested element is the first one, we can just return the
        // head.
        return head->info;
    } else if (index == numItems - 1) {
        // Same deal with the last element.
        return tail->info;
    } else {
        // Recursive helper function that searches the linked list.
        return elementSearch(head, index);
    }
}

/*
 * name:      elementSearch
 * purpose:   Returns the requested element of the list
 * arguments: Pointer to the start of a linked list, index of the desired
 *            element
 * returns:   The pointer at the given index
 * effects:   none
 */
char CharLinkedList::elementSearch(Node *front, int index) const {
    // This is basically a for loop. 
    if (index > 0) {
        return elementSearch(front->next, index - 1);
    } else return front->info;
}

/*
 * name:      toString
 * purpose:   Makes a string using the characters in the linked list
 * arguments: none
 * returns:   The linked list in string form
 * effects:   none
 */
std::string CharLinkedList::toString() const {
    std::stringstream ss;
    ss << "[CharLinkedList of size " << numItems << " <<";

    if (not isEmpty()) {
        // getChars is a recursive helper function that returns the characters
        // of the linked list in order as a string
        ss << getChars(head);
    }
    ss << ">>]";
    return ss.str();
}

/*
 * name:      getChars
 * purpose:   Makes a string of the characters in the linked list starting from
 *            the given pointer
 * arguments: The Node to start from 
 * returns:   A subset of the linked list in string form
 * effects:   none
 */
std::string CharLinkedList::getChars(Node *first) const {
    std::stringstream ss;
    ss << first->info;
    if (first != tail) {
        ss << getChars(first->next);
    }
    return ss.str(); 
}

/*
 * name:      toReverseString
 * purpose:   Makes a reversed string using the characters in the linked list
 * arguments: none
 * returns:   The reversed linked list in string form
 * effects:   none
 */
std::string CharLinkedList::toReverseString() const {
    std::stringstream ss;
    ss << "[CharLinkedList of size " << numItems << " <<";
    if (not isEmpty()) {
        // getReversedChars is a recursive helper function that returns the 
        // characters of the list in reversed order as a string.
        ss << getReversedChars(tail);
    }
    ss << ">>]";
    return ss.str();
}

/*
 * name:      getReversedChars
 * purpose:   Makes a reversed string of the characters in the linked list
 *            starting from the given pointer
 * arguments: The Node to start from 
 * returns:   A reversed subset of the linked list in string form
 * effects:   none
 */
std::string CharLinkedList::getReversedChars(Node *last) const {
    std::stringstream ss;
    ss << last->info;
    if (last != head) {
        ss << getReversedChars(last->previous);
    }
    return ss.str(); 
}

/*
 * name:      pushAtBack
 * purpose:   Pushes a character to the back of the linked list
 * arguments: A character to push back
 * returns:   none
 * effects:   Adds to the back of the linked list, updates tail
 */
void CharLinkedList::pushAtBack(char c) {
    // Uses the stored tail pointer to have O(n) complexity.
    if (isEmpty()) {
        // In the case that the list is empty, head and tail will point to the
        // same node.
        head = new Node;
        tail = head;
        head->info = c;
    } else {
        tail->next = new Node;
        tail->next->info = c;
        tail->next->previous = tail;
        tail = tail->next;
    }
    numItems++;
}

/*
 * name:      pushAtFront
 * purpose:   Pushes a character to the front of the linked list
 * arguments: A character to push to the front
 * returns:   none
 * effects:   Adds to the front of the linked list, updates head
 */
void CharLinkedList::pushAtFront(char c) {
    // Uses the stored head pointer to have O(n) complexity.
    if (isEmpty()) {
        // In the case that the list is empty, head and tail will point to the
        // same node.
        head = new Node;
        tail = head;
        head->info = c;
    } else {
        head->previous = new Node;
        head->previous->info = c;
        head->previous->next = head;
        head = head->previous;
    }
    numItems++;
}

/*
 * name:      insertAt
 * purpose:   Inserts a character into the linked list
 * arguments: A character to insert and the index to insert it at
 * returns:   none
 * effects:   Adds to the linked list, updates numItems
 */
void CharLinkedList::insertAt(char c, int index) {
    if (index > numItems or index < 0) {
        std::stringstream ss;
        ss << "index (" << index << ") not in range [0.." << numItems << "]";
        throw std::range_error(ss.str());
    } else if (index == numItems) {
        pushAtBack(c);
    } else if (index == 0) {
        pushAtFront(c);
    } else {
        Node *curr = head;
        // Iterates to collect the correct pointer
        for (int i = 0; i < index; i++) {
            curr = curr->next;
        }
        // This is wizardry
        // Basically it inserts a new node with the given character into its
        // place in the list while updating the surrounding nodes.
        curr->previous->next = new Node;
        curr->previous->next->previous = curr->previous;
        curr->previous = curr->previous->next;
        curr->previous->info = c;
        curr->previous->next = curr;
        numItems++;
    }
}

/*
 * name:      insertInOrder
 * purpose:   Inserts a character in order into the linked list
 * arguments: A character to insert
 * returns:   none
 * effects:   Adds to the linked list, updates numItems
 */
void CharLinkedList::insertInOrder(char c) {
    Node *curr = head;
    int i = 0;
    char low = 0;
    bool inserted = false;
    while (not inserted) {
        if (i == numItems) {
            insertAt(c, i);
            inserted = true;
        }
        if (not inserted){
            // Checks if the current location in the list is the right location
            // to insert at. 
            if (c >= low and c <= curr->info) {
                // This does increase time complexity, but I'm too tired to make
                // custom code for this function.
                insertAt(c, i);
                inserted = true;
            }
        }
        if (not inserted) {
            low = curr->info;
            curr = curr->next;
        }
        i++;
    }
}

/*
 * name:      popFromFront
 * purpose:   Removes the first element of the list
 * arguments: none
 * returns:   none
 * effects:   Removes the first element, updates numItems
 */
void CharLinkedList::popFromFront() {
    // Error checks
    if (isEmpty()) {
        throw std::runtime_error("cannot pop from empty LinkedList");
    } else if (numItems == 1) {
        clear();
    } else {
        // Uses the stored head pointer to delete with time complexity O(n).
        head = head->next;
        delete head->previous;
        head->previous = nullptr;
        numItems--;
    }
}

/*
 * name:      popFromBack
 * purpose:   Removes the last element of the list
 * arguments: none
 * returns:   none
 * effects:   Removes the last element, updates numItems
 */
void CharLinkedList::popFromBack() {
    // Error checks
    if (isEmpty()) {
        throw std::runtime_error("cannot pop from empty LinkedList");
    } else if (numItems == 1) {
        clear();
    } else {
        // Uses the stored tail pointer to delete with time complexity O(n).
        tail = tail->previous;
        delete tail->next;
        tail->next = nullptr;
        numItems--;
    }
}

/*
 * name:      removeAt
 * purpose:   Removes the indicated element of the list
 * arguments: index
 * returns:   none
 * effects:   Removes the requested element, updates numItems
 */
void CharLinkedList::removeAt(int index) {
    // Error checks
    if (index >= numItems or index < 0) {
        std::stringstream ss;
        ss << "index (" << index << ") not in range [0.." << numItems << ")";
        throw std::range_error(ss.str());
    } 
    // Checks if the time can be shortened with the use of the pop functions.
    else if (index == numItems - 1) {
        popFromBack();
    } else if (index == 0) {
        popFromFront();
    } else {
        Node *curr = head;
        for (int i = 0; i < index; i++) {
            curr = curr->next;
        }
        curr->previous->next = curr->next;
        curr->next->previous = curr->previous;
        delete curr;
        numItems--;
    }
}

/*
 * name:      replaceAt
 * purpose:   Replaces the indicated element of the list
 * arguments: Character, index
 * returns:   none
 * effects:   Replaces the requested element
 */
void CharLinkedList::replaceAt(char c, int index) {
    // Error checks
    if (index >= numItems or index < 0) {
        std::stringstream ss;
        ss << "index (" << index << ") not in range [0.." << numItems << ")";
        throw std::range_error(ss.str());
    } 
    // Checks if the end pointers can speed this up.
    else if (index == 0) {
        head->info = c;
    } else if (index == numItems - 1) {
        tail->info = c;
    } 
    // Uses a recursive helper function.
    else {
        recursionReplace(c, index, head);
    }
}

/*
 * name:      recursionReplace
 * purpose:   Replaces the indicated element of the list
 * arguments: Character, index, front
 * returns:   none
 * effects:   Replaces the requested element
 */
void CharLinkedList::recursionReplace(char c, int index, Node *front) {
    // Just another glorified for loop...
    if (index > 0) {
        recursionReplace(c, index - 1, front->next);
    } else {
        front->info = c;
    }
}

/*
 * name:      concatenate
 * purpose:   Adds a copy of the given list to the end of this linked list
 * arguments: A pointer to a linked list
 * returns:   none
 * effects:   concatenates the lists
 */
void CharLinkedList::concatenate(CharLinkedList *other) {
    // Uses pushAtBack to add the values to the end of the linked list.
    if (other != nullptr) {
        Node *curr = other->head;
        int limit = other->numItems;
        for (int i = 0; i < limit; i++) {
            pushAtBack(curr->info);
            curr = curr->next;
        }
    }
}
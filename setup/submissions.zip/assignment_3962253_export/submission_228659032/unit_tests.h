/*
 *  unit_tests.h
 *  Rigoberto Rodriguez-Anton {rrodri08}
 *  2/4/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  Uses Matt Russell's unit_test framework to test the CharLinkedList class.
 *
 */
#include "CharLinkedList.h"
#include <cassert>
#include <iostream>
#include <sstream>

/********************************************************************\
*                       CHAR LINKED LIST TESTS                       *
\********************************************************************/

// CONSTRUCTOR TESTS //

// Empty list construction test
void empty_construct() {
    CharLinkedList test;
    std::cout << test.size();
    assert(test.isEmpty());
}

// Singleton list construction test
void singleton_construct() {
    CharLinkedList test('c');
    std::cout << test.size();
    assert(test.size() == 1);
    assert(not test.isEmpty());
}

// Array construction test
void array_construct() {
    char list[4] = {'a', 'b', 'c', 'd'};
    CharLinkedList test(list, 4);
    std::cout << test.size();
    assert(test.size() == 4);
    assert(not test.isEmpty());
    std::cout << test.toString();
    assert(test.toString() == "[CharLinkedList of size 4 <<abcd>>]");
}


// COPY CONSTRUCTOR TESTS //
void copy_construct_empty() {
    CharLinkedList test;
    CharLinkedList copy(test);
    assert(copy.isEmpty());
    assert(copy.toString() == "[CharLinkedList of size 0 <<>>]");
}

void copy_construct_singleton() {
    CharLinkedList test('a');
    CharLinkedList copy(test);
    assert(copy.size() == 1);
    assert(copy.toString() == "[CharLinkedList of size 1 <<a>>]");
}

void copy_construct_large() {
    char list[4] = {'a', 'b', 'c', 'd'};
    CharLinkedList test(list, 4);
    CharLinkedList copy(test);
    assert(copy.size() == 4);
    assert(copy.toString() == "[CharLinkedList of size 4 <<abcd>>]");
}


// ASSIGNMENT OPERATOR TESTS //
void operator_empty() {
    CharLinkedList test;
    CharLinkedList copy;
    copy = test;
    assert(copy.isEmpty());
    assert(copy.toString() == "[CharLinkedList of size 0 <<>>]");
}

void operator_singleton() {
    CharLinkedList test('a');
    CharLinkedList copy;
    copy = test;
    assert(copy.size() == 1);
    assert(copy.toString() == "[CharLinkedList of size 1 <<a>>]");
}

void operator_large() {
    char list[4] = {'a', 'b', 'c', 'd'};
    CharLinkedList test(list, 4);
    CharLinkedList copy;
    copy = test;
    assert(copy.size() == 4);
    assert(copy.toString() == "[CharLinkedList of size 4 <<abcd>>]");
}

void singleton_operator_empty() {
    CharLinkedList test;
    CharLinkedList copy('z');
    copy = test;
    assert(copy.isEmpty());
    assert(copy.toString() == "[CharLinkedList of size 0 <<>>]");
}

void singleton_operator_singleton() {
    CharLinkedList test('a');
    CharLinkedList copy('z');
    copy = test;
    assert(copy.size() == 1);
    assert(copy.toString() == "[CharLinkedList of size 1 <<a>>]");
}

void singleton_operator_large() {
    char list[4] = {'a', 'b', 'c', 'd'};
    CharLinkedList test(list, 4);
    CharLinkedList copy('z');
    copy = test;
    assert(copy.size() == 4);
    assert(copy.toString() == "[CharLinkedList of size 4 <<abcd>>]");
}

void large_operator_empty() {
    char list2[4] = {'d', 'c', 'b', 'a'};
    CharLinkedList test;
    CharLinkedList copy(list2, 4);
    copy = test;
    assert(copy.isEmpty());
    assert(copy.toString() == "[CharLinkedList of size 0 <<>>]");
}

void large_operator_singleton() {
    char list2[4] = {'d', 'c', 'b', 'a'};
    CharLinkedList test('a');
    CharLinkedList copy(list2, 4);
    copy = test;
    assert(copy.size() == 1);
    assert(copy.toString() == "[CharLinkedList of size 1 <<a>>]");
}

void large_operator_large() {
    char list[4] = {'a', 'b', 'c', 'd'};
    char list2[4] = {'d', 'c', 'b', 'a'};
    CharLinkedList test(list, 4);
    CharLinkedList copy(list2, 4);
    copy = test;
    assert(copy.size() == 4);
    assert(copy.toString() == "[CharLinkedList of size 4 <<abcd>>]");
}


// CLEAR TESTS //
void clear_test() {
    char list[4] = {'a', 'b', 'c', 'd'};
    CharLinkedList test(list, 4);
    test.clear();
    assert(test.isEmpty());
}

void clear_empty() {
    CharLinkedList test;
    test.clear();
    assert(test.isEmpty());
}

void clear_singleton() {
    CharLinkedList test('a');
    test.clear();
    assert(test.isEmpty());
}


// FIRST AND LAST TESTS //
void first_empty() {
    CharLinkedList test;
    std::stringstream ss;
    bool error_thrown = false;
    try {
        test.first();
    }
    catch(const std::runtime_error &e) {
        ss << e.what();
        error_thrown = true;
    }
    assert(error_thrown);
    assert(ss.str() == "cannot get first of empty LinkedList");
}

void last_empty() {
    CharLinkedList test;
    std::stringstream ss;
    bool error_thrown = false;
    try {
        test.last();
    }
    catch(const std::runtime_error &e) {
        ss << e.what();
        error_thrown = true;
    }
    assert(error_thrown);
    assert(ss.str() == "cannot get last of empty LinkedList");
}

void first_singleton() {
    CharLinkedList test('a');
    assert(test.first() == 'a');
}

void last_singleton() {
    CharLinkedList test('a');
    assert(test.last() == 'a');
}

void first_large() {
    char list[4] = {'a', 'b', 'c', 'd'};
    CharLinkedList test(list, 4);
    assert(test.first() == 'a');
}

void last_large() {
    char list[4] = {'a', 'b', 'c', 'd'};
    CharLinkedList test(list, 4);
    assert(test.last() == 'd');
}


// ELEMENTAT TESTS //
void elementAt_empty() {
    CharLinkedList test;
    std::stringstream ss;
    bool error_thrown = false;
    try {
        test.elementAt(0);
    }
    catch(const std::range_error &e) {
        ss << e.what();
        error_thrown = true;
    }
    assert(error_thrown);
    assert(ss.str() == "index (0) not in range [0..0)");
}

void elementAt_rangeError_low() {
    char list[4] = {'a', 'b', 'c', 'd'};
    CharLinkedList test(list, 4);
    std::stringstream ss;
    bool error_thrown = false;
    try {
        test.elementAt(-1);
    }
    catch(const std::range_error &e) {
        ss << e.what();
        error_thrown = true;
    }
    assert(error_thrown);
    assert(ss.str() == "index (-1) not in range [0..4)");
}

void elementAt_rangeError_high() {
    char list[4] = {'a', 'b', 'c', 'd'};
    CharLinkedList test(list, 4);
    std::stringstream ss;
    bool error_thrown = false;
    try {
        test.elementAt(4);
    }
    catch(const std::range_error &e) {
        ss << e.what();
        error_thrown = true;
    }
    assert(error_thrown);
    assert(ss.str() == "index (4) not in range [0..4)");
}

void elementAt_singleton() {
    CharLinkedList test('a');
    assert(test.elementAt(0) == 'a');
}

void elementAt_zero_large() {
    char list[4] = {'a', 'b', 'c', 'd'};
    CharLinkedList test(list, 4);
    assert(test.elementAt(0) == 'a');
}

void elementAt_last_large() {
    char list[4] = {'a', 'b', 'c', 'd'};
    CharLinkedList test(list, 4);
    assert(test.elementAt(3) == 'd');
}

void elementAt_mid_large() {
    char list[4] = {'a', 'b', 'c', 'd'};
    CharLinkedList test(list, 4);
    assert(test.elementAt(2) == 'c');
}


// TOSTRING TESTS //
void string_empty() {
    CharLinkedList test;
    assert(test.toString() == "[CharLinkedList of size 0 <<>>]");
}

void string_single() {
    CharLinkedList test('a');
    assert(test.toString() == "[CharLinkedList of size 1 <<a>>]");
}

void string_large() {
    char list[4] = {'a', 'b', 'c', 'd'};
    CharLinkedList test(list, 4);
    assert(test.toString() == "[CharLinkedList of size 4 <<abcd>>]");
}


// REVERSE STRING TESTS //
void rstring_empty() {
    CharLinkedList test;
    assert(test.toReverseString() == "[CharLinkedList of size 0 <<>>]");
}

void rstring_single() {
    CharLinkedList test('a');
    assert(test.toReverseString() == "[CharLinkedList of size 1 <<a>>]");
}

void rstring_large() {
    char list[4] = {'a', 'b', 'c', 'd'};
    CharLinkedList test(list, 4);
    assert(test.toReverseString() == "[CharLinkedList of size 4 <<dcba>>]");
}


// PUSH AT BACK TESTS //
void pushback_one_empty() {
    CharLinkedList test;
    test.pushAtBack('a');
    assert(test.size() == 1);
    assert(test.toString() == "[CharLinkedList of size 1 <<a>>]");
}

void pushback_one_singleton() {
    CharLinkedList test('a');
    test.pushAtBack('b');
    assert(test.size() == 2);
    assert(test.toString() == "[CharLinkedList of size 2 <<ab>>]");
}

void pushback_one_large() {
    char list[4] = {'a', 'b', 'c', 'd'};
    CharLinkedList test(list, 4);
    test.pushAtBack('e');
    assert(test.size() == 5);
    assert(test.toString() == "[CharLinkedList of size 5 <<abcde>>]");
}

void pushback_multiple() {
    CharLinkedList test;
    test.pushAtBack('a');
    test.pushAtBack('b');
    test.pushAtBack('c');
    test.pushAtBack('d');
    assert(test.size() == 4);
    assert(test.toString() == "[CharLinkedList of size 4 <<abcd>>]");
}


// PUSH AT FRONT TESTS //
void pushfront_one_empty() {
    CharLinkedList test;
    test.pushAtFront('a');
    assert(test.size() == 1);
    assert(test.toString() == "[CharLinkedList of size 1 <<a>>]");
}

void pushfront_one_singleton() {
    CharLinkedList test('a');
    test.pushAtFront('b');
    assert(test.size() == 2);
    assert(test.toString() == "[CharLinkedList of size 2 <<ba>>]");
}

void pushfront_one_large() {
    char list[4] = {'a', 'b', 'c', 'd'};
    CharLinkedList test(list, 4);
    test.pushAtFront('e');
    assert(test.size() == 5);
    assert(test.toString() == "[CharLinkedList of size 5 <<eabcd>>]");
}

void pushfront_multiple() {
    CharLinkedList test;
    test.pushAtFront('a');
    test.pushAtFront('b');
    test.pushAtFront('c');
    test.pushAtFront('d');
    assert(test.size() == 4);
    assert(test.toString() == "[CharLinkedList of size 4 <<dcba>>]");
}

// INSERTAT TESTS by Tyler Calabrese, January 2021
// edited by: Milod Kazerounian, January 2022
// Tests correct insertion into an empty AL.
// Afterwards, size should be 1 and element at index 0
// should be the element we inserted.
void insertAt_empty_correct() { 

    CharLinkedList test_list;
    test_list.insertAt('a', 0);
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');

}

// Tests incorrect insertion into an empty AL.
// Attempts to call insertAt for index larger than 0.
// This should result in an std::range_error being raised.
void insertAt_empty_incorrect() {

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    // insertAt for out-of-range index
    test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
    // if insertAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    range_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0]");
    
}

// Tests correct insertAt for front of 1-element list.
void insertAt_front_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at front
    test_list.insertAt('b', 0);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'a');
    
}

// Tests correct insertAt for back of 1-element list.
void insertAt_back_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at back
    test_list.insertAt('b', 1);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    
}

// Tests calling insertAt for a large number of elements.
// Not only does this test insertAt, it also checks that
// array expansion works correctly.
void insertAt_many_elements() {
    
    CharLinkedList test_list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.insertAt('a', i);
    }

    assert(test_list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
    
}

// Tests insertion into front of a larger list
void insertAt_front_large_list() {
    char test_arr[9] = {'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    test_list.insertAt('y', 0);

    assert(test_list.size() == 10);
    assert(test_list.elementAt(0) == 'y');
    assert(test_list.toString() 
    == "[CharLinkedList of size 10 <<yabczdefgh>>]");

}

// Tests insertion into the back of a larger list
void insertAt_back_large_list() {

    char test_arr[10] = { 'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 10);  

    test_list.insertAt('x', 10);

    assert(test_list.size() == 11);
    assert(test_list.elementAt(10) == 'x');
    assert(test_list.toString() == 
    "[CharLinkedList of size 11 <<yabczdefghx>>]"); 

}

// Tests insertion into the middle of a larger list
void insertAt_middle_large_list() {
    char test_arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.insertAt('z', 3);

    assert(test_list.size() == 9);
    assert(test_list.elementAt(3) == 'z');
    assert(test_list.toString() == "[CharLinkedList of size 9 <<abczdefgh>>]");

}

// Tests out-of-range insertion for a non-empty list.
void insertAt_nonempty_incorrect() {
   
    char test_arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8]");
} 

// INSERT IN ORDER TESTS //
void single_order_test_empty() {
    CharLinkedList test;
    test.insertInOrder('a');
    std::cout << test.toString();
    assert(test.toString() == "[CharLinkedList of size 1 <<a>>]");
}

void multiple_order_test_empty() {
    CharLinkedList test;
    test.insertInOrder('a');
    test.insertInOrder('d');
    test.insertInOrder('c');
    test.insertInOrder('a');
    test.insertInOrder('c');
    test.insertInOrder('d');
    test.insertInOrder('c');
    std::cout << test.toString();
    assert(test.toString() == "[CharLinkedList of size 7 <<aacccdd>>]");
}

void multiple_order_test_large() {
    char list[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test(list, 8);
    test.insertInOrder('a');
    test.insertInOrder('c');
    test.insertInOrder('z');
    std::cout << test.toString();
    assert(test.toString() == "[CharLinkedList of size 11 <<aabccdefghz>>]");
}

// POP TESTS //
void popfront_empty() {
    CharLinkedList test;
    std::stringstream ss;
    bool error_thrown = false;
    try {
        test.popFromFront();
    }
    catch(const std::runtime_error &e) {
        ss << e.what();
        error_thrown = true;
    }
    assert(error_thrown);
    assert(ss.str() == "cannot pop from empty LinkedList");
}

void popback_empty() {
    CharLinkedList test;
    std::stringstream ss;
    bool error_thrown = false;
    try {
        test.popFromBack();
    }
    catch(const std::runtime_error &e) {
        ss << e.what();
        error_thrown = true;
    }
    assert(error_thrown);
    assert(ss.str() == "cannot pop from empty LinkedList");
}

void popfront_singleton() {
    CharLinkedList test('a');
    test.popFromFront();
    assert(test.isEmpty());
}

void popback_singleton() {
    CharLinkedList test('a');
    test.popFromBack();
    assert(test.isEmpty());
}

void popfront_large() {
    char list[4] = {'a', 'b', 'c', 'd'};
    CharLinkedList test(list, 4);
    test.popFromFront();
    std::cout << test.toString();
    assert(test.toString() == "[CharLinkedList of size 3 <<bcd>>]");
}

void popback_large() {
    char list[4] = {'a', 'b', 'c', 'd'};
    CharLinkedList test(list, 4);
    test.popFromBack();
    std::cout << test.toString();
    assert(test.toString() == "[CharLinkedList of size 3 <<abc>>]");
}

void pop_multiple() {
    char list[9] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i'};
    CharLinkedList test(list, 9);
    test.popFromBack();
    test.popFromFront();
    test.popFromBack();
    test.popFromFront();
    std::cout << test.toString();
    assert(test.toString() == "[CharLinkedList of size 5 <<cdefg>>]");
}


// REMOVE AT TESTS //
void remove_empty() {
    CharLinkedList test;
    std::stringstream ss;
    bool error_thrown = false;
    try {
        test.removeAt(0);
    }
    catch(const std::range_error &e) {
        ss << e.what();
        error_thrown = true;
    }
    assert(error_thrown);
    assert(ss.str() == "index (0) not in range [0..0)");
}

void remove_low() {
    char list[9] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i'};
    CharLinkedList test(list, 9);
    std::stringstream ss;
    bool error_thrown = false;
    try {
        test.removeAt(-1);
    }
    catch(const std::range_error &e) {
        ss << e.what();
        error_thrown = true;
    }
    assert(error_thrown);
    assert(ss.str() == "index (-1) not in range [0..9)");
}

void remove_high() {
    char list[9] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i'};
    CharLinkedList test(list, 9);
    std::stringstream ss;
    bool error_thrown = false;
    try {
        test.removeAt(9);
    }
    catch(const std::range_error &e) {
        ss << e.what();
        error_thrown = true;
    }
    assert(error_thrown);
    assert(ss.str() == "index (9) not in range [0..9)");
}

void remove_singleton() {
    CharLinkedList test('a');
    test.removeAt(0);
    assert(test.isEmpty());
}

void front_remove_large() {
    char list[9] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i'};
    CharLinkedList test(list, 9);
    test.removeAt(0);
    assert(test.size() == 8);
    assert(test.toString() == "[CharLinkedList of size 8 <<bcdefghi>>]");
}

void back_remove_large() {
    char list[9] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i'};
    CharLinkedList test(list, 9);
    test.removeAt(8);
    assert(test.size() == 8);
    assert(test.toString() == "[CharLinkedList of size 8 <<abcdefgh>>]");
}

void mid_remove_large() {
    char list[9] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i'};
    CharLinkedList test(list, 9);
    test.removeAt(5);
    assert(test.size() == 8);
    assert(test.toString() == "[CharLinkedList of size 8 <<abcdeghi>>]");
}

void multi_remove_large() {
    char list[9] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i'};
    CharLinkedList test(list, 9);
    test.removeAt(0);
    test.removeAt(5);
    test.removeAt(4);
    test.removeAt(5);
    assert(test.size() == 5);
    std::cout << test.toString();
    assert(test.toString() == "[CharLinkedList of size 5 <<bcdeh>>]");
}

// REPLACE TESTS //
void replace_empty() {
    CharLinkedList test;
    std::stringstream ss;
    bool error_thrown = false;
    try {
        test.replaceAt('a', 0);
    }
    catch(const std::range_error &e) {
        ss << e.what();
        error_thrown = true;
    }
    assert(error_thrown);
    assert(ss.str() == "index (0) not in range [0..0)");
}

void replace_low() {
    char list[9] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i'};
    CharLinkedList test(list, 9);
    std::stringstream ss;
    bool error_thrown = false;
    try {
        test.replaceAt('a', -1);
    }
    catch(const std::range_error &e) {
        ss << e.what();
        error_thrown = true;
    }
    assert(error_thrown);
    assert(ss.str() == "index (-1) not in range [0..9)");
}

void replace_high() {
    char list[9] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i'};
    CharLinkedList test(list, 9);
    std::stringstream ss;
    bool error_thrown = false;
    try {
        test.replaceAt('a', 9);
    }
    catch(const std::range_error &e) {
        ss << e.what();
        error_thrown = true;
    }
    assert(error_thrown);
    assert(ss.str() == "index (9) not in range [0..9)");
}

void replace_singlton() {
    CharLinkedList test('a');
    test.replaceAt('b', 0);
    assert(test.size() == 1);
    assert(test.first() == 'b');
}

void front_replace_large() {
    char list[9] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i'};
    CharLinkedList test(list, 9);
    test.replaceAt('1', 0);
    assert(test.size() == 9);
    assert(test.toString() == "[CharLinkedList of size 9 <<1bcdefghi>>]");
}

void back_replace_large() {
    char list[9] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i'};
    CharLinkedList test(list, 9);
    test.replaceAt('9', 8);
    assert(test.size() == 9);
    assert(test.toString() == "[CharLinkedList of size 9 <<abcdefgh9>>]");
}

void mid_replace_large() {
    char list[9] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i'};
    CharLinkedList test(list, 9);
    test.replaceAt('4', 3);
    assert(test.size() == 9);
    assert(test.toString() == "[CharLinkedList of size 9 <<abc4efghi>>]");
}

void multi_replace_large() {
    char list[9] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i'};
    CharLinkedList test(list, 9);
    test.replaceAt('0', 0);
    test.replaceAt('1', 1);
    test.replaceAt('8', 8);
    test.replaceAt('7', 7);
    assert(test.size() == 9);
    assert(test.toString() == "[CharLinkedList of size 9 <<01cdefg78>>]");
}

// CONCATANATE TESTS //
void empty_concatenate_none() {
    CharLinkedList test;
    test.concatenate(nullptr);
    assert(test.isEmpty());
}

void singleton_concatenate_none() {
    CharLinkedList test('a');
    test.concatenate(nullptr);
    assert(test.size() == 1);
    assert(test.first() == 'a');
}

void large_concatenate_none() {
    char list[9] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i'};
    CharLinkedList test(list, 9);
    test.concatenate(nullptr);
    assert(test.size() == 9);
    assert(test.toString() == "[CharLinkedList of size 9 <<abcdefghi>>]");
}

void empty_concatenate_empty() {
    CharLinkedList test;
    CharLinkedList copy;
    test.concatenate(&copy);
    assert(test.isEmpty());
    assert(test.toString() == "[CharLinkedList of size 0 <<>>]");
}

void singleton_concatenate_empty() {
    CharLinkedList test('a');
    CharLinkedList copy;
    test.concatenate(&copy);
    assert(test.size() == 1);
    assert(test.first() == 'a');
    assert(test.toString() == "[CharLinkedList of size 1 <<a>>]");
}

void large_concatenate_empty() {
    char list[9] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i'};
    CharLinkedList test(list, 9);
    CharLinkedList copy;
    test.concatenate(&copy);
    assert(test.size() == 9);
    assert(test.toString() == "[CharLinkedList of size 9 <<abcdefghi>>]");
}

void empty_concatenate_singleton() {
    CharLinkedList test;
    CharLinkedList copy('a');
    test.concatenate(&copy);
    assert(test.size() == 1);
    assert(test.toString() == "[CharLinkedList of size 1 <<a>>]");
}

void singleton_concatenate_singleton() {
    CharLinkedList test('b');
    CharLinkedList copy('a');
    test.concatenate(&copy);
    assert(test.size() == 2);
    assert(test.toString() == "[CharLinkedList of size 2 <<ba>>]");
}

void large_concatenate_singleton() {
    char list[9] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i'};
    CharLinkedList test(list, 9);
    CharLinkedList copy('z');
    test.concatenate(&copy);
    assert(test.size() == 10);
    assert(test.toString() == "[CharLinkedList of size 10 <<abcdefghiz>>]");
}

void empty_concatenate_large() {
    char list2[9] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i'};
    CharLinkedList copy(list2, 9);
    CharLinkedList test;
    test.concatenate(&copy);
    assert(test.size() == 9);
    assert(test.toString() == "[CharLinkedList of size 9 <<abcdefghi>>]");
}

void singleton_concatenate_large() {
    char list2[9] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i'};
    CharLinkedList copy(list2, 9);
    CharLinkedList test('z');
    test.concatenate(&copy);
    assert(test.size() == 10);
    assert(test.toString() == "[CharLinkedList of size 10 <<zabcdefghi>>]");
}

void large_concatenate_large() {
    char list[4] = {'1', '2', '3', '4'};
    char list2[9] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i'};
    CharLinkedList copy(list2, 9);
    CharLinkedList test(list, 4);
    test.concatenate(&copy);
    assert(test.size() == 13);
    assert(test.toString() == "[CharLinkedList of size 13 <<1234abcdefghi>>]");
}

void empty_concatenate_self() {
    CharLinkedList test;
    test.concatenate(&test);
    assert(test.isEmpty());
}

void singleton_concatenate_self() {
    CharLinkedList test('a');
    test.concatenate(&test);
    assert(test.size() == 2);
    assert(test.toString() == "[CharLinkedList of size 2 <<aa>>]");
}

void large_concatenate_self() {
    char list[9] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i'};
    CharLinkedList test(list, 9);
    test.concatenate(&test);
    assert(test.size() == 18);
    assert(test.toString() 
    == "[CharLinkedList of size 18 <<abcdefghiabcdefghi>>]");
}
/*
 *  unit_tests.h
 *  Tasnim Hossain
 *  February 3rd, 2023
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  Uses Matt Russell's unit_test framework to test the CharLinkedList class.
 *
 */

#include "CharLinkedList.h"
#include <cassert>
#include <iostream>

/********************************************************************\
*                       CHAR ARRAY LIST TESTS                        *
\********************************************************************/

void empty_constructor()
{
    CharLinkedList list;
    assert(list.size() == 0);
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}
void one_element_constructor()
{
    CharLinkedList list('c');
    assert(list.size() == 1);
    assert(list.toString() == list.toReverseString());
}
void empty_constructor_arr()
{
    char arr[] = {};
    CharLinkedList list(arr, 0);
    assert(list.size() == 0);
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
    assert(list.toReverseString() == "[CharLinkedList of size 0 <<>>]");
}
void constructor_arr()
{
    char arr[] = {'a', 'b', 'c', 'd', 'e', 'f', 'g'};
    CharLinkedList list(arr, 7);
    assert(list.size() == 7);
    assert(list.toString() == "[CharLinkedList of size 7 <<abcdefg>>]");
    assert(list.toReverseString() == "[CharLinkedList of size 7 <<gfedcba>>]");
}

void first_last_empty()
{
    bool first_runtime_error_thrown = false;
    bool last_runtime_error_thrown = false;
    std::string first_error_message = "";
    std::string last_error_message = "";
    CharLinkedList list;
    try
    {
        list.first();
    }
    catch (const std::runtime_error &e)
    {
        first_runtime_error_thrown = true;
        first_error_message = e.what();
    }
    assert(first_runtime_error_thrown);
    assert(first_error_message == "cannot get first of empty LinkedList");

    try
    {
        list.last();
    }
    catch (const std::runtime_error &e)
    {
        last_runtime_error_thrown = true;
        last_error_message = e.what();
    }
    assert(last_runtime_error_thrown);
    assert(last_error_message == "cannot get last of empty LinkedList");
}

void push_front_empty()
{
    CharLinkedList list;
    list.pushAtFront('a');
    assert(list.toReverseString() == list.toString());
    assert(list.size() == 1);
}
void push_back_empty()
{
    CharLinkedList list;
    list.pushAtBack('z');
    assert(list.toReverseString() == list.toString());
    assert(list.size() == 1);
}
void push_nonempty()
{
    char arr1[] = {'a', 'l', 'i', 'c', 'e'};
    CharLinkedList list(arr1, 5);
    list.pushAtBack('s');
    assert(list.toString() == "[CharLinkedList of size 6 <<alices>>]");
    list.pushAtFront('m');
    assert(list.toString() == "[CharLinkedList of size 7 <<malices>>]");
    assert(list.size() == 7);
}

void insertAt_in_bound()
{
    char arr1[] = {'a', 'l', 'i', 'c', 'e'};
    CharLinkedList list(arr1, 5);
    list.insertAt('X', 2);
    assert(list.toString() == "[CharLinkedList of size 6 <<alXice>>]");
    list.insertAt('X', list.size());
    std::cout << list.toString() << std::endl;
    assert(list.toString() == "[CharLinkedList of size 7 <<alXiceX>>]");
}

void insertAt_out_of_range()
{
    char arr1[] = {'a', 'l', 'i', 'c', 'e'};
    CharLinkedList list(arr1, 5);
    bool range_error_thrown = false;
    std::string error_message = "";
    try
    {
        list.insertAt('X', 7);
    }
    catch (const std::range_error &e)
    {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (7) not in range [0..5]");
}

void inserAt_zero()
{
    char arr1[] = {'a', 'l', 'i', 'c', 'e'};
    CharLinkedList list(arr1, 5);
    CharLinkedList list1;
    list.insertAt('M', 0);
    assert(list.toString() == "[CharLinkedList of size 6 <<Malice>>]");

    list1.insertAt('M', 0);
    assert(list1.toString() == "[CharLinkedList of size 1 <<M>>]");
}

void pop_front_non_empty()
{
    char arr1[] = {'a', 'l', 'i', 'c', 'e'};
    CharLinkedList list(arr1, 5);
    list.popFromFront();
    assert(list.size() == 4);
    assert(list.toString() == "[CharLinkedList of size 4 <<lice>>]");
}
void pop_front_empty()
{
    bool runtime_error_thrown = false;
    std::string error_message = "";
    CharLinkedList list;
    try
    {
        list.popFromFront();
    }
    catch (const std::runtime_error &e)
    {
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

void pop_back_non_empty()
{
    char arr1[] = {'a', 'l', 'i', 'c', 'e'};
    CharLinkedList list(arr1, 5);
    list.popFromBack();
    assert(list.size() == 4);
    assert(list.toString() == "[CharLinkedList of size 4 <<alic>>]");
}
void pop_back_empty()
{
    bool runtime_error_thrown = false;
    std::string error_message = "";
    CharLinkedList list;
    try
    {
        list.popFromBack();
    }
    catch (const std::runtime_error &e)
    {
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

void removeAt_correct()
{
    char arr1[] = {'a', 'l', 'i', 'c', 'e'};
    CharLinkedList list(arr1, 5);
    list.removeAt(0);
    assert(list.toString() == "[CharLinkedList of size 4 <<lice>>]");
    assert(list.size() == 4);
    list.removeAt(list.size() - 1);
    assert(list.toString() == "[CharLinkedList of size 3 <<lic>>]");
    assert(list.size() == 3);
    assert(list.first() == 'l');

    char arr[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList test_list(arr, 5);
    test_list.removeAt(3);
    assert(test_list.toString() == "[CharLinkedList of size 4 <<abde>>]");
}

void removeAt_empty()
{
    bool range_error_thrown = false;
    std::string error_message = "";
    CharLinkedList list;
    try
    {
        list.removeAt(0);
    }
    catch (const std::range_error &e)
    {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (0) not in range [0..0)");
}

void removeAt_out_of_range()
{
    bool range_error_thrown = false;
    std::string error_message = "";
    char arr[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(arr, 5);
    try
    {
        list.removeAt(6);
    }
    catch (const std::range_error &e)
    {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (6) not in range [0..5)");
}

void is_empty_and_clear()
{
    char arr[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(arr, 5);
    assert(not list.isEmpty());
    list.clear();
    assert(list.size() == 0);
    assert(list.isEmpty());
}

void isEmpty_clear_on_empty()
{
    CharLinkedList list;
    assert(list.isEmpty());
    assert(list.size() == 0);
    list.clear();
    assert(list.size() == 0);
}

void replace_at_front()
{
    char arr[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(arr, 5);
    list.replaceAt('X', 0);
    assert(list.size() == 5);
    assert(list.elementAt(0) == 'X');
}

void replace_at_end()
{
    char arr[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(arr, 5);
    list.replaceAt('X', 4);
    assert(list.size() == 5);
    assert(list.elementAt(4) == 'X');
}
void replace_at_middle()
{
    char arr[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(arr, 5);
    list.replaceAt('X', 2);
    assert(list.size() == 5);
    assert(list.elementAt(2) == 'X');
}
void replace_out_of_range()
{
    bool range_error_thrown = false;
    std::string error_message = "";
    char arr[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(arr, 5);
    try
    {
        list.replaceAt('X', 42);
    }
    catch (const std::range_error &e)
    {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..5)");
}
void concat_nonempty_with_empty()
{
    char arr[] = {'C', 'H', 'E', 'S', 'H', 'I', 'R', 'E'};
    CharLinkedList list(arr, 8);
    CharLinkedList other;
    list.concatenate(&other);
    assert(list.size() == 8);
    assert(list.toString() == "[CharLinkedList of size 8 <<CHESHIRE>>]");
}
void concat_empty_with_empty()
{
    CharLinkedList list;
    CharLinkedList other;
    list.concatenate(&other);
    assert(list.size() == 0);
    assert(list.toString() == list.toReverseString());
}
void concat_nonempty_with_nonempty()
{
    char arr[8] = {'C', 'H', 'E', 'S', 'H', 'I', 'R', 'E'};
    char arr2[3] = {'C', 'A', 'T'};
    CharLinkedList list(arr, 8);
    CharLinkedList other(arr2, 3);
    list.concatenate(&other);
    assert(list.size() == 11);
    assert(list.toString() == "[CharLinkedList of size 11 <<CHESHIRECAT>>]");
}
void concat_nonempty_self()
{
    char arr[3] = {'C', 'A', 'T'};
    CharLinkedList list(arr, 3);
    list.concatenate(&list);
    assert(list.size() == 6);
    assert(list.toString() == "[CharLinkedList of size 6 <<CATCAT>>]");
}

void concat_empty_self()
{
    CharLinkedList list;
    list.concatenate(&list);
    assert(list.size() == 0);
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}

void order_insert_first()
{
    char arr[5] = {'b', 'c', 'e', 'f', 'g'};
    CharLinkedList list(arr, 5);
    list.insertInOrder('a');
    assert(list.first() == 'a');
    assert(list.size() == 6);
}

void order_insert_last()
{
    char arr[5] = {'b', 'c', 'e', 'f', 'g'};
    CharLinkedList list(arr, 5);
    list.insertInOrder('z');
    assert(list.last() == 'z');
    assert(list.size() == 6);
}

void order_insert_middle()
{
    char arr[5] = {'b', 'c', 'g', 'k', 'e'};
    CharLinkedList list(arr, 5);
    list.insertInOrder('f');
    assert(list.toString() == "[CharLinkedList of size 6 <<bcfgke>>]");
    assert(list.size() == 6);
}

void order_insert_empty()
{
    CharLinkedList list;
    list.insertInOrder('X');
    assert(list.size() == 1);
    assert(list.toString() == list.toReverseString());
}

void elementAt_wrong()
{
    bool range_error_thrown = false;
    std::string error_message = "";
    CharLinkedList list;
    try
    {
        list.elementAt(5);
    }
    catch (const std::range_error &e)
    {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (5) not in range [0..0)");
}
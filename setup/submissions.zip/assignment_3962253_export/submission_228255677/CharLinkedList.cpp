/*
 *  CharLinkedList.cpp
 *  YOUR NAME HERE
 *  DATE CREATED
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  this file implement the methods for the CharLinkedList class
 *
 */

#include "CharLinkedList.h"
#include <stdexcept>
#include <iostream>
#include <sstream>
using namespace std;
/*
 * name:      Linked List default constructor
 * purpose:   initialize an empty Linked List
 * arguments: none
 * returns:   none
 * effects:   numItems to 0 (also updates front of list)
 */
CharLinkedList::CharLinkedList()
{
    numItems = 0;
    front = nullptr;
}
/*
 * name:      Linked List constructor
 * purpose:   initilize an one Node Linked List
 * arguments: a character to put in array
 * returns:   none
 * effects:   numItems to 1 (also updates front of list)
 */
CharLinkedList::CharLinkedList(char c)
{
    numItems = 1;
    Node *data = new Node;
    data->character = c;
    data->next = nullptr;
    data->prev = nullptr;
    front = data;
}

/*
 * name:      Linked List constructor
 * purpose:   intililizes an array with the elements from input array
 * arguments: character array to copy into Linked List and the size of
 *            numbers of elements to copy from input to the Linked List
 * returns:   none
 * effects:   numItems set to size, data set to arr (also updates front)
 */
CharLinkedList::CharLinkedList(char arr[], int size)
{
    numItems = size;
    int index = 0;
    front = nullptr;
    buildList(arr, size, index);
}

/*
 * name:      Linked List copy constructor
 * purpose:   initilizes a new instance of CharLinkedList identical to other
 * arguments: an CharLinkedList Linked List pointer to copy
 * returns:   none
 * effects:   copies all attributes and initizes it as a new CharLinkedList
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other)
{
    // copy front and size
    numItems = other.numItems;
    front = nullptr;

    if (numItems > 0)
    {
        front = new Node;
        front->character = other.front->character;
        front->prev = nullptr;
        front->next = nullptr;

        Node *curr = front;
        Node *curr_next = other.front->next;
        while (curr_next != nullptr)
        {
            // copy the next and previous nodes in the list
            curr->next = new Node;
            curr->next->character = curr_next->character;
            curr->next->prev = curr;

            // movet the current and current next node over by one
            curr->next->next = nullptr;
            curr = curr->next;
            curr_next = curr_next->next;
        }
    }
}

/*
 * name:      Linked List destructor
 * purpose:   free memory associated with the Linked List
 * arguments: none
 * returns:   none
 * effects:   frees memory allocated by Linked List instances
 */
CharLinkedList::~CharLinkedList()
{
    recycle(front);
}

/*
 * name:      operator
 * purpose:   deep copy the values from other to another existing instance of
 *            CharLinkedList
 * arguments: CharLinkedList memory adress to copy
 * returns:   refernece to the front of the deep copied linked list
 * effects:   deallocates the existing memeory to the existin Linked List being
 *            made a copy of other and reallocates the memory to adreses of the
 *            elements in other
 */
CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other)
{
    if (this != &other)
    {
        recycle(this->front);
        numItems = other.numItems;
        front = nullptr;

        if (numItems > 0)
        {
            front = new Node;
            front->character = other.front->character;
            front->prev = nullptr;
            front->next = nullptr;

            Node *curr = front;
            Node *curr_next = other.front->next;
            while (curr_next != nullptr)
            {
                // copy the next and previous nodes in the list
                curr->next = new Node;
                curr->next->character = curr_next->character;
                curr->next->prev = curr;

                // movet the current and current next node over by one
                curr->next->next = nullptr;
                curr = curr->next;
                curr_next = curr_next->next;
            }
        }
    }
    return *this;
}
/*
 * name:      isEmpty
 * purpose:   determines if the Linked List is empty or not
 * arguments: none
 * returns:   true if Linked List contains no Nodes, false otherwise
 * effects:   none
 */
bool CharLinkedList::isEmpty() const
{
    if (numItems == 0)
    {
        return true;
    }
    else
    {
        return false;
    }
}

/*
 * name:      clear
 * purpose:   clears all elements an Linked List
 * arguments: none
 * returns:   none
 * effects:   deallocates memeory for existing elements in the array
 */
void CharLinkedList::clear()
{
    recycle(front);
    numItems = 0;
    front = nullptr;
}

/*
 * name:      size
 * purpose:   determines the number of elements in an Linked List
 * arguments: none
 * returns:   an integer value of the number of elements. 0 if and
 *            and only if the array is empty
 * effects:   none
 */
int CharLinkedList::size() const
{
    return numItems;
}

/*
 * name:      first
 * purpose:   locate the first element in the Linked List
 * arguments: none
 * returns:   the first character in the Linked List
 * effects:   none
 */
char CharLinkedList::first() const
{
    if (numItems == 0)
    {
        throw std::runtime_error("cannot get first of empty LinkedList");
    }
    return front->character;
}

/*
 * name:      last
 * purpose:   locate the last element in the Linked List
 * arguments: none
 * returns:   the last character in the Linked List
 * effects:   none
 */
char CharLinkedList::last() const
{
    if (numItems == 0)
    {
        throw std::runtime_error("cannot get last of empty LinkedList");
    }
    Node *curr = front;
    while (curr->next != nullptr)
    {
        curr = curr->next;
    }
    return curr->character;
}

/*
 * name:      elementAt
 * purpose:   locate and return the element in the Linked List at the
 *            specified index
 * arguments: integer index of the element being searched for
 * returns:   none
 * effects:   none
 */
char CharLinkedList::elementAt(int index) const
{
    if (index < 0 or index >= numItems)
    {
        throw std::range_error("index (" + std::to_string(index) +
                               ") not in range " +
                               "[0.." + std::to_string(numItems) + ")");
    }
    return elementAtHelper(front, index);
}
/*
 * name:      elementAtHelper
 * purpose:   recursively locates the element at the given index
 * arguments: integer number of index and the startiung Node of the linked list
 * returns:   the character at the index
 * effects:   none
 */
char CharLinkedList::elementAtHelper(Node *curr, int index) const
{
    if (curr == nullptr)
    {
        throw std::range_error("index (" + std::to_string(index) +
                               ") not in range " +
                               "[0.." + std::to_string(numItems) + ")");
    }
    if (index == 0)
    {
        return curr->character;
    }
    return elementAtHelper(curr->next, index - 1);
}

/*
 * name:      toString
 * purpose:   turn the Linked List into a string and return it
 * arguments: none
 * returns:   a string representation of the Linked List
 * effects:   none
 */
std::string CharLinkedList::toString() const
{
    if (front == nullptr)
    {
        return "[CharLinkedList of size " +
               std::to_string(numItems) + " <<>>]";
    }
    Node *curr = front;
    std::stringstream ss;
    ss << "[CharLinkedList of size " +
              std::to_string(numItems) + " <<";
    while (curr != nullptr)
    {
        ss << curr->character;
        curr = curr->next;
    }
    ss << ">>]";
    return ss.str();
}

/*
 * name:      toReverseString
 * purpose:   turn the Linked List into a string in reverse order and return it
 * arguments: none
 * returns:   a string representation of the reserve of the Linked List
 * effects:   none
 */
std::string CharLinkedList::toReverseString() const
{
    if (front == nullptr)
    {
        return "[CharLinkedList of size " +
               std::to_string(numItems) + " <<>>]";
    }
    Node *last = front;
    while (last->next != nullptr)
    {
        last = last->next;
    }

    Node *curr = last;
    std::stringstream ss;
    ss << "[CharLinkedList of size " + std::to_string(numItems) + " <<";

    while (curr != nullptr)
    {
        ss << curr->character;
        curr = curr->prev;
    }
    ss << ">>]";
    return ss.str();
}

/*
 * name:      pushAtBack
 * purpose:   insert element in at the end of the Linked List
 * arguments: character to be inserted
 * returns:   none
 * effects:   increments numItems, updates list
 */
void CharLinkedList::pushAtBack(char c)
{
    Node *newNode = new Node;
    newNode->character = c;
    newNode->next = nullptr;
    if (front == nullptr)
    {
        newNode->prev = nullptr;
        front = newNode;
        numItems++;
    }
    else
    {
        Node *curr = front;
        while (curr->next != nullptr)
        {
            curr = curr->next;
        }
        curr->next = newNode;
        newNode->prev = curr;
        numItems++;
    }
}

/*
 * name:      pushAtFront
 * purpose:   insert element in at the begining of the Linked List
 * arguments: character to be inserted
 * returns:   none
 * effects:   increments numItems, updates list
 */
void CharLinkedList::pushAtFront(char c)
{
    Node *newNode = new Node;
    newNode->prev = nullptr;
    newNode->character = c;
    if (front == nullptr)
    {
        newNode->next = nullptr;
        front = newNode;
        numItems++;
    }
    else
    {
        Node *curr = front;
        front = newNode;
        newNode->next = curr;
        numItems++;
    }
}

/*
 * name:      insertAt
 * purpose:   inserts element into the specified index in an Linked List
 * arguments: character to be inserted and the index at which insertion
 *            happens
 * returns:   none
 * effects:   increments numitems and updates list
 */
void CharLinkedList::insertAt(char c, int index)
{
    if (index < 0 or index > numItems)
    {
        throw std::range_error("index (" + std::to_string(index) +
                               ") not in range [0.." +
                               std::to_string(numItems) + "]");
    }
    if (index == 0)
    {
        pushAtFront(c);
    }
    else if (index == numItems)
    {
        pushAtBack(c);
    }
    else
    {
        Node *newNode = new Node;
        Node *curr = front;
        newNode->character = c;
        int curr_index = 0;
        while (curr_index < index - 1)
        {
            curr = curr->next;
            curr_index++;
        }
        Node *temp_next = curr->next;
        curr->next = newNode;
        newNode->next = temp_next;
        newNode->prev = curr;
        temp_next->prev = newNode;
        numItems++;
    }
}

/*
 * name:      insertInOrder
 * purpose:   inserts element c after the first element in the
 *            Linked List that comes before c in the ASCII table
 * arguments: character c to insert into Linked List
 * returns:   none
 * effects:   increments numItems and updates list
 */
void CharLinkedList::insertInOrder(char c)
{
    if (front == nullptr)
    {
        pushAtFront(c);
        return;
    }
    Node *curr = front;
    int counter = 0;
    while (curr != nullptr and curr->character < c)
    {
        curr = curr->next;
        counter++;
    }
    if (curr == nullptr)
    {
        pushAtBack(c);
    }
    else
    {
        insertAt(c, counter);
    }
}

/*
 * name:      popFromBack
 * purpose:   Removes the very last element in the Linked List
 * arguments: none
 * returns:   none
 * effects:   decrements numItems
 */
void CharLinkedList::popFromBack()
{
    if (front == nullptr)
    {
        throw std::runtime_error("cannot pop from empty LinkedList");
    }
    else if (front->next == nullptr)
    {
        delete front;
        front = nullptr;
    }
    else
    {
        Node *curr = front;
        // find secodn to last item on the list
        while (curr->next->next != nullptr)
        {
            curr = curr->next;
        }
        delete curr->next;
        curr->next = nullptr;
    }
    numItems--;
}

/*
 * name:      popFromFront
 * purpose:   removes the very first element in the Linked List
 * arguments: none
 * returns:   none
 * effects:   shifts all elements beyond index 0 to the left by one
 *            decrements numItems
 */
void CharLinkedList::popFromFront()
{
    // empty list
    if (front == nullptr)
    {
        throw std::runtime_error("cannot pop from empty LinkedList");
    }

    Node *curr = front->next;
    delete front;
    if (curr != nullptr)
    {
        curr->prev = nullptr;
    }
    front = curr;
    numItems--;
}

/*
 * name:      removeAt
 * purpose:   removes the element at specified index
 * arguments: integer index value of the character to be removed
 * returns:   none
 * effects:   shifts all elements beyond index to the left by one,
 *            decrements numItems
 */
void CharLinkedList::removeAt(int index)
{
    if (index < 0 or index >= numItems)
    {
        throw std::range_error("index (" + std::to_string(index) +
                               ") not in range [0.." +
                               std::to_string(numItems) + ")");
    }
    if (index == numItems - 1)
    {
        popFromBack();
        return;
    }
    if (index == 0)
    {
        popFromFront();
        return;
    }
    Node *curr = front;
    int counter = 0;
    while (counter != index - 1)
    {
        curr = curr->next;
        counter++;
    }
    curr->prev->next = curr->next;
    curr->next->prev = curr->prev;
    delete curr;
    numItems--;
}

/*
 * name:      replaceAt
 * purpose:   replace the element at position index with c
 * arguments: the index number of where to replace. character c
 *            for what to replace element with
 * returns:   none
 * effects:   the pointer at position index changed to point to
 *            c
 */
void CharLinkedList::replaceAt(char c, int index)
{
    if (index < 0 or index >= numItems)
    {
        throw std::range_error("index (" + std::to_string(index) +
                               ") not in range [0.." +
                               std::to_string(numItems) + ")");
    }
    replaceHelper(front, c, index, 0);
}

/*
 * name:      replaceAtHelper
 * purpose:   recursively locates the letter to replace
 * arguments: the starting node, charcter to replace, index of the
 *            where the replacement happens and the starting index
 * returns:   none
 * effects:   the node at position index now points to input character
 */
void CharLinkedList::replaceHelper(Node *curr, char c, int index, int start)
{
    if (start == index)
    {
        curr->character = c;
        return;
    }
    replaceHelper(curr->next, c, index, start + 1);
}

/*
 * name:      concatenate
 * purpose:   add the input Linked List other at the end of andother
 *            Linked List
 * arguments: a CharLinkedList to be added
 * returns:   none
 * effects:   the current Linked List gets bigger, numItems gets updated
 */
void CharLinkedList::concatenate(CharLinkedList *other)
{
    if (this->isEmpty())
    {
        *this = *other;
        return;
    }
    if (other->isEmpty())
    {
        return;
    }
    // to avoid infinite loop
    if (this == other)
    {
        CharLinkedList *temp = new CharLinkedList(*other);
        Node *tempCurr = temp->front;
        while (tempCurr != nullptr)
        {
            this->pushAtBack(tempCurr->character);
            tempCurr = tempCurr->next;
        }
        delete temp;
        return;
    }
    int counter = 0;
    Node *curr = other->front;
    while (counter != other->numItems)
    {
        this->pushAtBack(curr->character);
        curr = curr->next;
        counter++;
    }
}
/*
 * name:      buildLisr
 * purpose:   creates a node for each item in the array and recursively
 *            links them
 * arguments: an array of characters, size of the array and starting index
 * returns:   none
 * effects:   the current Linked List gets bigger,
 *            (numItems is updated)
 */
void CharLinkedList::buildList(char arr[], int size, int idx)
{
    if (idx == size)
    {
        return;
    }
    Node *newNode = new Node;
    newNode->character = arr[idx];
    newNode->prev = nullptr;
    newNode->next = nullptr;
    if (front == nullptr)
    {
        front = newNode;
    }
    else
    {
        Node *curr = front;
        while (curr->next != nullptr)
        {
            curr = curr->next;
        }
        curr->next = newNode;
        newNode->prev = curr;
    }
    buildList(arr, size, idx + 1);
}
/*
 * name:      recycle
 * purpose:   recursively iderates through linked list and deletes each node
 * arguments: a node to start deleting at
 * returns:   none
 * effects:   frees up space taken up by nodes of linked lists
 */
void CharLinkedList::recycle(Node *curr)
{
    if (curr == nullptr)
    {
        return;
    }
    else
    {
        Node *next = curr->next;
        delete curr;
        recycle(next);
    }
}
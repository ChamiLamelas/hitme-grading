/*
 *  unit_tests.h
 *  Allison Yu (ayu15)
 *  2/2/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  The purpose of this file is to test the CharLinked List class
 *
 */

#include "CharLinkedList.h"
#include <cassert>

// ************************** CONSTRUCTOR TESTS *************************//

// Tests the default constructor 
// Size should be 0
void default_constructor() {
    CharLinkedList list; 
    assert(list.size() == 0);
}

// Tests the one element constructor
// Size should be 1 and element inserted should be 'b'
void one_element_constructor() {
    CharLinkedList list('b');
    assert(list.size() == 1);
    assert(list.toString() == "[CharLinkedList of size 1 <<b>>]");
}

// Tests the array constructor on a non empty array
// Size should be 5 and nodes should match array contents
void non_empty_array_constructor() {
    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(arr, 5);
    assert(list.size() == 5);
    assert(list.toString() == "[CharLinkedList of size 5 <<abcde>>]");
}

// Tests the array constructor on an empty array
// Size should be 0 and CharLinkedList should be empty
void empty_array_constructor() {
    char arr[0];
    CharLinkedList list(arr, 0);
    assert(list.size() == 0);
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}

// Tests the CharLinkedList parameter constructor on a CharLinkedList that is 
// empty
// Size should be 0 and CharLinkedList should be empty
void empty_CharLinkedList_constructor() {
    CharLinkedList list;
    CharLinkedList list1(list);
    assert(list.size() == 0);
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}

// Tests the CharLinkedList parameter constructor on a CharLinkedList that is 
// not empty
// Size should be 5 and should have a string of 
// "[CharLinkedList of size 5 <<abcde>>]"
void non_empty_CharLinkedList_constructor() {
    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(arr, 5);
    CharLinkedList list1(list);
    assert(list.size() == 5);
    assert(list.toString() == "[CharLinkedList of size 5 <<abcde>>]");
}

// Tests the overloaded assignment operator with a 
// CharLinkedList that is not empty
void non_empty_overloaded_constructor() {
    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list1(arr, 5);

    CharLinkedList list2; 
    // assignment operator gets called here
    list2 = list1; 
    assert(list2.size() == 5);
    for (int i = 0; i < 5; i++) {
        assert(list2.elementAt(i) == list1.elementAt(i));
    }
}

// Tests the overloaded assignment operator 
// with a CharLinkedList that is empty
void empty_overloaded_constructor() {
    CharLinkedList list1;
    CharLinkedList list2; 
    // assignment operator gets called here
    list2 = list1; 
    assert(list2.size() == 0);
}

// Tests the overloaded assignment operator 
// with a the same CharLinkedList 
void same_overloaded_constructor() {
    CharLinkedList list1;
    // assignment operator gets called here
    list1 = list1; 
    assert(list1.size() == 0);
}

// ****************************** ISEMPTY TESTS *****************************//

// Tests the isEmpty function on a nonempty CharLinkedList
// Return false
void non_empty_isEmpty() {
    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(arr, 5);
    assert(not(list.isEmpty()));
}

// Tests the isEmpty function on an empty CharLinkedList
// Return true
void empty_isEmpty() {
    CharLinkedList list;
    assert((list.isEmpty()));
}
 
// ****************************** CLEAR TESTS *****************************//

// Tests the clear function on a non empty CharLinkedList
// Size should be 0
void non_empty_clear() {
    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(arr, 5);
    list.clear(); 
    assert(list.size() == 0);
}

// Tests the clear function on an empty CharLinkedList
// Size should be 0
void empty_clear() {
    CharLinkedList list;
    list.clear(); 
    assert(list.size() == 0);
}

// ****************************** SIZE TESTS *****************************//

// Tests the size function on an empty CharLinkedList
// Size should be 0
void empty_size() {
    CharLinkedList list;
    assert(list.size() == 0);
}

// Tests the size function on a non empty CharLinkedList
// Size should be 5
void non_empty_size() {
    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(arr, 5);
    assert(list.size() == 5);
}

// ****************************** FIRST TESTS *****************************//

// Tests the first function on a non empty CharLinkedList
// Char returned should be 'b'
void non_empty_first() {
    CharLinkedList list('b');
    assert(list.first() == 'b');
}

// Tests the first function on a 1 element CharLinkedList
// Char returned should be 'b'
void one_element_first() {
    CharLinkedList list('b');
    assert(list.first() == 'b');
}

// Tests the first function on an empty CharLinkedList
// runtime error should be thrown
void empty_first() {
    CharLinkedList list;
    
    std::string error_message = "";
    bool runtime_error_thrown = false;
    try {
        char a = list.first();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true; 
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "cannot get first of empty LinkedList");
}

// ****************************** LAST TESTS *****************************//

// Tests the last function on a non empty CharLinkedList
// Char returned should be 'b'
void non_empty_last() {
    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(arr, 5);
    assert(list.last() == 'e');
}

// Tests the last function on a 1 element CharLinkedList
// Char returned should be 'b'
void one_element_last() {
    CharLinkedList list('b');
    assert(list.last() == 'b');
}

// Tests the first function on an empty CharLinkedList
// runtime error should be thrown
void empty_last() {
    CharLinkedList list;
    
    std::string error_message = "";
    bool runtime_error_thrown = false;
    try {
        char a = list.last();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true; 
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "cannot get last of empty LinkedList");
}

// ************************** ELEMENTAT TESTS **************************//

// Tests the range error exception for an index that is too large
// Test should throw an error out of bounds exception
void too_large_index_elementAt() {
    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(arr, 5);  

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        list.elementAt(42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..5)");
}

// Tests the range error exception for an index that is too small
// Test should throw an error out of bounds exception
void too_small_index_elementAt() {
    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(arr, 5);   

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        list.elementAt(-1);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (-1) not in range [0..5)");
}

// Tests the range error exception for an index that is 0 on a list with size 0
// Test should throw an error out of bounds exception
void zero_index_elementAt() {
    CharLinkedList list;   

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        list.elementAt(0);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (0) not in range [0..0)");
}

// Tests the range error exception for an index that is equal to numItems
// Test should throw an error out of bounds exception
void numItems_index_elementAt() {
    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(arr, 5);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        list.elementAt(5);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (5) not in range [0..5)");

}

// Tests the function elementAt with a valid index
// Test should return the correct element at the given index
void valid_index_elementAt() {
    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(arr, 5);

    char a = list.elementAt(2);
    assert(a == 'c');
}

// ************************** TOSTRING TESTS **************************//

// Tests the toString function on a 1 element CharLinkedList
// string returned should be "[CharLinkedList of size 1 <<b>>]""
void one_element_toString() {
    CharLinkedList list('b');
    assert(list.toString() == "[CharLinkedList of size 1 <<b>>]");
}

// Tests the toString function on a non empty CharLinkedList
// string returned should be "[CharLinkedList of size 5 <<abcde>>]""
void non_empty_toString() {
    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(arr, 5);
    assert(list.toString() == "[CharLinkedList of size 5 <<abcde>>]");
}

// Tests the toString function on an empty CharLinkedList
// string returned should be "[CharLinkedList of size 0 <<>>]""
void empty_toString() {
    CharLinkedList list;
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}

// ************************** TOREVERSESTRING TESTS ******************//

// Tests the toReverseString function on a 1 element CharLinkedList
// string returned should be "[CharLinkedList of size 1 <<b>>]""
void one_element_toReverseString() {
    CharLinkedList list('b');
    assert(list.toReverseString() == "[CharLinkedList of size 1 <<b>>]");
}

// Tests the toReverseString function on a non empty CharLinkedList
// string returned should be "[CharLinkedList of size 5 <<edcba>>]"
void non_empty_toReverseString() {
    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(arr, 5);
    assert(list.toReverseString() == "[CharLinkedList of size 5 <<edcba>>]");
}

// Tests the toString function on an empty CharLinkedList
// string returned should be "[CharLinkedList of size 0 <<>>]""
void empty_toReverseString() {
    CharLinkedList list;
    assert(list.toReverseString() == "[CharLinkedList of size 0 <<>>]");
}

// ************************** PUSHATBACK TESTS **************************//

// Tests the pushAtBack function on an empty CharLinkedList
// Size should be 1 and element in CharLinkedList should be 'b'
void empty_pushAtBack() {
    CharLinkedList list;
    list.pushAtBack('b');
    assert(list.size() == 1);
    assert(list.toString() == "[CharLinkedList of size 1 <<b>>]");
}

// Tests the pushAtBack function on 1 element CharLinkedList
// Size should be 2 and conents of CharLinkedList <<cb>>
void one_element_pushAtBack() {
    CharLinkedList list('c');
    list.pushAtBack('b');
    assert(list.size() == 2);
    assert(list.toString() == "[CharLinkedList of size 2 <<cb>>]");
}

// Tests the pushAtBack function on a non empty CharLinkedList
// Size should be 6 and string returned should be 
// "[CharLinkedList of size 6 <<abcdef>>]""
void non_empty_pushAtBack() {
    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(arr, 5);
    list.pushAtBack('f');
    assert(list.size() == 6);
    assert(list.toString() == "[CharLinkedList of size 6 <<abcdef>>]");
}

// ************************** PUSHATFRONT TESTS **************************//

// Tests the pushAtFront function on an empty CharLinkedList
// Size should be 1 and element in CharLinkedList should be 'b'
void empty_pushAtFront() {
    CharLinkedList list;
    list.pushAtFront('b');
    assert(list.size() == 1);
    assert(list.toString() == "[CharLinkedList of size 1 <<b>>]");
}

// Tests the pushAtFront function on 1 element CharLinkedList
// Size should be 2 and conents of CharLinkedList <<bc>>
void one_element_pushAtFront() {
    CharLinkedList list('c');
    list.pushAtFront('b');
    assert(list.size() == 2);
    assert(list.toString() == "[CharLinkedList of size 2 <<bc>>]");
}

// Tests the pushAtBack function on a non empty CharLinkedList
// Size should be 6 and string returned should be 
// "[CharLinkedList of size 6 <<abcdef>>]""
void non_empty_pushAtFront() {
    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(arr, 5);
    list.pushAtFront('f');
    assert(list.size() == 6);
    assert(list.toString() == "[CharLinkedList of size 6 <<fabcde>>]");
}

// ************************** INSERTAT TESTS **************************//

// Tests the insertAt function on a non empty CharLinkedList with middle index
// Size should be 6 and string returned should be 
// "[CharLinkedList of size 6 <<abcdef>>]"
void non_empty_middle_insertAt() {
    char arr[5] = {'a', 'b', 'd', 'e', 'f'};
    CharLinkedList list(arr, 5);
    list.insertAt('c', 2);
    assert(list.size() == 6);
    assert(list.toString() == "[CharLinkedList of size 6 <<abcdef>>]");
}

// Tests the insertAt function on a non empty CharLinkedList with index 0
// Size should be 6 and string returned should be 
// "[CharLinkedList of size 6 <<abcdef>>]"
void non_empty_front_insertAt() {
    char arr[5] = {'b', 'c', 'd', 'e', 'f'};
    CharLinkedList list(arr, 5);
    list.insertAt('a', 0);
    assert(list.size() == 6);
    assert(list.toString() == "[CharLinkedList of size 6 <<abcdef>>]");
}

// Tests the insertAt function on a non empty CharLinkedList with index length-1
// Size should be 6 and string returned should be 
// "[CharLinkedList of size 6 <<abcdfe>>]"
void non_empty_second_to_last_insertAt() {
    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(arr, 5);
    list.insertAt('f', 4);
    assert(list.size() == 6);
    assert(list.toString() == "[CharLinkedList of size 6 <<abcdfe>>]");
}

// Tests the insertAt function on a non empty CharLinkedList with index length
// Size should be 6 and string returned should be 
// "[CharLinkedList of size 6 <<abcdef>>]"
void non_empty_last_insertAt() {
    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(arr, 5);
    list.insertAt('f', 5);
    assert(list.size() == 6);
    assert(list.toString() == "[CharLinkedList of size 6 <<abcdef>>]");
}

// Tests the insertAt function on a 1 element CharLinkedList with index 0
// Size should be 2 and string returned should be 
// "[CharLinkedList of size 2 <<ab>>]"
void front_1_element_insertAt() {
    char arr[1] = {'b'};
    CharLinkedList list(arr, 1);
    list.insertAt('a', 0);
    assert(list.size() == 2);
    assert(list.toString() == "[CharLinkedList of size 2 <<ab>>]");
}

// Tests the insertAt function on a 1 element CharLinkedList with index 1
// Size should be 2 and string returned should be 
// "[CharLinkedList of size 2 <<ab>>]"
void back_1_element_insertAt() {
    char arr[1] = {'a'};
    CharLinkedList list(arr, 1);
    list.insertAt('b', 1);
    assert(list.size() == 2);
    assert(list.toString() == "[CharLinkedList of size 2 <<ab>>]");
}

// Tests the insertAt function on a 1 element CharLinkedList with index 0
// Size should be 1 and string returned should be 
// "[CharLinkedList of size 1 <<a>>]"
void empty_insertAt() {
    CharLinkedList list;
    list.insertAt('a', 0);
    assert(list.size() == 1);
    assert(list.toString() == "[CharLinkedList of size 1 <<a>>]");
}

// Tests the insertAt function CharLinkedList with an index that is too small
// Range error should be thrown
void too_small_insertAt() {
    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(arr, 5);

    std::string error_message = "";
    bool range_error_thrown = false;
    try {
        list.insertAt('c', -1);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true; 
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (-1) not in range [0..5]");
}

// Tests the insertAt function CharLinkedList with an index that is too large
// Range error should be thrown
void too_large_insertAt() {
    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(arr, 5);

    std::string error_message = "";
    bool range_error_thrown = false;
    try {
        list.insertAt('c', 7);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true; 
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (7) not in range [0..5]");
}

// ************************** POPFROMFRONT TESTS **************************//

// tests the popFromFront function on an empty CharLinkedList
// Runtime error should be thrown 
void empty_popFromFront() {
    CharLinkedList list;

    std::string error_message = "";
    bool runtime_error_thrown = false;
    try {
        list.popFromFront();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true; 
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

// tests the popFromFront function on a many element CharLinkedList
// Size should be 4
void non_empty_popFromFront() {
    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(arr, 5);
    list.popFromFront(); 
    assert(list.size() == 4);
    assert(list.toString() == "[CharLinkedList of size 4 <<bcde>>]");
}

// tests the popFromFront function on one element CharLinkedList
// Size should be 0
void one_element_popFromFront() {
    CharLinkedList list('b');
    list.popFromFront(); 
    assert(list.size() == 0);
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}

// ************************** POPFROMBACK TESTS **************************//

// tests the popFromBack function on an empty CharLinkedList
// Runtime error should be thrown 
void empty_popFromBack() {
    CharLinkedList list;

    std::string error_message = "";
    bool runtime_error_thrown = false;
    try {
        list.popFromBack();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true; 
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

// tests the popFromBack function on a many element CharLinkedList
// Size should be 4
void non_empty_popFromBack() {
    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(arr, 5);
    list.popFromBack(); 
    assert(list.size() == 4);
    assert(list.toString() == "[CharLinkedList of size 4 <<abcd>>]");
}

// tests the popFromFront function on one element CharLinkedList
// Size should be 0
void one_element_popFromBack() {
    CharLinkedList list('b');
    list.popFromBack(); 
    assert(list.size() == 0);
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}

// *********************** REMOVEAT TESTS ****************************//

// Tests the removeAt function on a filled CharLinkedList with an index that is 
// too large
// The function should throw a range out bounds error
void too_large_index_removeAt() {
    char arr[8] = { 'b', 'b', 'c', 'c', 'e', 'f', 'g', 'h' };
    CharLinkedList list(arr, 8); 
    
    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        list.removeAt(42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8)");
}

// Tests the removeAt function on a filled CharLinkedList with an index that is 
// too small
// The function should throw a range out bounds error
void too_small_index_removeAt() {
    char arr[8] = { 'b', 'b', 'c', 'c', 'e', 'f', 'g', 'h' };
    CharLinkedList list(arr, 8); 
    
    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        list.removeAt(-1);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (-1) not in range [0..8)");
}

// Tests the removeAt function on an empty CharLinkedList with an index that is 0
// The function should throw a range out bounds error
void zero_index_removeAt() {
    CharLinkedList list; 
    
    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        list.removeAt(0);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (0) not in range [0..0)");
}

// Tests the removeAt element with only one element in the CharLinkedList
// Size should be 0
void one_element_removeAt() {
    CharLinkedList list('a'); 
    list.removeAt(0);
    assert(list.size() == 0);
}

// Tests the removeAt element with a filled CharLinkedList and the first 
// element is removed
// Size should be 7 and the list should be {'b', 'c', 'c', 'e', 'f', 'g','h'}
void front_removeAt() {
    char arr[8] = { 'b', 'b', 'c', 'c', 'e', 'f', 'g', 'h' };
    CharLinkedList list(arr, 8); 
    list.removeAt(0);
    assert(list.size() == 7);
    assert(list.toString() == ("[CharLinkedList of size 7 <<bccefgh>>]"));
}

// Tests the removeAt element with a filled CharLinkedList and the last 
// element is removed
// Size should be 7 and the list should be {'b', 'b', 'c', 'c', 'e', 'f','g'}
void back_removeAt() {
    char arr[8] = { 'b', 'b', 'c', 'c', 'e', 'f', 'g', 'h' };
    CharLinkedList list(arr, 8); 
    list.removeAt(7);
    assert(list.size() == 7);
    assert(list.toString() == ("[CharLinkedList of size 7 <<bbccefg>>]"));
}

// Tests the removeAt element with a filled CharLinkedList and a middle  
// element is removed
// Size should be 7 and the list should be {'b', 'b', 'c', 'e', 'f', 'g','h'}
void middle_removeAt() {
    char arr[8] = { 'b', 'b', 'c', 'c', 'e', 'f', 'g', 'h' };
    CharLinkedList list(arr, 8); 
    list.removeAt(3);
    assert(list.size() == 7);
    assert(list.toString() == ("[CharLinkedList of size 7 <<bbcefgh>>]"));
}

// *********************** REPLACEAT TESTS ****************************//

// Tests the replaceAt function with a filled CharLinkedList and an index 
// that is negative
// Function should throw a range out of bounds error
void too_small_index_replaceAt() {
    char arr[8] = { 'b', 'b', 'c', 'c', 'e', 'f', 'g', 'h' };
    CharLinkedList list(arr, 8);


    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        list.replaceAt('a', -1);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (-1) not in range [0..8)");
    
}

// Tests the replaceAt function with a filled CharLinkedList and an index 
// that is too large
// Function should throw a range out of bounds error
void too_large_index_replaceAt() {
    char arr[8] = { 'b', 'b', 'c', 'c', 'e', 'f', 'g', 'h' };
    CharLinkedList list(arr, 8);


    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        list.replaceAt('a', 20);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (20) not in range [0..8)");
    
}

// Tests the replaceAt function with an empty CharLinkedList and index 0
// Size should be 1
void empty_replaceAt() {
    CharLinkedList list;
    list.replaceAt('a', 0);
    assert(list.elementAt(0) == 'a');
}

// Tests the replaceAt function with a 1 element CharLinkedList
// Size should be 1
void element1_replaceAt() {
    CharLinkedList list('b');
    list.replaceAt('a', 0);
    assert(list.elementAt(0) == 'a');
}

// Tests the replaceAt function with a filled CharLinkedList by replacing the 
// first element
// Element at index 0 should be 'a'
void first_replaceAt() {
    char arr[8] = { 'b', 'b', 'c', 'c', 'e', 'f', 'g', 'h' };
    CharLinkedList list(arr, 8);
    list.replaceAt('a', 0);
    assert(list.elementAt(0) == 'a');
}


// Tests the replaceAt function with a filled CharLinkedList by replacing a 
// middle element
// Element at index 3 should be 'a'
void middle_replaceAt() {
    char arr[8] = { 'b', 'b', 'c', 'c', 'e', 'f', 'g', 'h' };
    CharLinkedList list(arr, 8);
    list.replaceAt('a', 3);
    assert(list.elementAt(3) == 'a');
}

// Tests the replaceAt function with a filled CharLinkedList by replacing the 
// last element
// Element at index 3 should be 'a'
void last_replaceAt() {
    char arr[8] = { 'b', 'b', 'c', 'c', 'e', 'f', 'g', 'h' };
    CharLinkedList list(arr, 8);
    list.replaceAt('a', 7);
    assert(list.elementAt(7) == 'a');
}

// *********************** CONCATENATE TESTS ****************************//

// Tests the concatenate function with two CharLinkedLists that are filled
// This list should contain <<lovelyday>>
void two_lists_concatenate_test() {
    char arr1[6] = {'l', 'o', 'v', 'e', 'l', 'y'};
    char arr2[3] = {'d', 'a', 'y'};
    CharLinkedList list1(arr1, 6);
    CharLinkedList list2(arr2, 3);
    list1.concatenate(&list2);
    assert(list1.toString() == "[CharLinkedList of size 9 <<lovelyday>>]");
}

// Tests the concatenate function with two CharLinkedLists one is filled one is 
// empty
// This list should contain <<lovely>>
void second_empty_lists_concatenate_test() {
    char arr1[6] = {'l', 'o', 'v', 'e', 'l', 'y'};
    CharLinkedList list1(arr1, 6);
    CharLinkedList list2;

    list1.concatenate(&list2);
    assert(list1.toString() == "[CharLinkedList of size 6 <<lovely>>]");
}

// Tests the concatenate function with two CharLinkedLists one is empty one is 
// filled
// This list should contain <<day>>
void first_empty_lists_concatenate_test() {
    char arr2[3] = {'d', 'a', 'y'};
    CharLinkedList list1;
    CharLinkedList list2(arr2, 3);
    list1.concatenate(&list2);
    assert(list1.toString() == "[CharLinkedList of size 3 <<day>>]");
}

// Tests the concatenate function with two CharLinkedLists that have the same 
// contents
// This list should contain <<lovelylovely>>
void double_lists_concatenate_test() {
    char arr1[6] = {'l', 'o', 'v', 'e', 'l', 'y'};
    CharLinkedList list1(arr1, 6);
    list1.concatenate(&list1);
    assert(list1.toString() == "[CharLinkedList of size 12 <<lovelylovely>>]");
}

// *********************** INSERTINORDER TESTS ****************************//

// Tests the insertInOrder function on an empty CharLinkedList
// To string should be "[CharLinkedList of size 1 <<c>>]"
void empty_insertInOrder_test() {
    CharLinkedList list;
    list.insertInOrder('c');
    assert(list.toString() == "[CharLinkedList of size 1 <<c>>]");
}

// Tests the insertInOrder function on a nonempty CharLinkedList with an 
// element that should go in front
// toString should be "[CharLinkedList of size 9 <<abbcdefgh>>]"
void front_nonempty_insertInOrder_test() {
    char arr[8] = { 'b', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList list(arr, 8);
    list.insertInOrder('a');
    assert(list.toString() == "[CharLinkedList of size 9 <<abbcdefgh>>]");
}

// Tests the insertInOrder function on a nonempty CharLinkedList with an 
// element that should go in at the back
// Element at index 0 should be 'a'
void back_nonempty_insertInOrder_test() {
    char arr[8] = { 'b', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList list(arr, 8);
    list.insertInOrder('i');
    assert(list.toString() == "[CharLinkedList of size 9 <<bbcdefghi>>]");
}

// Tests the insertInOrder function on a nonempty CharLinkedList with an 
// element that should go in the middle
// Element at index 4 should be 'd'
void middle_nonempty_insertInOrder_test() {
    char arr[8] = { 'b', 'b', 'c', 'c', 'e', 'f', 'g', 'h' };
    CharLinkedList list(arr, 8);
    list.insertInOrder('d');
    assert(list.toString() == "[CharLinkedList of size 9 <<bbccdefgh>>]");
}





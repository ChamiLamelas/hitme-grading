/*
 *  CharLinkedList.cpp
 *  Allison Yu (ayu15)
 *  2/2/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  The purpose of this file is the implementation of the CharLinkedList
 *
 */

#include "CharLinkedList.h"
#include <string>
#include <sstream>
#include <stdexcept>
/*
 * name:      CharLinkedList
 * purpose:   default constructor for CharLinkedList class
 * arguments: none
 * returns:   none
 * effects:   initializes the members of the CharLinkedList
 */
CharLinkedList::CharLinkedList() {
    length = 0; 
    front = nullptr; 
    back = nullptr;
}

/*
 * name:      CharLinkedList
 * purpose:   constructor for CharLinkedList class
 * arguments: char c
 * returns:   none
 * effects:   initializes the members of the CharLinkedList and puts c as 
 *            a node in the CharLinkedList
 */
CharLinkedList::CharLinkedList(char c) {
    length = 0;
    front = nullptr; 
    back = nullptr;
    pushAtBack(c);
}

/*
 * name:      CharLinkedList
 * purpose:   constructor for CharLinkedList class
 * arguments: char array and int length
 * returns:   none
 * effects:   initializes the members of the CharLinkedList and puts elements of
 *            arr into the CharLinkedList
 */
CharLinkedList::CharLinkedList(char arr[], int length) {
    this->length = 0;  
    front = nullptr; 
    back = nullptr;
    for (int i = 0; i < length; i++) {
        pushAtBack(arr[i]);
    }
}

/*
 * name:      CharLinkedList
 * purpose:   constructor for CharLinkedList class
 * arguments: pointer to another CharLinkedList
 * returns:   none
 * effects:   initializes the members of the CharLinkedList and puts elements of
 *            other into this CharLinkedList
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other) {
    front = nullptr; 
    back = nullptr;
    Node *ptr = other.front;
    for (int i = 0; i < other.length; i++) {
        pushAtBack(ptr->c);
        ptr = ptr->next;
    }
}

/*
 * name:      CharLinkedList
 * purpose:   assignment operator for CharLinkedList class
 * arguments: pointer to another CharLinkedList
 * returns:   none
 * effects:   recycles storage held by other and makes a deep copy to this 
 *            CharLinkedList
 */
CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other) {
    if (this == &other) {
        return *this; 
    }
    front = nullptr; 
    back = nullptr;
    Node *ptr = other.front;
    for (int i = 0; i < other.length; i++) {
        pushAtBack(ptr->c);
        ptr = ptr->next;
    }
    return *this;
}

/*
 * name:      ~CharLinkedList
 * purpose:   destructor for CharLinkedList class
 * arguments: none
 * returns:   none
 * effects:   deletes any nodes off the heap
 */
CharLinkedList::~CharLinkedList() {
    dCharLinkedList(front);
}

/*
 * name:      dCharLinkedList
 * purpose:   destructor for CharLinkedList class
 * arguments: none
 * returns:   none
 * effects:   deletes any nodes off the heap
 */
void CharLinkedList::dCharLinkedList(Node *curr) {
    if (curr != nullptr) {
        dCharLinkedList(curr->next);
        delete curr; 
    }
}


/*
 * name:      isEmpty
 * purpose:   returns whether the CharLinkedList is empty
 * arguments: none
 * returns:   bool value
 * effects:   none
 */
bool CharLinkedList::isEmpty() const {
    return (front == nullptr); 
}

/*
 * name:      clear
 * purpose:   removes all the elements from CharLinkedList
 * arguments: none
 * returns:   none
 * effects:   all the Nodes are deleted from CharLinkedList
 */
void CharLinkedList::clear()  {
    Node *ptr; 
    while (front != nullptr) { // deletes all the Nodes in CharLinkedList
        ptr = front;
        front = front->next; 
        delete ptr; 
    }
    length = 0; 
    front = nullptr; 
    back = nullptr; 
}

/*
 * name:      size
 * purpose:   returns the size of the CharLinkedList
 * arguments: none
 * returns:   how many nodes are in CharLinkedList
 * effects:   none
 */
int CharLinkedList::size() const {
    return length; 
}

/*
 * name:      first
 * purpose:   returns the first element of the CharLinkedList
 * arguments: none
 * returns:   first element of CharLinkedList
 * effects:   throws a runtime error if the CharLinkedList is empty
 */
char CharLinkedList::first() const {
    // throws a runtime error if called on an empty LinkedList
    if (front == nullptr) {
        throw std::runtime_error("cannot get first of empty LinkedList");
    }
    return front->c; 
}

/*
 * name:      last
 * purpose:   returns the last element of the CharLinkedList
 * arguments: none
 * returns:   last element of CharLinkedList
 * effects:   throws a runtime error if the CharLinkedList is empty
 */
char CharLinkedList::last() const {
    // throws a runtime error if called on an empty LinkedList
    if (front == nullptr) {
        throw std::runtime_error("cannot get last of empty LinkedList");
    }
    return back->c; 
}

/*
 * name:      elementAt
 * purpose:   returns the char at the given index of the CharLinkedList
 * arguments: int index
 * returns:   element at the given index
 * effects:   throws a range error if given an invalid index
 */
char CharLinkedList::elementAt(int index) const {
    // throws range error if given invalid index
    if ((front == nullptr) or ((index >= length) or (index < 0))) {
        throw std::range_error("index (" + std::to_string(index) + 
        ") not in range [0.." + std::to_string(length) + ")");
    }

    return helperElementAt(index, front);
}

/*
 * name:      elementAt
 * purpose:   returns the char at the given index of the CharLinkedList
 * arguments: int index
 * returns:   element at the given index
 * effects:   throws a range error if given an invalid index
 */
char CharLinkedList::helperElementAt(int index, Node *curr) const {
    if (index == 0) {
        return curr->c; 
    } else {
        return helperElementAt(index - 1, curr->next);
    }
}

/*
 * name:      toString
 * purpose:   returns a string of the contents of CharLinkedList
 * arguments: none
 * returns:   string of CharLinkedList
 * effects:   none
 */
std::string CharLinkedList::toString() const {
    std::stringstream ss; 
    ss << "[CharLinkedList of size "; 
    ss << length; 
    ss << " <<";
    Node *ptr = front; 
    while (ptr != nullptr) {
        ss << ptr->c; 
        ptr = ptr->next; 
    }
    ss << ">>]"; 
    return ss.str(); 
    
}

/*
 * name:      toReverseString
 * purpose:   returns a string of the contents backwards of CharLinkedList
 * arguments: none
 * returns:   backwards string of CharLinkedList
 * effects:   none
 */
std::string CharLinkedList::toReverseString() const {
    std::stringstream ss; 
    ss << "[CharLinkedList of size "; 
    ss << length; 
    ss << " <<";
    Node *ptr = back; 
    while (ptr != nullptr) {
        ss << ptr->c; 
        ptr = ptr->previous; 
    }
    ss << ">>]"; 
    return ss.str(); 
    
}

/*
 * name:      pushAtBack
 * purpose:   adds a new Node to the back of the CharLinkedList
 * arguments: char c
 * returns:   none
 * effects:   adds a new Node to the back of the CharLinkedList
 */
void CharLinkedList::pushAtBack(char c) {
    // makes a new node
    Node *nNode = newNode(c, back, nullptr);

    if (back != nullptr) { // accounts for nonempty list
        back->next = nNode; 
    } else { // accounts for empty list
        front = nNode;
    }
    back = nNode; 
    length++; 

}

/*
 * name:      pushAtFront
 * purpose:   adds a new Node to the front of the CharLinkedList
 * arguments: char c
 * returns:   none
 * effects:   adds a new Node to the front of the CharLinkedList
 */
void CharLinkedList::pushAtFront(char c) {
    // makes new Node
    Node *nNode = newNode(c, nullptr, front);

    if (front != nullptr) { // accounts for non empty list
        front->previous = nNode;
    } else { // accounts for empty list
        back = nNode;
    }
    front = nNode; 
    length++; 
    
}

/*
 * name:      insertAt
 * purpose:   adds a new Node to the CharLinkedList at a given index
 * arguments: char c, int index
 * returns:   none
 * effects:   throws a range error if given an invalid index
 */
void CharLinkedList::insertAt(char c, int index) {
    // throws range error if given invalid index
    if ((index > length) or (index < 0)) {
        throw std::range_error("index (" + std::to_string(index) + 
        ") not in range [0.." + std::to_string(length) + "]");
    }

    if (index == 0) { // accounts for front of list
        pushAtFront(c);
    } else if (index == length) { // accounts for back of list
        pushAtBack(c);
    } else { // accounts for middle of the list
        Node *curr = front; 
        // makes new Node
        Node *nNode = newNode(c, nullptr, nullptr);
        // loop places curr at the element right before element at index
        for (int i = 0; i < index-1; i++) {
            curr = curr->next; 
        }
        // links nNode into the list
        nNode->next = curr->next;
        curr->next->previous = nNode; 
        nNode->previous = curr;
        curr->next = nNode; 
        length++; 
    }
}
/*
 * name:      insertInOrder
 * purpose:   inserts a Node in the correct order (assuming that list is sorted)
 * arguments: none
 * returns:   none
 * effects:   inserts a Node in order
 */
void CharLinkedList::insertInOrder(char c) {
    if ((front == nullptr) or (c <= front->c)) {
        pushAtFront(c);
    } else if (c >= back->c) {
        pushAtBack(c);
    } else {
        Node *ptr = front; 
        while (c <= ptr-> c) {
            ptr = ptr->next; 
        }
        Node *nNode = newNode(c, nullptr, nullptr); 
        nNode->next = ptr; 
        nNode->previous = ptr->previous; 
        ptr->previous->next = nNode;
        ptr->previous = nNode; 
        length++;
    }
}

/*
 * name:      popFromFront
 * purpose:   removes a Node from the front
 * arguments: none
 * returns:   none
 * effects:   throws a runtime error if called on an empty CharLinkedList
 */
void CharLinkedList::popFromFront() {
    // throws runtime error if the list is empty
    if (front == nullptr) {
        throw std::runtime_error("cannot pop from empty LinkedList");
    }
    if (length == 1) { // accounts for 1 element
        delete front; 
        front = nullptr; 
        back = nullptr; 
        length--; 
    } else { // accounts for more than 1 element
        Node *ptr = front; 
        front = front->next; 
        front->previous = nullptr; 
        ptr->next = nullptr;
        delete ptr; 
        length--; 
    }
}

/*
 * name:      popFromBack
 * purpose:   removes a Node from the back
 * arguments: none
 * returns:   none
 * effects:   throws a runtime error if called on an empty CharLinkedList
 */
void CharLinkedList::popFromBack() {
    // throws a runtime error if the list is empty
    if (back == nullptr) {
        throw std::runtime_error("cannot pop from empty LinkedList");
    }
    if (length == 1) { // accounts for 1 element
        delete back; 
        front = nullptr; 
        back = nullptr; 
        length--; 
    } else { // accounts for more than 1 element
        Node *ptr = back; 
        back = back->previous; 
        back->next = nullptr;
        ptr->previous = nullptr; 
        delete ptr; 
        length--;
    }
}

/*
 * name:      removeAt
 * purpose:   removes a Node from the given index
 * arguments: int index
 * returns:   none
 * effects:   throws a range error if given an invalid index
 */
void CharLinkedList::removeAt(int index) {
    // throws a range error if given an invalid index
    // covers case of empty list
    if ((front == nullptr) or ((index > length) or (index < 0))) {
        throw std::range_error("index (" + std::to_string(index) +
         ") not in range [0.." + std::to_string(length) + ")");
    }
    if (index == 0) { //removing at index zero has same function as popFromFront
        popFromFront(); 
    } else if (index == length-1) { // removing from back = popFromBack
        popFromBack();
    } else { // removing from middle
        Node *ptr = front; 
        for (int i = 0; i < index; i++) { // places ptr at correct index
            ptr = ptr->next; 
        }
        ptr->next->previous = ptr->previous; 
        ptr->previous->next = ptr->next; 
        ptr->next = nullptr; 
        ptr->previous = nullptr; 
        delete ptr; 
        length--; 
    }
}

/*
 * name:      replaceAt
 * purpose:   replaces the element at the given index
 * arguments: char c, int index
 * returns:   none
 * effects:   throws range error if given invalid index
 */
void CharLinkedList::replaceAt(char c, int index) {
    // throws a range error if given an invalid index
    if ((index > length) or (index < 0)) {
        throw std::range_error("index (" + std::to_string(index) +
         ") not in range [0.." + std::to_string(length) + ")");
    }
    helperReplaceAt(c, index, front); 
}

/*
 * name:      helperReplaceAt
 * purpose:   replaces the element at the given index
 * arguments: char c, int index
 * returns:   none
 * effects:   helper function of replaceAt
 */
void CharLinkedList::helperReplaceAt(char c, int index, Node *curr) {
    if (index == 0) {
        if (curr == nullptr) {
            pushAtFront(c);
        } else {
            curr->c = c;
        }
    } else {
        helperReplaceAt(c, index-1, curr->next);
    }
}

/*
 * name:      concatenate
 * purpose:   concatenates a given CharLinkedList to the end of this 
 *            CharLinkedList
 * arguments: pointer to CharLinkedList
 * returns:   none
 * effects:   adds contents of given CharLinkedList to the end of this list
 */
void CharLinkedList::concatenate(CharLinkedList *other) {
    CharLinkedList list;
    list = *other; 
    if (list.front != nullptr) { // adds contents of other to this list
        Node *ptr = list.front; 
        for (int i = 0; i < list.length; i++) {
            pushAtBack(ptr->c);
            ptr = ptr->next; 
        }
    }
}

/*
 * name:      newNode
 * purpose:   creates and returns a new Node to be added to the CharLinkedList
 * arguments: char c, CharLinkedlist pointer for previous, 
 *            CharLinkedlist pointer for next
 * returns:   pointer to the Node created
 * effects:   none
 */
CharLinkedList::Node *CharLinkedList::newNode(char data, Node *prev, Node *next) 
{
    Node *nNode = new Node;
    nNode->c = data;
    nNode->next = next;
    nNode->previous = prev;
    return nNode; 

}


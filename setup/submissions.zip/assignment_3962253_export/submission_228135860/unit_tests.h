/*
 *  unit_tests.h
 *  Amelia Bermack 
 *  2/1/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  Create tests for the CharLinkedList Class
 *
 */


#include "CharLinkedList.h"
#include <cassert>
#include <iostream>

//***CONSTRUCTOR TESTS***
//tests the first constructor 
void constructorTest1(){
    CharLinkedList test;
    assert(test.size() == 0);
}

//tests the second constructor 
void constructorTest2(){
    CharLinkedList test('a');
    assert(test.size() == 1);
    std::cout << test.toString();
}

//tests the third constructor 
void constructorTest3(){
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList test(arr, 3);
    assert(test.toString() == "[CharLinkedList of size 3 <<abc>>]");
}

//tests the third constructor but with a larger array 
void constructorTest4(){
    char arr[10] = {'a', 'b', 'c', 'a', 'b', 'c', 'a', 'b', 'c', 'd'};
    CharLinkedList test(arr, 10);
    assert(test.size() == 10);
    assert(test.toString() == "[CharLinkedList of size 10 <<abcabcabcd>>]");
}

//tests the third constructor but with only a single element 
void constructorTest5(){
    char arr[1] = {'a'};
    CharLinkedList test(arr, 1);

    assert(test.size() == 1);
    assert(test.toString() == "[CharLinkedList of size 1 <<a>>]");
}

//tests the first constructor and makes sure the toString is correct
void constructorTest6(){
    CharLinkedList test;
    assert(test.size() == 0);
    assert(test.toString() == "[CharLinkedList of size 0 <<>>]");
}

//***PUSH AT FRONT/BACK TESTS
//checks to make sure pushAtFront works with a single element already in list
void pushFrontTest1(){
    char arr[1] = {'a'};
    CharLinkedList test(arr, 1);

    test.pushAtFront('m');

    assert(test.size() == 2);
    assert(test.toString() == "[CharLinkedList of size 2 <<ma>>]");
}

//checks that pushAtFront works with nothing in list and adding a single char
void pushFrontTest2(){
    CharLinkedList test;

    test.pushAtFront('A');

    assert(test.size() == 1);
    assert(test.toString() == "[CharLinkedList of size 1 <<A>>]");
}

//checks to make shure pushAtBack works with a single char, then adds more chars
//and checks that the size and toString asserts are true
void pushBackTest1(){
    char arr[1] = {'a'};
    CharLinkedList test(arr, 1);

    test.pushAtBack('m');

    assert(test.size() == 2);
    assert(test.toString() == "[CharLinkedList of size 2 <<am>>]");

    test.pushAtFront('p');
    assert(test.size() == 3);
    assert(test.toString() == "[CharLinkedList of size 3 <<pam>>]");

    test.pushAtFront('p');
    assert(test.size() == 4);
    assert(test.toString() == "[CharLinkedList of size 4 <<ppam>>]");
}

//checks pushAtBack with nothing originally in the list
void pushBackTest2(){
    CharLinkedList test;
    test.pushAtBack('o');

    assert(test.size() == 1);
    assert(test.toString() == "[CharLinkedList of size 1 <<o>>]");
}

//***ISEMPTY TESTS***
//makes empty LL and checks that it's empty 
void emptyTest1(){
    CharLinkedList test;
    assert(test.isEmpty());
}

//starts with empty LL, adds a char and makes sure it is NOT empty 
void emptyTest2(){
    CharLinkedList test;
    test.pushAtBack('l');
    assert(not test.isEmpty());
}

//starts with an LL of size 1, makes sure that it is NOT empty 
void emptyTest3(){
    char arr[1] = {'a'};
    CharLinkedList test(arr, 1);
    assert(not test.isEmpty());
}

//starts with empty LL, adds a char to the front, makes sure that it's NOT empty
void emptyTest4(){
    CharLinkedList test;
    test.pushAtFront('l');
    assert(not test.isEmpty());
}
//**FIRST TESTS**
//checks to make sure first() correctly returns 'a'
void firstTest1(){
    char samp[3] = {'a', 'b', 'c'};
    CharLinkedList test(samp, 3);

    char letter = test.first();
    assert(letter = 'a');
}

//checks to make sure first() correctly throws an error for an empty LL
void firstTest2(){
    CharLinkedList test;
    bool errorThrown = false; 
    std::string message = "";

    try{
        test.first();
    }
    catch(const std::runtime_error &e){
        errorThrown = true;
        message = e.what();
    }

    assert(errorThrown);
    assert(message == "cannot get first of empty LinkedList");
}

//***LAST TESTS***
//checks to make sure last() correctly returns the last value in an LL
void lastTest1(){
    char samp[3] = {'a', 'b', 'c'};
    CharLinkedList test(samp, 3);

    char letter = test.last();
    assert(letter = 'c');
}

//checks to make sure last() correctly throws a runtime error for an empty LL
void lastTest2(){
    CharLinkedList test;
    bool errorThrown = false;
    std::string message = "";

    try{
        test.last();
    }
    catch(const std::runtime_error &e){
        errorThrown = true;
        message = e.what();
    }

    assert(errorThrown);
    assert(message == "cannot get last of empty LinkedList");
}

//makes sure that different pushAtFront and pushAtBack calls make the correct LL
void lastTest3(){
    CharLinkedList test;
    test.pushAtFront('a');
    test.pushAtBack('b');
    test.pushAtBack('d');
    test.pushAtFront('c');

    assert(test.first() == 'c');
    assert(test.last() == 'd');
}

//***ELEMENTAT TESTS***
//tests correct insertion into an LL
void elementAtTest1(){
    char samp[3] = {'a', 'b', 'c'};
    CharLinkedList test(samp, 3);

    char letter = test.elementAt(1);
    assert(letter == 'b');
}

//tests incorrect insertion into an LL
void elementAtTest2(){
    char samp[3] = {'a', 'b', 'c'};
    CharLinkedList test(samp, 3);

    bool range_error_thrown = false;
    std::string error_message = "";
    try{
        test.elementAt(3);//CHANGED STUFF RIGHT HERE
    }
    catch(const std::range_error &e){
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (3) not in range [0..3)");
}

//tests incorrect index call for elementAt(), makes sure an error is thrown 
void elementAtTest3(){
    char samp[3] = {'a', 'b', 'c'};
    CharLinkedList test(samp, 3);

    bool error = false;
    std::string message = "";

    try{
        test.elementAt(17);
    }
    catch(const std::range_error &e){
        error = true;
        message = e.what();
    }

    assert(error);
    assert(message == "index (17) not in range [0..3)");
}

//***REVERSE STRING TESTS***
//test the reverse string again for LL of size 5
void reverseStringTest1(){
    char samp[5] = {'u', 'r', 'm', 'o', 'm'};
    CharLinkedList test(samp, 5);
    assert(test.toReverseString() == "[CharLinkedList of size 5 <<momru>>]");
    std::cout << test.toReverseString();
}

//test teh reverseString for LL of size 0
void reverseStringTest2(){
    CharLinkedList test;
    assert(test.toReverseString() == "[CharLinkedList of size 0 <<>>]");
}

//tests an LL of size 3 for the reverse string 
void reverseStringTest3(){
    CharLinkedList test;
    test.pushAtFront('a');
    test.pushAtBack('m');
    test.pushAtFront('e');
    std::cout << test.toReverseString();
    assert(test.toReverseString() == "[CharLinkedList of size 3 <<mae>>]");
}

//***INSERT AT TESTS***
//checks that the insertAt function operates properly with an LL starting at 
//size 0
void insertAt_empty_correct() { 

    CharLinkedList test_list;
    test_list.insertAt('a', 0);
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');

}

// Tests incorrect insertion into an empty LL.
// Attempts to call insertAt for index larger than 0.
// This should result in an std::range_error being raised.
void insertAt_empty_incorrect() {

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    // insertAt for out-of-range index
    test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
    // if insertAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    range_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0]");
    
}

// Tests correct insertAt for front of 1-element list.
void insertAt_front_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at front
    test_list.insertAt('b', 0);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'a');
    
}

// Tests correct insertAt for back of 1-element list.
void insertAt_back_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at back
    test_list.insertAt('b', 1);

    std::cout << test_list.size();
    //assert(test_list.size() == 2);
    //assert(test_list.elementAt(0) == 'a');
    //assert(test_list.elementAt(1) == 'b');
    
}

// Tests calling insertAt for a large number of elements.
// Not only does this test insertAt, it also checks that
// linked list expansion works correctly.
void insertAt_many_elements() {
    
    CharLinkedList test_list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.insertAt('a', i);
    }

    assert(test_list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
    
}

// Tests insertion into front of a larger list
void insertAt_front_large_list() {
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    test_list.insertAt('y', 0);

    assert(test_list.size() == 10);
    assert(test_list.elementAt(0) == 'y');
    assert(test_list.toString() == 
    "[CharLinkedList of size 10 <<yabczdefgh>>]");

}

// Tests insertion into the back of a larger list
void insertAt_back_large_list() {

    char test_arr[10] = { 'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 10);  

    test_list.insertAt('x', 10);

    assert(test_list.size() == 11);
    assert(test_list.elementAt(10) == 'x');
    assert(test_list.toString() == 
    "[CharLinkedList of size 11 <<yabczdefghx>>]"); 

}

// Tests insertion into the middle of a larger list
void insertAt_middle_large_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.insertAt('z', 3);

    assert(test_list.size() == 9);
    std::cout << test_list.toString();
    assert(test_list.elementAt(3) == 'z');
    assert(test_list.toString() == "[CharLinkedList of size 9 <<abczdefgh>>]");

}

// Tests out-of-range insertion for a non-empty list.
void insertAt_nonempty_incorrect() {
   
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8]");
    
}

//***POP FRONT TESTING
//correctly tries to pop from the front of a size 3 linked list
void popFrontTest(){
    char samp[3] = {'a', 'l', 'd'};
    CharLinkedList test(samp, 3);

    test.popFromFront();

    assert(test.size() == 2);
    assert(test.toString() == "[CharLinkedList of size 2 <<ld>>]");
}

//correctly tries to pop from a size 1 linked list
void popFrontOneTest(){
    CharLinkedList test('m');

    test.popFromFront();

    assert(test.size() == 0);
    assert(test.toString() == "[CharLinkedList of size 0 <<>>]");
}

//incorrectly tries to pop from empty linked list
void popFrontTwoTest(){
    bool error = false;
    std::string message = "";
    CharLinkedList test;

    try{
        test.popFromFront();
    }
    catch(const std::runtime_error &e){
        error = true;
        message = e.what();
    }

    assert(error);
    assert(message == "cannot pop from empty LinkedList");
}

//***POP BACK TESTS
//incorrectly tries to pop from an empty linked list 
void popEmptyTest1(){
    bool throwError = false;
    std::string message = "";

    CharLinkedList test;

    try{
        test.popFromFront();
    }
    catch (const std::runtime_error &e){
        throwError = true;
        message = e.what();
    }

    assert(throwError);
    assert(message == "cannot pop from empty LinkedList");

}

//pops all the elements in the linked list and makes sure it's popping correctly
void popMultipleTest2(){
    bool throwError = false;
    std::string message = "";

    char samp[2] = {'l','y'};
    CharLinkedList test(samp, 2);

    test.popFromFront();
    test.popFromFront();
    
    try{
        test.popFromFront();
    }
    catch (const std::runtime_error &e){
        throwError = true;
        message = e.what();
    }

    assert(throwError);
    assert(message == "cannot pop from empty LinkedList");
}

//correctly tries to pop from the back of a size 3 linked list
void popBackTest(){
    char samp[3] = {'a', 'l', 'd'};
    CharLinkedList test(samp, 3);

    test.popFromBack();

    assert(test.size() == 2);
    assert(test.toString() == "[CharLinkedList of size 2 <<al>>]");
}

//correctly tries to pop back from a size 1 linked list
void popBackOneTest(){
    CharLinkedList test('m');

    test.popFromBack();

    assert(test.size() == 0);
    assert(test.toString() == "[CharLinkedList of size 0 <<>>]");
}

//incorrectly tries to pop back from an empty linked list 
void popEmptyTest2(){
    bool throwError = false;
    std::string message = "";

    CharLinkedList test;

    try{
        test.popFromBack();
    }
    catch (const std::runtime_error &e){
        throwError = true;
        message = e.what();
    }

    assert(throwError);
    assert(message == "cannot pop from empty LinkedList");

}

//pops back all the elements in the linked list and makes sure it's working
void popMultipleTest1(){
    bool throwError = false;
    std::string message = "";

    char samp[2] = {'l','y'};
    CharLinkedList test(samp, 2);

    test.popFromBack();
    test.popFromBack();
    
    try{
        test.popFromBack();
    }
    catch (const std::runtime_error &e){
        throwError = true;
        message = e.what();
    }

    assert(throwError);
    assert(message == "cannot pop from empty LinkedList");
}

//pop from da front AND from da back correctly woooo
void popFrontBackCorrectTest(){
    char samp[5] = {'l','y', 'a', 'x', 'z'};
    CharLinkedList test(samp, 5);

    test.popFromFront();
    test.popFromBack();
    test.popFromFront();
    test.popFromBack();

    assert(test.size() == 1);
    assert(test.toString() == "[CharLinkedList of size 1 <<a>>]");
}

//pop from da front AND from da back incorrectly boooo
void popFrontBackIncorrectTest(){
    bool error = false;
    std::string message = "";

    char samp[5] = {'l','y', 'a', 'x', 'z'};
    CharLinkedList test(samp, 5);

    try{
        test.popFromFront();
        test.popFromBack();
        test.popFromFront();
        test.popFromBack();
        test.popFromFront();
        test.popFromBack();
    }
    catch (const std::runtime_error &e){
        error = true;
        message = e.what();
    }

    assert(error);
    assert(message == "cannot pop from empty LinkedList");
}

//***REPLACEAT TESTS***
//tests the replacing at the beginning of an linked list
void replaceBeginningTest(){
    char samp[5] = {'l','y', 'a', 'x', 'z'};
    CharLinkedList test(samp, 5);

    test.replaceAt('f', 0);

    assert(test.size() == 5);
    assert(test.toString() == "[CharLinkedList of size 5 <<fyaxz>>]");
}

//tests the replacing at the end of an linked list
void replaceEndTest(){
    char samp[5] = {'l','y', 'a', 'x', 'z'};
    CharLinkedList test(samp, 5);

    test.replaceAt('f', 4);

    assert(test.size() == 5);
    assert(test.toString() == "[CharLinkedList of size 5 <<lyaxf>>]");
}

//tests the replacing in the middle of of an linked list
void replaceMiddleTest(){
    char samp[5] = {'l','y', 'a', 'x', 'z'};
    CharLinkedList test(samp, 5);

    test.replaceAt('f', 2);

    assert(test.size() == 5);
    assert(test.toString() == "[CharLinkedList of size 5 <<lyfxz>>]");
}

//tests the invalid replacing out of bounds of an linked list (below 0)
void replaceInvalidNegativeTest(){
    bool error = false;
    std::string message = "";

    char samp[5] = {'l','y', 'a', 'x', 'z'};
    CharLinkedList test(samp, 5);

    try{
        test.replaceAt('f', -1);
    }
    catch (const std::range_error &e){
        error = true;
        message = e.what();
    }

    assert(error);
    assert(message == "index (-1) not in range [0..5)");

}

//tests the invalid replacing out of bounds of an linked list (above numItems)
void replaceInvalidPositiveTest(){
    bool error = false;
    std::string message = "";

    char samp[5] = {'l','y', 'a', 'x', 'z'};
    CharLinkedList test(samp, 5);

    try{
        test.replaceAt('f', 5);
    }
    catch (const std::range_error &e){
        error = true;
        message = e.what();
    }

    assert(error);
    assert(message == "index (5) not in range [0..5)");
}

//***CLEAR TESTS***
//tests the clear() function
void clearTest(){
    char sampleArray[3] = {'a', 'b', 'c'};
    CharLinkedList test2(sampleArray, 3);

    test2.clear();
    assert(test2.isEmpty());
    std::cout << test2.toString();
}

void clearTest2(){
    CharLinkedList test;

    test.clear();
    assert(test.isEmpty());
}


//***REMOVE AT TESTS***
//tests that remove correctly removes from the front
void removeFrontTest(){
    char samp[5] = {'l','y', 'a', 'x', 'z'};
    CharLinkedList test(samp, 5);

    test.removeAt(0);

    assert(test.size() == 4);
    assert(test.toString() == "[CharLinkedList of size 4 <<yaxz>>]");
}

//tests that remove correctly removes from the back
void removeBackTest(){
    char samp[5] = {'l','y', 'a', 'x', 'z'};
    CharLinkedList test(samp, 5);

    test.removeAt(4);

    assert(test.size() == 4);
    assert(test.toString() == "[CharLinkedList of size 4 <<lyax>>]");
}

//tests that remove correctly removes from the middle
void removeMiddleTest(){
    char samp[5] = {'l','y', 'a', 'x', 'z'};
    CharLinkedList test(samp, 5);

    test.removeAt(1);

    assert(test.size() == 4);
    assert(test.toString() == "[CharLinkedList of size 4 <<laxz>>]");
}

//tests that remove correctly catches an invalid index
void removeInvalidTest(){
    bool error = false;
    std::string message = "";

    char samp[5] = {'l','y', 'a', 'x', 'z'};
    CharLinkedList test(samp, 5);

    try{
        test.removeAt(5);
    }
    catch (const std::range_error &e){
        error = true;
        message = e.what();
    }

    assert(error);
    assert(message == "index (5) not in range [0..5)");
}

//***COPY CONSTRUCTOR TESTS***
void constructorCopyTest1(){
    //creates the original character linked list list
    char ogArray[6] = {'a', 'm', 'e', 'l', 'i', 'a'};
    CharLinkedList original(ogArray, 6);
    
    //creates the deep copy (hopefully?)
    CharLinkedList copy(original);

    assert(copy.size() == 6);
    assert(copy.toString() == "[CharLinkedList of size 6 <<amelia>>]");
}

//tests that the copy constructor correctly makes a deep copy of an LL 
void constructorCopyTest2(){
    char arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList og(arr, 8);

    CharLinkedList copy(og);

    assert(copy.size() == 8);
    assert(copy.toString() == "[CharLinkedList of size 8 <<abcdefgh>>]");

    copy.replaceAt('z', 6);
    assert(copy.size() == 8);
    assert(copy.elementAt(6) == 'z');
    assert(og.size() == 8);
    assert(og.elementAt(6) == 'g');
}

//***ASSIGNMENT OPERATOR TEST***
//test the copy constructor 
//test the copy constructor 
void copyTest1(){
    char arr[6] = {'a', 'm', 'e', 'l', 'i', 'a'};
    CharLinkedList l1(arr, 6);

    CharLinkedList l2; 

    l2 = l1;

    assert(l2.size() == 6);
    assert(l2.toString() == "[CharLinkedList of size 6 <<amelia>>]");
}

//makes sure that the copy constructor works correctly and deletes the previous
//LL that used to be in the LL 
void copyTest2(){
    char arr1[6] = {'a', 'm', 'e', 'l', 'i', 'a'};
    CharLinkedList amelia(arr1, 6);

    char arr2[4] = {'b', 'o', 'n', 'u'};
    CharLinkedList bonu(arr2, 4);

    amelia = bonu;

    assert(amelia.size() == 4);
    assert(amelia.toString() == "[CharLinkedList of size 4 <<bonu>>]");
}

//tests the assignment operator for a larger LL
void copyTest3(){
    char arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList og(arr, 8);

    CharLinkedList copy;

    copy = og;

    assert(copy.size() == 8);
    assert(copy.toString() == "[CharLinkedList of size 8 <<abcdefgh>>]");

    copy.replaceAt('z', 6);
    assert(copy.size() == 8);
    assert(copy.elementAt(6) == 'z');
    assert(og.size() == 8);
    assert(og.elementAt(6) == 'g');
}


//***CONCATENATE TESTS***
//tests concatenate with two small linked lists
void conSmallTest(){
    char samp1[2] = {'l','y'};
    CharLinkedList test1(samp1, 2);

    char samp2[2] = {'a','f'};
    CharLinkedList test2(samp2, 2);

    test1.concatenate(&test2);

    assert(test1.size() == 4);
    assert(test2.size() == 2);
    assert(test1.toString() == "[CharLinkedList of size 4 <<lyaf>>]");
}

//tests concatenate with two large linked lists
void conLargeTest(){
    char samp1[10] = {'l','y', 'a', 'x', 'z','u','r', 'm', 'o', 'm'};
    CharLinkedList test1(samp1, 10);

    char samp2[10] = {'l','o', 'l', 'w', 'o','r','k', 'p', 'l', 's'};
    CharLinkedList test2(samp2, 10);

    test1.concatenate(&test2);

    assert(test1.size() == 20);
    assert(test2.size() == 10);
    assert(test1.toString() == 
    "[CharLinkedList of size 20 <<lyaxzurmomlolworkpls>>]");
}

//tests concatenate with an empty and full linked list
void conFullEmpTest(){
    char samp1[10] = {'l','y', 'a', 'x', 'z','u','r', 'm', 'o', 'm'};
    CharLinkedList test1(samp1, 10);

    CharLinkedList test2;

    test1.concatenate(&test2);

    assert(test1.size() == 10);
    assert(test2.size() == 0);
    assert(test1.toString() == "[CharLinkedList of size 10 <<lyaxzurmom>>]");
}

//tests concatenate with a full and empty linked list
void conEmpFullTest(){
    CharLinkedList test1;

    char samp1[10] = {'l','y', 'a', 'x', 'z','u','r', 'm', 'o', 'm'};
    CharLinkedList test2(samp1, 10);

    test1.concatenate(&test2);

    assert(test1.size() == 10);
    assert(test2.size() == 10);
    std::cout << test1.toString();
    assert(test1.toString() == "[CharLinkedList of size 10 <<lyaxzurmom>>]");
}

//tests cheshire cat example
void conCheshireTest(){
    char cat[8] = {'C', 'H', 'E', 'S', 'H', 'I', 'R', 'E'};
    CharLinkedList conCat(cat, 8); 

    conCat.concatenate(&conCat);

    assert(conCat.size() == 16);
    assert(conCat.toString() == 
    "[CharLinkedList of size 16 <<CHESHIRECHESHIRE>>]");
}

//test alphabetizing for empty LL
void orderEmptyTest1(){
    CharLinkedList test;
    test.insertInOrder('f');

    assert(test.size() == 1);
    assert(test.toString() == "[CharLinkedList of size 1 <<f>>]");
}

//test alphabetizing for sorted LL
void orderSortedMiddleTest(){
    char samp[5] = {'a', 'b', 'd', 'f', 'g'};
    CharLinkedList test(samp, 5);

    test.insertInOrder('c');

    assert(test.size() == 6);
    assert(test.toString() == "[CharLinkedList of size 6 <<abcdfg>>]");
}

//test alphabetizing for non-sorted LL (example on spec)
void orderNonSortedTest(){
    char samp[3] = {'Z', 'E', 'D'};
    CharLinkedList test(samp, 3);

    test.insertInOrder('A');
    assert(test.size() == 4);
    assert(test.toString() == "[CharLinkedList of size 4 <<AZED>>]");

}

//test alphabetiziing for sorted LL in the back
void orderSortedBackTest(){
    char samp[3] = {'A', 'E', 'D'};
    CharLinkedList test(samp, 3);

    test.insertInOrder('L');

    assert(test.size() == 4);
    assert(test.toString() == "[CharLinkedList of size 4 <<AEDL>>]");
}

//test alphabetizing for non-sorted LL in the middle
void orderNonSortedMiddleTest(){
    char samp[3] = {'A', 'Z', 'D'};
    CharLinkedList test(samp, 3);

    test.insertInOrder('X');

    assert(test.size() == 4);
    assert(test.toString() == "[CharLinkedList of size 4 <<AXZD>>]");
}

//test alphabetiziing for sorted LL in front
void orderSortedFrontMultipleTest(){
    char samp[3] = {'m', 'y', 'z'};
    CharLinkedList test(samp, 3);

    test.insertInOrder('l');

    assert(test.size() == 4);
    assert(test.toString() == "[CharLinkedList of size 4 <<lmyz>>]");

    test.insertInOrder('a');

    assert(test.size() == 5);
    assert(test.toString() == "[CharLinkedList of size 5 <<almyz>>]");
}

//test alphabetizing for non-sorted LL in front
void orderNonSortedFrontTest(){
    char samp[3] = {'z', 'm', 'y'};
    CharLinkedList test(samp, 3);

    test.insertInOrder('l');

    assert(test.size() == 4);
    assert(test.toString() == "[CharLinkedList of size 4 <<lzmy>>]");
}
    
//test alphabetizing for duplicated numbers in front
void orderDupFront(){
    char samp[3] = {'a', 'm', 'y'};
    CharLinkedList test(samp, 3);

    test.insertInOrder('a');

    assert(test.size() == 4);
    assert(test.toString() == "[CharLinkedList of size 4 <<aamy>>]");
}

//test alphabetizing for duplicated numbers in back
void orderDupBack(){
    char samp[3] = {'a', 'b', 'c'};
    CharLinkedList test(samp, 3);

    test.insertInOrder('c');

    assert(test.size() == 4);
    assert(test.toString() == "[CharLinkedList of size 4 <<abcc>>]");
}

//test alphabetizing for duplicated numbers in middle 
void orderDupMiddle(){
    char samp[3] = {'d', 'g', 'x'};
    CharLinkedList test(samp, 3);

    test.insertInOrder('g');

    assert(test.size() == 4);
    assert(test.toString() == "[CharLinkedList of size 4 <<dggx>>]");
}

//test alphabetizing with non alphabet chars
void orderNonAlphaCharTest(){
    char samp[3] = {':', '?', '{'};
    CharLinkedList test(samp, 3);

    test.insertInOrder(']');

    assert(test.size() == 4);
    assert(test.toString() == "[CharLinkedList of size 4 <<:?]{>>]");
}

//testing a whole bunch of ordered stuff
void orderMultipleTest(){
    CharLinkedList test;

    test.insertInOrder('?');
    test.insertInOrder('l');
    test.insertInOrder('a');

    //test
    assert(test.size() == 3);
    assert(test.toString() == "[CharLinkedList of size 3 <<?al>>]");
}
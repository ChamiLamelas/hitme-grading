/*
 *  CharLinkedList.cpp
 *  Amelia Bermack
 *  2/1/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  This is a class implementation for a linked list for homework 2.
 *
 */

#include "CharLinkedList.h"
#include <string>
#include <stdexcept>
#include <iostream>

/*
 * name:      CharLinkedList empty constructor
 * purpose:   initialize an empty CharLinkedList
 * arguments: none
 * returns:   none
 * effects:   numItems to 0, front, back, and next point to nullptr
*/
CharLinkedList::CharLinkedList(){
    front = nullptr;
    back = nullptr;
    numItems = 0; 
}

/*
 * name:      CharLinkedList single character constructor
 * purpose:   initialize a CharLinkedList with a single character 
 * arguments: a char
 * returns:   none
 * effects:   increase numItems by 1, sets the front and back pointer to Node
*/
CharLinkedList::CharLinkedList(char c){
    //create a new node
    Node *new_node = new Node;
    new_node->letter = c;
    new_node->next = nullptr;
    new_node->prev = nullptr;

    //set all the pointers
    front = new_node;
    back = new_node;

    //make the size 1
    numItems = 1;
}

/*
 * name:      CharLinkedList array constructor 
 * purpose:   initialize a CharLinkedList with an array and a size 
 * arguments: an array and the size of the array 
 * returns:   none
 * effects:   increase numItems by the size, create a linkedlist for the array 
*/
CharLinkedList::CharLinkedList(char arr[], int size){

    if(size > 0){
        Node *new_node = new Node;
        new_node->letter = arr[0];
        new_node->next = nullptr;
        new_node->prev = nullptr;
        front = new_node;
        back = new_node;
        numItems = 1;

        Node *temp = new_node;
        
        for(int i = 1; i < size; i++){
            Node *curr = newNode(arr[i], nullptr);
            temp = back;
            temp->next = curr;
            curr->prev = back;
            curr->next = nullptr;
            back = curr;
            numItems++;        
        }
    }
    else{
        front = nullptr;
        back = nullptr;
        numItems = 0; 
    }
    
}

/*
 * name:      CharLinkedList copy constructor 
 * purpose:   creates a deep copy of a CharLinkedList
 * arguments: another CharLinkedList
 * returns:   none
 * effects:   creates a deep copy, changes numItems, front and back pointers 
*/
CharLinkedList::CharLinkedList(const CharLinkedList &other){
    numItems = 1;
    
    front = new Node;
    front->letter = other.front->letter;


    Node *curr = other.front;
    curr = curr->next;
    Node *newListPrev = front;

    while(curr != nullptr){
        numItems++;
        //creates a new node and assigns the letter 
        Node *new_node = new Node;
        new_node->letter = curr->letter;

        //assigns the pointers 
        newListPrev->next = new_node;
        new_node->prev = newListPrev;

        //updates the copying pointers 
        newListPrev = newListPrev->next;
        curr = curr->next;
    }

    //sets the last node to the back pointer
    newListPrev->next = nullptr;
    back = newListPrev;
}

/*
 * name:      CharLinkedList assignment operator 
 * purpose:   creates a deep copy of a CharLinkedList
 * arguments: a reference to CharLinkedList
 * returns:   a CharLinkedList
 * effects:   creates a deep copy of another CharLinkedList
*/
CharLinkedList& CharLinkedList::operator=(const CharLinkedList &other){
    if(this == &other){ //if its the same things already, just return this 
        return *this;
    }

    clear(); //clears the list, if it used to have one 

    numItems = 1; //set the number of items to one, create a new Node 
    
    front = new Node;
    front->letter = other.front->letter;

    Node *curr = other.front; //set a temporary pointer to other's Node 
    curr = curr->next;
    Node *newListPrev = front;

    while(curr != nullptr){ //loops through the array 
        numItems++;
        //creates a new node and assigns the letter 
        Node *new_node = new Node;
        new_node->letter = curr->letter;

        //assigns the pointers 
        newListPrev->next = new_node;
        new_node->prev = newListPrev;

        //updates the copying pointers 
        newListPrev = newListPrev->next;
        curr = curr->next;
    }

    //sets the last node to the back pointer
    newListPrev->next = nullptr;
    back = newListPrev;

    return *this;
}

/*
 * name:      CharLinkedList pushAtFront function
 * purpose:   puts a char at the beginning of a Linked List
 * arguments: a character 
 * returns:   none
 * effects:   increases numItems, adds a char to the beginning of a LL
*/
void CharLinkedList::pushAtFront(char c){
    Node *new_node = new Node;
    new_node->letter = c;
    new_node->next = nullptr;
    new_node->prev = nullptr;
    if(numItems == 0){
        back = new_node;
    }
    else {
        Node *temp = front;
        temp->prev = new_node;
        new_node->next = front;
    }
    front = new_node;
    numItems++;
}

/*
 * name:      CharLinkedList pushAtBack function
 * purpose:   puts a character at the back of an LL 
 * arguments: none
 * returns:   none
 * effects:   deletes everything on the heap associated with a linked list
*/
void CharLinkedList::pushAtBack(char c){
    //create a new node with char c 
    Node *new_node = newNode(c, nullptr);
    
    if(numItems == 0){
        front = new_node;
    }
    else{
        Node *temp = back;
        temp->next = new_node;
        new_node->prev = back;
    }
    back = new_node;
    numItems++;
}

/*
 * name:      CharLinkedList destructor
 * purpose:   gets rid of memory associated with a linked list
 * arguments: none
 * returns:   none
 * effects:   deletes everything on the heap associated with a linked list
*/
CharLinkedList::~CharLinkedList(){
    recycleRecursive(front);
}

/*
 * name:      CharLinkedList recursive destructor helper
 * purpose:   recurses through a linked list and deletes nodes
 * arguments: a Node
 * returns:   none
 * effects:   deletes all Nodes in a Linked List
*/
void CharLinkedList::recycleRecursive(Node *curr){
    if(curr == nullptr) return;
    else{
        Node *next = curr->next;
        delete curr;
        recycleRecursive(next);
    }  
}

/*
 * name:      size()
 * purpose:   find the size of the linked list 
 * arguments: none
 * returns:   the size of the linked list as an integer
 * effects:   none
*/
int CharLinkedList::size() const{
    return numItems;
}

/*
 * name:      newNode()
 * purpose:   create a new node
 * arguments: a letter and the next node in the linked list
 * returns:   a node
 * effects:   creates a node
*/
CharLinkedList::Node* CharLinkedList::newNode(char let, Node *nextNode){
    Node *new_node = new Node;
    new_node->letter = let;
    new_node->next = nextNode;
    new_node->prev = nullptr;
    
    return new_node;
}

/*
 * name:      toString()
 * purpose:   turns the linked list into a string 
 * arguments: none
 * returns:   a string
 * effects:   none
*/
std::string CharLinkedList::toString() const{
    std::string output = "[CharLinkedList of size " + std::to_string(numItems) +
    " <<";

    Node *curr = front;
    while(curr != nullptr){
        output = output + curr->letter;
        curr = curr->next;
    }

    output = output + ">>]";

    return output;
}

/*
 * name:      toReverseString()
 * purpose:   turns the linked list into a string, but reversed 
 * arguments: none
 * returns:   a string
 * effects:   none
*/
std::string CharLinkedList::toReverseString() const{
    std::string output = "[CharLinkedList of size " + std::to_string(numItems) +
    " <<";

    Node *curr = back;

    while(curr != nullptr){
        output = output + curr->letter;
        curr = curr->prev;
    }

    output = output + ">>]";

    return output;
}

/*
 * name:      CharLinkedList isEmpty function
 * purpose:   checks if a LL is empty (no items)
 * arguments: none
 * returns:   a boolean, returns true if empty, false if not
 * effects:   none
*/
bool CharLinkedList::isEmpty() const{
    if(numItems == 0){
        return true;
    }
    else return false;
}

/*
 * name:      CharLinkedList first function
 * purpose:   gets the first item in the LL
 * arguments: none
 * returns:   the first character in the LL 
 * effects:   none
*/
char CharLinkedList::first() const{
    if(numItems == 0){
        throw std::runtime_error("cannot get first of empty LinkedList");
    }
    return front->letter;
}

/*
 * name:      CharLinkedList last function
 * purpose:   gets the last item in the LL
 * arguments: none
 * returns:   the last character in the LL 
 * effects:   none
*/
char CharLinkedList::last() const{
    if(numItems == 0){
        throw std::runtime_error("cannot get last of empty LinkedList");
    }
    return back->letter;
}

/*
 * name:      CharLinkedList elementAt function
 * purpose:   finds the character at a certain index in the LL
 * arguments: an index 
 * returns:   a character
 * effects:   none
*/
char CharLinkedList::elementAt(int index) const{
    if(index < 0 or index >= numItems){
        throw std::range_error("index (" + std::to_string(index) + ")" + 
        " not in range [0.." + std::to_string(numItems) + ")");
    }

    Node *found = recurseFind(front, index);
    return found->letter;
    
}

/*
 * name:      CharLinkedList insertAt function
 * purpose:   inserts a character at a specified index in a LL
 * arguments: a character (char) and an index (integer)
 * returns:   none
 * effects:   increases numItems, adds a node to the list
*/
void CharLinkedList::insertAt(char c, int index){
    //if it's out of bounds throw an error 
    if(index < 0 or index > numItems){
        throw std::range_error("index (" + std::to_string(index) + ")" + 
        " not in range [0.." + std::to_string(numItems) + "]");
    }

    if(index == 0){ //if its the front of the array, just use pushAtFront
        pushAtFront(c);
    }
    else if(index != numItems){
        Node *curr = front; //temp pointer to the front 
        int curr_index = 0; //the index of where the pointer is in the list 

        while(curr_index < index - 1){ //finds where to put the new node
            curr = curr->next;
            curr_index++;
        }

        Node *before = curr; //temp pointers for before and after the new node
        Node *after = curr->next;

        Node *new_node = new Node; //create a new node, insert the letter 
        new_node->letter = c;
        
        new_node->prev = before; //link the new node to before and after 
        new_node->next = after;

        before->next = new_node; //link the preexisting nodes to the new node 
        after->prev = new_node;

        numItems++; //increase the number of items 
    }
    else{ //if its the last node in the array, just pushAtBack 
        pushAtBack(c); 
    }
}

/*
 * name:      CharLinkedList insertInOrder function
 * purpose:   puts a character in the ASCII order 
 * arguments: a character c (char)
 * returns:   none
 * effects:   increases the number of items, inserts a character into the list
*/
void CharLinkedList::insertInOrder(char c){
    bool flag = true; 
    int index = numItems;
    Node *curr = front; //temporary pointer to the front

    for(int i = 0; i < numItems; i++){ //loops through the list
        if((c < curr->letter) and flag){ //if c is less than the next letter
            index = i; //set the right index to i and change the flag to false
            flag = false; //so the index won't change 
        }
        curr = curr->next; //increment curr for the next for loop iteration
    }

    insertAt(c, index); //insert the character at the specified index 

}

/*
 * name:      CharLinkedList popFromFront function
 * purpose:   deletes the first Node in the LL
 * arguments: none
 * returns:   none
 * effects:   deletes the first Node, decreases the number of items
*/
void CharLinkedList::popFromFront(){
    if(numItems == 0){
        throw std::runtime_error("cannot pop from empty LinkedList");
    }
    else if(numItems == 1){
        delete front;
        front = nullptr;
        back = nullptr;
    }
    else{
        Node *temp = front;
        front = front->next;
        
        delete temp;

        front->prev = nullptr;
    }
    numItems--;
}

/*
 * name:      CharLinkedList popFromBack function
 * purpose:   deletes a node from the back of the linked list
 * arguments: none
 * returns:   none
 * effects:   decreases numItems, deletes a node from the back of the array
*/
void CharLinkedList::popFromBack(){
    if(numItems == 0){ //throw an error if its an empty LL
        throw std::runtime_error("cannot pop from empty LinkedList");
    }
    else if(numItems == 1){ //if theres only one item
        delete front; //delete front, set front and back to nullptr
        front = nullptr;
        back = nullptr;
    }
    else{ 
        Node *temp = back; //set a temporary value to the back 
        back = back->prev; //change the back to equal the Node previous 

        delete temp; //delete the old back Node

        back->next = nullptr; //change the back's next to nullptr 
    }
    numItems--; //decrease the number of items 
}

/*
 * name:      CharLinkedList recurseFind function
 * purpose:   recursively finds a node within a LL
 * arguments: a Node and an index (int)
 * returns:   a Node
 * effects:   none
*/
CharLinkedList::Node* CharLinkedList::recurseFind(Node* curr, int index) const{
    if(index == 0){ //if it has recursed as many times as the index
        return curr; //return the current node 
    }
    //otherwise call the function again with the next node, and subtract index
    return recurseFind(curr->next, (index - 1));
}

/*
 * name:      CharLinkedList replaceAt function
 * purpose:   replaces a letter 
 * arguments: a character and an index 
 * returns:   none
 * effects:   replaces a letter in the LL at a specified index 
*/
void CharLinkedList::replaceAt(char c, int index){
    if(index < 0 or index >= numItems){ //throws an error if out of range 
        throw std::range_error("index (" + std::to_string(index) + ")" + 
        " not in range [0.." + std::to_string(numItems) + ")");
    }
    //call the recursive function, replace the letter in the returned Node 
    Node *found = recurseFind(front, index);
    found->letter = c;
}

/*
 * name:      CharLinkedList clear function
 * purpose:   deletes all the nodes in the LL
 * arguments: none
 * returns:   none
 * effects:   deletes all the nodes in the LL, changes numItems to 0, changes
 *            the front and back pointers to nullptr
*/
void CharLinkedList::clear(){
    Node *curr = front; //temporary variables to the front

    while(curr != nullptr){ //loop through the linked lists
        Node *temp = curr; 
        curr = curr->next; //iterate through, delete the temporary pointers
        front = curr; 
        delete temp; //delete the temp Node
        numItems--; //decrease numItems 
    }

    front = nullptr; //change front and back to nullptr
    back = nullptr;
}

/*
 * name:      CharLinkedList removeAt function
 * purpose:   removes a Node at a certain index
 * arguments: an index (int)
 * returns:   none
 * effects:   decreases numItems by 1, changes next and previous pointers
 *            to accomodate for the removed pointer 
*/
void CharLinkedList::removeAt(int index){
    if(index < 0 or index >= numItems){ //throws an error if out of bounds given
        throw std::range_error("index (" + std::to_string(index) + ")" + 
        " not in range [0.." + std::to_string(numItems) + ")");
    }

    if(index == 0) popFromFront();//if its for the first index, use popFromFront
    else if(index != (numItems - 1)){
        Node *found = recurseFind(front, index);     //find the before, after, 
        Node *before = recurseFind(front, index - 1);//and the node to be 
        Node *after = recurseFind(front, index + 1);//removed

        before->next = after; //switch around the pointers
        after->prev = before;

        delete found; //delete the pointer 

        numItems--; //decrease the number of items 
    }
    else popFromBack(); //if its the last indicy, just use popFromBack
    
}

/*
 * name:      CharLinkedList concatenate function
 * purpose:   adds a linked list to the back of another 
 * arguments: another CharlinkedList
 * returns:   none
 * effects:   increases numItems and moves around pointers
*/
void CharLinkedList::concatenate(CharLinkedList *other){
    if(other->numItems != 0){ //if the list to add's size is NOT 0
        if(other->toString() == toString()){ //if its the same list
            CharLinkedList copy = *other; //create a deep vopy
            //keeps track of what we're copying over
            Node *list2curr = copy.front;

            while(list2curr != nullptr){ //copy everything over using pushAtBack
                pushAtBack(list2curr->letter);
                list2curr = list2curr->next;
            }
        }
        else{
            //keeps track of what we're copying over
            Node *list2curr = other->front;

            while(list2curr != nullptr){//copys everything over using pushAtBack
                pushAtBack(list2curr->letter);
                list2curr = list2curr->next;
            }
        }
    }    
}
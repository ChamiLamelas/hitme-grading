/*
 *  unit_tests.h
 *  Alex Li
 *  1/31/2024 
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  This is the unit testing file that ensures the proper function
 *  of all functions/constructors in the CharLinkedList class
 *
 */

#include "CharLinkedList.h"
#include <cassert>
#include <string>
#include <iostream>

using namespace std;

/*
 * unit_tests.h
 *
 * CS 15 Homework 2
 * By: Tyler Calabrese
 * Edited by: Alex Li
 * Date: 2/4/2024


/*
 * constructor test 0
 * Make sure no fatal errors/memory leaks occur in the default constructor
 */

void constructor_test_0() {

    CharLinkedList list;

    assert(list.isEmpty());
    assert(list.size() == 0);


}

/*
 * constructor test 1
 * Make sure no fatal errors/memory leaks occur in the second constructor
 * Test size/isEmpty functions
 * Ensure first() and last() functions work properly
 */ 

void constructor_test_1() {

    CharLinkedList list('d');

    assert(not(list.isEmpty()));
    assert(list.size() == 1);
    assert(list.first() == 'd');
    assert(list.last() == 'd');

}

/*
 * constructor test 2
 * Make sure no fatal errors/memory leaks in the third constructor
 * Test Size function
 * Ensure first() and last() functions work properly
 */

void constructor_test2() {

    char testList[] = {'c', 'd', 'e', 'g', 'h'};
    int value = 5; 

    CharLinkedList list(testList, value);

    assert(list.size() == 5);
    assert(list.first() == 'c');
    assert(list.last() == 'h');

}

/*
 * deepCopy constructor test
 * Make sure no fatal errors/memory leaks in the deepCopy constructor
 * Ensure the lists have identical values and size
 * Ensure a change in the deep copy does not affect the initial list
 * (No shallow copies)
 */

void deepCopy_test() {

    char tempArr[] = {'j', 'h', 'f'};
    int length = 3;

    CharLinkedList list(tempArr, length);
    CharLinkedList deep_copy(list);

    assert(deep_copy.size() == 3);
    assert(deep_copy.first() == 'j');
    assert(deep_copy.last() == 'f');

    deep_copy.pushAtFront('k');
    assert(list.first() == 'j');

}

/* Ensure the clear function works as properly
 * Make sure no memory leaks occur when clearing the list
 * assert that size has been changed appropriately 
*/ 

void clear_test() {

    char arr[] = {'g', 'l', 'i'};
    CharLinkedList list(arr, 3);

    list.clear();

    assert(list.isEmpty());

}

/* Ensure the first function throws
 * an error properly when trying to 
 * access the first element of an empty CharLinkedList
 * */

void first_fail_test() {

    CharLinkedList list;
    bool runtime_error_thrown = false;
    std::string error_message = "";

    try {
        list.first();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot get first of empty LinkedList");

}

/* Ensure the last function throws
 * an error properly when trying to 
 * access the last element of an empty CharLinkedList
 * */

void last_fail_test() {

    CharLinkedList list;
    bool runtime_error_thrown = false;
    std::string error_message = "";

    try {
        list.last();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot get last of empty LinkedList");

}

/* Ensure the elementAt function works as properly
 * and returns the correct element at a specified
 * index
 */

void elementAt_test() {

    char testList[] = {'c', 'd', 'e', 'g', 'h'};
    int value = 5; 

    CharLinkedList list(testList, value);

    assert(list.elementAt(0) == 'c');
    assert(list.elementAt(1) == 'd');
    assert(list.elementAt(2) == 'e');
    assert(list.elementAt(3) == 'g');
    assert(list.elementAt(4) == 'h');

}

/* Ensure the elementAt function throws an error
 * when trying to access an element out of bounds
 */

void elementAtFail_test() {

    CharLinkedList list;
    bool range_error_thrown = false;
    std::string error_message = "";

    try {
        list.elementAt(50);
    }
    catch (const std::range_error &e) {

        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (50) not in range [0..0)");

}

/* toString function tester
 * ensure that toString outputs the correct message
 * according to the homework guidelines
*/

void toString_test() {

    char testList[] = {'c', 'd', 'e', 'g', 'h'};
    int value = 5; 

    CharLinkedList list(testList, value);

    assert(list.toString() == "[CharLinkedList of size 5 <<cdegh>>]");

}

/* toReverseString function tester
 * ensure that toReverseString outputs the correct 
 * message according to the homework guidelines
*/

void toReverseString_test() {

    char testList[] = {'c', 'd', 'e', 'g', 'h'};
    int value = 5; 

    CharLinkedList list(testList, value);

    assert (list.toReverseString() == "[CharLinkedList of size 5 <<hgedc>>]");

}

/* assignment operator test
 * Ensure that the assignment operator correctly
 * performs a deep copy of the previous list
 * and that altering the new list does not affect
 * heap memory in the old list */

void assignmentOperator_test() {

    char testList[] = {'h', 'b', 'c', 'g'};
    int value = 4; 

    CharLinkedList list(testList, value);
    CharLinkedList copy_list = list;

    assert (copy_list.first() == 'h');
    assert (copy_list.last() == 'g');

    copy_list.clear();

    assert(not(list.isEmpty())); // make sure list hasn't changed
    assert(copy_list.isEmpty());
    assert(list.first() == 'h');

}

/* assignment operator test
 * Ensure that the assignment operator correctly
 * performs a deep copy of the previous list
 * when copying an empty CharLinkedList to a 
 * filled CharLinkedList
 */

void assignmentOperator_test_empty() {

    char testList[] = {'e', 'f', 'c', 'g'};
    int value = 4; 

    CharLinkedList copy_list(testList, value);
    CharLinkedList list;

    copy_list = list;

    assert(copy_list.isEmpty()); 

}

/* assignment operator test
 * Ensure that the assignment operator correctly
 * performs a deep copy of the previous list
 * when copying a filled CharLinkedList to a newly
 * declared CharLinkedList variable
 * Ensure no memory leaks 
 */

void assignmentOperator_test_new() {

    char testList[] = {'e', 'f', 'c', 'g'};
    int value = 4; 

    CharLinkedList list(testList, value);
    CharLinkedList copy_list = list;

    assert(copy_list.toString() == "[CharLinkedList of size 4 <<efcg>>]");

}

/* pushAtBack test
 * ensure that the pushAtBack function
 * adds an element to the back as expected
 * and does not modify the existing elements in the list
 * Also make sure the size variable changes
 * appropriately
*/

void pushAtBack_test() {

    CharLinkedList list('g');

    list.pushAtBack('e');

    assert(list.elementAt(0) == 'g');
    assert(list.elementAt(1) == 'e');
    assert(list.size() == 2);

}

/* pushAtBack test for an empty list
 * ensure that the pushAtBack function
 * adds an element to the back as expected
 * even for an empty list
 */

void pushAtBack_test_emptyList() {

    CharLinkedList list;

    list.pushAtBack('a');

    assert(list.size() == 1);
    assert(list.first() == 'a');

}

/* pushAtFront test
* ensure that the pushAtFront function
* adds an element to the front as expected
* Also make sure the size variable changes
* appropriately
*/

void pushAtFront_test() {

    char testList[] = {'a', 'b', 'c', 'd'};
    int value = 4; 

    CharLinkedList list(testList, value);

    list.pushAtFront('z');
    list.pushAtFront('y');

    assert(list.elementAt(5) == 'd');
    assert(list.elementAt(4) == 'c');
    assert(list.elementAt(3) == 'b');
    assert(list.elementAt(2) == 'a');
    assert(list.elementAt(1) == 'z');
    assert(list.elementAt(0) == 'y');
    assert(list.size() == 6);
}

/* pushAtFront test for an empty list
 * ensure that the pushAtFront function
 * adds an element to the front as expected
 * even for an empty list
 */

void pushAtFront_test_emptyList() {

    CharLinkedList list;

    list.pushAtFront('a');

    assert(list.size() == 1);
    assert(list.first() == 'a');
    assert(list.last() == 'a');

}


// Tests correct insertion into an empty CharLinkedList.
// Afterwards, size should be 1 and element at index 0
// should be the element we inserted.

void insertAt_empty_correct() { 

    CharLinkedList test_list;

    test_list.insertAt('a', 0);

    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');

}


// Tests incorrect insertion into an empty CharLinkedList.
// Attempts to call insertAt for index larger than 0.
// This should result in an std::range_error being raised.

void insertAt_empty_incorrect() {

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    // insertAt for out-of-range index
    test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
    // if insertAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    range_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0]");
    
}

// Tests correct insertAt for front of 1-element list.
void insertAt_front_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at front
    test_list.insertAt('b', 0);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'a');
    
}

// Tests correct insertAt for back of 1-element list.
void insertAt_back_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at back
    test_list.insertAt('b', 1);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    
}

// Tests calling insertAt for a large number of elements.
// Ensure no edge case errors occur in larger lists 
void insertAt_many_elements() {
    
    CharLinkedList test_list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.insertAt('a', i);
    }

    assert(test_list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
    
}

// Tests insertion into front of a larger list
void insertAt_front_large_list() {
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    test_list.insertAt('y', 0);

    assert(test_list.size() == 10);
    assert(test_list.elementAt(0) == 'y');
    assert(test_list.toString() == 
    "[CharLinkedList of size 10 <<yabczdefgh>>]");

}

// Tests insertion into the back of a larger list
void insertAt_back_large_list() {

    char test_arr[10] = { 'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 10);  

    test_list.insertAt('x', 10);

    assert(test_list.size() == 11);
    assert(test_list.elementAt(10) == 'x');
    assert(test_list.toString() == 
    "[CharLinkedList of size 11 <<yabczdefghx>>]"); 

}

// Tests insertion into the middle of a larger list
void insertAt_middle_large_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.insertAt('z', 3);

    assert(test_list.size() == 9);
    assert(test_list.elementAt(3) == 'z');
    assert(test_list.toString() == "[CharLinkedList of size 9 <<abczdefgh>>]");

}

// Tests out-of-range insertion for a non-empty list.
void insertAt_nonempty_incorrect() {
   
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8]");
    
}

/* Ensure the insertInOrder function inserts the element appropriately 
 * into the correct indicies, changing the size of the LinkedList as follows
*/

void insertInOrder_test() {

    char test_arr[5] = { 'a', 'l', 'n', 'y', 'z' };

    CharLinkedList test_list(test_arr, 5);

    test_list.insertInOrder('b');
    test_list.insertInOrder('f');
    test_list.insertInOrder('l');
    test_list.insertInOrder('m');
    test_list.insertInOrder('q');
    test_list.insertInOrder('y');
    test_list.insertInOrder('z');

    //expected output of modified test_list.toString()
    string correct = "[CharLinkedList of size 12 <<abfllmnqyyzz>>]";

    assert(test_list.toString() == correct);

}

// Tests calling insertInOrder for a large number of elements.
// Ensure no edge cases occur with a larger list
void insertInOrder_many_elements() {
    
    CharLinkedList test_list;

    // insert 1000 elements
    for (int i = 'a'; i < 'z'; i++) {
        // always insert at the back of the list
        test_list.insertInOrder(i);
    }

    assert(test_list.size() == 25);
    assert(test_list.toString() == 
    "[CharLinkedList of size 25 <<abcdefghijklmnopqrstuvwxy>>]");
}

/* popFromFront function test 
 * Ensure that removing an element from
 * the front changes the size, list, and
 * first/last elements appropriately
*/

void popFromFront_test() {

    char values[6] = {'b', 'd', 'e', 'l', 'p', 'q'};

    CharLinkedList list(values, 6);

    list.popFromFront();

    assert(list.size() == 5);
    assert(list.first() == 'd');
    assert(list.last() == 'q');

    list.popFromFront();

    assert(list.size() == 4);
    assert(list.first() == 'e');
    assert(list.last() == 'q');

    list.popFromFront();

    assert(list.size() == 3);
    assert(list.first() == 'l');
    assert(list.last() == 'q');

}

/* popFromFront function test 
 * Ensure that removing an element from
 * the front of an 1 element CharLinkedList does not cause
 * any errors (as an edge case)
*/

void popFromFront_oneElementTest() {
    
    CharLinkedList list('e');
    list.popFromFront();

    assert(list.size() == 0);
    assert(list.isEmpty());
}

// /* popFromFront function fail test 
//  * Ensure that attempting to remove 
//  * the first element from an empty CharLinkedList 
//  * throws the runtime error message appropriately 
// */

void popFromFront_fail() {

    CharLinkedList list;
    bool runtime_error_thrown = false;
    std::string error_message = "";

    try {
        list.popFromFront();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");

}

/* popFromBack function test 
 * Ensure that removing an element from
 * the back changes the size, list, and
 * first/last elements appropriately
*/

void popFromBack_test() {

    char values[6] = {'b', 'd', 'e', 'l', 'p', 'q'};

    CharLinkedList list(values, 6);

    list.popFromBack();

    assert(list.size() == 5); // ensuring the CharLinkedLists change properly
    assert(list.first() == 'b');
    assert(list.last() == 'p');

    list.popFromBack();

    assert(list.size() == 4);
    assert(list.first() == 'b');
    assert(list.last() == 'l');

    list.popFromBack();

    assert(list.size() == 3);
    assert(list.first() == 'b');
    assert(list.last() == 'e');

}

/* popFromBack function fail test 
 * Ensure that attempting to remove 
 * the last element from an empty CharLinkedList 
 * throws the runtime error message appropriately 
*/

void popFromBack_fail() {

    CharLinkedList list;
    bool runtime_error_thrown = false;
    std::string error_message = "";

    try {
        list.popFromBack();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");

}

/* popFromBack function test 
 * Ensure that removing an element from
 * the back of an 1 element CharLinkedList does not cause
 * any errors (as an edge case)
*/

void popFromBack_oneElementTest() {
    
    CharLinkedList list('z');
    list.popFromBack();

    assert(list.size() == 0);
    assert(list.isEmpty());
}

/* removeAt function tester
 * ensure that the function removes an element at 
 * a specified index appropriately and changes 
 * the size appropriately
*/

void removeAt_test() {

    char values[10] = {'a', 'b', 'c', 'd', 'e', 'f', 'g','h', 'i', 'j'};
    CharLinkedList list(values, 10);

    list.removeAt(0);

    assert(list.size() == 9);
    assert(list.first() == 'b');
    assert(list.last() == 'j');

    list.removeAt(0);

    assert(list.size() == 8);
    assert(list.first() == 'c');
    assert(list.last() == 'j');

    list.removeAt(0);

    assert(list.size() == 7);
    assert(list.first() == 'd');
    assert(list.last() == 'j');

    list.removeAt(0);

    assert(list.size() == 6);
    assert(list.first() == 'e');
    assert(list.last() == 'j');

}

/* removeAt function tester
 * ensure that the function throws a range error when trying to 
 * remove an element out of bounds
*/

void removeAt_fail_test() {

    CharLinkedList list;
    bool range_error_thrown = false;
    std::string error_message = "";

    try { 
        list.removeAt(20);
    }
    catch(const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (20) not in range [0..0)");
}

/* replaceAt function tester
 * Ensure that the replaceAt function 
 * works appropriately and does not modify
 * the rest of the CharLinkedList
*/

void replaceAt_test() {

    char values[10] = {'a', 'b', 'c', 'd', 'e', 'f', 'g','h', 'i', 'j'};

    CharLinkedList list(values, 10);

    list.replaceAt('z', 0);
    list.replaceAt('f', 4);
    list.replaceAt('q', 9);

    assert(list.size() == 10);
    assert(list.toString() == "[CharLinkedList of size 10 <<zbcdffghiq>>]");

}

/* replaceAt function fail tester
 * Ensure that the replaceAt function 
 * throws a correct range error when 
 * trying to replace an element out of the index range
*/

void replaceAt_test_fail() {

    CharLinkedList list;
    bool range_error_thrown = false;
    std::string error_message = "";

    try { 
        list.replaceAt('a', 20);
    }
    catch(const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (20) not in range [0..0)");

}

/* concatenate function tester
 * ensures that the function correctly
 * adds a copy of the parameter CharLinkedList
 * to the end of the CharLinkedList the function
 * was called from.
 * For this test, we are testing concatenate
 * with two lists that both contain elements
*/

void concatenateTwoLists_test() {

    char list1Array[5] = {'j', 'a', 'm', 'e', 's'};
    char list2Array[3] = {'s', 'a', 'm'};

    CharLinkedList list1(list1Array, 5);
    CharLinkedList list2(list2Array, 3);

    list1.concatenate(&list2);


    assert(list1.size() == 8);
    assert(list1.toString() == "[CharLinkedList of size 8 <<jamessam>>]");

}

/* concatenate function tester
 * ensures that the function correctly
 * adds a copy of the parameter CharLinkedList
 * to the end of the CharLinkedList the function
 * was called from.
 * For this test, we are testing concatenation with
 * an empty list. Also ensure that the function does
 * not change the parameter CharLinkedList
*/

void concatenateWithEmptyList_test() {

    char list1Array[5] = {'a', 'l', 'i', 'c', 'e'};

    CharLinkedList list1(list1Array, 5);
    CharLinkedList list2;

    list1.concatenate(&list2);

    assert(list1.size() == 5);
    assert(list1.toString() == "[CharLinkedList of size 5 <<alice>>]");
    assert(list2.isEmpty()); // check that list2 hasn't been modified

}

/* concatenate function tester
 * ensures that the function correctly
 * adds a copy of the parameter CharLinkedList
 * to the end of the CharLinkedList the function
 * was called from.
 * For this test, we are testing concatenating to
 * an empty list.
*/

void concatenateToEmptyList() {

    char list2Array[6] = {'h', 'u', 'n', 't', 'e', 'r'};

    CharLinkedList list1;
    CharLinkedList list2(list2Array, 6);

    list1.concatenate(&list2);

    assert(list1.size() == 6);
    assert(list1.toString() == "[CharLinkedList of size 6 <<hunter>>]");
    assert(list2.toString() == "[CharLinkedList of size 6 <<hunter>>]");

}

/* concatenate function tester
 * ensures that the function correctly
 * adds a copy of the parameter CharLinkedList
 * to the end of the CharLinkedList the function
 * was called from.
 * For this test, we are testing concatenating the same
 * list to itself
*/

void concatenateToSelf() {

    char list1Array[5] = {'m', 'o', 'l', 'l', 'y'};

    CharLinkedList list(list1Array, 5);

    list.concatenate(&list);

    assert(list.size() == 10);
    assert(list.toString() == "[CharLinkedList of size 10 <<mollymolly>>]");

}

/* concatenate function tester
 * ensures that the function correctly
 * adds a copy of the parameter CharLinkedList
 * to the end of the CharLinkedList the function
 * was called from.
 * For this test, we are testing concatenating the same
 * list to itself but this time the list is empty
*/

void concatenateToSelfEmpty() {

    CharLinkedList list;

    list.concatenate(&list);

    assert(list.isEmpty());
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
    
}
/*
 *  CharLinkedList.cpp
 *  Alex Li
 *  1/31/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Purpose: This file contains the implementation of the CharLinkedList class, 
 *  which represents a doubly linked list containing characters. 
 */

#include "CharLinkedList.h"
#include <iostream>
#include <string>

using namespace std;

/*
 * name:      CharLinkedList default constructor
 * purpose:   creates an empty CharLinkedList
 * arguments: none
 * returns:   none
 */
CharLinkedList::CharLinkedList() {

    front = nullptr;
    back = nullptr;
    currSize = 0;

}


/*
 * name:      newNode
 * purpose:   creates a new Node and stores data and pointers within it
 * arguments: two Node pointers to the next and prev Nodes, and a char c
 *            to be stored as the data of the Node
 * returns:   a pointer to the new node
 */
CharLinkedList::Node* CharLinkedList::newNode(char c, Node *next, Node *prev) {

    Node *temp = new Node();
    temp->data = c;
    temp->next = next;
    temp->prev = prev;
    return temp;

}

/*
 * name:      CharLinkedList constructor
 * purpose:   creates a new CharLinkedList of size 1 with a given character c
 * arguments: a character to be stored in the linked list
 * returns:   none
 */

CharLinkedList::CharLinkedList(char c) {
    
    front = newNode(c, nullptr, nullptr);
    back = front;
    currSize = 1;

}

/*
 * name:      CharLinkedList constructor
 * purpose:   creates a new CharLinkedList with the same elements and 
 *            size as those of the array
 * arguments: a character array to effectively copy data from, an int 
 *            representing the array length
 * returns:   none
 */

CharLinkedList::CharLinkedList(char arr[], int size) {

    front = nullptr;
    back = nullptr;
    currSize = 0;

    for (int i = 0; i < size; i++) {
        pushAtBack(arr[i]); // keep adding all char elements from arr to back
                            // of LinkedList
    }
}

/*
 * name:      CharLinkedList constructor
 * purpose:   creates a new deep copy of a given CharLinkedList
 * arguments: a CharLinkedList instance that we are going to deep copy 
 * returns:   none
 */


CharLinkedList::CharLinkedList(const CharLinkedList &other) {

    front = nullptr;
    back = nullptr;
    currSize = 0;
    
    for (int i = 0; i < other.currSize; i++) {
        
        // keep adding all char elements from other to back
        // of LinkedList
        pushAtBack(other.elementAt(i)); 
    }

}

/*
 * name:      CharLinkedList destructor
 * purpose:   frees up all heap memory used by node instances in CharLinkedList
 * arguments: none
 * returns:   none
 */

CharLinkedList::~CharLinkedList() {

    recycleRecursive(front); 

}

/*
 * name:      recycleRecursive
 * purpose:   recursive helper function that traverses through a 
 *            CharLinkedList and deletes nodes one at a time to free up heap 
 *            memory
 * arguments: a pointer to a node
 * returns:   none
 */

void CharLinkedList::recycleRecursive(Node *curr) {

    if (curr == nullptr) {
        return;
    }

    Node *temp = curr->next;

    delete curr;

    recycleRecursive(temp);

}

/*
 * name:      CharLinkedList overloaded assignment operator
 * purpose:   make a deep copy of the right side instance and assign it to 
 *            the instance on the left side 
 * arguments: CharLinkedList instance
 * returns:   a reference to the current instance
 */

CharLinkedList& CharLinkedList::operator=(const CharLinkedList &other) {

    if (this == &other) {
        return *this;
    }

    recycleRecursive(front); 

    front = nullptr;
    back = nullptr;
    currSize = 0;
        
    for (int i = 0; i < other.currSize; i++) {
        pushAtBack(other.elementAt(i));
    }

    return *this;
}

/*
 * name:      isEmpty
 * purpose:   determine if a given CharLinkedList is empty
 * arguments: none
 * returns:   a boolean representing if the LinkedList is empty
 */

bool CharLinkedList::isEmpty() const {

    return (currSize == 0);

}

/*
 * name:      size
 * purpose:   provide the size of a given CharLinkedList
 * arguments: none
 * returns:   an integer representing the size of the LinkedList
 */

int CharLinkedList::size() const {

    return (currSize);

}

/*
 * name:      clear
 * purpose:   empty a given CharLinkedList and free up previous heap memory
 * arguments: none
 * returns:   none
 */

void CharLinkedList::clear() {

    recycleRecursive(front);
    currSize = 0;
    front = nullptr; 
    back = nullptr; 

}

/*
 * name:      first
 * purpose:   return the first element in a CharLinkedList
 * arguments: none
 * returns:   the first character in the CharLinkedList
 * effects:   throws a runtime error if the list is empty
 */

char CharLinkedList::first() const {

    if (isEmpty()) {
        throw runtime_error("cannot get first of empty LinkedList");
    }
    else {
        return front->data;
    }

}

/*
 * name:      last
 * purpose:   return the last element in a CharLinkedList
 * arguments: none
 * returns:   the last character in the CharLinkedList
 * effects:   throws a runtime error if the list is empty
 */

char CharLinkedList::last() const {

    if (isEmpty()) {
        throw runtime_error("cannot get last of empty LinkedList");
    }
    else {
        return back->data;
    }
    
}

/*
 * name:      traverseTo
 * purpose:   recursively traverse through LinkedList
 * arguments: an integer value counting the number of recursive calls to the 
 *            function traverseTo, and a pointer to a Node curr representing 
 *            the current Node
 * returns:   a pointer to a Node 
 * effects:   when value == 0, that is the base case and stops recursive call
 *            will return Node pointer at element "value"
 */
CharLinkedList::Node* CharLinkedList::traverseTo(int value, Node* curr) const {
    if (value == 0) {
        return curr;
    }

    return traverseTo(value - 1, curr->next);
}

/*
 * name:      elementAt
 * purpose:   get the element at a given index of a CharLinkedList
 * arguments: an integer index representing a CharLinkedList index we want
 * returns:   the character element at the index in the list 
 * effects:   throws a range error if trying to access an element out of bounds
 */
char CharLinkedList::elementAt(int index) const {

    // this functions checks whether the index is out of bounds
    // the false bool represents whether it is called in the insertAt function, 
    // in which the potential error message is different
    checkRangeError(index, false); 
                                
    // recursively traverse to the Node at the index
    Node *target = traverseTo(index, front);
    return target->data;
    

}

/*
 * name:      toString
 * purpose:   return a string containing the elements of CharLinkedList
 * arguments: none
 * returns:   a string containing characters of CharLinkedList
 */

std::string CharLinkedList::toString() const {

    string message = "[CharLinkedList of size " + std::to_string(currSize);
    message += " <<";

    for (int i = 0; i < currSize; i++) {
        message += elementAt(i);
    }

    message += ">>]";

    return message;
}

/*
 * name:      toReverseString
 * purpose:   return a string containing the characters of CharLinkedList, 
 *            reversed
 * arguments: none
 * returns:   a string containing the reversed characters of CharLinkedList
 */

std::string CharLinkedList::toReverseString() const {

    string message = "[CharLinkedList of size " + std::to_string(currSize);
    message += " <<";

    for (int i = currSize - 1; i >= 0; i--) {
        message += elementAt(i);
    }

    message += ">>]";

    return message;
}

/*
 * name:      pushAtBack
 * purpose:   place a character at the end of a CharLinkedList
 * arguments: a character to be placed at the end 
 * returns:   none
 */

void CharLinkedList::pushAtBack(char c) {

    Node *temp = back;
    back = newNode(c, nullptr, nullptr);

    if (currSize == 0) {
        front = back;
    }
    else {
        back->prev = temp; // only update prev/next if currSize isn't 0
        temp->next = back;
    }

    currSize++;
}

/*
 * name:      pushAtFront
 * purpose:   place a character at the front of a CharLinkedList
 * arguments: a character to be placed at the front
 * returns:   none
 */

void CharLinkedList::pushAtFront(char c) {
    
    Node *temp = front;
    front = newNode(c, nullptr, nullptr);

    if (currSize == 0) {
        back = front;
    }
    else {
        front->next = temp; // only update prev/next if currSize isn't 0
        temp->prev = front;
    }
    
    currSize++;

}

/*
 * name:      insertAt
 * purpose:   place a character at a given index in a CharLinkedList
 * arguments: a character to be placed, the index at which it is to be placed
 * returns:   none
 */

void CharLinkedList::insertAt(char c, int index) {

    // throw range error if index out of bounds. since it is called in 
    // insertAt, the bool value is true and displays a slightly different 
    // error message than that of elementAt, removeAt, etc.
    checkRangeError(index, true); 
    
    // push functions act as edge case checkers when inserted at the ends
    // of the LinkedList
    if (index == currSize) {
        pushAtBack(c);
    }
    else if (index == 0) {
        pushAtFront(c);
    }
    else { 
        Node *elementAtIndex = traverseTo(index, front);
        Node *element_prev = elementAtIndex->prev;

        // creates a new node in the middle with next/prev pointers to the 
        // previous Node at that index and the Node before
        Node *insertedElement = newNode(c, elementAtIndex, element_prev);

        elementAtIndex->prev = insertedElement;
        element_prev->next = insertedElement;

        currSize++;
    }
}


/*
 * name:      insertInOrder
 * purpose:   place a character in the correct alphabetical order in a 
 *            given CharLinkedList
 * arguments: a character to be inserted
 * returns:   none
 * note:      assumes the list is sorted in alphabetical order to begin
 */

void CharLinkedList::insertInOrder(char c) {

    if (currSize == 0) {
        pushAtFront(c); // if empty, just simply push c to front
    }
    else {
        int index = 0; // hold the index value to be inserted at
        Node *current_node = front;

        while (current_node != nullptr) {

            if (c <= current_node->data) {
                insertAt(c, index);
                return;
            }
            current_node = current_node->next;
            index++;
        }
        insertAt(c, index);
    }

}

/*
 * name:      popFromFront
 * purpose:   remove the first element from a given CharLinkedList
 * arguments: none
 * returns:   none
 * effects:   throws a runtime error if the list is empty
 */

void CharLinkedList::popFromFront() {

    if (isEmpty()) {
        throw runtime_error("cannot pop from empty LinkedList");
    }
    else if (currSize == 1) { // this is to handle edge cases where 
                              // front->prev is not defined
        clear();
        return;
    }
    
    Node *temp = front->next; 
    delete front;
    front = temp;
    front->prev = nullptr;
    currSize--; 
}

/*
 * name:      popFromBack
 * purpose:   remove the last element from a given CharLinkedList
 * arguments: none
 * returns:   none
 * effects:   throws a runtime error if the list is empty
 */

void CharLinkedList::popFromBack() {

    if (isEmpty()) {
        throw runtime_error("cannot pop from empty LinkedList");
    }
    else if (currSize == 1) { // also an edge case handler 
        clear();
        return;
    }
   
    Node *temp = back->prev; 
    delete back;
    back = temp;
    back->next = nullptr;
    currSize--; 
}

/*
 * name:      removeAt
 * purpose:   remove the character at a given index from a CharLinkedList
 * arguments: the index at which the character is to be removed
 * returns:   none
 * effects:   throws a range error if the index is out of bounds
 */

void CharLinkedList::removeAt(int index) {

    checkRangeError(index, false); // check if the index is out of bounds

    // these if-else if statements handle edge cases for removal using 
    // the previous pop functions
    if ((currSize == 1) or (index == 0)) { 
        popFromFront();
        return;
    }
    else if (index == currSize - 1) { 
        popFromBack();
        return;
    }

    Node *elementAt = traverseTo(index, front);
    Node *prevElement = elementAt->prev;
    Node *nextElement = elementAt->next;

    delete elementAt;
        
    prevElement->next = nextElement;
    nextElement->prev = prevElement;
    currSize--;
    
}

/*
 * name:      replaceAt
 * purpose:   replace the character at a given index in a CharLinkedList
 *            with a provided character
 * arguments: the index at which the character is to be replaced, the character
 *            that will be replacing it
 * returns:   none
 * effects:   throws a range error if the index is out of bounds
 */

void CharLinkedList::replaceAt(char c, int index) {

    checkRangeError(index, false); // check index in range
    
    // get pointer to node at index
    Node *element = traverseTo(index, front); 
    element->data = c;
}

/*
 * name:      concatenate
 * purpose:   add a copy of the parameter CharLinkedList to the end of the 
 *            list instance it is being called on, essentially merging
 *            two lists
 * arguments: a pointer to the list we want to concatenate
 * returns:   none
 * note:      essentially deep copies the elements of other to the end of the 
 *            current CharLinkedList instance
 */

void CharLinkedList::concatenate(CharLinkedList *other) {

    int otherSize = other->size();
    
    for (int i = 0; i < otherSize; i++) {
        pushAtBack(other->elementAt(i));
    }

}

/*
 * name:      checkRangeError
 * purpose:   reduce repeated code for throwing range errors by
 *            pre-creating the error message depending on which function
 *            it is in
 * arguments: the index to be tested, a boolean representing whether the
 *            function is called in insertAt
 * returns:   none
 * note:      if insert is true, the function will append a "]" to the end of
 *            the error message; otherwise, it will add a ")"
 */

void CharLinkedList::checkRangeError(int index, bool insert) const {

    // prepare the error message boilerplate
    string error = "index (" + to_string(index) + ") not in range ";
    error += "[0.." + to_string(currSize); 

    // first see if index is out of bounds in general - namely, for the
    // elementAt, removeAt, etc. functions
    if ((index < 0) or (index >= currSize)) {

        // if insert is false (not called in insertAt), we know the index
        // is out of bounds. add a ")" and throw the range error
        if (not(insert)) { 
            error += ")"; 
            throw range_error(error);
        }
        // now if insert is true, we recheck the index bounds for the insertAt
        // functions. if the index still isn't in range, we add a "]" and 
        // throw a slightly different range error
        else if ((index < 0) or (index > currSize)) {
            error += "]"; 
            throw range_error(error);
        }
    }

}

    

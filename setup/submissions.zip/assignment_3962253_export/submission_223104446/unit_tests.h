// Modified by Chami Lamelas, 06-19-2023
//      Made to follow style guide

#include "CharLinkedList.h"
#include <cassert>
#include <stdexcept>
#include <iostream>

void tostring_reverse_test() {
    char           characters[] = {'a', 'b', 'c', 'd'};
    CharLinkedList list(characters, 4);
    assert(list.toReverseString() == "[CharLinkedList of size 4 <<dcba>>]\n");

    list.removeAt(2);
    assert(list.toReverseString() == "[CharLinkedList of size 3 <<dba>>]\n");

    list.insertAt('x', 1);
    assert(list.toReverseString() == "[CharLinkedList of size 4 <<dbxa>>]\n");
}


void default_constructor_test() {
    CharLinkedList list;
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]\n");
}

void one_element_constructor_test() {
    char           fc = 'c';
    CharLinkedList list(fc);
    assert(list.first() == fc);
    assert(list.toString() == "[CharLinkedList of size 1 <<c>>]\n");
}

void arr_constructor_test() {
    char           characters[] = {'a', 'b', 'c', 'd'};
    CharLinkedList list(characters, 4);
    assert(list.toString() == "[CharLinkedList of size 4 <<abcd>>]\n");
}

void cc_test() {
    char            characters[] = {'a', 'b', 'c', 'd'};
    CharLinkedList *list         = new CharLinkedList(characters, 4);
    assert(list->toString() == "[CharLinkedList of size 4 <<abcd>>]\n");

    CharLinkedList copy(*list);
    assert(copy.toString() == "[CharLinkedList of size 4 <<abcd>>]\n");
    assert(copy.size() == 4);

    delete list;
    assert(copy.toString() == "[CharLinkedList of size 4 <<abcd>>]\n");
    assert(copy.size() == 4);
}

void asst_ovld_test() {
    char            characters[] = {'a', 'b', 'c', 'd'};
    CharLinkedList *list         = new CharLinkedList(characters, 4);
    assert(list->toString() == "[CharLinkedList of size 4 <<abcd>>]\n");

    CharLinkedList copy;
    copy = *list;
    assert(copy.toString() == "[CharLinkedList of size 4 <<abcd>>]\n");
    assert(copy.size() == 4);

    delete list;
    assert(copy.toString() == "[CharLinkedList of size 4 <<abcd>>]\n");
    assert(copy.size() == 4);
}

void clear_test() {
    char           characters[] = {'a', 'b', 'c', 'd'};
    CharLinkedList list(characters, 4);
    list.clear();
    assert(list.isEmpty());
}

void first_test() {
    char           characters[] = {'a', 'b', 'c', 'd'};
    CharLinkedList list(characters, 4);
    assert(list.first() == 'a');
    CharLinkedList empty_list;
    try {
        empty_list.first();
    } catch (const std::runtime_error &e) {
        assert(std::string(e.what()) == "cannot get first of empty LinkedList");
    }
}

void last_test() {
    char           characters[] = {'a', 'b', 'c', 'd'};
    CharLinkedList list(characters, 4);
    assert(list.first() == 'a');

    CharLinkedList empty_list;
    try {
        empty_list.last();
    } catch (const std::runtime_error &e) {
        assert(std::string(e.what()) == "cannot get last of empty LinkedList");
    }
}

void isEmpty_test() {
    CharLinkedList list;
    assert(list.isEmpty());

    CharLinkedList l2('c');
    assert(not l2.isEmpty());

    l2.clear();
    assert(l2.isEmpty());

    char           characters[] = {'a', 'b', 'c', 'd'};
    CharLinkedList l3(characters, 4);
    assert(not l3.isEmpty());
    l3.clear();
    assert(l3.isEmpty());
}


void elementAt_test() {
    CharLinkedList list('c');
    assert(list.elementAt(0) == 'c');

    try {
        list.elementAt(1);
    } catch (const std::range_error &e) {
        std::cout << e.what();
        assert(std::string(e.what()) == "index (1) not in range [0..1)");
    }
    char           characters[] = {'a', 'b', 'c', 'd'};
    CharLinkedList l2(characters, 4);

    for (int i = 0; i < 4; i++) {
        assert(l2.elementAt(i) == characters[i]);
    }
}

void pushAtFront_test() {
    CharLinkedList l;
    l.pushAtFront('a');
    assert(l.first() == 'a');
    assert(l.last() == 'a');
    assert(l.size() == 1);

    CharLinkedList l2('c');
    l2.pushAtFront('b');
    assert(l2.first() == 'b');
    assert(l2.last() == 'c');

    char           characters[] = {'a', 'b', 'c', 'd'};
    CharLinkedList l3(characters, 4);

    l3.pushAtFront('z');
    assert(l3.first() == 'z');
    assert(l3.last() == 'd');

    for (int i = 1; i < 5; i++) {
        assert(l3.elementAt(i) == characters[i - 1]);
    }
}

void insertAt_tests() {
    CharLinkedList l;
    l.insertAt('a', 0);
    assert(l.first() == 'a');
    assert(l.last() == 'a');
    assert(l.size() == 1);

    CharLinkedList l2('a');
    l2.insertAt('b', 1);
    assert(l2.first() == 'a');
    assert(l2.last() == 'b');

    l2.insertAt('z', 0);
    assert(l2.first() == 'z');
    assert(l2.elementAt(1) == 'a');
    assert(l2.last() == 'b');

    char           characters[] = {'a', 'b', 'c', 'd'};
    CharLinkedList l3(characters, 4);

    l3.insertAt('z', 1);
    assert(l3.elementAt(1) == 'z');
    assert(l3.first() == 'a');
    assert(l3.last() == 'd');
    assert(l3.size() == 5);

    l3.insertAt('q', 4);
    assert(l3.elementAt(4) == 'q');
    assert(l3.elementAt(1) == 'z');
    assert(l3.first() == 'a');
    assert(l3.last() == 'd');
    assert(l3.size() == 6);
}


void insertInOrder_tests() {
    CharLinkedList l;
    l.insertInOrder('a');
    assert(l.first() == 'a');
    assert(l.last() == 'a');
    assert(l.size() == 1);

    CharLinkedList l2('a');
    l2.insertInOrder('b');
    assert(l2.first() == 'a');
    assert(l2.last() == 'b');
    assert(l2.size() == 2);

    l2.insertInOrder('z');
    assert(l2.last() == 'z');
    assert(l2.elementAt(1) == 'b');
    assert(l2.first() == 'a');
    assert(l2.size() == 3);

    char           characters[] = {'a', 'b', 'c', 'd'};
    CharLinkedList l3(characters, 4);

    l3.insertInOrder('z');
    assert(l3.elementAt(4) == 'z');
    assert(l3.first() == 'a');
    assert(l3.last() == 'z');
    assert(l3.elementAt(3) == 'd');
    assert(l3.size() == 5);

    l3.insertInOrder('q');
    assert(l3.elementAt(4) == 'q');
    assert(l3.first() == 'a');
    assert(l3.last() == 'z');
    assert(l3.elementAt(3) == 'd');
    assert(l3.size() == 6);
}

void popFromFrontTest() {
    CharLinkedList l('c');
    l.popFromFront();
    assert(l.size() == 0);
    assert(l.isEmpty());
    try {
        l.popFromFront();
    } catch (const std::runtime_error &e) {
        assert(std::string(e.what()) == "cannot pop from empty LinkedList");
    }
}

void popFromBackTest() {
    CharLinkedList l;
    try {
        l.popFromBack();
    } catch (const std::runtime_error &e) {
        assert(std::string(e.what()) == "cannot pop from empty LinkedList");
    }

    CharLinkedList l2('c');
    l2.popFromBack();
    assert(l2.isEmpty());

    char           characters[] = {'a', 'b', 'c', 'd'};
    CharLinkedList l3(characters, 4);
    l3.popFromBack();
    assert(l3.last() == 'c');
    assert(l3.size() == 3);
}


void removeAtTest() {
    CharLinkedList l;
    try {
        l.removeAt(0);
    } catch (const std::runtime_error &e) {
        assert(std::string(e.what()) == "index (0) not in range [0..0)");
    }

    CharLinkedList l2('c');
    l2.removeAt(0);
    assert(l2.isEmpty());

    char           characters[] = {'a', 'b', 'c', 'd'};
    CharLinkedList l3(characters, 4);
    l3.removeAt(2);
    assert(l3.first() == 'a');
    assert(l3.last() == 'd');
    assert(l3.elementAt(1) == 'b');
    assert(l3.elementAt(2) == 'd');
    assert(l3.size() == 3);
}


void replaceAtTest() {
    CharLinkedList l;
    try {
        l.replaceAt('c', 0);
    } catch (const std::runtime_error &e) {
        assert(std::string(e.what()) == "index (0) not in range [0..0)");
    }

    CharLinkedList l2('c');
    l2.replaceAt('d', 0);
    assert(not l2.isEmpty());
    assert(l2.elementAt(0) == 'd');
    assert(l2.first() == 'd');
    assert(l2.last() == 'd');
    assert(l2.size() == 1);

    char           characters[] = {'a', 'b', 'c', 'd'};
    CharLinkedList l3(characters, 4);
    l3.replaceAt('z', 2);
    assert(l3.first() == 'a');
    assert(l3.last() == 'd');
    assert(l3.elementAt(1) == 'b');
    assert(l3.elementAt(2) == 'z');
    assert(l3.size() == 4);
}


void concatenateTest() {
    char            characters[] = {'a', 'b', 'c', 'd'};
    CharLinkedList *l_empty      = new CharLinkedList();
    CharLinkedList *l_full       = new CharLinkedList(characters, 4);

    // self concatenate empty
    l_empty->concatenate(l_empty);
    std::cout << "here 1" << std::endl;
    assert(l_empty->toString() == "[CharLinkedList of size 0 <<>>]\n");
    delete l_empty;
    l_empty = new CharLinkedList();

    // self concatenate not empty
    l_full->concatenate(l_full);
    std::cout << "here 2" << std::endl;
    assert(l_full->toString() == "[CharLinkedList of size 8 <<abcdabcd>>]\n");
    delete l_full;
    l_full = new CharLinkedList(characters, 4);

    // concatenate empty + full
    l_empty->concatenate(l_full);
    std::cout << "here 3" << std::endl;
    assert(l_empty->toString() == "[CharLinkedList of size 4 <<abcd>>]\n");
    delete l_empty;
    l_empty = new CharLinkedList();

    // concatenate full + empty
    l_full->concatenate(l_empty);
    std::cout << "here 4" << std::endl;
    assert(l_full->toString() == "[CharLinkedList of size 4 <<abcd>>]\n");
    delete l_full;

    // concatenate two full
    l_full                    = new CharLinkedList(characters, 4);
    CharLinkedList *scnd_full = new CharLinkedList(characters, 4);
    l_full->concatenate(scnd_full);
    std::cout << "here 5" << std::endl;
    assert(l_full->toString() == "[CharLinkedList of size 8 <<abcdabcd>>]\n");

    delete l_full;
    delete l_empty;
    delete scnd_full;
}


void sortTest() {
    char           characters[] = {'d', 'c', 'a', 'b'};
    CharLinkedList list(characters, 4);

    list.sort();
    std::cout << list.toString();
    assert(list.toString() == "[CharLinkedList of size 4 <<abcd>>]\n");
}


void sliceTest() {
    char           characters[] = {'d', 'c', 'a', 'b'};
    CharLinkedList list(characters, 4);

    CharLinkedList *l = list.slice(0, 1);
    std::cout << l->toString();
    assert(l->toString() == "[CharLinkedList of size 1 <<d>>]\n");
    delete l;

    l = list.slice(0, 2);
    assert(l->toString() == "[CharLinkedList of size 2 <<dc>>]\n");
    delete l;
}

#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H

#include <string>


// handy way to deal with inclusive/exclusive range checks
enum RangeType { inclusive = true, exclusive = false };

class CharLinkedList {
public:
    CharLinkedList();
    CharLinkedList(char c);
    CharLinkedList(char arr[], int sz);
    CharLinkedList(const CharLinkedList &other);
    CharLinkedList &operator=(const CharLinkedList &other);
    ~CharLinkedList();

    char first() const;
    char last() const;

    int  size() const;
    bool isEmpty() const;
    void clear();
    char elementAt(int index);

    void pushAtFront(char c);
    void pushAtBack(char c);
    void insertAt(char c, int index);
    void insertInOrder(char c);

    void popFromFront();
    void popFromBack();
    void removeAt(int index);
    void replaceAt(char c, int index);
    void concatenate(CharLinkedList *other);

    void            sort();
    CharLinkedList *slice(int left, int right);

    std::string toString() const;
    std::string toReverseString() const;

private:
    struct Node {
        Node(char c) {
            data = c;
            next = nullptr;
            prev = nullptr;
        }
        Node(char c, Node *nxt, Node *prv) {
            data = c;
            next = nxt;
            if (next) { next->prev = this; }
            prev = prv;
        }
        Node *next;
        Node *prev;
        char  data;
    };

    Node *front;
    Node *back;
    int   numels;

    void recursive_destroy(Node *curr);
    void add_nodes_to_this(Node *curr, Node *stop);
    void insertInOrderHelper(Node *curr, char c);

    Node *getNth(int d);
    Node *getNth(int d) const;

    Node *getNth(Node *n, int d);
    Node *getNth(Node *n, int d) const;

    Node *smallestChar(Node *curr, Node *curr_smallest);

    void initialize();

    void checkEmptyWithThrow(std::string) const;
    void checkBoundsWithThrow(int index, int stop, RangeType r) const;
};

#endif
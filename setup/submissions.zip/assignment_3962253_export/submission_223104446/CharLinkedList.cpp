/*
 * CharLinkedList.cpp
 * Matt Russell
 * 01-19-2022
 *
 * CharLinkedList implementation for HW2.
 *
 * Modified by Chami Lamelas, 06-19-2023
 *      Made to follow style guide
 */

#include "CharLinkedList.h"

#include <exception>
#include <iostream>
#include <sstream>
#include <string>

/*
 *    name: initialize
 * purpose: initialize the member variables of this
 *   takes: none
 * returns: none
 */
void CharLinkedList::initialize() {
    front = nullptr;
    back = nullptr;
    numels = 0;
}

/*
 *    name: default constructor
 * purpose: initialize this object
 *   takes: none
 * returns: none
 */
CharLinkedList::CharLinkedList() { initialize(); };

/*
 *    name: single char constructor
 * purpose: fill 'this' with the provided character
 *   takes: character to initialize the list with
 * returns: none
 */
CharLinkedList::CharLinkedList(char c) {
    initialize();
    pushAtFront(c);
}

/*
 *    name: array-based constructor
 * purpose: fill 'this' with the data in the provided array
 *   takes: array of chars, and size of the array
 * returns: none
 */
CharLinkedList::CharLinkedList(char arr[], int sz) {
    initialize();
    for (int i = 0; i < sz; i++) {
        this->pushAtBack(arr[i]);
    }
}

/*
 *    name: copy constructor
 * purpose: fill 'this' with the data in other
 *   takes: const reference to the 'other' CLL
 * returns: none
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other) {
    initialize();
    add_nodes_to_this(other.front, nullptr);
}

/*
 *    name: assignment operator overload
 * purpose: fill 'this' with the data in other
 *   takes: const reference to the 'other' CLL
 * returns: reference to the data in this
 */
CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other) {
    if (this != &other) {
        this->clear();
        add_nodes_to_this(other.front, nullptr);
    }
    return *this;
}

/*
 *    name: destructor
 * purpose: clear the data in this
 *   takes: none
 * returns: none
 */
CharLinkedList::~CharLinkedList() { recursive_destroy(front); }

/*
 *    name: first
 * purpose: report the char at the front of the list
 *   takes: none
 * returns: the character at the front of the list
 * precond: assumes there are elements in the list; if not, throws an exception
 */
char CharLinkedList::first() const {
    checkEmptyWithThrow("cannot get first of empty LinkedList");
    return front->data;
}

/*
 *    name: last
 * purpose: report the char at the end of the list
 *   takes: none
 * returns: the character at the end of the list
 * precond: assumes there are elements in the list; if not, throws an exception
 */
char CharLinkedList::last() const {
    checkEmptyWithThrow("cannot get last of empty LinkedList");
    return back->data;
}

/*
 *    name: size
 * purpose: report the number of elements in the list
 *   takes: none
 * returns: the number of elements in the list
 */
int CharLinkedList::size() const { return numels; }

/*
 *    name: isEmpty
 * purpose: report whether the list is empty or not
 *   takes: none
 * returns: true if the list is empty; false otherwise
 */
bool CharLinkedList::isEmpty() const { return numels == 0; }

/*
 *    name: clear
 * purpose: destroy the list
 *   takes: none
 * returns: none
 */
void CharLinkedList::clear() { 
    recursive_destroy(front); 
}

/*
 *    name: elementAt
 * purpose: returns the char at the given index
 *   takes: index to return the char at
 * returns: none
 */
char CharLinkedList::elementAt(int index) {
    checkBoundsWithThrow(index, size(), RangeType::exclusive);
    return getNth(index)->data;
}

/*
 *    name: pushAtFront
 * purpose: adds an item to the front of the list
 *   takes: char to add
 * returns: none
 */
void CharLinkedList::pushAtFront(char c) {
    Node *toAdd = new Node(c);
    if (not front) {
        front = toAdd;
        back = toAdd;
    } else {
        toAdd->next = front;
        front->prev = toAdd;
        front = toAdd;
        if (numels == 1) {
            back = front->next;
        }
    }
    numels += 1;
}

/*
 *    name: pushAtBack
 * purpose: adds an item to the back of the list
 *   takes: char to add
 * returns: none
 */
void CharLinkedList::pushAtBack(char c) {
    if (not front) {
        pushAtFront(c);
    } else {
        back->next = new Node(c, nullptr, back);
        back = back->next;
        numels++;
    }
}

/*
 *    name: insertAt
 * purpose: insert given character at given index
 *   takes: character to insert, index at which to insert
 * returns: none
 *   notes: this moves the current character at index i down by one
 */
void CharLinkedList::insertAt(char c, int index) {
    checkBoundsWithThrow(index, size(), RangeType::inclusive);

    if (index == 0) {
        pushAtFront(c);
    } else if (index == numels) {
        pushAtBack(c);
    } else {
        Node *curr = getNth(index - 1);
        Node *toAdd = new Node(c, curr->next, curr);
        curr->next = toAdd;
        numels++;
    }
}

/*
 *    name: insertInOrder
 * purpose: insert given character in it's sorted position
 *   takes: character
 * returns: none
 * precond: assumes list is already sorted
 */
void CharLinkedList::insertInOrder(char c) {
    if (not front or c < front->data) {
        pushAtFront(c);
    } else {
        insertInOrderHelper(front, c);
    }
}

/*
 *    name: popFromFront
 * purpose: removes first item in list
 *   takes: none
 * returns: none
 */
void CharLinkedList::popFromFront() {
    checkEmptyWithThrow("cannot pop from empty LinkedList");
    Node *todel = front;
    front = front->next;
    if (front)
        front->prev = nullptr;
    else
        back = nullptr;
    delete todel;
    numels--;
}

/*
 *    name: popFromBack
 * purpose: removes last item in list
 *   takes: none
 * returns: none
 */
void CharLinkedList::popFromBack() {
    checkEmptyWithThrow("cannot pop from empty LinkedList");
    if (numels == 1) {
        popFromFront();
    } else {
        Node *todel = back;
        back = todel->prev;
        back->next = nullptr;  // there will always be a prev
        delete todel;
        numels--;
    }
}

/*
 *    name: removeAt
 * purpose: removes the node at given index
 *   takes: index at which to remove
 * returns: none
 */
void CharLinkedList::removeAt(int index) {
    checkBoundsWithThrow(index, size(), RangeType::exclusive);
    if (index == 0)
        popFromFront();
    else if (index == numels - 1)
        popFromBack();
    else {  // not front, not back.
        Node *curr = getNth(index - 1);
        Node *todel = curr->next;
        curr->next = curr->next->next;
        curr->next->prev = curr;
        delete todel;
        numels--;
    }
}

/*
 *    name: replaceAt
 * purpose: replaces node at given index with provided character
 *   takes: character to replace, index at which to replace
 * returns: none
 */
void CharLinkedList::replaceAt(char c, int index) {
    checkBoundsWithThrow(index, size(), RangeType::exclusive);
    Node *toReplace = getNth(index);
    toReplace->data = c;
}

/*
 *    name: concatenate
 * purpose: adds data from 'other' to the back of this
 *   takes: pointer to CLL
 * returns: none
 */
void CharLinkedList::concatenate(CharLinkedList *other) {
    if (other->isEmpty()) return;
    Node *stop = nullptr;
    if (other == this) {
        stop = back;
    }
    add_nodes_to_this(other->front, stop);
    if (stop) this->pushAtBack(stop->data);
}

/*
 *    name: sort
 * purpose: sorts the current list in-place
 *   takes: none
 * returns: none
 */
void CharLinkedList::sort() {
    // don't really feel like coding out mergesort :)
    Node *curr = front;
    while (curr) {
        Node *smallest = smallestChar(curr->next, curr);
        if (curr->data != smallest->data) {
            char c = curr->data;
            curr->data = smallest->data;
            smallest->data = c;
        }
        curr = curr->next;
    }
}

/*
 *    name: slice
 * purpose: return a new CLL* object with data sliced from this
 *   takes: start and stop indices
 * returns: CLL* that points to heap-allocated CLL with deep copy of sliced data
 */
CharLinkedList *CharLinkedList::slice(int left, int right) {
    checkBoundsWithThrow(left, size(), RangeType::exclusive);
    checkBoundsWithThrow(right, size(), RangeType::inclusive);

    CharLinkedList *cll = new CharLinkedList();
    Node *curr = getNth(left);
    for (int i = 0; i < right - left; i++) {
        cll->pushAtBack(curr->data);
        curr = curr->next;
    }
    return cll;
}

/*
 *    name: toString()
 * purpose: represent the data in this as a string
 *   takes: none
 * returns: string formatted per spec
 */
std::string CharLinkedList::toString() const {
    std::stringstream ss;
    ss << "[CharLinkedList of size " << numels << " <<";
    Node *curr = front;
    while (curr) {
        ss << curr->data;
        curr = curr->next;
    }
    ss << ">>]";
    return ss.str();
}

/*
 *    name: toReverseString()
 * purpose: represent the data in reverse in this as a string
 *   takes: none
 * returns: string formatted per spec
 */
std::string CharLinkedList::toReverseString() const {
    std::stringstream ss;
    ss << "[CharLinkedList of size " << numels << " <<";
    Node *curr = back;
    while (curr) {
        ss << curr->data;
        curr = curr->prev;
    }
    ss << ">>]";
    return ss.str();
}

/*
 *    name: recursive destroy
 * purpose: recursively remove all heap-allocated data associated with this
 *   takes: current Node pointer
 * returns: none
 */
void CharLinkedList::recursive_destroy(Node *curr) {
    if (curr == nullptr) {
        initialize();  // reset vars for good measure
        return;
    }
    Node *nxt = curr->next;
    delete curr;
    recursive_destroy(nxt);
}

/*
 *    name: add_nodes_to_this
 * purpose: add a chain of nodes' data to this LL
 *   takes: node pointers to start and stop at
 * returns: none
 */
void CharLinkedList::add_nodes_to_this(Node *curr, Node *stop) {
    while (curr != stop) {
        this->pushAtBack(curr->data);
        curr = curr->next;
    }
}

/*
 *    name: insertInOrderHelper
 * purpose: add the given char to it's proper place in the sorted list
 *   takes: current node and char to insert
 * returns: none
 *    note: iterates through the list recursively. students don't need to do
 *          this for s2022; maybe an idea for future semesters.
 */
void CharLinkedList::insertInOrderHelper(Node *curr, char c) {
    if (not curr->next or curr->next->data >= c) {
        Node *toAdd = new Node(c, curr->next, curr);
        curr->next = toAdd;
        if (toAdd->next == nullptr) {
            back = toAdd;
        }
        numels++;
    } else {
        insertInOrderHelper(curr->next, c);
    }
}

/*
 *    name: getNth (wrapper)
 * purpose: wrapper around the getNth which takes a starting location
 *   takes: an integer representing the distance to the destination node
 * returns: pointer to the Nth node in the list.
 */
CharLinkedList::Node *CharLinkedList::getNth(int d) { return getNth(front, d); }

/*
 *    name: getNth (const wrapper)
 * purpose: wrapper around the const getNth which takes a starting location
 *   takes: an integer representing the distance to the destination node
 * returns: pointer to the Nth node in the list.
 */
CharLinkedList::Node *CharLinkedList::getNth(int d) const {
    return getNth(front, d);
}

/*
 *    name: getNth
 * purpose: recursively get the Nth element of the list
 *   takes: pointer of the current node, and integer representing the distance
 *          to the destination node
 * returns: pointer to the Nth node in the list.
 */
CharLinkedList::Node *CharLinkedList::getNth(Node *curr, int d) {
    if (d == 0) return curr;
    return getNth(curr->next, d - 1);
}

/*
 *    name: getNth (const)
 * purpose: recursively get the Nth element of the list
 *   takes: pointer of the current node, and integer representing the distance
 *          to the destination node
 * returns: pointer to the Nth node in the list.
 *   notes: this is the same as the other getNth, but is const - thus, it can
 *           be called by const member fns
 */
CharLinkedList::Node *CharLinkedList::getNth(Node *curr, int d) const {
    if (d == 0) return curr;
    return getNth(curr->next, d - 1);
}

/*
 *    name: smallestChar
 * purpose: recursively determine the smallest char among the chain of nodes
 *          pointed to from the first call to curr and beyond
 *   takes: pointer to the current node, and to the curr_smallest node
 * returns: pointer to the smallest node in the list.
 */
CharLinkedList::Node *CharLinkedList::smallestChar(Node *curr,
                                                   Node *curr_smallest) {
    if (not curr) {
        return curr_smallest;
    }
    if (curr->data < curr_smallest->data) {
        curr_smallest = curr;
    }
    return smallestChar(curr->next, curr_smallest);
}

/*
 *    name: checkBoundsWithThrow
 * purpose: check that the provided index is in bounds
 *   takes: index to check, index to stop, and whether the bound is inclusive or
 *          not
 * returns: none
 * notes: throws an std::range_error if out of bounds
 */
void CharLinkedList::checkBoundsWithThrow(int index, int stop,
                                          RangeType inc) const {
    if (index < 0 or index > stop or
        (index == stop and inc == RangeType::exclusive)) {
        std::string throwstr = "index (" + std::to_string(index) +
                               ") not in range [0.." + std::to_string(stop);
        if (inc == RangeType::inclusive) {
            throwstr += "]";
        } else {
            throwstr += ")";
        }
        throw std::range_error(throwstr);
    }
}

/*
 *    name: checkEmptyWithThrow
 * purpose: throw an std::range_error with the provided message if list is empty
 *   takes: message to throw
 * returns: none
 */
void CharLinkedList::checkEmptyWithThrow(std::string message) const {
    if (isEmpty()) {
        throw std::runtime_error(message);
    }
}

/*
 *  CharLinkedList.cpp
 *  Soraya Basrai
 *  01/31/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  File Purpose:
 *  This file implements the CharLinkedList class, which represents a doubly 
 *  linked list of characters. The class provides essential functionalities such
 *  as insertion, deletion, and manipulation of characters within the list. 
 *  Users interested in the detailed implementation of the CharLinkedList class 
 *  can refer to this file for a deeper understanding of how the class works 
 *  under the hood.
 *
 */

#include "CharLinkedList.h"
#include <iostream>
#include <sstream>
#include <stdexcept>
using namespace std;

/*
 * name:      CharLinkedList default constructor    
 * purpose:   initialize an empty array list
 * arguments: none
 * returns:   none
 * effects:   initializes front to nullptr and count to 0
 */
CharLinkedList::CharLinkedList() {
    front = nullptr;
    back = nullptr;
    count = 0;
}

/*
 * name:      CharLinkedList second constructor    
 * purpose:   takes in a single character and creates a 1-element list
 * arguments: char c
 * returns:   none
 * effects:   initializes front as a newNode and count to 1
 */
CharLinkedList::CharLinkedList(char c) {
    front = newNode(c);
    back = front;
    count = 1;
}

/*
 * name:      CharLinkedList third constructor    
 * purpose:   takes in an array of characters  the integer length of that array
 *            of characters as parameters. It will create a list containing the
 *            characters in the array.
 * arguments: arr arr[] and int size
 * returns:   none
 * effects:   turns a char array list into a char linked list 
 */
CharLinkedList::CharLinkedList(char arr[], int size) {
    front = nullptr;
    back = nullptr;
    count = 0;
    for (int i = 0; i < size; i++) {
        pushAtBack(arr[i]);
    }    
}

/*
 * name:      copy constructor   
 * purpose:   copy constructor
 * arguments: the given instance of a list
 * returns:   none
 * effects:   makes a deep copy of a given instance
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other) {
    if (other.front == nullptr) {
        return;
    }
    count = other.count;
    front = newNode(other.elementAt(0));

    Node *curr = front;
    for (int i = 1; i < count; i++) {
        curr->next = newNode(other.elementAt(i));
        curr = curr->next;
    }
}

/*
 * name:      newNode   
 * purpose:   takes in a single character and turns it into a new node with the 
 *            location of the previous and next element
 * arguments: char newData
 * returns:   the new node
 * effects:   initializes newNode
 */
CharLinkedList::Node *CharLinkedList::newNode(char newData) {
    Node *new_node = new Node;
    new_node->data = newData;
    new_node->next = nullptr;
    new_node->prev = nullptr;
    return new_node;
}

/*
 * name:      destructorHelper
 * purpose:   helper function that deletes CharLinkedList in the destructor
 * arguments: Node *curr
 * returns:   none
 * effects:   deletes the list in CharLinkedList
 */
void CharLinkedList::destructorHelper(Node *curr) {
    if (curr != nullptr) {
        if (curr->next != nullptr) {
            destructorHelper(curr->next);
        }
        delete curr;
    }
}

/*
 * name:      ~CharLinkedList   
 * purpose:   deletes and recycles the heap-allocated data in the current list
 * arguments: none
 * returns:   none
 * effects:   frees memory allocated by CharLinkedList instances
 */
CharLinkedList::~CharLinkedList() {
    destructorHelper(front);
}

/*
 * name:      &operator=
 * purpose:   assignment operator  
 * arguments: instance of a list to be copied
 * returns:   copied instance of the list parameter
 * effects:   recycles the storage associated with the instance 3 on the left 
 *            of the assignment and makes a deep copy of the instance on the 
 *            right hand side into the instance on the left hand side
 */
CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other) {
    if (this == &other) {
        return *this;
    }
    // recycles memory on the left side
    clear();
    // allocates memory on the left side
    count = other.count;

    if (count > 0) {
        front = newNode(other.elementAt(0));
        Node *curr = front;
        for (int i = 1; i < count; i++) {
            curr->next = newNode(other.elementAt(i));
            curr = curr->next;
        }
        back = curr;
    }
    return *this;
}

/*
 * name:      toString
 * purpose:   turns the array into a string and returns it
 * arguments: none
 * returns:   a string which contains the characters of CharLinkedList
 * effects:   none
 */
std::string CharLinkedList::toString() const {
    std::stringstream ss;
    if (isEmpty()) {
        return "[CharLinkedList of size 0 <<>>]";
    }

    ss << "[CharLinkedList of size " << count << " <<";

    Node *curr = front;
    while (curr != nullptr) {
        ss << curr->data;
        curr = curr->next;
    }

    ss << ">>]";
    return ss.str();
}

/*
 * name:      toReverseString
 * purpose:   turns the array into a reversed string and returns it
 * arguments: none
 * returns:   a reversed string which contains the characters of CharLinkedList
 * effects:   none
 */
std::string CharLinkedList::toReverseString() const {
    std::stringstream ss;
    if (isEmpty()) {
        return "[CharLinkedList of size 0 <<>>]";
    }

    ss << "[CharLinkedList of size " << count << " <<";

    Node *curr = back;
    
    while (curr != nullptr) {
        ss << curr->data;
        curr = curr->prev;
    }

    ss << ">>]";
    return ss.str();
}

/*
 * name:      isEmpty   
 * purpose:   shows if CharLinkedList is empty
 * arguments: none
 * returns:   a boolean value
 * effects:   none
 */
bool CharLinkedList::isEmpty() const {
    return (count == 0);
}

/*
 * name:      clear   
 * purpose:   makes CharLinkedList into an empty list
 * arguments: none
 * returns:   void
 * effects:   clears CharLinkedList
 */
void CharLinkedList::clear() {
    if (isEmpty()) {
        return;
    }
    else {
        destructorHelper(front);
        front = nullptr;
        back = nullptr;
        count = 0;
    }
}

/*
 * name:      size   
 * purpose:   shows a number value of the amount of items in the list
 * arguments: none
 * returns:   an int value (count)
 * effects:   none
 */
int CharLinkedList::size() const {
    return count;
}

/*
 * name:      first   
 * purpose:   shows the first element of CharLinkedList
 * arguments: none
 * returns:   first element (char) in the list
 * effects:   none
 */
char CharLinkedList::first() const {
    if (isEmpty()) {
        throw runtime_error("cannot get first of empty LinkedList");
    }
    return front->data;
}

/*
 * name:      last   
 * purpose:   finds the last element of CharLinkedList
 * arguments: none
 * returns:   pointer to the last element (char) in the list 
 * effects:   none
 */
char CharLinkedList::last() const {
    if (isEmpty()) {
        throw runtime_error("cannot get last of empty LinkedList");
    }
    else if (count == 1) {
        return front->data;
    }

    Node *back = front;
    while (back->next != nullptr) {
        back = back->next;
    }

    return back->data;
}

/*
 * name:      elementAt  
 * purpose:   takes an index and returns the element 
 * arguments: int index
 * returns:   element (char) in the list 
 * effects:   none
 */
char CharLinkedList::elementAt(int index) const {
    if (index < 0 or index >= count) {
        throw std::range_error("index (" + std::to_string(index) +
        ") not in range [0.." + std::to_string(count) + ")");
    }
    return elementAtHelper(front, index);
}

/*
 * name:      elementAtHelper
 * purpose:   private recursive helper function for elementAt
 * arguments: Node* current - the current node being processed
 *            int index - the target index to retrieve the element
 * returns:   element (char) in the list at the given index
 * effects:   none
 */
char CharLinkedList::elementAtHelper(Node* curr, int index) const {   
    if (index == 0) {
        return curr->data;
    }
    if (curr->next == nullptr) {
        throw std::range_error("index (" + std::to_string(index) +
        ") not in range [0.." + std::to_string(count) + ")");
    }
    return elementAtHelper(curr->next, index - 1);
}

/*
 * name:      pushAtBack
 * purpose:   inserts the given new element after the end of the existing 
 *            elements of the list
 * arguments: char c
 * returns:   void
 * effects:   replaces the last element of CharLinkedList
 */
void CharLinkedList::pushAtBack(char c) {
    Node *new_back = newNode(c);

    if (isEmpty()) {
        front = new_back;
        back = new_back;
        count++;
        return;
    }
    else {
        new_back->prev = back;
        back->next = new_back;
        back = new_back;
        count++;
        return;
    }
}

/*
 * name:      pushAtFront    
 * purpose:   Adds a new element to the end of the array
 * arguments: char for the new element 'c'
 * returns:   void
 * effects:   changes front in CharLinkedList to the new element
 */
void CharLinkedList::pushAtFront(char c) {
    Node *new_front = newNode(c);

    if (isEmpty()) {
        front = new_front;
        back = new_front;
    }
    else {
        new_front->next = front;
        front->prev = new_front;
        front = new_front;
    }

    count++;
}

/*
 * name:      insertAt   
 * purpose:   Inserts the new element at the given index
 * arguments: character c and int index 
 * returns:   void
 * effects:   inserts a new element into CharLinkedList
 */
void CharLinkedList::insertAt(char c, int index) {
    if (index < 0 or index > count) {
        string error_text = "index (" + to_string(index) + ") not in range [0.."
        + to_string(count) + "]";
        throw range_error(error_text);
    }

    if (isEmpty() or index == 0) {
        pushAtFront(c);
        return;
    }

    if (index == count) {
        pushAtBack(c);
        return;
    }

    else {
        Node *new_element = newNode(c);
        Node *curr = front;

        for (int i = 0; i < index - 1; i++) {
            curr = curr->next;
        }

        new_element->prev = curr;
        new_element->next = curr->next;
        curr->next = new_element;

        if (new_element->next != nullptr) {
            curr->prev = new_element;
        }

        count++;
    }
}

/*
 * name:      insertInOrder   
 * purpose:   Inserts the new element at the given index into CharArrayList 
 *            in ASCII order
 * arguments: character c  
 * returns:   nothing
 * effects:   inserts a new element into CharLinkedList
 */
void CharLinkedList::insertInOrder(char c) {
    if (isEmpty()) {
        pushAtFront(c);
    }
    else {
        bool last = true;
        for (int i = 0; i < count; i++) {
            if (c <= elementAt(i)) {
                insertAt(c, i);
                last = false;
                return;
            }
        }
        // edge case for if c is the last element
        if (last) {
            pushAtBack(c);
        }
    }
}

/*
 * name:      removeAt
 * purpose:   removes an element at a specified index
 * arguments: int index
 * returns:   void 
 * effects:   returns an specified element from CharLinkedList and throws an
 *            error for an out of range index 
 */

void CharLinkedList::removeAt(int index) { 
    if (index >= count or index < 0) {
        string error_text = "index (" + to_string(index) + ") not in range [0.."
        + to_string(count) + ")";
        throw range_error(error_text);
    }
    
    else if (index == 0 or count == 1) {
        // for elements that are in the front of the list
        popFromFront();
    }

    else if (count == index + 1) {
        // for elements that are last in the list
        popFromBack();
    }
    else {
        removeAtHelper(front, index);
    }
}


/*
 * name:      removeAtHelper
 * purpose:   recursively removes an element at a specific index
 * arguments: int index
 * returns:   void
 * effects:   helps replaceAtHelper with recursion 
 */
void CharLinkedList::removeAtHelper(Node *curr, int index) {
    if (index == 0) {
        Node *curr_prev = curr->prev;
        Node *curr_next = curr->next;
        
        if (curr_prev != nullptr) {
            curr_prev->next = curr_next;
        } else {
            // If curr_prev is nullptr
            front = curr_next;
        }

        if (curr_next != nullptr) {
            curr_next->prev = curr_prev;
        } else {
            // If curr_next is nullptr
            back = curr_prev;
        }

        delete curr;
        count--;
        return;
    }
    if (curr->next == nullptr) {
        string error_text = "index (" + to_string(index) + ") not in range [0.."
        + to_string(count) + ")";
        throw range_error(error_text);
    }
    return removeAtHelper(curr->next, index - 1);
}

/*
 * name:      replaceAt
 * purpose:   replaces an element with a new element at a specific index
 * arguments: char c and int index
 * returns:   void
 * effects:   replaces an element in CharLinkedlist with a new element and 
 *            throws an error when the index is our of range
 */
void CharLinkedList::replaceAt(char c, int index) { 
    if (index >= count or index < 0) {
        string error_text = "index (" + to_string(index) + ") not in range [0.."
        + to_string(count) + ")"; 
        throw range_error(error_text);
    }
    replaceAtHelper(front, c, index);
}

/*
 * name:      replaceAtHelper
 * purpose:   recursively replaces an element with a new element at a specific 
 *            index
 * arguments: Node* curr, char c, and int index
 * returns:   void
 * effects:   helps replaceAtHelper with recursion 
 */
void CharLinkedList::replaceAtHelper(Node *curr, char c, int index) const {
    if (index == 0) {
        curr->data = c;
        return;
    }

    if (curr->next != nullptr) {
        replaceAtHelper(curr->next, c, index - 1);
    }
}

/*
 * name:      popFromFront 
 * purpose:   removes the first element of the array
 * arguments: none
 * returns:   void type
 * effects:   removes the first element of CharLinkedList and throws an error
 *            for an empty list
 */
void CharLinkedList::popFromFront() {
    if (isEmpty()) {
        throw runtime_error("cannot pop from empty LinkedList");
    }
    else if (count == 1) {
        delete front;
        front = back = nullptr;
    } else {
        Node *new_front = front->next;
        new_front->prev = nullptr;
        delete front;
        front = new_front;
    }
    count--;
    return;
}

/*
 * name:      popFromBack
 * purpose:   removes the last element of an array
 * arguments: none
 * returns:   void
 * effects:   removes the last element of CharLinkedList and runs an error for
 *            an empty list
 */
void CharLinkedList::popFromBack() {
    if (isEmpty()) {
        throw runtime_error("cannot pop from empty LinkedList");
    } 
    if (count == 1) {
        delete front;
        front = back = nullptr;
    } else {
        Node *new_back = back->prev;
        new_back->next = nullptr;
        delete back;
        back = new_back;
    }
    count--;
}

/*
 * name:      concatenate
 * purpose:   Concatenates the linked list pointed to by the parameter value
 *            to the end of the linked list the function was called from.
 * arguments: CharLinkedList* - pointer to a second CharLinkedList
 * returns:   void
 * effects:   Modifies the linked list calling the function by adding a copy 
 *            of the array list pointed to by other to the end.
 */
void CharLinkedList::concatenate(CharLinkedList *other) {
    // size
    int temp;

    // concatenating itself
    if (this == other) {
        temp = count;
    }
    else {
        temp = other->count;
    }

    if (other->isEmpty()) {
        return;
    }
    else {
        for (int i = 0; i < temp; i++) {
            pushAtBack(other->elementAt(i));
        }
    }
}
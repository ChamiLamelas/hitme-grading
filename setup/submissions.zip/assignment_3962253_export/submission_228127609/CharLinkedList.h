/*
 *  CharLinkedList.h
 *  Soraya Basrai
 *  01/31/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  File Purpose:
 *  This header file defines the CharLinkedList class, a doubly linked list of 
 *  characters. Instances of this class represent an ordered list of characters,
 *  providing various functionalities for manipulation, traversal, and 
 *  information retrieval. Clients interested in utilizing the CharLinkedList 
 *  class can refer to this header file to understand the high-level interface 
 *  and capabilities of the class within the context of the overall program.
 *  Clients cannot access the private functions and definitions to create a 
 *  user-friendly interface.
 *  
 *
 */

#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H

#include <string>
using namespace std;

class CharLinkedList {
    public:
    CharLinkedList();
    CharLinkedList(char c);
    CharLinkedList(char arr[], int size);
    CharLinkedList(const CharLinkedList &other);
    ~CharLinkedList();
    CharLinkedList &operator=(const CharLinkedList &other);

    bool isEmpty() const;
    void clear();
    int size() const;
    char first() const;
    char last() const;
    char elementAt(int index) const;
    std::string toString() const;
    std::string toReverseString() const;
    void pushAtBack(char c);
    void pushAtFront(char c);
    void insertAt(char c, int index);
    void insertInOrder(char c);
    void popFromBack();
    void popFromFront();
    void removeAt(int index);
    void replaceAt(char c, int index);
    void concatenate(CharLinkedList *other);

    private:
    struct Node{
        char data;
        Node *next;
        Node *prev;
    };
    int count;
    Node *front;
    Node *back;
    void destructorHelper(Node *curr);
    Node *newNode(char newData);
    char elementAtHelper(Node* curr, int index) const;
    void replaceAtHelper(Node *curr, char c, int index) const;
    void removeAtHelper(Node *curr, int index);
};

#endif

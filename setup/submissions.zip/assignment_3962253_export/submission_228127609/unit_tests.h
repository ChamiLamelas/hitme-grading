/*
 *  unit_tests.h
 *  Soraya Basrai
 *  01/31/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  File Purpose:
 *  The unit tests cover a comprehensive range of scenarios, including edge 
 *  cases, normal use cases, and potential error conditions. Each test case aims
 *  to verify the correctness of specific methods and functionalities provided 
 *  by the CharLinkedList class.
 *
 */

#include "CharLinkedList.h"
#include <cassert>

// Dummy Test
void dummyTest() {
    std::cout << "Test worked" << std::endl;
}

// Tests CharLinkedList with an empty array
void first_constructor() {
    CharLinkedList test_list;
    assert(test_list.toString() == "[CharLinkedList of size 0 <<>>]");
}

// Tests CharLinkedList with an array of 1 element
void second_constructor() {
    CharLinkedList test_list('a');
    assert(test_list.toString() == "[CharLinkedList of size 1 <<a>>]");
}

// Tests third constructor with an array of multiple elements
void third_constructor() {
    char arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g','h'};
    CharLinkedList test_list(arr, 8);
    assert(test_list.size() == 8);
    cout << test_list.toString() << endl;
    assert(test_list.toString() == "[CharLinkedList of size 8 <<abcdefgh>>]");
}

// Tests destructor with an array of one element
void destructor(){
    auto *test_list = new CharLinkedList('a');
    assert(test_list->toString() == "[CharLinkedList of size 1 <<a>>]");
    delete test_list;
}

//Tests copy constuctor with an empty array
void constructor_copy() {
    CharLinkedList first('a');
    CharLinkedList second = first;
    assert(first.first() == 'a');
    assert(second.first() == 'a');
}

//Tests operator constructor with a non-empty list on an empty list
void operator_empty_test() {
    CharLinkedList first('a');
    CharLinkedList second;
    second = first;
    assert(first.first() == 'a');
    assert(second.first() == 'a');
}

//Tests operator constructor with an empty list on a non-empty empty list
void operator_test() {
    CharLinkedList first;
    CharLinkedList second('a');
    second = first;
    assert(first.toString() == "[CharLinkedList of size 0 <<>>]");
    assert(second.toString() == "[CharLinkedList of size 0 <<>>]");
}

//Tests operator constructor on itself
void operator_itself_test() {
    CharLinkedList first('a');
    CharLinkedList second('a');
    second = first;
    assert(first.toString() == "[CharLinkedList of size 1 <<a>>]");
    assert(second.toString() == "[CharLinkedList of size 1 <<a>>]");
}

//Tests operator constructor on 2 non-empty lists
void operator_test2() {
    CharLinkedList first('a');
    CharLinkedList second('b');
    second = first;
    assert(first.toString() == "[CharLinkedList of size 1 <<a>>]");
    assert(second.toString() == "[CharLinkedList of size 1 <<a>>]");
}


// toString()

// Tests toString with an empty array
void toString_empty() {
    CharLinkedList test_list;
    assert(test_list.toString() == "[CharLinkedList of size 0 <<>>]");
}

// Tests toString with an array of multiple elements
void toString_multiple_elements() {
    char arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g','h'};
    CharLinkedList list(arr,8);
    assert(list.size() == 8);
    assert(list.toString()  == "[CharLinkedList of size 8 <<abcdefgh>>]");
}

// isEmpty()

//Tests isEmpty() with an empty array
void isEmpty_correct_test() {
    CharLinkedList test_list;
    assert(test_list.isEmpty());
    assert(test_list.toString() == "[CharLinkedList of size 0 <<>>]");
}

// Tests isEmpty() with one element
void isEmpty_incorrect_test() {
    CharLinkedList test_list('a');
    assert(not test_list.isEmpty());
    assert(test_list.toString() == "[CharLinkedList of size 1 <<a>>]");
}

// Tests isEmpty with multiple elements
void isEmpty_multiple_elements() {
    char arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g','h'};
    CharLinkedList test_list(arr,8);
    assert(not test_list.isEmpty());
    assert(test_list.size() == 8);
    assert(test_list.toString()  == "[CharLinkedList of size 8 <<abcdefgh>>]");
}

// size()

//Tests size() with an empty array
void size_empty() {
    CharLinkedList test_list;
    assert(test_list.size() == 0);
}

//Tests size() with an array of one element
void size_one_element() {
    CharLinkedList test_list('a');
    assert(test_list.size() == 1);
}

// Tests size() with an array of multiple elements
void size_multiple_elements() {
    char arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g','h'};
    CharLinkedList test_list(arr,8);
    assert(test_list.size() == 8);
    assert(test_list.toString() == "[CharLinkedList of size 8 <<abcdefgh>>]");
}

// first()

// Tests first() with an empty array to test error
void first_error() {
    CharLinkedList test_list;
    bool exception_thrown = false;
    std::string error_message = "";

    try {
        char e = test_list.first();
    }

    catch (const std::runtime_error &o) {
        exception_thrown = true;
        error_message = o.what();
    }

    assert(exception_thrown);
    assert(error_message == "cannot get first of empty LinkedList");

}

// Tests first() with an array of one element
void first_one_element() {
    CharLinkedList test_list('a');
    assert(test_list.toString() == "[CharLinkedList of size 1 <<a>>]");
    assert(test_list.first() == 'a');
}

//Tests first() with an array of multiple elements
void first_multiple_elements() {
    char arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g','h'};
    CharLinkedList test_list(arr,8);
    assert(test_list.size() == 8);
    assert(test_list.first()== 'a');
    assert(test_list.toString() == "[CharLinkedList of size 8 <<abcdefgh>>]");
}


// last()

// Tests last() with an empty array to throw error
void last_error() {
    CharLinkedList test_list;
    bool exception_thrown = false;
    std::string error_message = "";

    try {
        char e = test_list.last();
    }

    catch (const std::runtime_error &o) {
        exception_thrown = true;
        error_message = o.what();
    }

    assert(exception_thrown);
    assert(error_message == "cannot get last of empty LinkedList");

}

// Tests last() with an array of one element
void last_one_element() {
    CharLinkedList test_list('a');
    assert(test_list.toString() == "[CharLinkedList of size 1 <<a>>]");
    assert(test_list.last() == 'a');
}

// Tests last() with an array of multiple elements
void last_multiple_elements() {
    char arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g','h'};
    CharLinkedList test_list(arr,8);
    assert(test_list.size() == 8);
    assert(test_list.last()== 'h');
    assert(test_list.toString() == "[CharLinkedList of size 8 <<abcdefgh>>]");
}

//clear()

// Tests clear() with an empty array
void clear_empty() {
    CharLinkedList test_list;
    assert(test_list.size() == 0);
    test_list.clear();
    assert(test_list.size() == 0);
}

// Tests clear() with an array of one element
void clear_one_element() {
    CharLinkedList test_list('a');
    assert(test_list.toString() == "[CharLinkedList of size 1 <<a>>]");
    test_list.clear();
    assert(test_list.size() == 0);
}

// Tests clear() with an array of multiple elements
void clear_multiple_elements() {
    char arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g','h'};
    CharLinkedList test_list(arr,8);
    assert(test_list.size() == 8);
    test_list.clear();
    assert(test_list.isEmpty());
    assert(test_list.size() == 0);
    assert(test_list.toString() == "[CharLinkedList of size 0 <<>>]");
}

// toReverseString()

// Tests toReverseString() with an empty array
void toReverseString_empty() {
    CharLinkedList test_list;
    assert(test_list.toReverseString() == "[CharLinkedList of size 0 <<>>]");
}

// Tests toReverseString() with an array of 1 element
void toReverseString_one_element() {
    CharLinkedList test_list('a');
    assert(test_list.toReverseString() == "[CharLinkedList of size 1 <<a>>]");
}

// Tests toReverseString() with an array of multiple elements
void toReverseString_multiple_elements() {
    char arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g','h'};
    CharLinkedList test_list(arr,8);
    assert(test_list.size() == 8);
    assert(test_list.toReverseString()  == 
    "[CharLinkedList of size 8 <<hgfedcba>>]");
}

// elementAt()

// Tests elementAt with an empty array to throw error
void elementAt_error() {
    CharLinkedList test_list;
    bool exception_thrown = false;
    std::string error_message = "";

    try {
        char e = test_list.elementAt(0);
    }

    catch (const std::range_error &o) {
        exception_thrown = true;
        error_message = o.what();
    }

    assert(exception_thrown);
    assert(error_message == "index (0) not in range [0..0)");
}

// Testing elementAt when the index is out of range
void elementAt_index_error() {
    bool range_error_thrown = false;
    string error_text = "";
    char arr[4] = {'a', 'b', 'c', 'd'};
    CharLinkedList test_list(arr, 4);

    try {
        test_list.elementAt(9);
    }

    catch(const std::range_error&e){
        range_error_thrown = true;
        error_text = e.what();
    }

    assert(range_error_thrown);
    assert(error_text == "index (9) not in range [0..4)");
}

// Testing elementAt when the index is negative
void elementAt_negative_index() {
    bool range_error_thrown = false;
    string error_text = "";
    char arr[4] = {'a', 'b', 'c', 'd'};
    CharLinkedList test_list(arr, 4);

    try {
        test_list.elementAt(-1);
    }

    catch(const std::range_error&e){
        range_error_thrown = true;
        error_text = e.what();
    }

    assert(range_error_thrown);
    assert(error_text == "index (-1) not in range [0..4)");
}

// Testing elementAt with an array of one element 
void elementAt_one_element() {
    char arr[1] = {'a'};
    CharLinkedList test_list(arr, 1);
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.toString() == "[CharLinkedList of size 1 <<a>>]");
}

// Testing elementAt with an array of multiple elements
void elementAt_multiple_elements() {
    char arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g','h'};
    CharLinkedList test_list(arr,8);
    assert(test_list.size() == 8);
    assert(test_list.elementAt(5) == 'f');
    assert(test_list.toString() == "[CharLinkedList of size 8 <<abcdefgh>>]");
}

// pushAtBack()

// Tests pushAtBack with an empty array
void pushAtBack_empty() {
    CharLinkedList test_list;
    assert(test_list.size() == 0);
    test_list.pushAtBack('a');
    assert(test_list.size() == 1);
    assert(test_list.toString() == "[CharLinkedList of size 1 <<a>>]");
}

// Tests pushAtBack with an array of 1 element
void pushAtBack_one_element() {
    CharLinkedList test_list('a');
    test_list.pushAtBack('b');
    assert(test_list.size() == 2);
    assert(test_list.toString() == "[CharLinkedList of size 2 <<ab>>]");
}

// Tests pushAtBack with an array of multiple elements
void pushAtBack_multiple_elements() {
    char arr[7] = {'a', 'b', 'c', 'd', 'e', 'f', 'g'};
    CharLinkedList test_list(arr, 7);
    assert(test_list.size() == 7);
    test_list.pushAtBack('h');
    assert(test_list.size() == 8);
    assert(test_list.toString() == "[CharLinkedList of size 8 <<abcdefgh>>]");
}

// pushAtFront()

//Tests pushAtFront with an empty list
void pushAtFront_empty() { 
    CharLinkedList test_list;
    test_list.pushAtFront('a');
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.toString() == "[CharLinkedList of size 1 <<a>>]");
}

//Tests pushAtFront with an array of one element list
void pustAtFront_one_element() {
    char arr[1] = {'a'};
    CharLinkedList test_list(arr, 1);
    test_list.pushAtFront('b');
    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'a');
    assert(test_list.toString() == "[CharLinkedList of size 2 <<ba>>]");
}

//Tests pushAtFront with an array of a multiple element list
void pustAtFront_multiple_elements() {
    char arr[7] = {'b', 'c', 'd', 'e', 'f', 'g','h'};
    CharLinkedList test_list(arr, 7);
    assert(test_list.size() == 7);
    test_list.pushAtFront('a');
    assert(test_list.size() == 8);
    assert(test_list.elementAt(1) == 'b');
    assert(test_list.toString() == "[CharLinkedList of size 8 <<abcdefgh>>]");
}

//Tests pushAtFront with many elements **cant use without insertAt
void pushAtFront_many_elements() {
    CharLinkedList test_list;
    for (int i = 0; i < 5000; i++) {
        test_list.insertAt('a', i);
    }

    assert(test_list.size() == 5000);
    test_list.pushAtFront('b');
    assert(test_list.first() == 'b');
}

// insertAt()

// Tests correct insertion into an empty AL.
void insertAt_empty_correct() { 
    CharLinkedList test_list;
    test_list.insertAt('a', 0);
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.toString() == "[CharLinkedList of size 1 <<a>>]");

}

// Tests incorrect insertion into an empty AL.
void insertAt_empty_incorrect() {
    bool range_error_thrown = false;
    std::string error_message = "";
    CharLinkedList test_list;

    try {
    test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
    range_error_thrown = true;
    error_message = e.what();
    }

    assert(range_error_thrown);
    cout << error_message << endl;
    assert(error_message == "index (42) not in range [0..0]");
}

//Tests correct insertAt for front of 1-element list.
void insertAt_front_singleton_list() {
    CharLinkedList test_list('b');
    test_list.insertAt('a', 0);
    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
}

// Tests correct insertAt for back of 1-element list.
void insertAt_back_singleton_list() {
    CharLinkedList test_list('a');
    test_list.insertAt('b', 1);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
}

// Tests calling insertAt for a large number of elements.
void insertAt_many_elements() {
    CharLinkedList test_list;

    for (int i = 0; i < 1000; i++) {
        test_list.insertAt('a', i);
    }

    assert(test_list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
}

// Tests insertion into front of a larger list
void insertAt_front_large_list() {
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);
    test_list.insertAt('y', 0);

    assert(test_list.size() == 10);
    assert(test_list.elementAt(0) == 'y');
    assert(test_list.toString() == 
    "[CharLinkedList of size 10 <<yabczdefgh>>]");
}

// Tests insertion into the back of a larger list
void insertAt_back_large_list() {
    char test_arr[10] = { 'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 10);  
    test_list.insertAt('x', 10);

    assert(test_list.size() == 11);
    assert(test_list.elementAt(10) == 'x');
    assert(test_list.toString() == 
    "[CharLinkedList of size 11 <<yabczdefghx>>]"); 
}

// Tests insertion into the middle of a larger list
void insertAt_middle_large_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.insertAt('z', 3);
    assert(test_list.size() == 9);
    assert(test_list.elementAt(3) == 'z');
    assert(test_list.toString() == "[CharLinkedList of size 9 <<abczdefgh>>]");
}

// Tests out-of-range insertion for a non-empty list.
void insertAt_nonempty_incorrect() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);
    bool range_error_thrown = false;
    std::string error_message = "";

    try {
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8]");
}

// removeAt()

// Tests if removeAt will throw an error for an empty array
void removeAt_index_error() {
    bool range_error_thrown = false;
    string error_text = "";
    CharLinkedList test_list;

    try {
        test_list.removeAt(0);
    }

    catch(const std::range_error&e){
        range_error_thrown = true;
        error_text = e.what();
    }

    assert(range_error_thrown);
    assert(error_text == "index (0) not in range [0..0)");
}

//Tests if removeAt will throw an error for index out of range
void removeAt_empty_error() {
    bool range_error_thrown = false;
    string error_text = "";
    char arr[4] = {'a', 'b', 'c', 'd'};
    CharLinkedList test_list(arr, 4);

    try {
        test_list.removeAt(5);
    }

    catch(const std::range_error&e){
        range_error_thrown = true;
        error_text = e.what();
    }

    assert(range_error_thrown);
    assert(error_text == "index (5) not in range [0..4)");
}

//Tests if removeAt will throw an error for index thats equal to the size
void removeAt_equal_index_error() {
    bool range_error_thrown = false;
    string error_text = "";
    char arr[4] = {'a'};
    CharLinkedList test_list(arr, 1);

    try {
        test_list.removeAt(1);
    }

    catch(const std::range_error&e){
        range_error_thrown = true;
        error_text = e.what();
    }

    assert(range_error_thrown);
    assert(error_text == "index (1) not in range [0..1)");
}

//Tests if removeAt will throw an error for a negative index 
void removeAt_index_negative_error() {
    bool range_error_thrown = false;
    string error_text = "";
    char arr[4] = {'a', 'b', 'c', 'd'};
    CharLinkedList test_list(arr, 4);

    try {
        test_list.removeAt(-1);
    }

    catch(const std::range_error&e){
        range_error_thrown = true;
        error_text = e.what();
    }

    assert(range_error_thrown);
    assert(error_text == "index (-1) not in range [0..4)");
}

// Tests removeAt with an array of 1 element
void removeAt_one_element() {
    CharLinkedList test_list('a');
    assert(test_list.size() == 1);
    test_list.removeAt(0);
    assert(test_list.size() == 0);
    assert(test_list.toString() == "[CharLinkedList of size 0 <<>>]");
}

// Tests removeAt with an array of multiple elements
void removeAt_multiple_elements() {
    char arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g','h'};
    CharLinkedList test_list(arr,8);
    assert(test_list.size() == 8);
    test_list.removeAt(5);
    assert(test_list.size() == 7);
    assert(test_list.elementAt(5) == 'g');
    assert(test_list.toString() == "[CharLinkedList of size 7 <<abcdegh>>]");
}

// Tests removeAt with an element at the front
void removeAt_front() {
    char arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g','h'};
    CharLinkedList test_list(arr, 8);
    assert(test_list.size() == 8);
    test_list.removeAt(0);
    assert(test_list.size() == 7);
    assert(test_list.toString() == "[CharLinkedList of size 7 <<bcdefgh>>]");
}

//Tests removeAt with an element at the last of the list
void removeAt_last() {
    char arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g','h'};
    CharLinkedList test_list(arr, 8);
    assert(test_list.size() == 8);
    test_list.removeAt(7);
    assert(test_list.size() == 7);
    assert(test_list.toString() == "[CharLinkedList of size 7 <<abcdefg>>]");
}

// replaceAt()

//Tests if replaceAt will throw an error for an empty array
void replaceAt_empty_error() {
    bool range_error_thrown = false;
    string error_text = "";
    CharLinkedList test_list;

    try {
        test_list.replaceAt('a', 0);
    }

    catch(const std::range_error&e){
        range_error_thrown = true;
        error_text = e.what();
    }

    assert(range_error_thrown);
    assert(error_text == "index (0) not in range [0..0)");
}

//Tests if replaceAt will throw an error for an index out of range
void replaceAt_index_error() {
    bool range_error_thrown = false;
    string error_text = "";
    char arr[4] = {'a', 'b', 'c', 'd'};
    CharLinkedList test_list(arr, 4);

    try {
        test_list.replaceAt('b', 5);
    }

    catch(const std::range_error&e){
        range_error_thrown = true;
        error_text = e.what();
    }

    assert(range_error_thrown);
    assert(error_text == "index (5) not in range [0..4)");
}

//Tests if replaceAt will throw an error for a negative index 
void replaceAt_index_negative_error() {
    bool range_error_thrown = false;
    string error_text = "";
    char arr[4] = {'a', 'b', 'c', 'd'};
    CharLinkedList test_list(arr, 4);

    try {
        test_list.replaceAt('b', -1);
    }

    catch(const std::range_error&e){
        range_error_thrown = true;
        error_text = e.what();
    }

    assert(range_error_thrown);
    assert(error_text == "index (-1) not in range [0..4)");
}

//Tests replaceAt with an array of 1 element
void replaceAt_one_element() {
    char arr[1] = {'b'};
    CharLinkedList test_list(arr, 1);
    assert(test_list.size() == 1);
    test_list.replaceAt('a', 0);
    assert(test_list.toString() == "[CharLinkedList of size 1 <<a>>]");
}

//Tests replaceAt with an array of multiple elements
void replaceAt_multiple_elements() {
    char arr[8] = {'a', 'b', 'c', 'd', 'z', 'f', 'g','h'};
    CharLinkedList test_list(arr,8);
    assert(test_list.size() == 8);
    test_list.replaceAt('e', 4);
    assert(test_list.size() == 8);
    assert(test_list.toString() == "[CharLinkedList of size 8 <<abcdefgh>>]");
}

// popFromBack()

//Tests the runtime error for popFromBack with an empty array
void popFromBack_error() {
    CharLinkedList test_list;
    bool exception_thrown = false;
    std::string error_message = "";

    try {
        test_list.popFromBack();
    } 
    
    catch (const std::runtime_error &o) {
        exception_thrown = true;
        error_message = o.what();
    }

    assert(exception_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

//Tests popFromBack with an array of 1 element
void popFromBack_one_element() {
    CharLinkedList test_list('a');
    assert(test_list.size() == 1);
    test_list.popFromBack();
    assert(test_list.toString() == "[CharLinkedList of size 0 <<>>]");
}

//Tests popFromBack with an array of multiple elements
void popFromBack_multiple_elements() {
    char arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g','h'};
    CharLinkedList test_list(arr,8);
    assert(test_list.size() == 8);
    test_list.popFromBack();
    assert(test_list.size() == 7);
    assert(test_list.toString() == "[CharLinkedList of size 7 <<abcdefg>>]");
}

// popFromFront()

//Tests popFromFront runtime error from an empty array 
void popFromFront_error() {
    CharLinkedList test_list;
    bool exception_thrown = false;
    std::string error_message = "";

    try {
        test_list.popFromFront();
    } 
    
    catch (const std::runtime_error &o) {
        exception_thrown = true;
        error_message = o.what();
    }

    assert(exception_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

//Tests popFromFront with an array of 1 element
void popFromFront_one_element() {
    CharLinkedList test_list('a');
    assert(test_list.size() == 1);
    test_list.popFromFront();
    assert(test_list.toString() == "[CharLinkedList of size 0 <<>>]");
}

//Tests popFromFront with an array of multiple elements
void popFromFront_multiple_elements() {
    char arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g','h'};
    CharLinkedList test_list(arr, 8);
    assert(test_list.size() == 8);
    test_list.popFromFront();
    assert(test_list.toString() == "[CharLinkedList of size 7 <<bcdefgh>>]");
}

// insertInOrder()

// Test insertInOrder with an empty list
void insertInOrder_empty() { 
    CharLinkedList test_list;
    test_list.insertInOrder('a');
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.toString() == "[CharLinkedList of size 1 <<a>>]");
}

// Tests insertInOrder with a list of 1 element
void insertInOrder_one_element() { 
    CharLinkedList test_list('a');
    assert(test_list.size() == 1);
    test_list.insertInOrder('b');
    assert(test_list.size() == 2);
    assert(test_list.toString() == "[CharLinkedList of size 2 <<ab>>]");
}

// Tests insertInOrder in the middle of a multiple element list
void insertInOrder_middle() {
    char arr[6] = {'a', 'b', 'c', 'e', 'f', 'g'};
    CharLinkedList test_list(arr, 6);
    assert(test_list.size() == 6);
    test_list.insertInOrder('d');
    assert(test_list.size() == 7);
    assert(test_list.toString() == "[CharLinkedList of size 7 <<abcdefg>>]");
}

// Tests insertInOrder in the front of a multiple element list
void insertInOrder_front() {
    char arr[6] = {'b', 'c', 'd', 'e', 'f', 'g'};
    CharLinkedList test_list(arr, 6);
    assert(test_list.size() == 6);
    test_list.insertInOrder('a');
    assert(test_list.size() == 7);
    assert(test_list.toString() == "[CharLinkedList of size 7 <<abcdefg>>]");
}

// Tests insertInOrder in the back of a multiple element list
void insertInOrder_back() {
    char arr[6] = {'a', 'b', 'c', 'd', 'e', 'f'};
    CharLinkedList test_list(arr, 6);
    assert(test_list.size() == 6);
    test_list.insertInOrder('g');
    assert(test_list.size() == 7);
    assert(test_list.toString() == "[CharLinkedList of size 7 <<abcdefg>>]");
}

// concatenate()

//Tests concatenate with two empty arrays
void concatenate_both_empty(){
    CharLinkedList list1;
    CharLinkedList list2;
    list1.concatenate(&list2);
    assert(list1.isEmpty());
}

//Tests concatenate an empty list with a non-empty list
void concatenate_empty() {
    CharLinkedList list1;
    assert(list1.size() == 0);
    char other_list[4] = {'a', 'b', 'c', 'd'};
    CharLinkedList list2(other_list, 4);
    list1.concatenate(&list2);
    assert(list1.toString() == "[CharLinkedList of size 4 <<abcd>>]");
}

//Tests concatenate with a non-empty list with an empty list
void concatenate_empty2() {
    char arr[4] = {'a', 'b', 'c', 'd'};
    CharLinkedList list1(arr, 4);
    CharLinkedList list2;
    list1.concatenate(&list2);
    assert(list1.toString() == "[CharLinkedList of size 4 <<abcd>>]");
}

// //Tests concatenate with 2 non-empty lists
void concatenate_one_element() {
    char arr[1] = {'a'};
    CharLinkedList list1(arr, 1);
    assert(list1.size() == 1);
    char other_list[1] = {'b'};
    CharLinkedList list2(other_list, 1);
    list1.concatenate(&list2);
    assert(list1.toString() == "[CharLinkedList of size 2 <<ab>>]");
}

// //Tests concatenate with an array of multiple elements
void concatenate_multiple_elements() {
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList list1(arr, 3);
    assert(list1.size() == 3);
    char other_list[3] = { 'd', 'e', 'f'};
    CharLinkedList list2(other_list, 3);
    list1.concatenate(&list2);
    assert(list1.toString() == "[CharLinkedList of size 6 <<abcdef>>]");
}

//Tests concatenate with one array adding to itself 
void concatenate_itself_test() {
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList list(arr, 3);
    assert(list.size() == 3);
    list.concatenate(&list);
    assert(list.toString() == "[CharLinkedList of size 6 <<abcabc>>]");
}


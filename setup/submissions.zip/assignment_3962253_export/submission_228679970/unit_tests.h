/*
 *  unit_tests.h
 *  CAITLYN WEI
 *  2/1/24
 *
 *  CS 15 HW 2 LINKED LISTS
 *
 *  Tests normal and edge cases for methods of the CharLinkedList class.
 *  Tests for error cases.
 *
 */

#include "CharLinkedList.h"
#include <cassert>

//testing the default constructor, sucessfully create default linked list
void default_constructor_test () {
    CharLinkedList test_list;
}

//testing the char constructor, checks if data value, front, and back pointers
//are as expected
void char_constructor_test () {
    CharLinkedList test_list('a');
    assert(test_list.first() == 'a');
    assert(test_list.toString() == "[CharLinkedList of size 1 <<a>>]");
}

//test array constructor
void array_constructor_test () {
    char test_array[] = {'a', 'b', 'c', 'd'};
    int size = 4;
    CharLinkedList test_list(test_array, size);

    assert(test_list.size() == 4);
    assert(test_list.first() == 'a');
    assert(test_list.last() == 'd');
    assert(test_list.toString() == "[CharLinkedList of size 4 <<abcd>>]");
}

void array_constructor_test_2 () {
    char test_array[] = {'a', 'b'};
    int size = 2;
    CharLinkedList test_list(test_array, size);

    assert(test_list.size() == 2);
    assert(test_list.first() == 'a');
    assert(test_list.last() == 'b');
    assert(test_list.toString() == "[CharLinkedList of size 2 <<ab>>]");
}

void array_constructor_test_3 () {
    char test_array[] = {'a', 'b', 'c'};
    int size = 3;
    CharLinkedList test_list(test_array, size);

    assert(test_list.size() == 3);
    assert(test_list.first() == 'a');
    assert(test_list.last() == 'c');
    assert(test_list.toString() == "[CharLinkedList of size 3 <<abc>>]");
}

//test array constructor when given empty array
void array_constructor_empty_test () {
    char test_array[0];
    int size = 0;
    CharLinkedList test_list(test_array, size);
//check first char
    bool runtime_error_thrown_first = false;
    std::string error_message_first = "";
    try {
        test_list.first();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown_first = true;
        error_message_first = e.what();
    }
    assert(runtime_error_thrown_first);
    assert(error_message_first == "cannot get first of empty LinkedList");
//check last char
    bool runtime_error_thrown_last = false;
    std::string error_message_last = "";
    try {
        test_list.last();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown_last = true;
        error_message_last = e.what();
    }
    assert(runtime_error_thrown_last);
    assert(error_message_last == "cannot get last of empty LinkedList");
//check linked list size
    assert(test_list.size() == 0);
}

//test array constructor when given an array size 1
void array_constructor_singleton_test () {
    char test_array[1] = {'a'};
    int size = 1;
    CharLinkedList test_list(test_array, size);

    assert(test_list.size() == 1);
    assert(test_list.first() == 'a');
    assert(test_list.last() == 'a');
    assert(test_list.toString() == "[CharLinkedList of size 1 <<a>>]");
}


//tests if size for empty linked list will return 0
void size_test_empty () {
    CharLinkedList test_list;
    assert(test_list.size() == 0);
}

//tests if size of single char linked list will return 1
void size_test_singleton () {
    CharLinkedList test_list('a');
    assert(test_list.size() == 1);
}


//tests if runtime error is thrown and checks the error message if first() 
//is used on an empty linked list
void first_test_empty () {
    CharLinkedList test_list;
    // var to track whether runtime_error is thrown
    bool runtime_error_thrown = false;
    // var to track any error messages raised
    std::string error_message = "";

    try {
    test_list.first();
    }
    catch (const std::runtime_error &e) {
    runtime_error_thrown = true;
    error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot get first of empty LinkedList");
}


//tests the first() function on a linked list with one char
void first_test_singleton () {
    CharLinkedList test_list('a');
    assert(test_list.first() == 'a');
}


//tests if range error is thrown and checks the error message if first() is 
//used on an empty linked list
void last_test_empty () {
    CharLinkedList test_list;
    // var to track whether runtime_error is thrown
    bool runtime_error_thrown = false;
    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.last();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot get last of empty LinkedList");
}

//tests the last() function on a linked list with one char
void last_test_singleton () {
    CharLinkedList test_list('a');
    assert(test_list.last() == 'a');
}

//push at back for default constructor
void push_at_back_test_default () {
    CharLinkedList test_list;
    test_list.pushAtBack('a');
    assert(test_list.last() == 'a');
    assert(test_list.size() == 1);
}

//push at back multiple times
void push_at_back_test_default_multiple () {
    CharLinkedList test_list;
    test_list.pushAtBack('a');
    test_list.pushAtBack('b');
    test_list.pushAtBack('c');
    test_list.pushAtBack('d');
    assert(test_list.last() == 'd');
    assert(test_list.size() == 4);
}

//push at back for single char constructor
void push_at_back_test_singleton () {
    CharLinkedList test_list('a');
    test_list.pushAtBack('b');
    assert(test_list.last() == 'b');
    assert(test_list.size() == 2);
}

//push at back for empty array
void push_at_back_test_empty_array () {
    char test_array[0];
    int size = 0;
    CharLinkedList test_list(test_array, size);
    test_list.pushAtBack('a');
    assert(test_list.last() == 'a');
    assert(test_list.size() == 1);
}

//push at back for single char array
void push_at_back_test_singleton_array () {
    char test_array[1] = {'a'};
    int size = 1;
    CharLinkedList test_list(test_array, size);
    test_list.pushAtBack('b');
    assert(test_list.last() == 'b');
    assert(test_list.size() == 2);
    assert(test_list.toString() == "[CharLinkedList of size 2 <<ab>>]");
}

//test push at back for array
void push_at_back_test_array () {
    char test_array[] = {'a', 'b', 'c', 'd'};
    int size = 4;
    CharLinkedList test_list(test_array, size);
    test_list.pushAtBack('e');
    assert(test_list.last() == 'e');
    assert(test_list.size() == 5);
    assert(test_list.toString() == "[CharLinkedList of size 5 <<abcde>>]");
}

//test push at front for default constructor
void push_at_front_test_default () {
    CharLinkedList test_list;
    test_list.pushAtFront('a');
    assert(test_list.first() == 'a');
    assert(test_list.size() == 1);
}

//test push at front multiple times
void push_at_front_test_default_multiple () {
    CharLinkedList test_list;
    test_list.pushAtFront('a');
    test_list.pushAtFront('b');
    test_list.pushAtFront('c');
    test_list.pushAtFront('d');
    assert(test_list.first() == 'd');
    assert(test_list.size() == 4);
    assert(test_list.toString() == "[CharLinkedList of size 4 <<dcba>>]");
}

//test push at front single char construct
void push_at_front_test_singleton () {
    CharLinkedList test_list('a');
    test_list.pushAtFront('b');
    assert(test_list.first() == 'b');
    assert(test_list.size() == 2);
}

//test push at front empty array
void push_at_front_test_empty_array () {
    char test_array[0];
    int size = 0;
    CharLinkedList test_list(test_array, size);
    test_list.pushAtFront('a');
    assert(test_list.first() == 'a');
    assert(test_list.size() == 1);
}

//test push at front single array
void push_at_front_test_singleton_array () {
    char test_array[1] = {'a'};
    int size = 1;
    CharLinkedList test_list(test_array, size);
    test_list.pushAtFront('b');
    assert(test_list.first() == 'b');
    assert(test_list.size() == 2);
}

//test push at front array
void push_at_front_test_array () {
    char test_array[] = {'a', 'b', 'c', 'd'};
    int size = 4;
    CharLinkedList test_list(test_array, size);
    test_list.pushAtFront('e');
    assert(test_list.first() == 'e');
    assert(test_list.size() == 5);
}

//test element at default, return range_error
void element_at_test_default_incorrect () {
    CharLinkedList test_list;
    bool range_error_thrown = false;
    std::string error_message = "";
    try {
        test_list.elementAt(0);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message ==  "index (0) not in range [0..0)");
}

//test element at invalid index
void element_at_test_singleton_incorrect () {
    CharLinkedList test_list('a');
    bool range_error_thrown = false;
    std::string error_message = "";
    try {
        test_list.elementAt(1);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message ==  "index (1) not in range [0..1)");
}

//test element at correct index
void element_at_test_singleton_correct () {
    CharLinkedList test_list('a');
    assert(test_list.elementAt(0) == 'a');
}

//attempting in access element at invalid index
void element_at_test_array_incorrect () {
    char test_array[] = {'a', 'b', 'c'};
    int size = 3;
    CharLinkedList test_list(test_array, size);
    bool range_error_thrown = false;
    std::string error_message = "";
    try {
        test_list.elementAt(6);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message ==  "index (6) not in range [0..3)");
}

//element at valid index, array
void element_at_test_array_correct () {
    char test_array[] = {'a', 'b', 'c', 'd', 'e'};
    int size = 5;
    CharLinkedList test_list(test_array, size);
    assert(test_list.elementAt(3) ==  'd');
}


void pop_from_front_singleton_correct () {
    CharLinkedList test_list('a');
    test_list.popFromFront();
    assert(test_list.size() == 0);
    assert(test_list.toString() ==  "[CharLinkedList of size 0 <<>>]");
}

void pop_from_front_empty_incorrect () {
    CharLinkedList test_list;

    bool runtime_error_thrown = false;
    std::string error_message = "";
    try {
        test_list.popFromFront();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message ==  "cannot pop from empty LinkedList");
}

void pop_from_front_array () {
    char test_array[] = {'a', 'b', 'c', 'd', 'e'};
    int size = 5;
    CharLinkedList test_list(test_array, size);
    test_list.popFromFront();
    assert(test_list.toString() ==  "[CharLinkedList of size 4 <<bcde>>]");
    assert(test_list.size() == 4);
    test_list.popFromFront();
    assert(test_list.toString() ==  "[CharLinkedList of size 3 <<cde>>]");
    assert(test_list.size() == 3);
}

void pop_from_back_singleton_correct () {
    CharLinkedList test_list('a');
    test_list.popFromBack();
    assert(test_list.size() == 0);
    assert(test_list.toString() ==  "[CharLinkedList of size 0 <<>>]");
}

void pop_from_Back_empty_incorrect () {
    CharLinkedList test_list;

    bool runtime_error_thrown = false;
    std::string error_message = "";
    try {
        test_list.popFromBack();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message ==  "cannot pop from empty LinkedList");
    
}

void pop_from_back_array () {
    char test_array[] = {'a', 'b', 'c', 'd', 'e'};
    int size = 5;
    CharLinkedList test_list(test_array, size);
    assert(test_list.toString() ==  "[CharLinkedList of size 5 <<abcde>>]");
    test_list.popFromBack();
    assert(test_list.toString() ==  "[CharLinkedList of size 4 <<abcd>>]");
    assert(test_list.size() == 4);
}

//removing at invalid index
void remove_at_default_incorrect () {
    CharLinkedList test_list;
    bool range_error_thrown = false;
    std::string error_message = "";
    try {
        test_list.removeAt(0);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message ==  "index (0) not in range [0..0)");
}

void remove_at_singleton () {
    CharLinkedList test_list('a');
    test_list.removeAt(0);
    assert(test_list.toString() ==  "[CharLinkedList of size 0 <<>>]");
}

void remove_at_singleton_incorrect () {
    CharLinkedList test_list('a');
    bool range_error_thrown = false;
    std::string error_message = "";
    try {
        test_list.removeAt(1);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message ==  "index (1) not in range [0..1)");
}

void remove_at_array () {
    char test_array[] = {'a', 'b', 'c', 'd', 'e'};
    int size = 5;
    CharLinkedList test_list(test_array, size);
    test_list.removeAt(2);
    assert(test_list.toString() ==  "[CharLinkedList of size 4 <<abde>>]");
    assert(test_list.size() == 4);
}

void remove_at_array_first () {
    char test_array[] = {'a', 'b', 'c', 'd', 'e'};
    int size = 5;
    CharLinkedList test_list(test_array, size);
    test_list.removeAt(0);
    assert(test_list.toString() ==  "[CharLinkedList of size 4 <<bcde>>]");
    assert(test_list.size() == 4);
}

void remove_at_array_last () {
    char test_array[] = {'a', 'b', 'c', 'd', 'e'};
    int size = 5;
    CharLinkedList test_list(test_array, size);
    test_list.removeAt(4);
    assert(test_list.toString() ==  "[CharLinkedList of size 4 <<abcd>>]");
    assert(test_list.size() == 4);
}

//removing at invalid index
void remove_at_array_incorrect () {
    char test_array[] = {'a', 'b', 'c', 'd', 'e'};
    int size = 5;
    CharLinkedList test_list(test_array, size);
    bool range_error_thrown = false;
    std::string error_message = "";
    try {
        test_list.removeAt(6);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message ==  "index (6) not in range [0..5)");
}

void to_string_default_test () {
    CharLinkedList test_list;

    assert(test_list.toString() ==  "[CharLinkedList of size 0 <<>>]");
}

void to_string_singleton_test () {
    CharLinkedList test_list('a');
    assert(test_list.toString() == "[CharLinkedList of size 1 <<a>>]");
}

void to_string_array_test () {
    char test_array[] = {'a', 'b', 'c', 'd', 'e'};
    int size = 5;
    CharLinkedList test_list(test_array, size);
    assert(test_list.toString() == "[CharLinkedList of size 5 <<abcde>>]");
}

void insert_at_default () {
    CharLinkedList test_list;
    test_list.insertAt('a', 0);
    assert(test_list.toString() == "[CharLinkedList of size 1 <<a>>]");    
}

//inserting at invalid index
void insert_at_default_incorrect () {
    CharLinkedList test_list;
    bool range_error_thrown = false;
    std::string error_message = "";
    try {
        test_list.insertAt('a', 1);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message ==  "index (1) not in range [0..0)");  
}

void insert_at_singleton_front () {
    CharLinkedList test_list('a');
    test_list.insertAt('b', 0);
    assert(test_list.toString() == "[CharLinkedList of size 2 <<ba>>]");    
}

void insert_at_singleton_back () {
    CharLinkedList test_list('a');
    test_list.insertAt('b', 1);
    assert(test_list.toString() == "[CharLinkedList of size 2 <<ab>>]");    
}

//inserting at invalid index
void insert_at_singleton_incorrect () {
    CharLinkedList test_list('a');
    bool range_error_thrown = false;
    std::string error_message = "";
    try {
        test_list.insertAt('b', 2);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message ==  "index (2) not in range [0..1)");  
}

void insert_at_array () {
    char test_array[] = {'a', 'b', 'c', 'd', 'e'};
    int size = 5;
    CharLinkedList test_list(test_array, size);
    test_list.insertAt('f', 2);
    assert(test_list.toString() == "[CharLinkedList of size 6 <<abfcde>>]");    
}

void insert_at_array_front () {
    char test_array[] = {'a', 'b', 'c', 'd', 'e'};
    int size = 5;
    CharLinkedList test_list(test_array, size);
    test_list.insertAt('f', 0);
    assert(test_list.toString() == "[CharLinkedList of size 6 <<fabcde>>]");    
}

void insert_at_array_back () {
    char test_array[] = {'a', 'b', 'c', 'd', 'e'};
    int size = 5;
    CharLinkedList test_list(test_array, size);
    test_list.insertAt('f', 5);
    assert(test_list.toString() == "[CharLinkedList of size 6 <<abcdef>>]");    
}

//inserting at invalid index
void insert_at_array_incorrect () {
    char test_array[] = {'a', 'b', 'c', 'd', 'e'};
    int size = 5;
    CharLinkedList test_list(test_array, size);
    bool range_error_thrown = false;
    std::string error_message = "";
    try {
        test_list.insertAt('f', 6);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message ==  "index (6) not in range [0..5)");  
}

void replace_at_default () {
    CharLinkedList test_list;
    bool range_error_thrown = false;
    std::string error_message = "";
    try {
        test_list.replaceAt('a', 0);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message ==  "index (0) not in range [0..0)");  
}

void replace_at_singleton () {
    CharLinkedList test_list('a');
    test_list.replaceAt('b', 0);
    assert(test_list.toString() == "[CharLinkedList of size 1 <<b>>]");  
}

void replace_at_singleton_invalid () {
    CharLinkedList test_list('a');
    bool range_error_thrown = false;
    std::string error_message = "";
    try {
        test_list.replaceAt('b', 1);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message ==  "index (1) not in range [0..1)");
}

void replace_at_array () {
    char test_array[] = {'a', 'b', 'c', 'd', 'e'};
    int size = 5;
    CharLinkedList test_list(test_array, size);
    test_list.replaceAt('f', 2);
    assert(test_list.toString() == "[CharLinkedList of size 5 <<abfde>>]");  
}

void replace_at_array_front () {
    char test_array[] = {'a', 'b', 'c', 'd', 'e'};
    int size = 5;
    CharLinkedList test_list(test_array, size);
    test_list.replaceAt('f', 0);
    assert(test_list.toString() == "[CharLinkedList of size 5 <<fbcde>>]");  
}

void replace_at_array_back () {
    char test_array[] = {'a', 'b', 'c', 'd', 'e'};
    int size = 5;
    CharLinkedList test_list(test_array, size);
    test_list.replaceAt('f', 4);
    assert(test_list.toString() == "[CharLinkedList of size 5 <<abcdf>>]");  
}

void to_reverse_string_default_test () {
    CharLinkedList test_list;

    assert(test_list.toReverseString() ==  "[CharLinkedList of size 0 <<>>]");
}

void to_reverse_string_singleton_test () {
    CharLinkedList test_list('a');
    assert(test_list.toReverseString() == "[CharLinkedList of size 1 <<a>>]");
}

void to_reverse_string_array_test () {
    char test_array[] = {'a', 'b', 'c', 'd', 'e'};
    int size = 5;
    CharLinkedList test_list(test_array, size);
    assert(test_list.toReverseString() == 
    "[CharLinkedList of size 5 <<edcba>>]");
}

void insert_in_order_default () {
    CharLinkedList test_list;
    test_list.insertInOrder('a');
    test_list.insertInOrder('z');
    test_list.insertInOrder('m');
    assert(test_list.toString() == "[CharLinkedList of size 3 <<amz>>]");
}

void insert_in_order_singleton () {
    CharLinkedList test_list('e');
    test_list.insertInOrder('a');
    test_list.insertInOrder('z');
    test_list.insertInOrder('m');
    assert(test_list.toString() == "[CharLinkedList of size 4 <<aemz>>]");
}

void insert_in_order_array () {
    char test_array[] = {'e', 'j', 'o', 't', 'y'};
    int size = 5;
    CharLinkedList test_list(test_array, size);
    test_list.insertInOrder('a');
    test_list.insertInOrder('z');
    test_list.insertInOrder('m');
    assert(test_list.toString() == "[CharLinkedList of size 8 <<aejmotyz>>]");
}






/*
 *  CharLinkedList.h
 *  CAITLYN WEI
 *  1/31/24
 *
 *  CS 15 HW 2 Linked List
 *
 * Serves as an interface for users, lists methods of CharLinkedList class.
 * A CharLinkedList is a ordered set of elements (Nodes) and can be used to 
 * store only chars. Each node has a pointer to the previous and next node in 
 * the linked list. The CharLinkedList also hold pointers to the front and back 
 * of the linked list as well as the number of elements (numItems) in the linked
 * list Each new CharLinkedList begins empty, unless otherwise specified by 
 * including various parameters.
 *
 */

#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H

#include <iostream>
#include <string>

using namespace std;

class CharLinkedList {
    public:
        CharLinkedList();
        CharLinkedList(char c);
        CharLinkedList(char arr[], int size);
        CharLinkedList(const CharLinkedList &other);
        ~CharLinkedList();
        CharLinkedList &operator=(const CharLinkedList &other);
        bool isEmpty() const;
        void clear();
        int size() const;
        char first() const;
        char last();
        char elementAt(int index) const;
        std::string toString() const;
        std::string toReverseString() const;
        void pushAtBack(char c);
        void pushAtFront(char c);
        void insertAt(char c, int index);
        void insertInOrder(char c);
        void popFromFront();
        void popFromBack();
        void removeAt(int index);
        void replaceAt(char c, int index);
        void concatenate(CharLinkedList *other);

    private:
        struct Node {
            char data;
            Node *next;
            Node *previous;
        };

        Node *front;
        Node *back;
        int numItems;

        void deleteNode(Node *curr);
        char findElement(Node *curr, int index) const;
        CharLinkedList:: Node *findNode(Node *currNode, 
        int index, int currIndex) const;
        void recycleRecursive(Node *curr);

};

#endif

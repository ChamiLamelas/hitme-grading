/*
 *  CharLinkedList.cpp
 *  CAITLYN WEI
 *  1/31/24
 *
 *  CS 15 HW 2 LINKED LIST
 *
 *  methods of CharLinkedList class
 *
 */

#include "CharLinkedList.h"
#include <sstream>


/* CharLinkedList()
 * Description: linked list default constructor, creates default linked list
 * Input: none
 * Output: N/A
 * Effects: creates default char linked list
 */
CharLinkedList::CharLinkedList() {
//initialize values
    front = nullptr;
    back = nullptr;
    numItems = 0;
};


/* CharLinkedList(char c)
 * Description: a constructor that created a char linked list using a given char
 * Input: a char c to initialize a node of a char linked list
 * Output: N/A
 * Effects: creates a linked list with a node containing the given char value
 */
CharLinkedList::CharLinkedList(char c) {
//initalize new node
    Node *newNode = new Node;
    newNode->data = c;
    newNode->next = nullptr;
    newNode->previous = nullptr;
//initialize values
    front = newNode;
    back = newNode;
    numItems = 1;
};

/* CharLinkedList(char arr[], int size)
 * Description: char linked list constuctor that creates a linked list using an
 *              array of chars and the int size of the array (number of elts.)
 * Input: an array of chars to be put in linked list and the size of the array
 * Output: N/A
 * Effects: creates a linked list with a node for each char in given array, 
 *          linked list is in the order of the given array.
 * Notes: MUST ENSURE THAT THE INT SIZE IS THE SIZE OF THE ARRAY, DID NOT
 *        ACCOUNT FOR INVALID USER INPUT WERE SIZE != SIZE OF GIVEN ARRAY!
 */
CharLinkedList::CharLinkedList(char arr[], int size) {
//pointer for previous node, used to doubly link
    Node *previousNode = nullptr;
    if (size == 0) {    //array size 0, default constructor
        front = nullptr;
        back = nullptr;
        numItems = 0;
    } else {
        for (int i = 0; i < size; i++) {
            Node *newNode = new Node;   //create new node for each element
            newNode->data = arr[i];
            if (previousNode == nullptr) {  //identify front
                front = newNode;
            } else {
                previousNode->next = newNode;   //link "forwards"
            }
            newNode->next = nullptr;    //newNode->next hasn't been made yet
            newNode->previous = previousNode;   //link "backwards"
            previousNode = newNode;
        }
        back = previousNode;                //identify back
        numItems = size;
    }
    
};

/* CharLinkedList(CharLinkedList &other)
 * Description: copy one linked list from user onto new linked list
 * Input: a linked list to be copied
 * Output: none
 * Effects: creates new linked list and copies all element of given linked list
 *          onto new linked list
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other) {
    numItems = 0;
    front = nullptr;
    back = nullptr;

    int otherSize = other.size();

    for (int i = 0; i < otherSize; i++) {
        this->pushAtBack(other.elementAt(i));
    }
    
};

/* ~CharLinkedList()
 * Description: deletes linked list using a recursive function, see deleteNode()
 * Input: none
 * Output: N/A
 * Effects: calls deleteNode(), deletes allocated memory on heap
 */
CharLinkedList::~CharLinkedList() {
    deleteNode(front);  //recursive func. see deleteNode()
};

/* deleteNode(Node *curr)
 * Description: a recursive function that deletes elements of a linked list by 
 *              deleting the current element, then recursively deleting each 
 *              next element until the end of the list.
 * Input: a Node pointer to the, preferably first, element
 * Output: N/A
 * Effects: deletes linked list, deletes allocated memory on heap
 */
void CharLinkedList::deleteNode(Node *curr) {
    if (curr == nullptr) {
        return;  // base case: reached the end of the list
    }
    Node *nextNode = curr->next;  // save the nextNode before deleting the curr
    delete curr;  // delete the current node
    deleteNode(nextNode);  // recursive call
};

/* CharLinkedList &operator=
 * Description: copy one linked list onto another
 * Input: a linked list to be copied
 * Output: linked list object
 * Effects: deletes memory on left linked list and creates a new linked list
 *          on right
 */
CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other) {
    if (this == &other) {
        return *this;
    }

    recycleRecursive(this->front);
    front = nullptr;
    back = nullptr;

    int otherSize = other.size();
    numItems = 0;

    for (int i = 0; i < otherSize; i++) {
        this->pushAtBack(other.elementAt(i));
    }

    return *this;
};

/* isEmpty()
 * Description: checks if a char linked list is empty
 * Input: none
 * Output: true if char linked list is empty, false if char linked list
 *          contains items.
 * Effects: N/A
 */
bool CharLinkedList::isEmpty() const {
    if (numItems == 0) {
        return 1;
    }
        return 0;
};

/* clear()
 * Description: "empties" linked list by making numItems 0
 * Input: none
 * Output: N/A
 * Effects: set numItems to 0
 */
void CharLinkedList::clear() {
    numItems = 0;
};

/* size()
 * Description: gives the size, or number of items, in a char linked list
 * Input: none
 * Output: returns numItems, the number of items in the char linked list
 * Effects: N/A
 */
int CharLinkedList::size() const {
    return numItems;
};


/* first()
 * Description: finds the first data value in a char linked list
 * Input: none
 * Output: returns the first element in a char linked list
 * Effects: N/A
 */
char CharLinkedList::first() const {
    //linked list is empty
    if (numItems == 0) {
        throw std::runtime_error("cannot get first of empty LinkedList");
    }
    return front->data;
};


/* last()
 * Description: finds the last data value in a char linked list
 * Input: none
 * Output: returns the last element in a char linked list
 * Effects: N/A
 */
char CharLinkedList::last() {
    //linked list is empty
    if (numItems == 0) {
        throw std::runtime_error("cannot get last of empty LinkedList");
    }
    return back->data;
};

/* elementAt()
 * Description: finds the element at a given index in a linked list using helper
                fn findElement.
 * Input: int index, where the user wants to identify an element of the LL
 * Output: returns the  element in the given index of the linked list
 * Effects: calls findElement (see findElement)
 * Notes: index is 0 indexed
 */
char CharLinkedList::elementAt(int index) const {
    if (index < 0 or index >= numItems) {
        throw std::range_error("index (" + std::to_string(index) + 
        ") not in range [0.." + std::to_string(numItems) + ")");
    }

    return findElement(this->front, index);

};

/* findElement(Node *curr, int index)
 * Description: finds the element at a given index in a linked list by 
                recursively searching for correct node at index in linked list.
 * Input: node pointer to first node in linked list. int index, where the user 
    `       wants to identify an element of the linkedlist
 * Output: returns the  element in the given index of the linked list
 * Effects: recursive, calls findElement until it arrives at the 
 *          given index node
 * Notes: index is 0 indexed
 */
char CharLinkedList::findElement(Node *curr, int index) const {
    if (index == 0) {
        return curr->data;
    }

    return findElement(curr->next, index - 1);
};

/* toString()
 * Description: prints out the elements of a linked list in the format:
                [CharLinkedList of size SIZE <<DATA>>] where SIZE is number of
                elements in the linked list and DATA is the individual chars 
                contained in linked list for every element (in "forward" order)
 * Input: none
 * Output: string [CharLinkedList of size SIZE <<DATA>>]
 * Effects: N/A
 */
std::string CharLinkedList::toString() const {
    std::ostringstream s;
    Node *curr = front;

    if (isEmpty()) {
        s << "[CharLinkedList of size 0 <<>>]";
    } else {
        s << "[CharLinkedList of size " << numItems << " <<";
        for (int i = 0; i < numItems; i++) {
            s << curr->data;
            curr = curr->next;
        }
        s << ">>]";
    }

    return s.str();
};

/* reverseString()
 * Description: prints out the elements of a linked list in the format:
                [CharLinkedList of size SIZE <<DATA>>] where SIZE is number of
                elements in the linked list and DATA is the individual chars 
                contained in linked list for every element (in "reverse" order)
 * Input: none
 * Output: string [CharLinkedList of size SIZE <<DATA>>]
 * Effects: N/A
 */
std::string CharLinkedList::toReverseString() const {
    std::ostringstream s;
    Node *curr = back;

    if (isEmpty()) {
        s << "[CharLinkedList of size 0 <<>>]";
    } else {
        s << "[CharLinkedList of size " << numItems << " <<";
        for (int i = 0; i < numItems; i++) {
            s << curr->data;
            curr = curr->previous;
        }
        s << ">>]";
    }

    return s.str();
};

/* pushAtBack()
 * Description: puts the given char at the end of a linked list by creating a 
                new node and initializing values
 * Input: char c of new char to add to linked list
 * Output: none
 * Effects: adds a node with data of char c to the end of the existing linked
 *          list. makes the newly added node the back of linked list. if the 
 *          initial linked list was empty, makes the newly created node as the
 *          front of the list. increments numItems.
 */
void CharLinkedList::pushAtBack(char c) {
    Node *newNode = new Node;
    newNode->data = c;
    newNode->next = nullptr;
    //if existing linked list has 0 elements
    if (numItems == 0) {
        this->front = newNode;
        newNode->previous = nullptr;
        
    } else {    //link new node
        newNode->previous = this->back;
        this->back->next = newNode;
    }
    this->back = newNode;   //new back of linked list
    numItems++;
};

/* pushAtFront()
 * Description: puts the given char at the beginning of a linked list by 
                creating a new node and initializing values
 * Input: char c of new char to add to linked list
 * Output: none
 * Effects: adds a node with data of char c to the beginning of the existing 
 *          linked list. makes the newly added node the front of linked list. 
 *          if the initial linked list was empty, makes the newly created node 
 *          as the back of the list. increments numItems.
 */
void CharLinkedList::pushAtFront(char c) {
    Node *newNode = new Node;
    newNode->data = c;
    newNode->previous = nullptr;
    //if existing linked list has 0 elements
    if (numItems == 0) {
        this->back = newNode;
        newNode->next = nullptr;
        
    } else {    //link new node
        newNode->next = this->front;
        this->front->previous = newNode;
    }
    this->front = newNode;   //new back of linked list
    numItems++;

};

/* insertAt()
 * Description: puts the given char at the given index of a linked list by 
                creating a new node and initializing values, 
                reassigning pointers
 * Input: char c of new char to add to linked list and int index at which new 
            element is to be located
 * Output: none
 * Effects: adds a node with data of char c to the given index of the existing 
 *          linked list. if the newly added node is the front of linked list, 
 *          calls pushAtFront(). if the newly added node is at the back of the
 *          linked list, calls pushAtBack(). reassigns next and previous 
 *          pointers for element before given index, element after given index,
 *          and new element. increments numItems.
 */
void CharLinkedList::insertAt(char c, int index) {
    if (index < 0 or index > numItems) {
        throw std::range_error("index (" + std::to_string(index) + 
        ") not in range [0.." + std::to_string(numItems) + ")");
    }
    if (index == 0) {
        pushAtFront(c);
    } else if (index == numItems) {
        pushAtBack(c);
    } else {
        Node *newNode = new Node;
        newNode->data = c;
        newNode->next = nullptr;
        newNode->previous = nullptr;
        Node *curr = front;
        int currIndex = 0;
        while (currIndex != index - 1) {
            curr = curr->next;
            currIndex++;
        }
        newNode->next = curr->next;
        newNode->previous = curr;
        curr->next->previous = newNode;
        curr->next = newNode;
        numItems++;
    }
    
};

/* insertInOrder()
 * Description: insert user provided data element into linked list in 
                alphabetical order
 * Input: char c of new char to add to linked list
 * Output: none
 * Effects: inserts char into linked list in alphabetical order
 * Note: assumes that linked list is already in alphabetical order
 */
void CharLinkedList::insertInOrder(char c) {
    int index = 0;
    while (index < numItems and elementAt(index) < c) {
        index++;
    }

    insertAt(c, index);
};

/* popFromFront()
 * Description: pops first element from the front of a linked list, effectively 
                deleting it.
 * Input: none
 * Output: N/A
 * Effects: makes the previously second element the new front, deletes the old 
 *          front element. decrements numItems.
 */
void CharLinkedList::popFromFront() {
    if (numItems == 0) {
        throw std::runtime_error("cannot pop from empty LinkedList");
    }

    Node *newFront = front->next;
    if (newFront!=nullptr) {    //linked list is not empty after popping
        newFront->previous = nullptr;
    } else {    //linked list is now empty after popping
        back = nullptr;
    }

    delete front;   //delete previous front
    front = newFront;
    
    numItems--;
};

/* popFromBack()
 * Description: pops last element from the back of a linked list, effectively 
                deleting it.
 * Input: none
 * Output: N/A
 * Effects: makes the previously second-to-last element the new back, deletes 
 *          the old back element. decrements numItems.
 */
void CharLinkedList::popFromBack() {
    if (numItems == 0) {
        throw std::runtime_error("cannot pop from empty LinkedList");
    }

    Node *newBack = back->previous;
    if (newBack!=nullptr) {    //linked list is not empty after popping
        newBack->next = nullptr;
    } else {    //linked list is now empty after popping
        front = nullptr;
    }

    delete back;   //delete previous back
    back = newBack;
    
    numItems--;
};

/* removeAt()
 * Description: pops element at a given index fron linked list, deleting element
 * Input: int index at which the user choses to delete element from linked list
 * Output: N/A
 * Effects: if the chosen element to delete was the front, initiates a new front
 *          element. if the chosen element to delete was the back, intitiates
 *          a new back element. changes pointers of the previous element's 
 *          next pointer to element after the deleted element and next element's
 *          previous pointer to the element before deleted element. 
 *          decrements numItems.
 * Notes: index is 0 indexed
 */
void CharLinkedList::removeAt(int index) {
    if (index < 0 or index >= numItems) {
        throw std::range_error("index (" + std::to_string(index) + 
        ") not in range [0.." + std::to_string(numItems) + ")");
    }

    if (index ==0) {
        popFromFront();
    } else if (index == numItems - 1) {
        popFromBack();
    } else {
        Node* current = front;
        for (int i = 0; i < index; ++i) {
            current = current->next;
        }
        Node *previousNode = current->previous;
        Node *nextNode = current->next;

        current->previous->next = nextNode;
        current->next->previous = previousNode;

        delete current;
        numItems--;
    }

};

/* replaceAt()
 * Description: replaces the data at the given index node by recursively finding
                the node.
 * Input: int index at which the user choses to replace element and char c of 
        data value to be replaced with.
 * Output: N/A
 * Effects: calls findNode(), replaces data at given index with given char
 * Notes: index is 0 indexed
 */
void CharLinkedList::replaceAt(char c, int index) {
    if (index < 0 or index >= numItems) {
        throw std::range_error("index (" + std::to_string(index) + 
        ") not in range [0.." + std::to_string(numItems) + ")");
    }

    Node *currNode = front;
    int currIndex = 0;
    Node *targetNode = findNode(currNode, index, currIndex);

    targetNode->data = c;
};

/* findNode()
 * Description: finds node at given index by "counting" from the front
 * Input: Node pointer to front node in linked list, int index of location of 
 *         element to be replaced, currindex = 0 to increment (count)
 * Output: a pointer to node to be replaced
 * Effects: calls findNode()
 * Notes: index is 0 indexed
 */
CharLinkedList::Node *CharLinkedList::findNode(Node *currNode, int index, 
                                                        int currIndex) const {
    if (currIndex == index) {
        return currNode;    //base case
    } else if (currIndex < index) {
        currIndex++;
        currNode = currNode->next;
        return findNode(currNode, index, currIndex);
    }
    return nullptr;
};



/* concatenate()
 * Description: concatenates linked list with user given linked list
 * Input: linked list object of linked list to be concatenated with
 * Output: N/A
 * Effects: concatenates linked list to user given linked list
 */
void CharLinkedList::concatenate(CharLinkedList *other) {
    Node *curr = other->front;
    int otherSize = other->size();

    for (int i = 0; i < otherSize; i++) {
        pushAtBack(curr->data);
        curr = curr->next;
    }
};

/* recycleRecursive()
 * Description: deletes memory
 * Input: none
 * Output: none
 * Effects: delete memory allocated on heap
 * Notes: index is 0 indexed
 */
void CharLinkedList::recycleRecursive(Node *curr) {
    if (curr == nullptr) {
        return;
    } else {
        Node *next = curr->next;
        delete curr;
        recycleRecursive(next);
    }
};


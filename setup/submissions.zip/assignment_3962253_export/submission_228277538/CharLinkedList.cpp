/*
 *  CharLinkedList.cpp
 *  Cole Morrel (cmorre02)
 *  2/3/24
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  This file contains an implementation of the CharLinkedList class.
 *
 */

#include "CharLinkedList.h"
#include <sstream>
#include <string>

/*
 * name:      CharLinkedList default constructor
 * purpose:   initialize an empty CharLinkedList
 * arguments: none
 * returns:   CharLinkedList
 * effects:   Empty CharLinkedList created
 */CharLinkedList::CharLinkedList() {
    front = nullptr;
    back = nullptr;
    numElements = 0;
}

/*
 * name:      CharLinkedList single character constructor
 * purpose:   initialize an CharLinkedList with a single char
 * arguments: a char to add to the CharLinkedList
 * returns:   CharLinkedList
 * effects:   CharLinkedList of size 1 created and input char in list.
 */
CharLinkedList::CharLinkedList(char inputChar) {
    front = nullptr;
    back = nullptr;
    numElements = 0;   
    pushAtFront(inputChar);
}

/*
 * name:      CharLinkedList array and size constructor
 * purpose:   initialize an CharLinkedList with an input array as input.
 * arguments: a array to use in CharLinkedList and the size of the array.
 * returns:   CharLinkedList
 * effects:   CharLinkedList of size equal to input size created with characters
 *            from input array in the ArrayList.
 */
CharLinkedList::CharLinkedList(char arr[], int size) {
    front = nullptr;
    back = nullptr;
    numElements = 0;
    
    // Add each element from array into list
    for(int i = size - 1; i >= 0; i--)
        pushAtFront(arr[i]);

}

/*
 * name:      CharLinkedList copy constructor
 * purpose:   create and initialize an new CharLinkedList with another
 *            CharLinkedList as an input.
 * arguments: a CharLinkedList to copy.
 * returns:   a CharLinkedList
 * effects:   makes a deep copy of an input CharLinkedList.
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other) {
    front = nullptr;
    back = nullptr;
    numElements = 0;
    
    // Copies nodes from other into new list
    copyNodes(other.front, other.numElements);
}


/*
 * destructor
 * purpose:   Free heap-allocated memory of 'this' 
 * arguments: None
 * returns:   None
 * effects:   memory on heap freed
 */
CharLinkedList::~CharLinkedList() {
    deleteNodes();
    
}

/*
 * name:      CharLinkedList assignment operator
 * purpose:   set one CharLinked list equal to another
 * arguments: a CharLinkedList to set this list equal to.
 * returns:   none
 * effects:   sets this list equal to another list (and frees memory of this
 *            list).
 */
CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other) {
    // Check if trying to set something equal to itself.
    if (this == &other)
        return *this;
    
    // Recycle memory
    clear();

    // Copies other right list into left list
    copyNodes(other.front, other.numElements);

    return *this;
}

/*
 * name:      isEmpty
 * purpose:   determines if the CharLinkedList is empty or not
 * arguments: none
 * returns:   true if CharLinkedList contains no elements, false otherwise
 * effects:   none
 */
bool CharLinkedList::isEmpty() const {
    // Check numElements is 0 AND front and back don't point to any Nodes
    if (numElements == 0 and front == nullptr and back == nullptr)
        return true;
    else
        return false;
}

/*
 * name:      size
 * purpose:   determine the number of items in the CharLinkedList
 * arguments: none
 * returns:   number of elements currently stored in the CharLinkedList
 * effects:   none
 */
int CharLinkedList::size() const {
    // numElements tracks how many elements in list, so only thing that needs to
    // be checked or returned
    return numElements;
}

/*
 * name:      first
 * purpose:   determines the element in CharLinkedList at the first position
 * arguments: none
 * returns:   char if index CharLinkedList is not empty
 * effects:   throws error if CharLinkedList is empty
 */
char CharLinkedList::first() const {
    // Use if-else to check for being called on empty list
    if (numElements == 0)
        throw std::runtime_error("cannot get first of empty LinkedList");
    else
        return front->info;
}

/*
 * name:      last
 * purpose:   determines the element in CharLinkedList at the last position
 * arguments: none
 * returns:   char if index CharLinkedList is not empty
 * effects:   throws error if CharLinkedList is empty
 */
char CharLinkedList::last() const {
     // Use if-else to check for being called on empty list
    if (numElements == 0)
        throw std::runtime_error("cannot get last of empty LinkedList");
    else
        return back->info;
}

/*
 * name:      elementAt
 * purpose:   determines the element in CharLinkedList at specific index
 * arguments: index as integer
 * returns:   char if index specified is within range of list
 * effects:   throws error if outside of range
 */
char CharLinkedList::elementAt(int index) const {
    // Use if-else to check for out of range index provided
    if (index >= 0 and index < numElements) {
        // Fetch element at index and then return info stored in that element
        Node *nodeAtIndex = nodeAt(index);
        return nodeAtIndex->info;
    } else {
        throw std::range_error("index (" + std::to_string(index) 
        + ") not in range [0.." + std::to_string(numElements) + ")");
    }


}


/*
 * name:      toString
 * purpose:   turns the list into a string, and returns it
 * arguments: none
 * returns:   a string representation of the list
 * effects:   none
 */
std::string CharLinkedList::toString() const {
    std::stringstream ss;
    ss << "[CharLinkedList of size " << this->numElements << " <<";

    // Start at front of list
    Node *curr = this->front;
    
    // iterate through every element in list, adding their info to stringstream
    while (curr != nullptr) {
        ss << curr->info;
        curr = curr->next;
    }

    ss << ">>]";

    return ss.str();
}


/*
 * name:      toReverseString
 * purpose:   returns the elements in the list as a string in reversed order
 * arguments: none
 * returns:   a string representation of the list reversed
 * effects:   none
 */
std::string CharLinkedList::toReverseString() const {
    std::stringstream ss;
    ss << "[CharLinkedList of size " << this->numElements << " <<";

    // Start at back of list (since want reverse string)
    Node *curr = this->back;
    
    // iterate through every element in list, adding their info to stringstream
    while (curr != nullptr) {
        ss << curr->info;
        curr = curr->previous;
    }

    ss << ">>]";

    return ss.str();
}






/*
 * name:      pushAtFront
 * purpose:   push the provided character into the front of the CharLinkedList
 * arguments: a character to add to the front of the list
 * returns:   none
 * effects:   increases num elements of CharLinkedList by 1,
 *            adds element to list
 */
void CharLinkedList::pushAtFront(char inputChar) {
    // Create new Node and store input info in it
    Node *newNode = new Node;
    newNode->info = (inputChar);

    // Account for adding to empty list
    if (numElements == 0) {
        // Set Node before newNode to nullptr (stored in front), 
        // and set back to newNode
        newNode->previous = front;
        back = newNode;
    } else {
        // Set node before newNode to node before old front (which is nullptr), 
        // and set node before old front to newNode
        newNode->previous = front->previous;
        front->previous = newNode;
    }

    // Set node after newNode to old front and set front to newNode
    newNode->next = front;
    front = newNode;
    
    numElements++;
}

/*
 * name:      pushAtBack
 * purpose:   push the provided character into the back of the CharLinkedList
 * arguments: a character to add to the back of the list
 * returns:   none
 * effects:   increases num elements of CharLinkedList by 1,
 *            adds element to list
 */
void CharLinkedList::pushAtBack(char inputChar) {
    // Create new Node and store input info in it
    Node *newNode = new Node;
    newNode->info = (inputChar);
    
    // Account for adding to empty list
    if (numElements == 0) {
        // Set Node after newNode to nullptr (stored in back), 
        // and set front to newNode
        newNode->next = back;
        front = newNode;
    } else {
        // Set node after newNode to node after old back (which is nullptr), 
        // and set node after old back to newNode
        newNode->next = back->next;
        back->next = newNode;
    }

    // Set node before newNode to old back and set back to newNode
    newNode->previous = back;
    back = newNode;
    
    numElements++;

}

/*
 * name:      insertAt
 * purpose:   push the provided character into the CharLinkedList at the
 *            specified index.
 * arguments: a character to add to the list, and an integer index to add it at
 * returns:   none
 * effects:   increases num elements of CharLinkedList by 1,
 *            adds element to list, throws error if specified index is outside
 *            of range of list
 */
void CharLinkedList::insertAt(char c, int index) {
    // Use if-else to check for out of range index provided, and for cases of 
    // adding at front or back of list
    if (index > 0 and index < numElements) {
        // Create pointers to nodes
        Node *insertAtNode;
        Node *newNode = new Node;

        // Fetch pointer to node we want to insert at
        insertAtNode = nodeAt(index);

        // update information in new node
        newNode->info = c;
        newNode->previous = insertAtNode->previous;
        newNode->next = insertAtNode;

        // update information of nodes around insertion 
        insertAtNode->previous->next = newNode;
        insertAtNode->previous = newNode;

        numElements++;
    } else if (index == 0) {
        pushAtFront(c);
    } else if (index == numElements) {
        pushAtBack(c);
    } else {
        throw std::range_error("index (" + std::to_string(index) 
        + ") not in range [0.." + std::to_string(numElements) + "]");
    }
}

/*
 * name:      insertInOrder
 * purpose:   push the provided character into the CharLinkedList in ascii order
 * arguments: a character to add to the list
 * returns:   none
 * effects:   increases num elements of CharLinkedList by 1,
 *            adds element to list
 */
void CharLinkedList::insertInOrder(char c) {
    Node *currentNode = front;

    // loop until first element which is greater than input (or final element)
    while ((currentNode != back) and (c > currentNode->info))
        currentNode = currentNode->next;

    // Account for cases of adding to empty or 1-element list
    if (numElements == 0) {
        pushAtFront(c);
    } else if ((currentNode == front) and (c < currentNode->info)) {
        pushAtFront(c);
    } else if ((currentNode == back) and (c > currentNode->info)) {
        pushAtBack(c);
    } else {
        Node *newNode = new Node;

        // update information in new node
        newNode->info = c;
        newNode->previous = currentNode->previous;
        newNode->next = currentNode;

        // update information of nodes around insertion
        currentNode->previous->next = newNode;
        currentNode->previous = newNode;

        numElements++;
    }
}

/*
 * name:      clear
 * purpose:   empties list, so it can be filled with new characters
 * arguments: none
 * returns:   none
 * effects:   sets num elements to 0.
 */
void CharLinkedList::clear() {
    // delete all nodes on heap, set counter to 0, and reset front/back pointers
    deleteNodes();
    numElements = 0;
    front = nullptr;
    back = nullptr;
}

/*
 * name:      popFromFront
 * purpose:   pop the provided character off the front of the list
 * arguments: none
 * returns:   none
 * effects:   decreases num elements of CharLinkedList by 1,
 *            removes element from list
 */
void CharLinkedList::popFromFront() {
    if (numElements == 0) {
        throw std::runtime_error("cannot pop from empty LinkedList");
    } else if (numElements == 1) {
        // If 1 element list delete node at front and reset front and back
        // pointers
        delete front;
        front = nullptr;
        back = nullptr;
        numElements--;
    } else {
        // Set new front of array, delete old node at front, set the Node 
        // "before" the front Node to nullptr, signifying the end of the list
        front = front->next;
        delete front->previous;
        front->previous = nullptr;
        numElements--;
    }
}

/*
 * name:      popFromBack
 * purpose:   pop the provided character off the back of the list
 * arguments: none
 * returns:   none
 * effects:   decreases num elements of CharLinkedList by 1,
 *            removes element from list
 */
void CharLinkedList::popFromBack() {
    if (numElements == 0) {
        throw std::runtime_error("cannot pop from empty LinkedList");
    } else if (numElements == 1) {
        // If 1 element list delete node at back and reset front and back
        // pointers
        delete back;
        front = nullptr;
        back = nullptr;
        numElements--;
    } else {
        // Set new back of array, delete old node at back, set the Node 
        // "after" the back Node to nullptr, signifying the end of the list
        back = back->previous;
        delete back->next;
        back->next = nullptr;
        numElements--;
    }
}

/*
 * name:      removeAt
 * purpose:   pop the provided character off of the list at the specified index
 * arguments: integer index to remove element at
 * returns:   none
 * effects:   decreases num elements of CharLinkedList by 1,
 *            removes element from list
 */
void CharLinkedList::removeAt(int index) {
    // Use if-else to check for out of range index provided, and for cases of 
    // adding at front or back of list
    if (index < 0 or index >= numElements) {
        throw std::range_error("index (" + std::to_string(index) 
        + ") not in range [0.." + std::to_string(numElements) + ")");
    } else if (index == 0) {
        popFromFront();
    } else if (index == numElements - 1) {
        popFromBack();
    } else {
        // Find node and update nodes next to point of removal
        Node *removeAtNode = nodeAt(index);
        removeAtNode->previous->next = removeAtNode->next;
        removeAtNode->next->previous = removeAtNode->previous;
        
        // delete node on heap
        delete removeAtNode;
        
        numElements--;
    }
}

/*
 * name:      replaceAt
 * purpose:   replace the character at the specified index with the provided
 *            chararcter
 * arguments: character to element replace with, 
 *            integer index to replace element at
 * returns:   none
 * effects:   changes single element in list
 */
void CharLinkedList::replaceAt(char c, int index) {
    // Use if-else to check for out of range index provided
    if (index < 0 or index >= numElements) {
        throw std::range_error("index (" + std::to_string(index) 
        + ") not in range [0.." + std::to_string(numElements) + ")");
    } else {
        // find node and set information at node to input
        Node *replaceAtNode = nodeAt(index);
        replaceAtNode->info = c;
    }
}

/*
 * name:      concatenate
 * purpose:   add one onto the end of another list
 * arguments: a list to add to the end of this list
 * returns:   none
 * effects:   list now has new elements of other list added one
 */
void CharLinkedList::concatenate(CharLinkedList *other) {
    // Copies nodes from other list into this list, effectively concatenating
    copyNodes(other->front, other->numElements);
}

/*
 * name:      deleteNodes
 * purpose:   deletes all elements in a list
 * arguments: none
 * returns:   none
 * effects:   memory freed, and no nodes in list
 */
void CharLinkedList::deleteNodes() {
    // Base case, returns once reached end of list
    if (front == nullptr) {
        return;

    // Recursive case
    } else {
        // delete front, set what used to be second element to front, then call
        // function again
        Node *nextNode = front->next;
        delete front;
        front = nextNode;
        deleteNodes();
    }
}

/*
 * name:      findNodeFromFront
 * purpose:   find the node at specified index, starting at front of list
 * arguments: integer index, Node pointer position, integer position
 * returns:   CharLinkedList::Node
 * effects:   returns a Node
 */
CharLinkedList::Node *CharLinkedList::findNodeFromFront(int index, 
Node *currentNode, int currentPos) const {
    // Base case where we have reached desired node
    if (index == currentPos)
        return currentNode;
    // Recursive case, call function again with next node in list (and increment
    // the currentPos counter)
    else 
        return findNodeFromFront(index, currentNode->next, currentPos + 1);
}

/*
 * name:      findNodeFromBack
 * purpose:   find the node at specified index, starting at back of list
 * arguments: integer index, Node pointer position, integer position
 * returns:   CharLinkedList::Node
 * effects:   returns a Node
 */
CharLinkedList::Node *CharLinkedList::findNodeFromBack(int index, 
Node *currentNode, int currentPos) const {
    // Base case where we have reached desired node
    if (index == currentPos)
        return currentNode;
    // Recursive case, call function again with previous node in list (and 
    // increment the currentPos counter (by -1))
    else 
        return findNodeFromBack(index, currentNode->previous, currentPos - 1);
}

/*
 * name:      nodeAt
 * purpose:   find the node at specified index, calls either findNodeFromFront
 *            or findNodeFromBack depending on index input
 * arguments: integer index
 * returns:   CharLinkedList::Node
 * effects:   returns a Node
 */
CharLinkedList::Node *CharLinkedList::nodeAt(int index) const {
    int middleNode = numElements / 2;
    Node *currentNode;

    // decide whether to start from front or back, then call functions to
    // actually get the node
    if (index > middleNode) {
        currentNode = findNodeFromBack(index, back, numElements - 1);
    } else if (index <= middleNode) {
        currentNode = findNodeFromFront(index, front, 0);
    }

    return currentNode;
}



/*
 * name:      copyNodes
 * purpose:   copies Nodes at and after one input Node to the end of this list
 * arguments: Node to start copying from, number of nodes to copy
 * returns:   none
 * effects:   copies Nodes onto the end of list
 */
void CharLinkedList::copyNodes(Node *copyFrom, int copyUntil) {
    // loop the number of times specified, getting the char info at each node we
    // are copying from and using it to call pushAtBack on list we are copyiny
    // to
    for (int i = 0; i < copyUntil; i++) {
        pushAtBack(copyFrom->info);
        copyFrom = copyFrom->next;
    }
}
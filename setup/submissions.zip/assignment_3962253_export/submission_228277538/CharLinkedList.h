/*
 *  CharLinkedList.h
 *  Cole Morrel (cmorre02)
 *  2/3/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 * The CharLinkedList class implements a ADT that can store a list of 
 * characters, such that the elements of the list can easily be added (using 
 * pushAtFront, pushAtBack, insertAt, insertInOrder), removed (using 
 * popFromFront, popFromBack, clear, removeAt), and replaced (using replaceAt). 
 * A CharLinkedList object can be created with a number of different paremeters,
 * such as an empty list (no parameters), a single character list (character 
 * input), a list of any length (array and integer size input), and a copy of an
 * existing list (CharLinkedList input). A CharLinkedList object can also be set
 * equal to another CharLinkedList object using the assignment operator. The 
 * list can be returned as a string, in both forward (using toString) and 
 * reverse (using toReverseString) order, and information on individual elements
 * in the list (first, last, elementAt), as well as the size of the list (size, 
 * empty), are available as well. One final function that the class has is the 
 * ability to concatenate two lists together using the concatenate function. 
 * This list allows elements to be accessed, added, and removed quickly, at the 
 * front and back of the list, but is slow at performing these operations in the
 * middle of the list.
 *
 */

#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H

#include <string>

class CharLinkedList {
public:

    // Constructors for CharLinkedList
    CharLinkedList();
    CharLinkedList(char c);
    CharLinkedList(char arr[], int size);
    CharLinkedList(const CharLinkedList &other);

    // Destructor for CharLinkedList
    ~CharLinkedList();

    // Copy assignment operator for CharLinkedList
    CharLinkedList &operator=(const CharLinkedList &other);

    // Methods used to fetch information about CharLinkedList
    bool isEmpty() const;
    int size() const;
    char first() const;
    char last() const;
    char elementAt(int index) const;
    std::string toString() const;
    std::string toReverseString() const;

    // Methods used to add to CharLinkedList
    void pushAtBack(char c);
    void pushAtFront(char c);
    void insertAt(char c, int index);
    void insertInOrder(char c);
    
    // Methods used to remove from CharLinkedList
    void clear();
    void popFromFront();
    void popFromBack();
    void removeAt(int index);

    // Other Methods used to modify CharLinkedList
    void replaceAt(char c, int index);
    void concatenate(CharLinkedList *other);


private:
    
    // Node representing each element in the list
    struct Node {
        char info;
        Node *next;
        Node *previous;
    };

    // Data on front and back of list, as well as number of elements in list
    Node *back;
    Node *front;
    int numElements;

    // Helper functions, used to more easily modify or fetch information about
    // the list
    void deleteNodes();
    Node *findNodeFromFront(int index, Node *currentNode, int currentPos) const;
    Node *findNodeFromBack(int index, Node *currentNode, int currentPos) const;
    Node *nodeAt(int index) const;
    void copyNodes(Node *copyFrom, int copyUntil);

};

#endif

/*
 *  unit_tests.h
 *  Cole Morrel (cmorre02)
 *  2/3/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  This file contains an the unit_tests of the CharLinkedList class.
 *
 */
#include "CharLinkedList.h"
#include <cassert>


//=========================== Empty Constructor Tests ==========================

// Tests that standard constructor works properly.
// This test was done before other getters were first implemented, so uses
// normally private data fields (and therefore needs to be commented out).
// void emptyConstructor_usage() {
//     CharLinkedList test_list;

//     assert(test_list.size() == 0);
//     assert(test_list.front == nullptr);
//     assert(test_list.back == nullptr);
// }

//=========================== pushAtFront Tests ================================

// Tests that pushAtfront works properly
// void pushAtFront_empty() {
//     CharLinkedList test_list;

//     test_list.pushAtFront('a');

//     assert(test_list.size() == 1);
//     assert(test_list.front == test_list.back);
//     assert(test_list.front->info == 'a');
// }

// Tests that pushAtFront works for single element list
// void pushAtFront_singleton() {
//     CharLinkedList test_list;

//     test_list.pushAtFront('a');

//     assert(test_list.size() == 1);

//     test_list.pushAtFront('b');

//     assert(test_list.size() == 2);
//     assert(test_list.front->info == 'b');
//     assert(test_list.front->next == test_list.back);
//     assert(test_list.back->info == 'a');
// }

//=========================== findNodeFromFront Tests ==========================

// Since out of bounds conditions vary dependent functions, we will assume that
// this function is called only for in bounds indices

// Tests that nodeAt works properly for single item list
// void findNodeFromFront_singleton() {
//     CharLinkedList test_list;
//     test_list.pushAtFront('a');

//     assert(test_list.findNodeFromFront(0, test_list.front, 0)->info == 'a');
// }

// Tests that nodeAt works properly for an the first element of a multi
// element list
// void findNodeFromFront_long_list_first() {
//     CharLinkedList test_list;
//     test_list.pushAtFront('a');
//     test_list.pushAtFront('b');
//     test_list.pushAtFront('c');
//     test_list.pushAtFront('d');
//     test_list.pushAtFront('e');

//     assert(test_list.findNodeFromFront(0, test_list.front, 0)->info == 'e');
// }

// Tests that nodeAt works properly for an index in a multi
// element list
// void findNodeFromFront_long_list_not_first() {
//     CharLinkedList test_list;
//     test_list.pushAtFront('a');
//     test_list.pushAtFront('b');
//     test_list.pushAtFront('c');
//     test_list.pushAtFront('d');
//     test_list.pushAtFront('e');

//     assert(test_list.findNodeFromFront(2, test_list.front, 0)->info == 'c');
// }

//=========================== findNodeFromBack Tests ==========================

// Tests that nodeAt works properly for single item list
// void findNodeFromBack_singleton() {
//     CharLinkedList test_list;
//     test_list.pushAtFront('a');

//     assert(test_list.findNodeFromBack(0, test_list.back, 0)->info == 'a');
// }

// Tests that nodeAt works properly for the last element of a multi
// element list
// void findNodeFromBack_long_list_last() {
//     CharLinkedList test_list;
//     test_list.pushAtFront('a');
//     test_list.pushAtFront('b');
//     test_list.pushAtFront('c');
//     test_list.pushAtFront('d');
//     test_list.pushAtFront('e');


//     assert(test_list.findNodeFromBack(4, test_list.back, 4)->info == 'a');
// }

// Tests that nodeAt works properly for an index in f a multi
// element list
// void findNodeFromBack_long_list_not_last() {
//     CharLinkedList test_list;
//     test_list.pushAtFront('a');
//     test_list.pushAtFront('b');
//     test_list.pushAtFront('c');
//     test_list.pushAtFront('d');
//     test_list.pushAtFront('e');


//     assert(test_list.findNodeFromBack(3, test_list.back, 4)->info == 'b');
// }



//=========================== nodeAt Tests =====================================


// Since out of bounds conditions vary dependent functions, we will assume that
// this function is called only for in bounds indices

// Tests that nodeAt works properly for single item list
// void nodeAt_singleton() {
//     CharLinkedList test_list;
//     test_list.pushAtFront('a');

//     assert(test_list.nodeAt(0)->info == 'a');
// }

// Tests that nodeAt works properly for the first element a multi
// element list
// void nodeAt_long_list_first() {
//     CharLinkedList test_list;
//     test_list.pushAtFront('a');
//     test_list.pushAtFront('b');
//     test_list.pushAtFront('c');
//     test_list.pushAtFront('d');
//     test_list.pushAtFront('e');

//     assert(test_list.nodeAt(0)->info == 'e');
// }

// Tests that nodeAt works properly for an index in the first half of a multi
// element list
// void nodeAt_long_list_first_half() {
//     CharLinkedList test_list;
//     test_list.pushAtFront('a');
//     test_list.pushAtFront('b');
//     test_list.pushAtFront('c');
//     test_list.pushAtFront('d');
//     test_list.pushAtFront('e');

//     assert(test_list.nodeAt(1)->info == 'd');
// }

// Tests that nodeAt works properly for an index in the middle of a multi
// element list
// void nodeAt_long_list_middle() {
//     CharLinkedList test_list;
//     test_list.pushAtFront('a');
//     test_list.pushAtFront('b');
//     test_list.pushAtFront('c');
//     test_list.pushAtFront('d');
//     test_list.pushAtFront('e');

//     assert(test_list.nodeAt(2)->info == 'c');
// }

// Tests that nodeAt works properly for an index in the second half of a multi
// element list
// void nodeAt_long_list_second_half() {
//     CharLinkedList test_list;
//     test_list.pushAtFront('a');
//     test_list.pushAtFront('b');
//     test_list.pushAtFront('c');
//     test_list.pushAtFront('d');
//     test_list.pushAtFront('e');


//     assert(test_list.nodeAt(3)->info == 'b');
// }

// Tests that nodeAt works properly for the last element in a multi
// element list
// void nodeAt_long_list_last() {
//     CharLinkedList test_list;
//     test_list.pushAtFront('a');
//     test_list.pushAtFront('b');
//     test_list.pushAtFront('c');
//     test_list.pushAtFront('d');
//     test_list.pushAtFront('e');


//     assert(test_list.nodeAt(4)->info == 'a');

// }

//=========================== elementAt Tests ==================================

// Tests that elementAt throws error when called on empty list (since no indices
// in bounds)
void elementAt_empty_incorrect() {
    // Create list and variables to track error information
    bool range_error_thrown = false;
    std::string error_message = "";
    CharLinkedList test_list;

    // Try to call function for out of range index, if it is correctly 
    // implemented, a range_error will be thrown
    try {
        test_list.elementAt(0);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    // Assert that error was thrown
    assert(range_error_thrown);
    assert(error_message == "index (0) not in range [0..0)");
}

// Tests that elementAt throws error when called on multi element list at out
// of bound index
void elementAt_long_list_incorrect() {
    // Create list and variables to track error information
    bool range_error_thrown = false;
    std::string error_message = "";
    CharLinkedList test_list;
    test_list.pushAtFront('a');
    test_list.pushAtFront('b');
    test_list.pushAtFront('c');
    test_list.pushAtFront('d');
    test_list.pushAtFront('e');

    // Try to call function for out of range index, if it is correctly 
    // implemented, a range_error will be thrown
    try {
        test_list.elementAt(10);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    // Assert that error was thrown
    assert(range_error_thrown);
    assert(error_message == "index (10) not in range [0..5)");
}

// Tests that elementAt works properly for single item list
void elementAt_singleton() {
    CharLinkedList test_list;
    test_list.pushAtFront('a');

    assert(test_list.elementAt(0) == 'a');
}

// Tests that elementAt works properly for the first itme in a multi
// element list
void elementAt_long_list_first() {
    CharLinkedList test_list;
    test_list.pushAtFront('a');
    test_list.pushAtFront('b');
    test_list.pushAtFront('c');
    test_list.pushAtFront('d');
    test_list.pushAtFront('e');

    assert(test_list.elementAt(0) == 'e');
}

// Tests that elementAt works properly for an index in the first half of a multi
// element list
void elementAt_long_list_first_half() {
    CharLinkedList test_list;
    test_list.pushAtFront('a');
    test_list.pushAtFront('b');
    test_list.pushAtFront('c');
    test_list.pushAtFront('d');
    test_list.pushAtFront('e');

    assert(test_list.elementAt(1) == 'd');
}

// Tests that elementAt works properly for an index in the middle of a multi
// element list
void elementAt_long_list_middle() {
    CharLinkedList test_list;
    test_list.pushAtFront('a');
    test_list.pushAtFront('b');
    test_list.pushAtFront('c');
    test_list.pushAtFront('d');
    test_list.pushAtFront('e');

    assert(test_list.elementAt(2) == 'c');
}

// Tests that elementAt works properly for an index in the second half of a 
// multi element list
void elementAt_long_list_second_half() {
    CharLinkedList test_list;
    test_list.pushAtFront('a');
    test_list.pushAtFront('b');
    test_list.pushAtFront('c');
    test_list.pushAtFront('d');
    test_list.pushAtFront('e');


    assert(test_list.elementAt(3) == 'b');
}

// Tests that elementAt works properly for the last element in a multi
// element list
void elementAt_long_list_last() {
    CharLinkedList test_list;
    test_list.pushAtFront('a');
    test_list.pushAtFront('b');
    test_list.pushAtFront('c');
    test_list.pushAtFront('d');
    test_list.pushAtFront('e');


    assert(test_list.elementAt(4) == 'a');

}

//=========================== Single Character Constructor Tests ===============

// Tests that the CharLinkedList was successfully created for a valid character
// input
void singleCharacterConstructor_usage() {
    CharLinkedList test_list('a');
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');
}

//=========================== Array and Int Input Constructor Tests ============

// Tests that CharLinkedList was successfully created for a valid char array and
// integer input that are equal in size and greater than 0
void arrayAndIntConstructor_usage_non_empty() {
    char inputArray[4]{'a', 'b', 'c', 'd'};
    CharLinkedList test_list(inputArray, 4);
    assert(test_list.size() == 4);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    assert(test_list.elementAt(2) == 'c');
    assert(test_list.elementAt(3) == 'd');
}

// Tests that CharLinkedList was successfully created for a valid char array and
// integer input that are equal in size and both 0
// SHOULD BE COMMENTED OUT AS ACCESSES PRIVATE DATA FIELDS
// void arrayAndIntConstructor_usage_empty() {
//     char inputArray[0];
//     CharLinkedList test_list(inputArray, 0);
//     assert(test_list.size() == 0);
//     assert(test_list.front == nullptr);
//     assert(test_list.back == nullptr);
// }

//=========================== toString Tests ===================================

// Test that toString correctly outputs string when CharLinkedList is empty
void toString_empty() {
    CharLinkedList test_list;

    // Get output of toString and check it matches message for empty 
    // CharLinkedList
    std::string outputString = test_list.toString();
    assert(test_list.size() == 0);
    assert(outputString == "[CharLinkedList of size 0 <<>>]");
}

// Test that toString correctly outputs string when CharLinkedList is not empty
void toString_not_empty() {
    // Create CharLinkedList to test
    char test_arr[5] = {'a', 'b', 'd', 'q', 'a'};
    CharLinkedList test_list(test_arr, 5);

    // Get output of toString and check it matches message for provided list
    std::string outputString = test_list.toString();
    assert(test_list.size() == 5);
    assert(outputString == "[CharLinkedList of size 5 <<abdqa>>]");

}

//=========================== insertAt Tests ===================================

// Tests correct insertion into an empty LL.
// Afterwards, size should be 1 and element at index 0
// should be the element we inserted.
void insertAt_empty_correct() { 

    CharLinkedList test_list;
    test_list.insertAt('a', 0);
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');

}

// Tests incorrect insertion into an empty LL.
// Attempts to call insertAt for index larger than 0.
// This should result in an std::range_error being raised.
void insertAt_empty_incorrect() {

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    // insertAt for out-of-range index
    test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
    // if insertAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    range_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0]");
    
}

// Tests correct insertAt for front of 1-element list.
void insertAt_front_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at front
    test_list.insertAt('b', 0);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'a');
    
}

// Tests correct insertAt for back of 1-element list.
void insertAt_back_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at back
    test_list.insertAt('b', 1);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    
}

// Tests calling insertAt for a large number of elements.
void insertAt_many_elements() {
    
    CharLinkedList test_list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.insertAt('a', i);
    }

    assert(test_list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
    
}

// Tests insertion into front of a larger list
void insertAt_front_large_list() {
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    test_list.insertAt('y', 0);

    assert(test_list.size() == 10);
    assert(test_list.elementAt(0) == 'y');
    assert(test_list.toString() == 
    "[CharLinkedList of size 10 <<yabczdefgh>>]");
    assert(test_list.toReverseString() == 
    "[CharLinkedList of size 10 <<hgfedzcbay>>]");

}

// Tests insertion into the back of a larger list
void insertAt_back_large_list() {

    char test_arr[10] = { 'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 10);  

    test_list.insertAt('x', 10);

    assert(test_list.size() == 11);
    assert(test_list.elementAt(10) == 'x');
    assert(test_list.toString() == 
    "[CharLinkedList of size 11 <<yabczdefghx>>]"); 
    assert(test_list.toReverseString() == 
    "[CharLinkedList of size 11 <<xhgfedzcbay>>]"); 

}

// Tests insertion into the middle of a larger list
void insertAt_middle_large_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.insertAt('z', 3);

    assert(test_list.size() == 9);
    assert(test_list.elementAt(3) == 'z');
    assert(test_list.toString() == "[CharLinkedList of size 9 <<abczdefgh>>]");
    assert(test_list.toReverseString() == 
    "[CharLinkedList of size 9 <<hgfedzcba>>]");

}

// Tests out-of-range insertion for a non-empty list.
void insertAt_nonempty_incorrect() {
   
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8]");
    
}

//=========================== pushAtBack Tests =================================

// Tests that pushAtBack works properly
// void pushAtBack_empty() {
//     CharLinkedList test_list;

//     test_list.pushAtBack('a');

//     assert(test_list.size() == 1);
//     assert(test_list.front == test_list.back);
//     assert(test_list.front->info == 'a');
// }

// Tests that pushAtBack works for single element list
// void pushAtBack_singleton() {
//     CharLinkedList test_list;

//     test_list.pushAtBack('a');

//     assert(test_list.size() == 1);

//     test_list.pushAtBack('b');

//     assert(test_list.size() == 2);
//     assert(test_list.front->info == 'a');
//     assert(test_list.front->next == test_list.back);
//     assert(test_list.back->previous == test_list.front);
//     assert(test_list.back->info == 'b');
// }

//=========================== isEmpty Tests ====================================

// Tests that isEmpty is correctly returning true when a CharLinkedList
// contains no items (this test only works when numItems is made public, and 
// therefore this test should normally be commented out).
// void isEmpty_true() {
//     CharLinkedList test_list;
//     assert(test_list.numElements == 0);
//     assert(test_list.front == nullptr);
//     assert(test_list.back == nullptr);
//     assert(test_list.isEmpty());
// }

// Tests that isEmpty is correctly returning false when a CharLinkedList
// contains items (this test only works when numItems is made public, and 
// therefore this test should normally be commented out).
// void isEmpty_false() {
//     CharLinkedList test_list('a');
//     assert(test_list.numElements != 0);
//     assert(!test_list.isEmpty());
// }

//=========================== first Tests ======================================

// Tests that for a non-empty CharLinkedList the first function successfully
// returns the first item in the list.
void first_correct() {
    // Create CharLinkedList to test
    char test_arr[2] = {'a', 'b'};
    CharLinkedList test_list(test_arr, 2);

    // Check that first item in array matches what is returned by first
    assert(test_list.first() == test_list.elementAt(0));
    
}

// Tests that first correctly throws a runtime_error when the CharLinkedList is
// empty.
void first_incorrect() {
    // var to track whether runtime_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    // first for empty array
    test_list.first();
    }
    catch (const std::runtime_error &e) {
    // if first is correctly implemented, a runtime_error will be thrown,
    // and we will end up here
    runtime_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(runtime_error_thrown);
    assert(error_message == "cannot get first of empty LinkedList");   
}

//=========================== last Tests =======================================

// Tests that for a non-empty CharLinkedList the last function successfully
// returns the last item in the list.
void last_correct() {
    // Create CharLinkedList to test
    char test_arr[2] = {'a', 'b'};
    CharLinkedList test_list(test_arr, 2);

    // Check that last item in array matches what is returned by last
    assert(test_list.last() == test_list.elementAt(1));
    
}

// Tests that last correctly throws a runtime_error when the CharLinkedList is
// empty.
void last_incorrect() {
    // var to track whether runtime_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    // last for empty array
    test_list.last();
    }
    catch (const std::runtime_error &e) {
    // if last is correctly implemented, a runtime_error will be thrown,
    // and we will end up here
    runtime_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(runtime_error_thrown);
    assert(error_message == "cannot get last of empty LinkedList");   
}

//=========================== toReverseString Tests ============================

// Test that toReverseString correctly outputs string when CharLinkedList is 
// empty
void toReverseString_empty() {
    CharLinkedList test_list;

    // Get output of toReverseString and check it matches message for empty 
    // CharLinkedList
    std::string outputString = test_list.toReverseString();
    assert(test_list.isEmpty());
    assert(outputString == "[CharLinkedList of size 0 <<>>]");
}

// Test that toReverseString correctly outputs string when CharLinkedList is not
// empty
void toReverseString_not_empty() {
    // Create CharLinkedList to test
    char test_arr[5] = {'a', 'b', 'd', 'q', 'a'};
    CharLinkedList test_list(test_arr, 5);

        // Get output of toReverseString and check it matches message for 
        // provided list
    std::string outputString = test_list.toReverseString();
    assert(test_list.size() == 5);
    assert(outputString == "[CharLinkedList of size 5 <<aqdba>>]");

}

//=========================== popFromFront Tests ===============================

// Test that popFromFront successfully throws error when it is used on an empty
// list
void popFromFront_incorrect() {
    // var to track whether runtime_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    // popFromFront for empty list
    test_list.popFromFront();
    }
    catch (const std::runtime_error &e) {
    // if popFromFront is correctly implemented, a runtime_error will be thrown,
    // and we will end up here
    runtime_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");   
}

// Test that popFromFront successfully pops element off single element list
void popFromFront_singleton_list() {
    // Create list
    CharLinkedList test_list('a');
    assert(test_list.size() == 1);
    
    // Pop (only) item off list and check list is empty
    test_list.popFromFront();
    assert(test_list.isEmpty());
}

// Test that popFromFront successfully pops single element off multi element 
// list
void popFromFront_large_list() {
    // Create list
    char test_arr[7] = {'a', 'd', 'i', 'j', 's', 'w', 'x'};
    CharLinkedList test_list(test_arr, 7);
    
    // Pop item off front and check list has changed accordingly
    test_list.popFromFront();
    assert(test_list.size() == 6);
    assert(test_list.elementAt(0) == 'd');
    assert(test_list.toString() == "[CharLinkedList of size 6 <<dijswx>>]");
    assert(test_list.toReverseString() == 
    "[CharLinkedList of size 6 <<xwsjid>>]");
}

// Tests that popFromFront successfully pops all elements off multi element list
void popFromFront_large_list_until_empty() {
    // Create list
    char test_arr[7] = {'a', 'd', 'i', 'j', 's', 'w', 'x'};
    CharLinkedList test_list(test_arr, 7);
    
    // Use loop to pop every off front of list, and check list is empty
    for (int i = 0; i < 7; i++)
        test_list.popFromFront();
    assert(test_list.isEmpty());
    assert(test_list.toString() == "[CharLinkedList of size 0 <<>>]");
}

//=========================== popFromBack Tests ================================

// Test that popFromBack successfully throws error when it is used on an empty
// list
void popFromBack_incorrect() {
    // var to track whether runtime_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    // popFromBack for empty list
    test_list.popFromBack();
    }
    catch (const std::runtime_error &e) {
    // if popFromBack is correctly implemented, a runtime_error will be thrown,
    // and we will end up here
    runtime_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");   
}

// Test that popFromBack successfully pops element off single element list
void popFromBack_singleton_list() {
    // Create list
    CharLinkedList test_list('a');
    assert(test_list.size() == 1);
    
    // Pop (only) item off list and check list is empty   
    test_list.popFromBack();
    assert(test_list.isEmpty());
}

// Test that popFromBack successfully pops single element off multi element 
// list
void popFromBack_large_list() {
    // Create list
    char test_arr[7] = {'a', 'd', 'i', 'j', 's', 'w', 'x'};
    CharLinkedList test_list(test_arr, 7);
    
    // Pop item off back and check list has changed accordingly
    test_list.popFromBack();
    assert(test_list.size() == 6);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.toString() == "[CharLinkedList of size 6 <<adijsw>>]");
    assert(test_list.toReverseString() == 
    "[CharLinkedList of size 6 <<wsjida>>]");
}

// Test that popFromBack successfully pops all elements off multi element list
void popFromBack_large_list_until_empty() {
    // Create list
    char test_arr[7] = {'a', 'd', 'i', 'j', 's', 'w', 'x'};
    CharLinkedList test_list(test_arr, 7);
    
    // Use loop to pop every off back of list, and check list is empty
    for (int i = 0; i < 7; i++)
        test_list.popFromBack();
    assert(test_list.isEmpty());
    assert(test_list.toString() == "[CharLinkedList of size 0 <<>>]");
}

//=========================== removeAt Tests ===================================

// Tests incorrect ussage of removeAt by calling index 0 on an empty list.
// This should result in an std::range_error being raised.
void removeAt_empty_incorrect() {

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    // removeAt for out-of-range index
    test_list.removeAt(0);
    }
    catch (const std::range_error &e) {
    // if removeAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    range_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (0) not in range [0..0)");
    
}

// Tests correct removeAt for a 1 element list.
void removeAt_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // remove from front, and check list is empty
    test_list.removeAt(0);
    assert(test_list.isEmpty());
    assert(test_list.isEmpty());
    
}


// Tests calling removeAt consecutively until list is empty
void removeAt_large_list_until_empty() {
    // Create list
    char test_arr[7] = {'a', 'd', 'i', 'j', 's', 'w', 'x'};
    CharLinkedList test_list(test_arr, 7);
    
    // Use for loop to remove all elements in list
    for (int i = 0; i < 7; i++)
        test_list.removeAt(0);
    
    // Check list is empty
    assert(test_list.isEmpty());
    assert(test_list.toString() == "[CharLinkedList of size 0 <<>>]");
}

// Tests removeAt used in the front of a larger list
void removeAt_front_large_list() {
    // Create list
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    // Remove the first element and check list updated accordingly
    test_list.removeAt(0);
    assert(test_list.size() == 8);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.toString() == "[CharLinkedList of size 8 <<bczdefgh>>]");
    assert(test_list.toReverseString() == 
    "[CharLinkedList of size 8 <<hgfedzcb>>]");

}

// Tests removeAt used in the back of a larger list
void removeAt_back_large_list() {
    // Create list
    char test_arr[10] = { 'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 10);  

    // Remove the last element and check list updated accordingly
    test_list.removeAt(9);
    assert(test_list.size() == 9);
    assert(test_list.elementAt(8) == 'g');
    assert(test_list.toString() == "[CharLinkedList of size 9 <<yabczdefg>>]");
    assert(test_list.toReverseString() == 
    "[CharLinkedList of size 9 <<gfedzcbay>>]"); 

}

// Tests removeAt used in the middle of a larger list
void removeAt_middle_large_list() {
    // Create list
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    // Remove element in middle and check list updated accordingly
    test_list.removeAt(3);
    assert(test_list.size() == 7);
    assert(test_list.elementAt(3) == 'e');
    assert(test_list.toString() == "[CharLinkedList of size 7 <<abcefgh>>]");
    assert(test_list.toReverseString() == 
    "[CharLinkedList of size 7 <<hgfecba>>]");

}

// Tests removeAt for out-of-range index on a non-empty list.
void removeAt_nonempty_incorrect() {
   
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.removeAt(42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8)");
    
}

//=========================== clear Tests ======================================

// Tests that clear functions properly on an empty list
void clear_empty() {
    CharLinkedList test_list;
    
    test_list.clear();
    assert(test_list.isEmpty());
}

// Tests that clear functions properly on an single element list
void clear_singleton_list() {
    // Create list and confirm not empty
    CharLinkedList test_list('c');
    assert(test_list.last() == 'c');
    
    // Clear list and confirm empty
    test_list.clear();
    assert(test_list.isEmpty()); 
}

// Tests that clear functions properly on an multi element list

void clear_large_list() {
    // Create list and confirm not empty
    char test_arr[7] = {'a', 'd', 'i', 'j', 's', 'w', 'x'};
    CharLinkedList test_list(test_arr, 7);
    assert(test_list.size() == 7);

    // Clear list and confirm empty
    test_list.clear();
    assert(test_list.isEmpty()); 
}

//=========================== replaceAt Tests ==================================

// Tests incorrect ussage of replaceAt, by trying to replace at index 0 of an
// empty list. In this situation a std::range_error should be thrown
void replaceAt_empty_incorrect() {

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    // replaceAt for out-of-range index
    test_list.replaceAt('a', 0);
    }
    catch (const std::range_error &e) {
    // if replaceAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    range_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (0) not in range [0..0)");
    
}

// Tests correct ReplaceAt for a 1 element list.
void replaceAt_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // replace only element, and check replacement was successful
    test_list.replaceAt('b', 0);
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'b');
    
}



// Tests replaceAt when used on the front of a larger list
void replaceAt_front_large_list() {
    // Create list
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    // Call replaceAt for first element and check list was updated accordingly
    test_list.replaceAt('y', 0);
    assert(test_list.size() == 9);
    assert(test_list.elementAt(0) == 'y');
    assert(test_list.toString() == "[CharLinkedList of size 9 <<ybczdefgh>>]");
    assert(test_list.toReverseString() == 
    "[CharLinkedList of size 9 <<hgfedzcby>>]");

}

// Tests replaceAt when used on the back of a larger list
void replaceAt_back_large_list() {
    // Create list
    char test_arr[10] = { 'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 10);  

    // Call replaceAt for last element and check list was updated accordingly
    test_list.replaceAt('x', 9);
    assert(test_list.size() == 10);
    assert(test_list.elementAt(9) == 'x');
    assert(test_list.toString() == 
    "[CharLinkedList of size 10 <<yabczdefgx>>]");
    assert(test_list.toReverseString() == 
    "[CharLinkedList of size 10 <<xgfedzcbay>>]");

}

// Tests replaceAt when used on the middle of a larger list
void replaceAt_middle_large_list() {
    // Create list
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    // Call replaceAt for element in the middle and check list was updated 
    // accordingly
    test_list.replaceAt('z', 3);
    assert(test_list.size() == 8);
    assert(test_list.elementAt(3) == 'z');
    assert(test_list.toString() == "[CharLinkedList of size 8 <<abczefgh>>]");
    assert(test_list.toReverseString() == 
    "[CharLinkedList of size 8 <<hgfezcba>>]");

}

// Tests usage of replaceAt for out out-of-range index on a non-empty list
void replaceAt_nonempty_incorrect() {
   
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.replaceAt('a', 42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8)");
    
}

// Tests using replaceAt to replace all entries in a list.
void replaceAt_all_entries() {
    // Create list
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    // Use for loop to call replaceAt on every element in list, setting them all
    // to the same character
    for (int i = 0; i < 8; i++)
        test_list.replaceAt('z', i);

    // Check all characters in list were successfully replaced
    assert(test_list.size() == 8);
    assert(test_list.toString() == "[CharLinkedList of size 8 <<zzzzzzzz>>]");
    assert(test_list.toReverseString() == 
    "[CharLinkedList of size 8 <<zzzzzzzz>>]");
}

//=========================== copyNodes Tests ==================================

// Because this is a private helper function only called in specific ways, will
// omit some tests, such as trying to copy empty node, or copying more times
// than list can allow.

// Tests copyNodes works copying nonempty list to empty
// void copyNodes_non_empty_to_empty() {
//     // Create lists
//     char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
//     CharLinkedList test_list1(test_arr, 8);
//     CharLinkedList test_list2;

//     test_list2.copyNodes(test_list1.front, 4);

//     assert(test_list1.size() == 8);
//     assert(test_list1.toString() == 
//     "[CharLinkedList of size 8 <<abcdefgh>>]");
//     assert(test_list1.toReverseString() == 
//     "[CharLinkedList of size 8 <<hgfedcba>>]");

//     assert(test_list2.size() == 4);
//     assert(test_list2.toString() == "[CharLinkedList of size 4 <<abcd>>]");
//     assert(test_list2.toReverseString() == 
//     "[CharLinkedList of size 4 <<dcba>>]");
// }

// Tests copyNodes works copying nonempty list to nonempty
// void copyNodes_non_empty_to_non_empty() {
//     // Create lists
//     char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
//     CharLinkedList test_list1(test_arr, 8);
//     CharLinkedList test_list2('q');

//     test_list2.copyNodes(test_list1.front, 4);

//     assert(test_list1.size() == 8);
//     assert(test_list1.toString() == 
//     "[CharLinkedList of size 8 <<abcdefgh>>]");
//     assert(test_list1.toReverseString() == 
//     "[CharLinkedList of size 8 <<hgfedcba>>]");

//     assert(test_list2.size() == 5);
//     assert(test_list2.toString() == 
//     "[CharLinkedList of size 5 <<qabcd>>]");
//     assert(test_list2.toReverseString() == 
//     "[CharLinkedList of size 5 <<dcbaq>>]");
// }

// Tests copyNodes works copying nonempty list to itself
// void copyNodes_non_empty_to_itself() {
//     // Create lists
//     char test_arr[4] = { 'a', 'b', 'c', 'd'};
//     CharLinkedList test_list(test_arr, 4);

//     test_list.copyNodes(test_list.front, 3);

//     assert(test_list.size() == 7);
//     assert(test_list.toString() == "[CharLinkedList of size 7 <<abcdabc>>]");
//     assert(test_list.toReverseString() == 
//     "[CharLinkedList of size 7 <<cbadcba>>]");
// }

//=========================== Deep Copy Constructor Tests ======================

// Tests that a CharLinkedList copy was successfully created for a valid single
// element CharLinkedList input
void deepCopyConstructor_usage_singleton() {
    // Make original CharLinkedList
    CharLinkedList test_list('a');
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');

    // Test copy constructor
    CharLinkedList test_list2(test_list);
    assert(test_list2.size() == 1);
    assert(test_list2.elementAt(0) == 'a');
}

// Tests that a CharLinkedList copy was successfully created for a valid multi-
// element CharLinkedList input
void deepCopyConstructor_usage_long_list() {
    // Make original CharLinkedList
    char inputArray[4]{'a', 'b', 'c', 'd'};
    CharLinkedList test_list(inputArray, 4);
    assert(test_list.size() == 4);
    assert(test_list.toString() == "[CharLinkedList of size 4 <<abcd>>]");
    assert(test_list.toReverseString() == 
    "[CharLinkedList of size 4 <<dcba>>]");

    // Test copy constructor (recheck original list too)
    CharLinkedList test_list2(test_list);
    assert(test_list2.size() == 4);
    assert(test_list2.toString() == "[CharLinkedList of size 4 <<abcd>>]");
    assert(test_list2.toReverseString() == 
    "[CharLinkedList of size 4 <<dcba>>]");
    assert(test_list.size() == 4);
    assert(test_list.toString() == "[CharLinkedList of size 4 <<abcd>>]");
    assert(test_list.toReverseString() == 
    "[CharLinkedList of size 4 <<dcba>>]");
}

//=========================== Assignment Operator Tests ========================

// Tests that one single element list was successfully set to another single 
// element list
void assignmentOperator_set_singleton_to_singleton() {
    CharLinkedList test_list('a');
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');

    CharLinkedList test_list2('b');
    assert(test_list2.size() == 1);
    assert(test_list2.elementAt(0) == 'b');

    test_list2 = test_list;

    assert(test_list2.size() == 1);
    assert(test_list2.elementAt(0) == 'a');

}

// Tests that one single element list was successfully set to itself
void assignmentOperator_set_singleton_to_itself() {
    CharLinkedList test_list('a');
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');

    test_list = test_list;

    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');

}

// Tests that one multi element list was successfully set to an empty list
void assignmentOperator_set_long_list_to_empty() {
    CharLinkedList test_list1;
    assert(test_list1.isEmpty());
    
    char inputArray[4]{'a', 'b', 'c', 'd'};
    CharLinkedList test_list2(inputArray, 4);
    assert(test_list2.size() == 4);
    assert(test_list2.toString() == "[CharLinkedList of size 4 <<abcd>>]");

    test_list2 = test_list1;
    
    assert(test_list1.isEmpty());
    assert(test_list2.isEmpty());


}

// Tests that one empty list was successfully set to a multi element list
void assignmentOperator_set_empty_to_long_list() {
    CharLinkedList test_list1;
    assert(test_list1.isEmpty());
    
    char inputArray[4]{'a', 'b', 'c', 'd'};
    CharLinkedList test_list2(inputArray, 4);
    assert(test_list2.size() == 4);
    assert(test_list2.toString() == "[CharLinkedList of size 4 <<abcd>>]");

    test_list1 = test_list2;
    
    assert(test_list1.size() == 4);
    assert(test_list1.toString() == "[CharLinkedList of size 4 <<abcd>>]");
    assert(test_list1.toReverseString() == 
    "[CharLinkedList of size 4 <<dcba>>]");
    assert(test_list2.size() == 4);
    assert(test_list2.toString() == "[CharLinkedList of size 4 <<abcd>>]");
    assert(test_list2.toReverseString() == 
    "[CharLinkedList of size 4 <<dcba>>]");
}

//=========================== concatenate Tests ================================

// Tests using concatenate on two empty lists
void concatenate_two_empty_lists() {
    // Create lists
    CharLinkedList test_list1;
    CharLinkedList test_list2;
    
    // Concatenate lists and check that both are still empty
    test_list1.concatenate(&test_list2);
    assert(test_list1.isEmpty());
    assert(test_list2.isEmpty());

}

// Tests concatenating a single element list with an empty list
void concatenate_singleton_with_empty() {
    // Create lists
    CharLinkedList test_list1('a');
    CharLinkedList test_list2;
    
    // Concatenate single element list with empty list
    test_list1.concatenate(&test_list2);
    
    // Check that single element list is unchanged, and empty list is empty
    assert(test_list1.size() == 1);
    assert(test_list1.first() == 'a');
    assert(test_list2.isEmpty());
}

// Tests concatenating empty list with single element list
void concatenate_empty_with_singleton() {
    // Create lists
    CharLinkedList test_list1;
    CharLinkedList test_list2('a');
    
    // Concatenate empty list with single element list
    test_list1.concatenate(&test_list2);
    
    // Check that empty list is now a copy of single element list and single
    // element list is unchanged
    assert(test_list1.size() == 1);
    assert(test_list1.first() == 'a');
    assert(test_list2.size() == 1);
    assert(test_list2.first() == 'a');
}

// Tests concatenating multi element list with empty list
void concatenate_long_list_with_empty() {
    // Create lists
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list1(test_arr, 8);
    CharLinkedList test_list2;
    
    // Concatenate multi element list with empty list
    test_list1.concatenate(&test_list2);
    
    // Check that multi element list is unchanged, and empty list is empty
    assert(test_list1.size() == 8);
    assert(test_list1.toString() == "[CharLinkedList of size 8 <<abcdefgh>>]");
    assert(test_list1.toReverseString() == 
    "[CharLinkedList of size 8 <<hgfedcba>>]");
    assert(test_list2.isEmpty());
}

// Tests concatenating empty list with multi element list
void concatenate_empty_with_long_list() {
    // Create lists
    CharLinkedList test_list1;
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list2(test_arr, 8);

    // Concatenate empty list with multi element list
    test_list1.concatenate(&test_list2);
    
    // Check that empty list is now a copy of multi element list and multi
    // element list is unchanged
    assert(test_list1.size() == 8);
    assert(test_list1.toString() == "[CharLinkedList of size 8 <<abcdefgh>>]");
    assert(test_list1.toReverseString() == 
    "[CharLinkedList of size 8 <<hgfedcba>>]");
    assert(test_list2.size() == 8);
    assert(test_list2.toString() == "[CharLinkedList of size 8 <<abcdefgh>>]");
    assert(test_list2.toReverseString() == 
    "[CharLinkedList of size 8 <<hgfedcba>>]");
}

// Tests concatenating two multi element lists
void concatenate_two_long_list() {
    // Create lists
    char test_arr1[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list1(test_arr1, 8);
    char test_arr2[10] = { 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r' };
    CharLinkedList test_list2(test_arr2, 10);
    
    // Concatenate list1 with list2
    test_list1.concatenate(&test_list2);
    
    // Check that list1 has been changed to reflect concatenation and list2 is
    // still the same
    assert(test_list1.size() == 18);
    assert(test_list1.toString() 
    == "[CharLinkedList of size 18 <<abcdefghijklmnopqr>>]");
    assert(test_list2.size() == 10);
    assert(test_list2.toString() 
    == "[CharLinkedList of size 10 <<ijklmnopqr>>]");
}

// Tests concatenating a list with itself
void concatenate_list_with_itself() {
    // Create list
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list1(test_arr, 8);
    
    // Concatenate list with itself
    test_list1.concatenate(&test_list1);
    
    // Check that list is now double the size and elements have been duplicated
    assert(test_list1.size() == 16);
    assert(test_list1.toString() 
    == "[CharLinkedList of size 16 <<abcdefghabcdefgh>>]");
        assert(test_list1.toReverseString() 
    == "[CharLinkedList of size 16 <<hgfedcbahgfedcba>>]");
}

//=========================== insertInOrder Tests ==============================

// Tests that insertInOrder functions correctly for an empty CharLinkedList
void insertInOrder_empty() {
    CharLinkedList test_list;

    test_list.insertInOrder('a');
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');
    
    test_list.insertInOrder('b');
    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    
}

// Tests that insertInOrder functions correctly when large amounts of characters
// are inserted
void insertInOrder_entire_alphabet_fromA() {
    CharLinkedList test_list;

    // Insert all letters in alphabet starting at a
    for (char letter = 'a'; letter <= 'z'; letter++) {
        test_list.insertInOrder(letter);
    }

    // Verify size is correct and character's order is correct
    assert(test_list.size() == 26);
    assert(test_list.toString() 
    == "[CharLinkedList of size 26 <<abcdefghijklmnopqrstuvwxyz>>]");
    assert(test_list.toReverseString() 
    == "[CharLinkedList of size 26 <<zyxwvutsrqponmlkjihgfedcba>>]");
}

// Tests that insertInOrder functions correctly when large amounts of characters
// are inserted (in a different way than previous test)
void insertInOrder_entire_alphabet_fromZ() {
    CharLinkedList test_list;

    // Insert all letters in alphabet starting at a
    for (char letter = 'z'; letter >= 'a'; letter--) {
        test_list.insertInOrder(letter);
    }

    // Verify size is correct and character's order is correct
    assert(test_list.size() == 26);
    assert(test_list.toString() 
    == "[CharLinkedList of size 26 <<abcdefghijklmnopqrstuvwxyz>>]");
    assert(test_list.toReverseString() 
    == "[CharLinkedList of size 26 <<zyxwvutsrqponmlkjihgfedcba>>]");
}

// Tests that insertInORder functions correctly when sinlge character is
// inserted in existing list (of ordered, but non continuous chararcters)
void insertInOrder_insert_mid_list() {
    // Create ordered list
    char test_arr[7] = {'a', 'd', 'i', 'j', 's', 'w', 'x'};
    CharLinkedList test_list(test_arr, 7);

    // Insert letter in middle of list
    test_list.insertInOrder('f');

    // Confirm chararcter inserted in correct position
    assert(test_list.size() == 8);
    assert(test_list.toString() == "[CharLinkedList of size 8 <<adfijswx>>]");
    assert(test_list.toReverseString() == 
    "[CharLinkedList of size 8 <<xwsjifda>>]");
}
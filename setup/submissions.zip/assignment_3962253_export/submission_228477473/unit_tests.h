/*
 *  unit_tests.h
 *  Tassilo Armleder
 *  6/02/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  FILE PURPOSE HERE
 * 
 * linked list unit test file
 *
 */

#include "CharLinkedList.h"
#include <cassert>

void CharLinkedList_const() {
    CharLinkedList test_list;
}

void CharLinkedList_char_c_const() {
    char c = 'x';
    CharLinkedList test_list(c);
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'x');
}

void CharLinkedList_arr_const() {
    char chars[5] = {'a','b','c','d','e'};
    CharLinkedList test_list(chars, 5);
    assert(test_list.size() == 5);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    assert(test_list.elementAt(2) == 'c');
    assert(test_list.elementAt(3) == 'd');
    assert(test_list.elementAt(4) == 'e');

}

void CharLinkedList_copyobject_const() {

    char chars[5] = {'a','b','c','d','e'};
    CharLinkedList temp(chars, 5);

    CharLinkedList test_list(temp);
    
    assert(test_list.size() == 5);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    assert(test_list.elementAt(2) == 'c');
    assert(test_list.elementAt(3) == 'd');
    assert(test_list.elementAt(4) == 'e');


}

void CharLinkedList_equaloperator() {

    char chars[3] = {'a','b','c'};
    CharLinkedList test_list(chars, 3);

    char chars2[3] = {'x','y','z'};
    CharLinkedList test_list2(chars2, 3);
    
    test_list = test_list2;

    assert(test_list.size() == 3);
    assert(test_list.elementAt(0) == 'x');
    assert(test_list.elementAt(1) == 'y');
    assert(test_list.elementAt(2) == 'z');
}

void isEmpty_() {
    char chars[5] = {'a','b','c','d','e'};
    CharLinkedList temp(chars, 5);

    assert(temp.isEmpty() == false);

    CharLinkedList temp2;

    assert(temp2.isEmpty() == true);
}

void clear_() {
    
    char chars[5] = {'a','b','c','d','e'};
    CharLinkedList temp(chars, 5);

    temp.clear();

    assert(temp.isEmpty() == true);
}

void size_() {
    
    char chars[5] = {'a','b','c','d','e'};
    CharLinkedList temp(chars, 5);

    assert(temp.size() == 5);
}


void first_() {
    
    char chars[5] = {'a','b','c','d','e'};
    CharLinkedList temp(chars, 5);

    assert(temp.first() == 'a');
}


void last_() {
    
    char chars[5] = {'a','b','c','d','e'};
    CharLinkedList temp(chars, 5);

    assert(temp.last() == 'e');
}


void elementAt_() {
    
    char chars[5] = {'a','b','c','d','e'};
    CharLinkedList test_list(chars, 5);
    
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    assert(test_list.elementAt(2) == 'c');
    assert(test_list.elementAt(3) == 'd');
    assert(test_list.elementAt(4) == 'e');
}

void toString_() {
    
    char chars[5] = {'a','b','c','d','e'};
    CharLinkedList test_list(chars, 5);
    
    assert(test_list.toString() == "[CharLinkedList of size 5 <<abcde>>]");

}

void toString_empty() {
    
    CharLinkedList test_list;
    
    assert(test_list.toString() == "[CharLinkedList of size 0 <<>>]");

}


void pushAtBack_() {
    
    char chars[5] = {'a','b','c','d','e'};
    CharLinkedList test_list(chars, 5);

    test_list.pushAtBack('x');
    
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    assert(test_list.elementAt(2) == 'c');
    assert(test_list.elementAt(3) == 'd');
    assert(test_list.elementAt(4) == 'e');
    assert(test_list.elementAt(5) == 'x');

}

void pushAtBack_empty() {
    
    CharLinkedList test_list;

    test_list.pushAtBack('x');
    
    assert(test_list.elementAt(0) == 'x');

}

void pushAtFront_() {
    
    char chars[5] = {'a','b','c','d','e'};
    CharLinkedList test_list(chars, 5);

    test_list.pushAtFront('x');
    
    assert(test_list.elementAt(0) == 'x');
    assert(test_list.elementAt(1) == 'a');
    assert(test_list.elementAt(2) == 'b');
    assert(test_list.elementAt(3) == 'c');
    assert(test_list.elementAt(4) == 'd');
    assert(test_list.elementAt(5) == 'e');

}

void pushAtFront_empty() {
    
    CharLinkedList test_list;

    test_list.pushAtFront('x');
    
    assert(test_list.elementAt(0) == 'x');

}

void insertAt_() {
    
    char chars[5] = {'a','b','c','d','e'};
    CharLinkedList test_list(chars, 5);

    test_list.insertAt('z',2);
    
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    assert(test_list.elementAt(2) == 'z');
    assert(test_list.elementAt(3) == 'c');
    assert(test_list.elementAt(4) == 'd');
    assert(test_list.elementAt(5) == 'e');

}

void insertAt_font() {
    
    char chars[5] = {'a','b','c','d','e'};
    CharLinkedList test_list(chars, 5);

    test_list.insertAt('x',0);
    
    assert(test_list.elementAt(0) == 'x');
    assert(test_list.elementAt(1) == 'a');
    assert(test_list.elementAt(2) == 'b');
    assert(test_list.elementAt(3) == 'c');
    assert(test_list.elementAt(4) == 'd');
    assert(test_list.elementAt(5) == 'e');

}

void insertAt_back() {
    
    char chars[5] = {'a','b','c','d','e'};
    CharLinkedList test_list(chars, 5);

    test_list.insertAt('x', 4);
    
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    assert(test_list.elementAt(2) == 'c');
    assert(test_list.elementAt(3) == 'd');
    assert(test_list.elementAt(4) == 'x');
    assert(test_list.elementAt(5) == 'e');

}

void insertInOrder_() {

    char chars[4] = {'a','b','d','e'};
    CharLinkedList test_list(chars, 4);

    test_list.insertInOrder('c');
    
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    assert(test_list.elementAt(2) == 'c');
    assert(test_list.elementAt(3) == 'd');
    assert(test_list.elementAt(4) == 'e');

}

void insertInOrder_front() {

    char chars[4] = {'b','c','d','e'};
    CharLinkedList test_list(chars, 4);

    test_list.insertInOrder('a');
    
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    assert(test_list.elementAt(2) == 'c');
    assert(test_list.elementAt(3) == 'd');
    assert(test_list.elementAt(4) == 'e');

}

void insertInOrder_back() {

    char chars[4] = {'b','c','d','e'};
    CharLinkedList test_list(chars, 4);

    test_list.insertInOrder('f');
    
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'c');
    assert(test_list.elementAt(2) == 'd');
    assert(test_list.elementAt(3) == 'e');
    assert(test_list.elementAt(4) == 'f');

}

void popFromFront_() {

    char chars[3] = {'a','b','c'};
    CharLinkedList test_list(chars, 3);

    test_list.popFromFront();
    
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'c');
    assert(test_list.size() == 2);
}

void popFromBack_() {

    char chars[3] = {'a','b','c'};
    CharLinkedList test_list(chars, 3);

    test_list.popFromBack();
    
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    assert(test_list.size() == 2);
}


void removeAt_() {

    char chars[3] = {'a','b','c'};
    CharLinkedList test_list(chars, 3);

    test_list.removeAt(1);
    
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'c');
    assert(test_list.size() == 2);
}

void removeAt_front() {

    char chars[3] = {'a','b','c'};
    CharLinkedList test_list(chars, 3);

    test_list.removeAt(0);
    
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'c');
    assert(test_list.size() == 2);
}

void removeAt_back() {

    char chars[3] = {'a','b','c'};
    CharLinkedList test_list(chars, 3);

    test_list.removeAt(2);
    
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    assert(test_list.size() == 2);
}

void replaceAt_() {

    char chars[3] = {'a','b','c'};
    CharLinkedList test_list(chars, 3);

    test_list.replaceAt('x',1);
    
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'x');
    assert(test_list.elementAt(2) == 'c');
}

void replaceAt_front() {

    char chars[3] = {'a','b','c'};
    CharLinkedList test_list(chars, 3);

    test_list.replaceAt('x',0);
    
    assert(test_list.elementAt(0) == 'x');
    assert(test_list.elementAt(1) == 'b');
    assert(test_list.elementAt(2) == 'c');
}

void replaceAt_back() {

    char chars[3] = {'a','b','c'};
    CharLinkedList test_list(chars, 3);

    test_list.replaceAt('x',2);
    
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    assert(test_list.elementAt(2) == 'x');
}

void concatenate_() {

    char chars[3] = {'a','b','c'};
    CharLinkedList test_list(chars, 3);

    char chars2[3] = {'d','e','f'};
    CharLinkedList test_list2(chars2, 3);

    test_list.concatenate(&test_list2);
    
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    assert(test_list.elementAt(2) == 'c');
    assert(test_list.elementAt(3) == 'd');
    assert(test_list.elementAt(4) == 'e');
    assert(test_list.elementAt(5) == 'f');
}

void concatenate_emptyOther() {

    char chars[3] = {'a','b','c'};
    CharLinkedList test_list(chars, 3);

    CharLinkedList test_list2;

    test_list.concatenate(&test_list2);
    
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    assert(test_list.elementAt(2) == 'c');
    assert(test_list.size() == 3);

}

void concatenate_empty() {

    char chars[3] = {'a','b','c'};
    CharLinkedList test_list2(chars, 3);

    CharLinkedList test_list;

    test_list.concatenate(&test_list2);
    
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    assert(test_list.elementAt(2) == 'c');
    assert(test_list.size() == 3);

}
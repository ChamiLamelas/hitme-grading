/*
 *  CharLinkedList.cpp
 *  Tassilo Armleder
 *  6/02/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  FILE PURPOSE HERE
 * 
 * linked list cpp file
 *
 */

#include "CharLinkedList.h"
#include <stdexcept>
#include <string>

using namespace std;

CharLinkedList::CharLinkedList() {
    nodeCount = 0;
    head = nullptr;
}

CharLinkedList::CharLinkedList(char c){
    nodeCount = 0;
    head = nullptr;

    
    nodeCount++;

    Node* new_node = new Node;
    
    new_node->data = c;
    
    head = new_node;
}

CharLinkedList::CharLinkedList(char arr[], int size){
    nodeCount = 0;
    head = nullptr;

    nodeCount+=size;

    Node* array_temp[size];

    for(int i = 0; i < size; i++) {

        Node* new_node = new Node;
        new_node->data = arr[i];
        array_temp[i] = new_node;
    }

    for(int i = 0; i < size; i++) {

        if(i == 0) {
            array_temp[i]->next = array_temp[i+1];
        } else if(i == size-1) {
            array_temp[i]->back = array_temp[i-1];
        } else {
            array_temp[i]->next = array_temp[i+1];
            array_temp[i]->back = array_temp[i-1];
        }
    }

    if(size > 0) {
        head = array_temp[0];
    }
    
}

CharLinkedList::CharLinkedList(const CharLinkedList &other){

    nodeCount = 0;
    head = nullptr;

     Node* temp = other.head;
    while(temp != nullptr) {
       pushAtBack(temp->data);
       temp = temp->next;
    }
}


CharLinkedList::~CharLinkedList(){

    if(head!= nullptr) {
        destructHelp(head);
    }
    head = nullptr;
}


CharLinkedList::Node* CharLinkedList::destructHelp(Node *cur){

    if (cur != nullptr) {
        destructHelp(cur->next);
        delete cur;
    }
    return nullptr;
}


CharLinkedList & CharLinkedList::operator=(const CharLinkedList &other){
    
    clear(); 

    Node* temp = other.head;
    while(temp != nullptr) {
       pushAtBack(temp->data);
       temp = temp->next;
    }

    return *this; 
}


bool CharLinkedList::isEmpty() const{

    if(nodeCount == 0) {
        return true;
    }
    return false;
}

void CharLinkedList::clear(){

    if(head!= nullptr) {
        destructHelp(head);
    }
    head = nullptr;
    nodeCount = 0;
}

int CharLinkedList::size() const{
    return nodeCount;
}

char CharLinkedList::first() const {

   if(nodeCount == 0) {
        throw runtime_error("cannot get first of empty LinkedList");
    } else{
        return elementAt(0);
    }
}

char CharLinkedList::last() const{

    if(nodeCount == 0) {
        throw runtime_error("cannot get last of empty LinkedList");
    } else{
        return elementAt(nodeCount-1);
    }
}

char CharLinkedList::elementAt(int index) const{

    if(index >= nodeCount) {
        string msg = "index "+to_string(index)+" not in range [0.."
        +to_string(nodeCount-1)+")";
        throw range_error(msg);
    }

    Node* temp = head;

    for(int i = 0; i < nodeCount; i++) {
        if(i == index) {
            return temp->data;
        }
        temp = temp->next;
    }
}

string CharLinkedList::toString() const{

    string output = "";

    for(int i = 0; i < nodeCount; i++) {
        output = output + elementAt(i);
    }

    return "[CharLinkedList of size "+to_string(nodeCount)+" <<"+output+">>]";

}

string CharLinkedList::toReverseString() const{

    string output = "";

    for(int i = nodeCount-1; i >= 0; i--) {
        output = output + elementAt(i);
    }

    return "[CharLinkedList of size "+to_string(nodeCount)+" <<"+output+">>]";

}

void CharLinkedList::pushAtBack(char c){

    Node* new_node = new Node;
    new_node->data = c;

    if(nodeCount == 0) {
        head = new_node;
    } else{
        Node* temp = head;

        for(int i = 0; i < nodeCount-1; i++) {
            temp = temp->next;
        }

        temp->next = new_node;
        new_node->back = temp;
    }
    nodeCount+=1;
}

void CharLinkedList::pushAtFront(char c){


    Node* new_node = new Node;
    new_node->data = c;

    if(nodeCount == 0) {
        head = new_node;
    } else{
    Node* temp = head;
    head = new_node;
    new_node->next = temp;
    temp->back = new_node;
    }
    nodeCount+=1;
}

void CharLinkedList::insertAt(char c, int index){
    

    if(index >= nodeCount) {
        string msg = "index "+to_string(index)+" not in range [0.."
        +to_string(nodeCount-1)+")";
        throw range_error(msg);
    }

    nodeCount+=1;

    Node* cur = head;

    if(index != 0) {

        for(int i = 0; i < index; i++) {
            cur = cur->next;
        }

        Node* new_node = new Node;
        new_node->data = c;

        new_node->next = cur;
        new_node->back = cur->back;

        cur->back->next = new_node;
        cur->back = new_node;
    } else if (index == 0) {
        pushAtFront(c);
    }

}

void CharLinkedList::insertInOrder(char c){

    Node* new_node = new Node;
    new_node->data = c;

    if (head == nullptr or c <= head->data) {
        new_node->next = head;
        if (head != nullptr) head->back = new_node;
        head = new_node;
    } else {
        Node* cur = head;
        while (cur->next != nullptr and c > cur->next->data) {
            cur = cur->next;
        }
        new_node->next = cur->next;
        if (cur->next != nullptr) cur->next->back = new_node;
        cur->next = new_node;
        new_node->back = cur;
    }

    nodeCount++;
}

void CharLinkedList::popFromFront(){

    if (nodeCount == 0) {
        throw runtime_error("cannot pop from empty LinkedList");
    }

    nodeCount-=1;

    Node* temp = head;

    head = head->next;
    head->next->back = nullptr;

    delete temp;
}

void CharLinkedList::popFromBack(){

    if (nodeCount == 0) {
        throw runtime_error("cannot pop from empty LinkedList");
    }

     Node* temp = head;

    for(int i = 0; i < nodeCount-1; i++) {
        temp = temp->next;
    }

    temp->back->next = nullptr;

    delete temp;

    nodeCount-=1;

}

void CharLinkedList::removeAt(int index){

    if(index >= nodeCount) {
        string msg = "index "+to_string(index)+" not in range [0.."
        +to_string(nodeCount-1)+")";
        throw range_error(msg);
    }


    if(index == 0) {
        popFromFront();
    } else if(index == nodeCount-1) {
        popFromBack();
    } else {
        nodeCount-=1;

        Node* cur = head;

        for(int i = 0; i < index; i++) {
            cur = cur->next;
        }

        cur->back->next = cur->next;
        cur->next->back = cur->back;

        delete cur;
    }
}

void CharLinkedList::replaceAt(char c, int index){

    if(index >= nodeCount) {
        string msg = "index "+to_string(index)+" not in range [0.."
        +to_string(nodeCount-1)+")";
        throw range_error(msg);
    }

    Node* rep = replaceHelp(head, 0,index);
    rep->data = c;

}

CharLinkedList::Node* CharLinkedList::replaceHelp(Node* curr_p, 
int curr, int index) {

    if(curr == index) {
        return curr_p;
    } else {
        return replaceHelp(curr_p->next, curr+1, index);
    }
}

void CharLinkedList::concatenate(CharLinkedList *other){

    Node* temp = other->head;

    while(temp != nullptr) {
       pushAtBack(temp->data);
       temp = temp->next;
    }
}
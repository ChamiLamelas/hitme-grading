/*
 *  CharLinkedList.cpp
 *  Nancy J. Chen {nchen12}
 *  01-31-2024
 *
 *  COMP 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  To make an CharLinkedList data structure with constructor and function
 *  implementations
 *
 */

#include "CharLinkedList.h"
#include <sstream>

using namespace std;

// PUBLIC FUNCTIONS
 
// CONSTRUCTORS
/*
 * name:      CharLinkedList default constructor   
 * purpose:   initialize an empty CharLinkedList
 * arguments: none
 * returns:   none
 * effects:   lsize to 0 
 */
CharLinkedList::CharLinkedList() {
    front = nullptr; 
    back = nullptr;
    lsize = 0;
}

/*
 * name:      CharLinkedList constructor    
 * purpose:   initialize a CharLinkedList with one element/character
 * arguments: one character to add to CharLinkedList
 * returns:   none
 * effects:   lsize to 0, and creates one element in the list
 */
CharLinkedList::CharLinkedList(char c) {
    front = newNode(c, nullptr, nullptr);
    back = front;
    lsize = 1;
}   

/*
 * name:      CharLinkedList constructor 
 * purpose:   initialize a CharLinkedList with pre-defined data array
 * arguments: pre-defined char data array, and the size of that array
 * returns:   none
 * effects:   lsize is set to the value of size, 
 *            sets the list to the pre-defined char array from parameter
 */
CharLinkedList::CharLinkedList(char arr[], int size) {
    lsize = size;

    if (lsize == 0) {
        front = nullptr; 
        back = nullptr;
    } else if (lsize == 1) {
        front = newNode(arr[0], nullptr, nullptr);
        back = front;
    } else {
        front = newNode(arr[0], nullptr, nullptr);
        Node *prev_node = front;

        for (int i = 1; i < lsize; i++) {
            Node *curr_node = newNode(arr[i], prev_node, nullptr);
            prev_node->next = curr_node;
            prev_node = curr_node;
        }

        back = prev_node;
    }
}

// DESTRUCTOR
/*
 * name:      CharLinkedList destructor
 * purpose:   free memory associated with the CharLinkedList
 * arguments: none
 * returns:   none
 * effects:   frees memory allocated by CharLinkedList instances
 */
CharLinkedList::~CharLinkedList() { // RECURSIVE
    if (lsize > 0)
        clear_memory(front);
}

// COPY CONSTRUCTOR 
/*
 * name:      CharLinkedList copy constructor
 * purpose:   initialize this CharLinkedList by making a copy of another 
 *            CharLinkedList 
 * arguments: the other CharLinkedList
 * returns:   this CharLinkedList
 * effects:   lsize and data list are updated
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other) {
    // Update values
    lsize = other.lsize; 

    // Update data list
    if (lsize == 0) {
        front = nullptr; 
        back = nullptr;
    } else if (lsize == 1) {
        front = newNode(other.front->data, nullptr, nullptr);
        back = front;
    } else {
        front = newNode(other.front->data, nullptr, nullptr);
        Node *prev_node = front;

        for (int i = 1; i < lsize; i++) {
            Node *curr_node = newNode(other.elementAt(i), prev_node, nullptr);
            prev_node->next = curr_node;
            prev_node = curr_node;
        }

        back = prev_node;
    }
}

// ASSIGNMENT OPERATOR
/*
 * name:      
 * purpose:   initialize this CharLinkedList by setting this to another 
 *            CharLinkedList, using an assignment operator =
 * arguments: the other CharLinkedList
 * returns:   this CharLinkedList
 * effects:   lsize and data list are updated
 */
CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other) {
    if (this == &other)
        return *this; // self assignment
    
    // Clear memory
    if (lsize > 0)
        clear_memory(front);
    
    // Update values
    lsize = other.lsize;

    // Update values
    if (other.lsize == 0) {
        front = nullptr; 
        back = nullptr;
    } else if (other.lsize == 1) {
        front = newNode(other.front->data, nullptr, nullptr);
        back = front;
    } else {
        front = newNode(other.front->data, nullptr, nullptr);
        Node *prev_node = front;
        for (int i = 1; i < lsize; i++) {
            Node *curr_node = newNode(other.elementAt(i), prev_node, nullptr);
            prev_node->next = curr_node;
            prev_node = curr_node;
        }
        back = prev_node;
    }

    return *this;
}

// FUNCTIONS TO RETRIEVE DATA
/*
 * name:      isEmpty   
 * purpose:   check if the data list is empty 
 * arguments: none
 * returns:   true if data list is empty, and false otherwise
 * effects:   none
 */
bool CharLinkedList::isEmpty() const {
    return lsize == 0;
}

/*
 * name:      clear
 * purpose:   clears/resets the data list
 * arguments: none
 * returns:   none
 * effects:   sets lsize (which the size of data list) to zero
 */
void CharLinkedList::clear() {
    if (lsize > 0) {
        clear_memory(front);
        lsize = 0;
    }
}

/*
 * name:      size
 * purpose:   retrieves what the size/lsize of the data list is for user
 * arguments: none
 * returns:   lsize
 * effects:   none
 */
int CharLinkedList::size() const {
    return lsize;
}

/*
 * name:      first
 * purpose:   retrieves the first character of the data list
 * arguments: none
 * returns:   first element of data list
 * effects:   none
 */
char CharLinkedList::first() const {
    if (isEmpty())
        throw runtime_error("cannot get first of empty LinkedList");

    return front->data;
}

/*
 * name:      last
 * purpose:   retrieves the last character of the data list
 * arguments: none
 * returns:   last element of data list
 * effects:   none
 */
char CharLinkedList::last() const {
    if (isEmpty())
        throw runtime_error("cannot get last of empty LinkedList");

    return back->data;
}

/*
 * name:      elementAt
 * purpose:   retrieves the character at user-specified index of data list
 * arguments: the index user wants to retrieve character from
 * returns:   character at specific index
 * effects:   none
 */
char CharLinkedList::elementAt(int index) const { // RECURSIVE
    stringstream ss; 
    if (index < 0 or index >= lsize) {
        ss << "index (" << index << ") not in range [0.." << lsize << ")";
        throw range_error(ss.str());
    }

    if (index == 0)
        return first(); 
    else if (index == lsize - 1)   
        return last(); 
    else { 
        char c;
        get_element(front, index, &c);
        return c;
    } 
}

// FUNCTIONS TO FORMAT DATA
/*
 * name:      toString
 * purpose:   creates a formatted string of the data list with characters in
 *            its original order
 * arguments: none
 * returns:   string of data list
 * effects:   none
 */
string CharLinkedList::toString() const {
    stringstream ss;
    ss << "[CharLinkedList of size " << lsize << " <<";

    Node *curr_node = front; 
    for (int i = 0; i < lsize; i++) {
        ss << curr_node->data; 
        curr_node = curr_node->next; 
    }

    ss << ">>]";

    return ss.str();
}

/*
 * name:      toReversedString
 * purpose:   creates a formatted string of the data list with characters in 
 *            reversed order
 * arguments: none
 * returns:   reversed string of data list
 * effects:   none
 */
string CharLinkedList::toReverseString() const {
    stringstream ss;
    ss << "[CharLinkedList of size " << lsize << " <<";

    Node *curr_node = back; 
    for (int i = lsize - 1; i > -1; i--) {
        ss << curr_node->data; 
        curr_node = curr_node->prev; 
    }

    ss << ">>]";
    
    return ss.str();
}

// FUNCTIONS TO MODIFY DATA
/*
 * name:      pushAtBack
 * purpose:   takes a character and insert that at the end of the data list
 * arguments: a character (to be inserted into data) 
 * returns:   none
 * effects:   data array is updated with new character at end of list
 */
void CharLinkedList::pushAtBack(char c) {
    Node *new_node = newNode(c, back, nullptr);

    if (lsize != 0)
        back->next = new_node; 
    
    back = new_node;
    if (lsize == 0)
        front = back;

    lsize++;
}

/*
 * name:      pushAtFront 
 * purpose:   takes a character and insert that at the front of the data list
 * arguments: a character (to be inserted into data) 
 * returns:   none
 * effects:   data array is updated with new character at start of list
 */
void CharLinkedList::pushAtFront(char c) {
    Node *new_node = newNode(c, nullptr, front);
    if (lsize != 0)
        front->prev = new_node;
    
    front = new_node;
    if (lsize == 0)
        back = front;

    lsize++;
} 

/*
 * name:      insertAt
 * purpose:   to insert a character into the data array at specific index
 * arguments: a character (to be inserted), the index in which it's inputted
 * returns:   none
 * effects:   updated data array with the inserted character
 */
void CharLinkedList::insertAt(char c, int index) {
    stringstream ss; 
    if (index < 0 or index > lsize) {
        ss << "index (" << index << ") not in range [0.." << lsize << "]";
        throw range_error(ss.str());
    }

    if (lsize == 0) {
        front = newNode(c, nullptr, nullptr);
        back = front; 
        lsize++;
    } else if (index == 0) {
        pushAtFront(c);
    } else if (index == lsize) {
        pushAtBack(c);
    } else {
        Node *curr_node = front; 
        for (int i = 0; i < index; i++) 
            curr_node = curr_node->next; // current node, move to right
        Node *prev_node = curr_node->prev; 

        Node *new_node = newNode(c, prev_node, curr_node);

        prev_node->next = new_node;
        curr_node->prev = new_node; 

        lsize++;
    }
}

/*
 * name:      insertInOrder
 * purpose:   insert a character into the data array in ASCII order
 * arguments: character to be inserted
 * returns:   none
 * effects:   a new character is inserted into the data array
 */
void CharLinkedList::insertInOrder(char c) {
    // For cases when existing list is empty
    if (lsize == 0) {
        Node *new_node = newNode(c, nullptr, nullptr);
        front = new_node; 
        back = front; 
        lsize++; 
        return;
    }

    // Look for node where this new element should be replaced
    Node *curr_node = front; 
    for (int i = 0; i < lsize; i++) {
        if (curr_node->data >= c)  
            i = lsize;
        else 
            curr_node = curr_node->next; 
    }

    // Insert element and shift over all following elements
    if (curr_node == nullptr) {
        Node *new_node = newNode(c, back, nullptr);
        back->next = new_node; 
        back = new_node;
    } else if (curr_node->prev == nullptr) {
        Node *new_node = newNode(c, nullptr, front);
        front->prev = new_node; 
        front = new_node; 
    } else if (curr_node->next == nullptr) {
        Node *new_node = newNode(c, back->prev, back);
        back->prev->next = new_node; 
        back->prev = new_node; 
    } else {
        Node *new_node = newNode(c, curr_node->prev, curr_node);
        curr_node->prev->next = new_node; 
        curr_node->prev = new_node; 
    }
    lsize++;
}

/*
 * name:      popFromFront
 * purpose:   removes the first element from the data list
 * arguments: none
 * returns:   none
 * effects:   size/lsize is reduced by 1, and first element is removed
 */
void CharLinkedList::popFromFront() {
    if (front == nullptr) 
        throw runtime_error("cannot pop from empty LinkedList");

    if (lsize == 1) {
        delete front;
        front = nullptr; 
        back = nullptr; 
    } else {
        Node* new_front = front->next;
        new_front->prev = nullptr;
        front->next = nullptr;
        
        // Free memory of the deleted node
        delete front;  
        front = new_front;
    }

    lsize--;
}

/*
 * name:      popFromBack
 * purpose:   removes the last element from the data list
 * arguments: none
 * returns:   none
 * effects:   lsize is reduced by 1
 */
void CharLinkedList::popFromBack() {
    if (back == nullptr) 
        throw runtime_error("cannot pop from empty LinkedList");
    
    if (lsize == 1) {
        delete front;
        front = nullptr; 
        back = nullptr; 
    } else {
        Node* new_back = back->prev;
        new_back->next = nullptr;
        back->prev = nullptr;
        
        // Free memory of the deleted node
        delete back;  
        back = new_back;
    }

    lsize--;
}

/*
 * name:      removeAt
 * purpose:   removes a element in the user-given index of the data list
 * arguments: the index of element that should be removed
 * returns:   none
 * effects:   data list shrinks by 1, and everything after the index shifts
 */
void CharLinkedList::removeAt(int index) { 
    stringstream ss; 
    if (index < 0 or index >= lsize) {
        ss << "index (" << index << ") not in range [0.." << lsize << ")";
        throw range_error(ss.str());
    }

    if (index == 0) {
        popFromFront(); 
    } else if (index == lsize - 1) {
        popFromBack();
    } else {  
        // Locate node at index from data list
        Node *curr_node = front; 
        for (int i = 0; i < index; i++) {
            curr_node = curr_node->next; 
        }

        // Remove node at index
        Node *prev_node = curr_node->prev; 
        Node *next_node = curr_node->next; 
        prev_node->next = next_node; 
        next_node->prev = prev_node; 
        delete curr_node; 

        lsize--;
    }
}

/*
 * name:      replaceAt
 * purpose:   replace the chracter at user-specified index of data array with c
 * arguments: the character that replaces a value in data array, 
 *            and user-specified index
 * returns:   none
 * effects:   data array is updated with replaced string.
' */
void CharLinkedList::replaceAt(char c, int index) { // RECURSIVE
    stringstream ss; 
    if (index < 0 or index >= lsize) {
        ss << "index (" << index << ") not in range [0.." << lsize << ")";
        throw range_error(ss.str());
    }

    replace_e(front, 0, index, c);
}

/*
 * name:      concatenate
 * purpose:   conatenate/combine two CharLinkedLists together
 * arguments: a pointer to another CharLinkedList
 * returns:   none
 * effects:   this CharLinkedList is udpated with new data values
 */
void CharLinkedList::concatenate(CharLinkedList *other) {
    // Checks if other linkedlist has data
    if (other == nullptr or other->lsize < 1) 
        return;

    // Make copy linkedlist of other CharLinkedList
    Node *new_front = newNode(other->front->data, nullptr, nullptr);
    Node *prev_node = new_front;
    for (int i = 1; i < other->lsize; i++) {
        Node *curr_node = newNode(other->elementAt(i), prev_node, nullptr);
        prev_node->next = curr_node;
        prev_node = curr_node;
    }
    Node *new_back = prev_node; 

    // Updates this data linkedlist
    if (lsize == 0) {
        front = new_front; 
    } else {
        back->next = new_front; 
        new_front->prev = back; 
    }
    
    back = new_back; 
    lsize += other->lsize;
}

// PRIVATE FUNCTIONS

/*
 * name:      newNode
 * purpose:   to create a new node with data that connects to the previous
 *            and next nodes
 * arguments: char data, pointers to previous node and next node
 * returns:   node that has the data from the argument
 * effects:   none
 */
CharLinkedList::Node *CharLinkedList::newNode(char nd, Node *np, Node *nn) {
    Node *new_node = new Node();
    new_node->data = nd;
    new_node->prev = np;
    new_node->next = nn;

    return new_node;
}

/*
 * name:      clear_memory
 * purpose:   clears up the data list and memory of list
 * arguments: the front (aka. pointer to the first item in the list)
 * returns:   none
 * effects:   data list is cleared from memory
 */
void CharLinkedList::clear_memory(Node *root) {
    if (root->next == nullptr) {
        delete root;
        return;
    } else {
        Node *next_node = root->next;
        delete root;
        clear_memory(next_node);
    }
}

/**
 * name:      get_element
 * purpose:   to retrieve an element from the data list
 * arguments: the pointer to the first item in the list, the iteration count,
 *            and the index of the element we're searching for
 * returns;   the char data of the element
 * effects:   none
*/
void CharLinkedList::get_element(Node *root, int index, char *c) const {
    if (index == 0) {
        *c = root->data;
    } else {
        index--;
        get_element(root->next, index, c);
    }
}

/**
 * name:      replace_e(lement)
 * purpose:   to replace an element from the data list
 * arguments: the pointer to the first item in the list, the iteration count,
 *            the index of the element we're searching for, and 
 *            the char replacing the original char in index
 * returns;   none
 * effects:   updated data list wiht replaced element
*/
void CharLinkedList::replace_e(Node *root, int count, int idx, char c) const {
    if (count == idx) 
        root->data = c;
    else
        replace_e(root->next, ++count, idx, c);
}
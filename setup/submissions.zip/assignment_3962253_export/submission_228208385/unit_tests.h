/*
 *  unit_tests.h
 *  Nancy Chen {nchen12}
 *  02-03-2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  Uses Matt Russell's unit_test framework to test the CharLinkedList class. 
 *  Checks for the edge cases for each function in the CharLinkedList class. 
 *
 */
#include "CharLinkedList.h"
#include <cassert>

/*********************************************************************\
*                       CHAR LINKED LIST TESTS                        *
\*********************************************************************/

/** 
 * constructor_test_default
 * Make sure no fatal errors/memory leaks in the default constructor
*/
void constructor_test_default() {
    CharLinkedList list;
}

/*
 * constructor_test_default_size
 * Make sure no items exist in the list upon construction
 */
void constructor_test_default_size() {
    CharLinkedList list; // One way to invoke the default constructor.
    assert(list.size() == 0);
}

/**
 * constructor_test_single
 * Make sure one item exists in the list upon construction
*/
void constructor_test_single() {
    CharLinkedList list('a');

    // Check if size of list is 1
    assert(list.size() == 1);

    // Check if first item in list is 'a'
    assert(list.elementAt(0) == 'a'); 
}

/**
 * constructor_test_array
 * Make sure the pre-defined array is carried over into the list construction
*/
void constructor_test_array() {
    char arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList list(arr, 8);
    
    // Check if list contains values of arr
    assert(list.toString() == "[CharLinkedList of size 8 <<abcdefgh>>]");
}

/**
 * copy_constructor_check_same
 * Make sure list1 is a copy of list2.
*/
void copy_constructor_check_same() {
    char arr[5] = { 'h', 'e', 'l', 'l', 'o'};

    // initialize two CharLinkedLists
    CharLinkedList list_1(arr, 5);
    CharLinkedList list_2(list_1); // Used copy constructor

    // check if list_2 has list_1 data
    assert(list_2.toString() == "[CharLinkedList of size 5 <<hello>>]");
}

/**
 * copy_constructor_after_replacing_orig
 * Make sure list1 is a copy of list2, and changing list2 doesn't change list1.
*/
void copy_constructor_after_replacing_orig() {
    char arr[5] = { 'h', 'e', 'l', 'l', 'o'};

    // initialize two CharLinkedLists
    CharLinkedList list_1(arr, 5);
    CharLinkedList list_2(list_1); // Used copy constructor

    // replace one character in 1st data array
    list_1.replaceAt('v', 0);

    // check if the 2nd data array still remained the same ("hello") even after 
    // 1st data array is changed
    assert(list_2.toString() == "[CharLinkedList of size 5 <<hello>>]");
}

/**
 * assignment_operator_check_same
 * Make sure list1 is a copy of list2 using the assignment operator =
*/
void assignment_operator_check_same() {
    char arr[5] = { 'h', 'e', 'l', 'l', 'o'};

    CharLinkedList list_1(arr, 5);
    CharLinkedList list_2 = list_1; // Used assignment operator

    list_1.replaceAt('v', 0);
    
    assert(list_2.toString() == "[CharLinkedList of size 5 <<hello>>]");
}

/**
 * assignment_operator_after_replacing_orig
 * Make sure list1 is a copy of list2 using the assignment operator =, 
 * this time checking if assignment operator still works on existing list
*/
void assignment_operator_after_replacing_orig() {
    char arr[5] = { 'h', 'e', 'l', 'l', 'o'};
    char arr_2[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };

    // initialize one CharLinkedList
    CharLinkedList list(arr, 5); 
    list = CharLinkedList(arr_2, 8); // Used assignemnt operator 

    // check if the 2nd data array contains the updated array (arr_2) 
    assert(list.toString() == "[CharLinkedList of size 8 <<abcdefgh>>]");

}


/**
 * isEmpty_test
 * Make sure isEmpty is accurate by checking with newly-constructed list
*/
void isEmpty_test() {
    CharLinkedList list; 
    // list is newly created, so isEmpty() should return true.
    assert(list.isEmpty());
}

/**
 * clear_test
 * Make sure the list is cleared even after being initialized with pre-defined
 * array, by checking if size is 0. 
*/
void clear_test() {
    char arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    // initialize list with a pre-defined array, so the list contains data
    CharLinkedList list(arr, 8);
    
    // clear the list, and checks if size is now 0
    list.clear();
    assert(list.size() == 0);
}

/** 
 * size_test
 * Make sure the size of the list is correct, using all 4 types of constructors
*/
void size_test() {
    CharLinkedList list_1; 
    assert(list_1.size() == 0);

    CharLinkedList list_2('a'); 
    assert(list_2.size() == 1);

    char arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList list_3(arr, 8);
    assert(list_3.size() == 8);

    CharLinkedList list_4(list_3);
    assert(list_4.size() == 8);
}

/**
 * first_test_incorrect
 * Make sure first() throws error message when data array has size less than 1
*/
void first_test_incorrect() {
    // var to track whether range_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    string error_message = "";

    CharLinkedList list;
    try {
        // first for out-of-range index
        list.first();
    }
    catch (const runtime_error &e) {
        // if insertAt is correctly implemented, a rubtime_error will be thrown,
        // and we will end up here
        runtime_error_thrown = true;
        error_message = e.what();
    }

    // out here, we make our assertions
    assert(runtime_error_thrown);
    assert(error_message == "cannot get first of empty LinkedList");
}

/**
 * first_test_correct
 * Make sure first() is accurate
*/
void first_test_correct() {
    char arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    // initialize list with a pre-defined array, so the list contains data
    CharLinkedList list(arr, 8);

    // test first
    assert(list.first() == 'a');
}

/**
 * last_test_incorrect
 * Make sure last() throws error messages when size of data array is less than 1
 * Throws error messages
*/
void last_test_incorrect() {
    // var to track whether range_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    string error_message = "";

    CharLinkedList list;
    try {
        // last for out-of-range index
        list.last();
    }
    catch (const runtime_error &e) {
        // if insertAt is correctly implemented, a range_error will be thrown,
        // and we will end up here
        runtime_error_thrown = true;
        error_message = e.what();
    }

    // out here, we make our assertions
    assert(runtime_error_thrown);
    assert(error_message == "cannot get last of empty LinkedList");
}

/**
 * last_test_correct
 * Make sure last() is accurate
*/
void last_test_correct() {
    char arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    // initialize list with a pre-defined array, so the list contains data
    CharLinkedList list(arr, 8);

    // test first
    assert(list.last() == 'h');
}

/**
 * elementAt_test_incorrect
 * Make sure elementAt() throws error when the index is out of bounds
*/
void elementAt_test_incorrect() {
    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    string error_message = "";

    CharLinkedList list;
    try {
        // elementAt for out-of-range index
        list.elementAt(4);
    }
    catch (const range_error &e) {
        // if insertAt is correctly implemented, a range_error will be thrown,
        // and we will end up here
        range_error_thrown = true;
        error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (4) not in range [0..0)");
}

/**
 * elementAt_test_correct_first
 * Make sure elementAt() is accurate for accessing first data in list
*/
void elementAt_test_correct_first() {
    char arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    // initialize list with a pre-defined array, so the list contains data
    CharLinkedList list(arr, 8);

    // test elementAt
    assert(list.elementAt(0) == 'a');
}

/**
 * elementAt_test_correct_mid
 * Make sure elementAt() is accurate for accessing data in middle of big list
*/
void elementAt_test_correct_mid() {
    char arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    // initialize list with a pre-defined array, so the list contains data
    CharLinkedList list(arr, 8);

    // test elementAt
    assert(list.elementAt(5) == 'f');
}

/**
 * elementAt_test_last
 * Make sure elementAt() is accurate for accessing last data in list
*/
void elementAt_test_last() {
    char arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    // initialize list with a pre-defined array, so the list contains data
    CharLinkedList list(arr, 8);

    // test elementAt
    assert(list.elementAt(7) == 'h');
}

/**
 * elementAt_test_small
 * Make sure elementAt() is accurate for accessing elements in small list
*/
void elementAt_test_small() {
    CharLinkedList list;

    list.pushAtBack('c');
    assert(list.elementAt(0) == 'c');

    list.pushAtBack('a');
    assert(list.elementAt(1) == 'a');

    list.pushAtBack('t');
    assert(list.elementAt(2) == 't');

    assert(list.elementAt(0) == 'c');
    assert(list.elementAt(1) == 'a');
    assert(list.elementAt(2) == 't');
}

/**
 * toString_test
 * Make sure the string of data array is accurate 
*/
void toString_test() {
    char arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    // initialize list with a pre-defined array, so the list contains data
    CharLinkedList list(arr, 8);

    // test toString
    assert(list.toString() == "[CharLinkedList of size 8 <<abcdefgh>>]");
}

/**
 * toReverseString_test
 * Make sure the reversed string of data array is right 
*/
void toReverseString_test() {
    char arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    // initialize list with a pre-defined array, so the list contains data
    CharLinkedList list(arr, 8);

    // test toReverseString
    assert(list.toReverseString() == "[CharLinkedList of size 8 <<hgfedcba>>]");
}

/**
 * pushAtBack test
 * Make sure the last element 
*/
void pushAtBack_test() {
    char arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    // initialize list with a pre-defined array, so the list contains data
    CharLinkedList list(arr, 8);

    // execute pushAtBack()
    list.pushAtBack('3');

    // test pushAtBack() with toString()
    assert(list.toString() == "[CharLinkedList of size 9 <<abcdefgh3>>]");
}

/**
 * pushAtFront test
 * Make sure that the element is added to the front of the list correctly
*/
void pushAtFront_test() {
    char arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    // initialize list with a pre-defined array, so the list contains data
    CharLinkedList list(arr, 8);

    // execute pushAtFront()
    list.pushAtFront('3');

    // test pushAtFront() with toString()
    assert(list.toString() == "[CharLinkedList of size 9 <<3abcdefgh>>]");
}

/**
 * insertAt test - See below
*/

/**
 * insertInOrder_test_all
 * Make sure lowercase letters, capitalized letter, numbers, and special 
 * characters are inserted in order for a large array
*/
void insertInOrder_test_all() {
    char arr[8] = { 'a', 'b', 'c', 'd', 'e', 'g', 'g', 'y' };

    CharLinkedList list(arr, 8);

    list.insertInOrder('u');
    assert(list.toString() == "[CharLinkedList of size 9 <<abcdegguy>>]");

    list.insertInOrder('Y');
    assert(list.toString() == "[CharLinkedList of size 10 <<Yabcdegguy>>]");

    list.insertInOrder('5');
    assert(list.toString() == "[CharLinkedList of size 11 <<5Yabcdegguy>>]");

    list.insertInOrder('?');
    assert(list.toString() == "[CharLinkedList of size 12 <<5?Yabcdegguy>>]");

    list.insertInOrder('z');
    assert(list.toString() == "[CharLinkedList of size 13 <<5?Yabcdegguyz>>]");

    list.insertInOrder('f');
    assert(list.toString() == "[CharLinkedList of size 14 <<5?Yabcdefgguyz>>]");
}

/**
 * popFromBack_test
 * Make sure popFromBack removes one element from the end of the list
*/
void popFromBack_test() {
    // initialize list with a pre-defined array, so the list contains data
    char arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList list(arr, 8);
    CharLinkedList list_2('c');

    // execute popFromBack()
    list.popFromBack();
    list_2.popFromBack();

    // test popFromBack() with toString()
    assert(list.toString() == "[CharLinkedList of size 7 <<abcdefg>>]");
    assert(list_2.toString() == "[CharLinkedList of size 0 <<>>]");
}

/**
 * popFromFront_test
 * Make sure popFromFront correctly removes one element from the front of list
*/
void popFromFront_test() {
    char arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    // initialize list with a pre-defined array, so the list contains data
    CharLinkedList list(arr, 8);
    CharLinkedList list_2('c');

    // execute popFromFront()
    list.popFromFront();
    list_2.popFromFront();

    // test popFromFront() with toString()
    assert(list.toString() == "[CharLinkedList of size 7 <<bcdefgh>>]");
    assert(list_2.toString() == "[CharLinkedList of size 0 <<>>]");
}

/**
 * removeAt_test
 * Make sure removeAt correctly removes one element from specific index
*/
void removeAt_test() {
    char arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    // initialize list with a pre-defined array, so the list contains data
    CharLinkedList list(arr, 8);
    CharLinkedList list_2('c');

    // execute removeAt()
    list.removeAt(4);
    list.removeAt(0);
    list.removeAt(5);
    list_2.removeAt(0);

    // test popFromFront() with toString()
    assert(list.toString() == "[CharLinkedList of size 5 <<bcdfg>>]");
    assert(list_2.toString() == "[CharLinkedList of size 0 <<>>]");
}

/**
 * replaceAt_test
 * Make sure the element in the data array is replaced sucessfully.
*/
void replaceAt_test() {
    char arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    // initialize list with a pre-defined array, so the list contains data
    CharLinkedList list(arr, 8);

    // execute replaceAt()
    list.replaceAt('2', 2);

    // test replaceAt() with toString()
    assert(list.toString() == "[CharLinkedList of size 8 <<ab2defgh>>]");
}

/**
 * concatenate_two_nonempty_lists
 * Make sure that two nonempty lists can be concatenated with each other.
*/
void concatenate_two_nonempty_lists() {
    char arr[5] = { 'h', 'e', 'l', 'l', 'o'};
    char arr_2[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };

    CharLinkedList list_1(arr, 5);
    CharLinkedList list_2(arr_2, 8);

    list_1.concatenate(&list_1);
    assert(list_1.toString() == "[CharLinkedList of size 10 <<hellohello>>]");

    list_2.concatenate(&list_1);
    assert(list_2.toString() == 
    "[CharLinkedList of size 18 <<abcdefghhellohello>>]");
}

/**
 * concatenate_empty_to_nonempty
 * Make sure that concatenating an empty list onto nonempty list works
*/
void concatenate_empty_to_nonempty() {
    char arr[5] = { 'h', 'e', 'l', 'l', 'o'};

    CharLinkedList list_1(arr, 5);
    CharLinkedList list_2;

    list_2.concatenate(&list_1);
    assert(list_2.toString() == "[CharLinkedList of size 5 <<hello>>]");
}


/**
 * concatenate_nonempty_to_empty
 * Make sure that concatenating an nonempty list onto empty list works
*/
void concatenate_nonempty_to_empty() {
    char arr_2[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };

    CharLinkedList list_1;
    CharLinkedList list_2(arr_2, 8);

    list_2.concatenate(&list_1);
    assert(list_2.toString() == "[CharLinkedList of size 8 <<abcdefgh>>]");
}

/**
 * concatenate_itself
 * Make sure that concatenating itself works
*/
void concatenate_itself() {
    char arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };

    CharLinkedList list(arr, 8);

    list.concatenate(&list);
    assert(list.toString() == 
    "[CharLinkedList of size 16 <<abcdefghabcdefgh>>]");
}


// INSERTAT TESTS by Tyler Calabrese, January 2021
// edited by: Milod Kazerounian, January 2022
// Tests correct insertion into an empty AL.
// Afterwards, size should be 1 and element at index 0
// should be the element we inserted.
void insertAt_empty_correct() { 

    CharLinkedList test_list;
    test_list.insertAt('a', 0);
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');

}

// Tests incorrect insertion into an empty AL.
// Attempts to call insertAt for index larger than 0.
// This should result in an std::range_error being raised.
void insertAt_empty_incorrect() {

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
        // insertAt for out-of-range index
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        // if insertAt is correctly implemented, a range_error will be thrown,
        // and we will end up here
        range_error_thrown = true;
        error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0]");
    
}

// Tests correct insertAt for front of 1-element list.
void insertAt_front_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at front
    test_list.insertAt('b', 0);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'a');
    
}

// Tests correct insertAt for back of 1-element list.
void insertAt_back_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at back
    test_list.insertAt('b', 1);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    
}

// Tests calling insertAt for a large number of elements.
// Not only does this test insertAt, it also checks that
// array expansion works correctly.
void insertAt_many_elements() {
    
    CharLinkedList test_list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.insertAt('a', i);
    }

    assert(test_list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
    
}

// Tests insertion into front of a larger list
void insertAt_front_large_list() {
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    test_list.insertAt('y', 0);

    assert(test_list.size() == 10);
    assert(test_list.elementAt(0) == 'y');
    assert(test_list.toString() ==     
    "[CharLinkedList of size 10 <<yabczdefgh>>]");

}

// Tests insertion into the back of a larger list
void insertAt_back_large_list() {

    char test_arr[10] = { 'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 10);  

    test_list.insertAt('x', 10);

    assert(test_list.size() == 11);
    assert(test_list.elementAt(10) == 'x');
    assert(test_list.toString() == 
    "[CharLinkedList of size 11 <<yabczdefghx>>]"); 

}

// Tests insertion into the middle of a larger list
void insertAt_middle_large_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.insertAt('z', 3);

    assert(test_list.size() == 9);
    assert(test_list.elementAt(3) == 'z');
    assert(test_list.toString() == 
    "[CharLinkedList of size 9 <<abczdefgh>>]");

}

// Tests out-of-range insertion for a non-empty list.
void insertAt_nonempty_incorrect() {
   
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8]");
    
}
/*
 *  CharLinkedList.h
 *  Nancy Chen {nchen12}
 *  01-31-2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  An header file for the CharLinkedList class that outlines all the 
 *  variables, functions, and private data struct. 
 */

#include <iostream>

#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H

using namespace std; 

class CharLinkedList {
public: 
    // constructors
    CharLinkedList();
    CharLinkedList(char c);
    CharLinkedList(char arr[], int size);
    CharLinkedList(const CharLinkedList &other);

    // destructor
    ~CharLinkedList();

    // assignment operator
    CharLinkedList &operator=(const CharLinkedList &other);

    // retrieve info
    bool isEmpty() const; 
    void clear();
    int size() const; 
    char first() const; 
    char last() const; 
    char elementAt(int index) const; 

    // to string
    string toString() const; 
    string toReverseString() const; 

    // modify info
    void pushAtBack(char c);
    void pushAtFront(char c); 
    void insertAt(char c, int index);
    void insertInOrder(char c);
    void popFromFront();
    void popFromBack();
    void removeAt(int index);
    void replaceAt(char c, int index);
    void concatenate(CharLinkedList *other);

private: 
    struct Node {
        char data;
        Node *prev;
        Node *next;
    };

    Node *front, *back;
    Node *newNode(char newData, Node *newPrev, Node *newNext);
    int lsize;

    // recursive helper functions
    void clear_memory(Node *root);
    void get_element(Node *root, int index, char *c) const;
    void replace_e(Node *root, int count, int idx, char c) const;
};

#endif

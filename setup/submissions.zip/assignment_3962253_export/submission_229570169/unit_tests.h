/*
 *  unit_tests.h
 *  Julia Mechner
 *  January 29 2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  File Purpose: Test the functions in the CharLinkedList.cpp file. 
 *
 */

#include "CharLinkedList.h"
#include <cassert>
#include <iostream>
#include <string>

using namespace std;


// Tests construction of empty CharLinkedList
// Afterwards, size should be 0 and there should be 
// no elements. 
void cllConstructorTest1() {
    CharLinkedList list;
    assert(list.size() == 0);
}

// Tests construction of CharLinkedList with one provided 
// character. 
// Afterwards, the list should have one element with the
// character provided. 
void cllConstructorTest2() {
    char c = 'c';
    CharLinkedList list(c);
    assert(list.size() == 1);
    assert(list.elementAt(0) == 'c');
}

// Tests construction of CharLinkedList with elements provided
// in array. 
// Afterwards, the list should have the elements in the array. 
void cllConstructorTest3() {
    int size = 3;
    char c[3];
    c[0] = 'a';
    c[1] = 'b';
    c[2] = 'c';
    CharLinkedList list(c, size);
    assert(list.size() == 3);
    assert(list.elementAt(0) == 'a');
}

// Tests copy construction with a provided CharLinkedList  
// onto another one. 
// Afterwards, the created CharLinkedList should be identical 
// to the provided one. 
void copyConstructorTest() {
    int size = 3;
    char c[3];
    c[0] = 'a';
    c[1] = 'b';
    c[2] = 'c';
    CharLinkedList list(c, size);
    CharLinkedList copy_list(list);
    assert(copy_list.size() == 3);
    assert(copy_list.elementAt(0) == 'a');
    assert(copy_list.elementAt(1) == 'b');
    assert(copy_list.elementAt(2) == 'c');
}

// Tests copy construction with a provided CharLinkedList  
// onto the same one. 
// Afterwards, the created CharLinkedList should be identical 
// to the provided one. 
void selfCopyTest() {
    CharLinkedList test_list;
    CharLinkedList copy_list(test_list);
    // Asserts that size is as it should be
    assert(copy_list.size() == 0);
}

// Tests assignment operator.
// Afterwards, the CharLinked List to the left of the operand
// should be identical to the one on the right. 
void assignmentOperatorTest() {
    // Create two character arrays to be input for the 
    // CharLinkedLists.     
    char arr1[3];
    arr1[0] = 'a';
    arr1[1] = 'b';
    arr1[2] = 'c';
    char arr2[3];
    arr2[0] = 'd';
    arr2[1] = 'e';
    arr2[2] = 'f';
    CharLinkedList list_a(arr1, 3);
    CharLinkedList list_b(arr2, 3);
    list_b = list_a;
    // Asserts that size and characters are as they should be
    assert(list_b.isEmpty());
}

// Tests assignment operator copied onto itself.
// Afterwards, the CharLinkedList to the left of the operand
// should be identical to the one on the right. 
void selfAssignmentTest() {
    // Create two character arrays to be input for the 
    // CharLinkedLists.     
    char arr1[3];
    arr1[0] = 'a';
    arr1[1] = 'b';
    arr1[2] = 'c';
    char arr2[3];
    arr2[0] = 'a';
    arr2[1] = 'b';
    arr2[2] = 'c';
    CharLinkedList list_a(arr1, 3);
    CharLinkedList list_b(arr2, 3);
    list_b = list_a;
    // Asserts that size and characters are as they should be
    assert(list_b.size() == 3);
    assert(list_b.first() == 'a');
}

// Tests if the size is accurately returned. 
// Afterwards, the list should have three elements, thus
// returning a size of 3. 
void sizeTest() {
    int size = 3;
    char c[3];
    c[0] = 'a';
    c[1] = 'b';
    c[2] = 'c';
    CharLinkedList list(c, size);
    assert(list.size() == 3);
}

// Tests the is empty by creating an empty LinkedList. 
// Afterwards, the list should come back as empty. 
void isEmptyTest() {
    CharLinkedList list;
    assert(list.isEmpty());
}

// Tests the clear function by determining if list is empty
// after clear is called. 
// Afterwards, the isEmpty test should come back true. 
void clearTest() {
    int size = 3;
    char c[3];
    c[0] = 'a';
    c[1] = 'b';
    c[2] = 'c';
    CharLinkedList list(c, size);
    list.clear();
    assert(list.isEmpty());  
}

// Tests the retrieval of the first character by providing 
// an array with a given first character. 
// The first should return 'a', which is the first character
// of the array. 
void firstTest() {
    int size = 3;
    char c[3];
    c[0] = 'a';
    c[1] = 'b';
    c[2] = 'c';
    CharLinkedList list(c, size); 
    assert(list.first() == 'a');
}

// Tests error messages of first() by making an empty list. 
// Appropriate error message should be thrown. 
void emptyFirstTest() {
    CharLinkedList list;

   // var to track whether runtime_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        list.first();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    cout << error_message << endl;
    cout << "“cannot get first of empty LinkedList" << endl;
    assert(runtime_error_thrown);
    assert(error_message == "cannot get first of empty LinkedList");
}

// Tests the retrieval of the last character by providing 
// an array with a given last character. 
// The last should return 'c', which is the last character
// of the array. 
void lastTest() {
    int size = 3;
    char c[3];
    c[0] = 'a';
    c[1] = 'b';
    c[2] = 'c';
    CharLinkedList list(c, size); 
    assert(list.last() == 'c');   
}

// Tests error messages of last() by making an empty list. 
// Appropriate error message should be thrown. 
void emptyLastTest() {
    CharLinkedList list;

   // var to track whether runtime_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        list.last();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    cout << error_message << endl;
    cout << "“cannot get last of empty LinkedList" << endl;
    assert(runtime_error_thrown);
    assert(error_message == "cannot get last of empty LinkedList");
}

// Tests the retrieval of a given character by providing 
// an array with a given character at that index. 
// The first should return 'c', which is the character
// at the provided index of the array. 
void elementAtTest() {
    int size = 3;
    char c[3];
    c[0] = 'a';
    c[1] = 'b';
    c[2] = 'c';
    CharLinkedList list(c, size); 
    assert(list.elementAt(1) == 'b'); 
}

// Tests error messages of elementAt() by making an empty list. 
// Appropriate error message should be thrown. 
void elementAtEmptyTest() {
    char z = 'z';
    CharLinkedList list; 

   // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        list.elementAt(1);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    cout << error_message << endl;
    cout << "index (1) not in range [0..0)" << endl;
    assert(range_error_thrown);
    assert(error_message == "index (1) not in range [0..0)");
} 

// Tests the pushAtFront by checking if the last
// character is the one provided for the pushAtFront function.
// The first character should be 'd'. 
void pushAtFrontTest() {
    int size = 3;
    char c[3];
    c[0] = 'a';
    c[1] = 'b';
    c[2] = 'c';
    char d = 'd';
    CharLinkedList list(c, size); 
    list.pushAtFront(d);
    assert(list.first() == 'd');  
}

// Tests the pushAtBack by checking if the last
// character is the one provided for the pushAtBack function.
// The last character should be 'd'. 
void pushAtBackTest() {
    int size = 3;
    char c[3];
    c[0] = 'a';
    c[1] = 'b';
    c[2] = 'c';
    char d = 'd';
    CharLinkedList list(c, size); 
    list.pushAtBack(d);
    assert(list.last() == 'd');  
}

// Tests the pushAtBack on large list by checking if the last
// character is the one provided for the pushAtBack function.
// The last character should be 'x'. 
void pushAtBackLargeList() {

    char test_arr[10] = { 'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList list(test_arr, 10);  

    list.insertAt('x', 10);

    assert(list.size() == 11);
    assert(list.elementAt(10) == 'x');
    assert(list.toString() == 
    "[CharLinkedList of size 11 <<yabczdefghx>>]"); 

}

// Tests the insertAt by checking if the character
// at the index is the one provided for the insertAt function.
// The character at the index should be 'z'. 
void insertAtTest() {
    int size = 5;
    char c[5];
    c[0] = 'a';
    c[1] = 'b';
    c[2] = 'c';
    c[3] = 'd';
    c[4] = 'e';
    char z = 'z';
    CharLinkedList list(c, size);
    list.insertAt(z, 2);
    assert(list.elementAt(2) == 'z');
}

// Tests error messages by inserting at a negative index
// Appropriate error message should be thrown. 
void insertAtNegativeTest() {
    char z = 'z';
    int size = 3;
    char c[3];
    c[0] = 'a';
    c[1] = 'b';
    c[2] = 'c';
    CharLinkedList list(c, size); 

   // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        list.insertAt(z, -1);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    cout << error_message << endl;
    cout << "index (-1) not in range [0..3)" << endl;
    assert(range_error_thrown);
    assert(error_message == "index (-1) not in range [0..3)");
} 

// Tests error messages of insertAt() by making an empty list. 
// Appropriate error message should be thrown. 
void insertAtEmptyTest() {
    char z = 'z';
    CharLinkedList list; 

   // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        list.insertAt(z, 1);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    cout << error_message << endl;
    cout << "index (1) not in range [0..0]" << endl;
    assert(range_error_thrown);
    assert(error_message == "index (1) not in range [0..0]");
} 

// Tests the insertInOrder by checking if the provided character
// is in alphabetical order relative to the others in the array.
// The last character should be 'z'. 
void insertInOrderTest() {
    int size = 5;
    char c[5];
    c[0] = 'a';
    c[1] = 'b';
    c[2] = 'd';
    c[3] = 'e';
    c[4] = 'f';
    char z = 'z';
    CharLinkedList list(c, size);
    list.insertInOrder(z);
    assert(list.elementAt(5) == 'z');
}

// Tests the popFromFront by checking the the first character
// is what used to be the second-to-first character.
// Checks that the first character has been updated.
void popFromFrontTest() {
    int size = 3;
    char c[3];
    c[0] = 'a';
    c[1] = 'b';
    c[2] = 'c';
    CharLinkedList list(c, size); 
    list.popFromFront();
    assert(list.first() == 'b');  
}

// Tests the popFromBack by checking the last character
// is what used to be second-to-last.
// Checks that the last character has been updated
void popFromBackTest() {
    int size = 3;
    char c[3];
    c[0] = 'a';
    c[1] = 'b';
    c[2] = 'c';
    CharLinkedList list(c, size); 
    list.popFromBack();
    assert(list.last() == 'b');  
}

// Tests the toString by comparing the result to a message 
// outlining all the characters in the list. 
// The message should in include the string abc. 
void toStringTest() {
    int size = 3;
    char c[3];
    c[0] = 'a';
    c[1] = 'b';
    c[2] = 'c';
    CharLinkedList list(c, size); 
    assert(list.toString() == "[CharLinkedList of size 3 <<abc>>]");
}

// Tests the toString by comparing the result to a message 
// outlining the lack of characters in the list. 
// The message should in include an empty string. 
void emptyToStringTest() {
    CharLinkedList list; 
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}

// Tests the toReverseString by comparing the result to a message 
// outlining all the characters in the array in reverse order. 
// The message should in include the string cba.
void toReverseStringTest() {
    int size = 3;
    char c[3];
    c[0] = 'a';
    c[1] = 'b';
    c[2] = 'c';
    CharLinkedList list(c, size); 
    assert(list.toReverseString() == "[CharLinkedList of size 3 <<cba>>]");
}

// Tests the toReverseString by comparing the result to a message 
// outlining the lack of characters in the list. 
// The message should in include an empty string. 
void EmptyToReverseStringTest() {
    CharLinkedList list; 
    assert(list.toReverseString() == "[CharLinkedList of size 0 <<>>]");
}

// Tests the RemoveAt function by checking the the character at the
// given index is gone after the function is called. 
// Checks that the character at the given index
// is gone. 
void removeAtTest() {
    int size = 3;
    char c[3];
    c[0] = 'a';
    c[1] = 'b';
    c[2] = 'c';
    CharLinkedList list(c, size); 
    list.removeAt(1);
    assert(list.elementAt(1) == 'c');  
}

// Tests error messages of removeAt() by making an empty list. 
// Appropriate error message should be thrown. 
void removeAtEmptyTest() {
    char z = 'z';
    CharLinkedList list; 

   // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        list.removeAt(1);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    cout << error_message << endl;
    cout << "index (1) not in range [0..0)" << endl;
    assert(range_error_thrown);
    assert(error_message == "index (1) not in range [0..0)");
} 

// Tests the replaceAtTest by checking the the character at 
// the given index has been replaced by the provided one. 
// Checks that the character is now the provided one, not the 
// original. 
void replaceAtTest() {
    int size = 3;
    char c[3];
    c[0] = 'a';
    c[1] = 'b';
    c[2] = 'c';
    char z = 'z';
    CharLinkedList list(c, size); 
    list.replaceAt(z, 1);
    assert(list.elementAt(1) == 'z');  
} 

// Tests error messages of replaceAt() by making an empty list. 
// Appropriate error message should be thrown. 
void replaceAtEmptyTest() {
    char z = 'z';
    CharLinkedList list; 

   // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        list.replaceAt(z, 1);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    cout << error_message << endl;
    cout << "index (1) not in range [0..0)" << endl;
    assert(range_error_thrown);
    assert(error_message == "index (1) not in range [0..0)");
} 

// Tests the concatenate function by checking the sizes
// and characters of the combined list. 
void concatenateTest() {
    char c[3];
    c[0] = 'a';
    c[1] = 'b';
    c[2] = 'c';
    char other[3];
    other[0] = 'd';
    other[1] = 'e';
    other[2] = 'f';
    CharLinkedList list(c, 3); 
    CharLinkedList other_list(other, 3);
    list.concatenate(&other_list);
    assert(list.size() == 6);
    assert(list.elementAt(3) == 'd'); 
}

// Tests the concatenate function by checking the sizes
// and characters of the combined list, the latter of 
// which is empty.  
void concatenateEmptyTest() {
    // Create a character array to be input for the 
    // CharArrayList.
    char arr1[3];
    arr1[0] = 'a';
    arr1[1] = 'b';
    arr1[2] = 'c';
    CharLinkedList list_b(arr1, 3);
    CharLinkedList list_a;
    list_a.concatenate(&list_b);
    // Asserts that size is as it should be
    assert(list_a.size() == 3);
}

// Tests the concatenate function by checking the sizes
// and characters of the combined list, the former of 
// which is empty.
void concatenateOppositeEmptyTest() {
    // Create a character array to be input for the 
    // CharArrayList.
    char arr1[3];
    arr1[0] = 'a';
    arr1[1] = 'b';
    arr1[2] = 'c';
    CharLinkedList list_a(arr1, 3);
    CharLinkedList list_b;
    list_a.concatenate(&list_b);
    // Asserts that size is as it should be
    assert(list_a.size() == 3);
}




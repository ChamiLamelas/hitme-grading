/*
 *  CharLinkedList.cpp
 *  Julia Mechner
 *  January 29, 2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  File Purpose: Implement the desired interface of a CharLinkedList
 *                in which a user can make lists of their desired size, 
 *                add, remove, and replace elements, and make deep 
 *                of other CharLinkedLists.  
 *
 */

#include "CharLinkedList.h"
#include <sstream>
#include <string>
#include <iostream>

using namespace std;

/*
 * name:      CharLinkedList constructor
 * purpose:   Construct list with 0 elements and set numItems 
 *            and capacity to 0. 
 * arguments: none
 * returns:   none
 * effects:   Creates a default empty LinkedList with no items and no 
 *            capacity. 
 */
CharLinkedList::CharLinkedList() {
    front = nullptr;
    back = nullptr;
    numItems  = 0;
}

/*
 * name:      CharLinkedList constructor
 * purpose:   Construct list with one element and set numItems
 *            and capacity to 1. 
 * arguments: One character that will become the first element. 
 * returns:   none
 * effects:   Constructs LinkedList with 1 item, capacity of 1, 
 *            and the provided character as the first element. 
 */
CharLinkedList::CharLinkedList(char c) {
    numItems = 1;
    Node *curr = new Node;
    curr->name = c;
    curr->next = nullptr;
    curr->prev = nullptr;
    front = curr; 
    back = curr;
}

/*
 * name:      CharLinkedList constructor
 * purpose:   Constructs a list of aspecified size, populated 
 *            with characters from a provided array. 
 * arguments: int size of list and character array to populate it.
 * returns:   none
 * effects:   Constructs LinkedList of specified size with the 
 *            elements in the provided array. 
 */
CharLinkedList::CharLinkedList(char arr[], int size) {
    front = nullptr;    
    back = nullptr;
    numItems = 0;

    for (int i = (size - 1); i >= 0; i = i - 1) {
        pushAtFront(arr[i]);
    }
     
}

/*
 * name:      CharLinkedList copy constructor
 * purpose:   Constructs LinkedList with elements and numItems
 *            equal to that of another LinkedList. 
 * arguments: The address of the LinkedList to be copied. 
 * returns:   none
 * effects:   Constructs a new LinkedList identical to the one at 
 *            the provided address.  
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other) {
    front = nullptr;    
    back = nullptr;

    Node *other_curr = other.back; 
    for (int i = (other.size() - 1); i >= 0; i = i - 1) {
        pushAtFront(other_curr->name);
        other_curr = other_curr->prev;
    }
}

/*
 * name:      CharLinkedList destructor
 * purpose:   Deletes the list on the heap and frees memory.  
 * arguments: none
 * returns:   none
 * effects:   Deletes list and frees the memory.  
 */
CharLinkedList::~CharLinkedList() {
    Node *curr = front; 
    deleter(curr);
}

CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other) {
    if (this == &other) {
        return *this;
    } 
    clear();
    front = nullptr;    
    back = nullptr;
    Node *other_curr = other.back; 
    for (int i = 0; i < other.size(); i++) {
        pushAtFront(other_curr->name);
        other_curr = other_curr->prev;
    }
    return *this;
}


void CharLinkedList::deleter(Node *curr) {
    if (curr == nullptr) {
        return;
    } else {
        Node *deleted = curr; 
        curr = curr->next; 
        delete deleted; 
        deleter(curr);
    }
}

/*
 * name:      CharLinkedList size
 * purpose:   Return the size of the list.  
 * arguments: none 
 * returns:   none
 * effects:   Provides the number of items of the list. 
 */
int CharLinkedList::size() const {
    return numItems;
}

/*
 * name:      CharLinkedList isEmpty
 * purpose:   Determines if list is empty. 
 * arguments: none 
 * returns:   none
 * effects:   Tells the user if the list is empty. 
 */
bool CharLinkedList::isEmpty() const {
    if (numItems == 0) {
        return true;
    } 
    return false;
}

/*
 * name:      CharLinkedList clear
 * purpose:   Clears the list to have 0 items and no 
 *            elements.  
 * arguments: none 
 * returns:   none
 * effects:   Results in an empty CharLinkedList. 
 */
void CharLinkedList::clear()  {
    while (numItems != 0) {
        popFromFront();
    }
}

char CharLinkedList::elementAt(int index) const {
    if (numItems == 0) {
        throw range_error ("index (" + to_string(index) + 
        ") not in range [0.." + to_string(numItems) + ")");
    }
    int remaining = index; 
    Node *curr = front;
    return helperElement(remaining, curr)->name;
}

/*
 * name:      CharLinkedList toString
 * purpose:   Strings together all the characters in the 
 *            list and returns them with a message providing the 
 *            final string and the size. 
 * arguments: none 
 * returns:   A message containing the string with the characters. 
 * effects:   Provides user with a message containing the characters
 *            in the list strung together. 
 */
std::string CharLinkedList::toString() const {  
    Node *curr = front;
    std::stringstream ss;
    ss << "[CharLinkedList of size " << numItems << " <<";
    for (int i = 0; i < numItems; i++) {
        ss << curr->name;
        curr = curr->next; 
    }
    ss << ">>]";
    return ss.str();
}

/*
 * name:      CharLinkedList toReverseString
 * purpose:   Strings together all the characters in the 
 *            list in reverse order and returns them with a 
 *            message providing the final string and the size. 
 * arguments: none 
 * returns:   A message containing the string with the characters
 *            in reverse order. 
 * effects:   Provides user with a message containing the characters
 *            in the list strung together in reverse order. 
 */
std::string CharLinkedList::toReverseString() const {  
    Node *curr = back;
    std::stringstream ss;
    ss << "[CharLinkedList of size " << numItems << " <<";
    for (int i = 0; i < numItems; i++) {
        ss << curr->name;
        curr = curr->prev; 
    }
    ss << ">>]";
    return ss.str();
}

/*
 * name:      CharLinkedList helperElement
 * purpose:   Recursively finds the element at the given index.
 * arguments: none 
 * returns:   A pointer to the node of the element at the index. 
 * effects:   Goes through each element and returns the one that 
 *            the user is looking for. 
 */
CharLinkedList::Node *CharLinkedList::helperElement(int rem, Node *curr) const {
    if (rem == 0) {
        return curr; 
    } else {
        curr = curr->next;
        rem = rem - 1;
        return helperElement(rem, curr);
    }
}

/*
 * name:      CharLinkedList first
 * purpose:   Returns the first character in the LinkedList. 
 * arguments: none 
 * returns:   The first character in the list. 
 * effects:   Provides user with first character in list or an 
 *            error message if the list is empty. 
 */
char CharLinkedList::first() const {
    if (numItems == 0) {
        throw runtime_error ("cannot get first of empty LinkedList");
    }
    return front->name;
}

/*
 * name:      CharLinkedList last
 * purpose:   Returns the last character in the LinkedList. 
 * arguments: none 
 * returns:   The last character in the list. 
 * effects:   Provides user with last character in list or an
 *            error message is the list is empty. 
 */
char CharLinkedList::last() const {
    if (numItems == 0) {
        throw runtime_error ("cannot get last of empty LinkedList");
    }
    return back->name;
}

/*
 * name:      CharLinkedList pushAtFront
 * purpose:   Inserts a character before the first element on the list. 
 * arguments: Character to be inserted. 
 * returns:   none
 * effects:   Adds an additional character at the beginning of the list
 *            that the user provides.  
 */
void CharLinkedList::pushAtFront(char c) {
    if (numItems == 0) {
        Node *new_node = new Node;
        new_node->name = c;
        new_node->next = nullptr;
        new_node->prev = nullptr;
        back = new_node;
        front = new_node;
    } else {
        Node *new_node = new Node;
        new_node->name = c;
        new_node->next = front;
        front->prev = new_node;
        new_node->prev = nullptr;
        front = new_node;

    }
    numItems++; 
}

/* 
 * name:      CharLinkedList pushAtBack
 * purpose:   Inserts a character after the last element on the list. 
 * arguments: Character to be inserted. 
 * returns:   none
 * effects:   Adds an additional character at the end of the list that
 *            the user provides.  
 */
void CharLinkedList::pushAtBack(char c) {
    if (numItems == 0) {  
        Node *new_node = new Node;
        new_node->name = c;
        new_node->next = nullptr;
        new_node->prev = nullptr;
        back = new_node;
        front = new_node;
    } else {
        Node *new_node = new Node;
        new_node->name = c;
        new_node->next = nullptr;
        new_node->prev = back;
        back->next = new_node;
        back = new_node;
    }
    numItems++; 
}

/*
 * name:      CharLinkedList insertAt
 * purpose:   Inserts a character in the list at the provided index. 
 * arguments: Character to be inserted and its index 
 * returns:   none
 * effects:   Inserts an additional character at the provided index 
 *            in the list. 
 */
void CharLinkedList::insertAt(char c, int index) {
    if ((index > numItems) or (index < 0)) {
        throw range_error ("index (" + to_string(index) + 
        ") not in range [0.." + to_string(numItems) + "]");
    }
    Node *new_node = new Node;
    Node *previous = front;
    Node *following = front->next; 
    for (int i = 0; i < (index - 1); i++) {
        previous = previous->next; 
        following = following->next; 
    }
    new_node->name = c; 
    new_node->prev = previous; 
    new_node->next = following; 
    following->prev = new_node; 
    previous->next = new_node;
}

/*
 * name:      CharLinkedList insertInOrder
 * purpose:   Inserts a character before the first character in the 
 *            list that follows it in the alphabet.
 * arguments: Character to be inserted. 
 * returns:   none
 * effects:   Adds an additional character to the list in alphabetical 
 *            order, meaning before the first letter that comes after
 *            it in the alphabet. 
 */
void CharLinkedList::insertInOrder(char c) {
    int index = numItems;
    Node *curr = front;
    for (int i = 0; i < numItems; i++) {
        if (curr->name < c) {
            index = (i + 1);
        }
        curr = curr->next;
    }
    if (index == numItems) {
        pushAtBack(c);
    } else {
        insertAt(c, index);
    }
}

/*
 * name:      CharLinkedList popFromFront
 * purpose:   Deletes the first character in the LinkedList and 
 *            subtracts it from the number of items. 
 * arguments: none
 * returns:   none
 * effects:   Removes first item of the list and sends an error
 *            message if the list is already empty. 
 */
void CharLinkedList::popFromFront() {
    if (numItems == 0) {
        throw runtime_error ("cannot pop from empty LinkedList");
    }
    Node *deleted = front;
    front = front->next;
    delete deleted;
    numItems = numItems - 1;
} 

/*
 * name:      CharLinkedList popFromBack
 * purpose:   Deletes the last character in the LinkedList and 
 *            subtracts it from number of items. 
 * arguments: none
 * returns:   none
 * effects:   Removes last item of the list and sends an error 
 *            message if the list is already empty. 
 */
void CharLinkedList::popFromBack() {
    if (numItems == 0) {
        throw runtime_error ("cannot pop from empty LinkedList");
    }
    // removeAt(numItems);
    Node *deleted = back;
    back = back->prev;
    back->next = nullptr;
    delete deleted;
    numItems = numItems - 1;
} 

/*
 * name:      CharLinkedList removeAt
 * purpose:   Deletes the last character in the LinkedList and 
 *            subtracts it from the number of items. 
 * arguments: integer index of character to be removed. 
 * returns:   none
 * effects:   Removes character at given index or sends an error
 *            message if that index is not within the list's range. 
 */
void CharLinkedList::removeAt(int index) {
    if ((index > numItems) or (index < 0)) {
        throw range_error ("index (" + to_string(index) + 
        ") not in range [0.." + to_string(numItems) + ")");
    }
    Node *deleted = front; 
    for (int i = 0; i < (index); i++) {
        deleted = deleted->next; 
    }
    Node *previous = deleted->prev;
    Node *following = deleted->next; 
    previous->next = following; 
    following->prev = previous; 
    delete deleted; 
    numItems = numItems - 1; 
}

/*
 * name:      CharLinkedList replaceAt
 * purpose:   Replaces the character at a given index with 
 *            a provided character. 
 * arguments: Character to replace and index of character to 
 *            be replaced as an integer. 
 * returns:   none
 * effects:   Replaces the character at the given index or sends
 *            an error message. 
 */
void CharLinkedList::replaceAt(char c, int index) {
    if ((index > numItems) or (index < 0)) {
        throw range_error ("index (" + to_string(index) + 
        ") not in range [0.." + to_string(numItems) + ")");
    }
    Node* curr = front;
    for (int i = 0; i < (index); i++) {
        curr = curr->next; 
    }
    curr->name = c;
} 

/*
 * name:      CharLinkedList concatenate
 * purpose:   Combines two CharLinkedLists, adding the contents
 *            of the second to the end of the first.
 * arguments: Pointer to the CharLinkedList to be added on. 
 * returns:   none
 * effects:   Combines the two CharLinkedLists.
 */
void CharLinkedList::concatenate(CharLinkedList *other) {
    int otherSize = other->size();
    Node *other_curr = other->front; 
    for (int i = 0; i < otherSize; i++) {
        pushAtBack(other_curr->name);
        other_curr = other_curr->next;
    } 
}
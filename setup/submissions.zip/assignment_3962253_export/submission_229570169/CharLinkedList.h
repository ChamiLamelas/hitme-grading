/*
 *  CharLinkedList.h
 *  Julia Mechner
 *  January 29, 2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  File Purpose: to Contain the function and variable declarations
 *                needed to implemented the CharLinkedList interface. 
 *
 */

#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H

#include <string>

class CharLinkedList {
    public:
    CharLinkedList();
    CharLinkedList(char c);
    CharLinkedList(char arr[], int size);
    CharLinkedList(const CharLinkedList &other);
    ~CharLinkedList();
    CharLinkedList &operator=(const CharLinkedList &other);
    void pushAtFront(char c);
    void pushAtBack(char c);
    void insertAt(char c, int index);
    void insertInOrder(char c);
    int size() const;
    char first() const;
    char last() const;
    char elementAt(int index) const;
    bool isEmpty() const;
    void clear();
    void popFromFront();
    void popFromBack();
    void removeAt(int index);
    void replaceAt(char c, int index);
    void concatenate(CharLinkedList *other);
    std::string toString() const;
    std::string toReverseString() const;

private:
    struct Node {
        char      name;
        Node       *next;
        Node       *prev;
    };

    Node *helperElement(int index, Node *curr) const;
    void deleter(Node *curr);

    Node *front;
    Node *back;
    int   numItems;
};

#endif

/*
 *  unit_tests.h
 *  Ryan Chen
 *  2/3/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  FILE PURPOSE HERE
 *
 */

 #include "CharLinkedList.h"
 #include <cassert>
 #include <iostream>


// Tests correct insertion into an empty AL.
// Afterwards, size should be 1 and element at index 0
// should be the element we inserted.
void insertAt_empty_correct() { 

    CharLinkedList test_list;
    test_list.insertAt('a', 0);
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');

}

// Tests incorrect insertion into an empty AL.
// Attempts to call insertAt for index larger than 0.
// This should result in an std::range_error being raised.
void insertAt_empty_incorrect() {

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
        // insertAt for out-of-range index
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        // if insertAt is correctly implemented, a range_error will be thrown,
        // and we will end up here
        range_error_thrown = true;
        error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0]");
    
}

// Tests correct insertAt for front of 1-element list.
void insertAt_front_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at front
    test_list.insertAt('b', 0);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'a');
    
}

// Tests correct insertAt for back of 1-element list.
void insertAt_back_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at back
    test_list.insertAt('b', 1);

    // std::cout << test_list.toString() << std::endl;

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    
}

// Tests calling insertAt for a large number of elements.
// Not only does this test insertAt, it also checks that
// array expansion works correctly.
void insertAt_many_elements() {
    
    CharLinkedList test_list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.insertAt('a', i);
    }

    assert(test_list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
    
}

// Tests insertion into front of a larger list
void insertAt_front_large_list() {
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    test_list.insertAt('y', 0);

    assert(test_list.size() == 10);
    assert(test_list.elementAt(0) == 'y');
    assert(test_list.toString() == 
    "[CharLinkedList of size 10 <<yabczdefgh>>]");

}

// Tests insertion into the back of a larger list
void insertAt_back_large_list() {

    char test_arr[10] = { 'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 10);  

    test_list.insertAt('x', 10);

    assert(test_list.size() == 11);
    assert(test_list.elementAt(10) == 'x');
    assert(test_list.toString() == 
    "[CharLinkedList of size 11 <<yabczdefghx>>]"); 

}

// Tests insertion into the middle of a larger list
void insertAt_middle_large_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.insertAt('z', 3);

    assert(test_list.size() == 9);
    assert(test_list.elementAt(3) == 'z');
    assert(test_list.toString() == "[CharLinkedList of size 9 <<abczdefgh>>]");

}

// Tests out-of-range insertion for a non-empty list.
void insertAt_nonempty_incorrect() {
   
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8]");
    
}

//test to see whether the 1st constructor works
//should return "[CharLinkedList of size 0 <<>>]" 
void constructorTest_1() 
{
  CharLinkedList test;
  assert(test.size() == 0);
  // assert(test.getFront == nullptr);
  // assert(test.getBack == nullptr);
    
}

//test to see whether the 2nd constructor works
//should return "[CharLinkedList of size 1 <<a>>]" 
void constructorTest_2()
{
  CharLinkedList test = CharLinkedList('a');
  assert(test.size() == 1);

}

//test to see whether the 3rd constructor works
//should return "[CharLinkedList of size 3 <<abc>>]"
void constructorTest_3()
{
  char test_arr[3] = { 'a', 'b', 'c' };
  CharLinkedList test_list(test_arr, 3);
  assert(test_list.size() == 3);
  assert(test_list.toString() == "[CharLinkedList of size 3 <<abc>>]");

}

//test to see whether the 4th constructor works
//should return "[CharLinkedList of size 3 <<abc>>]"
void constructorTest_4()
{
  char test_arr[] = {'a', 'b', 'c'};
  CharLinkedList test = CharLinkedList(test_arr, 3);
  CharLinkedList copy = CharLinkedList(test);

  assert(test.toString() == copy.toString());
  assert(copy.size() == 3);
}

//test to see whether the assignementOperator works
//should return "[CharLinkedList of size 3 <<abc>>]"
void assignmentOperator_test()
{
  char test_arr[] = {'a', 'b', 'c'};
  CharLinkedList test = CharLinkedList(test_arr, 3);
   
  CharLinkedList copy = test;

  assert(copy.toString() == test.toString());
}

//test to see whether the elementAt() function works
//should return 'b'
void elementAt_test()
{
  char test_arr[3] = { 'a', 'b', 'c' };
  CharLinkedList test_list(test_arr, 3);
  char testChar = test_list.elementAt(1);
   
  try
  {
    assert(testChar = 'b');
  }catch(std::range_error)
  {
    std::cout << "caught range error" << std::endl;
  }
}

//test to see whether the toString() function works
//should return "[CharLinkedList of size 3 <<abc>>]"
void toString_test()
{
  char test_arr[3] = { 'a', 'b', 'c' };
  CharLinkedList test_list(test_arr, 3);

  assert(test_list.size() == 3);
  assert(test_list.toString() == "[CharLinkedList of size 3 <<abc>>]");
}

//test to see whether the toReverseString() function works
//should return "[CharLinkedList of size 5 <<edcba>>]"
void toReverseString_test()
{
  char test_arr[6] = { 'a', 'b', 'c', 'd', 'e' };
  CharLinkedList test_list(test_arr, 5);
  assert(test_list.size() == 5);
  assert(test_list.toReverseString() == "[CharLinkedList of size 5 <<edcba>>]");
}

//test to see whether the pushAtBack() function works
//should return "[CharLinkedList of size 2 <<ab>>]" and 
//"[CharLinkedList of size 1 <<a>>]"
void pushAtBack_test()
{
  CharLinkedList test = CharLinkedList('a');
  test.pushAtBack('b');
  assert(test.size() == 2);
  assert(test.toString() == "[CharLinkedList of size 2 <<ab>>]");

  CharLinkedList test2 = CharLinkedList();
  test2.pushAtBack('a');
  assert(test2.size() == 1);
  assert(test2.toString() == "[CharLinkedList of size 1 <<a>>]");
}

//test to see whether the pushAtFront() function works
//should return "[CharLinkedList of size 2 <<ba>>]" and
// "[CharLinkedList of size 1 <<a>>]"
void pushAtFront_test()
{
  CharLinkedList test = CharLinkedList('a');
  test.pushAtFront('b');
  assert(test.size() == 2);
  assert(test.toString() == "[CharLinkedList of size 2 <<ba>>]");

  CharLinkedList test2 = CharLinkedList();
  test2.pushAtFront('a');
  assert(test2.size() == 1);
  assert(test2.toString() == "[CharLinkedList of size 1 <<a>>]");

}

//test whether the empty() function correctly works
//the given array is empty so should return true
void isEmpty_test()
{
  CharLinkedList test_list = CharLinkedList();
  assert(test_list.isEmpty());
}

//test to see whether the insertAt() function works
//should return "[CharLinkedList of size 4 <<abfc>>]"
void insertAt_test()
{
  char test_arr[3] = { 'a', 'b', 'c' };
  CharLinkedList test_list(test_arr, 3);
  test_list.insertAt('f', 2);
  CharLinkedList test_list2 = CharLinkedList();
  test_list2.insertAt('a', 0);
  assert(test_list2.toString() == "[CharLinkedList of size 1 <<a>>]");

  try
  {
    assert(test_list.toString() == "[CharLinkedList of size 4 <<abfc>>]");

  }catch(std::range_error)
  {
    std::cout << "caught range error" << std::endl;
  }
}

//test to see whether the insertInOrder() function works
//should return "[CharLinkedList of size 4 <<abcd>>]"
void insertInOrder_test()
{
  CharLinkedList test_list2 = CharLinkedList();
  char test_arr[3] = { 'a', 'b', 'd' };
  CharLinkedList test_list(test_arr, 3);
  test_list.insertInOrder('c');
  test_list2.insertInOrder('a');
  assert(test_list.toString() == "[CharLinkedList of size 4 <<abcd>>]");
  assert(test_list2.toString() == "[CharLinkedList of size 1 <<a>>]");
  
}

//test to see whether the size() function works
//should return a size of 3
void size_test()
{
  char test_arr[3] = { 'a', 'b', 'c' };
  CharLinkedList test_list(test_arr, 3);

  CharLinkedList test_list2 = CharLinkedList();

  int testNum = test_list.size();
  assert(testNum = 3);
  assert(test_list2.size() == 0);
}

//test to see whether the first() function works
//should return 'a'
void first_test() 
{
  char test_arr[3] = { 'a', 'b', 'c' };
  CharLinkedList test_list(test_arr, 3);

  try
  {
    assert(test_list.first() == 'a');
  }catch(std::runtime_error)
  {
    std::cout << "caught runtime error" << std::endl;
  }
  
}

//test to see whether the last() function works
//should return 'c'
void last_test() 
{
  char test_arr[3] = { 'a', 'b', 'c' };
  CharLinkedList test_list(test_arr, 3);

  try
  {
    assert(test_list.last() == 'c');
  }catch(std::runtime_error)
  {
    std::cout << "caught runtime error" << std::endl;
  }
}

//test to see whether the popFromFront() function works
//should return "[CharLinkedList of size 2 <<bc>>]"
void popFromFront_test()
{
  char test_arr[3] = { 'a', 'b', 'c' };
  CharLinkedList test_list(test_arr, 3);

  // CharLinkedList test_list = CharLinkedList();

  test_list.popFromFront();

  try
  {
    assert(test_list.toString() == "[CharLinkedList of size 2 <<bc>>]");
  }catch(std::runtime_error)
  {
    std::cout << "caught runtime error" << std::endl;
  }
  
}


//test to see whether the popFromBack() function works
//should return "[CharLinkedList of size 2 <<ab>>]"
void popFromBack_test()
{
  char test_arr[3] = { 'a', 'b', 'c' };
  CharLinkedList test_list(test_arr, 3);

  test_list.popFromBack();
  try
  {
    assert(test_list.toString() == "[CharLinkedList of size 2 <<ab>>]");
  }catch(std::runtime_error)
  {
    std::cout << "caught runtime error" << std::endl;
  }
}

//test to see whether the removeAt() function works
//should return "[CharLinkedList of size 2 <<ac>>]"
void removeAt_test()
{
  char test_arr[3] = { 'a', 'b', 'c' };
  CharLinkedList test_list(test_arr, 3);

  test_list.removeAt(1);

  try
  {
    assert(test_list.toString() == "[CharLinkedList of size 2 <<ac>>]");
  }catch(std::range_error)
  {
    std::cout << "caught range error" << std::endl;
  }
}

//test whether the clear() function works
//should delete the nodes of the linkedlists and set numItems to 0
void clear_test()
{
  char test_arr[3] = { 'a', 'b', 'c' };
  CharLinkedList test_list(test_arr, 3);

  test_list.clear();
  assert(test_list.toString() == "[CharLinkedList of size 0 <<>>]");
}

//test to see whether the concatenate() function works
//should return "[CharLinkedList of size 6 <<abcdef>>]" and tests 
//concatenation with itself 
void concatenate_test()
{
  char test_arr[3] = { 'a', 'b', 'c' };
  CharLinkedList test_list(test_arr, 3);

  char test_arr2[3] = { 'd', 'e', 'f' };
  CharLinkedList test_list2(test_arr2, 3);

  test_list2.concatenate(&test_list);

  test_list.concatenate(&test_list);

  assert(test_list2.toString() == "[CharLinkedList of size 6 <<defabc>>]");
  assert(test_list2.size() == 6);
  assert(test_list.toString() == "[CharLinkedList of size 6 <<abcabc>>]");
  assert(test_list.size() == 6);
}

//test to see whether the replaceAt() function works
//should return "[CharLinkedList of size 3 <<abf>>]"
void replaceAt_test()
{
  char test_arr[3] = { 'a', 'b', 'c' };
  CharLinkedList test_list(test_arr, 3);
  test_list.replaceAt('f', 2);

  try
  {
    assert(test_list.toString() == "[CharLinkedList of size 3 <<abf>>]");

  }catch(std::range_error)
  {
    std::cout << "caught range error" << std::endl;
  }

}

/*
 *  CharLinkedList.cpp
 *  Ryan Chen
 *  2/3/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  CharArrayList.cpp holds the implementations for all of the methods in the 
 class
 *
 */

#include "CharLinkedList.h"
#include <stdexcept>

/*
 * name: CharLinkedList()
 * purpose: constructer to create an empty CharLinkedList
 * argument: none
 * returns: none
 * effects: create an empty CharLinkedList
 */
CharLinkedList::CharLinkedList()
{   
    //initialize vars of CharLinkedList
    front = nullptr;
    back = nullptr;
    numItems = 0;
    
}

/*
 * name: CharLinkedList(char c) 
 * purpose: constructer to create a CharLinkedList with one element c
 * argument: a char to put in the CharLinkedList
 * returns: none
 * effects: creates a CharLinkedList with one item c
 */
CharLinkedList::CharLinkedList(char c)
{   
    //create a new node
    Node *newNode = new Node;

    //initialize vars of new node
    newNode->info = c;
    newNode->next = nullptr;
    newNode->prev = nullptr;

    //initialize vars of CharLinkedList
    front = newNode;
    back = newNode;
    numItems = 1;
}

/*
 * name: CharLinkedList(char arr[], int size) 
 * purpose: constructer to create a CharLinkedList with data from a char arr
 * argument: a char arr and the size of that array
 * returns: none
 * effects: copys over the data from the char arr into a CharLinkedList
 */
CharLinkedList::CharLinkedList(char arr[], int size)
{   

    //initialize vars of CharLinkedList
    front = nullptr;
    back = nullptr;
    numItems = size;


    //iterate through the char arr and create a CharLinkedList with nodes for
    //each character
    for(int i = 0; i < numItems; i++) 
    {   
        Node *newNode = new Node;
        newNode->info = arr[i];
        newNode->next = nullptr;

        //if list is empty
        if(front == nullptr) 
        {   
            newNode->prev = nullptr; 
            front = newNode;
            back = newNode;

        }else
        {
            back->next = newNode;
            newNode->prev = back;
            back = newNode;
        }
    }
}

/*
 * name: CharLinkedList(const CharLinkedList &other) 
 * purpose: constructor that create a deep copy of a given CharLinkedList
 * argument: a pointer to a CharLinkedList
 * returns: none
 * effects: creates a deep copy of the CharLinkedList provided
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other) 
{   
    //initialize vars of CharLinkedList
    front = nullptr;
    back = nullptr;
    numItems = 0;

    //create a deep copy of other by copying the the elements of other into 
    //this
    for(int i = 0; i < other.size(); i++)
    {
        pushAtBack(other.elementAt(i));
    }


}

/*
 * name: ~CharLinkedList()
 * purpose: a destructor the deletes the heap allocated data
 * argument: None
 * returns: None
 * effects: deletes the heap-allocated data
 */
CharLinkedList::~CharLinkedList()
{   
    //run recursive helper to delete all nodes
    recursiveHelper(front);
}

/*
 * name: &CharLinkedList::operator=(const CharLinkedList &other)
 * purpose: makes a deep copy of the right side of the assignment to the 
 left side of the assignment
 * argument: a pointer to a CharLinkedList
 * returns: none
 * effects: creates a deep copy of the right side and puts it into the left 
 side
 */
CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other)
{   

    //intialize vars for CharLinkedList
    front = nullptr;
    back = nullptr;
    numItems = 0;


    //create a deep copy of the right of the = to the left side
    for(int i = 0; i < other.size(); i++)
    {
        pushAtBack(other.elementAt(i));
    }


    //return the left side
    return *this;
}

/*
 * name: toString()
 * purpose: print out the size and elements in the CharLinkedList
 * argument: none
 * returns: returns the string "[CharLinkedList of size x <<y>>]" where x is 
 the size of the CharLinkedList and y is the elements.
 * effects: none
 */
std::string CharLinkedList::toString() const
{   
    //create format string for the output
    std::string chars = "";
    std::string format = "[CharLinkedList of size " + std::to_string(numItems);

    //new node to hold front
    Node *newNode = this->front;

    //iterate through the node and put the info into a string
    while(newNode != nullptr)
    {
        chars += newNode->info;
        newNode = newNode->next;
    }

    delete newNode;

    //return the string output
    return format + " <<" + chars + ">>]";
}

/*
 * name: toReverseString()
 * purpose: print out the size and elements (in reverse order) in the 
 CharLinkedList
 * argument: none
 * returns: returns the string "[CharLinkedList of size x <<y>>]" where x is 
 the size of the CharLinkedList and y is the elements but reversed. 
 (Ex: abc -> cba)
 * effects:
 */
std::string CharLinkedList::toReverseString() const
{   
    //create format string for the output
    std::string chars = "";
    std::string format = "[CharLinkedList of size " + std::to_string(numItems);

    //new node to hold front
    Node *newNode = this->front;

    //iterate through the node and put the info into a string
    while(newNode != nullptr)
    {
        chars += newNode->info;
        newNode = newNode->next;
    }

    delete newNode;

    //reverse the string
    for(int i = 0; i < numItems / 2; i++)
    {   
        char temp = chars[numItems - i - 1];
        chars[numItems - i - 1] = chars[i];
        chars[i] = temp;
    }

    //return the string output
    return format + " <<" + chars + ">>]";
}

/*
 * name: elementAt()
 * purpose: return the info of a node at a given index in the CharLinkedList
 * argument: an int of the index 
 * returns: the info of a node at the given index or an error if the index is 
 out of bounds
 * effects: none
 */
char CharLinkedList::elementAt(int index) const
{   
    //check for out of bounds index and throw range error if so
    if((index > numItems) or (index < 0))
    {
      throw std::range_error("index (" + std::to_string(index) + 
      ") not in range [0.." + std::to_string(numItems) + ")");
    }

    //run recursive helper that iterates through the list and returns the
    //info of the node at the given index
    return elementAtHelper(front, index);
}

/*
 * name: isEmpty()
 * purpose: check if the CharLinkedList has no elements
 * argument: none
 * returns: a boolean value whether the CharLinkedList has elements or not
 * effects: none
 */
bool CharLinkedList::isEmpty() const
{   

    //if numItems > 0 return false else return true
    if(numItems > 0)
    {
        return false;
    }

    return true;
}

/*
 * name: clear()
 * purpose: set the numItems of the CharLinkedList to 0 and delete all nodes
 * argument: none
 * returns: none
 * effects: sets the numItems of the CharLinkedList to 0 and delete all nodes
 */
void CharLinkedList::clear()
{   

    //new node to hold front
    Node *newNode = front;


    //iterate through the linked list and delete the nodes
    while(newNode != nullptr)
    {
        Node *temp = newNode->next;
        delete newNode;
        newNode = temp;
    }

    //reset CharLinkedList vars
    front = nullptr;
    back = nullptr;

    numItems = 0;
}

/*
 * name: size()
 * purpose: return the number of items in the CharLinkedList
 * argument: none
 * returns: returns the numItems in the CharLinkedList
 * effects: none
 */
int CharLinkedList::size() const
{
    return numItems;
}

/*
 * name: first()
 * purpose: return the info of the first node in the CharLinkedList
 * argument: none
 * returns: the info of the first node in the CharLinkedList
 * effects: none
 */
char CharLinkedList::first() const
{   
    //check if linked list is empty then if not return the front nodes info
    if(isEmpty()) 
    {   
        throw std::runtime_error("cannot get first of empty LinkedList");
    }else
    {
        return front->info;
    }
}

/*
 * name: last()
 * purpose: return the info of the last node in the CharLinkedList
 * argument: none
 * returns: the info of the last node in the CharLinkedList
 * effects: none
 */
char CharLinkedList::last() const 
{   

    //check if linked list is empty then if not return the last nodes info
    if(isEmpty()) 
    {
        throw std::runtime_error("cannot get first of empty LinkedList");
    }else
    {
        return back->info;
    }
}

/*
 * name: pushAtBack(char c)
 * purpose: put given character at the back of CharLinkedList
 * argument: character c 
 * returns: none
 * effects: creates a new node and sets its info to the given char c and places 
 the node at the back of the CharLinkedList and increments numItems by 1.
 */
void CharLinkedList::pushAtBack(char c) 
{   
    //create a new node
    Node *newNode = new Node;
    newNode->info = c;
    newNode->next = nullptr;
    newNode->prev = nullptr;

    //if the list is not empty set back->next to the newNode and newNode->prev
    //to back
    if(back != nullptr)
    {
        back->next = newNode;
        newNode->prev = back;
    }

    back = newNode;

    //if list is empty set front to new node also
    if(front == nullptr)
    {
        front = newNode;
    }

    numItems++;
}

/*
 * name: pushAtFront(char c)
 * purpose: put given character at the front of CharLinkedList
 * argument: character c 
 * returns: none
 * effects: creates a new node and sets its info to the given char c and places 
 the node at the front of the CharLinkedList and increments numItems by 1.
 */
void CharLinkedList::pushAtFront(char c)
{   
    //create a new node
    Node *newNode = new Node;
    newNode->info = c;
    newNode->next = nullptr;
    newNode->prev = nullptr;
    
    //if the list is not empty set front->prev to the newNode and newNode->next
    //to front
    if(front != nullptr)
    {
        front->prev = newNode;
        newNode->next = front;
    }
    
    front = newNode;

    //if list is empty set back to new node also
    if(back == nullptr)
    {
        back = newNode;
    }

    numItems++;
}


/*
 * name: insertAt(char c, int index)
 * purpose: insert a given char at a given index
 * argument: char c to insert and int index for where to insert
 * returns: none
 * effects: creates a new node sets its info to given char c and inserts it at
 the given index
 */
void CharLinkedList::insertAt(char c, int index)
{   
    //create a new node
    Node *newNode = new Node;
    newNode->prev = nullptr;
    newNode->next = nullptr;
    newNode->info = c;

    //check if index is out of bounds
    if((index > numItems) or (index < 0))
    {
      delete newNode;
      throw std::range_error("index (" + std::to_string(index) + 
      ") not in range [0.." + std::to_string(numItems) + "]");
    }

    //if index is front run pushAtFront
    if((index == 0) or (numItems == 0)) 
    {
        pushAtFront(c);
        delete newNode;
        return;
    //if index is back run pushAtBack
    }else if(index == numItems) 
    {
        pushAtBack(c);
        delete newNode;
        return;
    }

    //interate through the linked list till we reach node at given index
    Node *curr = front;
    for(int i = 0; i < index; i++)
    {
        curr = curr->next;
    }

    //insert the newNode at given index and set all pointers
    newNode->prev = curr->prev;
    newNode->next = curr;
    curr->prev->next = newNode;
    curr->prev = newNode;

    //increment numItems
    numItems++;
}

/*
 * name: insertInOrder
 * purpose: inserts given char c in ASCII order
 * argument: char c to insert
 * returns: none
 * effects: inserts the char c into the CharLinkedList in ASCII Order
 */
void CharLinkedList::insertInOrder(char c)
{
    Node *newNode = this->front;
    int counter = 0;

    if(isEmpty())
    {
        pushAtFront(c);
        delete newNode;
        return;
    }

    while(c > newNode->info)
    {
        newNode = newNode->next;
        counter++;
    }

    insertAt(c, counter);
    
}

/*
 * name: popFromFront()
 * purpose: remove the first item from the CharLinkedList
 * argument: none
 * returns: none
 * effects: removes the first item from the CharLinkedList
 */
void CharLinkedList::popFromFront()
{   
    //check if list is empty
    if(isEmpty()) 
    {   
        throw std::runtime_error("cannot pop from empty LinkedList");
    }else
    {   
        //remove the first node from the linked list
        Node *temp = front->next;
        delete front;
        front = temp;
        front->prev = nullptr;
        numItems--;
    }
}

/*
 * name: popFromBack()
 * purpose: removes the last item from the CharLinkedList
 * argument: none
 * returns: none
 * effects: removes the last item from the CharLinkedList
 */
void CharLinkedList::popFromBack()
{   
    //check if list is empty
    if(isEmpty()) 
    {
        throw std::runtime_error("cannot pop from empty LinkedList");
    }else
    {   
        //remove the last node from the linked list
        Node *temp = back->prev;
        delete back;
        back = temp;
        back->next = nullptr;
        numItems--;
    }
}

/*
 * name: removeAt(int index) 
 * purpose: remove the node from the CharLinkedList at the given index
 * argument: index to of what node to remove
 * returns: none
 * effects: removes the node in the CharLinkedList at index
 */
void CharLinkedList::removeAt(int index)
{   
    //check if index is out of bounds
    if((index >= numItems) or (index < 0))
    { 
      throw std::range_error("index (" + std::to_string(index) + 
      ") not in range [0.." + std::to_string(numItems) + ")");
    }

    //if index is front run popFromFront
    if(index == 0)
    {
        popFromFront();
        return;
    //if index is last run popFromBack
    }else if(index == (numItems - 1))
    {
        popFromBack();
        return;
    }else
    {   
        //create a new node
        Node *newNode = this->front;

        //iterate through the linked list until we reach the given index
        for(int i = 0; i < index; i++)
        {
            newNode = newNode->next;
        }

        //remove the node at the given index
        newNode->prev->next = newNode->next;
        newNode->next->prev = newNode->prev;
        delete newNode;
        numItems--;
    }
}

/*
 * name: replaceAt(char c, int index)
 * purpose: replaces the c haracter at a given index with a given char
 * argument: a char c and a int index
 * returns: none
 * effects: replaces the info of the node at the given index with the given 
 char c
 */
void CharLinkedList::replaceAt(char c, int index)
{   
    //check if index is out of bounds
    if((index >= numItems) or (index < 0))
    {
      throw std::range_error("index (" + std::to_string(index) + 
      ") not in range [0.." + std::to_string(numItems) + ")");
    }

    //run recursive helper to reach node at given index
    Node *curr = replaceAtHelper(front, index);
    //set that nodes info to given char
    curr->info = c;
}


/*
 * name: concatenate(CharLinkedList *other) 
 * purpose: adds the elements of given CharLinkedList to back of current 
 CharLinkedList
 * argument: pointer to a CharLinkedList
 * returns: none
 * effects: combines the 2 CharLinkedLists
 */
void CharLinkedList::concatenate(CharLinkedList *other)
{   

    if(other == nullptr)
    {
        return;
    }

    CharLinkedList temp(*this);

    //add elements from other to back of current linked list
    for(int i = 0; i < other->size(); i++)
    {
        temp.pushAtBack(other->elementAt(i));
    }
    
    clear();

    *this = temp;
    
}

//recursive helper for destructor that iterates through the list deleting 
//each node
void CharLinkedList::recursiveHelper(Node *curr)
{   

    //check if curr is the nullptr and if its not delete the current node and
    //recursively run through the linked list deleting all the nodes till we
    //reach the nullptr and return
    if(curr != nullptr)
    {   
        Node *next = curr->next;
        delete curr;
        curr = next;
        recursiveHelper(curr);
    }else
    {
       return;
    }
}

//recursive helper for elementAt that iterates through the list and stops when 
//it reaches the given index and returns the info at the node
char CharLinkedList::elementAtHelper(Node *curr, int index) const
{   

    //check if index = 0 if it is, return its info and if its not 
    //recursively run the function with curr->next and index - 1 in order to 
    //reach node at given index. W
    if(index == 0)
    {
        return curr->info;
    }else
    {
       return elementAtHelper(curr->next, index - 1);
    }
}

//recursive helper for elementAt that iterates through the list and stops when 
//it reaches the given index and returns the node
CharLinkedList::Node* CharLinkedList::replaceAtHelper(Node *curr, int index)
{   
    //check if index = 0 if it is, return the node and if its not 
    //recursively run the function with curr->next and index - 1 in order to 
    //reach node at given index. W
    if(index == 0)
    {   
        return curr;
    }else
    {
        return replaceAtHelper(curr->next, index - 1);
    }
}



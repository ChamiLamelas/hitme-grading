/*
 *  CharLinkedList.cpp
 *  Walid Nejmi
 *  01/30/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Create an ADT that represents a double linked list of characters.
 *
 */

#include "CharLinkedList.h"

#include <sstream>
#include <string>
#include <iostream>

/*
 * name: CharLinkedList (constructor)     
 * purpose: Constructs an empty object CharLinkedList
 * arguments: None
 * returns: Nothing
 * effects: Initializes an empty CharLinkedList with vSize = 0, front, and back
 * pointers to nullptr.
 */
CharLinkedList::CharLinkedList() {
    front = nullptr;
    back = nullptr;
    vSize = 0;
}

/*
 * name: CharLinkedList (constructor)        
 * purpose: Constructs a CharLinkedList with a single character
 * arguments: c - the character to initialize the list with
 * returns: Nothing
 * effects: Initializes a CharLinkedList with a single character 'c'.
 */
CharLinkedList::CharLinkedList(char c) {
    Node *new_node = create_node(c);
    front = nullptr;
    back = nullptr;

    if (front == nullptr) {
        front = new_node;
        back = new_node;
    }
    vSize = 1;
}


/*
 * name: CharLinkedList (constructor)     
 * purpose: Constructs a CharLinkedList from an array of characters
 * arguments: arr - the array of characters, size - the size of the array
 * returns: Nothing
 * effects: Initializes a CharLinkedList with the contents of the array 'arr' 
 * of size 'size'.
 */
CharLinkedList::CharLinkedList(char arr[], int size) {
    front = nullptr;
    back = nullptr;
    vSize = 0;

    for (int i = 0; i < size; i++) {
        pushAtBack(arr[i]); // insert the new elements at the back of the list
    }
}

/*
 * name: CharLinkedList(constructor)        
 * purpose: Copy constructor for CharLinkedList
 * arguments: other - the CharLinkedList to copy from
 * returns: Nothing
 * effects: Initializes a new CharLinkedList with the same contents as 'other'.
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other) {
    front = nullptr;
    back = nullptr;
    vSize = 0;

    Node *current = other.front;
    while (current != nullptr) {
        this->pushAtBack(current->data);
        current = current->next; // push back all nodes of the other list
    }
}

/*
 * name: ~CharLinkedList (destructor) 
 * purpose: Destructor for CharLinkedList
 * arguments: None
 * returns: Nothing
 * effects: Deallocates memory for the double linked list.
 */
CharLinkedList::~CharLinkedList() {
    destructorHelper(front);
}

/*
 * name: operator=      
 * purpose: Assignment operator for CharLinkedList
 * arguments: other - the CharLinkedList to assign from
 * returns: Nothing
 * effects: Assigns the contents of 'other' to the current CharLinkedList.
 */
CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other) {
    if (this != &other) {
        clear();
        Node *current = other.front;
        while (current != nullptr) {
            pushAtBack(current->data);
            current = current->next;
        }
    }
    return *this;
}

/*
 * name: isEmpty      
 * purpose: Checks whether the CharLinkedList is empty
 * arguments: None
 * returns: True if the CharLinkedList is empty, False otherwise
 * effects: None
 */
bool CharLinkedList::isEmpty() const {
    return vSize == 0;
}

/*
 * name: clear      
 * purpose: Clears the contents of the CharLinkedList
 * arguments: None
 * returns: Nothing
 * effects: Deallocates the memory allocated for each of node of the linked 
 * list.
 */
void CharLinkedList::clear() {
    Node *current = front;
    while (current != nullptr) {
        Node *next = current->next;
        delete current;
        current = next;
    }
    front = nullptr;
    back = nullptr;
    vSize = 0;
}

/*
 * name: size      
 * purpose: Returns the number of characters in the CharLinkedList
 * arguments: None
 * returns: The number of characters in the CharLinkedList
 * effects: None
 */
int CharLinkedList::size() const {
    return vSize;
}


/*
 * name: first      
 * purpose: Returns the first character in the CharLinkedList
 * arguments: None
 * returns: The first character in the CharLinkedList
 * effects: None
 */
char CharLinkedList::first() const {
    if (isEmpty()) {
        throw runtime_error("cannot get first of empty LinkedList");
    }
    return front->data;
}

/*
 * name: last      
 * purpose: Returns the last character in the CharLinkedList
 * arguments: None
 * returns: The last character in the CharLinkedList
 * effects: None
 */
char CharLinkedList::last() const {
    if (isEmpty()) {
        throw runtime_error("cannot get last of empty LinkedList");
    }    
    return back->data;
}

/*
 * name: elementAt      
 * purpose: Returns the character at the specified index
 * arguments: index - the index of the character to retrieve
 * returns: The character at the specified index
 * effects: None
 */
char CharLinkedList::elementAt(int index) const {
    if (index < 0 or index >= vSize) {
        throw range_error("index (" + std::to_string(index) + 
        ") not in range [0.." + std::to_string(vSize) + ")");
    }
    return elementAtHelper(front, index);
}

/*
 * name: toString      
 * purpose: Returns a string representation of the CharLinkedList
 * arguments: None
 * returns: A string representation of the CharLinkedList
 * effects: Creates a string, does not affect the array list
 */    
std::string CharLinkedList::toString() const {
    std::stringstream ss;
    ss << "[CharLinkedList of size " << vSize << " <<";
    Node *current = front;
    while (current != nullptr) {
        ss << current->data;
        current = current->next;
    }
    ss << ">>]";
    return ss.str();
}

/*
 * name: toReverseString      
 * purpose: Returns a reverse string representation of the CharLinkedList
 * arguments: None
 * returns: A reverse string representation of the CharLinkedList
 * effects: Creates a string, does not affect the array list
 */
std::string CharLinkedList::toReverseString() const {
    std::stringstream ss;
    ss << "[CharLinkedList of size " << vSize << " <<";
    Node *current = back;
    while (current != nullptr) {
        ss << current->data;
        current = current->before;
    }
    ss << ">>]";
    return ss.str();
}

/*
 * name: pushAtBack      
 * purpose: Adds a character to the end of the CharLinkedList
 * arguments: c - the character to add
 * returns: Nothing
 * effects: Adds the character 'c' to the end of the CharLinkedList.
 */
void CharLinkedList::pushAtBack(char c) {
    Node *new_node = create_node(c);

    if (isEmpty()) {
        front = new_node;
        back = new_node;
    } else {
        back->next = new_node;
        new_node->before = back;
        back = new_node;
    }
    vSize++;
}
    
/*
 * name: pushAtFront      
 * purpose: Adds a character to the beginning of the CharLinkedList
 * arguments: c - the character to add
 * returns: Nothing
 * effects: Adds the character 'c' to the beginning of the CharLinkedList.
 */    
void CharLinkedList::pushAtFront(char c) {
    Node *new_node = create_node(c);

    if (isEmpty()) {
        front = new_node;
        back = new_node;
    } else {
        front->before = new_node;
        new_node->next = front;
        front = new_node;
    }
    vSize++;
}


/*
 * name: insertAt      
 * purpose: Inserts a character at the specified index
 * arguments: c - the character to insert, index - the index at which to insert
 * returns: Nothing
 * effects: Inserts the character 'c' at the specified 'index' position, 
 * shifting elements that follow to the right.
 */
void CharLinkedList::insertAt(char c, int index) {
    if (index < 0 or index > vSize) {
        throw range_error("index (" + std::to_string(index) + 
        ") not in range [0.." + std::to_string(vSize) + "]");       
    }

    if (index == 0) {
        pushAtFront(c);
    } else if (index == vSize) {
        pushAtBack(c);
    } else {
        Node *new_node = create_node(c);
        Node *current = front;
        for (int i = 0; i < index - 1; i++) {
            current = current->next;
        }
        new_node->next = current->next;
        new_node->before = current;
        current->next->before = new_node;
        current->next = new_node;
        vSize++;
    }

}

/*
 * name: insertInOrder      
 * purpose: Inserts a character in sorted order
 * arguments: c - the character to insert
 * returns: Nothing
 * effects: Inserts the character 'c' into the CharLinkedList while 
 * maintaining sorted order.
 */
void CharLinkedList::insertInOrder(char c) {
    if (front == nullptr) {
        pushAtFront(c);
    } else {
        int index = findInsertIndex(c); // find the index to insert
        insertAt(c, index);
    }
}

/*
 * name: popFromFront      
 * purpose: Removes the character from the beginning of the CharLinkedList
 * arguments: None
 * returns: Nothing
 * effects: Removes the character from the beginning of the CharLinkedList.
 */    
void CharLinkedList::popFromFront() {
    if (isEmpty()) {
        throw runtime_error("cannot pop from empty LinkedList");
    }
    if (front == back) { // if there is only one element in the list
        delete front;
        front = nullptr;
        back = nullptr;
    } else {
        Node *temp = front;
        front = front->next;
        front->before = nullptr;
        delete temp;
    }
    vSize--;
}

/*
 * name: popFromBack      
 * purpose: Removes the character from the end of the CharLinkedList
 * arguments: None
 * returns: Nothing
 * effects: Removes the character from the end of the CharLinkedList.
 */
void CharLinkedList::popFromBack() {
    if (isEmpty()) {
        throw runtime_error("cannot pop from empty LinkedList");
    }
    if (front == back) { // if there is only one element in the list
        delete back;
        front = nullptr;
        back = nullptr;
    } else {
        Node *temp = back;
        back = back->before;
        back->next = nullptr;
        delete temp;
    }
    vSize--;
}

/*
 * name: removeAt      
 * purpose: Removes the character at the specified index
 * arguments: index - the index of the character to remove
 * returns: Nothing
 * effects: Removes the character at the specified 'index' position, 
 * shifting the following elements to the left.
 */
void CharLinkedList::removeAt(int index) {
    if (index < 0 or index >= vSize) {
        throw range_error("index (" + std::to_string(index) + 
        ") not in range [0.." + std::to_string(vSize) + ")");       
    }   
    if (index == 0) {
        popFromFront();
        return;
    } else if (index == vSize - 1) {
        popFromBack();
        return;
    } else {
        Node *current = front;
        for (int i = 0; i < index; i++) {
            current = current->next;
        }
        Node *next_node = current->next;
        Node *before_node = current->before;
        before_node->next = next_node;
        next_node->before = before_node;
        delete current;
        vSize--;
    }
}

/*
 * name: replaceAt      
 * purpose: Replaces the character at the specified index with a new character
 * arguments: c - the new character, index - the index of the character to 
 * replace
 * returns: Nothing
 * effects: Replaces the character at the specified 'index' with the character 
 * 'c'.
 */
void CharLinkedList::replaceAt(char c, int index) {
    if (index < 0 or index >= vSize or isEmpty()) {
        throw range_error("index (" + std::to_string(index) + 
        ") not in range [0.." + std::to_string(vSize) + ")");          
    }
    replaceHelper(front, c, index);

}

/*
 * name: concatenate      
 * purpose: Concatenates another CharLinkedList to the end of the current one
 * arguments: other - a pointer to the CharLinkedList to concatenate
 * returns: Nothing
 * effects: Appends the characters from 'other' to the end of the current 
 * CharLinkedList.
 */
void CharLinkedList::concatenate(CharLinkedList *other) {
   int size = other->size(); 
   for (int i = 0; i < size; i++) {
        this->pushAtBack(other->elementAt(i));
   }
}

/*
 * name: create_node      
 * purpose: Initialize a node on the heap.
 * arguments: character 'c'.
 * returns: pointer to the node.
 * effects: Creates a struct node.
 */
CharLinkedList::Node* CharLinkedList::create_node(char c) {
    Node *new_node = new Node;
    new_node->data = c;
    new_node->next = nullptr;
    new_node->before = nullptr;
    return new_node;
}

/*
 * name: replaceHelper      
 * purpose: Recursively replaces an element at a given index
 * arguments: character 'c', pointer to a Struct node, index 'index'
 * returns: Nothing.
 * effects: Replaces an element at a given index.
 */
void CharLinkedList::replaceHelper(Node* current, char c, int index) {
    if (index == 0) {
        current->data = c; // Replace the element at the current node
        return;
    }
    if (current->next != nullptr) {
        replaceHelper(current->next, c, index - 1); // Move to the next node
    }
}

/*
 * name: destructorHelper      
 * purpose: Recursively deallocates the memory allocated for the nodes.
 * arguments: pointer to a struct Node.
 * effects: Deallocates memory on the heap.
 */
void CharLinkedList::destructorHelper(Node *curr) {
    if (curr == nullptr) {
        return;
    }
    destructorHelper(curr->next);
    delete curr;
}

/*
 * name: elementAtHelper      
 * purpose: Recursively finds an element at a given index.
 * arguments: character 'c', index 'index', 
 * returns: The character in the double linked list at index 'index'
 * effects: None.
 */
char CharLinkedList::elementAtHelper(Node *current, int index) const {
    if (index == 0) {
        return current->data;
    }
    return elementAtHelper(current->next, index - 1);
}

/*
 * name: findInsertIndex      
 * purpose: Finds the right index to insert a character to keep the linked list
 * sorted.
 * arguments: character 'c' 
 * returns: The value of the index.
 * effects: None.
 */
int CharLinkedList::findInsertIndex(char c) const {
    Node *current = front;
    int index = 0;
    while (current != nullptr and current->data <= c) {
        current = current->next;
        index++;
    }
    return index;
}
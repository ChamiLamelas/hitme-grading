/*
 *  unit_tests.h
 *  Walid Nejmi
 *  01/30/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  A unit test file for the CharLinkedList Class.
 *
 */

#include "CharLinkedList.h"
#include <cassert>
#include <iostream>
#include <string>


/*
 * constructor test 0
 * Make sure no fatal errors/memory leaks in the default constructor
 */
void constructor_test_0() {
    CharLinkedList list;
}
/*
 * constructor test 1
 * Make sure no items exist in the list upon construction
 */
void constructor_test_1() {
    CharLinkedList list;
    assert(list.size() == 0);
}

/*
 * constructor test 2
 * Make sure no fatal errors/memory leaks in the constructor
 */
void constructor_test_2() {
    CharLinkedList list('l');
    assert(list.size() == 1);
    assert(list.elementAt(0) == 'l');
    assert(list.first() == 'l');
    assert(list.last() == 'l');
}

/*
 * constructor test 3
 * Make sure no fatal errors/memory leaks in the constructor
 */
void constructor_test_3() {
    char char_array[] = {'a', 'b', 'c'};
    CharLinkedList list(char_array, 3);
    assert(list.size() == 3);
    assert(list.elementAt(0) == 'a');
    assert(list.elementAt(1) == 'b');
    assert(list.elementAt(2) == 'c');
}

// push back non empty list
void push_at_back_test1() {
    CharLinkedList list('l');
    assert(list.size() == 1);
    assert(list.elementAt(0) == 'l');
    list.pushAtBack('c');
    assert(list.size() == 2);   
    assert(list.elementAt(1) == 'c');
}

// pop back one element
void pop_back_one_element() {
    CharLinkedList list('l');
    assert(list.size() == 1);
    assert(list.elementAt(0) == 'l');
    list.popFromBack();
    assert(list.size() == 0);   
}

// pop back 3 elements
void pop_back_3_element() {
    char char_array[] = {'a', 'b', 'c'};
    CharLinkedList list(char_array, 3);
    assert(list.size() == 3);
    list.popFromBack();
    assert(list.size() == 2);
    assert(list.elementAt(1) == 'b');
    list.popFromBack();
    assert(list.size() == 1);
    assert(list.elementAt(0) == 'a');
    list.popFromBack();
    assert(list.size() == 0);
}

// pop front one element
void pop_front_one_element() {
    CharLinkedList list('l');
    assert(list.size() == 1);
    assert(list.elementAt(0) == 'l');
    list.popFromFront();
    assert(list.size() == 0);   
}

// pop front 3 elements
void pop_front_3_element() {
    char char_array[] = {'a', 'b', 'c'};
    CharLinkedList list(char_array, 3);
    assert(list.size() == 3);
    list.popFromFront();
    assert(list.size() == 2);
    assert(list.elementAt(0) == 'b');
    list.popFromFront();
    assert(list.size() == 1);
    assert(list.elementAt(0) == 'c');
    list.popFromFront();
    assert(list.size() == 0);
}

// remove at index = 0
void removeAt0() {
    char char_array[] = {'a', 'b', 'c'};
    CharLinkedList list(char_array, 3);
    list.removeAt(0);
    assert(list.size() == 2);
    assert(list.elementAt(0) == 'b'); 
}

// remove at end 3 elements
void removeAtend() {
    char char_array[] = {'a', 'b', 'c'};
    CharLinkedList list(char_array, 3);
    list.removeAt(2);
    assert(list.size() == 2);
    assert(list.elementAt(1) == 'b'); 
}

// remove middle 3 elements
void removeMiddle() {
    char char_array[] = {'a', 'b', 'c'};
    CharLinkedList list(char_array, 3);
    list.removeAt(1);
    assert(list.size() == 2);
    assert(list.elementAt(0) == 'a'); 
    assert(list.elementAt(1) == 'c'); 
}

// convert to string non empty list
void toString_nonempty() {
    char char_array[] = {'a', 'b', 'c'};
    CharLinkedList list(char_array, 3);
    assert(list.toString() == "[CharLinkedList of size 3 <<abc>>]");
}

// convert to string empty list
void toString_empty() {
    CharLinkedList list;
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}

// convert to reverse string non empty list
void toReverseString_nonempty() {
    char char_array[] = {'a', 'b', 'c'};
    CharLinkedList list(char_array, 3);
    assert(list.toReverseString() == "[CharLinkedList of size 3 <<cba>>]");
}

// convert to reverse string empty list
void toReverseString_empty() {
    CharLinkedList list;
    assert(list.toReverseString() == "[CharLinkedList of size 0 <<>>]");
}

// push at front empty list
void pushAtFront_empty() {
    CharLinkedList list;
    list.pushAtFront('c');
    assert(list.size() == 1);
    assert(list.elementAt(0) == 'c');
}

// push at front non empty list
void pushAtfront_nonempty() {
    char char_array[] = {'a', 'b', 'c'};
    CharLinkedList list(char_array, 3);
    list.pushAtFront('c');
    assert(list.size() == 4);
    assert(list.elementAt(0) == 'c');
    assert(list.toString() == "[CharLinkedList of size 4 <<cabc>>]");
}

// insert middle non empty list
void insertAt_middle() {
    char char_array[] = {'a', 'b', 'c'};
    CharLinkedList list(char_array, 3);
    list.insertAt('z', 1);
    assert(list.size() == 4);
    assert(list.elementAt(0) == 'a');
    assert(list.elementAt(1) == 'z');
    assert(list.elementAt(2) == 'b');
    assert(list.elementAt(3) == 'c');

}

// insert in order at the back
void insert_in_order_back() {
    char char_array[] = {'a', 'b', 'c'};
    CharLinkedList list(char_array, 3);
    list.insertInOrder('z');
    assert(list.size() == 4);    
    assert(list.last() == 'z');

}

// insert in order middle
void insert_in_order_test1() {
    char char_array[] = {'a', 'b', 'z'};
    CharLinkedList list(char_array, 3);
    list.insertInOrder('c');
    assert(list.size() == 4);    
    assert(list.elementAt(2) == 'c');

}

// Tests correct insertion into an empty AL.
// Afterwards, size should be 1 and element at index 0
// should be the element we inserted.
void insertAt_empty_correct() { 

    CharLinkedList test_list;
    test_list.insertAt('a', 0);
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');

}

// Tests incorrect insertion into an empty AL.
// Attempts to call insertAt for index larger than 0.
// This should result in an std::range_error being raised.
void insertAt_empty_incorrect() {

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    // insertAt for out-of-range index
    test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
    // if insertAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    range_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0]");
    
}

// Tests correct insertAt for front of 1-element list.
void insertAt_front_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at front
    test_list.insertAt('b', 0);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'a');
    
}

// Tests correct insertAt for back of 1-element list.
void insertAt_back_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at back
    test_list.insertAt('b', 1);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    
}

// Tests calling insertAt for a large number of elements.
// Not only does this test insertAt, it also checks that
// array expansion works correctly.
void insertAt_many_elements() {
    
    CharLinkedList test_list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.insertAt('a', i);
    }

    assert(test_list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
    
}
// Test insert at beginning list
void insertAt_front_large_list() {
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    test_list.insertAt('y', 0);

    assert(test_list.size() == 10);
    assert(test_list.elementAt(0) == 'y');
    assert(test_list.toString() == 
    "[CharLinkedList of size 10 <<yabczdefgh>>]");

}

// Tests insertion into the back of a larger list
void insertAt_back_large_list() {

    char test_arr[10] = { 'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 10);  

    test_list.insertAt('x', 10);

    assert(test_list.size() == 11);
    assert(test_list.elementAt(10) == 'x');
    assert(test_list.toString() == 
    "[CharLinkedList of size 11 <<yabczdefghx>>]"); 

}

// Tests insertion into the middle of a larger list
void insertAt_middle_large_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.insertAt('z', 3);

    assert(test_list.size() == 9);
    assert(test_list.elementAt(3) == 'z');
    assert(test_list.toString() ==     
    "[CharLinkedList of size 9 <<abczdefgh>>]");

}

// Tests out-of-range insertion for a non-empty list.
void insertAt_nonempty_incorrect() {
   
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8]");
    
}

// Test push front in a large list
void pushFront_large_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList list(test_arr, 8);

    list.pushAtFront('z');
    assert(list.size() == 9);
    assert(list.elementAt(0) == 'z');
    assert(list.elementAt(1) == 'a');
    assert(list.elementAt(6) == 'f');
    assert(list.elementAt(8) == 'h');
}

// Test push front in an empty list
void pushFront_empty_list() {
    CharLinkedList list;

    list.pushAtFront('a');
    assert(list.size() == 1);
    assert(list.elementAt(0) == 'a');
}
// Test replace in a non-empty list
void replace_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList list(test_arr, 8);

    list.replaceAt('z', 0);
    list.replaceAt('w', 3);
    assert(list.size() == 8);
    assert(list.elementAt(0) == 'z');
    assert(list.elementAt(3 == 'w'));
}


// Test toReverseString in a non-empty list
void toStringreverse() {
    char test_array[5] = { 'A', 'l', 'i', 'c', 'e'};
    CharLinkedList list(test_array, 5);

    assert(list.toReverseString() == "[CharLinkedList of size 5 <<ecilA>>]");
}

// Test toReverseString in an empty list
void toStringReverse_empty() {
    CharLinkedList list;

    assert(list.toReverseString() == "[CharLinkedList of size 0 <<>>]");
}

// Test popFront in a non-empty list
void popfront() {
    char test_array[3] = { 'A', 'l', 'i'};
    CharLinkedList list(test_array, 3);

    list.popFromFront();
    assert(list.size() == 2);
    assert(list.elementAt(0) == 'l');
    assert(list.elementAt(1) == 'i');
}
// Test remove in a non-empty list
void remove_list() {
    char test_array[3] = { 'A', 'l', 'i'};
    CharLinkedList list(test_array, 3);

    list.removeAt(1);
    assert(list.size() == 2);
    assert(list.elementAt(0) == 'A');
    assert(list.elementAt(1) == 'i');
}

// Test remove in front in a non-empty list
void remove_front_list() {
    char test_array[3] = { 'A', 'l', 'i'};
    CharLinkedList list(test_array, 3);

    list.removeAt(0);
    assert(list.size() == 2);
    assert(list.elementAt(0) == 'l');
    assert(list.elementAt(1) == 'i');
}

// Test remove at the end of a non-empty list
void remove_end_list() {
    char test_array[3] = { 'A', 'l', 'i'};
    CharLinkedList list(test_array, 3);

    list.removeAt(2);
    assert(list.size() == 2);
    assert(list.elementAt(0) == 'A');
    assert(list.elementAt(1) == 'l');
}

// Test insertinOrder in a non-empty list
void insertInOrder_list_1() {
    char test_array[3] = { 'Z', 'E', 'D'};
    CharLinkedList list(test_array, 3);

    list.insertInOrder('A');
    assert(list.size() == 4);
    assert(list.elementAt(0) == 'A' );
}

// Test insertinOrder in a non-empty list
void insertInOrder_list_2() {
    char test_array[3] = { 'b', 'c', 'd'};
    CharLinkedList list(test_array, 3);

    list.insertInOrder('e');
    assert(list.size() == 4);
    assert(list.elementAt(0) == 'b' );
    assert(list.elementAt(3) == 'e' );
}

// Test insertinOrder in a non-empty list
void insertInOrder_list_3() {
    char test_array[3] = { 'b', 'e', 'z'};
    CharLinkedList list(test_array, 3);

    list.insertInOrder('c');
    assert(list.size() == 4);
    assert(list.elementAt(0) == 'b' );
    assert(list.elementAt(1) == 'c' );
}


// Test concatenate with two non empty lists
void concatenate_test() {
    char test_array[2] = { 'h', 'i'};
    CharLinkedList list1(test_array, 2);

    char test_array_2[2] = { 'o', 'p'};
    CharLinkedList list2(test_array_2, 2);

    list1.concatenate(&list2);

    assert(list1.size() == 4);
    assert(list1.elementAt(0) == 'h');
    assert(list1.elementAt(1) == 'i');
    assert(list1.elementAt(2) == 'o');
    assert(list1.elementAt(0) == 'h');
}

// Test concatenate with an empty list
void concatenate_test_empty() {
    char test_array[2] = { 'h', 'i'};
    CharLinkedList list1(test_array, 2);

    CharLinkedList list2;

    list1.concatenate(&list2);

    assert(list1.size() == 2);
    assert(list1.elementAt(0) == 'h');
    assert(list1.elementAt(1) == 'i');
}

// Test concatenate with itself
void concatenate_test_itself() {
    char test_array[2] = { 'h', 'i'};
    CharLinkedList list1(test_array, 2);

    assert(list1.size() == 2);
    list1.concatenate(&list1);

    assert(list1.size() == 4);
    assert(list1.elementAt(0) == 'h');
    assert(list1.elementAt(1) == 'i');
    assert(list1.elementAt(2) == 'h');
    assert(list1.elementAt(3) == 'i');    
}

// Test concatenate two empty lists
void concatenate_empty_nonempty() {
    char test_array[2] = { 'h', 'i'};
    CharLinkedList list2(test_array, 2);

    CharLinkedList list1;

    list1.concatenate(&list2);

    assert(list1.size() == 2);
    assert(list1.elementAt(0) == 'h');
    assert(list1.elementAt(1) == 'i'); 
}

// Test throw errors in insertAt for index < 0
void error_insertAt() {
    CharLinkedList list('c');
    bool exception_thrown = false;
    std::string error_message = "";

    try {
        list.insertAt('z', -1);
    } catch (const std::runtime_error &o) {
        exception_thrown = true;
        error_message = o.what();
    }

    assert(exception_thrown);
    assert(error_message == "index (-1) not in range [0..1]");
}

// Test throw errors in insertAt for index > size
void error_insertAt_2() {
    CharLinkedList list('c');
    bool exception_thrown = false;
    std::string error_message = "";

    try {
        list.insertAt('z', 31);
    } catch (const std::runtime_error &o) {
        exception_thrown = true;
        error_message = o.what();
    }

    assert(exception_thrown);
    assert(error_message == "index (31) not in range [0..1]");
}

// Test throw errors in removeAt index < 0
void error_removeAt() {
    CharLinkedList list('c');
    bool exception_thrown = false;
    std::string error_message = "";

    try {
        list.removeAt(-1);
    } catch (const std::runtime_error &o) {
        exception_thrown = true;
        error_message = o.what();
    }

    assert(exception_thrown);
    assert(error_message == "index (-1) not in range [0..1)");
}

// Test throw errors in removeAt index > size
void error_removeAt_2() {
    CharLinkedList list('c');
    bool exception_thrown = false;
    std::string error_message = "";

    try {
        list.removeAt(31);
    } catch (const std::runtime_error &o) {
        exception_thrown = true;
        error_message = o.what();
    }

    assert(exception_thrown);
    assert(error_message == "index (31) not in range [0..1)");
}
// Test throw errors in replace at index < 0
void error_replaceAt() {
    CharLinkedList list('c');
    bool exception_thrown = false;
    std::string error_message = "";

    try {
        list.replaceAt('z', -1);
    } catch (const std::runtime_error &o) {
        exception_thrown = true;
        error_message = o.what();
    }

    assert(exception_thrown);
    assert(error_message == "index (-1) not in range [0..1)");
}

// Test throw errors in removeAt index >= size
void error_replaceAt_2() {
    CharLinkedList list('c');
    bool exception_thrown = false;
    std::string error_message = "";

    try {
        list.replaceAt('z', 1);
    } catch (const std::runtime_error &o) {
        exception_thrown = true;
        error_message = o.what();
    }

    assert(exception_thrown);
    assert(error_message == "index (1) not in range [0..1)");
}

// Test throw errors in elementAt index < 0
void error_elementAt() {
    CharLinkedList list('c');
    bool exception_thrown = false;
    std::string error_message = "";

    try {
        list.elementAt(-1);
    } catch (const std::runtime_error &o) {
        exception_thrown = true;
        error_message = o.what();
    }

    assert(exception_thrown);
    assert(error_message == "index (-1) not in range [0..1)");
}


// Test throw errors in removeAt index >= 0
void error_elementAt_2() {
    CharLinkedList list('c');
    bool exception_thrown = false;
    std::string error_message = "";

    try {
        list.elementAt(1);
    } catch (const std::runtime_error &o) {
        exception_thrown = true;
        error_message = o.what();
    }

    assert(exception_thrown);
    assert(error_message == "index (1) not in range [0..1)");
}

// Test throw errors in first in an empty list
void error_first() {
    CharLinkedList list;
    bool exception_thrown = false;
    std::string error_message = "";

    try {
        char e = list.first();
    } catch (const std::runtime_error &o) {
        exception_thrown = true;
        error_message = o.what();
    }

    assert(exception_thrown);
    assert(error_message == "cannot get first of empty LinkedList");
}

// Test throw errors in last in an empty list
void error_last() {
    CharLinkedList list;
    bool exception_thrown = false;
    std::string error_message = "";

    try {
        char e = list.last();
    } catch (const std::runtime_error &o) {
        exception_thrown = true;
        error_message = o.what();
    }

    assert(exception_thrown);
    assert(error_message == "cannot get last of empty LinkedList");
}

// Test throw errors with replace in an empty list
void replace_empty_list() {
    CharLinkedList list;
    bool exception_thrown = false;
    std::string error_message = "";

    try {
        list.replaceAt('z', 0);
    } catch (const std::runtime_error &o) {
        exception_thrown = true;
        error_message = o.what();
    }

    assert(exception_thrown);
    assert(error_message == "index (0) not in range [0..0)");
}


// Test clear function on empty list
void test_clear_empty() {
    CharLinkedList list;
    assert(list.size() == 0);

    list.clear();
    assert(list.size() == 0);
    
}

// Test operator assignment on two non-empty lists
void test_operator() {
    CharLinkedList list1('e');
    CharLinkedList list2('z');

    list2 = list1;
    assert(list1.first() == 'e');
    assert(list2.first() == 'e');
}

// Test operator assignment on itself
void test_operator_itself() {
    CharLinkedList list1('e');
    CharLinkedList list2('e');

    list2 = list1;
    assert(list1.first() == 'e');
    assert(list2.first() == 'e');
}

// Test operator assignment on empty list
void test_operator_empty() {
    CharLinkedList list1('e');
    CharLinkedList list2;

    list2 = list1;
    assert(list1.first() == 'e');
    assert(list2.first() == 'e');
}

// Test operator assignment on empty list
void test_operator_empty_2() {
    CharLinkedList list1;
    CharLinkedList list2('e');

    list2 = list1;
    assert(list1.size() == 0);
    assert(list2.size() == 0);
}

//Test copy constructor
void copy_constructor_test() {
    CharLinkedList list1;

    list1.pushAtBack('a');
    list1.pushAtBack('b');

    CharLinkedList list2(list1);

    assert(list2.size() == list1.size());
    assert(list2.elementAt(0) == 'a');
    assert(list2.elementAt(1) == 'b');
}
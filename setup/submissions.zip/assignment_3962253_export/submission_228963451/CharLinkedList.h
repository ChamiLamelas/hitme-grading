/*
 *  CharLinkedList.h
 *  Wilson Wu (wwu10)
 *  2/5/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Contains all the function, destructor, and constructor declarations
 *  for the class/program as well as the variables and private functions
 *  and the structure nodes.
 */

#include <string>

#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H

class CharLinkedList {
    public:
    // constructors
        CharLinkedList();
        CharLinkedList(char c);
        CharLinkedList(char arr[], int size);
        CharLinkedList(const CharLinkedList &other);
        ~CharLinkedList();   

        CharLinkedList &operator=(const CharLinkedList &other);

    // functions
        bool isEmpty() const;
        void clear();
        int size() const;
        char first() const;
        char last() const;
        char elementAt(int index) const;
        std::string toString() const;
        std::string toReverseString() const;
        void pushAtBack(char c);
        void pushAtFront(char c);
        void insertAt(char c, int index);
        void insertInOrder(char c);
        void popFromFront();
        void popFromBack();
        void removeAt(int index);
        void replaceAt(char c, int index);
        void concatenate(CharLinkedList *other);

    private:
        int listSize;

        struct Node {
            char info;
            Node* next;
            Node* back;

            Node(char c){
                // back = b;
                // next = n;
                info = c;
            }
            Node(char c,Node* b,Node* n){
                back = b;
                next = n;
                info = c;
            }
        };
        Node* front;
        Node* end;

        void deleteNodesRecursive(Node* currNode);
        Node* findNode(Node* currNode,int index) const;
};

#endif

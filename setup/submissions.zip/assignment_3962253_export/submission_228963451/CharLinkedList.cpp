/*
 *  CharLinkedList.cpp
 *  Wilson Wu (wwu10)
 *  2/5/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Contains all the function, destructor, and constructor definitions,
 *  explains all of them and contains the actual code
 */

#include "CharLinkedList.h"
#include <stdexcept>
#include <string>
#include <iostream>

    //constructors
    CharLinkedList::CharLinkedList(){
        front = nullptr;
        end = nullptr;
        listSize = 0;
    }
    CharLinkedList::CharLinkedList(char c){
        Node* newNode = new Node(c);
        newNode->next = nullptr;
        newNode->back = nullptr;
        front = newNode;
        end = newNode;
        listSize = 1;
    }
    CharLinkedList::CharLinkedList(char arr[], int size){
        front = nullptr;
        end = nullptr;
        listSize = 0;
        for(int i = 0; i < size; i++){
            pushAtBack(arr[i]);
        }
        listSize = size;
    }
    CharLinkedList::CharLinkedList(const CharLinkedList &other){
        listSize = 0;
        Node* currNode = other.front;
        while(currNode != nullptr){
            pushAtBack(currNode->info);
            currNode = currNode->next;
        }
        listSize = other.listSize;
    }
    CharLinkedList::~CharLinkedList(){
        deleteNodesRecursive(front);
    }   
// name:      deletedNodesRecursive
// purpose:   to free up the memory used by the LinkedList by deleteing it 
//            recursively
// arguments: pointer to the current node
// returns:   nothing
// effects:   deletes all nodes linked to linkedlist from front
    void CharLinkedList::deleteNodesRecursive(Node* currNode){
        if(currNode == nullptr){
            // std::cerr << "currNode == nullptr Case" << std::endl;
            return;
        }
        else{
            // std::cerr << "recursive Case" << std::endl;
            deleteNodesRecursive(currNode->next);
            delete currNode;
        }
    }

// name:      assignement operator
// purpose:   creates a deep copy of the arrraylist on the right to the one 
//            the left, as well as freeing the memory
// arguments: the address of one LinkedList
// returns:   a CharLinkedList object
// effects:   none
    CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other){
        if(this == &other) {
            return *this;
        }

        clear();

        Node* currNode = other.front;
        while(currNode != nullptr){
            pushAtBack(currNode->info);
            currNode = currNode->next;
        }
        listSize = other.listSize;
        return *this;
    }

    // functions
// name:      isEmpty
// purpose:   checks if the LinkedList is empty
// arguments: none
// returns:   boolean on if the LinkedList is empty
// effects:   none
    bool CharLinkedList::isEmpty() const{
        if(listSize == 0) return true;
        else return false;
    }
// name:      clear
// purpose:   makes the instance an empty LinkedList
// arguments: none
// returns:   none
// effects:   none
    void CharLinkedList::clear(){
        deleteNodesRecursive(front);
        end = nullptr;
        front = nullptr;
        listSize = 0;
    }
// name:      size
// purpose:   return number of characters in LinkedList
// arguments: none
// returns:   none
// effects:   none
    int CharLinkedList::size() const{
        return listSize;
    }
// name:      first
// purpose:   get the first character in LinkedList
// arguments: none
// returns:   first character
// effects:   throws an runtime error if LinkedList is empty
    char CharLinkedList::first() const{
        if(isEmpty()){
            throw std::runtime_error("cannot get first of empty LinkedList");
        }
        else return front->info;
    }
// name:      last
// purpose:   get the last character in LinkedList
// arguments: none
// returns:   last character
// effects:   throws an runtime error if LinkedList is empty
    char CharLinkedList::last() const{
        if(isEmpty()){
            throw std::runtime_error("cannot get last of empty LinkedList");
        }
        else return end->info;
    }
// name:      elementAt
// purpose:   get the caracter at index given in LinkedList
// arguments: integer of the index
// returns:   character at given index
// effects:   throws a range error if index is out of linkedlists range
    char CharLinkedList::elementAt(int index) const{
        if(index > listSize - 1 or index < 0){
            std::string message = "index (" + std::to_string(index);
            std::string message1  = ") not in range [0..";
            std::string message2 = std::to_string(listSize) + ")";
            throw std::range_error(message + message1 + message2);
        }
        else return findNode(front,index)->info;
    }
// name:      findNode
// purpose:   to find the node in linked list at index-th spot
// arguments: pointer to current node and int of index we want to find
// returns:   Pointer to the node we want
// effects:   none
    CharLinkedList::Node* 
    CharLinkedList::findNode(Node* currNode,int index) const{
        if(index == 0){ 
            // std::cerr << "Index == 0 Case" << std::endl;
            return currNode;
        }
        if(currNode->next == nullptr){ 
            // std::cerr << "currNode->next == nullptr Case" << std::endl;
            return currNode;
        }
        else{
            // std::cerr << "Recursive Case" << std::endl;
            index--;
            return findNode(currNode->next,index);
        }
    }
    
// name:      toString
// purpose:   converts the info and data in the LinkedList
// arguments: none
// returns:   string with info
// effects:   none
    std::string CharLinkedList::toString() const{
        std::string message = "";
        std::string size = "CharLinkedList of size " + std::to_string(listSize);
        for(int i = 0; i < listSize; i++){
            message += elementAt(i);
        }
        return "[" + size + " <<" + message + ">>]";
    }
// name:      toReverseString
// purpose:   converts the info and data in the LinkedList backwards
// arguments: none
// returns:   string with backwards info
// effects:   none
    std::string CharLinkedList::toReverseString() const{
        std::string message = "";
        std::string size = "CharLinkedList of size " + std::to_string(listSize);
        for(int i = listSize-1; i >= 0; i--){
            message += elementAt(i);
        }
        return "[" + size + " <<" + message + ">>]";
    }
// name:      pushAtBack
// purpose:   to insert a character at the back of the LinkedList
// arguments: character you want to insert
// returns:   none
// effects:   none
    void CharLinkedList::pushAtBack(char c){
        if(isEmpty()){
            // std::cerr << "isEmpty case for inserting " << c << std::endl;
            end = new Node(c,nullptr,nullptr);
            front = end;
        }
        else{
            // std::cerr << "inserting at end for " << c << std::endl;
            end->next = new Node(c,end,nullptr);
            end = end->next;
        }
        listSize++;
    }
// name:      pushAtFront
// purpose:   to insert at the front of the LinkedList
// arguments: character you want to insert
// returns:   none
// effects:   none
    void CharLinkedList::pushAtFront(char c){
        if(isEmpty()){
            // std::cerr << "isEmpty case for inserting " << c << std::endl;
            end = new Node(c,nullptr,nullptr);
            front = end;
        }
        else{
            // std::cerr << "inserting at front " << c << std::endl;
            front->back = new Node(c,nullptr,front);
            front = front->back;
        }
        listSize++;
    }
// name:      insertAt
// purpose:   to insert a character into the LinkedList at given index
// arguments: character you want to insert, given index to insert at
// returns:   none
// effects:   throws a range error if index is outside linkedlists range
    void CharLinkedList::insertAt(char c, int index){
        if(index > listSize or index < 0){
            std::string message = "index (" + std::to_string(index);
            std::string message1  = ") not in range [0..";
            std::string message2 = std::to_string(listSize) + "]";
            throw std::range_error(message + message1 + message2);
        }

        if(isEmpty()){
            // std::cerr << "isEmpty case for inserting " << c << std::endl;
            end = new Node(c,nullptr,nullptr);
            front = end;
            listSize++;
        }
        else if(index == 0){
            // std::cerr << "inserting at front called" << std::endl;
            pushAtFront(c);
        }
        else if(index == listSize){
            // std::cerr << "inserting at back called" << std::endl;
            pushAtBack(c);
        }
        else{
            Node* currNode = findNode(front,index);

            Node* newNode = new Node(c);
            newNode->next = currNode;
            newNode->back = currNode->back;

            currNode->back->next = newNode;
            currNode->back = newNode;
            listSize++;
        }
    }
// name:      insertInOrder
// purpose:   to insert a character in the right spot in an 
//            alphabetically sorted LinkedList
// arguments: character to insert
// returns:   none
// effects:   none
    void CharLinkedList::insertInOrder(char c){
        if(isEmpty()){
            // std::cerr << "isEmpty case for inserting " << c << std::endl;
            end = new Node(c,nullptr,nullptr);
            front = end;
            listSize++;
        }
        else{
            int i = 0;
            Node* currNode = front;
            while(c > currNode->info){
                currNode = currNode->next;
                i++;
            }
            insertAt(c,i);
        }
    }
// name:      popFromFront
// purpose:   to remove element from the front of the LinkedList
// arguments: none
// returns:   none
// effects:   none
    void CharLinkedList::popFromFront(){
        if(isEmpty()){
            throw std::runtime_error("cannot pop from empty LinkedList");
        }
        else if(listSize == 1){
            delete front;
            front = nullptr;
            end = front;
            listSize = 0;
        }
        else{
            Node* currNode = front;
            front->next->back = nullptr;
            front = front->next;
            delete currNode;
            listSize--;
        }
    }
// name:      popFromBack
// purpose:   to remove the element from the back of the LinkedList
// arguments: none
// returns:   none
// effects:   none
    void CharLinkedList::popFromBack(){
        if(isEmpty()){
            throw std::runtime_error("cannot pop from empty LinkedList");
        }
        else if(listSize == 1){
            delete front;
            front = nullptr;
            end = front;
            listSize = 0;
        }
        else{
            Node* currNode = end;
            end->back->next = nullptr;
            end = end->back;
            delete currNode;
            listSize--;
        }
    }
// name:      removeAt
// purpose:   to remove the element at specified index
// arguments: index to remove from
// returns:   none
// effects:   throws a range error if index is outside linkedlists range
    void CharLinkedList::removeAt(int index){
        if(index > listSize - 1 or index < 0){
            std::string message = "index (" + std::to_string(index);
            std::string message1  = ") not in range [0..";
            std::string message2 = std::to_string(listSize) + ")";
            throw std::range_error(message + message1 + message2);
        }
        if(index == 0){
            popFromFront();
        }
        else if(index == listSize - 1){
            popFromBack();
        }
        else{
            Node* currNode = findNode(front,index);
            currNode->next->back = currNode->back;
            currNode->back->next = currNode->next;
            delete currNode;
            listSize--;
        }
    }
// name:      replaceAt
// purpose:   replaces element at specified index with new element
// arguments: given new element and specified index
// returns:   none
// effects:   range error if index is outside linkedlists range
    void CharLinkedList::replaceAt(char c, int index){
        if(index > listSize - 1 or index < 0){
            std::string message = "index (" + std::to_string(index);
            std::string message1  = ") not in range [0..";
            std::string message2 = std::to_string(listSize) + ")";
            throw std::range_error(message + message1 + message2);
        }
        findNode(front,index)->info = c;
    }
// name:      concatenate
// purpose:   to add an LinkedList onto the back of another LinkedList
// arguments: a pointer to the other LinkedList
// returns:   none
// effects:   none
    void CharLinkedList::concatenate(CharLinkedList *other){
        // Node* currNode = other->front;
        int otherSize = other->size();
        for(int i = 0; i < otherSize; i++){
            pushAtBack(other->elementAt(i));
            // std::cout << other->size() << std::endl;
            // std::cout << other->elementAt(i) << std::endl;
            // currNode = currNode->next;
        }
    }
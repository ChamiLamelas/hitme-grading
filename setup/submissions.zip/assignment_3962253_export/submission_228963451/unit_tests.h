/*
 *  unit_tests.h
 *  Wilson
 *  Wu
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  Contains all the unit tests for this homework/program. Their are an 
 *  extensive amount of tests for the functions used
 */


#include "CharLinkedList.h"
#include <cassert>

void test(){}

void clearEmpty_test(){
    CharLinkedList test_list;
    test_list.clear();

    assert(test_list.isEmpty());
}

// Tests correct insertion into an empty AL.
// Afterwards, size should be 1 and element at index 0
// should be the element we inserted.
void insertAt_empty_correct() { 

    CharLinkedList test_list;
    test_list.insertAt('a', 0);

    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');

}

// Tests incorrect insertion into an empty AL.
// Attempts to call insertAt for index larger than 0.
// This should result in an std::range_error being raised.
void insertAt_empty_incorrect() {

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    // insertAt for out-of-range index
    test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
    // if insertAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    range_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0]");
    
}

// Tests correct insertAt for front of 1-element list.
void insertAt_front_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at front
    test_list.insertAt('b', 0);

    // std::cerr << test_list.toString() << std::endl;

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'a');
    
}

// Tests correct insertAt for back of 1-element list.
void insertAt_back_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at back
    test_list.insertAt('b', 1);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    
}

// Tests calling insertAt for a large number of elements.
// Not only does this test insertAt, it also checks that
// array expansion works correctly.
void insertAt_many_elements() {
    
    CharLinkedList test_list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.insertAt('a', i);
    }

    assert(test_list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
    
}

// Tests insertion into front of a larger list
void insertAt_front_large_list() {
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    test_list.insertAt('y', 0);

    assert(test_list.size() == 10);
    assert(test_list.elementAt(0) == 'y');
    // std::cout << "we are printing out testList" << test_list.toString();
    assert(test_list.toString()=="[CharLinkedList of size 10 <<yabczdefgh>>]");

}

// Tests insertion into the back of a larger list
void insertAt_back_large_list() {

    char test_arr[10] = { 'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 10);  

    test_list.insertAt('x', 10);

    assert(test_list.size() == 11);
    assert(test_list.elementAt(10) == 'x');
    assert(test_list.toString() == 
    "[CharLinkedList of size 11 <<yabczdefghx>>]"); 

}

// Tests insertion into the middle of a larger list
void insertAt_middle_large_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.insertAt('z', 3);

    assert(test_list.size() == 9);
    assert(test_list.elementAt(3) == 'z');
    assert(test_list.toString() == "[CharLinkedList of size 9 <<abczdefgh>>]");

}

// Tests out-of-range insertion for a non-empty list.
void insertAt_nonempty_incorrect() {
   
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8]");
    
}



void removeAt_test() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.removeAt(3);

    assert(test_list.size() == 7);
    assert(test_list.elementAt(3) == 'e');
    assert(test_list.toString() == "[CharLinkedList of size 7 <<abcefgh>>]");
}

void removeAtFront_test(){
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.removeAt(0);

    assert(test_list.size() == 7);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.toString() == "[CharLinkedList of size 7 <<bcdefgh>>]");
}

void removeAtBack_test(){
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.removeAt(7);

    assert(test_list.size() == 7);
    assert(test_list.last() == 'g');
    assert(test_list.toString() == "[CharLinkedList of size 7 <<abcdefg>>]");
}

void removeAtEmpty_test(){
    CharLinkedList test_list;

    bool range_error_thrown = false;

    std::string error_message = "";

    try {
    test_list.removeAt(0);
    }
    catch (const std::range_error &e) {
    range_error_thrown = true;
    error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (0) not in range [0..0)");

}

void replaceAt_test() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.replaceAt('x',3);

    assert(test_list.size() == 8);
    assert(test_list.elementAt(3) == 'x');
    assert(test_list.toString() == "[CharLinkedList of size 8 <<abcxefgh>>]");
}



void concatenate_test() {
    char test_arr1[2] = {'x','y'};
    char test_arr2[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list1(test_arr1, 2);
    CharLinkedList test_list2(test_arr2, 8);

    test_list1.concatenate(&test_list2);

    assert(test_list1.size() == 10);
    assert(test_list1.elementAt(0) == 'x');
    assert(test_list1.elementAt(2) == 'a');
    std::string message = "[CharLinkedList of size 10 <<xyabcdefgh>>]";
    assert(test_list1.toString() == message);
}



void concatenateItself_test() {
    char test_arr1[2] = {'x','y'};
    CharLinkedList test_list1(test_arr1, 2);

    test_list1.concatenate(&test_list1);

    // std::cerr << test_list1.toString() << std::endl;

    assert(test_list1.size() == 4);
    assert(test_list1.elementAt(0) == 'x');
    assert(test_list1.elementAt(2) == 'x');
    std::string message = "[CharLinkedList of size 4 <<xyxy>>]";
    assert(test_list1.toString() == message);
}



void insertInOrder_test() {
    char test_arr[4] = {'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 4);

    test_list.insertInOrder('a');

    assert(test_list.toString() == "[CharLinkedList of size 5 <<aefgh>>]");
    
    test_list.insertInOrder('f');

    assert(test_list.toString() == "[CharLinkedList of size 6 <<aeffgh>>]");
                                    
}

void clear_test() {
    char test_arr[4] = {'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 4);

    test_list.clear();

    assert(test_list.toString() == "[CharLinkedList of size 0 <<>>]");
    assert(test_list.isEmpty());
    
}

void operator_test() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    char test_arr1[2] = {'x','y'};
    CharLinkedList test_list(test_arr, 8);
    CharLinkedList test_list1(test_arr1, 2);

    test_list = test_list1;

    // std::cout << test_list.toString() << test_list1.toString();
    assert(test_list.toString() ==  test_list1.toString());
    
}

void popFromBack_empty_test(){
    // var to track whether range_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    // insertAt for out-of-range index
    test_list.popFromBack();
    }
    catch (const std::runtime_error &e) {
    // if insertAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    runtime_error_thrown = true;
    error_message = e.what();
    }

    // std::cerr << error_message << std::endl;
    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

void popFromFront_test(){
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr,8);

    test_list.popFromFront();

    assert(test_list.toString() == "[CharLinkedList of size 7 <<bcdefgh>>]");
}
void popFromBack_test(){
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr,8);

    test_list.popFromBack();

    assert(test_list.toString() == "[CharLinkedList of size 7 <<abcdefg>>]");
}

void popFromFront_empty_test(){
    // var to track whether range_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    // insertAt for out-of-range index
    test_list.popFromFront();
    }
    catch (const std::runtime_error &e) {
    // if insertAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    runtime_error_thrown = true;
    error_message = e.what();
    }

    // std::cerr << error_message << std::endl;
    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

void first_test(){
    char test_arr[3] = {'t','a','l'};
    CharLinkedList test_list(test_arr,3);
    
    assert(test_list.first() == 't');
}

void last_test(){
    char test_arr[3] = {'t','a','l'};
    CharLinkedList test_list(test_arr,3);
    
    assert(test_list.last() == 'l');
}

void copyConstructor_test(){
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr,8);
    CharLinkedList test_list_copy(test_list);

    assert(test_list.toString() == test_list_copy.toString());
}


void elementAtEmpty_test(){
    CharLinkedList test_list;
    
    bool range_error_thrown = false;

    std::string error_message = "";

    try {
    test_list.elementAt(30);
    }
    catch (const std::range_error &e) {
    range_error_thrown = true;
    error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (30) not in range [0..0)");
}

void elementAt_test(){
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr,8);

    assert(test_list.elementAt(3) == 'd');
}


void elementAt_errorTest(){
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr,8);

    bool range_error_thrown = false;

    std::string error_message = "";

    try {
    test_list.elementAt(30);
    }
    catch (const std::range_error &e) {
    range_error_thrown = true;
    error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (30) not in range [0..8)");
}

void elementAtNegative_errorTest(){
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr,8);

    bool range_error_thrown = false;

    std::string error_message = "";

    try {
    test_list.elementAt(-1);
    }
    catch (const std::range_error &e) {
    range_error_thrown = true;
    error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (-1) not in range [0..8)");
}

void removeAtSize_errorTest(){
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr,8);

    bool range_error_thrown = false;

    std::string error_message = "";

    try {
    test_list.elementAt(-1);
    }
    catch (const std::range_error &e) {
    range_error_thrown = true;
    error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (-1) not in range [0..8)");
}

void elementAtSize_errorTest(){
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr,8);

    bool range_error_thrown = false;

    std::string error_message = "";

    try {
    test_list.elementAt(8);
    }
    catch (const std::range_error &e) {
    range_error_thrown = true;
    error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (8) not in range [0..8)");
}

void replaceAtSize_errorTest(){
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr,8);

    bool range_error_thrown = false;

    std::string error_message = "";

    try {
    test_list.replaceAt('c',8);
    }
    catch (const std::range_error &e) {
    range_error_thrown = true;
    error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (8) not in range [0..8)");
}

void insertAtSize_errorTest(){
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr,8);

    bool range_error_thrown = false;

    std::string error_message = "";

    try {
    test_list.insertAt('c',9);
    }
    catch (const std::range_error &e) {
    range_error_thrown = true;
    error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (9) not in range [0..8]");
}


void removeAt_errorTest(){
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr,8);

    bool range_error_thrown = false;

    std::string error_message = "";

    try {
    test_list.removeAt(30);
    }
    catch (const std::range_error &e) {
    range_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (30) not in range [0..8)");
}


void replaceAt_errorTest(){
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr,8);

    bool range_error_thrown = false;

    std::string error_message = "";

    try {
    test_list.replaceAt('c',30);
    }
    catch (const std::range_error &e) {
    range_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (30) not in range [0..8)");
}


void toReverseString_test(){
    char test_arr[5] = {'d', 'e', 'f', 'g'};
    CharLinkedList test_list(test_arr,4);

    assert(test_list.toReverseString()=="[CharLinkedList of size 4 <<gfed>>]");
}

void toString_test(){
    char test_arr[5] = {'A','l','i','c','e'};
    CharLinkedList test_list(test_arr,5);

    assert(test_list.toString() == "[CharLinkedList of size 5 <<Alice>>]");
}

void clear_empty_test(){
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr,5);

    test_list.clear();

    assert(test_list.isEmpty());
}

void size_test(){
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr,8);

    // std::cerr << "Full String" << test_list.toString();
    // std::cout << test_list.size();

    assert(test_list.size() == 8);
}

void constructor_test(){
    char test_arr[3] = {'a','b','c'};
    CharLinkedList test_list(test_arr,3);

    // std::cerr << "The first character: " << test_list.first() << std::endl;
    assert(test_list.first() == 'a');
}

void defaultConstructor_test(){
    CharLinkedList test_list;
    
    assert(test_list.isEmpty());
}

void singletonConstructor_test(){
    CharLinkedList test_list('a');

    assert(test_list.first() == 'a');
    assert(test_list.size() == 1);
}

void doubletonConstructor_test(){
    char test_arr[2] = {'a','b'};
    CharLinkedList test_list(test_arr,3);


    assert(test_list.first() == 'a');
}

void firstEmpty_test(){
    CharLinkedList test_list;
    bool runtime_error_thrown = false;

    std::string error_message = "";

    try {
    test_list.first();
    }
    catch (const std::runtime_error &e) {
    runtime_error_thrown = true;
    error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot get first of empty LinkedList");
}

void lastEmpty_test(){
    CharLinkedList test_list;
    bool runtime_error_thrown = false;

    std::string error_message = "";

    try {
    test_list.last();
    }
    catch (const std::runtime_error &e) {
    runtime_error_thrown = true;
    error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot get last of empty LinkedList");
}

void concatenateEmptyEmpty_test() {
    CharLinkedList test_list1;
    CharLinkedList test_list2;

    test_list1.concatenate(&test_list2);

    assert(test_list1.size() == 0);
    std::string message = "[CharLinkedList of size 0 <<>>]";
    assert(test_list1.toString() == message);
}




// Tests correct insertAt for front of 1-element list.
void removeAt_front_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at front
    test_list.removeAt(0);

    // std::cerr << test_list.toString() << std::endl;

    assert(test_list.size() == 0);
}

// Tests calling insertAt for a large number of elements.
// Not only does this test insertAt, it also checks that
// array expansion works correctly.
void removeAt_many_elements() {
    
    CharLinkedList test_list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.insertAt('a', i);
    }

    assert(test_list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }

    test_list.removeAt(2);

    assert(test_list.size() == 999);   
}

// Tests insertion into front of a larger list
void removeAt_front_large_list() {
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    test_list.removeAt(0);

    assert(test_list.size() == 8);
    // std::cout << "we are printing out testList" << test_list.toString();
    assert(test_list.toString()=="[CharLinkedList of size 8 <<bczdefgh>>]");

}

// Tests insertion into the back of a larger list
void removeAt_back_large_list() {

    char test_arr[10] = { 'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 10);  

    test_list.removeAt(9);

    assert(test_list.size() == 9);
    assert(test_list.toString() == "[CharLinkedList of size 9 <<yabczdefg>>]"); 

}

// Tests insertion into the middle of a larger list
void removeAt_middle_large_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.removeAt(3);

    assert(test_list.size() == 7);
    assert(test_list.toString() == "[CharLinkedList of size 7 <<abcefgh>>]");

}



void elementAt_front_singleton_list() {
    CharLinkedList test_list('a');

    assert(test_list.elementAt(0) == 'a');
}


// Tests insertion into front of a larger list
void elementAt_large_list() {
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(8) == 'h');
    assert(test_list.elementAt(3) == 'z');
}

// Tests correct insertAt for front of 1-element list.
void replaceAt_front_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at front
    test_list.replaceAt('b',0);

    // std::cerr << test_list.toString() << std::endl;

    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'b');
}

// Tests calling insertAt for a large number of elements.
// Not only does this test insertAt, it also checks that
// array expansion works correctly.
void replaceAt_many_elements() {
    
    CharLinkedList test_list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.insertAt('a', i);
    }

    assert(test_list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }

    test_list.replaceAt('b',2);

    assert(test_list.elementAt(2) == 'b');
}

// Tests insertion into front of a larger list
void removeAt_large_list() {
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    test_list.replaceAt('z',0);
    test_list.replaceAt('a',8);
    test_list.replaceAt('d',3);

    // std::cout << "we are printing out testList" << test_list.toString();
    assert(test_list.toString()=="[CharLinkedList of size 9 <<zbcddefga>>]");

}

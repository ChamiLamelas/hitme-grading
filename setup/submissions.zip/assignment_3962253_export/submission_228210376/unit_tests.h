/*
 *  unit_tests.h
 *  Tianhong Feng (tfeng01)
 *  2024.2.4
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  Purpose: Test each functions to make sure that they are well written
 *
 */

#include "CharLinkedList.h"
#include <cassert>

// Test no fatal errors/memory leaks in the default constructor one
void constructor_test_memoryLeak_1() 
{
    CharLinkedList test_list;
}

// Test no items exist in the list upon construction, in constructor one
void constructor_test_1() 
{
    CharLinkedList test_list; 
    assert(test_list.size() == 0);
}

// Test no fatal errors/memory leaks in the default constructor two
void constructor_test_memoryLeak_2() 
{
    CharLinkedList test_list('a');
}

// Test number of elements in the list upon construction, in constructor two
void constructor_test_2() 
{
    CharLinkedList test_list('a');
    assert(test_list.size() == 1);
    assert(test_list.first() == 'a');
    assert(test_list.last() == 'a');
}

// Test no fatal errors/memory leaks in the default constructor three
void constructor_test_memoryLeak_3() 
{
    char test_arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);
}

// Test number of elements in the list upon construction, in constructor three
void constructor_test_3() 
{
    char test_arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);
    assert(test_list.size() == 8);
    assert(test_list.first() == 'a');
    assert(test_list.last() == 'h');
}

// Test adding an size non-positive array
// It should return an empty list
void constructor_test_3_empty() 
{
    char test_arr[0];
    CharLinkedList test_list(test_arr, 0);
    assert(test_list.isEmpty());
}

// Test no fatal errors/memory leaks in the default constructor four when
// copying a not empty CharLinkedList
void constructor_test_memoryLeak_4() 
{
    char test_arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList original_list(test_arr, 8);
    CharLinkedList test_list(original_list);
}

// Test no fatal errors/memory leaks in the default constructor four when
// copying an empty CharArrayList
void constructor_test_memoryLeak_4_empty() 
{
    CharLinkedList original_list;
    CharLinkedList test_list(original_list);
}

// Test number in the list upon construction, in constructor four, when
// copying a not empty CharArrayList
void constructor_test_4() 
{
    char test_arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList original_list(test_arr, 8);
    CharLinkedList test_list(original_list);
    assert(test_list.size() == 8);
    assert(test_list.first() == 'a');
    assert(test_list.last() == 'h');
}

// Test number in the list upon construction, in constructor four, when
// copying an empty CharArrayList
void constructor_test_4_empty() 
{
    CharLinkedList original_list;
    CharLinkedList test_list(original_list);
    assert(test_list.size() == 0);
}

// Test operator when there are two non empty CharLinkedList
void operator_test()
{
    char test_arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList original_list(test_arr, 8);
    char test_arr_1[4] = {'A', 'B', 'C', 'D' };
    CharLinkedList new_list(test_arr_1, 4);
    original_list = new_list;
    assert(original_list.size() == 4);
    assert(original_list.first() == 'A');
    assert(original_list.last() == 'D');
}

// Test operator when there is one empty CharLinkedList
void operator_test_2()
{
    char test_arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList original_list(test_arr, 8);
    CharLinkedList new_list;
    original_list = new_list;
    assert(original_list.isEmpty());
}

// Test operator when there is one empty CharLinkedList
void operator_test_3()
{
    char test_arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList new_list(test_arr, 8);
    CharLinkedList original_list;
    original_list = new_list;
    assert(not original_list.isEmpty());
    assert(original_list.last() == 'h');
}

// Test operator when copying itself
void operator_test_self()
{
    char test_arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);
    test_list = test_list;
    assert(test_list.last() == 'h');

}

// Test that checks if the CharLinkedList is empty
// The Empty function should return true
void isEmpty_test_correct() 
{
    CharLinkedList test_list;
    assert(test_list.isEmpty());
}

// Test that checks if the CharLinkedList is not empty
// The Empty function should return false
void isEmpty_test_incorrect() 
{
    CharLinkedList test_list('a');
    assert(not test_list.isEmpty());
}

// Test whether the clear function makes the CharLinkedList empty when it
// originially is not empty
void clear_test_origin_not_empty() 
{
    char test_arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);
    test_list.clear();
    assert(test_list.isEmpty());
}

// Test whether the clear function makes the CharLinkedList empty when it
// originially is empty
void clear_test_origin_empty() 
{
    CharLinkedList test_list;
    test_list.clear();
    assert(test_list.isEmpty());
}

// Test finding the size of the CharLinkedList when Linksize is zero
void size_test_zero() 
{
    CharLinkedList test_list; 
    assert(test_list.isEmpty());
    assert(test_list.size() == 0);
}

// Test finding the size of the CharLinkedList when Linksize is not zero
void size_test_non_zero() 
{
    CharLinkedList test_list('a');
    assert(test_list.size() == 1);
}

// Test finding the size of the CharLinkedList when Linksize is large
void size_test_large() 
{
    char test_arr[11] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h','i' ,'j','k'};
    CharLinkedList test_list(test_arr, 11);
    assert(test_list.size() == 11);
}

// Test to find the first character when the CharLinkedList is empty
// This should result in an std::runtime_error being raised.
void first_test_incorrect() 
{
// var to track whether range_error is thrown
    bool runtime_error_thrown = false;

// var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
        test_list.first();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "cannot get first of empty LinkedList");
}

// Test correct finding the first character in the CharLinkedList
// The first element should be the element we inserted, which is 'h'
void first_test_correct() 
{
    char test_arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);
    assert(test_list.first() == 'a');
}

// Test correct finding the first character in the CharLinkedList, when there 
// is only one element in the CharLinkedList
// The first element should be the element we inserted, which is 'a'
void first_test_correct_oneElement() 
{
    char test_arr[1] = { 'a'};
    CharLinkedList test_list(test_arr, 1);
    assert(test_list.first() == 'a');
}

// Test to find the first character when the CharLinkedList is empty
// This should result in an std::runtime_error being raised.
void last_test_incorrect() 
{
// var to track whether range_error is thrown
    bool runtime_error_thrown = false;

// var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
        test_list.last();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "cannot get last of empty LinkedList");
}

// Test correct finding the last character in the CharLinkedList
// Afterwards, the last element should be the element we inserted, which is 'h'
void last_test_correct() 
{
    char test_arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);
    assert(test_list.last() == 'h');
}

// Test correct finding the last character in the CharLinkedList, when there 
// is only one element in the CharLinkedList
// The last element should be the element we inserted, which is 'a'
void last_test_correct_oneElement() 
{
    char test_arr[1] = {'a'};
    CharLinkedList test_list(test_arr, 1);
    assert(test_list.first() == 'a');
}

// Tests correct finding in an not empty CharLinkedList.
void elementAt_non_empty_correct() 
{ 
    char test_arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);
    assert(test_list.size() == 8);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    assert(test_list.elementAt(2) == 'c');
    assert(test_list.elementAt(7) == 'h');
}

// Tests correct finding in an not empty CharLinkedList.
void elementAt_correct_oneElement() 
{ 
    char test_arr[1] = {'a'};
    CharLinkedList test_list(test_arr, 1);
    assert(test_list.elementAt(0) == 'a');
}

// Tests incorrect finding into an empty CharLinkedList.
// Attempts to call elementAt for index larger than 0.
// This should result in an std::range_error being raised.
void elementAt_empty_incorrect() 
{

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    test_list.elementAt(1);
    }
    catch (const std::range_error &e) {
    // if elementAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    range_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (1) not in range [0..0)");
    
}

// Tests incorrect finding into an empty CharLinkedList.
// Attempts to call elementAt for index 0.
// This should result in an std::range_error being raised.
void elementAt_empty_incorrect_zero() 
{

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    test_list.elementAt(0);
    }
    catch (const std::range_error &e) {
    // if elementAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    range_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (0) not in range [0..0)");
    
}

// Tests out-of-range finding for a non-empty CharLinkedList.
void elementAt_nonempty_incorrect() 
{
   
    char test_arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.elementAt(-7);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (-7) not in range [0..8)");
}

// Test the tostring function with an empty CharLinkedList
// Afterwards, the empty CharLinkedList would be formatted like this:
// [CharLinkedList of size 0 <<>>]
void tostring_empty_test() 
{
    CharLinkedList test_list; 
    assert(test_list.toString() == "[CharLinkedList of size 0 <<>>]");
}

// Test the tostring function with an not empty CharLinkedList
// Afterwards, the non empty CharLinkedList would be formatted like this:
// [CharLinkedList of size 5 <<Alice>>]
void tostring_non_empty_test() 
{
    char test_arr[5] = {'A', 'l', 'i', 'c', 'e'};
    CharLinkedList test_list(test_arr, 5);
    assert(test_list.toString() == "[CharLinkedList of size 5 <<Alice>>]");
}

// Test the toReverseString function with an empty CharLinkedList
// Afterwards, the empty CharLinkedList would be formatted like this:
// [CharLinkedList of size 0 <<>>]
void toReverseString_empty_test() 
{
    CharLinkedList test_list; 
    assert(test_list.toReverseString() == "[CharLinkedList of size 0 <<>>]");
}

// Test the toReverseString function with a not empty CharLinkedList
// Afterwards, the non empty CharLinkedList would be formatted like this:
// [CharLinkedList of size 5 <<ecilA>>]
void toReverseString_non_empty_test() 
{
    char test_arr[5] = {'A', 'l', 'i', 'c', 'e'};
    CharLinkedList list(test_arr, 5);
    assert(list.toReverseString() == "[CharLinkedList of size 5 <<ecilA>>]");
}

// Test the toReverseString function with a one element CharLinkedList
// Afterwards, the non empty CharLinkedList would be formatted like this:
// [CharLinkedList of size 1 <<e>>]
void toReverseString_one_element() 
{
    char test_arr[1] = {'e'};
    CharLinkedList list(test_arr, 1);
    assert(list.toReverseString() == "[CharLinkedList of size 1 <<e>>]");
}

// Test the toReverseString function with other character
// Afterwards, the non empty CharLinkedList would be formatted like this:
// [CharLinkedList of size 2 <<!e>>]
void toReverseString_other_character() 
{
    char test_arr[2] = {'e','!'};
    CharLinkedList list(test_arr, 2);
    assert(list.toReverseString() == "[CharLinkedList of size 2 <<!e>>]");
}

// Test pushAtBack function with an empty CharLinkedList
// Afterwards, the size of the CharLinkedList should be 1 and the element 
// should be the one we inserted.
void pushAtBack_empty_test() 
{
    CharLinkedList test_list; 
    test_list.pushAtBack('a');
    assert(test_list.size() == 1);
    assert(test_list.last() == 'a');
}

// Test pushAtBack function with a not empty CharLinkedList
void pushAtBack_non_empty_test() 
{
    char test_arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);
    test_list.pushAtBack('i');
    assert(test_list.size() == 9);
    assert(test_list.last() == 'i');
}

// Tests calling pushAtBack for a large number of elements.
void pushAtBack_many_elements() 
{
    
    CharLinkedList test_list;

    // Add 1000 elements
    for (int i = 0; i < 1000; i++) {
        test_list.pushAtBack('a');
    }

    assert(test_list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
}

// Test pushAtFront function with an empty CharLinkedList
// Afterwards, the size of the CharLinkedList should be 1 and the element 
// should be the one we inserted.
void pushAtFront_empty_test() 
{
    CharLinkedList test_list; 
    test_list.pushAtFront('a');
    assert(test_list.size() == 1);
    assert(test_list.first() == 'a');
}

// Test pushAtFront function with a not empty CharLinkedList
void pushAtFront_non_empty_test() 
{
    char test_arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);
    test_list.pushAtFront('i');
    assert(test_list.size() == 9);
    assert(test_list.first() == 'i');
}

// Tests calling pushAtFront for a large number of elements.
void pushAtFront_many_elements() 
{
    
    CharLinkedList test_list;

    // Add 1000 elements
    for (int i = 0; i < 1000; i++) {
        test_list.pushAtFront('a');
    }

    assert(test_list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
}

// Tests correct insertion into an empty CharLinkedList.
// Afterwards, size should be 1 and element at index 0
// should be the element we inserted.
void insertAt_empty_correct() 
{ 

    CharLinkedList test_list;
    test_list.insertAt('a', 0);
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');

}

// Tests incorrect insertion into an empty CharLinkedList.
// Attempts to call insertAt for index larger than 0.
// This should result in an std::range_error being raised.
void insertAt_empty_incorrect() 
{

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    // insertAt for out-of-range index
    test_list.insertAt('a', 1);
    }
    catch (const std::range_error &e) {
    // if insertAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    range_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (1) not in range [0..0]");
    
}

// Tests correct insertAt for front of 1-element list.
void insertAt_front_singleton_list() 
{
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at front
    test_list.insertAt('b', 0);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'a');
    
}

// Tests correct insertAt for back of 1-element list.
void insertAt_back_singleton_list() 
{
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at back
    test_list.insertAt('b', 1);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    
}

// Tests calling insertAt for a large number of elements.
// Not only does this test insertAt, it also checks that
// array expansion works correctly.
void insertAt_many_elements() 
{
    
    CharLinkedList test_list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.insertAt('a', i);
    }

    assert(test_list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
    
}

// Tests insertion into front of a larger list
void insertAt_front_large_list() 
{
    char test_arr[9] = {'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    test_list.insertAt('y', 0);

    assert(test_list.size() == 10);
    assert(test_list.elementAt(0) == 'y');
    assert(test_list.toString() == 
    "[CharLinkedList of size 10 <<yabczdefgh>>]");

}

// Tests insertion into the back of a larger list
void insertAt_back_large_list() 
{

    char test_arr[10] = {'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 10);  

    test_list.insertAt('x', 10);

    assert(test_list.size() == 11);
    assert(test_list.elementAt(10) == 'x');
    assert(test_list.toString() == 
    "[CharLinkedList of size 11 <<yabczdefghx>>]"); 

}

// Tests insertion into the middle of a larger list
void insertAt_middle_large_list() 
{
    char test_arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.insertAt('z', 3);

    assert(test_list.size() == 9);
    assert(test_list.elementAt(3) == 'z');
    assert(test_list.toString() == "[CharLinkedList of size 9 <<abczdefgh>>]");

}

// Tests out-of-range insertion for a non-empty list.
void insertAt_nonempty_incorrect() 
{
   
    char test_arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.insertAt('a', -1);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (-1) not in range [0..8]");
    
}

// Test the insertInOrder function when all letters are capitalized
void insertInOrder_test_capitalized() 
{
    char test_arr[5] = {'A', 'B', 'D', 'E', 'F'};
    CharLinkedList test_list(test_arr, 5);
    test_list.insertInOrder('C');
    assert(test_list.size() == 6);
    assert(test_list.elementAt(2) == 'C');

    char test_arr_2[3] = {'Z', 'E', 'D'};
    CharLinkedList test_list_2(test_arr_2, 3);
    test_list_2.insertInOrder('A');
    assert(test_list_2.size() == 4);
    assert(test_list_2.elementAt(0) == 'A');
}

// Test the insertInOrder function when the new element should be put in 
// the front
void insertInOrder_test_front() 
{
    char test_arr[5] = {'E', 'F', 'G', 'H', 'I'};
    CharLinkedList test_list(test_arr, 5);
    test_list.insertInOrder('C');
    assert(test_list.size() == 6);
    assert(test_list.elementAt(0) == 'C');
}

// Test the insertInOrder function when the new element should be put in 
// the end
void insertInOrder_test_last() 
{
    char test_arr[5] = {'E', 'F', 'G', 'H', 'I'};
    CharLinkedList test_list(test_arr, 5);
    test_list.insertInOrder('J');
    assert(test_list.size() == 6);
    assert(test_list.elementAt(5) == 'J');
}

// Test the insertInOrder function when all letters are not capitalized
void insertInOrder_test_not_capitalized()
{
    char test_arr[5] = {'a', 'b', 'd', 'e', 'f'};
    CharLinkedList test_list(test_arr, 5);
    test_list.insertInOrder('c');
    assert(test_list.size() == 6);
    assert(test_list.elementAt(2) == 'c');

    char test_arr_2[3] = {'a', 'z', 'g'};
    CharLinkedList test_list_2(test_arr_2, 3);
    test_list_2.insertInOrder('e');
    assert(test_list_2.size() == 4);
    assert(test_list_2.elementAt(1) == 'e');
    assert(test_list_2.elementAt(0) == 'a');
    assert(test_list_2.elementAt(3) == 'g');
}

// Test the insertInOrder function when part of the letters are capitalized
// and part or them are not
void insertInOrder_test_part_capitalized() 
{
    char test_arr[5] = {'A', 'B', 'D', 'E', 'F'};
    CharLinkedList test_list(test_arr, 5);
    test_list.insertInOrder('c');
    assert(test_list.size() == 6);
    assert(test_list.elementAt(5) == 'c');
}

// Test the insertInOrder function when part of the letters are in ASCII 
// sequence
void insertInOrder_part_ASCII()
{
    char test_arr_2[3] = { 'z', 'E', 'g'};
    CharLinkedList test_list_2(test_arr_2, 3);
    test_list_2.insertInOrder('a');
    assert(test_list_2.size() == 4);
    assert(test_list_2.elementAt(0) == 'a');
}

// Test incorrect removement from an empty CharLinkedList. (popFromFront)
// This should result in an std::runtime_error being raised.
void popFromFront_test_incorrect() 
{
// var to track whether range_error is thrown
    bool runtime_error_thrown = false;

// var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
        test_list.popFromFront();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

// Test correct removement from a more than one elements CharLinkedList. 
// (popFromFront)
void popFromFront_correct_more() 
{
    char test_arr[5] = {'A', 'B', 'D', 'E', 'F'};
    CharLinkedList test_list(test_arr, 5);
    test_list.popFromFront();
    assert(test_list.size() == 4);
    assert(test_list.last() == 'F');
    assert(test_list.first() == 'B');
}

// Test correct removement from a one element CharLinkedList. (popFromFront)
void popFromFront_correct_one() 
{
    char test_arr[1] = {'A'};
    CharLinkedList test_list(test_arr, 1);
    test_list.popFromFront();
    assert(test_list.size() == 0);
    assert(test_list.isEmpty());
}

// Test incorrect removement from an empty CharLinkedList. (popFromBack)
// This should result in an std::runtime_error being raised.
void popFromBack_test_incorrect() 
{
// var to track whether range_error is thrown
    bool runtime_error_thrown = false;

// var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
        test_list.popFromBack();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

// Test correct removement from a more than one elements CharLinkedList. 
// (popFromFront)
void popFromBack_test_correct() 
{
    char test_arr[5] = {'A', 'B', 'D', 'E', 'F'};
    CharLinkedList test_list(test_arr, 5);
    test_list.popFromBack();
    assert(test_list.size() == 4);
    assert(test_list.last() == 'E');
    assert(test_list.first() == 'A');
}

// Test correct removement from a one element CharLinkedList. (popFromBack)
void popFromBack_correct_one() 
{
    char test_arr[1] = {'A'};
    CharLinkedList test_list(test_arr, 1);
    test_list.popFromBack();
    assert(test_list.size() == 0);
    assert(test_list.isEmpty());
}

// Test correct removement from a one element CharLinkedList. (removeAt)
void removeAt_one_correct() 
{
    char test_arr[1] = { 'A'};
    CharLinkedList test_list(test_arr, 1);
    test_list.removeAt(0); 
    assert(test_list.size() == 0);
    assert(test_list.isEmpty());
}

// Test correct removement from more than one elements CharLinkedList. 
// (removeAt)
void removeAt_non_empty_correct() 
{
    char test_arr[5] = { 'A', 'B', 'D', 'E', 'F'};
    CharLinkedList test_list(test_arr, 5);
    test_list.removeAt(0); 
    test_list.removeAt(3); 
    assert(test_list.size() == 3);
    assert(test_list.last() == 'E');
    assert(test_list.first() == 'B');
}

// Test correct removement from the front of the CharLinkedList. 
// (removeAt)
void removeAt_front_correct() 
{
    char test_arr[5] = { 'A', 'B', 'D', 'E', 'F'};
    CharLinkedList test_list(test_arr, 5);
    test_list.removeAt(0); 
    assert(test_list.size() == 4);
    assert(test_list.last() == 'F');
    assert(test_list.first() == 'B');
}

// Test correct removement from the back of the CharLinkedList. 
// (removeAt)
void removeAt_back_correct() 
{
    char test_arr[5] = { 'A', 'B', 'D', 'E', 'F'};
    CharLinkedList test_list(test_arr, 5);
    test_list.removeAt(4); 
    assert(test_list.size() == 4);
    assert(test_list.last() == 'E');
    assert(test_list.first() == 'A');
}


// Test incorrect removement from a not empty CharLinkedList. (removeAt)
void removeAt_non_empty_incorrect() 
{
// var to track whether range_error is thrown
    bool runrange_error_thrown = false;

// var to track any error messages raised
    std::string error_message = "";

    char test_arr[5] = { 'A', 'B', 'D', 'E', 'F'};
    CharLinkedList test_list(test_arr, 5);
    try {
        test_list.removeAt(-3);
    }
    catch (const std::range_error &e) {
        runrange_error_thrown = true;
        error_message = e.what();
    }
    assert(runrange_error_thrown);
    assert(error_message == "index (-3) not in range [0..5)");
}

// Test incorrect removement from an empty CharLinkedList. (removeAt)
void removeAt_empty_incorrect() 
{
// var to track whether range_error is thrown
    bool runrange_error_thrown = false;

// var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
        test_list.removeAt(0);
    }
    catch (const std::range_error &e) {
        runrange_error_thrown = true;
        error_message = e.what();
    }
    assert(runrange_error_thrown);
    assert(error_message == "index (0) not in range [0..0)");
}

// Test correct removement from more than one elemnts CharLinkedList. 
// (replaceAt)
void replaceAt_more_correct() 
{
    char test_arr[5] = { 'A', 'B', 'D', 'E', 'F'};
    CharLinkedList test_list(test_arr, 5);
    test_list.replaceAt('a', 0); 
    test_list.replaceAt('d', 2); 
    assert(test_list.size() == 5);
    assert(test_list.last() == 'F');
    assert(test_list.first() == 'a');
    assert(test_list.elementAt(2) == 'd');
}

// Test correct removement from a one elemnts CharLinkedList. (replaceAt)
void replaceAt_one_correct() 
{
    CharLinkedList test_list('A');
    test_list.replaceAt('a', 0); 
    assert(test_list.size() == 1);
    assert(test_list.last() == 'a');
}

// Test incorrect removement from an empty CharLinkedList. (replaceAt)
void replaceAt_empty_incorrect() 
{
// var to track whether range_error is thrown
    bool runrange_error_thrown = false;

// var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
        test_list.replaceAt('a', 0);
    }
    catch (const std::range_error &e) {
        runrange_error_thrown = true;
        error_message = e.what();
    }
    assert(runrange_error_thrown);
    assert(error_message == "index (0) not in range [0..0)");
}

// Test incorrect removement from a not empty CharLinkedList. (replaceAt)
void replaceAt_non_empty_incorrect() 
{
// var to track whether range_error is thrown
    bool runtime_error_thrown = false;

// var to track any error messages raised
    std::string error_message = "";

    char test_arr[5] = { 'A', 'B', 'D', 'E', 'F'};
    CharLinkedList test_list(test_arr, 5);
    try {
        test_list.replaceAt('a', 5);
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "index (5) not in range [0..5)");
}

// Test correct concatenation of two non empty CharLinkedList
void concatenate_non_empty() {
    char test_arr_1[5] = { 'A', 'B', 'C', 'D', 'E'};
    CharLinkedList first_list(test_arr_1, 5);
    char test_arr_2[5] = { 'a', 'b', 'c', 'd', 'e'};
    CharLinkedList second_list(test_arr_2, 5);

    first_list.concatenate(&second_list);
    assert(first_list.size() == 10);
    assert(first_list.last() == 'e');
    assert(first_list.first() == 'A');
}

// Test correct concatenation of one empty CharLinkedList
void concatenate_one_empty_1() {
    char test_arr_1[5] = { 'A', 'B', 'C', 'D', 'E'};
    CharLinkedList first_list(test_arr_1, 5);
    CharLinkedList second_list;

    first_list.concatenate(&second_list);
    assert(first_list.size() == 5);
    assert(first_list.last() == 'E');
    assert(first_list.first() == 'A');
}

// Test correct concatenation of one empty CharLinkedList
void concatenate_one_empty_2() {
    char test_arr_2[5] = { 'A', 'B', 'C', 'D', 'E'};
    CharLinkedList second_list(test_arr_2, 5);
    CharLinkedList first_list;

    first_list.concatenate(&second_list);
    assert(first_list.size() == 5);
    assert(first_list.last() == 'E');
    assert(first_list.first() == 'A');
}

// Test correct concatenation of itself
void concatenate_same() {
    char test_arr_1[5] = { 'A', 'B', 'C', 'D', 'E'};
    CharLinkedList first_list(test_arr_1, 5);

    first_list.concatenate(&first_list);
    assert(first_list.size() == 10);
    assert(first_list.elementAt(7) == 'C');
    assert(first_list.first() == 'A');
}

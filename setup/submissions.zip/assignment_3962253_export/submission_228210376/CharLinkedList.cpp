/*
 *  CharLinkedList.cpp
 *  Tianhong Feng (tfeng01)
 *  2024.2.3
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Purpose: Implementation of a simple doubly linked char list Class.
 *
 */

#include "CharLinkedList.h"
#include "stdexcept"
#include <sstream>

/*
 * Name:      First CharLinkedList default constructor
 * Purpose:   Initialize an empty CharLinkedList
 * Arguments: None
 * Returns:   None
 * Effects:   set size to 0 and make the front with nullptr
 */
CharLinkedList::CharLinkedList()
{
    front = nullptr;
    Linksize = 0;
}

/*
 * Name:      Second CharLinkedList default constructor
 * Purpose:   Initialize an empty CharLinkedList
 * Arguments: A single character
 * Returns:   None
 * Effects:   size to 1 (also updates the front pointer)
 */
CharLinkedList::CharLinkedList(char c)
{
    front = new Node(c, nullptr, nullptr);
    Linksize = 1;
}

/*
 * Name:      Third CharArrayList default constructor
 * Purpose:   Initialize an empty CharLinkedList
 * Arguments: An array of characters and the integer length of that array
 * Returns:   None
 * Effects:   Change Linksize to size (also updates pointers and elements)
 */
CharLinkedList::CharLinkedList(char arr[], int size)
{
    if (size <= 0)
    {
        front = nullptr;
        Linksize = 0;
    }
    else
    {
        front = new Node(arr[0]);
        Node *curr = front;
        for (int i = 1; i < size; i++)
        {
            curr->next = new Node(arr[i], nullptr, curr);
            curr->next->prev = curr;
            curr = curr->next;
        }
        Linksize = size;
        front->prev = nullptr;
    }
}

/*
 * Name:      Fourth CharLinkedList default constructor
 * Purpose:   Initialize an empty CharLinkedList
 * Arguments: A pointer to a new CharLinkedList
 * Returns:   None
 * Effects:   Change Linksize to new size (also updates pointers and elements)
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other) 
{
    front = copyCharLinkedList(other.front);
    Linksize = other.Linksize;
}

/*
 * Name:      CharLinkedList destructor
 * Purpose:   Free memory associated with the CharLinkedList
 * Arguments: None
 * Returns:   None
 * Effects:   Frees memory allocated by CharLinkedlist instances
 */
CharLinkedList::~CharLinkedList()
{
    recycRecursive(front);
}

/*
 * Name:      Assignment operator
 * Purpose:   Recycle the storage associated with the instance on the 
 *            left of the assignment and makes a deep copy of the instance on 
 *            the right hand side into the instance on the left hand side.
 * Arguments: None
 * Returns:   None
 * Effects:   Recycle the storage associated with the instance on the 
 *            left of the assignment and makes a deep copy of the instance on 
 *            the right hand side into the instance on the left hand side.
 */
CharLinkedList &CharLinkedList::operator = (const CharLinkedList &other) 
{
    if (&other == this)
    {
        return *this;
    }
    else
    {
        clear();
        front = copyCharLinkedList(other.front);
        Linksize = other.Linksize;
        return *this;
    }
}

/*
 * Name:      isEmpty
 * Purpose:   Determines if the CharLinkedList is empty or not
 * Arguments: None
 * Returns:   True if CharLinkedList contains no elements, false otherwise
 * Effects:   None
 */
bool CharLinkedList::isEmpty() const 
{
    return Linksize == 0;
}

/*
 * Name:      clear
 * Purpose:   Make the instance into an empty CharLinkedList
 * Arguments: None
 * Returns:   None
 * Effects:   Make the instance into an empty CharLinkedList
 */
void CharLinkedList::clear() 
{
    recycRecursive(front);
    front = nullptr;
    Linksize = 0;
}

/*
 * Name:      size
 * Purpose:   Determine the number of items in the CharLinkedList
 * Arguments: None
 * Returns:   Number of elements currently stored in the CharLinkedList
 * Effects:   None
 */
int CharLinkedList::size() const
{
    return Linksize;
}

/*
 * Name:      first
 * Purpose:   Get the first character in the char linked list
 * Arguments: None
 * Returns:   The first character in the char linked list
 * Effects:   None
 */
char CharLinkedList::first() const 
{
    if (isEmpty()) {
        throw std::runtime_error("cannot get first of empty LinkedList");
    }
    else {
        return front->data;
    }
}

/*
 * Name:      last
 * Purpose:   Get the last character in the char linked list
 * Arguments: None
 * Returns:   The last character in the char linked list
 * Effects:   None
 */
char CharLinkedList::last() const 
{
    if (isEmpty()) {
        throw std::runtime_error("cannot get last of empty LinkedList");
    }

    Node *curr = front;
    while (curr->next != nullptr)
    {
        curr = curr->next;
    }
    return curr->data;
}

/*
 * Name:      elementAt
 * Purpose:   Get the element in the CharLinkedList at specific index
 * Arguments: An integer index
 * Returns:   The element in the CharLinkedList at specific index
 * Effects:   None
 */
char CharLinkedList::elementAt(int index) const 
{
    if (index < 0 or index >= Linksize) {
        throw std::range_error("index (" + std::to_string(index) + 
        ") not in range [0.." + std::to_string(Linksize) + ")");
    }
    else {
        return elementAtRec(front, index, 0);
    }
}

/*
 * Name:      tostring
 * Purpose:   Get a string which contains the characters of the CharLinkedList
 * Arguments: None
 * Returns:   A string which contains the characters of the CharLinkedList
 * Effects:   None
 */
std::string CharLinkedList::toString() const 
{
    std::stringstream ss;
    ss << "[CharLinkedList of size " << Linksize << " <<";

    if (Linksize != 0 ) 
    {
        Node *curr = front;
        while (curr != nullptr) {
            ss << curr->data;
            curr = curr->next;
        }
    }

    ss << ">>]";
    return ss.str();
}

/*
 * Name:      toReverseString
 * Purpose:   Get a string which contains the characters of the CharLinkedList
 *            in reverse
 * Arguments: None
 * Returns:   A string which contains the characters of the CharLinkedList in 
 *            reverse
 * Effects:   None
 */
std::string CharLinkedList::toReverseString() const 
{
    std::stringstream ss;
    ss << "[CharLinkedList of size " << Linksize << " <<";

    if (Linksize != 0 )
    {
        Node *curr = front;
        while (curr->next != nullptr) 
        {
            curr = curr->next;
        }

        while (curr != nullptr) 
        {
            ss << curr->data;
            curr = curr->prev;
        }
    }

    ss << ">>]";
    return ss.str();
}

/*
 * Name:      pushAtBack
 * Purpose:   Push the provided integer into the back of the CharLinkedList
 * Arguments: An integer to add to the back of the CharLinkedList
 * Returns:   None
 * Effects:   Increases num elements of CharLinkedList by 1, adds element to 
 *            list
 */
void CharLinkedList::pushAtBack(char c) 
{
    Node *new_node = new Node(c, nullptr, nullptr);

    if (front == nullptr) {
        front = new_node;
    }
    else {
        Node *curr = front;
        while (curr->next !=nullptr) {
            curr = curr->next;
        }
        curr->next = new_node;
        curr->next->prev = curr;
    }
    Linksize++;
}

/*
 * Name:      pushAtFront
 * Purpose:   Push the provided integer into the back of the CharLinkedList
 * Arguments: An integer to add to the back of the CharLinkedList
 * Returns:   None
 * Effects:   Increases num elements of CharLinkedList by 1, adds element to 
 *            list
 */
void CharLinkedList::pushAtFront(char c)
{
    if (isEmpty()) {
        front = new Node(c);
    }
    else{
        front = new Node(c, front, nullptr);
        front->next->prev = front;
    }
    Linksize++;
}

/*
 * Name:      insertAt
 * Purpose:   Inserts the new element at the specified index and shifts the 
 *            existing elements as necessary
 * Arguments: An element (char) and an integer index
 * Returns:   None
 * Effects:   Inserts the new element at the specified index and shifts the 
 *            existing elements as necessary
 */
void CharLinkedList::insertAt(char c, int index) 
{
    if (index < 0 or index > Linksize) {
        throw std::range_error("index (" + std::to_string(index) + 
        ") not in range [0.." + std::to_string(Linksize) + "]");
    }

    if (index == 0) {
        pushAtFront(c);
    } 
    else if (index == Linksize) {
        pushAtBack(c);
    } 
    else {
        Node *curr = front;
        Node *new_node = new Node(c, nullptr, nullptr);
        new_node->prev = getIndex(index - 1);
        new_node->next = getIndex(index);
        Linksize++;
        for (int i = 0; i < index - 1; i++){
            curr = curr->next;
        }
        curr->next = new_node;
        curr->next->next->prev = new_node;
    }
}

/*
 * Name:      insertInOrder
 * Purpose:   Insert the element into the CharLinkedList in ASCII order
 * Arguments: An element (char) 
 * Returns:   None
 * Effects:   Insert the element into the CharLinkedList in ASCII order
 */
void CharLinkedList::insertInOrder(char c) 
{
    Node *new_node = new Node(c, nullptr, nullptr);
    if (front == nullptr) {
        front = new_node;
    }
    else if (c < front->data) {
        new_node->next = front;
        front = new_node;
        front->next->prev = front;
    }
    else {
        Node *curr = front;
        while (curr->next != nullptr and c > curr->next->data) {
            curr = curr->next;
        }
        new_node->prev = curr;
        new_node->next = curr->next;
        curr->next = new_node;
        if (curr->next->next != nullptr) {
            curr->next->next->prev = new_node;
        }
    }
    Linksize++;
}

/*
 * Name:      popFromFront
 * Purpose:   Removes the first element from the CharLinkedList
 * Arguments: None
 * Returns:   None
 * Effects:   Removes the first element from the CharLinkedList
 */
void CharLinkedList::popFromFront() 
{
    if (isEmpty()) {
        throw std::runtime_error("cannot pop from empty LinkedList");
    }
    if (Linksize == 1)
    {
        delete front;
        front = nullptr;
        Linksize--;
    }
    else {
        front = front->next;
        delete front->prev;
        front->prev = nullptr;
        Linksize--;
    }
}

/*
 * Name:      popFromBack
 * Purpose:   Removes the last element from the array list
 * Arguments: None
 * Returns:   None
 * Effects:   Removes the last element from the array list
 */
void CharLinkedList::popFromBack() 
{
    if (isEmpty()) 
    {
        throw std::runtime_error("cannot pop from empty LinkedList");
    }
    if (Linksize == 1)
    {
        delete front;
        front = nullptr;
        Linksize--;
    }
    else {
        Node *curr = front;
        while (curr->next->next != nullptr)
        {
            curr = curr->next;
        }
        delete curr->next;
        curr->next = nullptr;
        Linksize--;
    }
}

/*
 * Name:      removeAt(int index)
 * Purpose:   Removes the element at specific index from the CharLinkedList
 * Arguments: An integer
 * Returns:   None
 * Effects:   Removes the element at specific index from the CharLinkedList
 */
void CharLinkedList::removeAt(int index) 
{
    if (index < 0 or index >= Linksize) {
        throw std::range_error("index (" + std::to_string(index) + 
        ") not in range [0.." + std::to_string(Linksize) + ")");
    }
    if (index == 0) {
        popFromFront();
    }
    else if (index == Linksize - 1) {
        popFromBack();
    }
    else {
        Node *curr = front;
        for (int i = 0; i < index - 1; i++) {
            curr = curr->next;
        }
        Node *temp = curr->next;
        curr->next = curr->next->next;
        curr->next->prev = curr;
        delete temp;
        Linksize--;
    }
}

/*
 * Name:      replaceAt(char c, int index)
 * Purpose:   Replace the element at specific index with another element
 * Arguments: An integer
 * Returns:   None
 * Effects:   Replace the element at specific index with another element
 */
void CharLinkedList::replaceAt(char c, int index) 
{
    replaceAtRec(front, c, index, 0);
}

/*
 * Name:      concatenate(CharLinkedList *other)
 * Purpose:   Add a copy of the array list pointed to by the parameter value 
 *            to the end of the array
 * Arguments: A pointer to a second CharLinkedList
 * Returns:   None
 * Effects:   Add a copy of the CharLinkedList pointed to by the parameter 
 *            value to the end of the CharLinkedList
 */
void CharLinkedList::concatenate(CharLinkedList *other) {
    if (other->isEmpty()) {
        return;
    }
    if (isEmpty()) {
        Node *new_node = new Node(other->front->data, nullptr, nullptr);
        front = new_node;
        Node *curr = front;
        Node *othercurr = other->front->next;
        while (othercurr != nullptr) {
            curr->next = new Node(othercurr->data);
            curr->next->prev = curr;
            curr = curr->next;
            othercurr = othercurr->next;
        }  
    }
    else {
        Node *curr = front;
        curr = helperEnd(curr);
        Node *othercurr = other->front;
        int number = 0;
        while (othercurr != nullptr and number <= other->Linksize) {
            curr->next = new Node(othercurr->data);
            curr->next->prev = curr;
            curr = curr->next;
            othercurr = othercurr->next;
            number++;
        }     
    }
    Linksize += other->Linksize;
}

/*
 * Name:      recycRecursive
 * Purpose:   A helper function that goes through every char in the list and 
 *            delete all of them.
 * Arguments: A Node
 * Returns:   None
 * Effects:   Go through every char in the list and delete all of them.
 */
void CharLinkedList::recycRecursive(Node *curr)
{
    if (curr == nullptr)
    {
        return;
    }
    else
    {
        Node *next = curr->next;
        delete curr;
        recycRecursive(next);
    }
}

/*
 * Name:      getIndex
 * Purpose:   A helper function that get the node at specific index.
 * Arguments: An index
 * Returns:   The node at specific index
 * Effects:   None
 */
CharLinkedList::Node *CharLinkedList::getIndex(int index) const
{
    Node *curr = front;
    int curr_index = 0;
    while (curr_index < index)
    {
        curr = curr->next;
        curr_index++;
    }
    return curr;
}

/*
 * Name:      copyCharLinkedList
 * Purpose:   A helper function that copy all the elements in the 
 *            CharLinkedList.
 * Arguments: A Node
 * Returns:   A node
 * Effects:   None
 */
CharLinkedList::Node *CharLinkedList::copyCharLinkedList(const Node *other) 
{
    if (other == nullptr) {
        return nullptr;
    }
    Node *curr = new Node(other->data);
    curr->next = curr;
    curr->next->prev = curr;
    curr->next = copyCharLinkedList(other->next);

    return curr;
}

/*
 * Name:      replaceAtRec
 * Purpose:   A helper function that use recursive to replace an element with
 *            another one.
 * Arguments: A Node, a character, an target index, and a current index
 * Returns:   None
 * Effects:   A helper function that use recursive to replace an element with
 *            another one.
 */
void CharLinkedList::replaceAtRec(Node *curr, char c, int index, int currindex)
{
    if (curr == nullptr) {
        throw std::range_error("index (" + std::to_string(index) + 
        ") not in range [0.." + std::to_string(Linksize) + ")");     
    }
    else if (index == currindex) {
        curr->data = c;
    }
    else {
        replaceAtRec(curr->next, c, index, currindex + 1);
    }
}

/*
 * Name:      elementAtRec
 * Purpose:   A helper function that use recursive to find an element at
 *            specific index.
 * Arguments: A Node, a character, an target index, and a current index
 * Returns:   An element
 * Effects:   None
 */
char CharLinkedList::elementAtRec(Node *curr, int index, int currindex) const
{
    if (currindex == index) {
        return curr->data;
    }
    else {
        return elementAtRec(curr->next, index, currindex + 1);
    }
}

/*
 * Name:      helperEnd
 * Purpose:   A helper function that finds the end of the CharLinkedList.
 * Arguments: A Node
 * Returns:   The end Node of the CharLinkedList.
 * Effects:   None
 */
CharLinkedList::Node *CharLinkedList::helperEnd(Node *curr) 
{
    while (curr->next != nullptr) {
        curr = curr->next;
    }
    return curr;
}

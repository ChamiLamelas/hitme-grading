/*
 *  CharLinkedList.h
 *  Tianhong Feng (tfeng01)
 *  2024.2.3
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Purpose: Interface for a simple doubly linked char list Class. Or, an 
 *           interface of CharLinkedList class, which includes key information 
 *           regarding the CharLinkedList class. Clients can directly use
 *           the functions in this file to satisfy their own needs.
 *
 */

#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H

#include <string>

class CharLinkedList {
public:
    // Constructor and Destructor
    CharLinkedList();
    CharLinkedList(char c);
    CharLinkedList(char arr[], int size);
    CharLinkedList(const CharLinkedList &other);
    ~CharLinkedList();

    // Operator Overload
    CharLinkedList &operator=(const CharLinkedList &other);

    // Other functions
    bool isEmpty() const;
    void clear();
    int size() const;
    char first() const;
    char last() const;
    char elementAt(int index) const;
    std::string toString() const;
    std::string toReverseString() const;
    void pushAtBack(char c);
    void pushAtFront(char c);
    void insertAt(char c, int index);
    void insertInOrder(char c);
    void popFromFront();
    void popFromBack();
    void removeAt(int index);
    void replaceAt(char c, int index);
    void concatenate(CharLinkedList *other);

private:
    struct Node {
        char data;
        Node *next;
        Node *prev;
        Node (char c, Node *n = nullptr, Node *p = nullptr) : data(c), next(n),
              prev(p) {}
    };

    Node *front;
    int Linksize;
    void recycRecursive(Node *curr);
    void replaceAtRec(Node *curr, char c, int index, int currindex);
    char elementAtRec(Node *curr, int index, int currindex) const;
    Node *copyCharLinkedList(const Node *other);
    Node *getIndex(int index) const;
    Node *helperEnd(Node *curr);
};

#endif

/*
 *  CharLinkedList.h
 *  Justin McNamara
 *  2/2/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  This is the interface of CharLinkedList.cpp outlining which
 *  functions a client could use on a given instance of a 
 *  CharLinkedList
 *
 */

#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H
#include <iostream>
#include <string>

class CharLinkedList {
private:
    struct Node {
        Node *prev;
        Node *next;
        char letter;
    };

    int numItems;
    Node *front;
    Node *back;

    // Helper functions
    void recycleRecursivley(Node *curr);
    Node *elementAtHelper(Node *curr, int index) const;
    void replaceAtHelper(Node *curr, char c, int index);

public:
    CharLinkedList();
    CharLinkedList(char c);
    CharLinkedList(char arr[], int size);
    CharLinkedList(const CharLinkedList &other);
    ~CharLinkedList();
    CharLinkedList &operator=(const CharLinkedList &other);

    bool isEmpty() const;
    void clear();
    int size() const;
    char first() const;
    char last() const;
    char elementAt(int index) const;
    std::string toString() const;
    std::string toReverseString() const;
    void pushAtBack(char c);
    void pushAtFront(char c);
    void insertAt(char c, int index);
    void insertInOrder(char c);
    void popFromFront();
    void popFromBack();
    void removeAt(int index);
    void replaceAt(char c, int index);
    void concatenate(CharLinkedList *other);
};


#endif
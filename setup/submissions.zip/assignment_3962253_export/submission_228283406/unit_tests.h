/*
 *  unit_tests.h
 *  Justin McNamara
 *  2/2/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  The purpose of this file is to test the implementation
 *  of functions in CharLinkedList. By testing individual 
 *  aspects of each function this streamlined the coding
 *  process and ensured proper functionality.
 *  
 *  NOTE: All functions were made public when testing!
 */

#include "CharLinkedList.h"
#include <cassert>

// Test assignment operator
void asssingmentOperator0() {
    char test_arr[8] = { 'a', 'b', 'c'};
    CharLinkedList test_list1(test_arr, 3);

    CharLinkedList test_list2; 
    test_list2 = test_list1;

    assert(test_list1.size() == test_list2.size());
    for(int i = 0; i < 3; i++) {
        assert(test_list1.elementAt(i) == test_list2.elementAt(i));
    }
}

// Test assignment operator
void assingmentOperator1() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list1(test_arr, 8);

    CharLinkedList test_list2;
    test_list2 = test_list1;

    test_list1.popFromFront();

    assert(test_list1.size() == 7);
    assert(test_list2.size() == 8);
}

// Test assignment operator
void assignmentOperator2() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list1(test_arr, 8);

    CharLinkedList test_list2;
    test_list2 = test_list1;

    test_list2.clear();

    assert(test_list1.size() == 8);
    assert(test_list2.size() == 0);
}

// Test assignment operator
void assignmentOperator3() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list1(test_arr, 8);

    CharLinkedList test_list2;
    test_list1 = test_list2;

    assert(test_list1.size() == 0);
    assert(test_list2.size() == 0);
}

// Tests isEmpty() on empty list
void isEmpty_empty_list() {
    CharLinkedList test_list;
    assert(test_list.isEmpty());
}

// Tests isEmpty() on singleton list
void isEmpty_singleton_list() {
    CharLinkedList test_list('a');
    assert(not test_list.isEmpty());
}

// Tests isEmpty() on nonempty list
void isEmpty_nonempty_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);
    assert(not test_list.isEmpty());
}

// Tests clear() on empty list
void clear_empty_list() {
    CharLinkedList test_list;
    test_list.clear();
    assert(test_list.isEmpty());
}

// Tests clear() on singleton list
void clear_singleton_list() {
    CharLinkedList test_list('a');
    test_list.clear();
    assert(test_list.isEmpty());
}

// Tests clear() on nonempty list
void clear_nonmpty_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.clear();
}

// Tests size() on empty list
void size_empty_list() {
    CharLinkedList test_list;

    assert(test_list.size() == 0);
}

// Tests size() on singleton list
void size_singleton_list() {
    CharLinkedList test_list('a');

    assert(test_list.size() == 1);
}

// Tests size() on nonempty list
void size_nonempty_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    assert(test_list.size() == 8);
}

// Tests first() on empty list
void first_empty_list() {
    CharLinkedList test_list;

    // var to track whether range_error is thrown
    bool runtime_error_thrown = false;
    
    // var to track any error messages raised
    std::string error_message = "";
    
    try {
        test_list.first();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot get first of empty LinkedList");
}

// Tests first() on singleton list
void first_singleton_list() {
    CharLinkedList test_list('a');

    assert(test_list.first() == 'a');
    assert(test_list.last() == 'a');
}

// Tests first() on nonempty list
void first_nonempty_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    assert(test_list.first() == 'a');
    assert(test_list.last() == 'h');
}

// Tests last() on empty list
void last_empty_list() {
    CharLinkedList test_list;

    // var to track whether range_error is thrown
    bool runtime_error_thrown = false;
    
    // var to track any error messages raised
    std::string error_message = "";
    
    try {
        test_list.last();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot get last of empty LinkedList");
}

// Tests last() on singleton list
void last_singleton_list() {
    CharLinkedList test_list('a');

    assert(test_list.last() == 'a');
}

// Tests last() on nonempty list
void last_nonempty_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);
    assert(test_list.last() == 'h');
}

// Tests elementAt() on empty list
void elementAt_empty_list() {
    CharLinkedList test_list;

    // var to track whether range_error is thrown
    bool range_error_thrown = false;
    
    // var to track any error messages raised
    std::string error_message = "";
    
    try {
        test_list.elementAt(0);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (0) not in range [0..0)");
}

// Tests elementAt() on singleton list
void elementAt_singleton_list() {
    CharLinkedList test_list('a');
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');
}

// Tests elementAt() on nonempty list
void elementAt_nonempty_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    assert(test_list.elementAt(2) == 'c');
    assert(test_list.elementAt(3) == 'd');
    assert(test_list.elementAt(4) == 'e');
    assert(test_list.elementAt(5) == 'f');
    assert(test_list.elementAt(6) == 'g');
    assert(test_list.elementAt(7) == 'h');
}

// Tests elementAt() on nonempty list with index greater 
// than numItems
void elementAt_index_greater() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;
    
    // var to track any error messages raised
    std::string error_message = "";
    
    try {
        test_list.elementAt(9);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (9) not in range [0..8)");
}

// Tests elementAt() on nonempty list with index
// lesser than numItems
void elementAt_index_lesser() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;
    
    // var to track any error messages raised
    std::string error_message = "";
    
    try {
        test_list.elementAt(-1);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (-1) not in range [0..8)");
}

// Tests toString() on empty list
void toString_empty_list() {
    CharLinkedList test_list;

    std::string letters = "";
    letters = test_list.toString();

    assert(letters == "[CharLinkedList of size 0 <<>>]");
}

// Tests toString() on singleton list
void toString_singleton_list() {
    CharLinkedList test_list('a');

    std::string letters = "";
    letters = test_list.toString();

    assert(letters == "[CharLinkedList of size 1 <<a>>]");
}

// Tests toString() on nonempty list
void toString_nonempty_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    std::string letters = "";
    letters = test_list.toString();

    assert(letters == "[CharLinkedList of size 8 <<abcdefgh>>]");    
}

// Tests toReverseString() on empty list
void toReverseString_empty_list() {
    CharLinkedList test_list;

    std::string letters = "";
    letters = test_list.toReverseString();

    assert(letters == "[CharLinkedList of size 0 <<>>]");
}

// Tests toReverseString() on singleton list
void toReverseString_singleton_list() {
    CharLinkedList test_list('a');

    std::string letters = "";
    letters = test_list.toReverseString();

    assert(letters == "[CharLinkedList of size 1 <<a>>]");
}

// Tests toReverseString() on nonempty list
void toReverseString_nonempty_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    std::string letters = "";
    letters = test_list.toReverseString();

    assert(letters == "[CharLinkedList of size 8 <<hgfedcba>>]");   
}

/// Test pushAtFront on empty list
void pushAtFront_empty_list() {
    CharLinkedList test_list;

    test_list.pushAtFront('a');

    assert(test_list.elementAt(0) == 'a');
    assert(test_list.size() == 1);
}

// Test pushAtFront on singleton list
void pushAtFront_singleton_list() {
    CharLinkedList test_list('a');

    test_list.pushAtFront('b');

    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'a');
    assert(test_list.size() == 2);
}

// Test pushAtFront on nonempty list
void pushAtFront_nonempty_list() {
    char test_arr[8] = { 'z', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.pushAtFront('a');
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'z');
    assert(test_list.elementAt(2) == 'b');
    assert(test_list.elementAt(3) == 'c');
    assert(test_list.elementAt(4) == 'd');
    assert(test_list.elementAt(5) == 'e');
    assert(test_list.elementAt(6) == 'f');
    assert(test_list.elementAt(7) == 'g');
    assert(test_list.elementAt(8) == 'h');
    assert(test_list.size() == 9);
}

// Test pushAtFront on nonempty list many times
void pushAtFront_many() {
    CharLinkedList test_list;
    for(int i = 0; i < 1000; i++) {
        test_list.pushAtFront('a');
        assert(test_list.size() == i + 1);
        assert(test_list.elementAt(i) == 'a');
    }
}

// Test pushAtBack on empty list
void pushAtBack_empty_list() {
    CharLinkedList test_list;

    test_list.pushAtBack('a');

    assert(test_list.elementAt(0) == 'a');
    assert(test_list.size() == 1);
}

// Test pushAtBack on singleton list
void pushAtBack_singleton_list() {
    CharLinkedList test_list('a');

    test_list.pushAtBack('b');

    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    assert(test_list.size() == 2);
}

// Test pushAtBack on nonempty list
void pushAtBack_nonempty_list() {
    char test_arr[8] = { 'z', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.pushAtBack('a');
    assert(test_list.elementAt(0) == 'z');
    assert(test_list.elementAt(1) == 'b');
    assert(test_list.elementAt(2) == 'c');
    assert(test_list.elementAt(3) == 'd');
    assert(test_list.elementAt(4) == 'e');
    assert(test_list.elementAt(5) == 'f');
    assert(test_list.elementAt(6) == 'g');
    assert(test_list.elementAt(7) == 'h');
    assert(test_list.elementAt(8) == 'a');
    assert(test_list.size() == 9);
}

// Test pushAtBack on nonempty list many times
void pushAtBack_many() {
    CharLinkedList test_list;
    for(int i = 0; i < 1000; i++) {
        test_list.pushAtBack('a');
        assert(test_list.size() == i + 1);
        assert(test_list.elementAt(i) == 'a');
    }
}

// Tests correct insertion into an empty AL.
// Afterwards, size should be 1 and element at index 0
// should be the element we inserted.
void insertAt_empty_correct() { 

    CharLinkedList test_list;
    test_list.insertAt('a', 0);
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');

}

// Tests incorrect insertion into an empty AL.
// Attempts to call insertAt for index larger than 0.
// This should result in an std::range_error being raised.
void insertAt_empty_incorrect() {

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
        // insertAt for out-of-range index
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        // if insertAt is correctly implemented a range_error will be thrown
        // and we will end up here
        range_error_thrown = true;
        error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0]");
}

// Tests correct insertAt for front of 1-element list.
void insertAt_front_singleton_list() {
    CharLinkedList test_list('a');

    test_list.insertAt('b', 0);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'a');
    
}

// Tests correct insertAt for back of 1-element list.
void insertAt_back_singleton_list() {
    CharLinkedList test_list('a');

    test_list.insertAt('b', 1);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    
}

// Tests calling insertAt for a large number of elements.
// Not only does this test insertAt, it also checks that
// array expansion works correctly.
void insertAt_many_elements() {
    CharLinkedList test_list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.insertAt('a', i);
    }

    assert(test_list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
    
}

// Tests insertion into front of a larger list
void insertAt_front_large_list() {
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    test_list.insertAt('y', 0);

    assert(test_list.size() == 10);
    assert(test_list.elementAt(0) == 'y');
    assert(test_list.toString() ==    
    "[CharLinkedList of size 10 <<yabczdefgh>>]");

}

// Tests insertion into the back of a larger list
void insertAt_back_large_list() {
    char test_arr[10] = { 'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 10);  

    test_list.insertAt('x', 10);

    assert(test_list.size() == 11);
    assert(test_list.elementAt(10) == 'x');
    assert(test_list.toString() == 
    "[CharLinkedList of size 11 <<yabczdefghx>>]"); 
}

// Tests insertion into the middle of a larger list
void insertAt_middle_large_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.insertAt('z', 3);

    assert(test_list.size() == 9);
    assert(test_list.elementAt(3) == 'z');
    assert(test_list.toString() ==     
    "[CharLinkedList of size 9 <<abczdefgh>>]");
}

// Tests out-of-range insertion for a non-empty list.
void insertAt_nonempty_incorrect() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8]");
}

// Test insertInOrder on empty list
void insertInOrder_empty_list() {
    CharLinkedList test_list;
    assert(test_list.isEmpty());

    test_list.insertInOrder('a');

    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');
}

// Test insertInOrder on singleton list
void insertInOrder_singleton_list() {
    CharLinkedList test_list('a');
    assert(test_list.size() == 1);

    test_list.insertInOrder('b');

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
}

// Test insertInOrder on nonempty list
// character should go to index 0
void insertInOrder_beginning_nonempty_list() {
    char test_arr[8] = { 'b', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.insertInOrder('a');

    assert(test_list.size() == 9);
    assert(test_list.elementAt(0) == 'a');
}

void insertInOrder_middle_nonempty_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.insertInOrder('d');

    assert(test_list.size() == 9);
    assert(test_list.elementAt(3) == 'd');
    assert(test_list.elementAt(4) == 'd');
}

// Test insertInOrder on nonempty list
// character should go to index numItems
void insertInOrder_end_nonempty_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.insertInOrder('i');

    assert(test_list.size() == 9);
    assert(test_list.elementAt(8) == 'i');
}

// Commented out since string was too long :)
// Test insertInOrder many times 
// This was the test my insertInOrder failed last
// time and wanted to be sure I didn't miss it
// void insertInOrder_many_times() {
//     char test_arr1[26] = { 'a', 'b', 'C', 'd', 'e', 'f', 'g',
//     'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r',
//     'S', 't', 'u', 'v', 'w', 'x', 'y', 'z'};
//     CharLinkedList test_list(test_arr1, 26);

//     char test_arr2[26] = { 'A', 'B', 'C', 'D', 'E', 'F', 'G',
//     'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R',
//     'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'};

//     for(int i = 0; i < 26; i++) {
//        test_list.insertInOrder(test_arr2[i]);
//     }

//     std::string letters = "";
//     letters = test_list.toString();

//     assert(test_list.size() == 52);
//     assert(letters == 
//     "[CharLinkedList of size 52 
//       <<ABCDEFGHIJKLMNOPQRSTUVWXYZabCdefghijklmnopqrStuvwxyz>>]");
// }

// Test popFromFront on empty list
void popFromFront_empty_list() {
    CharLinkedList test_list;

    // var to track whether range_error is thrown
    bool runtime_error_thrown = false;
    
    // var to track any error messages raised
    std::string error_message = "";
    
    try {
        test_list.popFromFront();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

// Test popFromFront on singleton list
void popFromFront_singleton_list() {
    CharLinkedList test_list('a');
    assert(test_list.size() == 1);
    assert(test_list.first() == 'a');

    test_list.popFromFront();

    
    assert(test_list.isEmpty());
}

// Test popFromFront on nonempty list
void popFromFront_nonempty_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);
    assert(test_list.size() == 8);
    assert(test_list.first() == 'a');
    
    test_list.popFromFront();
    assert(test_list.first() == 'b');
    assert(test_list.size() == 7);
    test_list.popFromFront();
    assert(test_list.first() == 'c');
    assert(test_list.size() == 6);
    test_list.popFromFront();
    assert(test_list.first() == 'd');
    assert(test_list.size() == 5);
    test_list.popFromFront();
    assert(test_list.first() == 'e');
    assert(test_list.size() == 4);
    test_list.popFromFront();
    assert(test_list.first() == 'f');
    assert(test_list.size() == 3);
    test_list.popFromFront();
    assert(test_list.first() == 'g');
    assert(test_list.size() == 2);
    test_list.popFromFront();
    assert(test_list.first() == 'h');
    assert(test_list.size() == 1);
    test_list.popFromFront();
    assert(test_list.isEmpty());
}

// Test popFromBack on empty list
void popFromBack_empty_list() {
    CharLinkedList test_list;

    // var to track whether range_error is thrown
    bool runtime_error_thrown = false;
    
    // var to track any error messages raised
    std::string error_message = "";
    
    try {
        test_list.popFromBack();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

// Test popFromBack on singleton list
void popFromBack_singleton_list() {
    CharLinkedList test_list('a');
    assert(test_list.size() == 1);
    assert(test_list.first() == 'a');

    test_list.popFromBack();

    
    assert(test_list.isEmpty());
}

// Test popFromBack on nonempty list
void popFromBack_nonempty_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);
    assert(test_list.size() == 8);
    assert(test_list.last() == 'h');

    test_list.popFromBack();
    assert(test_list.size() == 7);
    assert(test_list.last() == 'g');
    test_list.popFromBack();
    assert(test_list.size() == 6);
    assert(test_list.last() == 'f');
    test_list.popFromBack();
    assert(test_list.size() == 5);
    assert(test_list.last() == 'e');
    test_list.popFromBack();
    assert(test_list.size() == 4);
    assert(test_list.last() == 'd');
    test_list.popFromBack();
    assert(test_list.size() == 3);
    assert(test_list.last() == 'c');
    test_list.popFromBack();
    assert(test_list.size() == 2);
    assert(test_list.last() == 'b');
    test_list.popFromBack();
    assert(test_list.size() == 1);
    assert(test_list.last() == 'a');
    test_list.popFromBack();
    assert(test_list.isEmpty());
}

// Test removeAt on empty list
void removeAt_empty_list() {
    CharLinkedList test_list;

    // var to track whether range_error is thrown
    bool range_error_thrown = false;
    
    // var to track any error messages raised
    std::string error_message = "";
    
    try {
        test_list.replaceAt('a', 0);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (0) not in range [0..0)");
}

// Test removeAt on singleton list
void removeAt_singleton_list() {
    CharLinkedList test_list('a'); 
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');

    test_list.removeAt(0);


    assert(test_list.isEmpty());
}

// Test removeAt on nonempty list
void removeAt_nonempty_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    for(int i = 0; i < 4; i++) {
        test_list.removeAt(2);
    }

    assert(test_list.size() == 4);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    assert(test_list.elementAt(2) == 'g');
    assert(test_list.elementAt(3) == 'h');
}

// Test removeAt on nonempty list index 
// less than numItems
void removeAt_index_lesser() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;
    
    // var to track any error messages raised
    std::string error_message = "";
    
    try {
        test_list.removeAt(-3);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (-3) not in range [0..8)");
}

// Test removeAt on nonempty list index 
// greater than numItems
void removeAt_index_greater() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;
    
    // var to track any error messages raised
    std::string error_message = "";
    
    try {
        test_list.removeAt(9);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (9) not in range [0..8)");
}

// Test replaceAt on empty list
void replactAt_empty_list() {
    CharLinkedList test_list;

    // var to track whether range_error is thrown
    bool range_error_thrown = false;
    
    // var to track any error messages raised
    std::string error_message = "";
    
    try {
        test_list.replaceAt('a', 0);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (0) not in range [0..0)");
}

// Test replaceAt on singleton list
void replactAt_singleton_list() {
    CharLinkedList test_list('a');
    assert(test_list.first() == 'a');
    assert(test_list.size() == 1);

    test_list.replaceAt('b', 0);

    assert(test_list.size() == 1);
    assert(test_list.first() == 'b');
}

// Test replaceAt on nonempty list many times
void replactAt_nonempty_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    for(int i = 0; i < 8; i++) {
        test_list.replaceAt('z', i);
    }

    assert(test_list.elementAt(0) == 'z');
    assert(test_list.elementAt(1) == 'z');
    assert(test_list.elementAt(2) == 'z');
    assert(test_list.elementAt(3) == 'z');
    assert(test_list.elementAt(4) == 'z');
    assert(test_list.elementAt(5) == 'z');
    assert(test_list.elementAt(6) == 'z');
    assert(test_list.elementAt(7) == 'z');
}

// Test replaceAt on nonempty list index
// less than numItems
void replaceAt_index_lesser() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;
    
    // var to track any error messages raised
    std::string error_message = "";
    
    try {
        test_list.replaceAt('a', -3);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (-3) not in range [0..8)");
}

// Test replaceAt on nonempty list index
// greater than numItems
void replaceAt_index_greater() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;
    
    // var to track any error messages raised
    std::string error_message = "";
    
    try {
        test_list.replaceAt('a', 9);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (9) not in range [0..8)");
}

// Test concatenate empty with empty
void concatenate_empty_lists() {
    CharLinkedList test_list1;
    CharLinkedList test_list2;

    test_list1.concatenate(&test_list2);

    assert(test_list1.size() == 0);
    assert(test_list1.isEmpty());
}

// Test concatenate empty with singleton
void concatenate_empty_singleton() {
    CharLinkedList test_list1;
    CharLinkedList test_list2('a');

    test_list1.concatenate(&test_list2);

    assert(test_list1.size() == 1);
    assert(test_list1.elementAt(0) == 'a');
}

// Test concatenate singleton with empty
void concatenate_singleton_empty() {
    CharLinkedList test_list1;
    CharLinkedList test_list2('a');

    test_list2.concatenate(&test_list1);

    assert(test_list2.size() == 1);
    assert(test_list2.elementAt(0) == 'a');
}

// Test concatenate singleton with singleton
void concatenate_singleton_singleton() {
    CharLinkedList test_list1('a');
    CharLinkedList test_list2('b');

    test_list1.concatenate(&test_list2);

    assert(test_list1.size() == 2);
    assert(test_list1.elementAt(0) == 'a');
    assert(test_list1.elementAt(1) == 'b');
}

// Test concatenate empty with nonempty
void concatenate_empty_nonempty() {
    CharLinkedList test_list1;
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list2(test_arr, 8);

    test_list1.concatenate(&test_list2);

    assert(test_list1.size() == 8);
    assert(test_list1.elementAt(0) == 'a');
    assert(test_list1.elementAt(1) == 'b');
    assert(test_list1.elementAt(2) == 'c');
    assert(test_list1.elementAt(3) == 'd');
    assert(test_list1.elementAt(4) == 'e');
    assert(test_list1.elementAt(5) == 'f');
    assert(test_list1.elementAt(6) == 'g');
    assert(test_list1.elementAt(7) == 'h');
}

// Test concatenate nonempty with empty
void concatenate_nonempty_empty() {
    CharLinkedList test_list1;
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list2(test_arr, 8);

    test_list2.concatenate(&test_list1);

    assert(test_list2.size() == 8);
    assert(test_list2.elementAt(0) == 'a');
    assert(test_list2.elementAt(1) == 'b');
    assert(test_list2.elementAt(2) == 'c');
    assert(test_list2.elementAt(3) == 'd');
    assert(test_list2.elementAt(4) == 'e');
    assert(test_list2.elementAt(5) == 'f');
    assert(test_list2.elementAt(6) == 'g');
    assert(test_list2.elementAt(7) == 'h');
}

// Test concatenate singleton with nonempty
void concatenate_singleton_nonempty() {
    CharLinkedList test_list1('z');
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list2(test_arr, 8);

    test_list1.concatenate(&test_list2);

    assert(test_list1.size() == 9);
    assert(test_list1.elementAt(0) == 'z');
    assert(test_list1.elementAt(1) == 'a');
    assert(test_list1.elementAt(2) == 'b');
    assert(test_list1.elementAt(3) == 'c');
    assert(test_list1.elementAt(4) == 'd');
    assert(test_list1.elementAt(5) == 'e');
    assert(test_list1.elementAt(6) == 'f');
    assert(test_list1.elementAt(7) == 'g');
    assert(test_list1.elementAt(8) == 'h');
}

// Test concatenate nonempty with nonempty
void concatenate_nonempty_nonempty() {
    char test_arr1[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list1(test_arr1, 8);
    char test_arr2[8] = { 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p' };
    CharLinkedList test_list2(test_arr2, 8);

    test_list1.concatenate(&test_list2);

    assert(test_list1.size() == 16);
    assert(test_list1.elementAt(0) == 'a');
    assert(test_list1.elementAt(1) == 'b');
    assert(test_list1.elementAt(2) == 'c');
    assert(test_list1.elementAt(3) == 'd');
    assert(test_list1.elementAt(4) == 'e');
    assert(test_list1.elementAt(5) == 'f');
    assert(test_list1.elementAt(6) == 'g');
    assert(test_list1.elementAt(7) == 'h');
    assert(test_list1.elementAt(8) == 'i');
    assert(test_list1.elementAt(9) == 'j');
    assert(test_list1.elementAt(10) == 'k');
    assert(test_list1.elementAt(11) == 'l');
    assert(test_list1.elementAt(12) == 'm');
    assert(test_list1.elementAt(13) == 'n');
    assert(test_list1.elementAt(14) == 'o');
    assert(test_list1.elementAt(15) == 'p');
}

// Test concatenate empty with self
void concatenate_empty_self() {
    CharLinkedList test_list1;

    test_list1.concatenate(&test_list1);

    assert(test_list1.size() == 0);
    assert(test_list1.isEmpty());
}

// Test concatenate singleton with self
void concatenate_singleton_self() {
    CharLinkedList test_list1('a');

    test_list1.concatenate(&test_list1);

    assert(test_list1.size() == 2);
    assert(test_list1.elementAt(0) == 'a');
    assert(test_list1.elementAt(1) == 'a');
}

// Test concatenate nonempty with self
void concatenate_nonempty_self() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list1(test_arr, 8);

    test_list1.concatenate(&test_list1);

    assert(test_list1.size() == 16);
    assert(test_list1.elementAt(0) == 'a');
    assert(test_list1.elementAt(1) == 'b');
    assert(test_list1.elementAt(2) == 'c');
    assert(test_list1.elementAt(3) == 'd');
    assert(test_list1.elementAt(4) == 'e');
    assert(test_list1.elementAt(5) == 'f');
    assert(test_list1.elementAt(6) == 'g');
    assert(test_list1.elementAt(7) == 'h');
    assert(test_list1.elementAt(8) == 'a');
    assert(test_list1.elementAt(9) == 'b');
    assert(test_list1.elementAt(10) == 'c');
    assert(test_list1.elementAt(11) == 'd');
    assert(test_list1.elementAt(12) == 'e');
    assert(test_list1.elementAt(13) == 'f');
    assert(test_list1.elementAt(14) == 'g');
    assert(test_list1.elementAt(15) == 'h');
}
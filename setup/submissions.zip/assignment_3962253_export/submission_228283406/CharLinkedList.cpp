/*
 *  CharLinkedList.cpp
 *  Justin McNamara
 *  2/2/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  This file is the implementation of the functions declared
 *  in CharLinkedList.
 *
 */

#include "CharLinkedList.h"

using namespace std;

/*
 * Purspose: Creates an instance of an empty CharLinkedList
 * Parameters: None
 * Return value: None
 * Effects: Instantiates empty CharLinkedList
 */
CharLinkedList::CharLinkedList() {
    numItems = 0;
    front = nullptr;
    back = nullptr;
}

/*
 * Purspose: Creates an instance of a CharArrayList with one element
 * Parameters: a character
 * Return value: None
 * Effects: Instantiates singleton CharLinkedList
 */
CharLinkedList::CharLinkedList(char c) {
    numItems = 1;
    Node *data = new Node;
    data->prev = nullptr;
    data->next = nullptr;
    data->letter = c;
    front = data;
    back = data;
}

/*
 * Purspose: Creates an instance of a CharArrayList with many
            elements
 * Parameters: array of characters and the size of the array
 * Return value: None
 * Effects: Instatiates nonempty CharArrayList
 */
CharLinkedList::CharLinkedList(char arr[], int size) {
    numItems = 0;
    front = nullptr;
    back = nullptr;
    // Iterate back at numItems - 1 to preserve order
    for(int i = size - 1; i >= 0; i--) {
        pushAtFront(arr[i]);
    }
}

/*
 * Purspose: Copy constructor
 * Parameters: The address of a CharLinkedList
 * Return value: none
 * Effects: Creates a copy of the passed CharLinkedList
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other) {
    numItems = 0;
    front = nullptr;
    back = nullptr;
    // Iterate back at numItems - 1 to preserve order
    for(int i = other.numItems - 1; i >= 0; i--) {
        pushAtFront(other.elementAt(i));
    }
}

/*
 * Purspose: Recycle memory
 * Parameters: A node
 * Return value: void
 * Effects: Deletes list
 */
void CharLinkedList::recycleRecursivley(Node *curr) {
    if(curr == nullptr) {
        return;
    } else {
        Node *next = curr->next;
        delete curr;
        recycleRecursivley(next);
    }
}

/*
 * Purspose: Destructor
 * Parameters: none
 * Return value: none
 * Effects: Frees up used memory
 */
CharLinkedList::~CharLinkedList() {
    recycleRecursivley(front);
}

/*
 * Purspose: Overloads the assignment operator
 * Parameters: The address of a CharArrayList
 * Return value: &CharArrayList
 * Effects: Enables creation of deep copy
 */
CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other) {
    if(this == &other) {
        return *this;
    }
    if(other.isEmpty()) {
        clear();
        return *this;
    }
    clear();
    for(int i = other.numItems - 1; i >= 0; i--) {
        pushAtFront(other.elementAt(i));
    }
    return *this;
}

/*
 * Purspose: Check if a list is empty
 * Parameters: none
 * Return value: bool
 * Effects: none
 */
bool CharLinkedList::isEmpty() const {
    return (this->numItems == 0);
}

/*
 * Purspose: Clear data
 * Parameters: none
 * Return value: void
 * Effects: Frees up used heap memory
 */
void CharLinkedList::clear() {
    recycleRecursivley(front);
    front = nullptr;
    back = nullptr;
    numItems = 0;
}

/*
 * Purspose: Get a lists size
 * Parameters: none
 * Return value: int
 * Effects: none
 */
int CharLinkedList::size() const {
    return numItems;
}

/*
 * Purspose: Get the first char of a list
 * Parameters: none
 * Return value: char
 * Effects: none
 */
char CharLinkedList::first() const {
    if(isEmpty()) {
        throw std::runtime_error("cannot get first of empty LinkedList");
    }
    return front->letter;
}

/*
 * Purspose: Get the last char of a list
 * Parameters: none
 * Return value: char
 * Effects: none
 */
char CharLinkedList::last() const {
    if(isEmpty()) {
        throw std::runtime_error("cannot get last of empty LinkedList");
    }
    return back->letter;
}

/*
 * Purspose: Find the node of an element at a given index
 * Parameters: Node and an index
 * Return value: Node
 * Effects: none
 */
CharLinkedList::
Node *CharLinkedList::elementAtHelper(Node *curr, int index) const {
    if(index == 0) {
        return curr;
    }
    return elementAtHelper(curr->next, index - 1);
}

/*
 * Purspose: Get the character at a given index
 * Parameters: an index
 * Return value: char
 * Effects: none
 */
char CharLinkedList::elementAt(int index) const {
    if(index < 0 or index > numItems - 1 or numItems == 0) {
        throw std::range_error("index (" + std::to_string(index) + 
        ") not in range [0.." + std::to_string(numItems) + ")");
    }
    return elementAtHelper(front, index)->letter;
}

/*
 * Purspose: print the size and elements
 * Parameters: none
 * Return value: string
 * Effects: none
 */
std::string CharLinkedList::toString() const {
    std:: string letters = "";
    for(int i = 0; i < numItems; i++) {
        letters += elementAt(i);
    }
    return "[CharLinkedList of size " + std::to_string(numItems) + " <<" +
    letters + ">>]";
}

/*
 * Purspose: print out the size and elements in reverse order
 * Parameters: none
 * Return value: string
 * Effects: none
 */
std::string CharLinkedList::toReverseString() const {
    std:: string letters = "";
    for(int i = numItems - 1; i >= 0; i--) {
        letters += elementAt(i);
    }
    return "[CharLinkedList of size " + to_string(numItems) + " <<" +
    letters + ">>]";
}

/*
 * Purspose: adds an element to the back
 * Parameters: char c
 * Return value: void 
 * Effects: increases the numItems and updates front and back
 */
void CharLinkedList::pushAtBack(char c) {
    Node *data = new Node;
    data->letter = c;
    data->next = nullptr;
    if(not front) {
        data->prev = nullptr;
        front = data;
    } 
    if(back) {
        back->next = data;
        data->prev = back;
    }
    back = data;   
    numItems++;
}

/*
 * Purspose: adds an element to the front
 * Parameters: char c
 * Return value: void
 * Effects: increases the numItems and updates front and back
 */
void CharLinkedList::pushAtFront(char c) {
    Node *data = new Node;
    data->letter = c;
    data->prev = nullptr;
    data->next = front;
    if(front != nullptr) { //cannot access prev if front is null
        front->prev = data;
    } else {
        back = data;
    }
    front = data;
    numItems++;
}

/*
 * Purspose: Insert an element at a given index
 * Parameters: char c int index
 * Return value: void
 * Effects: Increases numItems and updates front and back
 */
void CharLinkedList::insertAt(char c, int index) {
    if(index < 0 or index > numItems) {
        throw std::range_error("index (" + to_string(index) + 
        ") not in range [0.." + to_string(numItems)+ "]");
    }
    if(index == 0) {
        pushAtFront(c);
    } else if(index == numItems) {
        pushAtBack(c);
    } else {
        // Find next and prev Nodes
        Node *nodeAfter = elementAtHelper(front, index);
        Node *nodeBefore = nodeAfter->prev;

        Node *data = new Node;
        data->letter = c;
        data->prev = nodeBefore;
        data->next = nodeAfter;
        //Update before->next and after->prev
        nodeBefore->next = data;
        nodeAfter->prev = data;
        numItems++;
    }
}

/*
 * Purspose: Insert a given element based on its ASCII value
 * Parameters: char c
 * Return value: void
 * Effects: Increase numItems and updates front and back if needed
 */
void CharLinkedList::insertInOrder(char c) {
    if(isEmpty()) {
       insertAt(c, 0);
    } else { 
        Node *temp = front;
        int insertIndex = 0;
        while(temp != nullptr and c > temp->letter) {
            temp = temp->next;
            insertIndex++;
        }
        insertAt(c, insertIndex);
    }
}
    
// }
/*
 * Purspose: Remove the first element
 * Parameters: none
 * Return value: void
 * Effects: decrease numItems updates front
 */
void CharLinkedList::popFromFront() {
    if(isEmpty()) {
        throw std::runtime_error("cannot pop from empty LinkedList");
    }

    Node *temp = front->next;
    if(temp) {
        temp->prev = nullptr;
    }
    delete front;
    front = temp;
    if(front) {
        front->prev = nullptr;
    } else {
        back = nullptr;
    }
    numItems--;
}

/*
 * Purspose: Remove the last element
 * Parameters: none
 * Return value: void
 * Effects: decrease numItems and updates back
 */
void CharLinkedList::popFromBack() {
    if(isEmpty()) {
        throw std::runtime_error("cannot pop from empty LinkedList");
    }

    Node *temp = back->prev;
    if(temp) {
        temp->next = nullptr;
    } else {
        front = nullptr;
        temp = front;
    }
    delete back;
    back = temp;
    numItems--;
}

/*
 * Purspose: Remove an element at a given index
 * Parameters: int index
 * Return value: void
 * Effects: decrease numItems and updates front and back if needed
 */
void CharLinkedList::removeAt(int index) {
    if(index < 0 or index > numItems - 1 or numItems == 0) {
        throw std::range_error("index (" + std::to_string(index) + 
        ") not in range [0.." + std::to_string(numItems) + ")");
    }
    if(index == 0) {
        popFromFront();
    } else if(index == numItems - 1) {
        popFromBack();
    } else {
        Node *removeNode = elementAtHelper(front, index);
        Node *nodeBefore = removeNode->prev;
        Node *nodeAfter = removeNode->next;
        delete removeNode;
        nodeBefore->next = nodeAfter;
        nodeAfter->prev = nodeBefore;
        numItems--;
    }
}

void CharLinkedList::replaceAtHelper(Node *curr, char c, int index) {
    if(index == 0) {
        curr->letter = c;
        return;
    }
    return replaceAtHelper(curr->next, c, index - 1);
}

/*
 * Purspose: Replace a given element with a desired new
 *          one at a given index
 * Parameters: char c int index
 * Return value: void
 * Effects: None
 */
void CharLinkedList::replaceAt(char c, int index) {
    if(index > numItems - 1 or index < 0 or numItems == 0){
        throw std::range_error("index (" + std::to_string(index) + 
        ") not in range [0.." + std::to_string(numItems) + ")");
    }
    replaceAtHelper(front, c, index);
}

/*
 * Purspose: Concatenate two CharLinkedLists
 * Parameters: CharLinkedList *other
 * Return value: void
 * Effects: updates numItems front and back as needed
 */
void CharLinkedList::concatenate(CharLinkedList *other) {
    if(other->numItems == 0 or other->front == nullptr){
        return;
    }
    int size = other->numItems;
    for(int i = 0; i < size; i++) {
        pushAtBack(other->elementAt(i));
    }
}
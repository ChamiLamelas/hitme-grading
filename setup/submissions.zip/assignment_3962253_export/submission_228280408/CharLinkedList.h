/*
 *  CharLinkedList.h
 *  Karla Armoush
 *  02/03/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  This file is an inteface for a doubly linked list
 *
 */

#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H
#include <string>

class CharLinkedList {
public:
    CharLinkedList();
    CharLinkedList(char c); 
    CharLinkedList(char arr[], int size); 
    CharLinkedList(const CharLinkedList &other);
    ~CharLinkedList();
    CharLinkedList &operator=(const CharLinkedList &other);
    bool isEmpty() const;
    void clear();
    int size() const;
    char first() const;
    char last() const;
    char elementAt(int index) const;
    std::string toString() const;
    std::string toReverseString() const;
    void pushAtBack(char c);
    void pushAtFront(char c);
    void insertAt(char c, int index);
    void insertInOrder(char c);
    void popFromFront();
    void popFromBack();
    void removeAt(int index);
    void replaceAt(char c, int index);
    void concatenate(CharLinkedList *other);

private:
    struct Node {
        Node* next;
        Node* prev;
        char data;
    };
        Node *front;
        Node *back;
        int listSize;
        
        Node *newNode(char c, Node *next, Node *prev);
        void destroyRecursively(Node *curr);
        char getChar(int index, Node *curr, int count) const;
        Node *getNode(Node *curr, int index, int count);
};

#endif

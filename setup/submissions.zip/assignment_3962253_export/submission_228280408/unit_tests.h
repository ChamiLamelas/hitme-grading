/*
*  unit_tests.h
*  Karla Armoush
*  02/06/2024
*
*  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
*
*  This file contains unit tests for each function in CharLinkedList.cpp
*
*/

#include "CharLinkedList.h"
#include <cassert>
#include <iostream>
#include <string>

using namespace std;

//Testing the default constructor.
void default_constructor_test() {
    CharLinkedList test_list;
    assert(test_list.size() == 0);
    assert(test_list.isEmpty());
}

//Testing constructor with one character.
void second_contructor_test() {
    CharLinkedList test_list('a');
    assert(test_list.size() == 1);
    assert(not test_list.isEmpty());
}

//Testing constructor with an array of characters.
void third_contructor_test() {
    char test_arr[3] = { 'a', 'b', 'c'};
    CharLinkedList test_list(test_arr, 3);
    assert(test_list.size() == 3);
    assert(not test_list.isEmpty());
}

//Testing isEmpty with an empty list
void isEmpty_empty_test() {
    CharLinkedList test_list;
    assert(test_list.size() == 0);
    assert(test_list.isEmpty());
}

//Testing isEmpty with a non-empty list
void isEmpty_nonempty_test() {
    CharLinkedList test_list('a');
    assert(test_list.size() == 1);
    assert(not test_list.isEmpty());
}

//Testing if the size is functioning properly
void size_test() {
    CharLinkedList test_list1('a'); 
    assert(test_list1.size() == 1);
    CharLinkedList test_list2; 
    assert(test_list2.size() == 0);
    assert(test_list2.isEmpty());
    char test_arr[3] = { 'a', 'b', 'c'};
    CharLinkedList test_list3(test_arr, 3);
    assert(test_list3.size() == 3);
}


//Testing pushing a character into an empty list.
void pushAtBack_empty_test() {
    CharLinkedList test_list;
    test_list.pushAtBack('a');
    assert(not test_list.isEmpty());
    assert(test_list.size() == 1);
}

//Testing pushing a character into an non-empty list.
void pushAtBack_nonempty_test() {
    CharLinkedList test_list('a');
    test_list.pushAtBack('b');
    assert(not test_list.isEmpty());
    assert(test_list.size() == 2);
}

//Test stroring an empty list in a string.
void toString_empty_test() {
    CharLinkedList test_list;
    assert(test_list.toString() == "[CharLinkedList of size 0 <<>>]");
}

//Test stroring an the characters of a non-empty list in a string.
void toString_nonempty_test() {
    char test_arr[3] = { 'a', 'b', 'c'};
    CharLinkedList test_list(test_arr, 3);
    assert(test_list.toString() == "[CharLinkedList of size 3 <<abc>>]");
}

//Running toReverseString on a list with multiple nodes/elements once.
void toReverseString_multiple_test_once() {
    char test_arr[3] = { 'a', 'b', 'c'};
    CharLinkedList test_list(test_arr, 3);
    assert(test_list.toReverseString() == "[CharLinkedList of size 3 <<cba>>]");
}

//Running toReverseString on a list with two nodes/elements.
void toReverseString_two_test() {
    char test_arr[3] = { 'a', 'b'};
    CharLinkedList test_list(test_arr, 2);
    assert(test_list.toReverseString() == "[CharLinkedList of size 2 <<ba>>]");
}

//Running toReverseString on a list with one node/element.
void toReverseString_single_test() {
    CharLinkedList test_list('a');
    assert(test_list.toReverseString() == "[CharLinkedList of size 1 <<a>>]");
}

//Running toReverseString on an empty list.
void toReverseString_empty_test() {
    CharLinkedList test_list;
    assert(test_list.toReverseString() == "[CharLinkedList of size 0 <<>>]");
}

//Clearing an empty linked list.
void clear_empty_test() {
    CharLinkedList test_list;
    test_list.clear();
    assert(test_list.toString() == "[CharLinkedList of size 0 <<>>]");
}

//Clearing a non-empty linked list: multiple elements/nodes.
void clear_multiple_test() {
    char test_arr[3] = { 'a', 'b', 'c'};
    CharLinkedList test_list(test_arr, 3);
    test_list.clear();
    assert(test_list.toString() == "[CharLinkedList of size 0 <<>>]");
}

//Clearing a non-empty linked list: one element/node.
void clear_single_test() {
    CharLinkedList test_list('a');
    test_list.clear();
    assert(test_list.toString() == "[CharLinkedList of size 0 <<>>]");
}

//Testing elementAt with indices that are out of bounds.
void elementAt_outOfBounds_empty() {
    bool range_error_thrown = false;
    std::string error_message = "";
    CharLinkedList test_list;
    try {
        test_list.elementAt(10);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (10) not in range [0..0)");   
}

//Testing elementAt with indices that are out of bounds for a non-empty list.
void elementAt_outOfBounds_nonempty() {
    bool range_error_thrown = false;
    std::string error_message = "";
    char test_arr[3] = { 'b', 'c', 'd'};
    CharLinkedList test_list(test_arr, 3);
    try {
        test_list.elementAt(3);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (3) not in range [0..3)");   
}

//Testing accessing elements at various indices in a list of multiple elements.
void elementAt_test_multipleElements() {
    char test_arr[3] = { 'b', 'c', 'd'};
    CharLinkedList test_list(test_arr, 3);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'c');
    assert(test_list.elementAt(2) == 'd');  
}

//Testing accessing elements in a list with one element.
void elementAt_test_oneElement() {
    CharLinkedList test_list('a');
    assert(test_list.elementAt(0) == 'a');
    test_list.pushAtBack('b');
    assert(test_list.elementAt(1) == 'b');
}

//Testing incorrect insertion into an empty list.
void insertAt_empty_correct() { 
    CharLinkedList test_list;
    test_list.insertAt('a', 0);
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');
}

// Testing incorrect insertion into an empty AL.
// Attempts to call insertAt for index larger than 0.
// This should result in an std::range_error being raised.
void insertAt_empty_incorrect() {

    bool range_error_thrown = false;

    std::string error_message = "";

    CharLinkedList test_list;
    try {
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0]");

}

//Testing incorrect insertion into an empty list.
void insertAt_front_singleton_list() {

    CharLinkedList test_list('a');

    test_list.insertAt('b', 0);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'a');

}

//Testing correct insertAt for back of 1-element list.
void insertAt_back_singleton_list() {

    CharLinkedList test_list('a');

    test_list.insertAt('b', 1);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');

}

//Testing inserting multiple elements into a list.
void insertAt_many_elements() {

    CharLinkedList test_list;

    for (int i = 0; i < 1000; i++) {
        test_list.insertAt('a', i);
    }

    assert(test_list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }

}

//Testing insertion into front of a larger list
void insertAt_front_large_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g' };
    CharLinkedList test_list(test_arr, 8);

    test_list.insertAt('y', 0);

    assert(test_list.size() == 9);
    assert(test_list.elementAt(0) == 'y');
    assert(test_list.toString() == "[CharLinkedList of size 9 <<yabczdefg>>]");

}

//Testing insertion into the back of a larger list
void insertAt_back_large_list() {

    char test_arr[10] = { 'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 10);  

    test_list.insertAt('x', 10);

    assert(test_list.size() == 11);
    assert(test_list.elementAt(10) == 'x');
    assert(test_list.toString() == 
    "[CharLinkedList of size 11 <<yabczdefghx>>]"); 

}

//Testing insertion into the middle of a larger list
void insertAt_middle_large_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.insertAt('z', 3);

    assert(test_list.size() == 9);
    assert(test_list.elementAt(3) == 'z');
    assert(test_list.toString() == "[CharLinkedList of size 9 <<abczdefgh>>]");

}

//Testing out-of-range insertion for a non-empty list.
void insertAt_nonempty_incorrect() {

    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    bool range_error_thrown = false;

    std::string error_message = "";

    try {
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8]");

}

//Testing removing from the front of a list.
void removeAt_front_test() {
    CharLinkedList test_list('a');
    test_list.pushAtBack('b');
    test_list.removeAt(0);
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'b');
    test_list.removeAt(0);
    assert(test_list.size() == 0);
    assert(test_list.isEmpty());
}

//Testing removing from the middle of a list.
void removeAt_middle_test() {
    char test_arr[3] = { 'a', 'b', 'c'};
    CharLinkedList test_list(test_arr, 3);
    test_list.removeAt(1);
    assert(test_list.size() == 2);
    assert(test_list.elementAt(1) == 'c');
    assert(test_list.toString() == "[CharLinkedList of size 2 <<ac>>]");
}

//Testing removing from the back of a list.
void removeAt_test_last_element() {
    char test_arr[3] = { 'a', 'b'};
    CharLinkedList test_list(test_arr, 2);
    test_list.removeAt(1);
    assert(test_list.size() == 1);
    assert(not test_list.isEmpty());
    assert(test_list.toString() == "[CharLinkedList of size 1 <<a>>]");
}

//Testing removing from an empty list.
void removeAt_outOfBounds_index() {
    bool range_error_thrown = false;
    std::string error_message = "";
    CharLinkedList test_list;
    try {
        test_list.removeAt(10);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (10) not in range [0..0)");   
}

//Testing obtaining the first element from a single-element list.
void first_single_test() {
    CharLinkedList test_list('a');
    assert(test_list.first() == 'a');
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.size() == 1);
    assert(test_list.toString() == "[CharLinkedList of size 1 <<a>>]");
}

//Testing obtaining the first element from a multiple-element list.
void first_multiple_test() {
    char test_arr[3] = { 'a', 'b', 'c'};
    CharLinkedList test_list(test_arr, 3);
    assert(test_list.first() == 'a');
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.size() == 3);
    assert(test_list.toString() == "[CharLinkedList of size 3 <<abc>>]");
}

//Testing obtaining the first element from an empty list.
void first_empty_test() {
    bool runtime_error_thrown = false;
    std::string error_message = "";
    CharLinkedList test_list;
    try {
        test_list.first();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "cannot get first of empty LinkedList");  
}

//Testing obtaining the last element from a single-element list.
void last_single_test() {
    CharLinkedList test_list('a');
    assert(test_list.last() == 'a');
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.size() == 1);
    assert(test_list.toString() == "[CharLinkedList of size 1 <<a>>]");
}

//Testing obtaining the last element from a multiple-element list.
void last_multiple_test() {
    char test_arr[3] = { 'a', 'b', 'c'};
    CharLinkedList test_list(test_arr, 3);
    assert(test_list.last() == 'c');
    assert(test_list.elementAt(2) == 'c');
    assert(test_list.size() == 3);
    assert(test_list.toString() == "[CharLinkedList of size 3 <<abc>>]");
}

//Testing obtaining the first element from an empty list.
void last_empty_test() {
    bool runtime_error_thrown = false;
    std::string error_message = "";
    CharLinkedList test_list;
    try {
        test_list.last();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "cannot get last of empty LinkedList");  
}

//Pushing at the front of an empty list.
void pushAtFront_empty_test() {
    CharLinkedList test_list;
    test_list.pushAtFront('a');
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.toString() == "[CharLinkedList of size 1 <<a>>]");
}

//Pushing at the front of a list with a single node/element.
void pushAtFront_single_test() {
    CharLinkedList test_list('b');
    test_list.pushAtFront('a');
    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.toString() == "[CharLinkedList of size 2 <<ab>>]");
}

//Pushing at the front of a list with multiple nodes/elements several times.
void pushAtFront_test_3() {
    char test_arr[3] = { 'a', 'b', 'c'};
    CharLinkedList test_list(test_arr, 3);
    test_list.pushAtFront('d');
    assert(test_list.size() == 4);
    assert(test_list.elementAt(0) == 'd');
    assert(test_list.toString() == "[CharLinkedList of size 4 <<dabc>>]");
    test_list.pushAtFront('e');
    assert(test_list.size() == 5);
    assert(test_list.elementAt(0) == 'e');
    assert(test_list.toString() == "[CharLinkedList of size 5 <<edabc>>]");
    test_list.pushAtFront('f');
    assert(test_list.size() == 6);
    assert(test_list.elementAt(0) == 'f');
    assert(test_list.toString() == "[CharLinkedList of size 6 <<fedabc>>]");
}

//Popping from the front of a list with multiple elements several times.
void popFromFront_multiple_test() {
    char test_arr[3] = { 'a', 'b', 'c'};
    CharLinkedList test_list(test_arr, 3);
    test_list.popFromFront();
    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.toString() == "[CharLinkedList of size 2 <<bc>>]");
    test_list.popFromFront();
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'c');
    assert(test_list.toString() == "[CharLinkedList of size 1 <<c>>]");
}

//Popping from the front of a list with a single node/element
void popFromFront_test_2() {
    CharLinkedList test_list('a');
    test_list.popFromFront();
    assert(test_list.size() == 0);
    assert(test_list.toString() == "[CharLinkedList of size 0 <<>>]");
}

//Popping from the front of an empty list
void popFromFront_empty_test() {
    bool runtime_error_thrown = false;
    std::string error_message = "";
    CharLinkedList test_list;
    try {
        test_list.popFromFront();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");  
}

//Popping from the back of a list with multiple elements several times.
void popFromBack_multiple_test() {
    char test_arr[3] = { 'a', 'b', 'c'};
    CharLinkedList test_list(test_arr, 3);
    test_list.popFromBack();
    assert(test_list.size() == 2);
    assert(test_list.toString() == "[CharLinkedList of size 2 <<ab>>]");
    test_list.popFromBack();
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.toString() == "[CharLinkedList of size 1 <<a>>]");
}

//Popping from the back of a list with a single node/element
void popFromBack_single_test() {
    CharLinkedList test_list('a');
    test_list.popFromBack();
    assert(test_list.size() == 0);
    assert(test_list.toString() == "[CharLinkedList of size 0 <<>>]");
}

//Popping from the back of an empty list
void popFromBack_empty_test() {
    bool runtime_error_thrown = false;
    std::string error_message = "";
    CharLinkedList test_list;
    try {
        test_list.popFromBack();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");  
}

//Replacing characters in a list with multiple nodes several times.
void replaceAt_multiple_test() {
    char test_arr[3] = { 'a', 'b', 'c'};
    CharLinkedList test_list(test_arr, 3);
    test_list.replaceAt('f', 1);
    test_list.replaceAt('f', 0);
    assert(test_list.elementAt(1) == 'f');
    assert(test_list.size() == 3);
    assert(test_list.toString() == "[CharLinkedList of size 3 <<ffc>>]");
}

//Replacing at an index which is out of bounds.
void replaceAt_outOfBounds_test() {
    bool range_error_thrown = false;
    std::string error_message = "";
    CharLinkedList test_list;
    try {
        test_list.replaceAt('c', 10);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (10) not in range [0..0)");  
}

//Replacing at a negative index which is out of bounds.
void replaceAt_outOfBounds2_test() {
    bool range_error_thrown = false;
    std::string error_message = "";
    CharLinkedList test_list;
    try {
        test_list.replaceAt('c', -1);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (-1) not in range [0..0)");  
}

//Replacing at the front and back and middle of the list
void replaceAt_allCases_test() {
    char test_arr[3] = { 'a', 'b', 'c'};
    CharLinkedList test_list(test_arr, 3);
    test_list.replaceAt('w', 0);
    test_list.replaceAt('w', 1);
    test_list.replaceAt('w', 2);
    assert(test_list.toString() == "[CharLinkedList of size 3 <<www>>]");
}

//Testing the copy constructor for a non-empty list.
void copy_constructor_nonempty_test() {
    char test_arr[3] = { 'a', 'b', 'c'};
    CharLinkedList test_list1(test_arr, 3);
    CharLinkedList test_list2(test_list1);
    test_list2.pushAtBack('d');
    assert(test_list2.toString() == "[CharLinkedList of size 4 <<abcd>>]");
    assert(test_list1.toString() == "[CharLinkedList of size 3 <<abc>>]");
}

//Testing the copy constructor for a empty list.
void copy_constructor_empty_test() {
    CharLinkedList test_list1;
    CharLinkedList test_list2(test_list1);
    test_list2.pushAtBack('d');
    assert(test_list2.size() == 1);
    assert(test_list1.size() == 0);
}

//Makes sure the contents of one CharArrayList to are being assigned properly
//to another array list
void assignment_operator_test() {
    char test_arr[3] = { 'a', 'b', 'c'};
    CharLinkedList test_list(test_arr, 3);
    CharLinkedList test_list1;
    test_list1 = test_list;
    test_list1.pushAtBack('d');
    assert(test_list1.toString() == "[CharLinkedList of size 4 <<abcd>>]");
    assert(test_list.toString() == "[CharLinkedList of size 3 <<abc>>]");
}

//Inserting in ASCII order into a non-empty list in the middle 
void insertInOrder_middle_test() {
    char test_arr[3] = { 'a', 'b', 'd'};
    CharLinkedList test_list(test_arr, 3);
    test_list.insertInOrder('c');
    assert(test_list.toString() == "[CharLinkedList of size 4 <<abcd>>]");
}

//Inserting in ASCII order into a non-empty list at the front and at the back
void insertInOrder_frontAndBack_test() {
    char test_arr[3] = { 'b', 'c'};
    CharLinkedList test_list(test_arr, 2);
    test_list.insertInOrder('a');
    assert(test_list.toString() == "[CharLinkedList of size 3 <<abc>>]");
    test_list.insertInOrder('d');
    assert(test_list.toString() == "[CharLinkedList of size 4 <<abcd>>]");
}

//Inserting in ASCII order into a linked list when the character being 
//inserted is the same as the first element of the list
void insertInOrder_same_test() {
    char test_arr[3] = { 'c', 'e', 'f'};
    CharLinkedList test_list(test_arr, 3);
    test_list.insertInOrder('c');
    assert(test_list.toString() == "[CharLinkedList of size 4 <<ccef>>]");
}

//Inserting in ASCII order into an empty list
void insertInOrder_empty_test() {
    CharLinkedList test_list;
    test_list.insertInOrder('a');
    assert(test_list.toString() == "[CharLinkedList of size 1 <<a>>]");
}

//Inserting in ASCII order 
void insertInOrder_edgeCase_test() {
    char test_arr[4] = { 'a', 'b', 'c', 'd'};
    CharLinkedList test_list(test_arr, 4);
    test_list.insertInOrder('7');
    assert(test_list.toString() == "[CharLinkedList of size 5 <<7abcd>>]");
}

//Concatenating one non-empty list with another non-empty list
void concatenate_two_nonempty_lists_test() {
    char test_arr1[1] = { 'o'};
    CharLinkedList CharLinkedListOne(test_arr1, 1);
    char test_arr2[1] = {'i'};
    CharLinkedList CharLinkedListTwo(test_arr2, 1);
    CharLinkedListOne.concatenate(&CharLinkedListTwo);
    assert(CharLinkedListOne.toString() == "[CharLinkedList of size 2 <<oi>>]");
}

//Concatenating one empty list with another non-empty list
void concatenat_test_1() {
    char test_arr1[2] = { 'h', 'e'};
    CharLinkedList CharLinkedListOne(test_arr1, 2);
    CharLinkedList CharLinkedListTwo;
    CharLinkedListOne.concatenate(&CharLinkedListTwo);
    assert(CharLinkedListOne.toString() == "[CharLinkedList of size 2 <<he>>]");
}

//Concatenating one non-empty list with another empty list
void concatenate_test_2() {
    CharLinkedList CharLinkedListOne;
    char test_arr[1] = {'y'};
    CharLinkedList CharLinkedListTwo(test_arr, 1);
    CharLinkedListOne.concatenate(&CharLinkedListTwo);
    assert(CharLinkedListOne.toString() == "[CharLinkedList of size 1 <<y>>]");
}

//Self-concatenation test
void self_concatenation_test() {
    char test_arr[1] = {'o'};
    CharLinkedList CharLinkedListOne(test_arr, 1);
    CharLinkedListOne.concatenate(&CharLinkedListOne);
    assert(CharLinkedListOne.toString() == "[CharLinkedList of size 2 <<oo>>]");
}

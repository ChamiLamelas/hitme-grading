/*
 *  CharLinkedList.cpp
 *  Karla Armoush
 *  02/03/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  This file implements a doubly linked list (DLL) class. 
 *  A DLL can be traversed in both forward and backward directions. 
 *
 */

#include "CharLinkedList.h"

#include <sstream>
#include <string>
#include <iostream>

using namespace std;

/*
 * name:      node_maker
 * purpose:   Creates a new node on the heap
 * arguments: the data that the node holds (a character) and the pointer to the
 *            next node
 * returns:   none
 * effects:   Allocates memory for a new node on the heap.  
 */
CharLinkedList::Node *CharLinkedList::newNode(char c, Node *next, Node *prev) {
    Node *new_node = new Node;
    new_node->data = c;
    new_node->next = next;
    new_node->prev = prev;

    return new_node;
}

/*
 * name:      CharLinkedList default constructor
 * purpose:   Initializes an empty CharLinkedList
 * arguments: none
 * returns:   none 
 * effects:   Initializes the front and back pointers to nullptr and sets the 
 *            list size to 0. 
 */
CharLinkedList::CharLinkedList() {
    front = nullptr;
    back = nullptr;
    listSize  = 0;
}

/*
 * name:      size
 * purpose:   Returns the number of elements in the CharLinkedList
 * arguments: none
 * returns:   the number of elements currently stored in the CharLinkedList
 * effects:   none
 */
int CharLinkedList::size() const {
    return listSize; 
}

/*
 * name:      isEmpty
 * purpose:   Checks if the CharLinkedList is empty
 * arguments: none
 * returns:   true if CharArrayList contains no elements, false otherwise
 * effects:   none
 */
bool CharLinkedList::isEmpty() const {
    if (listSize == 0) {
        return true;
    }
    return false; 
}

/*
 * name:      CharLinkedList destructor
 * purpose:   Cleans up memory allocated on the heap
 * arguments: none
 * returns:   none
 * effects:   Deallocates memory for all nodes in the CharLinkedList
 */
CharLinkedList::~CharLinkedList() {
    if (front == nullptr) {
        return;
    }
    destroyRecursively(front);
}

/*
 * name:      CharLinkedList destructor private recursive function
 * purpose:   Cleans up memory allocated on the heap
 * arguments: none
 * returns:   none
  * effects:  Frees up memory for all nodes in the CharLinkedList recursively
 */
void CharLinkedList::destroyRecursively(Node *curr) {
    if (curr == nullptr) {
        return;
    } 
    destroyRecursively(curr->next);
    delete curr;
}

/*
 * name:      CharLinkedList second constructor
 * purpose:   Initializes a CharLinkedList with a single character
 * arguments: a character (c)
 * returns:   none
 * effects:   Initializes a CharLinkedList with a single character and sets the 
 *            list size to 1
 */
CharLinkedList::CharLinkedList(char c) {
    listSize = 1;
    Node *new_node = newNode(c, nullptr, nullptr);
    front = back = new_node;
}

/*
 * name:      pushAtBack
 * purpose:   Adds a new character to the back of the linked list
 * arguments: a character (c)
 * returns:   none
 * effects:   Inserts a new node containing the character at the back of the 
 *            list and increments the list size accordingly
 */
void CharLinkedList::pushAtBack(char c) {
    //pushAtBack is a special case of insertAt
    insertAt(c, listSize);
}

/*
 * name:      CharLinkedList third constructor
 * purpose:   Constructs a list of multiple characters
 * arguments: An array of characters and the size of it
 * returns:   none
 * effects:     Initializes a CharLinkedList with characters from an array
 */
CharLinkedList::CharLinkedList(char arr[], int size) {
    listSize = 0;
    front = back = nullptr;
    //Use pushAtBack to add the elements of the array to the list
    for (int i = 0; i < size; i++) { 
        pushAtBack(arr[i]);
    }  
}

/*
 * name:      toString
 * purpose:   Stores the characters on the list in a string
 * arguments: An array of characters and the size of it
 * returns:   none
 * effects:   none
 */
std::string CharLinkedList::toString() const {
    //Start from the front of the list
    Node *curr_node = front;
    //Traverse the list from back to front and add the characters to the string
    std::string str = "[CharLinkedList of size " + std::to_string(listSize) + 
    " <<";
    for (int i = 0; i < listSize; i++) {
        str += curr_node->data;
        curr_node = curr_node->next;
    } 
    str += ">>]";
    return str;
}

/*
 * name:      toReverseString
 * purpose:   Returns a string containing the characters of the CharLinkedList 
 *            in reverse order
 * arguments: none
 * returns:   a string representing the CharLinkedList in reverse
 * effects:   none
 */
std::string CharLinkedList::toReverseString() const {
    //Start from the front of the list
    Node *curr_node = back; 
    std::string str = "[CharLinkedList of size " + std::to_string(listSize) + 
    " <<";
    //Traverse the list from back to front and add the characters to the string
    while (curr_node != nullptr) {
        str += curr_node->data;
        curr_node = curr_node->prev;
    }
    str += ">>]";
    return str;
}

/*
 * name:      clear
 * purpose:   Empties the list and frees up memory
 * arguments: none
 * returns:   none
 * effects:   Deallocates memory for all nodes in the CharLinkedList and resets 
 *            the list size to 0
 */
void CharLinkedList::clear() {
    destroyRecursively(front);
    listSize = 0;
    front = nullptr;
    back = nullptr;
}

/*
* name:      elementAt
* purpose:   retrieves the character at the specified index in the list
* arguments: an integer index
* returns:   the character at the specified index
* effects:   none
*/
char CharLinkedList::elementAt(int index) const {
    char char_atIndex;
    if (index < 0 or index >= listSize) {
        throw range_error("index (" + std::to_string(index) + 
        ") not in range [0.." + std::to_string(listSize) + ")");
    }
    char_atIndex = getChar(index, front, 0);
    return char_atIndex;
}

/*
* name:      getChar
* purpose:   elementAt private recursive function
* arguments: an integer index, a pointer to the current node, a counter to keep 
*            track of the element that the program is at
* returns:   the character at the specified index
* effects:   none
*/
char CharLinkedList::getChar(int index, Node *curr, int count) const {
    if (count == index) {
        return curr->data;
    }
    count++;
    return getChar(index, curr->next, count);
}

/*
* name:      insertAt
* purpose:   adds a node to the list at the specified index
* arguments: a character and an integer index
* returns:   none
* effects:   inserts a new node containing the character at the specified index 
*            and increments the list size
*/
void CharLinkedList::insertAt(char c, int index) {
    if (index < 0 or index >= listSize + 1) {
        throw range_error("index (" + std::to_string(index) + 
        ") not in range [0.." + std::to_string(listSize) + "]");
    }
    //Inserting in an empty list
    if (isEmpty()) {
        Node *new_node = newNode(c, nullptr, nullptr);
        front = new_node;
        back = new_node;
    } else {
        //Inserting at the front of the list
        if (index == 0) {
            Node *curr = front;
            Node *new_node = newNode(c, curr, nullptr);
            curr->prev = new_node;
            front = new_node;
        //Insering at the back of the list
        } else if (index == listSize) {
            Node *curr = back;
            Node *new_node = newNode(c, nullptr, curr);
            back = new_node;
            curr->next = new_node;
        //Inserting in the middle of the list
        } else {
            Node *curr = getNode(front, index - 1, 0);
            Node *old = curr->next;
            Node *new_node = newNode(c, old, curr);
            curr->next = new_node;
            old->prev = new_node;
        }
    }
    listSize++; //Increasing the size of the list in line with the insertion
}

/*
* name:      getNode
* purpose:   insertAt private recursive function, used to find the node with the
*            specified index
* arguments: an integer index, the current node, a counter to keep track of the
*            element that the program is at
* returns:   the node at the specified index
* effects:   none 
*/
CharLinkedList::Node *CharLinkedList::getNode(Node *curr, int index,
                                                         int count) {
    if (count == index) {  
        return curr;
    }
    count++;
    return getNode(curr->next, index, count);
}

/*
* name:      removeAt
* purpose:   removes a node from the list at the specified index
* arguments: an integer index
* returns:   none
*/
void CharLinkedList::removeAt(int index) {
    if (index < 0 or index >= listSize + 1) {
        throw range_error("index (" + std::to_string(index) + 
        ") not in range [0.." + std::to_string(listSize) + ")");
    }
    //Removing the first element
    if (index == 0) {
        if (listSize == 1) {
            delete front;
            front = back = nullptr;
        } else {
            Node *to_be_deleted = front;
            Node *new_first = to_be_deleted->next;
            new_first->prev = nullptr;
            front = new_first;
            delete to_be_deleted;
        }
    //Removing the last element
    } else if (index == listSize - 1) {
        Node *to_be_deleted = back;
        Node *new_back = to_be_deleted->prev;
        new_back->next = nullptr;
        back = new_back;
        delete to_be_deleted;
    //Removing from the middle
    } else {
        Node *to_be_deleted = front;
        for (int i = 0; i < index; i++) {
            to_be_deleted = to_be_deleted->next;
        }
        Node *prev_node = to_be_deleted->prev;
        Node *next_node = to_be_deleted->next;
        prev_node->next = next_node;
        next_node->prev = prev_node;
        delete to_be_deleted;
    }
    listSize--;
}

/*
 * name:      first
 * purpose:   returns the character stored in the data variable of the first
 *            node on the linked list.
 * arguments: none
 * returns:   a character representing the data stored in the first node
 * effects:   none
 */
char CharLinkedList::first() const {
    if (isEmpty()) {
        throw runtime_error("cannot get first of empty LinkedList");
    }
    return front->data;
}

/*
 * name:      last
 * purpose:   returns the character stored in the data variable of the last
 *            node on the linked list.
 * arguments: none
 * returns:   a character representing the data stored in the last node
 * effects:   none
 */
char CharLinkedList::last() const {
    if (isEmpty()) {
        throw runtime_error("cannot get last of empty LinkedList");
    }
    return back->data;
}

/*
 * name:      pushAtFront
 * purpose:   adds a node to the list at the front
 * arguments: a character 
 * returns:   none
 * effects:   inserts a new node containing the character at the front of the
 *             list and increments the list size
 */
void CharLinkedList::pushAtFront(char c) {
    //pushAtFront is a special case of insertAt
    insertAt(c, 0);
}

/*
 * name:      popFromFront
 * purpose:   removes a node from the front of the list
 * arguments: none 
 * returns:   none
 * effects:   removes a node from the front of the list and decrements the 
 *            list size
 */
void CharLinkedList::popFromFront() {
    //If the list is empty, throw a runtime error
    if (isEmpty()) {
        throw runtime_error("cannot pop from empty LinkedList");
    }
    //popFromFront is a special case of removeAt
    removeAt(0);
}

/*
 * name:      popFromBack
 * purpose:   removes a node from the back of the list
 * arguments: none 
 * returns:   none
 * effects:   removes a node from the front of the list and decrements the 
 *            list size
 */
void CharLinkedList::popFromBack() {
    //If the list is empty, throw a runtime error
    if (isEmpty()) {
        throw runtime_error("cannot pop from empty LinkedList");
    }
    //popFromBack is a special case of removeAt
    removeAt(listSize - 1);
}

void CharLinkedList::replaceAt(char c, int index) {
    if (index < 0 or index >= listSize) {
        throw range_error("index (" + std::to_string(index) + 
        ") not in range [0.." + std::to_string(listSize) + ")");
    }
    Node *replace = getNode(front, index, 0);
    replace->data = c;
}

/*
 * name:      CharLinkedList copy constructor
 * purpose:   Creates a deep copy of a given CharLinkedList.
 * arguments: another CharLinkedList (other)
 * returns:   none
 * effect:    creates a copy of a list
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other) {
    front = back = nullptr;
    listSize = 0;
    Node *curr = other.front;
    while (curr != nullptr) {
        pushAtBack(curr->data);
        curr = curr->next;
    }
}

/*
 * name:      assignment operator
 * purpose:   Assigns the contents of one CharLinkedList to another
 * arguments: another CharLinkedList (other)
 * returns:   a reference to the modified CharLinkedList
 * effects:   assigns the contents of one CharLinkedList to another
 */
CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other) {
    if (this == &other) {
        return *this;
    }
    clear();
    Node *curr = other.front;
    while (curr != nullptr) {
        pushAtBack(curr->data);
        curr = curr->next;
    }
    return *this;
}

/*
 * name:      insertInOrder
 * purpose:   Inserts a character in ascending order into the CharLinkedList
 * arguments: a character (c)
 * returns:   none
 * effects:   Inserts a character in ascending order into the CharLinkedList
 */
void CharLinkedList::insertInOrder(char c) {
    if (isEmpty() or c >= back->data) {
        pushAtBack(c);
        return;
    }
    if (c <= front->data) {
        pushAtFront(c);
        return;
    }
    Node *curr = front;
    int index = 0;
    while (curr != nullptr and c > curr->data) {
        Node *prev = nullptr;
        prev = curr;
        curr = curr->next;
        index++;
    }
    insertAt(c, index);
}

/*
 * name:      concatenate
 * purpose:   adds a copy of the array list pointed to by the parameter value 
 *            to the end of the array list the function was called from
 * arguments: pointer to a second CharArrayList to be concatenated
 * returns:   none
 * effects:   none
 */
void CharLinkedList::concatenate(CharLinkedList *other) {
    if (other->isEmpty()) {
        return;
    }
    int index = other->listSize;
    for (int i = 0; i < index; i++) {
        this->pushAtBack(other->elementAt(i));
    }
}

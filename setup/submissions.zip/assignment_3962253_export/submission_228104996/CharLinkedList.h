/*
 *  CharLinkedList.h
 *  Susan Nguyen
 *  1/30/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Header file for CharLinkedList which is a class that represents a doubly
 *  linked list of chars. There are default and parameterized constructors,
 *  which allows the user to decide whether the linked list starts off empty,
 *  copied from an array, copied from another linked list, or starts at a single
 *  node. The public functions allow the user to access and modify the
 *  LinkedList. In this doubly linked list, there is both a front and back
 *  pointer allowing for easy access.
 *
 */

#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H

#include<iostream>
#include<string>
using namespace std;

class CharLinkedList {
    public:
    CharLinkedList();
    CharLinkedList(char c);
    CharLinkedList(char arr[], int size);
    CharLinkedList(const CharLinkedList &other);

    ~CharLinkedList();

    CharLinkedList &operator=(const CharLinkedList &other);
    bool isEmpty() const;
    void clear();
    int size() const;
    char first() const;
    char last() const;
    char elementAt(int index) const;
    std::string toString() const;
    std::string toReverseString() const;
    void pushAtBack(char c);
    void pushAtFront(char c);
    void insertAt(char c, int index);
    void insertInOrder(char c);
    void popFromFront();
    void popFromBack();
    void removeAt(int index);
    void replaceAt(char c, int index);
    void concatenate(CharLinkedList *other);

    private:
        struct Node {
            char element;
            Node *next;
            Node *prev;

            Node(char c);
            Node(char, Node *after);
        };

    Node *front;
    Node *back;
    int len;
    Node *help_loop(int index, Node *curr) const;
    void erasure(Node *curr);
};

#endif
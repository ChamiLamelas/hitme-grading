/*
 *  unit_tests.h
 *  Susan Nguyen
 *  1/31/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  Tests the functions in CharLinkedList.cpp
 *
 */

#include "CharLinkedList.h"
#include <cassert>

/********************************************************************\
*                       CHAR LINKED LIST TESTS                       *
\********************************************************************/

// Tests if the default constructor creates a list with size 0
void default_constructor() {
    CharLinkedList test_list;

    assert(test_list.size() == 0);
}

// Tests if the parameterized constructor creates a list with size 1
void constructor_two() {
    CharLinkedList test_list('a');

    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');
}

// Tests if the parameterized constructor creates a list with the same size 
// and contents as the array and int passed in
void constructor_three() {
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    assert(test_list.size() == 9);

    assert(test_list.elementAt(8) == 'h');
    assert(test_list.toString() == "[CharLinkedList of size 9 <<abczdefgh>>]");
}

// Tests if the parameterized constructor creates a list with the same contents
// as the passed in list
void constructor_four() {
    // CharLinkedList smile('a');
    // CharLinkedList test_list(smile);

    char smile[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList smile_list(smile, 9);
    CharLinkedList test_list(smile_list);


    assert(test_list.size() == 9);
    assert(test_list.elementAt(8) == 'h');
    assert(test_list.toString() == "[CharLinkedList of size 9 <<abczdefgh>>]");
}

// Tests if there is a deep copy made
void deep_copy_test() {
    //CharLinkedList smile('a');
    char smile[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList smile_list(smile, 9);
    CharLinkedList frown;

    frown = smile_list;
    //frown.insertAt('a', 0);

    assert(frown.size() == 9);
    assert(frown.toString() == "[CharLinkedList of size 9 <<abczdefgh>>]");
    assert(smile_list.toString() == "[CharLinkedList of size 9 <<abczdefgh>>]");
}

// Tests the to string
void test_string() {
    //CharLinkedList test_list;
    CharLinkedList test_list('a');
    //test_list.insertAt('a', 0);

    // assert(test_list.toString() == "[CharLinkedList of size 0 <<>>]");
    assert(test_list.toString() == "[CharLinkedList of size 1 <<a>>]");
    // assert(test_list.toString() == "[CharLinkedList of size 2 <<aa>>]");
}

// Tests correct insertion into an empty AL.
// Afterwards, size should be 1 and element at index 0
// should be the element we inserted.
void insertAt_empty_correct() { 
    CharLinkedList test_list;
    test_list.insertAt('a', 0);
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');

}

// Tests incorrect insertion into an empty AL.
// Attempts to call insertAt for index larger than 0.
// This should result in an std::range_error being raised.
void insertAt_empty_incorrect() {

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    // insertAt for out-of-range index
    test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
    // if insertAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    range_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0]");
    
}

// Tests correct insertAt for front of 1-element list.
void insertAt_front_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at front
    test_list.insertAt('b', 0);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'a');
    
}

// Tests correct insertAt for back of 1-element list.
void insertAt_back_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at back
    test_list.insertAt('b', 1);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    
}

// Tests calling insertAt for a large number of elements.
// Not only does this test insertAt, it also checks that
// array expansion works correctly.
void insertAt_many_elements() {
    
    CharLinkedList test_list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.insertAt('a', i);
    }

    assert(test_list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
    
}

// Tests insertion into front of a larger list
void insertAt_front_large_list() {
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList t_list(test_arr, 9);

    t_list.insertAt('y', 0);

    assert(t_list.size() == 10);
    assert(t_list.elementAt(0) == 'y');
    assert(t_list.toString() == "[CharLinkedList of size 10 <<yabczdefgh>>]");

}

// Tests insertion into the back of a larger list
void insertAt_back_large_list() {

    char test_arr[10] = { 'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 10);  

    test_list.insertAt('x', 10);

    assert(test_list.size() == 11);
    assert(test_list.elementAt(10) == 'x');
    assert(test_list.toString() == 
    "[CharLinkedList of size 11 <<yabczdefghx>>]"); 

}

// Tests insertion into the middle of a larger list
void insertAt_middle_large_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.insertAt('z', 3);

    assert(test_list.size() == 9);
    assert(test_list.elementAt(3) == 'z');
    assert(test_list.toString() == "[CharLinkedList of size 9 <<abczdefgh>>]");
}

// Tests out-of-range insertion for a non-empty list.
void insertAt_nonempty_incorrect() {
   
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8]");
    
}

// Tests if the list is actually empty
void test_empty() {
    CharLinkedList test_list;

    assert(test_list.isEmpty());
}

// Tests access if the list is empty
void first_incorrect() {
    CharLinkedList test_list;

    bool runtime_error_thrown = false;

    std::string error_message = "";

    try{
       test_list.first(); 
    }
    catch(const std::runtime_error &e){
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot get first of empty LinkedList");
}

// Tests access for the first element in the list
void first_correct() {
    CharLinkedList test_list('a');

    assert(test_list.first() == 'a');
}

// Tests access if the list is empty
void last_incorrect() {
    CharLinkedList test_list;

    bool runtime_error_thrown = false;

    std::string error_message = "";

    try{
       test_list.last(); 
    }
    catch(const std::runtime_error &e){
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot get last of empty LinkedList");
}

// Tests access for the last element in the list
void last_correct() {
    CharLinkedList test_list('a');
    // test_list.insertAt('y', 0);

    assert(test_list.last() == 'a');
}

// Tests the reverse to string
void test_reverse() {
    char t_arr[4] = { 'a', 'b', 'c', 'z' };
    CharLinkedList t_list(t_arr, 4);

    assert(t_list.size() == 4);
    assert(t_list.toReverseString() == "[CharLinkedList of size 4 <<zcba>>]");
}

// Tests the insertion of an element to the back of the list
void test_push_back() {
    char test_arr[3] = { 'a', 'b', 'c' };
    CharLinkedList test_list(test_arr, 3);
    test_list.pushAtBack('d');

    assert(test_list.toString() == "[CharLinkedList of size 4 <<abcd>>]");
}

// Tests the insertion of an element to the front of the list
void test_push_front() {
    char test_arr[3] = { 'a', 'b', 'c' };
    CharLinkedList test_list(test_arr, 3);
    test_list.pushAtFront('a');

    assert(test_list.toString() == "[CharLinkedList of size 4 <<aabc>>]");
}

// Tests the insertion of an element in ASCII value order
void test_order() {
    char test_arr[3] = { 'a', 'b', 'c' };
    CharLinkedList test_list(test_arr, 3);
    test_list.insertInOrder('d');

    assert(test_list.toString() == "[CharLinkedList of size 4 <<abcd>>]");
}

// Tests the concatenation of one list to another
void test_concat() {
    CharLinkedList list_one('p');
    char test_arr[3] = { 'e', 'n', 'n' };
    CharLinkedList list_two(test_arr, 3);

    list_one.concatenate(&list_two);
    assert(list_one.toString() == "[CharLinkedList of size 4 <<penn>>]");
}

// Tests the removal if the list is empty
void front_pop_incorrect() {
    CharLinkedList test_list;

    bool runtime_error_thrown = false;

    std::string error_message = "";

    try{
       test_list.popFromFront(); 
    }
    catch(const std::runtime_error &e){
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

// Tests the removal of the first element in a list
void front_pop_correct() {
    CharLinkedList test_list('a');
    test_list.popFromFront();

    assert(test_list.toString() == "[CharLinkedList of size 0 <<>>]");
}

// Tests the removal if the list is empty
void back_pop_incorrect() {
    CharLinkedList test_list;

    bool runtime_error_thrown = false;

    std::string error_message = "";

    try{
       test_list.popFromBack(); 
    }
    catch(const std::runtime_error &e){
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

// Tests the removal of the last element in a list
void back_pop_correct() {
    CharLinkedList test_list('a');
    test_list.popFromBack();

    assert(test_list.toString() == "[CharLinkedList of size 0 <<>>]");
}

// Tests an out-of-range removal
void remove_incorrect() {
    bool range_error_thrown = false;

    std::string error_message = "";

    CharLinkedList test_list;
    try {
    test_list.removeAt(42);
    }
    catch (const std::range_error &e) {
    range_error_thrown = true;
    error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0)");
}

// Tests the removal of an element from the list
void remove_correct() {
    CharLinkedList test_list('a');
    test_list.insertAt('a', 1);
    test_list.insertAt('a', 1);

    test_list.removeAt(1);
    assert(test_list.toString() == "[CharLinkedList of size 2 <<aa>>]");
}

// Tests out-of-range for replacing an element in a list
void replace_incorrect() {
    bool range_error_thrown = false;

    std::string error_message = "";

    CharLinkedList test_list;
    try {
    test_list.replaceAt('c', 42);
    }
    catch (const std::range_error &e) {
    range_error_thrown = true;
    error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0)");
}

// Tests replacing an element in a list
void replace_correct() {
    CharLinkedList test_list('a');
    test_list.insertAt('b', 1);

    test_list.replaceAt('c', 1);
    assert(test_list.toString() == "[CharLinkedList of size 2 <<ac>>]");
}

// Tests the clear function
void test_clear() {
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    test_list.clear();
    assert(test_list.size() == 0);
    assert(test_list.toString() == "[CharLinkedList of size 0 <<>>]");
}

// Tests clear on an empty list
void test_empty_clear() {
    CharLinkedList test_list;
    test_list.clear();
}

// Tests concatenation with itself
void test_self_concat() {
    CharLinkedList list('p');

    list.concatenate(&list);
    assert(list.toString() == "[CharLinkedList of size 2 <<pp>>]");
}

// Tests long concatenation
void long_self_concat() {
    char test1[9] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i' };
    CharLinkedList list(test1, 9);
    
    list.concatenate(&list);
    string check = "[CharLinkedList of size 18 <<abcdefghiabcdefghi>>]";
    assert(list.toString() == check);
}

// Tests insertInOrder with many elements
void many_order_insert() {
    char test1[9] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i' };
    char test2[9] = { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I' };
    CharLinkedList list(test1, 9);
    for(int i = 0; i < 9; i++) {
        list.insertInOrder(test2[i]);
    }

    string check = "[CharLinkedList of size 18 <<ABCDEFGHIabcdefghi>>]";
    assert(list.toString() == check);
}

// Tests out of range error for elementAt
void incorrect_element() {
    bool range_error_thrown = false;

    std::string error_message = "";

    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);
    try {
        test_list.elementAt(42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..9)");
}
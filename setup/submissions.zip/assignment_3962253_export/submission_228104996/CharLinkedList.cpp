/*
 *  CharLinkedList.cpp
 *  Susan Nguyen (tnguye41)
 *  1/30/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Purpose: Implements CharLinkedList. It is an expanding list with pointers to
 *  the previous and next nodes. There are front
 *  and back pointers for easy accessibility. The front pointer's previous
 *  Node pointer and the back pointer's next Node pointer should be nullptr.
 *
 */

#include "CharLinkedList.h"

/* Parameterized constructor for Node
 * Input: one char
 * Purpose: constructor to initialize a Node in space
 * Output: returns nothing
*/
CharLinkedList::Node::Node(char c) {
    element = c;
    next = nullptr;
    prev = nullptr;
};

/* Parameterized constructor for Node
 * Input: one char and a Node pointer
 * Purpose: constructor to initialize a Node with a pointer to its
 *      previous Node
 * Output: returns nothing
*/
CharLinkedList::Node::Node(char c, Node *other) {
    element = c;
    next = other;
    prev = nullptr;
};

/* Default constructor for CharLinkedList
 * Input: no inputs
 * Purpose: constructor to initialize an empty CharLinkedList
 * Output: returns nothing
*/
CharLinkedList::CharLinkedList() {
    front = nullptr;
    back = nullptr; 
    len = 0;
};

/* Constructor for CharLinkedList
 * Input: one char
 * Purpose: constructor to initialize a CharLinkedList with a size and capacity
 *      of 1. sets the first element in CharLinkedList to c
 * Output: returns nothing
*/
CharLinkedList::CharLinkedList(char c) {
    len = 1;
    front = new Node(c);
    back = front;
};

/* Constructor for CharLinkedList
 * Input: an array of chars, and the size of the array
 * Purpose: constructor to initialize a CharLinkedList with a size and capacity
 *      of the char array passed in.
 * Output: returns nothing
*/
CharLinkedList::CharLinkedList(char arr[], int size) {
    len = size;
    front = new Node(arr[0]);
    back = front;
    for(int i = 1; i < size; i++){
        Node *curr = new Node(arr[i]);

        back->next = curr;
        back->next->prev = back; // sets the previous Node's next to it
        back = curr;
    }
};

/* Constructor for CharLinkedList
 * Input: the address of a CharLinkedList
 * Purpose: constructor to initialize a CharLinkedList to the other
 *      CharLinkedList
 * Output:
*/
CharLinkedList::CharLinkedList(const CharLinkedList &other) {
    Node *curr = other.front;
    len = other.len;
    //copies elements over
    for(int i = 0; i < other.len; i++){
        Node *temp = new Node(curr->element);

        if(i == 0){
            front = temp;
            back = temp;
        } else {
            back->next = temp;
            temp->prev = back;
            back = temp;
        }
        curr = curr->next;
    }
};

/* Deconstructor for CharLinkedList
 * Input: no inputs
 * Purpose: deletes all memory on the heap
 * Output: returns nothing
*/
CharLinkedList::~CharLinkedList() {
    erasure(front);
};

/* Deep Copy for CharLinkedList
 * Input: the address of a CharLinkedList
 * Purpose: creates a deep copy of the passed CharLinkedList
 * Output: returns the address of the copied CharLinkedList
*/
CharLinkedList & CharLinkedList::operator=(const CharLinkedList &other) {
    if(this == &other){
        return *this;
    }

    Node *curr = other.front;
    for(int i = 0; i < other.len; i++){
        Node *temp = new Node(curr->element);

        if(i == 0){
            front = temp;
            back = temp;
        } else {
            back->next = temp;
            temp->prev = back;
            back = temp;
        }
        curr = curr->next;
    }

    len = other.len;
    return *this;
}

/* isEmpty
 * Input: nothign
 * Purpose: checks to see if the CharLinkedList is empty or not by checking if
 *      the size is 0 or if the first element in the CharLinkedList is nullptr
 * Output: boolean if the CharLinkedList is empty or not
*/
bool CharLinkedList::isEmpty() const {
    if(len == 0) return true;
    return false;
}

/* clear
 * Input: nothing
 * Purpose: clears the CharLinkedList so that the size and capacity is 0.
 * Output: nothing
*/
void CharLinkedList::clear() {
    erasure(front);
    front = nullptr;
    back = nullptr;
    len = 0;
}

/* size
 * Input: nothing
 * Purpose: obtains the visible size of the CharLinkedList and returns it
 * Output: returns to visible size of the CharLinkedList
*/
int CharLinkedList::size() const {
    return len;
}

/* first
 * Input: nothing
 * Purpose: obtains the first element of CharLinkedList and returns it unless
 *      the CharLinkedList is already empty
 * Output: returns the first char in CharLinkedList
*/
char CharLinkedList::first() const {
    // checks if the list is empty
    if(isEmpty()){
        throw runtime_error("cannot get first of empty LinkedList");
    }

    return front->element;
}

/* last
 * Input: nothing
 * Purpose: obtains the last element of CharLinkedList and returns it unless the
 *      CharLinkedList is already empty
 * Output: returns the last char in CharLinkedList
*/
char CharLinkedList::last() const {
    // checks if the list is empty
    if(isEmpty()){
        throw runtime_error("cannot get last of empty LinkedList");
    }

    return back->element;
}

/* elementAt
 * Input: an int
 * Purpose: obtains an element at the passed int and returns it unless the index
 *      is not in range
 * Output: returns the char at a given index in CharLinkedList
*/
char CharLinkedList::elementAt(int index) const {
    // checks if the index is out of range
    if (index < 0 or index >= len) {
        throw range_error("index (" + to_string(index) + ") not in range "
            "[0.." + to_string(len) + ")");
    }

    Node *curr = help_loop(index, front);

    return curr->element;
}

/* toString
 * Input: nothing
 * Purpose: creates a string that contains the size and contents of
 *      CharLinkedList
 * Output: returns a string that contains the size and contents of
 *      CharLinkedList
*/
std::string CharLinkedList::toString() const {
    string str = "[CharLinkedList of size " + to_string(len) + " <<";

    for(int i = 0; i < len; i++){
        str += elementAt(i);
    }
    str += ">>]";

    return str;
}

/* toReverseString
 * Input: nothing
 * Purpose: creates a string the contains the size and contents of the
 *      CharLinkedList in reverse order
 * Output: returns a string that contains the size and contents of
 *      CharLinkedList in reverse order
*/
std::string CharLinkedList::toReverseString() const {
    string str = "[CharLinkedList of size " + to_string(len) + " <<";

    for(int i = len - 1; i >= 0; i--){
        str += elementAt(i);
    }
    str += ">>]";

    return str;
}

/* pushAtBack
 * Input: a char
 * Purpose: adds the passed in char to the end of CharLinkedList
 * Output: nothing
*/
void CharLinkedList::pushAtBack(char c) {
    insertAt(c, len);
}

/* pushAtFront
 * Input: a char
 * Purpose: adds the passed in char to the front of CharLinkedList
 * Output: nothing
*/
void CharLinkedList::pushAtFront(char c) {
    insertAt(c, 0);
}

/* insertAt
 * Input: a char and an int that represents the index
 * Purpose: inserts a passed in char at the passed in index in CharLinkedList
 *      unless the index is not in range
 * Output: nothing
*/
void CharLinkedList::insertAt(char c, int index) {
    if (index < 0 or index > len) {
        throw range_error("index (" + to_string(index) + ") not in range"
            " [0.." + to_string(len) + "]");
    }

    if(index == 0){
        front = new Node(c, front);
        len++;
        return;
    }

    Node *curr = front;
    int curr_index = 0;
    // loops until it gets to the Node before the insertation point
    while(curr_index < index - 1){
        curr = curr->next;
        curr_index++;
    }

    curr->next = new Node(c, curr->next);
    curr->next->prev = curr;

    if(index == len){
        back = curr->next;
    }
    len++;
}

/* insertInOrder
 * Input: char c
 * Purpose: inserts a passed in char in CharLinkedList in ASCII value order
 *      assuming that CharLinkedList is already sorted
 * Output: nothing
*/
void CharLinkedList::insertInOrder(char c) {
    int index = 0;
    Node *curr = front;
    for(int i = 1; i <= len; i++){
        if(curr->element <= c){
            index = i;
        }
        curr = curr->next;
    }

    insertAt(c, index);
}

/* popFromFront
 * Input: nothing
 * Purpose: removes the first element in CharLinkedList unless the
 *      CharLinkedList is already empty
 * Output: nothing
*/
void CharLinkedList::popFromFront() {
    // checks if the list is empty
    if(isEmpty()){
        throw runtime_error("cannot pop from empty LinkedList");
    }

    if(len == 1){
        delete front;
        front = nullptr;
        back = nullptr;
        len--;
        return;
    }

    Node *temp = front->next;
    delete temp->prev;
    temp->prev = nullptr;
    front = temp;
    len--;
}

/* popFromBack
 * Input: nothing
 * Purpose: removes the last element in CharLinkedList unless the CharLinkedList
 *      is already empty
 * Output: nothing
*/
void CharLinkedList::popFromBack() {
    // checks if the list is empty
    if(isEmpty()){
        throw runtime_error("cannot pop from empty LinkedList");
    }

    if(len == 1){
        delete front;
        front = nullptr;
        back = nullptr;
        len--;
        return;
    }

    Node *temp = back->prev;
    delete temp->next;
    temp->next = nullptr;
    back = temp;
    len--;
}

/* removeAt
 * Input: an int that represents the index
 * Purpose: removes the element in CharLinkedList at the passed in index unless
 *      the index is not in range
 * Output: nothing
*/
void CharLinkedList::removeAt(int index) {
    // checks if the index is out of range
    if (index < 0 or index >= len) {
        throw range_error("index (" + to_string(index) + ") not in range"
            " [0.." + to_string(len) + ")");
    }

    if(index == 0) {
        popFromFront();
        return;
    }
    if(index == len - 1) {
        popFromBack();
        return;
    }

    Node *curr = help_loop(index - 1, front);
    Node *del = curr->next;
    curr->next = del->next;
    del->next->prev = curr;
    delete del;
    len--;
}

/* replaceAt
 * Input: a char and an int that represents the index
 * Purpose: replaces the element at the passed in index with the passed in char
 *      in CharLinkedList unless the index is not in range
 * Output: nothing
*/
void CharLinkedList::replaceAt(char c, int index) {
    // checks if the index is out of range
    if (index < 0 or index >= len) {
        throw std::range_error("index (" + to_string(index) + ") not in range"
        " [0.." + to_string(len) + ")");
    }

    if(index == 0){
        Node *curr = new Node(c);
        curr->next = front->next;
        front->next->prev = curr;
        delete front;
        front = curr;
        return;
    }
    if(index == len - 1){
        Node *curr = new Node(c);
        curr->prev = back->prev;
        back->prev->next = curr;
        delete back;
        back = curr;
        return;
    }

    Node *before = help_loop(index - 1, front);
    Node *temp = before->next->next;
    before->next = new Node(c);
    before->next->next = temp;
    before->next->prev = before;
}

/* concatenate
 * Input: CharLinkedList pointer
 * Purpose: adds the contents in the passed in CharLinkedList pointer to
 *      CharLinkedList 
 * Output: nothing
*/
void CharLinkedList::concatenate(CharLinkedList *other) {
    Node *curr = other->front;
    int len2 = other->size();
    for(int i = 0; i < len2; i++){
        pushAtBack(curr->element);
        curr = curr->next;
    }
}

/* help_loop
 * Input: a Node pointer and an int that represents the index
 * Purpose: loops recursively through the LinkedList until it reaches the
 *      passed in index, starting from the passed in pointer
 * Output: pointer to a Node
*/
CharLinkedList::Node *CharLinkedList::help_loop(int index, Node *curr) const {
    if(index == 0){
        return curr;
    }
    return help_loop(index - 1, curr->next);
}

/* erasure
 * Input: Node pointer
 * Purpose: loops recursively through the LinkedList in order to delete the
 *      LinkedList
 * Output: nothing
*/
void CharLinkedList::erasure(Node *curr) {
    if(curr != nullptr){
        erasure(curr->next);
        delete curr;
    }
}
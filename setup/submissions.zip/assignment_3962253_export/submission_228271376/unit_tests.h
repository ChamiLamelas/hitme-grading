/*
 *  unit_tests.h
 *  Alexis Lee (ylee34)
 *  Feb 1, 2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  Tests methods of CharLinkedList
 *
 */

#include "CharLinkedList.h"
#include <cassert>
#include <string>
#include <stdexcept>

// tests default constructor to ensure no errors
void constructor_test0() {
    CharLinkedList test_list;
}

// tests 2nd constructor to see if object is created correctly
// should only have element A and a size of 1
void constructor_test1() {
    // initialize 1 char list
    CharLinkedList test_list('A');

    // check size
    assert(test_list.size() == 1);
    std::string test_string = "[CharLinkedList of size 1 <<A>>]";

    // check string
    assert(test_list.toString() == test_string);
    
}

// // tests third constructor to see if array is copied correctly
// // should spell string "hey" and have a size of 3 
void constructor_test2() {
    // initialize and populate list, call constructor with test_array
    
    char test_array[3] = {'h', 'e', 'y'};
    CharLinkedList test_list(test_array, 3);

    // check size and string
    
    std::string test_string = "[CharLinkedList of size 3 <<hey>>]";
    assert(test_list.size() == 3);
    assert(test_list.toString() == test_string);
}

// tests copy constructor with empty array object
// object should be a copy of other with the same size and elements
void copyConstructor_test0() {
    // create another object of CharArrayList
    char test_array[3] = {'h', 'e', 'y'};
    CharLinkedList other_test(test_array, 3);

    // call constructor and check if string of chars are identical
    CharLinkedList test_list(other_test);
    assert(other_test.toString() == test_list.toString());
}

// tests operator with already populated list object
// object should also just be a copy of other with the same size and elements
void operator_test0() {
    // create other CharArrayList
    char test_array[5] = {'h', 'e', 'l', 'l', 'o'};
    CharLinkedList other_test(test_array, 5);

    // created populated array and construct the test_list
    char test_arr[3] = {'a', 'b', 'c'};
    CharLinkedList test_list(test_arr, 3);

    test_list = other_test;

    // check size and if string of chars are identical
    assert(test_list.size() == 5);
    assert(other_test.toString() == test_list.toString());
}

// tests operator with empty list object
// object should be a copy of other object with same size and elements
void operator_test_empty() {
    // create other CharArrayList
    char test_array[5] = {'h', 'e', 'l', 'l', 'o'};
    CharLinkedList other_test(test_array, 5);

    // create empty object
    CharLinkedList test_list;

    test_list = other_test;

    // check size and if string of chars are identical
    assert(other_test.size() == 5);
    assert(other_test.toString() == test_list.toString());
}

// tests isEmpty with empty array; should be empty
void isEmpty_test0() {
    // create empty array and check if empty
    CharLinkedList test_list;
    assert (test_list.isEmpty());
}

// tests isEmpty with populated array, should not be empty
void isEmpty_test1() {
    char test_array[5] = {'h', 'e', 'l', 'l', 'o'};
    CharLinkedList test_list(test_array, 5);

    assert (not test_list.isEmpty());
}

// tests clear method on empty list object
// should be empty
void clear_test0() {
    // create empty array and then clear
    CharLinkedList test_list;
    test_list.clear();

    assert (test_list.isEmpty());
    assert (test_list.size() == 0);
}

// tests clear method on populated list object
// should be empty
void clear_test1() {
    // create populated array and then clear
    char test_array[3] = {'h', 'e', 'y'};
    CharLinkedList test_list(test_array, 3);

    test_list.clear();

    assert (test_list.isEmpty());
}

// tests size method with manually populated list object
// size should be 3
void size_test0() {
    // create populated array with size 3
    char test_array[3] = {'h', 'e', 'y'};
    CharLinkedList test_list(test_array, 3);

    assert (test_list.size() == 3);
}

// tests size method with empty list
// size should be 0
void size_test1() {
    // create empty array
    CharLinkedList test_list;

    assert (test_list.size() == 0);
}

// tests first method with empty list object
// should throw runtime error
void first_test0() {
    // create populated array 
    char test_array[3] = {'h', 'e', 'y'};
    CharLinkedList test_list(test_array, 3);

    // clear object so it is empty
    test_list.clear();
    assert (test_list.isEmpty());
    
    bool runtime_error_thrown = false;
    std::string error_message = "";

    // call first on empty list
    try {
        test_list.first();
    }

    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot get first of empty LinkedList");

}

// tests first method with populated list
// should return first character in list, 'h'
void first_test1() {
    // create populated array
    char test_array[3] = {'h', 'e', 'y'};
    CharLinkedList test_list(test_array, 3);

    assert (test_list.first() == 'h');
}

// tests last method with empty list
// should throw runtime error
void last_test0() {
    // create populated list and then clear
    char test_array[3] = {'h', 'e', 'y'};
    CharLinkedList test_list(test_array, 3);

    test_list.clear();
    assert (test_list.isEmpty());

    bool runtime_error_thrown = false;
    std::string error_message = "";

    // call last on empty array
    try {
        test_list.last();
    }

    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot get last of empty LinkedList");
    
}

// tests last method with populated list
// should return last character, 'y'
void last_test1() {
    // create populated list
    char test_array[3] = {'h', 'e', 'y'};
    CharLinkedList test_list(test_array, 3);

    assert (test_list.last() == 'y');
}

// tests elementAt with list with one character
// first element should be the only character 
void elementAt_test0() {
    // create list with one element
    CharLinkedList test_list('A');

    assert (test_list.elementAt(0) == 'A');
}

// tests incorrect case of calling elementAt
// should throw range error
void elementAt_test1() {
    // create element with one element
    CharLinkedList test_list('A');
    
    // initialize bool and string variables
    bool range_error_thrown = false;
    std::string error_message = "";

    // call elementAt at an index out of range
    try {
        test_list.elementAt(1);
    }

    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (1) not in range [0..1)");
}

void elementAt_test2() {
    // create populated list
    char test_array[3] = {'h', 'e', 'y'};
    CharLinkedList test_list(test_array, 3);
    assert(test_list.elementAt(2) == 'y');
}
// tests toString method with empty list
void toString_test0() {
    // create empty list
    CharLinkedList test_list;

    // create string to store what toString should produce
    std::string test_string = "[CharLinkedList of size 0 <<>>]";

    assert (test_string == test_list.toString());
}

// tests toString method with populated list
void toString_test1() {
    // create populated list
    char test_array[3] = {'h', 'e', 'y'};
    CharLinkedList test_list(test_array, 3);

    // create string to store what toString should produce
    std::string test_string = "[CharLinkedList of size 3 <<hey>>]";

    assert (test_string == test_list.toString());
}

// tests toReverseString method with populated list
void toReverseString_test0() {
    // create populated list
    char test_array[3] = {'h', 'e', 'y'};
    CharLinkedList test_list(test_array, 3);
    
    // create string to store what toString should produce 
    std::string test_rString = "[CharLinkedList of size 3 <<yeh>>]";

    assert (test_rString == test_list.toReverseString());
}

// tests toReverseString method with empty array
void toReverseString_test1() {
    CharLinkedList test_list;
    
    // create string to store what toString should produce 
    std::string test_rString = "[CharLinkedList of size 0 <<>>]";

    assert (test_rString == test_list.toReverseString());
}


// tests pushAtBack method with populated array
// should insert character into back of array
void pushAtBack_test0() {
    // create populated array
    char test_array[3] = {'h', 'e', 'y'};
    CharLinkedList test_list(test_array, 3);
    
    test_list.pushAtBack('o');

    // create string to store what toString should produce
    std::string test_rString = "[CharLinkedList of size 4 <<heyo>>]";

    assert (test_list.toString() == test_rString);
}

// tests pushAtBack method with empty list
// inserted character should be the only list
void pushAtBack_test1() {
    // create empty list
    CharLinkedList test_list;

    test_list.pushAtBack('a');

    assert (test_list.toString() == "[CharLinkedList of size 1 <<a>>]");
}

// // tests pushAtFront with populated array
// // the char should be at the front of the array
void pushAtFront_test0() {
    // create populated array
    char test_array[3] = {'h', 'e', 'y'};
    CharLinkedList test_list(test_array, 3);
    
    test_list.pushAtFront('o');

    // create string to store what toString should produce
    std::string test_rString = "[CharLinkedList of size 4 <<ohey>>]";

    assert (test_list.toString() == test_rString);
}

// // tests pushAtFront with empty array
// inserted char should be the first element
void pushAtFront_test1() {
    // create empty array
    CharLinkedList test_list;

    test_list.pushAtFront('a');

    assert (test_list.toString() == "[CharLinkedList of size 1 <<a>>]");
}

// Tests correct insertion into an empty AL.
// Afterwards, size should be 1 and element at index 0
// should be the element we inserted.
void insertAt_empty_correct() { 
    CharLinkedList test_list;
    test_list.insertAt('a', 0);

    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');
}

// Tests incorrect insertion into an empty AL.
// Attempts to call insertAt for index larger than 0.
// This should result in an std::range_error being raised.
void insertAt_empty_incorrect() {

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    // insertAt for out-of-range index
    test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
    // if insertAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    range_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0]");
    
}

// Tests correct insertAt for front of 1-element list.
void insertAt_front_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at front
    test_list.insertAt('b', 0);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'a');
    
}

// Tests correct insertAt for back of 1-element list.
void insertAt_back_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at back
    test_list.insertAt('b', 1);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    
}

// Tests calling insertAt for a large number of elements.
// Not only does this test insertAt, it also checks that
// array expansion works correctly.
void insertAt_many_elements() {
    
    CharLinkedList test_list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.insertAt('a', i);
    }

    assert(test_list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
    
}

// Tests insertion into front of a larger list
void insertAt_front_large_list() {
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    test_list.insertAt('y', 0);

    assert(test_list.size() == 10);
    assert(test_list.elementAt(0) == 'y');
    assert(test_list.toString() == 
            "[CharLinkedList of size 10 <<yabczdefgh>>]");

}

// Tests insertion into the back of a larger list
void insertAt_back_large_list() {

    char test_arr[10] = { 'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 10);  

    test_list.insertAt('x', 10);

    assert(test_list.size() == 11);
    assert(test_list.elementAt(10) == 'x');
    assert(test_list.toString() == 
    "[CharLinkedList of size 11 <<yabczdefghx>>]"); 

}

// Tests insertion into the middle of a larger list
void insertAt_middle_large_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.insertAt('z', 3);
    std::cout << test_list.toString() << std::endl;
    assert(test_list.size() == 9);
    assert(test_list.elementAt(3) == 'z');
    assert(test_list.toString() ==     
           "[CharLinkedList of size 9 <<abczdefgh>>]");

}

// Tests out-of-range insertion for a non-empty list.
void insertAt_nonempty_incorrect() {
   
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8]");
    
}

// tests insertInOrder method where char should be inserted in the middle
// of the array
// should be in alphabetical order
void insertInOrder_test0() {
    // create array where char should be inserted in middle
    char test_arr[8] = { 'a', 'b', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 7);
    
    test_list.insertInOrder('c');

    assert(test_list.toString() 
           == "[CharLinkedList of size 8 <<abcdefgh>>]");
}

// tests insertInOrder method where char should be inserted in the front
// of the array
// should be in alphabetical order
void insertInOrder_test1() {
    // create array where char should be inserted in front
    char test_arr[8] = { 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 7);
    
    test_list.insertInOrder('a');

    assert(test_list.toString() 
           == "[CharLinkedList of size 8 <<abcdefgh>>]");
}

// tests insertInOrder method where char should be inserted in the end
// of the array
// should be in alphabetical order
void insertInOrder_test2() {
    // create array where char should be inserted in the end
    char test_arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g'};
    CharLinkedList test_list(test_arr, 7);
    
    test_list.insertInOrder('h');

    assert(test_list.toString() == "[CharLinkedList of size 8 <<abcdefgh>>]"); 
}


// tests incorrect call of popFromFront with empty list
// should throw runtime error 
void popFromFront_test0() {
    bool runtime_error_thrown = false;
    std::string error_message = "";

    // create empty array
    CharLinkedList test_list;

    try {
        test_list.popFromFront();
    }

    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

// tests popFromFront method with populated list
// should decrement size and be missing the first character
void popFromFront_test1() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.popFromFront();

    assert(test_list.toString() == "[CharLinkedList of size 7 <<bcdefgh>>]");
}

// tests incorrect call of popFromBack method with empty array
// should throw runtime error
void popFromBack_test0() {
    bool runtime_error_thrown = false;
    std::string error_message = "";

    // create empty array
    CharLinkedList test_list;

    try {
        test_list.popFromBack();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

// tests popFromBack method with populated array
// should decrement size and be missing the last character
void popFromBack_test1() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.popFromBack();

    assert(test_list.toString() == "[CharLinkedList of size 7 <<abcdefg>>]");
}

// tests removeAt function with populated list
// should decrement size and remove char at provided list
void removeAt_test0() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.removeAt(5);

    assert(test_list.toString() == "[CharLinkedList of size 7 <<abcdegh>>]");
}

// tests incorrect call of removeAt with empty list
// should throw range error
void removeAt_test1() {
    bool range_error_thrown = false;
    std::string error_message = "";

    // create empty array
    CharLinkedList test_list;

    try {
        test_list.removeAt(5);
    }

    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (5) not in range [0..0)");
}

// tests removeAt method with list with one character and out of range index
// should throw range error
void removeAt_test2() {
    bool range_error_thrown = false;
    std::string error_message = "";

    // create array with one element
    CharLinkedList test_list('a');

    // call removeAt with index out of bounds
    try {
        test_list.removeAt(5);
    }

    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (5) not in range [0..1)");
}

// tests replaceAt method, replacing a character in the middle of array
// should have the same size and replace correctly
void replaceAt_test0() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.replaceAt('z', 3);
    assert(test_list.toString() == "[CharLinkedList of size 8 <<abczefgh>>]");
}

// tests incorrect call of replaceAt method with empty array
// should throw range error
void replaceAt_test1() {
    bool range_error_thrown = false;
    std::string error_message = "";

    // create empty array
    CharLinkedList test_list;

    // call replaceAt with index out of bounds
    try {
        test_list.replaceAt('z', 5);
    }

    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (5) not in range [0..0)");
}

// tests concatenate method with two populated list
// should return strings concatenated with size added up
void concatenate_test0() {
    // create "other"
    char test_arr[8] = {'C', 'H', 'E', 'S', 'H', 'I', 'R', 'E'};
    CharLinkedList other_list(test_arr, 8);

    char test_array[3] = {'c', 'a', 't'};
    CharLinkedList test_list(test_array, 3);

    test_list.concatenate(&other_list);

    assert(test_list.size() == 11);
    assert(test_list.toString() == 
           "[CharLinkedList of size 11 <<catCHESHIRE>>]");
}

// tests concatenate method with same object
// should return the string repeated two times with double the size
void concatenate_test1() {
    // create object and "other" object
    char test_arr[8] = {'C', 'H', 'E', 'S', 'H', 'I', 'R', 'E'};
    CharLinkedList test_list(test_arr, 8);

    test_list.concatenate(&test_list);

    assert(test_list.toString() 
    == "[CharLinkedList of size 16 <<CHESHIRECHESHIRE>>]");
}

// tests concatenate method with empty list
// should return only the characters in other with other's size
void concatenate_test2() {
    // create empty array
    CharLinkedList test_list;

    // create "other" instance
    char test_arr[8] = {'C', 'H', 'E', 'S', 'H', 'I', 'R', 'E'};
    CharLinkedList other_list(test_arr, 8);

    test_list.concatenate(&other_list);

    assert(test_list.toString() == "[CharLinkedList of size 8 <<CHESHIRE>>]");
}

// tests concatenate method with empty other list
// should return same string and same size
void concatenate_test3() {
    // create empty "other" instance
    CharLinkedList other_list;

    char test_arr[8] = {'C', 'H', 'E', 'S', 'H', 'I', 'R', 'E'};
    CharLinkedList test_list(test_arr, 8);

    test_list.concatenate(&other_list);

    assert(test_list.toString() == "[CharLinkedList of size 8 <<CHESHIRE>>]");
}


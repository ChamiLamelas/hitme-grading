/*
 *  CharLinkedList.cpp
 *  Alexis Lee
 *  Feb 1, 2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  This file implements CharLinkedList, 
 *  a linked list data structure that contains characters.
 *
 */

#include "CharLinkedList.h"
#include <stdexcept>
#include <iostream>

// name: CharLinkedList (default constructor)
// purpose: creates empty CharLinkedList
// arguments: nothing
// returns: nothing
// effects: initialize member variables of empty CharLinkedList
CharLinkedList::CharLinkedList() {
    front = nullptr;
    back = nullptr;
    lsize = 0;
}

// name: CharLinkedList (constructor)
// purpose: creates list of size 1 with user-provided char
// arguments: char c
// returns: nothing
// effects: initialize member variables of CharLinkedList and inserts 
//          user-provided character into front
CharLinkedList::CharLinkedList(char c) {
    lsize = 1;

    Node *new_node = new Node;
    new_node->data = c;
    new_node->prev = nullptr;
    new_node->next = nullptr;

    front = new_node;
    back = new_node;
}

// name: CharLinkedList (constructor)
// purpose: creates CharLinkedList and populates it with elements of 
//          user-provided array
// arguments: list of characters and size of that list
// returns: nothing
// effects: initialize member variables of CharLinkedList with user-provided
//          size and and copies elements of user-provided array into the 
//          CharLinkedList
CharLinkedList::CharLinkedList(char arr[], int size) {
    lsize = 0;
    front = nullptr;
    back = nullptr;
    for (int i = 0; i < size; i++) {
        pushAtBack(arr[i]);
    }
}

// name: CharLinkedList (constructor)
// purpose: copies CharLinkedList provided by user into new CharLinkedList
// argument: other CharLinkedList
// returns: nothing
// effects: creates new CharLinkedList and copies all member variables and 
//          elements of user-provided other CharLinkedList
CharLinkedList::CharLinkedList(const CharLinkedList &other) {
    front = nullptr;
    back = nullptr;

    int fixed_size = other.size();
    lsize = 0;
    
    for (int i = 0; i < fixed_size; i++){
        this->pushAtBack(other.elementAt(i)); 
    }

}

// name: ~CharArrayList (destructor)
// purpose: deletes/recycles all heap-allocated data
// argument: nothing
// returns: nothing
// effects: deletes/recycles, and frees up all heap-allocated data 
CharLinkedList::~CharLinkedList() {
    recycleRecursive(front);
}

// name: CharLinkedList &operator=
// purpose: overload "=" operator to copy data of one CharLinkedList to another
// argument: other CharLinkedList
// returns: CharLinkedList object
// effects: deletes memory of left hand side CharLinkedList object and creates
//          a new object that is a copy of the right hand side CharLinkedList 
//          object
CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other) {
    // if right hand size and left hand size are already equal, just return
    // object
    if (this == &other){
        return *this;
    }
    
    recycleRecursive(this->front);

    front = nullptr;
    back = nullptr;

    // create fixed size variable for for loop as size changes during pushBack
    int fixed_size = other.size();
    lsize = 0;
    
    for (int i = 0; i < fixed_size; i++){
        this->pushAtBack(other.elementAt(i)); 
    }

    return *this;
}


// name: isEmpty
// purpose: returns a bool value that is true when the CharLinkedList is empty
//          and false if not
// argument: nothing
// returns: boolean value
// effects: nothing
bool CharLinkedList::isEmpty() const {
    if (lsize == 0){
        return true;
    } else {
        return false;
    }
}

// name: clear
// purpose: makes the CharLinkedList "empty" to the user
// argument: nothing
// returns: nothing
// effects: resets the object's size to 0 so it appears empty to the user
void CharLinkedList::clear() {
    lsize = 0;
}

// name: size
// purpose: returns the size of the object
// argument: nothing
// returns: int size of the object
// effects: nothing
int CharLinkedList::size() const {
    return lsize;
}

// name: first
// purpose: returns first element of object's list
// argument: nothing
// returns: character of first element of the object
// effects: throws runtime error if object called has no 
//          first element/is empty
char CharLinkedList::first() const {
    if (lsize == 0){
        throw std::runtime_error("cannot get first of empty LinkedList");
    } else {
        return front->data;
    }  
}

// name: last
// purpose: returns last element of object's list
// argument: nothing
// returns: character of last element of the object
// effects: throws runtime error if object called has no 
//          last element/is empty
char CharLinkedList::last() const {
    if (lsize == 0){
        throw std::runtime_error("cannot get last of empty LinkedList");
    } else {
        return back->data;
    }
}

char CharLinkedList::elementAt(int index) const {
    if (index >= lsize or index < 0){
        throw std::range_error("index (" +  std::to_string(index) + 
        ") not in range [0.." + std::to_string(lsize) + ")");
    }

    // initialize variables to pass into getNode
    Node *curr = front;
    int curr_index = 0;

    Node *elem = getNode(curr, index, curr_index);

    return elem->data;
}

// name: toString
// purpose: returns string of elements in CharLinkedList object and its size
// argument: nothing
// returns: string of info. about the CharLinkedList object 
// effects: nothing/returns string
std::string CharLinkedList::toString() const {
    std::string str = "[CharLinkedList of size " 
                      + std::to_string(lsize) + " <<";
    
    Node *curr = this->front;

    // traverse through list and add char to string
    while (curr != nullptr) {
        str += curr->data;
        curr = curr->next;
    }

    str += ">>]";

    return str;
}

// name: toReverseString
// purpose: returns string of elements in CharLinkedList object but in reverse
// arguments: nothing
// returns: string of elements in reverse and its size
// effects: nothing/returns string
std::string CharLinkedList::toReverseString() const {
    std::string rStr = "[CharLinkedList of size " 
                       + std::to_string(lsize) + " <<";
    
    Node *curr = this->back;

    // traverse through list and add char to string
    while (curr != nullptr) {
        rStr += curr->data;
        curr = curr->prev;
    }

    rStr += ">>]";

    return rStr;
}
// name: pushAtBack
// purpose: pushes user-provided character onto the back of the CharArrayList
//          object
// arguments: character c
// returns: nothing
// effects: adds new character c to the back of the object, expands size
void CharLinkedList::pushAtBack(char c) {
    Node *curr_node = new Node;
    curr_node->data = c;

    // update pointers
    curr_node->prev = back;
    curr_node->next = nullptr;

    if (front == nullptr) {
        front = curr_node;
    }

    if (back != nullptr) {
        back->next = curr_node;
    }

    back = curr_node;
    lsize ++;
}

// name: pushAtFront
// purpose: pushes user-provided character onto the front of the CharArrayList
//          object
// arguments: character c
// returns: nothing
// effects: adds new character c to the front of the object, expands size
void CharLinkedList::pushAtFront(char c) {
    Node *curr_node = new Node;
    curr_node->data = c;

    // update pointers
    curr_node->prev = nullptr;
    curr_node->next = front;

    if (front != nullptr) {
        front->prev = curr_node;
    }

    if (back == nullptr) {
        back = curr_node;
    }

    front = curr_node;

    lsize ++;
}

// name: insertAt
// purpose: inserts user-provided character into user-provided index
// arguments: character c and integer index
// returns: nothing
// effects: throws range error if user-provided index is out of bound, 
//          and inserts c into list at index
void CharLinkedList::insertAt(char c, int index) {
    if (index > lsize or index < 0){
        throw std::range_error("index (" +  std::to_string(index) + 
        ") not in range [0.." + std::to_string(lsize) + "]");
    }

    if (index == 0) {
        pushAtFront(c);
    } else if (index == lsize) {
        pushAtBack(c);
    } else {
        // initialize variables to pass into getNode
        Node *curr = front;
        int curr_index = 0;
        
        // get node at index
        Node *curr_node = getNode(curr, index, curr_index);

        // create new node with char c
        Node *new_node = newNode(c);

        new_node->prev = curr_node->prev;
        new_node->next = curr_node;
        curr_node->prev->next = new_node;
        curr_node->prev = new_node;
        
        lsize ++;

    }  
}

// name: insertInOrder
// purpose: insert user-provided character into object's list in alphabetical
//          order
// arguments: user-provided character c
// returns: nothing
// effects: inserts character in array in alphabetical order
void CharLinkedList::insertInOrder(char c) {
    int index = 0;
    while (index < lsize and elementAt(index) < c){
        index++;
    }
    
    insertAt(c, index);

}
// name: popFromFront
// purpose: removes first element of object's list
// arguments: nothing
// returns: nothing
// effects: throw error if object is empty or "removes" first element
//          of list 
void CharLinkedList::popFromFront() {
    if (isEmpty()){
        throw std::runtime_error("cannot pop from empty LinkedList");
    }
    Node *curr_node = front;
    front = front->next;
    delete curr_node;

    lsize--;
}

// name: popFromBack
// purpose: removes last element of object's list
// arguments: nothing
// returns: nothing
// effects: throw error is object is empty or "remove" last element 
void CharLinkedList::popFromBack() {
    if (isEmpty()){
        throw std::runtime_error("cannot pop from empty LinkedList");
    }

    Node *curr_node = back;
    back = back->prev;
    delete curr_node;
    back->next = nullptr;

    lsize--;
}

// name: removeAt
// purpose: remove element at user-provided index
// arguments: user provided index
// returns: nothing
// effects: throw error if index is out of bounds, or "remove" element at index
//          by moving each element up 1 starting from the element after 
//          the index
void CharLinkedList::removeAt(int index) {
    if (index >= lsize or index < 0){
        throw std::range_error("index (" +  std::to_string(index) + 
        ") not in range [0.." + std::to_string(lsize) + ")");
    }

    Node *curr = front;
    int curr_index = 0;

    // find node at index
    Node *elem = getNode(curr, index, curr_index);
 
    // update pointers
    Node *prev_node = elem->prev;
    Node *next_node = elem->next;

    delete elem;

    prev_node->next = next_node;
    next_node->prev = prev_node;

    lsize --;
}

// name: replaceAt
// purpose: replace user-provided character at user-provided index
// arguments: character c and int index
// returns: nothing
// effects: throws error if index is out of bounds, replace element at index
//          with user-provided character
void CharLinkedList::replaceAt(char c, int index) {
    if (index >= lsize or index < 0){
            throw std::range_error("index (" +  std::to_string(index) + 
            ") not in range [0.." + std::to_string(lsize) + ")");
    }

    Node *curr = front;
    int curr_index = 0;
    Node *elem = getNode (curr, index, curr_index);

    // replace data
    elem->data = c;
}

// name: concatenate
// purpose: concatenate user-provided object of CharLinkedList with 
//          object of CharLinkedList that was called
// arguments: CharLinkedList object other
// returns: nothing
// effects: adds elements up other's array to the back of "this" object
void CharLinkedList::concatenate(CharLinkedList *other){
    Node *curr_node = other->front;
    int otherSize = other->size();

    for (int i = 0; i < otherSize; i++) {
        pushAtBack(curr_node->data);
        curr_node = curr_node->next;
    }
}


// name: recycleRecursive
// purpose: deletes/recycles memory 
// arguments: node
// returns: nothing
// effects: deletes all memory allocated for list using recursion
void CharLinkedList::recycleRecursive(Node *curr) {
    if(curr == nullptr) {
        return;
    } else {
        Node *next = curr->next;
        delete curr;
        recycleRecursive(next);
    }
}

// name: getNode
// purpose: gets the node at a certain index
// arguments: current node (front), index at which is being reached, 
//            current index (of node)
// returns: node at index
// effects: nothing
CharLinkedList::Node *CharLinkedList::getNode(Node *curr, int index, 
                                              int curr_index) const {

    if (curr_index == index) {
        return curr;
    } else if (curr_index < index){
        // update current index and node curr until curr_index is equal to 
        // index, recurse back
        curr_index ++;
        curr = curr->next;
        return getNode(curr, index, curr_index);
    }
    return nullptr;
}

// name: newNode
// purpose: creates new node
// arguments: character of the node's data
// returns: new node
// effects: creates new node and initializes its variables
CharLinkedList::Node *CharLinkedList::newNode(char c) {
    Node *new_node = new Node;
    new_node->data = c;
    new_node->next = nullptr;
    new_node->prev = nullptr;

    return new_node;
}
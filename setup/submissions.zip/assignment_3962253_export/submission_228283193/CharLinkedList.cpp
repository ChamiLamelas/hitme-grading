/*
 *  CharLinkedList.cpp
 *  Jerry Huang
 *  2/2/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Create a linked list data structure that contains characters
 *
 */

#include "CharLinkedList.h"
#include <sstream>
#include <stdexcept>
#include <iostream>

/*
 * name:      CharLinkedList default constructor
 * purpose:   initialize an empty Linked list with initial capacity of 0
 * arguments: none
 * returns:   none
 * effects:   numItems to 0 and updates back and front
 */
CharLinkedList::CharLinkedList(){
    front = nullptr;
    back = nullptr;
    numItems = 0;
}

/*
 * name:      CharLinkedList constructor
 * purpose:   Take in a single character and create a one element linked list
              consisting of that character.
 * arguments: char
 * returns:   none
 * effects:   numItems to 1 and updates back and front
 */
CharLinkedList::CharLinkedList(char c){
    numItems = 0; 
    Node *new_node = createNode(c, nullptr, nullptr);
    front = new_node;
    back = new_node;
}

/*
 * name:      CharLinkedList constructor
 * purpose:   initialize an Linked list with characters from a passed List
 * arguments: array of characters, int representing the size of the passed array
 * returns:   none
 * effects:   updates numItems and updates back and front
 */
CharLinkedList::CharLinkedList(char arr[], int size){
    // initialize 
    front = nullptr;
    back = nullptr;
    numItems = 0; 

    if (size <= 0){
        return;
    } else { // back to front
        for (int i = size-1; i >= 0; i--) {
            if(front == nullptr){
                Node *new_node = createNode(arr[i], nullptr, nullptr);
                front = new_node;
                back = new_node;
            } else {
                Node *new_node = createNode(arr[i], front, nullptr);
                front->prev = new_node;
                front = new_node;
            }
        }
    } 
}

/*
 * name:      CharLinkedList constructor
 * purpose:   create a deep copy of given instance
 * arguments: CharLinkedList instance 
 * returns:   none
 * effects:   updates numItems and updates back and front
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other){
    front = nullptr;
    back = nullptr;
    numItems = 0;
    
    Node* other_curr = other.front;
    Node* last_new_node = nullptr; 

    // Loop continousouly until the end of the "other" list, making a deep copy
    // and updating
    while (other_curr != nullptr) {
        Node *new_curr = new Node();
        new_curr->data = other_curr->data;
        new_curr->next = nullptr; 
        new_curr->prev = last_new_node; 

        if (front == nullptr) {
            front = new_curr;
        }

        if (last_new_node != nullptr) {
            last_new_node->next = new_curr;
        }

        last_new_node = new_curr;
        other_curr = other_curr->next;
        numItems++;
    }
    back = last_new_node;
}

/*
 * name:      createNode
 * purpose:   creates a node 
 * arguments: character representing the node data, and two node pointers
              representing the next node and the previous node
 * returns:   Node called new_node
 * effects:   Increases numItems by one 
 */
CharLinkedList::Node *CharLinkedList::createNode(char c, Node *next, Node *prev)
{
    Node *new_node = new Node;
    new_node->data = c;
    new_node->next = next;
    new_node->prev = prev;
    numItems++;

    return new_node;
}

/*
 * name:      CharLinkedList destructor
 * purpose:   clear heap space from list
 * arguments: none
 * returns:   none
 * effects:   deletes list from memory and resets front, back and numItems
 */
CharLinkedList::~CharLinkedList(){
    destructorHelper(front);
    front = nullptr;
    back = nullptr;
    numItems = 0;
}

/*
 * name:      destructorHelper
 * purpose:   recursively clear heap space from list
 * arguments: a Node which the destructor passes as the front node 
 * returns:   none
 * effects:   deletes list from memory
 */
void CharLinkedList::destructorHelper(Node *curr){
    if (curr != nullptr) {
        Node *next_node = curr->next;
        delete curr;
        destructorHelper(next_node);
    } else {
        return;
    }
}

/*
 * name:      operator=
 * purpose:   Make a deep copy of the instance on the right hand side into the
 *            instance on the left
 * arguments: Reference to other CharLinkedList object
 * returns:   A reference to the CharLinkedList object this function calls on
 * effects:   numItems, front and back are all updated
 */
CharLinkedList& CharLinkedList::operator=(const CharLinkedList &other){
    if (this == &other) { // the instances are identical 
        return *this;
    }
    clear(); 

    Node* other_curr = other.front;
    Node* last_new_node = nullptr; // track the last created node 

    while (other_curr != nullptr) {
        Node* this_curr = new Node();
        this_curr->data = other_curr->data;
        this_curr->next = nullptr; 
        this_curr->prev = last_new_node; 

        if (front == nullptr) {
            front = this_curr;
        }

        if (last_new_node != nullptr) {
            last_new_node->next = this_curr;
        }

        last_new_node = this_curr;
        other_curr = other_curr->next;
        numItems++;
    }
    back = last_new_node;
    return *this;
}

/*
 * name:      size
 * purpose:   return an integer value that is the number of characters in the 
              linked list
 * arguments: none
 * returns:   integer representing the number of elements in the linked list
 * effects:   none
 */
int CharLinkedList::size() const{
    return numItems; 
}

/*
 * name:      isEmpty
 * purpose:   return whether a linked list has characters (true) or not (false)
 * arguments: none
 * returns:   true or false
 * effects:   none
 */
bool CharLinkedList::isEmpty() const{
    if (numItems == 0){
        return true;
    } 
    return false;
}

/*
 * name:      first
 * purpose:   returns the first character in the linked list
 * arguments: none
 * returns:   the first character in the linked list or runtime error exception
              if the linked list is empty
 * effects:   none
 */
char CharLinkedList::first() const{
    if (isEmpty()) {
        throw std::runtime_error("cannot get first of empty LinkedList");
    } 
    return front->data;
}

/*
 * name:      last
 * purpose:   returns the last character in the linked list
 * arguments: none
 * returns:   the last character in the linked list or runtime error exception
              if the linked list is empty
 * effects:   none
 */
char CharLinkedList::last() const{
    if (isEmpty()) {
        throw std::runtime_error("cannot get last of empty LinkedList");
    }
    return back->data;
}

/*
 * name:      toString
 * purpose:   returns a specially formatted string which contains the 
              characters of the linked list
 * arguments: none
 * returns:   returns a formatted string which contains the characters of the
              linked list
 * effects:   none
 */
std::string CharLinkedList::toString() const {
    Node *curr_node = front;
    std::stringstream ss;
    ss << "[CharLinkedList of size " << numItems << " <<";
    
    // copy the elements of the list into the stringstream in order
    for (int i = 0; i < numItems; i++) {
        ss << curr_node->data;
        curr_node = curr_node->next;
    }

    ss << ">>]";
    return ss.str();
}

/*
 * name:      toString
 * purpose:   returns a specially formatted string which contains the 
              characters of the linked list in reverse
 * arguments: none
 * returns:   returns a formatted string which contains the characters of the
              linked list in reverse
 * effects:   none
 */
std::string CharLinkedList::toReverseString() const {
    Node *curr_node = back;
    std::stringstream ss;
    ss << "[CharLinkedList of size " << numItems << " <<";
    
    // copy the elements of the list into the stringstream in order
    for (int i = 0; i < numItems; i++) {
        ss << curr_node->data;
        curr_node = curr_node->prev;
    }

    ss << ">>]";
    return ss.str();
}

/*
 * name:      clear
 * purpose:   makes the instance into an empty list
 * arguments: none
 * returns:   none
 * effects:   resets front, back and numItems
 */
void CharLinkedList::clear(){
    destructorHelper(front);
    front = nullptr;
    back = nullptr;
    numItems = 0;
}

/*
 * name:      insertAt
 * purpose:   Inserts an element at the specified index and adjusts 
              pointers accordingly
 * arguments: a char element and int index representing where the passed element
              will be inserted
 * returns:   none
 * effects:   throws range error message if the passed index is out of the range
              [0..size] and increases the size of the linked list if the passed
              index is in range and possibly adjusts
 */
void CharLinkedList::insertAt(char c, int index) {
    if (index > numItems or index < 0) {
        throw std::range_error("index (" + std::to_string(index) + 
                               ") not in range "\
                               "[0.." + std::to_string(numItems) + "]");
    } else if (index == 0 or numItems == 0) {
        pushAtFront(c);
        
    } else if (index == numItems) {
        pushAtBack(c);
    } else { 
        Node *curr_node;
        if (index >= (numItems * 0.5)) {
            curr_node = elementAtHelperFromBack(index, back);
        } else {
            curr_node = elementAtHelperFromFront(index, front);
        }

        Node *new_node = createNode(c, nullptr, nullptr);
        curr_node->prev->next = new_node;
        new_node->prev = curr_node->prev;
        curr_node->prev = new_node;
        new_node->next = curr_node;
    } 
}

/*
 * name:      insertInOrder
 * purpose:   Inserts an element into the linked list in ASCII order
 * arguments: a char element 
 * returns:   none
 * effects:   calls on the pushAtBack function if the element isn't inserted
              in the front or middle of the linked list and insertAt otherwise
 */
void CharLinkedList::insertInOrder(char c) {
    bool inserted = false;

    Node *curr_node = front;
    int index = 0;

    // compare c to each element in the list
    while (curr_node != nullptr){ 
        if (c <= curr_node->data and not inserted) { 
            insertAt(c, index);
            inserted = true;
        }
        curr_node = curr_node->next;
        index++;
    }
    
    if (not inserted){ // in the case that c has the largest ASCII number
        pushAtBack(c);
    }
}

/*
 * name:      pushAtFront
 * purpose:   Inserts an element at the front of the existing elements of the 
              linked list
 * arguments: a char element
 * returns:   none
 * effects:   increases the size of the linked list after the element is pushed
              at front and adjusts the front (and back) pointer 
 */
void CharLinkedList::pushAtFront(char c){
    if (numItems == 0){
        Node *new_node = createNode(c, nullptr, nullptr);
        front = new_node;
        back = new_node;
    } else {
        Node *new_node = createNode(c, front, nullptr);
        front->prev = new_node;
        front = new_node;
    }
}

/*
 * name:      pushAtBack
 * purpose:   Inserts an element at the back of the existing elements of the 
              linked list
 * arguments: a char element
 * returns:   none
 * effects:   increases the size of the linked list after the element is pushed
              at back and adjusts the back (and front) pointer 
 */
void CharLinkedList::pushAtBack(char c){
    if (numItems == 0){
        Node *new_node = createNode(c, nullptr, nullptr);
        front = new_node;
        back = new_node;
    } else {
        Node *new_node = createNode(c, nullptr, back);
        back->next = new_node;
        back = new_node;
    }
}

/*
 * name:      removeAt
 * purpose:   Takes an integer index and removes the element at the specified
              index
 * arguments: int index representing which element this function should remove
 * returns:   none
 * effects:   throws range error message if the passed index is out of the range
              [0..size) and reduces the size of the linked list if the passed
              index is in range
 */
void CharLinkedList::removeAt(int index){
    if (index >= numItems or index < 0) {
        throw std::range_error("index (" + std::to_string(index) + 
                          ") not in range [0.." + std::to_string(numItems) 
                          + ")");
    } else if (index == 0) {
        popFromFront();
    } else if (index == numItems-1) {
        popFromBack();
    } else { 
        Node *curr_node;
        if (index >= (numItems * 0.5)) {
            curr_node = elementAtHelperFromBack(index, back);
        } else {
            curr_node = elementAtHelperFromFront(index, front);
        }
        curr_node->prev->next = curr_node->next;
        curr_node->next->prev = curr_node->prev;
        delete curr_node;
        numItems--;
    } 
}

/*
 * name:      popFromFront
 * purpose:   Removes the first element from the linked list
 * arguments: none
 * returns:   none
 * effects:   tthrows runtime message if the list is empty and adjusts front,
              back pointers and numItems
 */
void CharLinkedList::popFromFront(){
    if (numItems == 0) {
        throw std::runtime_error("cannot pop from empty LinkedList");
    }
    if (front->next == nullptr) { // true when size of array is 1
        delete front;
        front = nullptr;
        back = nullptr;
        numItems = 0;
    } else {
        Node *curr_node = front->next;
        delete front;
        curr_node->prev = nullptr;
        front = curr_node;
        numItems--;
    }

}

/*
 * name:      popFromBack
 * purpose:   Removes the back element from the linked list
 * arguments: none
 * returns:   none
 * effects:   throws runtime message if the list is empty and adjusts front,
              back pointers and numItems
 */
void CharLinkedList::popFromBack(){
    if (numItems == 0) {
        throw std::runtime_error("cannot pop from empty LinkedList");
    }
    if (back->prev == nullptr) { // true when size of array is 1
        delete back;
        front = nullptr;
        back = nullptr;
        numItems = 0;
    } else {
        Node *curr_node = back->prev;
        delete back;
        curr_node->next = nullptr;
        back = curr_node;
        numItems--;
    }
}

/*
 * name:      replaceAt
 * purpose:   Takes an integer index and removes the element at the specified
              index
 * arguments: int index representing which element should be replaced, char 
              representing the element doing the replacing
 * returns:   none
 * effects:   throws range error message if the passed index is out of the range
              [0..size) and replaces element if in range
 */
void CharLinkedList::replaceAt(char c, int index){
    if (index >= numItems or index < 0) {
        throw std::range_error("index (" + 
                               std::to_string(index) + ") not in range "\
                               "[0.." + std::to_string(numItems) + ")");
    } 
    
    Node *new_node;
    if (index >= (numItems * 0.5)) {
        new_node = elementAtHelperFromBack(index, back);
    } else {
        new_node = elementAtHelperFromFront(index, front);
    }
    
    new_node->data = c;
}

/*
 * name:      concatenate
 * purpose:   Adds a copy of the list list pointed to by the parameter
              value to the end of the linked list the function was called from
 * arguments: a pointer to a CharArrayList
 * returns:   none
 * effects:   potentially updates front and back pointer as well as numItems
 */
void CharLinkedList::concatenate(CharLinkedList *other) {
    if (other->front == nullptr) { // other list is empty
        return;
    } else if (front == nullptr) { // this list is empty
        *this = *other;
        return;
    } else {
        int this_size = numItems;

        // make a deep copy
        CharLinkedList other_list = CharLinkedList(*other);
        int other_size = other_list.size();

        for (int i = 0; i < other_size; i++) {
            Node *new_node = createNode(other_list.elementAt(i), nullptr, back);
            back->next = new_node;
            back = new_node;
        }
        numItems = this_size + other_size;
    }
}

/*
 * name:      elementAt
 * purpose:   Takes an integer index and returns the element (char) in linked
              list at that index.
 * arguments: int index representing which element this function should return
 * returns:   the element in the linked list at the passed index or a 
              range error message if the index isn't in the range [0..SIZE)
 * effects:   none
 */
char CharLinkedList::elementAt(int index) const{
    if (index >= numItems or index < 0) {
        throw std::range_error("index (" + std::to_string(index) + 
                          ") not in range [0.." + std::to_string(numItems) 
                          + ")");
    }

    Node *new_node;
    if (index >= (numItems * 0.5)) {
        new_node = elementAtHelperFromBack(index, back);
    } else {
        new_node = elementAtHelperFromFront(index, front);
    }
    return new_node->data;
}

/*
 * name:      elementAtHelperFromBack
 * purpose:   Takes an integer index and starting point node (back) and 
              recursively determines the char at that index 
 * arguments: int index representing which element this function should return
              and a Node pointer to the current pointer
 * returns:   node 
 * effects:   none
 */
CharLinkedList::Node *CharLinkedList::
                        elementAtHelperFromBack(int index, Node *curr) const{
    int steps = numItems - 1 - index;
    if (steps == 0) {
        return curr; 
    } else {
        return elementAtHelperFromBack(index + 1, curr->prev);
    }
}
/*
 * name:      elementAtHelperFromFront
 * purpose:   Takes an integer index and starting point node (front) and 
              recursively determines the char at that index 
 * arguments: int index representing which element this function should return
              and a Node pointer to the current pointer
 * returns:   node 
 * effects:   none
 */
CharLinkedList::Node *CharLinkedList::
                        elementAtHelperFromFront(int index, Node *curr) const{
    if (index == 0) {
        return curr; 
    } else {
        return elementAtHelperFromFront(index - 1, curr->next);
    }
}

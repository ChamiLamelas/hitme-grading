/*
 *  unit_tests.h
 *  Jerry Huang
 *  2/2/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  Create a linked list data structure that contains characters
 *
 */

 #include "CharLinkedList.h"
 #include <cassert>
 #include <iostream>



 /********************************************************************\
*                       CHAR LINKED LIST TESTS                        *
\********************************************************************/

// Test default constructor and destructor
void constructor1_correct(){
    CharLinkedList test_list;
}

// Test second constructor for correct size
void constructor2_correct(){
    CharLinkedList test_list('a');
    assert(test_list.size() == 1);
}

// Test third constructor for correct size and elements and toString
void constructor3_correct(){
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList test_list(arr, 3);
    assert(test_list.toString() == "[CharLinkedList of size 3 <<abc>>]");
}

// Test third constructor using empty list for correct size
void constructor3_emptyArray_correct(){
    char arr[0];
    CharLinkedList test_list(arr, 0);
    assert(test_list.size() == 0);
}

// Test fourth constructor 
void constructor4_correct(){ // create at some point
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList test_list(arr, 3);
    CharLinkedList copied_list(test_list);
    assert(copied_list.toString() == "[CharLinkedList of size 3 <<abc>>]");
}

// Test fourth constructor for empty list
void constructor4_emptyArray_correct(){ // create at some point
    CharLinkedList test_list;
    CharLinkedList copied_list(test_list);
    assert(copied_list.size() == 0);
}

// Test size function
void size_correct(){
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList test_list(arr, 3);
    assert(test_list.size() == 3);
}

// Test if isEmpty() works correctly for filled list 
void isEmpty_incorrect(){
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList test_list(arr, 3);
    assert(not test_list.isEmpty());
}

// Test if isEmpty() works correctly for empty list
void isEmpty_correct(){
    CharLinkedList test_list;
    assert(test_list.isEmpty());
}

// test first() function when the linked list is filled (correct)
void first_correct(){
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList test_list(arr, 3);
    assert(test_list.first() == 'a');
}

// test first() function when the linked list is empty (incorrect)
void first_incorrect() { // should be a fail
    CharLinkedList test_list;

    // var to track whether runtime_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";
    
    try {
        test_list.first();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot get first of empty LinkedList");
}

// test last() function when the linked list is filled (correct)
void last_correct(){
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList test_list(arr, 3);
    assert(test_list.last() == 'c');
}

// test last() function when the linked list is empty (incorrect)
void last_incorrect() { // should be a fail
    CharLinkedList test_list;

    // var to track whether runtime_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";
    
    try {
        test_list.last();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot get last of empty LinkedList");
}

// test toString() function for a filled list
void toString_filledList_correct(){
    char arr[5] = {'A', 'l', 'i', 'c', 'e'};
    CharLinkedList test_list(arr, 5);
    assert(test_list.toString() == "[CharLinkedList of size 5 <<Alice>>]");
}

// test toString() function for an empty list
void toString_emptyList_correct(){
    CharLinkedList test_list;
    assert(test_list.toString() == "[CharLinkedList of size 0 <<>>]");
}

// test toReverseString() function for a filled list
void toReverseString_filledList_correct(){
    char arr[5] = {'A', 'l', 'i', 'c', 'e'};
    CharLinkedList test_list(arr, 5);
    assert(test_list.toReverseString() == "[CharLinkedList of size 5 " \
                                           "<<ecilA>>]");
}

// test toReverseString() function for an empty list
void toReverseString2_emptyList_correct(){
    CharLinkedList test_list;
    assert(test_list.toReverseString() == "[CharLinkedList of size 0 <<>>]");
}

// test clear() function and toString() function 
void clear_correct(){
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList test_list(arr, 3);
    test_list.clear();
    assert(test_list.isEmpty());
}

// test clear() function and toString() function 
void clear_emptyList_correct(){
    CharLinkedList test_list;
    test_list.clear();
    assert(test_list.isEmpty());
}

// test pushAtBack() with a filled Linked list
void pushAtBack_filledList_correct(){
    char arr1[3] = {'A', 'b', 'c'};
    CharLinkedList test_list(arr1, 3);
    test_list.pushAtBack('d');
    assert(test_list.toString() == "[CharLinkedList of size 4 <<Abcd>>]");
}

// test pushAtBack() with an empty Linked list
void pushAtBack_emptyList_correct(){
    CharLinkedList test_list;
    test_list.pushAtBack('d');
    assert(test_list.toString() == "[CharLinkedList of size 1 <<d>>]");
}

// test pushAtBack() with a one element Linked list
void pushAtBack_oneElementList_correct(){
    CharLinkedList test_list;
    test_list.pushAtBack('d');
    test_list.pushAtBack('a');
    assert(test_list.toString() == "[CharLinkedList of size 2 <<da>>]");
}

// test pushAtFront() with a filled Linked list
void pushAtFront_filledList_correct(){
    char arr1[3] = {'A', 'b', 'c'};
    CharLinkedList test_list(arr1, 3);
    test_list.pushAtFront('d');
    assert(test_list.toString() == "[CharLinkedList of size 4 <<dAbc>>]");
}

// test pushAtFront() with an empty Linked list
void pushAtFront_emptyList_correct(){
    CharLinkedList test_list;
    test_list.pushAtFront('d');
    assert(test_list.toString() == "[CharLinkedList of size 1 <<d>>]");
}

// test popFromFront function for filled Linked list
void popFromFront_correct(){
    char arr[5] = {'A', 'l', 'i', 'c', 'e'};
    CharLinkedList test_list(arr, 5);
    test_list.popFromFront();
    assert(test_list.toString() == "[CharLinkedList of size 4 <<lice>>]");
}

// test popFromFront function for two element Linked list
void popFromFront_twoElementList_correct(){
    char arr[2] = {'A', 'l'};
    CharLinkedList test_list(arr, 2);
    test_list.popFromFront();
    assert(test_list.toString() == "[CharLinkedList of size 1 <<l>>]");
}

// test popFromFront function for empty Linked list (incorrect)
void popFromFront_incorrect(){
    CharLinkedList test_list;

    // var to track whether runtime_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";
    
    try {
        test_list.popFromFront();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

// test popFromBack function for filled Linked list
void popFromBack_correct(){
    char arr[5] = {'A', 'l', 'i', 'c', 'e'};
    CharLinkedList test_list(arr, 5);
    test_list.popFromBack();
    assert(test_list.toString() == "[CharLinkedList of size 4 <<Alic>>]");
}

// test popFromBack function for two element Linked list
void popFromBack_twoElementList_correct(){
    char arr[2] = {'A', 'l'};
    CharLinkedList test_list(arr, 2);
    test_list.popFromBack();
    assert(test_list.toString() == "[CharLinkedList of size 1 <<A>>]");
}

// test popFromBack function for empty Linked list (incorrect)
void popFromBack_incorrect(){
    CharLinkedList test_list;

    // var to track whether runtime_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";
    
    try {
        test_list.popFromBack();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}


// test removeAt for index out of range (too big) - incorrect
void removeAt_indexTooLarge_incorrect(){  // should be a fail
    char arr[5] = {'A', 'l', 'i', 'c', 'e'};
    CharLinkedList test_list(arr, 5);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";
    
    try {
        test_list.removeAt(5);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (5) not in range [0..5)");
}

// test removeAt for index out of range (too small) - incorrect
void removeAt_indexTooSmall_incorrect(){  // should be a fail
    char arr[3] = {'A', 'l', 'i'};
    CharLinkedList test_list(arr, 3);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";
    
    try {
        test_list.removeAt(-1);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (-1) not in range [0..3)");
}

// test removeAt for index 0 in a size 5 linked list 
void removeAt_indexZeroSize5_correct(){
    char arr[5] = {'A', 'l', 'i', 'c', 'e'};
    CharLinkedList test_list(arr, 5);
    test_list.removeAt(0);
    assert(test_list.toString() == "[CharLinkedList of size 4 <<lice>>]");
}

// test removeAt for index in the middle of a size 5 linked list 
void removeAt_indexMiddleSize5_correct(){
    char arr[5] = {'A', 'l', 'i', 'c', 'e'};
    CharLinkedList test_list(arr, 5);
    test_list.removeAt(3);
    assert(test_list.toString() == "[CharLinkedList of size 4 <<Alie>>]");
}

// test removeAt for index at the end of a size 5 linked list 
void removeAt_indexLastSize5_correct(){
    char arr[5] = {'A', 'l', 'i', 'c', 'e'};
    CharLinkedList test_list(arr, 5);
    test_list.removeAt(4);
    assert(test_list.toString() == "[CharLinkedList of size 4 <<Alic>>]");
}

// test removeAt for index 0 in a size 3 linked list 
void removeAt_indexZeroSize3_correct(){
    char arr[3] = {'A', 'l', 'i'};
    CharLinkedList test_list(arr, 3);
    test_list.removeAt(0);
    assert(test_list.toString() == "[CharLinkedList of size 2 <<li>>]");
}

// test removeAt for index in the middle of a size 3 linked list 
void removeAt_indexMiddleSize3_correct(){
    char arr[3] = {'A', 'l', 'i'};
    CharLinkedList test_list(arr, 3);
    test_list.removeAt(1);
    assert(test_list.toString() == "[CharLinkedList of size 2 <<Ai>>]");
}

// test removeAt for index at the end of a size 3 linked list 
void removeAt_indexLastSize3_correct(){
    char arr[3] = {'A', 'l', 'i'};
    CharLinkedList test_list(arr, 3);
    test_list.removeAt(2);
    assert(test_list.toString() == "[CharLinkedList of size 2 <<Al>>]");
}

// test removeAt for index 0 in an empty linked list
void removeAt_emptyLinkedList_incorrect(){
    CharLinkedList test_list;

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";
    
    try {
        test_list.removeAt(0);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (0) not in range [0..0)");
}

// test replaceAt for index out of range (too big) - incorrect
void replaceAt_indexTooLarge_incorrect(){  // should be a fail
    char arr[5] = {'A', 'l', 'i', 'c', 'e'};
    CharLinkedList test_list(arr, 5);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";
    
    try {
        test_list.replaceAt('Z', 5);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (5) not in range [0..5)");
}

// test replaceAt for index out of range (too small) - incorrect
void replaceAt_indexTooSmall_incorrect(){  // should be a fail
    char arr[3] = {'A', 'l', 'i'};
    CharLinkedList test_list(arr, 3);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";
    
    try {
        test_list.replaceAt('Z', -1);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (-1) not in range [0..3)");
}

// test replaceAt for index 0 in an empty Linked list
void replaceAt_emptyLinkedList_incorrect(){
    CharLinkedList test_list;

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";
    
    try {
        test_list.replaceAt('Z', 0);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (0) not in range [0..0)");
}

// test replaceAt for index in the middle of linked list 
void replaceAt_indexMiddle_correct(){
    char arr[5] = {'A', 'l', 'i', 'c', 'e'};
    CharLinkedList test_list(arr, 5);
    test_list.replaceAt('Z', 3);
    assert(test_list.toString() == "[CharLinkedList of size 5 <<AliZe>>]");
}

// test replaceAt for index 0 in a filled Linked list 
void replaceAt_indexZero_correct(){
    char arr[5] = {'A', 'l', 'i', 'c', 'e'};
    CharLinkedList test_list(arr, 5);
    test_list.replaceAt('Z', 0);
    assert(test_list.toString() == "[CharLinkedList of size 5 <<Zlice>>]");
}

// test replaceAt for last index in a filled Linked list 
void replaceAt_lastIndex_correct(){
    char arr[5] = {'A', 'l', 'i', 'c', 'e'};
    CharLinkedList test_list(arr, 5);
    test_list.replaceAt('Z', 4);
    assert(test_list.toString() == "[CharLinkedList of size 5 <<AlicZ>>]");
}

// test concatenate() between two different sized linked lists
void concatenate_difSizedLists_correct(){
    char arr1[3] = {'A', 'b', 'c'};
    CharLinkedList test_list1(arr1, 3);
    char arr2[2] = {'d', 'e'};
    CharLinkedList test_list2(arr2, 2);
    test_list1.concatenate(&test_list2);
    assert(test_list1.toString() == "[CharLinkedList of size 5 <<Abcde>>]");
}

// test concatenate() between a filled and empty Linked list
void concatenate_filledAndEmptyList_correct(){
    char arr1[3] = {'A', 'b', 'c'};
    CharLinkedList test_list1(arr1, 3);
    CharLinkedList test_list2;
    test_list1.concatenate(&test_list2);
    assert(test_list1.toString() == "[CharLinkedList of size 3 <<Abc>>]");
}

// test concatenate() between an empty and filled Linked list
void concatenate_emptyAndFilledList_correct(){
    char arr1[3] = {'A', 'b', 'c'};
    CharLinkedList test_list1(arr1, 3);
    CharLinkedList test_list2;
    test_list2.concatenate(&test_list1);
    std::cout<<"this right: " << test_list1.toString()<< std::endl;
    assert(test_list1.toString() == "[CharLinkedList of size 3 <<Abc>>]");
}

// test concatenate() with an Linked list with itself 
void concatenate_itself_correct(){
    char arr1[3] = {'A', 'b', 'c'};
    CharLinkedList test_list1(arr1, 3);
    test_list1.concatenate(&test_list1);
    assert(test_list1.toString() == "[CharLinkedList of size 6 <<AbcAbc>>]");
}

// test concatenate() with two empty Linked lists
void concatenate_twoEmptyLists_correct(){
    CharLinkedList test_list1;
    CharLinkedList test_list2;
    test_list1.concatenate(&test_list2);
    assert(test_list1.toString() == "[CharLinkedList of size 0 <<>>]");
}

// test elementAt for index out of range (too big) - incorrect
void elementAt_indexTooLarge_incorrect(){  // should be a fail
    char arr[5] = {'A', 'l', 'i', 'c', 'e'};
    CharLinkedList test_list(arr, 5);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";
    
    try {
        test_list.elementAt(5);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (5) not in range [0..5)");
}

// test elementAt for index 0 in an empty Linked list
void elementAt_emptyLinkedList_incorrect(){
    CharLinkedList test_list;

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";
    
    try {
        test_list.elementAt(0);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (0) not in range [0..0)");
}

// test elementAt for index out of range (too small) - incorrect
void elementAt_indexTooSmall_incorrect(){  // should be a fail
    char arr[3] = {'A', 'l', 'i'};
    CharLinkedList test_list(arr, 3);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";
    
    try {
        test_list.elementAt(-1);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (-1) not in range [0..3)");
}

// test elementAt for index in the back half of Linked list 
void elementAt_indexBackHalf_correct(){
    char arr[5] = {'A', 'l', 'i', 'c', 'e'};
    CharLinkedList test_list(arr, 5);
    assert(test_list.elementAt(3) == 'c');   
}

// test elementAt for index in the front half of Linked list 
void elementAt_indexFirstHalf_correct(){
    char arr[5] = {'A', 'l', 'i', 'c', 'e'};
    CharLinkedList test_list(arr, 5);
    assert(test_list.elementAt(1) == 'l');   
}

// test elementAt for index 0 in a filled Linked list 
void elementAt_indexZero_correct(){
    char arr[5] = {'A', 'l', 'i', 'c', 'e'};
    CharLinkedList test_list(arr, 5);
    assert(test_list.elementAt(0) == 'A');
}

// test elementAt last index in a filled Linked list 
void elementAt_lastIndex_correct(){
    char arr[5] = {'A', 'l', 'i', 'c', 'e'};
    CharLinkedList test_list(arr, 5);
    assert(test_list.elementAt(4) == 'e');
}


// Test the operator= function in the scenario that test_list2 has a greater 
// size than test_list1
void operator_otherIsLarger_correct(){ // create at some point
    char arr1[3] = {'a', 'b', 'c'};
    char arr2[5] = {'d', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list1(arr1, 3);
    CharLinkedList test_list2(arr2, 5);
    test_list1 = test_list2;
    std::cout<< "1: " << test_list1.toString() << std::endl;
    assert(test_list1.toString() == "[CharLinkedList of size 5 <<defgh>>]");
}

// Test the operator= function in the scenario that test_list2 has a greater 
// size than test_list1
void operator_otherIsSmaller_correct(){ // create at some point
    char arr1[5] = {'d', 'e', 'f', 'g', 'h'};
    char arr2[3] = {'a', 'b', 'c'};
    CharLinkedList test_list1(arr1, 5);
    CharLinkedList test_list2(arr2, 3);
    test_list1 = test_list2;
    std::cout<< "2: " << test_list1.toString() << std::endl;
    assert(test_list1.toString() == "[CharLinkedList of size 3 <<abc>>]");

}

// Test the operator= function in the scenario that test_list2 has an equal 
// size than test_list1
void operator_otherIsSameSize_correct(){ // create at some point
    char arr1[3] = {'d', 'e', 'f'};
    char arr2[3] = {'a', 'b', 'c'};
    CharLinkedList test_list1(arr1, 3);
    CharLinkedList test_list2(arr2, 3);
    test_list1 = test_list2;
    std::cout<< "3: " << test_list1.toString() << std::endl;
    assert(test_list1.toString() == "[CharLinkedList of size 3 <<abc>>]");
}

// Test the operator= function in the scenario that test_list2 has an equal 
// size than test_list1
void operator_otherIsIdentical_correct(){ // create at some point
    char arr1[3] = {'d', 'e', 'f'};
    char arr2[3] = {'d', 'e', 'f'};
    CharLinkedList test_list1(arr1, 3);
    CharLinkedList test_list2(arr2, 3);
    test_list1 = test_list2;
    std::cout<< "4: " << test_list1.toString() << std::endl;
    assert(test_list1.toString() == "[CharLinkedList of size 3 <<def>>]");
}

// Tests correct insertion into an empty LL.
// Afterwards, size should be 1 and element at index 0
// should be the element we inserted.
void insertAt_empty_correct() { 

    CharLinkedList test_list;
    test_list.insertAt('a', 0);
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');

}

// Tests incorrect insertion into an empty LL.
// Attempts to call insertAt for index larger than 0.
// This should result in an std::range_error being raised.
void insertAt_empty_incorrect() {

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    // insertAt for out-of-range index
    test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
    // if insertAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    range_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0]");
    
}

// Tests correct insertAt for front of 1-element list.
void insertAt_front_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at front
    test_list.insertAt('b', 0);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'a');
    
}

// Tests correct insertAt for back of 1-element list.
void insertAt_back_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at back
    test_list.insertAt('b', 1);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    
}

// Tests calling insertAt for a large number of elements.
void insertAt_many_elements() {
    
    CharLinkedList test_list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.insertAt('a', i);
    }

    assert(test_list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
    
}

// Tests insertion into front of a larger list
void insertAt_front_large_list() {
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    test_list.insertAt('y', 0);

    assert(test_list.size() == 10);
    assert(test_list.elementAt(0) == 'y');
    assert(test_list.toString() == "[CharLinkedList of size 10 
                                   <<yabczdefgh>>]");

}

// Tests insertion into the back of a larger list
void insertAt_back_large_list() {

    char test_arr[10] = { 'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 10);  

    test_list.insertAt('x', 10);

    assert(test_list.size() == 11);
    assert(test_list.elementAt(10) == 'x');
    assert(test_list.toString() == 
    "[CharLinkedList of size 11 <<yabczdefghx>>]"); 

}

// Tests insertion into the middle of a larger list
void insertAt_middle_large_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.insertAt('z', 3);

    assert(test_list.size() == 9);
    assert(test_list.elementAt(3) == 'z');
    assert(test_list.toString() == "[CharLinkedList of size 9 <<abczdefgh>>]");

}

// Tests out-of-range insertion for a non-empty list.
void insertAt_nonempty_incorrect() {
   
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8]");
    
}


// test insertInOrder for an element in the middle of the Linked list order
void insertInOrder_middleElement_correct(){
    char arr1[5] = {'A', 'B', 'D', 'E', 'F'};
    CharLinkedList test_list(arr1, 5);
    test_list.insertInOrder('C');
    
    assert(test_list.toString() == "[CharLinkedList of size 6 <<ABCDEF>>]");
}

// test insertInOrder for an element in the middle of a size 3 list in order
void insertInOrder_middleSize3List_correct(){
    char arr1[5] = {'A', 'B', 'D'};
    CharLinkedList test_list(arr1, 3);
    test_list.insertInOrder('C');
    
    assert(test_list.toString() == "[CharLinkedList of size 4 <<ABCD>>]");
}

// test insertInOrder for an element in the middle of a size 2 list in order
void insertInOrder_middleSize2List_correct(){
    char arr1[5] = {'A', 'B'};
    CharLinkedList test_list(arr1, 2);
    test_list.insertInOrder('B');

    assert(test_list.toString() == "[CharLinkedList of size 3 <<ABB>>]");
}

// test insertInOrder for a list containing unsorted Linked list ('ZED')
void insertInOrder_unsortedList_correct(){
    char arr1[3] = {'Z', 'E', 'D'};
    CharLinkedList test_list(arr1, 3);
    test_list.insertInOrder('A');

    assert(test_list.toString() == "[CharLinkedList of size 4 <<AZED>>]");
}

// test insertInOrder for when the inserted letter is already in the Linked list
void insertInOrder_repeatLetter_correct(){
    char arr1[3] = {'D', 'E', 'Z'};
    CharLinkedList test_list(arr1, 3);
    test_list.insertInOrder('E');

    assert(test_list.toString() == "[CharLinkedList of size 4 <<DEEZ>>]");
}

// test insertInOrder for when the inserted letter should be last
void insertInOrder_insertedLast_correct(){
    char arr1[3] = {'A', 'B', 'C'};
    CharLinkedList test_list(arr1, 3);
    test_list.insertInOrder('D');

    assert(test_list.toString() == "[CharLinkedList of size 4 <<ABCD>>]");
}

// test insertInOrder for when the current Linked list is empty
void insertInOrder_emptyList_correct(){
    CharLinkedList test_list;
    test_list.insertInOrder('D');

    assert(test_list.toString() == "[CharLinkedList of size 1 <<D>>]");
}
/*
*  CharLinkedList.h
*  Naomi Gillis (ngilli02)
*  February 5, 2024
*
*  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
*
*  This is a class declaration for a charLinkedList
 *  A char linked list holds a list of chars and this 
 *  class holds all possible functions for the linked list class.
 *  Some things that a char linked list can do include popback, (add 
 *  a char to the back of an list), insetAt, ( put a new char 
 *  at an index given by the user) and concatenate(combine two 
 *  linkedlists)
*
*/


#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H
#include <string>


class CharLinkedList {


public:
    CharLinkedList(); //constructor
    CharLinkedList(char c);//constructor
    CharLinkedList(char arr [], int size);//constructor
    CharLinkedList(const CharLinkedList &other);//constructor
    ~CharLinkedList();//destructor
    CharLinkedList &operator=(const CharLinkedList &other); //= operation
     bool isEmpty() const;//checks if empty
    void clear(); //clears arraylist
    int size() const; //gets size
    char first() const;//gets first char
    char last() const;//gets last char
    char elementAt(int index) const; //gets indexth char 
    std:: string toString() const; //prints arraylist
    std :: string toReverseString() const; //prints arraylist backwards
    void pushAtBack(char c); //pushes new char to back
    void pushAtFront(char c); //pushes new char to front
    void insertAt(char c, int index);//pushes new char to index
    void insertInOrder(char c); //inserts char in ascii order
    void popFromFront(); //pops first char
    void popFromBack();//pops last char
    void removeAt(int index); //removes indexth char
    void replaceAt(char c, int index); //replaces indexth char
    void concatenate(CharLinkedList *other); //combines two arraylists


private:
    struct Node {
        char      info;
        Node       *next;
        Node       *previous;
    };
    Node *head;
    Node *tail;
    int numItems; //size
    char elementAtRecursion(Node * n, int index) const;
    Node* replaceAtRecursion(Node * n, int index) const;


};




#endif






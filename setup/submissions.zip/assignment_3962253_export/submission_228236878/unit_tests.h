/*
*  unit_tests.h
*  Naomi Gillis (ngilli02)
*  February 5, 2024
*
*  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
*
*  Unit Testing for the CharLinkedList class
*
*/


#include <cassert>




#include "CharLinkedList.h"


//tests basic constructor
void constructor_test_0() {
}
//tests basic constructor
void constructor_test_10() {
    CharLinkedList test_list;
}
//tests size with basic constructor
void size_test_0()
{
    CharLinkedList test_list;
    assert(test_list.size() == 0);
}
//tests one char constructor
void constructor_test_1() {
    char a = 'a';
    CharLinkedList test_list = CharLinkedList(a);
    assert(test_list.size() == 1);
    assert(test_list.toString() == "[CharLinkedList of size 1 <<a>>]");
}
//tests constructor when given array and size
void constructor_test_2() {
    char hello[3] = {'a','b','c'};
    CharLinkedList test_list = CharLinkedList(hello, 3);
    assert(test_list.toString() == "[CharLinkedList of size 3 <<abc>>]");
}
//tests constructor when given array and size
void constructor_test_12() {
    char hello[1] = {'a'};
    CharLinkedList test_list = CharLinkedList(hello, 1);
    assert(test_list.toString() == "[CharLinkedList of size 1 <<a>>]");
}
//tests constructor when given array and size
void constructor_test_13() {
    char hello[2] = {'a', 'b'};
    CharLinkedList test_list = CharLinkedList(hello, 2);
    assert(test_list.toString() == "[CharLinkedList of size 2 <<ab>>]");
}
// tests constructor when given another Linkedlist
void constructor_test_5() {
    char hello[3] = {'a','b','c'};
    CharLinkedList test_list = CharLinkedList(hello, 3);
    CharLinkedList test_list2 = CharLinkedList(test_list);
    assert(test_list2.toString() == "[CharLinkedList of size 3 <<abc>>]");
}
// tests operator equals function when same size
void operator_test_0() {
    char hello[3] = {'a','b','c'};
    CharLinkedList test_list = CharLinkedList(hello, 3);
    char hello2[3] = {'A','b','c'};
    CharLinkedList test_list2 = CharLinkedList(hello2,3);
    test_list = test_list2;
    assert(test_list.toString() == "[CharLinkedList of size 3 <<Abc>>]");
}
//tests operator equals function when both empty
void operator_test_1() {
    CharLinkedList test_list;
    CharLinkedList test_list2;
    test_list = test_list2;
    assert(test_list2.toString() == "[CharLinkedList of size 0 <<>>]");
}
//tests operator equals function when test1 is empty
void operator_test_2() {
    CharLinkedList test_list;
    char hello2[3] = {'A','b','c'};
    CharLinkedList test_list2 = CharLinkedList(hello2,3);
    test_list = test_list2;
    assert(test_list2.toString() == "[CharLinkedList of size 3 <<Abc>>]");
}
//tests operator equals function when test2 is empty
void operator_test_3() {
    char hello[3] = {'a','b','c'};
    CharLinkedList test_list = CharLinkedList(hello, 3);
    CharLinkedList test_list2;
    test_list = test_list2;
    assert(test_list2.toString() == "[CharLinkedList of size 0 <<>>]");
}
//tests to string on empty linked list
void to_string_0() {
    CharLinkedList test_list = CharLinkedList();
    assert(test_list.size() == 0);
    assert(test_list.toString() == "[CharLinkedList of size 0 <<>>]");
}
// tests pushAtBack when empty
void  push_back_test_0() {
    CharLinkedList test_list;
    test_list.pushAtBack('c');
    assert(test_list.toString() == "[CharLinkedList of size 1 <<c>>]");
}
// tests pushAtBack when empty and pushes twice
void  push_back_test_1() {
    CharLinkedList test_list;
    test_list.pushAtBack('c');
    test_list.pushAtBack('c');
    assert(test_list.toString() == "[CharLinkedList of size 2 <<cc>>]");
}
// tests pushAtBack when has one char and pushes once
void  push_back_test_5() {
    char a = 'a';
    CharLinkedList test_list = CharLinkedList(a);
    test_list.pushAtBack('c');
    assert(test_list.toString() == "[CharLinkedList of size 2 <<ac>>]");
}
// tests pushAtBack when has one char and pushes twice
void  push_back_test_4() {
    char a = 'a';
    CharLinkedList test_list = CharLinkedList(a);
    test_list.pushAtBack('c');
    test_list.pushAtBack('c');
    assert(test_list.toString() == "[CharLinkedList of size 3 <<acc>>]");
}
// tests pushAtBack when has three chars and pushes
void  push_back_test_2() {
    char hello[3] = {'a','b','c'};
    CharLinkedList test_list = CharLinkedList(hello, 3);
    test_list.pushAtBack('c');
    assert(test_list.size() == 4);
}
// tests pushAtBack when has three chars and pushes
void  push_back_test_3() {
    char hello[3] = {'a','b','c'};
    CharLinkedList test_list = CharLinkedList(hello, 3);
    test_list.pushAtBack('c');
    assert(test_list.toString() == "[CharLinkedList of size 4 <<abcc>>]");
}
// tests clean when has three chars
void  clean_test_0() {
    char hello[3] = {'a','b','c'};
    CharLinkedList test_list = CharLinkedList(hello, 3);
    test_list.clear();
    assert(test_list.toString() == "[CharLinkedList of size 0 <<>>]");
}
// tests clean when has three chars, checks is empty
void  clean_test_1() {
    char hello[3] = {'a','b','c'};
    CharLinkedList test_list = CharLinkedList(hello, 3);
    test_list.clear();
    assert(test_list.isEmpty() );
}
// tests clean when is empty, checks is empty
void  clean_test_2() {
    CharLinkedList test_list;
    test_list.clear();
    assert(test_list.isEmpty());
}
//tests isEmpty when empty
void is_empty_test_0() {
    CharLinkedList test_list;
    assert(test_list.isEmpty());
}
//tests isEmpty when not empty
void is_empty_test_1() {
    char a = 'a';
    CharLinkedList test_list = CharLinkedList(a);
    assert(not test_list.isEmpty());
}
//tests isEmpty when not empty and then is cleared
void is_empty_test_2() {
    char a = 'a';
    CharLinkedList test_list = CharLinkedList(a);
    test_list.clear();
    assert(test_list.isEmpty());
}


// tests first when one char in Linkedlist
void first_test_0() {
    char a = 'a';
    CharLinkedList test_list = CharLinkedList(a);
    assert(test_list.first() == 'a');
}
// tests first when three chars in Linkedlist
void first_test_1() {
    char hello[3] = {'a','b','c'};
    CharLinkedList test_list = CharLinkedList(hello, 3);
    assert(test_list.first() == 'a');
}
// tests first when no chars in Linkedlist
//makes sure throws correct exception
void first_test_2() {
    CharLinkedList test_list;
    // var to track whether range_error is thrown
    bool runtime_error_thrown = false;


    // var to track any error messages raised
    std::string error_message = "";


    try {
        test_list.first();
    } catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "cannot get first of empty LinkedList");
}
void last_test_0() {
    char a = 'a';
    CharLinkedList test_list = CharLinkedList(a);
    assert(test_list.last() == 'a');
}
// tests first when three chars in Linkedlist
void last_test_1() {
    char hello[3] = {'a','b','c'};
    CharLinkedList test_list = CharLinkedList(hello, 3);
    assert(test_list.last() == 'c');
}
// tests first when no chars in Linkedlist
// makes sure throws correct exception
void last_test_2() {
    CharLinkedList test_list;
    // var to track whether range_error is thrown
    bool runtime_error_thrown = false;


    // var to track any error messages raised
    std::string error_message = "";


    try {
        test_list.last();
    } catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }


    assert(runtime_error_thrown);
    assert(error_message == "cannot get last of empty LinkedList");
}


// tests reverse string with nothing in it
void reverse_string_test_0() {
    CharLinkedList test_list;
    assert(test_list.toReverseString() == "[CharLinkedList of size 0 <<>>]");
}
// tests reverse string with three chars in it
void  reverse_string_2() {
    char hello[3] = {'a','b','c'};
    CharLinkedList test_list = CharLinkedList(hello, 3);
    assert(test_list.toReverseString() == "[CharLinkedList of size 3 <<cba>>]");
}
// tests reverse string with one char in it
void  reverse_string_3() {
    char a = 'a';
    CharLinkedList test_list = CharLinkedList(a);
    assert(test_list.toReverseString() == "[CharLinkedList of size 1 <<a>>]");
}


// tests pushAtFront when has empty and pushes once
void  push_front_test_0() {
    CharLinkedList test_list;
    test_list.pushAtFront('c');
    assert(test_list.toString() == "[CharLinkedList of size 1 <<c>>]");
}
// tests pushAtFront when has empty and pushes twice
void  push_front_test_1() {
    CharLinkedList test_list;
    test_list.pushAtFront('c');
    test_list.pushAtFront('b');
    assert(test_list.toString() == "[CharLinkedList of size 2 <<bc>>]");;
}
// tests pushAtFront when has three chars and pushes once
void  push_front_test_2() {
    char hello[3] = {'a','b','c'};
    CharLinkedList test_list = CharLinkedList(hello, 3);
    test_list.pushAtFront('c');
    assert(test_list.size() == 4);
}
// tests pushAtFront when has three chars and pushes once
void  push_front_test_3() {
    char hello[3] = {'a','b','c'};
    CharLinkedList test_list = CharLinkedList(hello, 3);
    test_list.pushAtFront('c');
    assert(test_list.toString() == "[CharLinkedList of size 4 <<cabc>>]");
}

// Tests correct insertion into an empty AL.
// Afterwards, size should be 1 and element at index 0
// should be the element we inserted.
void insertAt_empty_correct() {
    CharLinkedList test_list;
    test_list.insertAt('a', 0);
    assert(test_list.size() == 1);
    assert(test_list.toString() == "[CharLinkedList of size 1 <<a>>]");
}

// // Tests incorrect insertion into an empty AL.
// // Attempts to call insertAt for index larger than 0.
// This should result in an std::range_error being raised.
void insertAt_empty_incorrect() {
    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
        // insertAt for out-of-range index
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        // if insertAt is correctly implemented, a range_error will be thrown,
        // and we will end up here
        range_error_thrown = true;
        error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0]");
}

// // Tests correct insertAt for front of 1-element list.
void insertAt_front_singleton_list() {
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at front
    test_list.insertAt('b', 0);

    assert(test_list.size() == 2);
    assert(test_list.toString() == "[CharLinkedList of size 2 <<ba>>]");
}

// Tests correct insertAt for back of 1-element list.
void insertAt_back_singleton_list() {
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at back
    test_list.insertAt('b', 1);

    assert(test_list.size() == 2);
    assert(test_list.toString() == "[CharLinkedList of size 2 <<ab>>]");
}

// Tests calling insertAt for a large number of elements.
// Not only does this test insertAt, it also checks that
// Linked expansion works correctly.
void insertAt_many_elements() {
    CharLinkedList test_list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.insertAt('a', i);
    }

    assert(test_list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
}

// Tests insertion into front of a larger list
void insertAt_front_large_list() {
    char test_arr[9] = {'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(test_arr, 9);

    test_list.insertAt('y', 0);

    assert(test_list.size() == 10);
    // assert(test_list.elementAt(0) == 'y');
    assert(test_list.toString() == "[CharLinkedList of size 10"
                                    " <<yabczdefgh>>]");
}

// Tests insertion into the back of a larger list
void insertAt_back_large_list() {
    char test_arr[10] = {'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(test_arr, 10);

    test_list.insertAt('x', 10);

    assert(test_list.size() == 11);
    // assert(test_list.elementAt(10) == 'x');
    assert(test_list.toString() ==
           "[CharLinkedList of size 11 <<yabczdefghx>>]");
}

// Tests insertion into the middle of a larger list
void insertAt_middle_large_list() {
    char test_arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(test_arr, 8);

    test_list.insertAt('z', 3);

    assert(test_list.size() == 9);
    // assert(test_list.elementAt(3) == 'z');
    assert(test_list.toString() == "[CharLinkedList of size 9 <<abczdefgh>>]");
}

// Tests out-of-range insertion for a non-empty list.
void insertAt_nonempty_incorrect() {
    char test_arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.insertAt('a', 42);
    } catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8]");
}
// tests popFromFront when starts empty
//tests exception
void pop_from_front_0() {
    CharLinkedList test_list;

    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.popFromFront();
    } catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}
// tests popFromFront when starts with one char 
void pop_from_front_1() {
    char test_arr[8] = {'a'};
    CharLinkedList test_list(test_arr, 1);

    test_list.popFromFront();

    assert(test_list.size() == 0);
    assert(test_list.toString() == "[CharLinkedList of size 0 <<>>]");
}
// tests popFromFront when starts full 
void pop_from_front_2() {
    char test_arr[7] = {'a', 'b', 'c', 'd', 'f', 'g', 'h'};
    CharLinkedList test_list(test_arr, 7);

    test_list.popFromFront();

    assert(test_list.size() == 6);
    assert(test_list.toString() == "[CharLinkedList of size 6 <<bcdfgh>>]");
}

// tests popFromBack when starts empty
//tests exception
void pop_from_back_0() {
    CharLinkedList test_list;

    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.popFromBack();
    } catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}
// tests popFromBack when starts full 
void pop_from_back_2() {
    char test_arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(test_arr, 8);

    test_list.popFromBack();

    assert(test_list.size() == 7);
    assert(test_list.toString() == "[CharLinkedList of size 7 <<abcdefg>>]");
}
// tests popFromBack when starts with one char 
void pop_from_back_3() {
    char test_arr[8] = {'a'};
    CharLinkedList test_list(test_arr, 1);

    test_list.popFromBack();

    assert(test_list.size() == 0);
    assert(test_list.toString() == "[CharLinkedList of size 0 <<>>]");
}
// tests remove when starts empty
//tests exception being thrown 
void remove_0() {
    CharLinkedList test_list;

    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.removeAt(3);
    } catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "index (3) not in range [0..0)");
}
// tests remove when starts empty and index = 0 
//tests exception being thrown 
void remove_7() {
    CharLinkedList test_list;

    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.removeAt(0);
    } catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "index (0) not in range [0..0)");
}
// tests remove when starts wiht one char but index is OOB
void remove_at_1() {
    char test_arr[1] = {'a'};
    CharLinkedList test_list(test_arr, 1);

    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.removeAt(3);
    } catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "index (3) not in range [0..1)");
}
// tests remove when starts with one char 
void remove_at_2() {
    char test_arr[1] = {'a'};
    CharLinkedList test_list(test_arr, 1);

    test_list.removeAt(0);

    assert(test_list.size() == 0);
    assert(test_list.toString() == "[CharLinkedList of size 0 <<>>]");
}
// tests remove when starts full 
void remove_at_3() {
    char test_arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList test_list(test_arr, 5);

    test_list.removeAt(0);

    assert(test_list.size() == 4);
    assert(test_list.toString() == "[CharLinkedList of size 4 <<bcde>>]");
}
void remove_at_4() {
    char test_arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList test_list(test_arr, 5);

    test_list.removeAt(3);

    assert(test_list.size() == 4);
    assert(test_list.toString() == "[CharLinkedList of size 4 <<abce>>]");
}


// tests concatenate when both lists are empty 
void concatenate_0() {
    
    CharLinkedList test_list;
    CharLinkedList test_list2;

    test_list.concatenate(&test_list2);

    assert(test_list.size() == 0);
    assert(test_list.toString() == "[CharLinkedList of size 0 <<>>]");
}
// tests concatenate when list two is empty 
void concatenate_1() {
    char test_arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList test_list(test_arr, 5);
    CharLinkedList test_list2;

    test_list.concatenate(&test_list2);
    
    assert(test_list.size() == 5);
    assert(test_list.toString() == "[CharLinkedList of size 5 <<abcde>>]");
}
// tests concatenate when list one is empty 
void concatenate_2() {
    char test_arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList test_list(test_arr, 5);
    CharLinkedList test_list2;

    test_list2.concatenate(&test_list);
    
    assert(test_list.size() == 5);
    assert(test_list.toString() == "[CharLinkedList of size 5 <<abcde>>]");
}
// tests concatenate when both lists are the same 
void concatenate_3() {
    char test_arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList test_list(test_arr, 5);
    char test_arr2[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList test_list2(test_arr2, 5);

    test_list.concatenate(&test_list2);
    
    assert(test_list.size() == 10);
    assert(test_list.toString() == "[CharLinkedList of size 10"
                                    " <<abcdeabcde>>]");
}
// tests concatenate when both lists are full 
void concatenate_4() {
    char test_arr[3] = {'c', 'a', 't'};
    CharLinkedList test_list(test_arr, 3);
    char test_arr2[8] = {'C', 'H', 'E', 'S', 'H', 'I', 'R', 'E'};
    CharLinkedList test_list2(test_arr2, 8);
    
    test_list.concatenate(&test_list2);
    
    assert(test_list.size() == 11);
    assert(test_list.toString() == "[CharLinkedList of size 11 " 
                                   "<<catCHESHIRE>>]");
}
// tests concatenate when concatenates itself 
void concatenate_5() {
    char test_arr[2] = {'a', 'b'};
    CharLinkedList test_list(test_arr, 2);
    test_list.concatenate(&test_list);
    
    assert(test_list.size() == 4);
    assert(test_list.toString() == "[CharLinkedList of size 4 "
                                   "<<abab>>]");
}
// tests concatenate when concatenates itself 
void concatenate_6() {
    char test_arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList test_list(test_arr, 5);
    test_list.concatenate(&test_list);
    
    assert(test_list.size() == 10);
    assert(test_list.toString() == "[CharLinkedList of size 10 "
                                   "<<abcdeabcde>>]");
}

// tests insertInOrder when starts empty 
void insert_in_order_0() {
    CharLinkedList test_list;

    test_list.insertInOrder('z');

    assert(test_list.size() == 1);
    assert(test_list.toString() == "[CharLinkedList of size 1 <<z>>]");
}
// tests insertInOrder when empty
void insert_in_order_4() {
    CharLinkedList test_list;

    test_list.insertInOrder('z');

    assert(test_list.size() == 1);
    assert(test_list.toString() == "[CharLinkedList of size 1 <<z>>]");
}
// tests insertInOrder when starts full and char is last ascii wise
void insert_in_order_1() {
    char test_arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(test_arr, 8);

    test_list.insertInOrder('z');

    assert(test_list.size() == 9);
    assert(test_list.toString() == "[CharLinkedList of size 9 <<abcdefghz>>]");
}
// tests insertInOrder when starts full and char is in the middle 
void insert_in_order_2() {
    char test_arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(test_arr, 8);

    test_list.insertInOrder('e');

    assert(test_list.size() == 9);
    assert(test_list.toString() == "[CharLinkedList of size 9 <<abcdeefgh>>]");
}
// tests insertInOrder when starts full and char is in the middle 
void insert_in_order_3() {
    char test_arr[8] = {'a', 'b', 'c', 'd', 'f', 'g', 'h'};
    CharLinkedList test_list(test_arr, 7);

    test_list.insertInOrder('e');

    assert(test_list.size() == 8);
    assert(test_list.toString() == "[CharLinkedList of size 8 <<abcdefgh>>]");
}
// tests insertInOrder when starts full and char is at front 
void insert_in_order_5() {
    char test_arr[8] = {'a', 'b', 'c', 'd', 'f', 'g', 'h'};
    CharLinkedList test_list(test_arr, 7);

    test_list.insertInOrder('a');

    assert(test_list.size() == 8);
    assert(test_list.toString() == "[CharLinkedList of size 8 <<aabcdfgh>>]");
}

// tests elementAt when one char in Linkedlist
void element_at_test_0() {
    char a = 'a';
    CharLinkedList test_list = CharLinkedList(a);
    assert(test_list.elementAt(0) == 'a');
}
// tests elementAt when three chars in Linkedlist
void element_at_test_1() {
    char hello[3] = {'a','b','c'};
    CharLinkedList test_list = CharLinkedList(hello, 3);
    assert(test_list.elementAt(1) == 'b');
}
// tests elementAt when three char in Linkedlist and index is OOB 
//checks correct exception is thrown 
void element_at_test_2() {
    char hello[3] = {'a','b','c'};
    CharLinkedList test_list = CharLinkedList(hello, 3);
    // var to track whether range_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.elementAt(4);
    } catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "index (4) not in range [0..3)");
}
// tests elementAt when no chars in Linkedlist and index is OOB 
//checks correct exception is thrown 
void element_at_test_3() {
    CharLinkedList test_list;
    // var to track whether range_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.elementAt(3);
    } catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "index (3) not in range [0..0)");
}
// tests replace when starts empty
//tests exception being thrown 
void replace_at_0() {
    CharLinkedList test_list;

    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.replaceAt('c', 3);
    } catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "index (3) not in range [0..0)");
}
// tests replace when starts empty and index is 0 
//tests exception being thrown 
void replace_at_7() {
    CharLinkedList test_list;

    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.replaceAt('c', 0);
    } catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "index (0) not in range [0..0)");
}
// tests replace when starts full and replaces at index 0 
void replace_at_1() {
    char test_arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList test_list(test_arr, 5);

    test_list.replaceAt('c', 0);

    assert(test_list.size() == 5);
    assert(test_list.toString() == "[CharLinkedList of size 5 <<cbcde>>]");
}
// tests replace when starts full and replaces at index 4 
void replace_at_2() {
    char test_arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList test_list(test_arr, 5);

    test_list.replaceAt('c', 4);

    assert(test_list.size() == 5);
    assert(test_list.toString() == "[CharLinkedList of size 5 <<abcdc>>]");
}


/*
*  CharLinkedList.cpp
*  Naomi Gillis (ngilli02)
*  February 5, 2024
*
*  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
*
*  Implementation of CharLinkedListClass
*
*/


#include "CharLinkedList.h"
#include <sstream>
using namespace std;

/*
 * name:      CharLinkedList
 * purpose:   No paramater constructor for char linkedlist class
 * arguments: None
 * returns:   Nothing
 * effects:   initializes private variables, sets 
 * everything to zero or nullptr 
 */
CharLinkedList::CharLinkedList()
{
    //sets everything to null or 0 
    head = nullptr;
    tail = nullptr;
    numItems = 0;
}
/*
 * name:      CharLinkedList(char c)
 * purpose:   Single parameter constructor for char linkedlist class
 * arguments: Char c, represents a char to be placed into a arraylist
 * returns:   Nothing
 * effects:   initializes private variables to hold a single char  
 */
CharLinkedList::CharLinkedList(char c)
{
    //makes a new node 
    Node *newNode = new Node();
    //puts the char c into that node
    newNode->info = c;
    //only one node in list, sets previous and next to null
    newNode->previous = nullptr;
    newNode->next = nullptr;
    //head and tail are newNode
    head = newNode;
    tail = newNode;
    numItems = 1;
}
/*
 * name:      CharLinkedList(char arr[], int size)
 * purpose:   constructor for char linkedlist class, holds an array and 
 * it's size to be placed into a linkedlist
 * arguments: a char array holding a list of chars to go into the linkedlist 
 * and the size of the char array 
 * returns:   Nothing
 * effects:   initializes private variables, sets everything based on the 
 * given array  
 */
CharLinkedList::CharLinkedList(char arr [], int size)
{
    //initializes everything in case size = 0 
    numItems = 0;
    head = nullptr;
    tail = nullptr;
    //pushes back each char 
    for (int i = 0; i < size; i++){
        pushAtBack(arr[i]);
    }
}
/*
 * name:      CharLinkedList(const CharLinkedList &other)
 * purpose:   Constructor for char linkedlist class, initializes to 
 * a given linkedlist's information
 * arguments: a pointer to an already made linkedlist 
 * returns:   Nothing
 * effects:   initializes private variables, sets everything to 
 * the values inside of the given linkedlist 
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other)
{
    //initializes everything in case size = 0 
    numItems = 0;
    head = nullptr;
    tail = nullptr;
    //temp node to walk through other list
    Node *temp = other.head;
    while (temp != nullptr){
    //puts other array into this list
        pushAtBack(temp->info);
        temp = temp->next;
    }
}
 /*
 * name:      ~CharLinkedList
 * purpose:   Destructor 
 * arguments: None
 * returns:   Nothing
 * effects:   deletes memory of char linked list  
 */
CharLinkedList::~CharLinkedList()
{
    //node temp to walk through list
    Node *temp = head;
    while (temp != nullptr){
    //deletes each node
        Node *temp2 = temp->next;
        delete temp;
        temp = temp2;
    }
    //sets size to 0 and head/tail to nullptr
    head = nullptr;
    tail = nullptr; 
    numItems = 0;
}
/*
 * name:      = operator
 * purpose:   checks if two linkedlists are equal, returns an linkedlist 
 * containing the other linkedlist 
 * arguments: a CharLinkedList, other, to compare with this arraylist
 * returns:   a CharLinkedList containing the information in the other 
 * linkedlist
 * effects:   moves what is in the other linkedlist into this linkedlist
 */
CharLinkedList& CharLinkedList::operator=(const CharLinkedList &other)
{
    //clears the list if theres anything in it
    clear();
    Node *temp = other.head;
    //temp array to walk through other list 
    while (temp != nullptr){
        //pushes each char in other list to this list
        pushAtBack(temp->info);
        temp = temp->next;
    }
    return *this;
}
/*
 * name:      clear
 * purpose:   deletes all nodes, leaves linked list with one node pointing 
 * to nullptrs and sets size to 0 
 * arguments: None
 * returns:   None
 * effects:   Its necessary to delete every node
 */
void CharLinkedList::clear()
{
    //temp node to walk through list 
    Node *temp = head;
    while (temp != nullptr){
        //deletes each node in the list 
        Node *temp2 = temp->next;
        delete temp;
        temp = temp2;
    }
    //sets everything to null or 0 
    head = nullptr;
    tail = nullptr;
    numItems = 0;
}
/*
 * name:      isEmpty
 * purpose:   checks if the linkedlist's size is zero and determines 
 * if it is empty 
 * arguments: None
 * returns:   a boolean representing if the linkedlist is empty or not 
 * effects:   Determines if a linkedlist is empty
 */
bool CharLinkedList::isEmpty() const
{
    if (numItems == 0)//checks to see
        return true;//if empty
    else
        return false;//returns the correct
}
/*
 * name:      first
 * purpose:   gets the char at the 0th index of an linkedlist
 * arguments: None
 * returns:   a char representing the first char in a linkedlist
 * effects:   Raises an error if the linkedlist is empty
 */
char CharLinkedList::first() const
{
    if (numItems == 0){
        //if the arraylist is empty, throw exception
        throw std::runtime_error("cannot get first" 
                               " of empty LinkedList");
    }
    else{
        return head->info;
    }
}
/*
 * name:      last
 * purpose:   return the last char in an linkedlist 
 * arguments: None
 * returns:   A char representing the last char in an linkedlist
 * effects:   Raises an error if the linkedlist is empty
 */
char CharLinkedList::last() const
{
    if (numItems == 0){
        //if the arraylist is empty, throw exception
        throw std::runtime_error("cannot get last" 
                                " of empty LinkedList");
    }
    else{
        return tail->info;
    }
}
/*
 * name:      pushAtBack
 * purpose:   pushes a given char to the back of the linked list
 * arguments: A char c to be added to the end of the linkedlist 
 * returns:   None
 * effects:   There's different cases is the list is empty 
 */
void CharLinkedList::pushAtBack(char c)
{
    //makes new node holding char c 
    Node* newNode = new Node();
    newNode->info = c;  
    if (numItems == 0){
        //if nothing in list, set head and tail to newNode
        newNode->previous = nullptr;
        head = newNode;
    }
    else {
        newNode->previous = tail; 
        tail->next = newNode; 
    }
    //it will be at back so sets next to null
    newNode->next = nullptr;
    tail = newNode;
    numItems++;
}
/*
 * name:      pushAtFront
 * purpose:   pushes a char to the front of the linkedlist
 * arguments: A char c to be added to the front of the linkedlist 
 * returns:   None
 * effects:   Expands if necessary.
 */
void CharLinkedList::pushAtFront(char c)
{
    //creates newNode holding char c 
    Node* newNode = new Node();
    newNode->info = c;
    if(numItems == 0)
    {
        newNode->next = nullptr; 
        tail = newNode;
    }
    else {
        newNode->next = head;
        head->previous = newNode; 
    }
    //at front so sets previous to null and next to currenthead 
    newNode->previous = nullptr;
    //sets head to newNode
    head = newNode;
    numItems++;
}
/*
 * name:      insertAt
 * purpose:   inserts a char at a given index
 * arguments: a char c to be added to the linked list at index 
 * index. 
 * returns:   None
 * effects:   Raises an error if the index is out of bounds
 */
void CharLinkedList::insertAt(char c, int index)
{
    if (index > numItems or index < 0){ //if out of bounds, throw exception
        throw std::range_error("index (" + std::to_string(index) +
                                ") not in range [0.." 
                                + std::to_string(numItems) +  "]");
    }
    else{ 
        if (index == 0){
            pushAtFront(c);//if insert at index 0, push @ front 
        }
        else if (index == numItems or numItems == 0){
            pushAtBack(c);//if insert at index numItems, push @ front 
        }
        else {
            Node *newNode = new Node(); //creates new node holding 
            newNode->info = c; //char c 
            Node *temp = head;//temp node to walk through list
            int count = 0;//count to get to correct index
            while (count < index){
                count++; //moves so that temp is index
                temp = temp->next; 
            }
            newNode->next = temp;//places newNode correctly into 
            newNode->previous = temp->previous; //list
            temp->previous->next = newNode;//sets all pointers
            temp->previous = newNode;   
            numItems++; 
        }
    } 
}
/*
 * name:      insertInOrder
 * purpose:   places a char into a linkedlist in it's ascii order
 * arguments: char c to be placed into the linkedlist
 * returns:   None
 * effects:   assumes the list is already sorted into ascii order
 */
void CharLinkedList::insertInOrder(char c)
{
    Node *temp = head;
    int count = 0; 
    // node temp to walk through list
    while (temp != nullptr and c > temp->info){
        count++;
        temp = temp->next;//finds correct index
    }
    insertAt(c, count); //inserts 
}
/*
 * name:      elementAt(int index)
 * purpose:   returns the char at index 
 * arguments: an integer index that shows the place in the list 
 * to get the char 
 * returns:   a char representing the char at index index 
 * effects:   Raises an error if index is out of bounds
 * Uses recursion.  
 */
char CharLinkedList::elementAt(int index) const
{
    if (index >= numItems or index < 0 ){
        //if out of bounds, throw exception
        throw std::range_error("index (" + std::to_string(index) +
                                ") not in range [0.." 
                                + std::to_string(numItems) +  ")"); 
    }
    else if (index == 0){
        return first(); //if index is 0, return char in head
    }
    else if (index == numItems - 1){
        return last(); //if index is 0, return char in head
    }
    else {
        //otherwise, recursively find the char 
        return elementAtRecursion(head->next, index - 1);
    }
}
/*
 * name:      elementAtRecursion(Node * n, int index)
 * purpose:   private method, recursively find the node at index 
 * index and returns its char
 * arguments: an integer index that shows the place in the list 
 * to get the char and a node n that continues to equal n->next 
 * until it reaches the node at the indexth index
 * returns:   a char representing the char at index index 
 * effects:   Raises an error if index is out of bounds
 * Uses recursion.  
 */
char CharLinkedList::elementAtRecursion(Node *n, int index) const
{
    if (index == 0){
        return n->info;//if index = 0, return the char at the front 
        //base case 
    }
    else {
        //otherwise, call function again moving node to the next node 
        //and subtracting one from index
        return elementAtRecursion(n->next, index - 1);
    }
}
/*
 * name:      replaceAtRecursion(Node * n, int index)
 * purpose:   private method, recursively find the node at the indexth
 * index 
 * arguments: an integer index that shows the place in the list 
 * to get the char and a node n that continues to equal n->next 
 * until it reaches the node at the indexth index
 * returns:   a node that is at the indexth index
 * effects:   Raises an error if index is out of bounds
 * Uses recursion.  
 */
CharLinkedList::Node* CharLinkedList::replaceAtRecursion(Node *n, 
                                                        int index) const
{
    if (index == 0){
        return n; // if index = 0, return that node
        //base case
    }
    else {
        //otherwise, call function again moving node to the next node 
        //and subtracting one from index
        return replaceAtRecursion(n->next, index - 1);
    }
}
/*
 * name:      replaceAt
 * purpose:   replaces a char at index index with the new char c 
 * arguments: a char c to be placed at index index
 * returns:   None
 * effects:   Raises an error if index is out-of-bounds
 */
void CharLinkedList::replaceAt(char c, int index)
{
    if (index >= numItems or index < 0 or numItems == 0){
        //if out of bounds, throw exception
        throw std::range_error("index (" + std::to_string(index) +
                                ") not in range [0.." 
                                + std::to_string(numItems) +  ")");
    }
    else{
        //recursively find the node to replace
        Node *hold = replaceAtRecursion(head, index);
        //change its char 
        hold->info = c;
        }
}
/*
 * name:      size
 * purpose:   get the size of the linkedlist 
 * arguments: None
 * returns:   an integer holding the linkedlist's current size
 * effects:   N/A
 */
int CharLinkedList::size() const
{
    return numItems;
}
/*
 * name:      popFromFront
 * purpose:   removes the char at the first place in the linkedlist
 * arguments: None
 * returns:   None
 * effects:   Raises an error if linkedlist is empty
 */
void CharLinkedList::popFromFront()
{ 
    if (numItems == 0){
        //if empty, throw exception
        throw std::runtime_error("cannot pop from"  
                                " empty LinkedList");
    }
    else if (numItems == 1){
        //if just one node in list, just clear 
        clear(); 
    }
    else{
        //otherwise delete the first node 
        //and update the head and its pointers
        head = head->next; 
        delete head->previous;
        head->previous = nullptr; 
        numItems--; 
    } 
}
/*
 * name:      popFromBack
 * purpose:   Removes a char from the back of the linkedlist 
 * arguments: None
 * returns:   None
 * effects:   Raises an error if linkedlist is empty
 */
void CharLinkedList::popFromBack()
{ 
    if (numItems == 0){
        //if empty, throw exception
        throw std::runtime_error("cannot pop from"  
                                " empty LinkedList");
    }
    else if (numItems == 1){
        //if just one node in list, just clear 
        clear(); 
    }
    else{
        //otherwise delete the first node 
        //and update the head and its pointers
        tail = tail->previous; 
        delete tail->next;
        tail->next = nullptr; 
        numItems--; 
    } 
}
/*
 * name:      removeAt
 * purpose:   removes the char at the given index
 * arguments: an integer index representing the index to remove a char from
 * returns:   None
 * effects:   Raises an error if index is out of bounds 
 */
void CharLinkedList::removeAt(int index)
{
    if (index >= numItems or index < 0 or numItems == 0){
        //if out of bounds, throw exception
        throw std::range_error("index (" + std::to_string(index) +
                                ") not in range [0.." 
                                + std::to_string(numItems) +  ")");
    }
    else if (numItems == 1){
        clear(); //if only one node, just clear 
    }
    else if (index == 0){
        popFromFront();//if index =0, pop from front
    }
    else if (index == numItems - 1){
        popFromBack();//if index = last element, pop from back 
    }
    else{
        int count = 0;  //count to find correct index
        Node *temp = head; 
        while (count != index)
        {
            temp = temp->next;//find correct index to remeove
            count++; 
        }
        temp->previous->next = temp->next; //sets pointers correctly
        temp->next->previous = temp->previous;
        delete temp; //deletes node at index 
        numItems --;
    }
}
/*
 * name:      concatenate
 * purpose:   combines this list with another list
 * arguments: an linkedlist other to combine with this linkedlist
 * returns:   None
 * effects:   has different cases depending on 
 * lists having no chars or the same chars 
 */
void CharLinkedList::concatenate(CharLinkedList *other)
{
    if (this == other){
        //if self concatenation
        CharLinkedList temp;
        Node *tempNode = head;//put info into temp linked list
        while (tempNode != nullptr){
            temp.pushAtBack(tempNode->info);
            tempNode = tempNode->next;
        }
        Node *temp2 = temp.head;//temp to walk through our list
        while (temp2 != nullptr){
            pushAtBack(temp2->info);//puts everything in temp 
            temp2 = temp2->next; //list into this list 
        }
    }
    else {
        Node *temp = other->head; //walk through other list
        while (temp != nullptr) {
            pushAtBack(temp->info);//pushes everything back into 
            temp = temp->next; //this list 
        }
    }
}
/*
 * name:      toString
 * purpose:   prints out the linkedlist correctly
 * arguments: None
 * returns:   a string containing the correct printed linkedlist 
 * effects:   N/A
 */
std:: string CharLinkedList::toString() const
{
    std::stringstream ss;
    ss << "[CharLinkedList of size ";
    ss << numItems;//prints header part of tostring
    ss << " <<";
    Node *temp = head;
    while (temp != nullptr){
        ss << temp->info;//prints each char in order
        temp = temp->next;
    }
    ss << ">>]";//prints end brackets
    return ss.str();
}
/*
 * name:      toReverseString
 * purpose:   prints out the linkedlist backwards
 * arguments: None
 * returns:   a string containing the correct printed linkedlist 
 * effects:   N/A
 */
std :: string CharLinkedList::toReverseString() const
{
    std::stringstream ss;
    ss << "[CharLinkedList of size ";
    ss << numItems;//prints header part of tostring
    ss << " <<";
    Node *temp = tail;
    while (temp != nullptr){
        ss << temp->info;//prints each char in backwards order 
        temp = temp->previous;
    }
    ss << ">>]";//prints end brackets
    return ss.str();


}





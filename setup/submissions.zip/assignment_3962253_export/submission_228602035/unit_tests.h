/*
 *  unit_tests.h
 *  Jonah Kim (jokim01)
 *  2/1/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  Purpose: Run unit tests for  the CharLinkedList class
 *
 */
#include "CharLinkedList.h"
#include <cassert>
#include <iostream>

/*
 * Tests if the no argument constructor can create an empty LinkedList without
 issue
*/
void no_arg_constructor_test()
{
    CharLinkedList testList;
    assert(testList.toString() == "[CharLinkedList of size 0 <<>>]");
}

/*
 * Tests if the singleton constructor can create a 1-element constructor
 with the correct character. 
*/
void singleton_constructor_test()
{
    CharLinkedList testList = CharLinkedList('a');
    assert(testList.toString() == "[CharLinkedList of size 1 <<a>>]");
}

/*
 * Tests if the array constructor creates an empty list when the user inputs
 an invalid size
*/
void arrayConstructor_empty_invalid_test()
{
    char testArr[0];
    CharLinkedList testList = CharLinkedList(testArr, -1);
    assert(testList.toString() == "[CharLinkedList of size 0 <<>>]");
}

/*
 * Tests if the array constructor can create a list based on an empty array
*/
void arrayConstructor_empty_test()
{
    char testArr[0];
    CharLinkedList testList = CharLinkedList(testArr, 0);
    assert(testList.toString() == "[CharLinkedList of size 0 <<>>]");
}

/*
 * Tests if the CharLinkedList Array constructor creates a singleton
 LinkedList with the correct element and size.
*/
void array_constructor_singleton_test()
{
    char testArr [1] = {'g'};
    CharLinkedList testList = CharLinkedList(testArr, 1);
    assert(testList.toString() == "[CharLinkedList of size 1 <<g>>]");
}

/*
 * Tests if the CharLinkedList Array constructor creates a larger
 LinkedList with the correct elements and size.
*/
void array_constructor_larger_test()
{
    char testArr [7] = {'g','i','l','d','o','n','g'};
    CharLinkedList testList = CharLinkedList(testArr, 7);
    assert(testList.toString() == "[CharLinkedList of size 7 <<gildong>>]");
}

/*
 * Tests if the copy constructor can copy a singleton
*/
void copy_constructor_singletons_test()
{
    CharLinkedList testList = CharLinkedList('a');
    CharLinkedList testList2(testList);
    assert(testList2.toString() == "[CharLinkedList of size 1 <<a>>]");
}

/*
 * Tests if the copy constructor can create a deep copy
*/
void copy_constructor_deep_copy_test()
{
    CharLinkedList testList = CharLinkedList('a');
    CharLinkedList testList2(testList);
    /* Checks if changing testList will change testList2*/
    testList.pushAtBack('b');
    assert(testList2.toString() == "[CharLinkedList of size 1 <<a>>]");
}

/*
 * Tests if the copy constructor can copy a large list
*/
void copy_constructor_large_test()
{
    CharLinkedList testList;
    for (int i = 0; i < 1000; i++)
    {
        testList.pushAtBack('a');
    }
    CharLinkedList testList2(testList);
    assert(testList2.size() == 1000);
    for (int i = 0; i < 1000; i++)
    {
        assert(testList.elementAt(i) == 'a');
    }   
}

/*
 * Tests if the assignment operator can copy the value of a singleton onto
 another singleton
*/
void assignment_operator_two_singleton_test()
{
    CharLinkedList testList = CharLinkedList('a');
    CharLinkedList testList2 = CharLinkedList('b');
    testList = testList2;
    assert(testList.toString() == "[CharLinkedList of size 1 <<b>>]");
}

/*
 * Tests if assignment operator creates a deep copy
*/
void assignment_operator_deep_copy_test()
{
    CharLinkedList testList = CharLinkedList('a');
    CharLinkedList testList2 = CharLinkedList('b');
    testList = testList2;
    /* Checks if changing testList2 will change testList */
    testList2.pushAtBack('c');
    assert(testList.toString() == "[CharLinkedList of size 1 <<b>>]");
}

/*
 * Tests if the list remains the same when the user attempts to assign it 
 to itself
*/
void assignment_operator_self_copy_test()
{
    char testArr [7] = {'g','i','l','d','o','n','g'};
    CharLinkedList testList = CharLinkedList(testArr, 7);
    testList = testList;
    assert(testList.toString() == "[CharLinkedList of size 7 <<gildong>>]");
}

/*
 * Tests if assignment operator can combine an empty list with a non-empty one
*/
void assignment_operator_empty_non_empty_test()
{
    CharLinkedList testList;
    CharLinkedList testList2 = CharLinkedList('b');
    testList = testList2;
    assert(testList.toString() == "[CharLinkedList of size 1 <<b>>]");
}

/*
 * Tests if assignment operator can combine a non-empty list with an empty one
*/
void assignment_operator_non_empty_empty_test()
{
    CharLinkedList testList = CharLinkedList('b');
    CharLinkedList testList2;
    testList = testList2; 
    assert(testList2.toString() == "[CharLinkedList of size 0 <<>>]");
}

/* Tests if assignment operator can make 1 large list equal to the values
of another large list*/
void assignment_operator_large_test()
{
    CharLinkedList testList;
    for  (int i = 0; i < 1000; i++)
    {
        testList.pushAtBack('a');
    }

    CharLinkedList testList2;
    for  (int i = 0; i < 1000; i++)
    {
        testList2.pushAtBack('b');
    }

    testList = testList2;
    assert(testList.size() == 1000);
    for  (int i = 0; i < 1000; i++)
    {
        assert(testList.elementAt(i) == 'b');
    }
}

/*
 * Tests if the isEmpty function can correctly identify an empty list
*/
void isEmpty_empty_test()
{
    CharLinkedList testList;
    assert(testList.isEmpty());
}

/*
 * Tests if the isEmpty function can correctly identify a non-empty list
*/
void isEmpty_non_empty_test()
{
    CharLinkedList testList = CharLinkedList('a');
    assert(not (testList.isEmpty()));
}

/*
 * Tests if the clear function can resolve without changing an already-empty
 list
*/
void clear_empty_test()
{
    CharLinkedList testList;
    testList.clear();
    assert(testList.isEmpty());
}

/*
 * Tests if the clear function can clear a singleton
*/
void clear_singleton_test()
{
    CharLinkedList testList = CharLinkedList('a');
    testList.clear();
    assert(testList.isEmpty());
}

/*
 * Tests if the clear function can clear a large list
*/
void clear_large_test()
{
    CharLinkedList testList;
    for  (int i = 0; i < 1000; i++)
    {
        testList.pushAtBack('a');
    }
    testList.clear();
    assert(testList.isEmpty());
}

/*
 * Tests if a list can be added to and removed from after calling clear
*/
void clear_post_clear_test()
{
    char testArr [7] = {'g','i','l','d','o','n','g'};
    CharLinkedList testList = CharLinkedList(testArr, 7);
    testList.clear();
    testList.pushAtBack('a');
    assert(testList.toString() == "[CharLinkedList of size 1 <<a>>]");
    testList.removeAt(0);
    assert(testList.isEmpty());
}

/*
 * Tests if the size function can return the size of an empty list
*/
void size_empty_test()
{
    CharLinkedList testList;
    assert(testList.size() == 0);
}

/*
 * Tests if the size function can return the size of a singleton
*/
void size_singleton_test()
{
    CharLinkedList testList = CharLinkedList('a');
    assert(testList.size() == 1);
}

/*
 * Tests if the first function can throw correct runtime error when called on
 empty list
*/
void first_empty_test()
{
    bool runtimeErrorThrown = false;
    std::string errorMessage = "";
    CharLinkedList testList;
    try
    {
        testList.first();
    }
    catch(const std::runtime_error &e)
    {
        runtimeErrorThrown = true;
        errorMessage = e.what();
    }
    assert(runtimeErrorThrown);
    assert(errorMessage == "cannot get first of empty LinkedList");
}

/*
 * Tests if the first function can return the first element of a singleeton
*/
void first_singleton_test()
{
    CharLinkedList testList = CharLinkedList('a');
    assert(testList.first() == 'a');
}

/*
 * Tests if the first function can return the first element of a large list
*/
void first_large_test()
{
    CharLinkedList testList = CharLinkedList('a');
    for  (int i = 1; i < 999; i++)
    {
        testList.insertAt('b', i);
    }
    assert(testList.first() == 'a');
}


/*
 * Tests if the last function can throw correct runtime error when called on
 empty list
*/
void last_empty_test()
{
    bool runtimeErrorThrown = false;
    std::string errorMessage = "";
    CharLinkedList testList;
    try
    {
        testList.last();
    }
    catch(const std::runtime_error &e)
    {
        runtimeErrorThrown = true;
        errorMessage = e.what();
    }
    assert(runtimeErrorThrown);
    assert(errorMessage == "cannot get last of empty LinkedList");
}

/*
 * Tests if the last function can return the first element of a singleeton
*/
void last_singleton_test()
{
    CharLinkedList testList = CharLinkedList('a');
    assert(testList.last() == 'a');
}

/*
 * Tests if the last function can return the last element of a large list
*/
void last_large_test()
{
    CharLinkedList testList;
    for  (int i = 0; i < 999; i++)
    {
        testList.insertAt('b', i);
    }
    testList.insertAt('a', 999);
    assert(testList.last() == 'a');
}

/*
 * Tests if elementAt can throw the correct range error when called on empty
 list and the index is less than the lower bound
*/
void elementAt_empty_lower_bound_test()
{
    bool rangeErrorThrown = false;
    std::string errorMessage = "";
    CharLinkedList testList;
    try
    {
        testList.elementAt(-1);
    }
    catch(const std::range_error &e)
    {
        rangeErrorThrown = true;
        errorMessage = e.what();
    }
    assert(rangeErrorThrown);
    assert(errorMessage == "index (-1) not in range [0..0)");
}

/*
 * Tests if elementAt can throw the correct range error when called on empty
 list and the index is equal to the size
*/
void elementAt_empty_upper_bound_test()
{
    bool rangeErrorThrown = false;
    std::string errorMessage = "";
    CharLinkedList testList;
    try
    {
        testList.elementAt(0);
    }
    catch(const std::range_error &e)
    {
        rangeErrorThrown = true;
        errorMessage = e.what();
    }
    assert(rangeErrorThrown);
    assert(errorMessage == "index (0) not in range [0..0)");
}

/*
 * Tests if elementAt can return the element at a valid index of a singleton 
*/
void elementAt_singleton_test()
{
    CharLinkedList testList = CharLinkedList('a');
    assert(testList.elementAt(0) == 'a');

}
/*
 Tests if elementAt can throw the correct range error when called on a large
 list and the index is less than the lower bound
*/
void elementAt_large_lower_bound_test()
{
    bool rangeErrorThrown = false;
    std::string errorMessage = "";
    CharLinkedList testList;
    for  (int i = 0; i < 1000; i++)
    {
    testList.insertAt('a', i);
    }

    try
    {
        testList.elementAt(-1);
    }
    catch(const std::range_error &e)
    {
        rangeErrorThrown = true;
        errorMessage = e.what();
    }
    assert(rangeErrorThrown);
    assert(errorMessage == "index (-1) not in range [0..1000)");
}

/*
 Tests if elementAt can throw the correct range error when called on a large
 list and the index is greater than the upper bound
*/
void elementAt_large_upper_bound_test()
{
    bool rangeErrorThrown = false;
    std::string errorMessage = "";
    CharLinkedList testList;
    for  (int i = 0; i < 1000; i++)
    {
    testList.insertAt('a', i);
    }

    try
    {
        testList.elementAt(1000);
    }
    catch(const std::range_error &e)
    {
        rangeErrorThrown = true;
        errorMessage = e.what();
    }
    assert(rangeErrorThrown);
    assert(errorMessage == "index (1000) not in range [0..1000)");
}

/*
 * Tests if elementAt can return the value at the front of a large list
*/
void elementAt_large_front_test()
{
    CharLinkedList testList;
    
    testList.insertAt('a', 0);
    for  (int i = 1; i < 1000; i++)
    {
        testList.insertAt('b', i);
    }
    assert(testList.elementAt(0) == 'a');
}

/*
 * Tests if elementAt can return the value in the middle of a large list
*/
void elementAt_large_mid_test()
{
    CharLinkedList testList;
    for  (int i = 0; i < 499; i++)
    {
        testList.insertAt('a', i);
    }
    testList.insertAt('b', 499);
    for  (int i = 500; i < 1000; i++)
    {
        testList.insertAt('a', i);
    }
    assert(testList.elementAt(499) == 'b');
}

/*
 * Tests if elementAt can return the value at the back of a large list
*/
void elementAt_large_back_test()
{
    CharLinkedList testList;
    for (int i = 0; i < 1000; i++)
    {
        testList.insertAt('a', i);
    }
    testList.insertAt('b', 1000);
    assert(testList.elementAt(1000) == 'b');
}

/* Tests if toReverseString can print an empty ArrayList */
void toReverseString_empty_test()
{
    CharLinkedList testList;
    assert(testList.toReverseString() == "[CharLinkedList of size 0 <<>>]");
}

/* Tests if toReverseString can print a singleton ArrayList */
void toReversetring_singleton_test()
{
    CharLinkedList testList = CharLinkedList('a');
    assert(testList.toReverseString() == "[CharLinkedList of size 1 <<a>>]");
}

/* Tests if toReverseString can print an ArrayList with more than 1 element */
void toReverseString_larger_test()
{
    char testArr[10] = {'a', 'b', 'a', 'a', 'a', 'a', 'a', 'a', 'a', 'a'};
    CharLinkedList testList = CharLinkedList(testArr, 10);
    assert(testList.toReverseString() == 
    "[CharLinkedList of size 10 <<aaaaaaaaba>>]");
}

/*
 * Tests if the pushAtBack function can insert the correct element at the 
 back of an empty list
*/
void pushAtBack_empty_test()
{
    CharLinkedList testList;
    testList.pushAtBack('a');
    assert(testList.toString() == "[CharLinkedList of size 1 <<a>>]");
    assert(testList.first() == 'a');
    assert(testList.last() == 'a');
}

/*
 * Tests if the pushAtBack function can insert the correct element at the 
 back of a singleton list
*/
void pushAtBack_singleton_test()
{
    CharLinkedList testList = CharLinkedList('a');
    testList.pushAtBack('b');
    assert(testList.toString() == "[CharLinkedList of size 2 <<ab>>]");
    assert(testList.first() == 'a');
    assert(testList.last() == 'b');
}

/*
 * Tests if the pushAtBack function can be called many times in succession
*/
void pushAtBack_many_times_test()
{
    CharLinkedList testList;
    for (int i = 0; i < 1000; i++)
    {
        testList.pushAtBack('b');
    }
    assert(testList.size() == 1000);
    for (int i = 0; i < 1000; i++)
    {
        assert(testList.elementAt(i) == 'b');
    }
}

/*
 * Tests if the pushAtBack function can add an element to the back of a large
 list
*/
void pushAtBack_large_test()
{
    CharLinkedList testList;
    for (int i = 0; i < 1000; i++)
    {
        testList.pushAtBack('b');
    }
    testList.pushAtBack('c');
    assert(testList.elementAt(1000) == 'c');
}

/*
 * Tests if the pushAtFront function can insert the correct element at the 
 front of an empty list
*/
void pushAtFront_empty_test()
{
    CharLinkedList testList;
    testList.pushAtFront('a');

    assert(testList.toString() == "[CharLinkedList of size 1 <<a>>]");
    assert(testList.first() == 'a');
    assert(testList.last() == 'a');
}

/*
 * Tests if the pushAtFront function can insert the correct element at the 
 front of an singleton list
*/
void pushAtFront_singleton_test()
{
    CharLinkedList testList = CharLinkedList('a');
    testList.pushAtFront('b');

    assert(testList.toString() == "[CharLinkedList of size 2 <<ba>>]");
    assert(testList.first() == 'b');
    assert(testList.last() == 'a');
}

/*
 * Tests if the pushAtFront function can be called many times in succession
 without error and result in a LinkedList with accurate size and elements
*/
void pushAtFront_many_times_test()
{
    CharLinkedList testList;
    for (int i = 0; i < 1000; i++)
    {
        testList.pushAtFront('a');
    }

    assert(testList.size() == 1000);
    for (int i = 0; i < 1000; i++)
    {
        assert(testList.elementAt(i) == 'a');
    }
}

/*
 * Tests if the pushAtFront function can add an element to the front of a 
 large list
*/
void pushAtFront_large_test()
{
    CharLinkedList testList;
    for (int i = 0; i < 1000; i++)
    {
        testList.pushAtFront('a');
    }
    testList.pushAtFront('b');

    assert(testList.first() == 'b');
}

/*
 * Tests if the insertAt function can throw correct range error when it 
 receives an index less than the lower bound and the list is empty
*/
void insertAt_empty_lower_bound_test()
{
    bool rangeErrorThrown = false;
    std::string errorMessage = "";
    CharLinkedList testList;
    try
    {
        testList.insertAt('c', -1);
    }
    catch(const std::runtime_error &e)
    {
        rangeErrorThrown = true;
        errorMessage = e.what();
    }
    assert(rangeErrorThrown);
    assert(errorMessage == "index (-1) not in range [0..0]");
}

/*
 * Tests if the insertAt function can throw correct range error when it 
 receives an index greater than the upper bound and the list is empty
*/
void insertAt_empty_upper_bound_test()
{
    bool rangeErrorThrown = false;
    std::string errorMessage = "";
    CharLinkedList testList;
    try
    {
        testList.insertAt('c', 1);
    }
    catch(const std::runtime_error &e)
    {
        rangeErrorThrown = true;
        errorMessage = e.what();
    }
    assert(rangeErrorThrown);
    assert(errorMessage == "index (1) not in range [0..0]");
}

/*
 * Tests if the insertAt function can insert the correct value at the front
  for  empty lists
*/
void insertAt_empty_front_test()
{
    CharLinkedList testList;
    testList.insertAt('a', 0);
    assert(testList.toString() == "[CharLinkedList of size 1 <<a>>]");
 
    assert(testList.first() == 'a');
    assert(testList.last() == 'a');
}

/*
 * Tests if the insertAt function can insert the correct value at the front
  for  singleton lists
*/
void insertAt_singleton_front_test()
{
    CharLinkedList testList = CharLinkedList('a');
    testList.insertAt('b', 0);
    assert(testList.toString() == "[CharLinkedList of size 2 <<ba>>]");
   
    assert(testList.first() == 'b');
    assert(testList.last() == 'a');
}

/*
 * Tests if the insertAt function can insert the correct value at the back
  for  singleton lists
*/
void insertAt_singleton_back_test()
{
    CharLinkedList testList = CharLinkedList('a');
    testList.insertAt('b', 1);
    assert(testList.toString() == "[CharLinkedList of size 2 <<ab>>]");
    assert(testList.first() == 'a');
    assert(testList.last() == 'b');
}

/*
 * Tests if the insertAt can be used to make a large list
*/
void insertAt_make_large_test()
{
    CharLinkedList testList;
    for (int i = 0; i < 1000; i++)
    {
        testList.insertAt('a', i);
    }
    assert(testList.size() == 1000);

    for (int i = 0; i < 1000; i++)
    {
        assert(testList.elementAt(i) == 'a');
    }
}

/*
 * Tests if the insertAt function can throw correct range error when it 
 receives an index less than the lower bound and the list is larger
*/
void insertAt_larger_lower_bound_test()
{
    bool rangeErrorThrown = false;
    std::string errorMessage = "";
    char testArr [7] = {'g','i','l','d','o','n','g'};
    CharLinkedList testList = CharLinkedList(testArr, 7);

    try
    {
        testList.insertAt('c', -1);
    }
    catch(const std::runtime_error &e)
    {
        rangeErrorThrown = true;
        errorMessage = e.what();
    }
    assert(rangeErrorThrown);
    assert(errorMessage == "index (-1) not in range [0..7]");
}

/*
 * Tests if the insertAt function can throw correct range error when it 
 receives an index greater than the upper bound and the list is larger
*/
void insertAt_larger_upper_bound_test()
{
    bool rangeErrorThrown = false;
    std::string errorMessage = "";
    char testArr [7] = {'g','i','l','d','o','n','g'};
    CharLinkedList testList = CharLinkedList(testArr, 7);

    try
    {
        testList.insertAt('c', 8);
    }
    catch(const std::runtime_error &e)
    {
        rangeErrorThrown = true;
        errorMessage = e.what();
    }
    assert(rangeErrorThrown);
    assert(errorMessage == "index (8) not in range [0..7]");
}

/*
 * Tests if the insertAt can insert at the front of a larger list
*/
void insertAt_front_larger_test()
{
    char testArr [7] = {'g','i','l','d','o','n','g'};
    CharLinkedList testList = CharLinkedList(testArr, 7);
    testList.insertAt('a', 0);
    assert(testList.toString() == "[CharLinkedList of size 8 <<agildong>>]");
    assert(testList.first() == 'a');
    assert(testList.last() == 'g');   
}

/*
 * Tests if the insertAt can insert in the middle of a larger list
*/
void insertAt_mid_larger_test()
{
    char testArr [7] = {'g','i','l','d','o','n','g'};
    CharLinkedList testList = CharLinkedList(testArr, 7);
    testList.insertAt('a', 3);
    assert(testList.toString() == "[CharLinkedList of size 8 <<giladong>>]");
    assert(testList.first() == 'g');
    assert(testList.last() == 'g');   
}

/*
 * Tests if the insertAt can insert in the back of a larger list
*/
void insertAt_back_larger_test()
{
    char testArr [7] = {'g','i','l','d','o','n','g'};
    CharLinkedList testList = CharLinkedList(testArr, 7);
    testList.insertAt('a', 7);
    assert(testList.toString() == "[CharLinkedList of size 8 <<gildonga>>]");
    assert(testList.first() == 'g');
    assert(testList.last() == 'a');   
}

/* Tests insertion into an empty list*/
void insert_in_order_empty_test()
{
    CharLinkedList testList;
    testList.insertInOrder('a');
    assert(testList.toString() == "[CharLinkedList of size 1 <<a>>]");
}

/*
 * Tests inserting an element in order into a singleton list
*/
void insert_in_order_singleton_test()
{
    CharLinkedList testList = CharLinkedList('b');
    testList.insertInOrder('a');
    assert(testList.toString() == "[CharLinkedList of size 2 <<ab>>]");
}

/*
 * Tests inserting an element in order into the front of a large list
*/
void insert_in_order_large_front_test()
{
    CharLinkedList testList;
    for (int i = 0; i < 1000; i++)
    {
        testList.pushAtBack('b');
    }
    testList.insertInOrder('a');
    assert(testList.first() == 'a');
}

/*
 * Tests inserting an element in order into the middle of a large list
*/
void insert_in_order_large_mid_test()
{
    CharLinkedList testList;
    for (int i = 0; i < 500; i++)
    {
        testList.pushAtBack('b');
    }
    for (int i = 0; i < 500; i ++)
    {
        testList.pushAtBack('d');
    }
    testList.insertInOrder('c');
    assert(testList.elementAt(500) == 'c');
}

/*
 * Tests inserting an element in order into the back of a large list
*/
void insert_in_order_large_back_test()
{
    CharLinkedList testList;
    for (int i = 0; i < 1000; i++)
    {
        testList.pushAtBack('b');
    }
    testList.insertInOrder('c');
    assert(testList.last() == 'c');
}

/*
 * Tests inserting an element in order if there is an equivalent char in
 a singleton list
*/
void insert_in_order_singleton_duplicate_test()
{
    CharLinkedList testList = CharLinkedList('a');
    testList.insertInOrder('a');
    assert(testList.toString() == "[CharLinkedList of size 2 <<aa>>]");
}

/*
 * Tests inserting an element in order into the front of a large list
 when there are duplicate values
*/
void insert_in_order_large_front_duplicate_test()
{
    CharLinkedList testList;
    testList.pushAtBack('b');
    for (int i = 0; i < 999; i++)
    {
        testList.pushAtBack('c');
    }
    testList.insertInOrder('b');
    assert(testList.elementAt(1) == 'b');
}

/*
 * Tests inserting an element in order into the middle of a large list
 when there are duplicate values
*/
void insert_in_order_large_middle_duplicate_test()
{
    CharLinkedList testList;
    for (int i = 0; i < 500; i++)
    {
        testList.pushAtBack('b');
    }
    for (int i = 0; i < 500; i ++)
    {
        testList.pushAtBack('d');
    }
    testList.insertInOrder('b');
    assert(testList.elementAt(500) == 'b');
}

/*
 * Tests if popFromFront can throw the correct runtime error when called on
 an empty list
*/
void popFromFront_empty_test()
{
    bool runtimeErrorThrown = false;
    std::string errorMessage = "";
    CharLinkedList testList;
    try
    {
        testList.popFromFront();
    }
    catch(const std::runtime_error &e)
    {
        runtimeErrorThrown = true;
        errorMessage = e.what();
    }
    assert(runtimeErrorThrown);
    assert(errorMessage == "cannot pop from empty LinkedList");
}

/*
 * Tests if the popFromFront function can remove the correct value for  
 singleton lists */
void popFromFront_singleton_test()
{
    CharLinkedList testList = CharLinkedList('a');
    testList.popFromFront();
    assert(testList.isEmpty());
}

/* Tests if the popFromFront function can remove the front of a large list */
void popFromFront_large_test()
{
    CharLinkedList testList;
    for (int i = 0; i < 999; i++)
    {
        testList.pushAtBack('a');
    }
    testList.pushAtFront('b');
    testList.popFromFront();
    assert(testList.size() == 999);
    /* If the front was removed properly, the first element should be 'a'
    now */
    assert(testList.first() == 'a');
}

/*
 * Tests if popFromBack can throw the correct runtime error when called on
 an empty list
*/
void popFromBack_empty_test()
{
    bool runtimeErrorThrown = false;
    std::string errorMessage = "";
    CharLinkedList testList;
    try
    {
        testList.popFromBack();
    }
    catch(const std::runtime_error &e)
    {
        runtimeErrorThrown = true;
        errorMessage = e.what();
    }
    assert(runtimeErrorThrown);
    assert(errorMessage == "cannot pop from empty LinkedList");
}

/*
 * Tests if the popFromBack function can remove the correct value for  
 singleton lists */
void popFromBack_singleton_test()
{
    CharLinkedList testList = CharLinkedList('a');
    testList.popFromBack();
    assert(testList.isEmpty());
}

/* Tests if the popFromBack function can remove the back of a large list */
void popFromBack_large_test()
{
    CharLinkedList testList;
    for (int i = 0; i < 999; i++)
    {
        testList.pushAtBack('a');
    }
    testList.pushAtBack('b');
    testList.popFromBack();
    assert(testList.size() == 999);
    /* If the front was removed properly, the last element should be 'a'
    now */
    assert(testList.last() == 'a');
}

/*
 * Tests if removeAt can throw the correct range error when called on an empty
 list and the index is less than the lower bound
*/
void removeAt_empty_lower_bound_test()
{
    bool rangeErrorThrown = false;
    std::string errorMessage = "";
    CharLinkedList testList;
    try
    {
        testList.removeAt(0);
    }
    catch(const std::range_error &e)
    {
        rangeErrorThrown = true;
        errorMessage = e.what();
    }
    assert(rangeErrorThrown);
    assert(errorMessage == "index (0) not in range [0..0)");
}

/*
 * Tests if removeAt can throw the correct range error when called on an empty
 list and the index is greater than the upper bound
*/
void removeAt_empty_upper_bound_test()
{
    bool rangeErrorThrown = false;
    std::string errorMessage = "";
    CharLinkedList testList;
    try
    {
        testList.removeAt(1);
    }
    catch(const std::range_error &e)
    {
        rangeErrorThrown = true;
        errorMessage = e.what();
    }
    assert(rangeErrorThrown);
    assert(errorMessage == "index (1) not in range [0..0)");
}

/*
 * Tests if the removeAt function can remove the correct value for  
 singleton lists */
void removeAt_singleton_test()
{
    CharLinkedList testList = CharLinkedList('a');
    testList.removeAt(0);
    assert(testList.isEmpty());
}

/* Tests if the removeAt function can remove the front of a large list */
void removeAt_large_front_test()
{
    CharLinkedList testList;
    for (int i = 0; i < 999; i++)
    {
        testList.pushAtBack('a');
    }
    testList.pushAtFront('b');
    testList.removeAt(0);
    assert(testList.size() == 999);
    /* If the front was removed properly, the first element should be 'a'
    now */
    assert(testList.first() == 'a');
}

/* Tests if the removeAt function can remove the middle of a large list */
void removeAt_large_mid_test()
{
    CharLinkedList testList;
    for (int i = 0; i < 499; i++)
    {
        testList.insertAt('a', i);
    }
    testList.insertAt('b', 499);
    for (int i = 500; i < 1000; i++)
    {
        testList.insertAt('a', i);
    }
    testList.removeAt(499);
    assert(testList.size() == 999);
    /* If the element was removed properly, the element at index 499 should be
    a */
    assert(testList.elementAt(499) == 'a');
}

/* Tests if the removeAt function can remove the back of a large list */
void removeAt_large_back_test()
{
    CharLinkedList testList;
    for (int i = 0; i < 999; i++)
    {
        testList.pushAtBack('a');
    }
    testList.pushAtBack('b');
    testList.removeAt(999);
    assert(testList.size() == 999);
    /* If the element was removed properly, the element at the back should be
    a */
    assert(testList.last() == 'a');
}

/*
 * Tests if removeAt can throw the correct range error when the user 
 attempts to remove an out-of-range item from a large list and the index is 
 less than the lower bound
*/
void removeAt_large_lower_bound_test()
{
    bool rangeErrorThrown = false;
    std::string errorMessage = "";
    CharLinkedList testList;
    for (int i = 0; i < 1000; i++)
    {
        testList.pushAtBack('a');
    }

    try
    {
        testList.removeAt(-1);
    }
    catch(const std::range_error &e)
    {
        rangeErrorThrown = true;
        errorMessage = e.what();
    }
    assert(rangeErrorThrown);
    assert(errorMessage == "index (-1) not in range [0..1000)");
}

/*
 * Tests if removeAt can throw the correct range error when the user 
 attempts to remove an out-of-range item from a large list and the index is 
 greater than the upper bound
*/
void removeAt_large_upper_bound_test()
{
    bool rangeErrorThrown = false;
    std::string errorMessage = "";
    CharLinkedList testList;
    for (int i = 0; i < 1000; i++)
    {
        testList.pushAtBack('a');
    }

    try
    {
        testList.removeAt(1000);
    }
    catch(const std::range_error &e)
    {
        rangeErrorThrown = true;
        errorMessage = e.what();
    }
    assert(rangeErrorThrown);
    assert(errorMessage == "index (1000) not in range [0..1000)");
}

/*
 * Tests if removeAt can be called many times in succession
*/
void removeAt_large_many_times_test()
{
    CharLinkedList testList;
    for (int i = 0; i < 1000; i++)
    {
        testList.pushAtBack('a');
    }
    for (int i = 999; i > -1; i--)
    {
        testList.removeAt(i);
    }
    assert(testList.isEmpty());
}

/*
 * Tests if replaceAt can throw the correct range error when called on an empty
 list and the index is less than the lower bound
*/
void replaceAt_empty_lower_bound_test()
{
    bool rangeErrorThrown = false;
    std::string errorMessage = "";
    CharLinkedList testList;
    try
    {
        testList.replaceAt('c', -1);
    }
    catch(const std::range_error &e)
    {
        rangeErrorThrown = true;
        errorMessage = e.what();
    }
    assert(rangeErrorThrown);
    assert(errorMessage == "index (-1) not in range [0..0)");
}

/*
 * Tests if replaceAt can throw the correct range error when called on an empty
 list and the index is greater than the upper bound
*/
void replaceAt_empty_upper_bound_test()
{
    bool rangeErrorThrown = false;
    std::string errorMessage = "";
    CharLinkedList testList;
    try
    {
        testList.replaceAt('c', 0);
    }
    catch(const std::range_error &e)
    {
        rangeErrorThrown = true;
        errorMessage = e.what();
    }
    assert(rangeErrorThrown);
    assert(errorMessage == "index (0) not in range [0..0)");
}

/*
 * Tests if the replaceAt function can replace the value in a singleton 
 with another element. */
void replaceeAt_singleton_test()
{
    CharLinkedList testList = CharLinkedList('a');
    testList.replaceAt('b', 0);
    assert(testList.toString() == "[CharLinkedList of size 1 <<b>>]");
}

/* Tests if the replaceAt function can replace the front of a large list
with another element */
void replaceAt_large_front_test()
{
    CharLinkedList testList;
    for (int i = 0; i < 999; i++)
    {
        testList.pushAtBack('a');
    }
    testList.replaceAt('b', 0);
    assert(testList.size() == 999);
    /* If the front was replaced properly, the first element should be 'b'
    now */
    assert(testList.first() == 'b');
}

/* Tests if the replaceeAt function can replace the middle of a large list */
void replaceAt_large_mid_test()
{
    CharLinkedList testList;
    for (int i = 0; i < 1000; i++)
    {
        testList.insertAt('a', i);
    }
    testList.replaceAt('b', 499);
    assert(testList.size() == 1000);
    /* If the element was replaced properly, the element at index 499 should 
    be 'b' */
    assert(testList.elementAt(499) == 'b');
}

/* Tests if the replaceAt function can replace the back of a large list */
void replaceAt_large_back_test()
{
    CharLinkedList testList;
    for (int i = 0; i < 1000; i++)
    {
        testList.pushAtBack('a');
    }
    testList.replaceAt('b', 999);
    assert(testList.size() == 1000);
    /* If the element was removed properly, the element at the back should be
    'b' */
    assert(testList.last() == 'b');
}

/*
 * Tests if replaceAt can throw the correct range error when the user 
 attempts to replace an out-of-range item from a large list and the index
 is less than the lower bound
*/
void replaceAt_large_lower_bound_test()
{
    bool rangeErrorThrown = false;
    std::string errorMessage = "";
    CharLinkedList testList;
    for (int i = 0; i < 1000; i++)
    {
        testList.pushAtBack('a');
    }

    try
    {
        testList.replaceAt('b', -1);
    }
    catch(const std::range_error &e)
    {
        rangeErrorThrown = true;
        errorMessage = e.what();
    }
    assert(rangeErrorThrown);
    assert(errorMessage == "index (-1) not in range [0..1000)");
}

/*
 * Tests if replaceAt can throw the correct range error when the user 
 attempts to replace an out-of-range item from a large list and the index
 is less than the upper bound
*/
void replaceAt_large_upper_bound_test()
{
    bool rangeErrorThrown = false;
    std::string errorMessage = "";
    CharLinkedList testList;
    for (int i = 0; i < 1000; i++)
    {
        testList.pushAtBack('a');
    }

    try
    {
        testList.replaceAt('b', 1000);
    }
    catch(const std::range_error &e)
    {
        rangeErrorThrown = true;
        errorMessage = e.what();
    }
    assert(rangeErrorThrown);
    assert(errorMessage == "index (1000) not in range [0..1000)");
}

/*
 * Tests if replaceAt can be called many times in succession
*/
void replaceAt_large_many_times_test()
{
    CharLinkedList testList;
    for (int i = 0; i < 1000; i++)
    {
        testList.pushAtBack('a');
    }
    for (int i = 999; i > -1; i--)
    {
        testList.replaceAt('b', i);
    }

    for (int i = 0; i < 1000; i++)
    {
        assert(testList.elementAt(i) == 'b');
    }
    
}


/*
 * Tests if concatenate can combine 2 singletons
*/
void concatenate_singletons_test()
{
    CharLinkedList testList = CharLinkedList('a');
    CharLinkedList testList2 = CharLinkedList('b');
    testList.concatenate(&testList2);
    assert(testList.toString() == "[CharLinkedList of size 2 <<ab>>]");
}

/*
 * Tests if concatenate creates a deep copy
*/
void concatenate_deep_copy_test()
{
    CharLinkedList testList = CharLinkedList('a');
    CharLinkedList testList2 = CharLinkedList('b');
    testList.concatenate(&testList2);
    /* Checks if changing testList2 will change testList */
    testList2.pushAtBack('c');
    assert(testList.toString() == "[CharLinkedList of size 2 <<ab>>]");
}

/*
 * Tests if concatenate can enable a list to copy itself
*/
void concatenate_self_copy_test()
{
    char testArr [7] = {'g','i','l','d','o','n','g'};
    CharLinkedList testList = CharLinkedList(testArr, 7);
    testList.concatenate(&testList);
    assert(testList.toString() == 
    "[CharLinkedList of size 14 <<gildonggildong>>]");
}

/*
 * Tests if concatenate can combine an empty list with a non-empty one
*/
void concatenate_empty_non_empty_test()
{
    CharLinkedList testList;
    CharLinkedList testList2 = CharLinkedList('b');
    testList.concatenate(&testList2);
    assert(testList.toString() == "[CharLinkedList of size 1 <<b>>]");
}

/*
 * Tests if concatenate can combine a non-empty list with an empty one
*/
void concatenate_non_empty_empty_test()
{
    CharLinkedList testList;
    CharLinkedList testList2 = CharLinkedList('b');
    /* Combines the non-empty testList2 with testList instead of the other
    way around, like in the above test*/
    testList2.concatenate(&testList);
    assert(testList2.toString() == "[CharLinkedList of size 1 <<b>>]");
}

/* Tests if concatenate can combine 2 large lists*/
void concatenate_large_test()
{
    CharLinkedList testList;
    for (int i = 0; i < 1000; i++)
    {
        testList.pushAtBack('a');
    }
    CharLinkedList testList2;
    for (int i = 0; i < 1000; i++)
    {
        testList2.pushAtBack('b');
    }

    testList.concatenate(&testList2);
    assert(testList.size() == 2000);
    for (int i = 0; i < 1000; i++)
    {
        assert(testList.elementAt(i) == 'a');
    }
    /* Checks if testList2's items have been inserted in the right order*/
    for (int i = 1000; i < 2000; i++)
    {
        assert(testList.elementAt(i) == 'b');        
    }
}


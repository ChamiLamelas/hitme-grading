/*
 *  CharLinkedList.h
 *  Jonah Kim (jokim01)
 *  2/1/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Purpose: CharLinkedList is a class that represents an ordered list of 
 char instances. The list is implemented using a LinkedList, so adding and
 removing elements is relatively fast, but accessing them is slower than 
 ArrayLists. By default, a CharLinkedList starts as empty, but clients can
 create singleton and multi-element instances. They can then add and remove
 chars from the list, replace elements, retrieve elements at the front, back or 
 another specific location, retrieve the contents of the entire list for 
 printing, clear the list completely, copy and concatenate lists.  
 * 
 */
#include <string>
#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H

class CharLinkedList 
{
    public:
    CharLinkedList();
    CharLinkedList(char c);
    CharLinkedList(char arr[], int size);
    CharLinkedList(const CharLinkedList &other);
    ~CharLinkedList();
    CharLinkedList &operator=(const CharLinkedList &other);
    bool isEmpty() const;
    void clear();
    int size() const;
    char first() const;
    char last() const;
    char elementAt(int index) const;
    std::string toString() const;
    std::string toReverseString() const;
    void pushAtBack(char c);
    void pushAtFront(char c);
    void insertAt(char c, int index);
    void insertInOrder(char c);
    void popFromFront();
    void popFromBack();
    void removeAt(int index);
    void replaceAt(char c, int index);
    void concatenate(CharLinkedList *other);
   
    private:
    int listSize;
     struct Node
    {
        Node *prev;
        Node *next;
        char element;
    };
    Node *findNode(int i1, int i2, Node *curr) const;
    Node *front;
    Node *back;

    Node *newNode(Node *insertPrev, Node *insertNext, char insertElement);
    void deleteNodes(Node *curr);
    void deleteNodesSingletonCase(Node *curr);
    void rangeErrorInclusive(int index);
    void rangeErrorExclusive(int index) const;
    void emptyCaseInsertAt(char c);
    void singletonCaseRemoveAt(Node *nodeToRemove);
};



#endif

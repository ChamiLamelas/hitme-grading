/*
 *  CharLinkedList.cpp
 *  Jonah Kim (jokim01)
 *  2/1/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Purpose: This file contains an implementation of the CharLinkedList class
 *
 */

#include "CharLinkedList.h"
#include <sstream>
#include <iostream>

using namespace std;

/*
 * name: CharLinkedList default constructor
 * purpose: Create an empty instance of CharLinkedList
 * parameters: none
 * return value: none
 * effects: Initializes size to 0 and the pointers to the front and back of
 the list to null.
*/
CharLinkedList::CharLinkedList()
{
    listSize = 0;
    front = nullptr;
    back = nullptr;
}

/*
 * name: CharLinkedList singleton constructor
 * purpose: Create an instance of CharLinkedList with 1 element
 * parameters: A character to initialize the list with
 * return value: none
 * effects: Initializes size to 1 and the first node's values. Assigns the
 front and back pointers to the first node.
*/
CharLinkedList::CharLinkedList(char c)
{
    front = newNode(nullptr, nullptr, c);
    back = front;
    listSize = 1;
}

/*
 * name: CharLinkedList array constructor
 * purpose: Create a CharLinkedList with the same size and elements as a char
 array
 * parameters: A group of elements and how many there are
 * return value: none
 * effects: Initializes all nodes in the list based on the char array
*/
CharLinkedList::CharLinkedList(char arr[], int size)
{
    // Need to initialize elements before inserting new elements
    listSize = 0;
    front = nullptr;
    back = nullptr;
    for (int i = 0; i < size; i++)
    {
        insertAt(arr[i], i);
    }  
}

/*
 * name: CharLinkedList copy constructor
 * purpose: Create a deep copy of another CharLinkedList instance
 * parameters: The location of the list to be copied
 * return value: none
 * effects: Creates a deep copy with the same size and elements as another 
 CharLinkedList
*/
CharLinkedList::CharLinkedList(const CharLinkedList &other)
{
    int otherSize = other.size();
    /* Initializes variables to default values to avoid errors when pushing at 
    back*/
    listSize = 0;
    front = nullptr;
    back = nullptr;
    for (int i = 0; i < otherSize; i++)
    {
        pushAtBack(other.elementAt(i));
    }   
}

/*
 * name: CharLinkedList assignment operator
 * purpose: Creates a deep copy of the list on the right of the equal sign to
 the one on the left of the equal sign.
 * parameters: The address of a list to be copied
 * return value: The new CharLinkedList instance
 * effects: Creates a deep copy with the same size and elements as another 
 CharLinkedList to the object on the left side of the equal sign.
*/
CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other)
{
    if (this == &other)
    {
        return *this;
    }
    int otherSize = other.size();
    clear();
    for (int i = 0; i < otherSize; i++)
    {
        pushAtBack(other.elementAt(i));
    }
    return *this;
}
/*
 * name: CharLinkedList destructor
 * purpose: Clear memory taken up by CharLinkedList nodes
 * parameters: none
 * return value: none
 * effects: Results in all nodes being deleted with all memory freed
*/
CharLinkedList::~CharLinkedList()
{
    deleteNodes(front);
}

/*
 * name: isEmpty
 * purpose: Tell whether the list is empty or not
 * parameters: none
 * return value: Return whether the list is empty or not
 * effects: none
*/
bool CharLinkedList::isEmpty() const
{
    if (listSize == 0 and front == nullptr and back == nullptr)
    {
        return true;
    }
    return false;
}

/*
 * name: clear
 * purpose: Deletes all nodes in the list but not the list itself
 * parameters: none
 * return value: none
 * effects: Results in an empty list with no Nodes. Size of the list is 0 and
 the front and back point to nothing.
*/
void CharLinkedList::clear()
{
    if (isEmpty())
    {
        return;
    }
    deleteNodes(front);
}


/*
 * name: size
 * purpose: Tell how many members the list has
 * parameters: none
 * return value: Return the number of members in the list
 * effects: none
*/
int CharLinkedList::size() const
{
    return listSize;
}

/*
 * name: first
 * purpose: Provide the first element in the list
 * parameters: none
 * return value: Returns the first element in the list
 * effects: none
*/
char CharLinkedList::first() const
{
    if (listSize == 0)
    {
        throw std::runtime_error("cannot get first of empty LinkedList");
    }
    return front->element;
}

/*
 * name: first
 * purpose: Provide the first element in the list
 * parameters: none
 * return value: Returns the first element in the list
 * effects: none
*/
char CharLinkedList::last() const
{
    if (listSize == 0)
    {
        throw std::runtime_error("cannot get last of empty LinkedList");
    }
    return back->element;
}

/*
 * name: elementAt
 * purpose: Return the element at a specified index
 * parameters: The location of the element that will be returned
 * return value: Return the character at the specified index
 * effects: none
*/
char CharLinkedList::elementAt(int index) const
{
    rangeErrorExclusive(index);
    CharLinkedList::Node *desiredNode = findNode(0, index, front);
    return desiredNode->element;
}

/*
 * name: toString
 * purpose: Convert the contents of a list into a string to be printed
 * parameters: none
 * return value: Returns the size and contents of the list as a formatted
 string
 * effects: none
*/
std::string CharLinkedList::toString() const
{
    std::stringstream ss;
    ss << "[CharLinkedList of size " << listSize << " <<";
    CharLinkedList::Node *curr = front;
    // Adds elements to the string if the list is not empty
    while(curr != nullptr)
    {
        ss << curr->element;
        curr = curr->next;
    }
    ss << ">>]";
    return ss.str();
}

/*
 * name: toReverseString
 * purpose: Convert the contents of a list into a string to be printed in
reverse order.
 * parameters: none
 * return value: Returns the size and contents of the list as a formatted
 string in reverse order
 * effects: none
*/
std::string CharLinkedList::toReverseString() const
{
    std::stringstream ss;
    ss << "[CharLinkedList of size " << listSize << " <<";
    CharLinkedList::Node *curr = back;
    while(curr != nullptr)
    {
        ss << curr->element;
        curr = curr->prev;
    }
    ss << ">>]";
    return ss.str();
}
/*
 * name: pushAtBack
 * purpose: Add a given character to the back of a list
 * parameters: A character to add
 * return value: none
 * effects: Inserts the given character at the back and updates the size
*/
void CharLinkedList::pushAtBack(char c)
{
    insertAt(c, listSize);
}


/*
 * name: pushAtFront
 * purpose: Add a given character to the front of a list
 * parameters: A character to add
 * return value: none
 * effects: Inserts the given character at the back and updates the size
*/
void CharLinkedList::pushAtFront(char c)
{
    insertAt(c, 0);
}

/*
 * name: insertAt
 * purpose: Add a given character at a given location
 * parameters: A character to add and a location
 * return value: none
 * effects: Adds the given character at the given location and updates the 
 size
*/
void CharLinkedList::insertAt(char c, int index)
{
    rangeErrorInclusive(index);
    if (isEmpty())
    {
        emptyCaseInsertAt(c);
        return;
    }
    // Inserting at the front
    if (index == 0)
    {
        // Makes the former front point to the new front
        front->prev = newNode(nullptr, front, c);
        front = front->prev;
    }
    else if (index == listSize)
    {
        back->next = newNode(back, nullptr, c);
        back = back->next;
    }
    else
    {
        int currIndex = 0;
        CharLinkedList::Node *curr = front;
        while(currIndex < index - 1)
        {
            curr = curr->next;
            currIndex++;
        }
        curr->next = newNode(curr, curr->next, c); 
    }
    listSize++;
}

/*
 * name: insertInOrder
 * purpose: Insert an element into a list in ASCII order at the first 
 correct index
 * parameters: The character to insert
 * return value: none
 * effects: Increases the list's size, inserts the element at the correct 
 index, updates front and back pointers if needed
*/
void CharLinkedList::insertInOrder(char c)
{
    // c can be inserted anywhere in between index 0 and the back
    for (int i = 0; i <= listSize; i++)
    {
        // If the only spot for c is the back, there is no need to compare it
        if (i == listSize)
        {
            insertAt(c, i);
            return;
        }
        // c can be inserted at i if it comes before or is equal to the 
        // already present element 
        else if (c <= elementAt(i))
        {
            insertAt(c, i);
            return;
        }
        else
        {
            continue;
        }
    }
}
/*
 * name: popFromFront
 * purpose: Remove the character at the front
 * parameters: none
 * return value: none
 * effects: Deletes the character at the front, makes the nodes before
 and after it point to each other, updates the front and back pointers
*/
void CharLinkedList::popFromFront()
{
    if (isEmpty())
    {
        throw std::runtime_error("cannot pop from empty LinkedList");
    }
    removeAt(0);
}

/*
 * name: popFromBack
 * purpose: Remove the character at the back
 * parameters: none
 * return value: none
 * effects: Deletes the character at the back, makes the nodes before
 and after it point to each other, updates the front and back pointers
*/
void CharLinkedList::popFromBack()
{
    if (isEmpty())
    {
        throw std::runtime_error("cannot pop from empty LinkedList");
    }
    removeAt(listSize - 1);
}

/*
 * name: removeAt
 * purpose: Remove the character at a given location
 * parameters: A location to remove at
 * return value: none
 * effects: Deletes the character at the given location, makes the nodes before
 and after it point to each other, updates the front and back pointers.
 Updates the list's size.
*/
void CharLinkedList::removeAt(int index)
{
    rangeErrorExclusive(index);
    CharLinkedList::Node *nodeToRemove = findNode(0, index, front);
    if (listSize == 1)
    {
        singletonCaseRemoveAt(nodeToRemove);
    }
    else if (nodeToRemove == front)
    {
        /* Redesignates the next element as the new front*/
        CharLinkedList::Node *newFront = nodeToRemove->next;
        delete nodeToRemove;
        newFront->prev = nullptr;
        front = newFront;
    }
    else if (nodeToRemove == back)
    {
        CharLinkedList::Node *newBack = nodeToRemove->prev;
        delete nodeToRemove;
        newBack->next = nullptr;
        back = newBack;
    }
    else
    {
        /* Makes the next and previous nodes to point to each other */
        CharLinkedList::Node *previousNode = nodeToRemove->prev;
        CharLinkedList::Node *nextNode = nodeToRemove->next;
        nextNode->prev = previousNode;
        previousNode->next = nextNode;
        delete nodeToRemove;
    }
    listSize--;
}

/*
 * name: replaceAt
 * purpose: Replace the character at a given location with another character
 * parameters: A character to insert and a location to insert at
 * return value: none
 * effects: Changes the element at the given index to the new character
*/
void CharLinkedList::replaceAt(char c, int index)
{
    rangeErrorExclusive(index);
    CharLinkedList::Node *nodeToReplace = findNode(0, index, front);
    nodeToReplace->element = c;
}

/*
 * name: concatenate
 * purpose: Combine the contents of 2 LinkedLists into 1
 * parameters: The location in memory of another LinkedList
 * return value:
 * effects: Creates a new deep copy of the given list with a size equal to 
 the combined one of the 2 lists, with the contents being identical to the
lists. The contents of the list the function is called on go right before 
those of the parameter. 
*/
void CharLinkedList::concatenate(CharLinkedList *other)
{
    /* other's size is placed in a variable to avoid an infinite loop
    during self concatenation*/
    int otherSize = other->size();
    
    for (int i = 0; i < otherSize; i++)
    {
        pushAtBack(other->elementAt(i));       
    }
}
/*
 * PRIVATE FUNCTIONS
*/

/*
 * name: newNode
 * purpose: Creates a new Node with the specified parameters
 * parameters: The location of the nodes that are directly before and after
 the new Node and the character to insert
 * return value: Returns a fully initialized Node
 * effects: Creates a new Node on the heap 
*/
CharLinkedList::Node *CharLinkedList::newNode(Node *insertPrev, 
Node *insertNext, char insertElement)
{
    Node *newNode = new Node;
    newNode->prev = insertPrev;
    newNode->next = insertNext;
    newNode->element = insertElement;

    return newNode;
}


/*
 * name: deleteNodes
 * purpose: Delete all nodes in the LinkedList
 * parameters: The location of the node that will be deleted
 * return value: none
 * effects: Frees memory taken up by each node in the LinkedList. Decrements
 listSize
*/
void CharLinkedList::deleteNodes(CharLinkedList::Node *curr)
{
    if (listSize == 0)
    {
        return;
    }
    else if (listSize == 1)
    {
        deleteNodesSingletonCase(curr);
    }
    else if (curr == back)
    {
        delete curr;
        back = nullptr;
        listSize--;
    }
    else if (curr == front)
    {
        /* Need to store the next value before front is deleted */
        CharLinkedList::Node *next = curr->next;
        delete curr;
        front = nullptr;
        listSize--;
        deleteNodes(next);
    }
    else
    {
        CharLinkedList::Node *next = curr->next;
        delete curr;
        listSize--;
        deleteNodes(next);
    }
}

/*
 * name: deleteNodesSingletonCase
 * purpose: Handles deleteNodes' singleton list case: If the listSize is 1, 
 the only element is deleted. Reduces line count in deleteNodes.
 * parameters: A pointer to the current Node being analyzed in the list
 * return value: none
 * effects: Deletes the only element in the singleton, reassigns front and 
 back to nullptr and updates the size
*/
void CharLinkedList::deleteNodesSingletonCase(Node *curr)
{
    delete curr;
    back = nullptr;
    front = nullptr;
    listSize--;
}

/*
 * name: findNode
 * purpose: Iterate through the LinkedList to find a node at a specified 
 location.
 * parameters: The current index in the list, i1, the desired index in the 
 list, i2 and the current Node in the list
 * return value: The node at the desired location
 * effects: none
*/
CharLinkedList::Node *CharLinkedList::findNode(int i1, int i2, Node* curr) const  
{
    if (i1 == i2)
    {
        return curr;
    }
    return findNode(i1+ 1, i2, curr->next);
}

/*
 * name: rangeErrorInclusive
 * purpose: Throw a range error if a given index is out of an inclusive range
 * return value: none
 * effects: Error message has a different range, [...] than the range error for 
 functions like removeAt, [...)
*/
void CharLinkedList::rangeErrorInclusive(int index)
{
    stringstream ss;
    ss << "index (" << index << ") not in range [0.." << listSize << "]";
    if (index > listSize or index < 0)
    {
        throw std::range_error(ss.str());
    }
}

/*
 * name: rangeErrorExclusive
 * purpose: Throw a range error if a given index is out of an exclusive range
 * return value: none
 * effects: Error message has a different range, [...) than the range error for 
 functions like insertAt, [...]
*/
void CharLinkedList::rangeErrorExclusive(int index) const
{
    if (index > listSize - 1 or index < 0)
    {
        stringstream ss;
        ss << "index (" << index << ") not in range [0.." << listSize << ")";
        throw std::range_error(ss.str());
    }
}


/*
 * name: emptyCaseInsertAt
 * purpose: Creates a new Node and assigns the front and back when a value
 is inserted into an empty list with insertAt. Reduces line count.
 * return value: none
 * efffects: Updates the front and back to point to the new Node and updates
 the list's size
*/
void CharLinkedList::emptyCaseInsertAt(char c)
{
    front = newNode(nullptr, nullptr, c);
    back = front;
    listSize++;
}

/*
 * name: singletonCaseRemoveAt
 * purpose: Deletes a Node and reassigns the front and back to nullptr when
 the element in a singleton list is removed with removeAt. Reduces line count.
 * return value: none
 * effects: Frees memory taken up by a Node and reassigns the front and back
 pointers to nullptr.
*/
void CharLinkedList::singletonCaseRemoveAt(Node *nodeToRemove)
{
    delete nodeToRemove;
    front = nullptr;
    back = nullptr;
}
/*
 *  CharLinkedList.cpp
 *  Benson Jiang
 *  2/1/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  The purpose of this file is to define the implementation of the 
 *  CharArrayList class. The details of each function is defined in the 
 *  function contract below above every function.
 *
 */

#include "CharLinkedList.h"
#include <string>
#include <stdexcept>

/*
 * name:      CharLinkedList
 * purpose:   To define the default constructor for CharLinkedList
 * arguments: None
 * returns:   None
 * effects:   Initializes the needed values 
 */
CharLinkedList::CharLinkedList(){
    front = nullptr;
    listSize = 0;
}

/*
 * name:      ~CharLinkedList
 * purpose:   To define the destructor for CharLinkedList
 * arguments: None
 * returns:   None
 * effects:   Frees any allocated memory off the heap
 */
CharLinkedList::~CharLinkedList(){
    destructorHelper(front); 
}

/*
 * name:      destructorHelper
 * purpose:   To help dealloacte memory recursively
 * arguments: None
 * returns:   None
 * effects:   Frees any allocated memory off the heap
 */
void CharLinkedList::destructorHelper(Node *node){
    if(node == nullptr){ //Base case for the deletion
        return;
    }
    else{
        Node *temp = node;
        destructorHelper(node->next);
        delete temp;
    }
}



/*
 * name:      CharLinkedList with one char
 * purpose:   To define the constructor for CharLinkedList with one char
 * arguments: The character to insert into the list
 * returns:   None
 * effects:   Initializes the needed values and creates a node with the data
 */
CharLinkedList::CharLinkedList(char c){
    front = new Node(); //Initializes the values and the pointers by creating
    front->data = c; // one node
    front->next = nullptr;
    front->prev = nullptr;
    listSize = 1;
}


/*
 * name:      CharLinkedList with a string
 * purpose:   To define the constructor for CharLinkedList with a string
 * arguments: The characters to insert into the list
 * returns:   None
 * effects:   Initializes the needed values and create nodes with the data
 */
CharLinkedList::CharLinkedList(char arr[], int size){
    front = nullptr;
    listSize = 0;
    //Iterates through the array to copy the elements over
    for(int i = 0; i < size; i++){
        pushAtBack(arr[i]); 
    }
}

/*
 * name:      CharLinkedList Deep Copy
 * purpose:   To define the constructor for deep copy CharLinkedList 
 * arguments: The CharLinkedList object to be copied
 * returns:   None
 * effects:   Initializes the needed values and create nodes with the data from
 *            the other linked list
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other){
    front = nullptr;
    listSize = 0;
    //Iterates through the other linked list to copy the elements over
    for(int i = 0; i < other.size(); i++){
        pushAtBack(other.elementAt(i)); 
    }

}

/*
 * name:      CharLinkedList Deep Copy
 * purpose:   To define the constructor for deep copy CharLinkedList 
 * arguments: The CharLinkedList object to be copied
 * returns:   None
 * effects:   Initializes the needed values and create nodes with the data from
 *            the other linked list
 */
CharLinkedList& CharLinkedList::operator=(const CharLinkedList &other){
    if(this == &other){
        return *this;
    }
    //Resets the current linked list then copies over the elements from the
    //other linked list
    clear();
    int size = other.size();
    for(int i = 0; i < size; i++){
        pushAtBack(other.elementAt(i));
    }
    return *this;
}

/*
 * name:      isEmpty
 * purpose:   To find if the linkedlist is empty
 * arguments: None
 * returns:   The boolean value of whether or not the linked list is empty
 * effects:   None
 */
bool CharLinkedList::isEmpty() const{
    if(listSize == 0){
        return true;
    }
    return false;
}


/*
 * name:      size
 * purpose:   To find the size of the current linked list
 * arguments: None
 * returns:   The integer value of the linked list 
 * effects:   None
 */
int CharLinkedList::size() const{
    if(isEmpty()){
        return 0;
    }
    return listSize;
}

/*
 * name:      first
 * purpose:   To find the first element of the current linked list
 * arguments: None
 * returns:   The character value of the linked list at index 0 if any
 * effects:   None
 */
char CharLinkedList::first() const{
    if(isEmpty()){
        throw std::runtime_error("cannot get first of empty LinkedList");
    }
    return front->data;

}

/*
 * name:      last
 * purpose:   To find the last element of the current linked list
 * arguments: None
 * returns:   The character value of the linked list at index size-1 if any
 * effects:   None
 */
char CharLinkedList::last() const{
    if(isEmpty()){
        throw std::runtime_error("cannot get last of empty LinkedList");
    }
    //Iterates to the end of the linked list
    return elementAt(listSize - 1);
}

/*
 * name:      elementAt
 * purpose:   To find the element of the current linked list given an index
 * arguments: The index of the desired character
 * returns:   The character from the linked list at index if any
 * effects:   None
 */
char CharLinkedList::elementAt(int index) const{
    if(index < 0 or index >= listSize){
        std::string idx = std::to_string(index);
        std::string size = std::to_string(listSize);
        std::string message = "index (" + idx + ") not in range [0.." + size;
        message = message + ")";
        throw std::range_error(message);
    }
    return elementAtHelper(front, index);
}

/*
 * name:      elementAtHelper
 * purpose:   To find the element recursively
 *            of the current linked list given an index
 * arguments: The index of the desired character
 * returns:   The character from the linked list at index if any
 * effects:   None
 */
char CharLinkedList::elementAtHelper(Node *current, int index) const {
    if (index == 0) {
        return current->data;
    } else { //This reduces the index by one when we go to the next Node
        return elementAtHelper(current->next, index - 1);
    }
}


/*
 * name:      toString
 * purpose:   To print the characters stored in the linked list
 * arguments: None
 * returns:   A string containing the size and characters of the linked list
 * effects:   None
 */
std::string CharLinkedList::toString() const{
    std::string word = "";
    std::string size = std::to_string(listSize);
    for(int i = 0; i < listSize; i++){
        word += elementAt(i);
    }
    
    return "[CharLinkedList of size " + size + " <<" + word + ">>]";
}

/*
 * name:      toReverseString
 * purpose:   To print the characters stored in the linked list reversed
 * arguments: None
 * returns:   A reversed string containing the size and characters 
 *            of the linked list
 * effects:   None
 */
std::string CharLinkedList::toReverseString() const{
    std::string word = "";
    std::string size = std::to_string(listSize);
    for(int i = listSize - 1; i >= 0; i--){
        word += elementAt(i);
    }
    
    return "[CharLinkedList of size " + size + " <<" + word + ">>]";
}

/*
 * name:      insertAt
 * purpose:   To insert a character at the desrired index
 * arguments: The index of the desired character and the character
 * returns:   None
 * effects:   Inserts a character and shifts the rest of the chars down one
 */
void CharLinkedList::insertAt(char c, int index){
    if(index < 0 or index > listSize){
        std::string idx = std::to_string(index);
        std::string size = std::to_string(listSize);
        std::string message = "index (" + idx + ") not in range [0.." + size;
        message = message + "]";
        throw std::range_error(message);
    }
    if(index == 0){//Edge case: sets the first char to the inputted char
        pushAtFront(c); // this ensures that if the list is empty one is made
    }
    else if(index == listSize){//Edge case: sets the last char to the inputted 
        pushAtBack(c);//char this ensures that if the list is empty one is made
    }
    else{//Finds the current indexed node then creates a new Node to point
        Node *temp = nodeAt(index);// to the current prev and next pointers
        Node *newNode = new Node();// then the new node is in front of the 
        newNode->data = c; // old current node.
        newNode->next = temp;
        newNode->prev = temp->prev;
        temp->prev = newNode;
        temp = temp->prev->prev;
        temp->next = newNode;
        listSize++;
    }
}

/*
 * name:      nodeAt
 * purpose:   To return the node at a given index
 * arguments: The index of the desired Node
 * returns:   The Node at the inputed index
 * effects:   None
 */
CharLinkedList::Node* CharLinkedList::nodeAt(int index) const{
    Node *temp = front;
    for(int i = 0; i < index; i++){
        temp = temp->next;
    }
    return temp;
}


/*
 * name:      pushAtBack
 * purpose:   To insert a character at the back of the linked list
 * arguments: The character to be inserted
 * returns:   None
 * effects:   Adds a character to a Node to the end of the linked list
 */
void CharLinkedList::pushAtBack(char c){
    Node *newNode = new Node();
    newNode->data = c;
    newNode->next = nullptr;
    if(listSize == 0){ //Initializes a new linked list if there is not one
        front = newNode;
        front->prev = nullptr;
    }
    else{//Iterate to the end and push the new node
        Node *temp = nodeAt(listSize - 1);
        temp->next = newNode;
        newNode->prev = temp;
    }
    listSize++;
}

/*
 * name:      pushAtFront
 * purpose:   To insert a character at the front of the linked list
 * arguments: The character to be inserted
 * returns:   None
 * effects:   Adds a character to a Node to the front of the linked list
 */
void CharLinkedList::pushAtFront(char c){
    Node *newNode = new Node();
    newNode->data = c;
    newNode->prev = nullptr;
    if(listSize == 0){ //Initializes a new linked list
        front = newNode;
        front->next = nullptr;
    }
    else{ //Adds to the front of the list by repointer pointers
        newNode->next = front;
        front->prev = newNode; // Set the prev pointer of the old front node
        front = newNode;
    }
    listSize++;
}


/*
 * name:      clear
 * purpose:   To clear the linked list's Nodes and its elements
 * arguments: None
 * returns:   None
 * effects:   Dealloactes the heap memory in use and resets the linked list
 */
void CharLinkedList::clear(){
    destructorHelper(front);
    front = nullptr;
    listSize = 0;
}

/*
 * name:      popFromFront
 * purpose:   To remove the first element in the linked list
 * arguments: None
 * returns:   None
 * effects:   Removes the first element and reassigns the 
 *            pointers pointed towards it
 */
void CharLinkedList::popFromFront(){
    if(isEmpty()){
        throw std::runtime_error("cannot pop from empty LinkedList");
    }
    Node *temp = front;
    front = front->next;
    if(front != nullptr) { // Check if the list is not empty after popping
        front->prev = nullptr;
    }
    delete temp;
    listSize--;
}

/*
 * name:      popFromBack
 * purpose:   To remove the last element in the linked list
 * arguments: None
 * returns:   None
 * effects:   Removes the last element and reassigns the 
 *            pointers pointed towards it
 */
void CharLinkedList::popFromBack(){
    if(isEmpty()){
        throw std::runtime_error("cannot pop from empty LinkedList");
    }
    Node *temp = nodeAt(listSize - 1);
    if(temp->prev != nullptr) { //Checks to see if there is only one element
        Node *tempPrev = temp->prev;
        tempPrev->next = nullptr;
    }
    else {
        front = nullptr; // If there's only one node, set front to nullptr
    }
    delete temp;
    listSize--;
}

/*
 * name:      insertInOrder
 * purpose:   To insert a character into the linked list based on ASCII values
 * arguments: The character to be inserted
 * returns:   None
 * effects:   Adds the element to the right index in the linked list.
 */
void CharLinkedList::insertInOrder(char c){
    for(int i = 0; i < listSize; i++){
        if(c <= nodeAt(i)->data){//Compares ascii value and if it is <= then 
            insertAt(c,i);// inserts and returns
            return;
        }
    }
    pushAtBack(c);
}


/*
 * name:      removeAt
 * purpose:   To remove the character at an index
 * arguments: The index of the character in the linked list to be deleted
 * returns:   None
 * effects:   Removes the element at the index in the linked list.
 */
void CharLinkedList::removeAt(int index){
    if(index < 0 or index >= listSize){
        std::string idx = std::to_string(index);
        std::string size = std::to_string(listSize);
        std::string message = "index (" + idx + ") not in range [0.." + size;
        message = message + ")";
        throw std::range_error(message);
    }
    if(index == 0){//Edge case:removes first node
        popFromFront();
    }
    else if(index == listSize - 1){
        popFromBack();//Last node removed
    }
    else{
        Node *temp = nodeAt(index);
        Node *tempPrev = temp->prev; //Stores the to be deleted variable
        tempPrev->next = temp->next; // and repoints pointers
        temp->next->prev = tempPrev;
        delete temp;
        listSize--;
    }
}

/*
 * name:      replaceAt
 * purpose:   To replace a the current character with a new one at a given
 *            index 
 * arguments: The character to be inserted and the index
 * returns:   None
 * effects:   Replaces the element at the right index in the linked list
 *            with a given character
 */
void CharLinkedList::replaceAt(char c, int index){
    if(index < 0 or index >= listSize){
        std::string idx = std::to_string(index);
        std::string size = std::to_string(listSize);
        std::string message = "index (" + idx + ") not in range [0.." + size;
        message = message + ")";
        throw std::range_error(message);
    }
    Node *temp = front;
    replaceAtHelper(temp, index, c);
}

/*
 * name:      replaceAtHelper
 * purpose:   To replace a the current character with a new one at a given
 *            index 
 * arguments: The character to be inserted and the index
 * returns:   None
 * effects:   Replaces the element at the right index in the linked list
 *            with a given character
 */
void CharLinkedList::replaceAtHelper(Node *current, int index, char c){
    // If the index is 0, we've reached the node we're looking for, so
    //replace the element
    if(index == 0){
        current->data = c;
        return;
    }
    // Otherwise, recursively call the function on the next node, decrementing
    //the index
    else{
        replaceAtHelper(current->next, index - 1, c);
    }
}

/*
 * name:      concatenate
 * purpose:   To append an linked list to the current one
 * arguments: The linked list to be inserted 
 * returns:   None
 * effects:   Changes the linked list elements
 */
void CharLinkedList::concatenate(CharLinkedList *other){
    int size = other->size();
    for(int i = 0; i < size; i++){
        pushAtBack(other->elementAt(i));
    }
}

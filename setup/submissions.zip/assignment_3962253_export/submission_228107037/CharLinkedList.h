/*
 *  CharLinkedList.h
 *  Benson Jiang
 *  2/1/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Purpose: The CharLinkedList class consists of the list ADT operations but
 *  it is implemented using a linked list data structure. Since this class
 *  is implemeneted using a linked list structure then the insertion and
 *  deletion operations are inexpensive while locating elements may be more
 *  costly. The client is able to create 4 different types of the classes 
 *  when first calling it. Then the client is able to utlize the list
 *  ADT operations since the class expands based on the inputs.
 *
 */

#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H

#include <string>

class CharLinkedList {
    public:
        //Constructors
        CharLinkedList();
        CharLinkedList(char c);
        CharLinkedList(char arr[], int size);
        CharLinkedList(const CharLinkedList &other);

        ~CharLinkedList();

        CharLinkedList &operator=(const CharLinkedList &other);

        //Getters
        int size() const;
        char first() const;
        char last() const;
        char elementAt(int index) const;
        std::string toString() const;
        std::string toReverseString() const;

        //Setters
        bool isEmpty() const;
        void clear();
        void pushAtBack(char c);
        void pushAtFront(char c);
        void insertAt(char c, int index);
        void insertInOrder(char c);
        void popFromFront();
        void popFromBack();
        void removeAt(int index);
        void replaceAt(char c, int index);
        void concatenate(CharLinkedList *other);


    private:
        struct Node{
            Node* next;
            Node* prev;
            char data;
        };

        Node* front;
        int listSize;
        void destructorHelper(Node *node);
        char elementAtHelper(Node *current, int index) const;
        Node* nodeAt(int index) const;
        void replaceAtHelper(Node *current, int index, char c);

};

#endif

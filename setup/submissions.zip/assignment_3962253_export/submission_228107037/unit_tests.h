/*
 *  unit_tests.h
 *  Benson Jiang
 *  2/1/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  Purpose: The purpose of this file is to comphrensively test all the 
 *  functions created in the CharLinkedList class. These test are modular
 *  and consist of testing a specific funcitonality of the function such as
 *  errors or desired outcome.
 *
 */

#include "CharLinkedList.h"
#include <cassert>


// This checks the default constructor
void defaultCharLinkedList(){
    CharLinkedList list;
}

// This checks the one character constructor
void charLinkedListOneChar(){
    CharLinkedList list('z');
}

// This checks the string constructor
void charLinkedListString(){
    CharLinkedList list("zamboni",7);
}

// This checks if the default constructor is initialized right
void emptyDefault(){
    CharLinkedList list;
    assert(list.isEmpty());
}

// This checks if the one char constructor is initialized right
void emptyOneChar(){
    CharLinkedList list('z');
    assert(not list.isEmpty());
}

// This checks if the string constructor is initialized right
void emptyMulitChar(){
    CharLinkedList list("zamboni",7);
    assert(not list.isEmpty());
}

// This checks if the size function works for different types
void sizeTest(){
    CharLinkedList list;
    assert(list.size() == 0);
    CharLinkedList list1('z');
    assert(list1.size() == 1);
    CharLinkedList list2("zamboni",7);
    assert(list2.size() == 7);
}

// Checks to see if the first character is right
void firstTest(){
    CharLinkedList list1('z');
    assert(list1.first() == 'z');
    CharLinkedList list2("zamboni",7);
    assert(list2.first() == 'z');
}

// Checks the runtime error on the first function
void firstErrorTest(){
    CharLinkedList list;
    std::string errMessage = "";
    try{
        list.first();
    }
    catch(const std::runtime_error &e){
        errMessage = e.what();
    }
    assert(errMessage == "cannot get first of empty LinkedList");
}

//Checks the last function
void lastTest(){
    CharLinkedList list("Jack",4);
    assert(list.last() == 'k');
    CharLinkedList list1('z');
    assert(list1.last() == 'z');
}

// Checks the runtime error on the last function
void lastErrorTest(){
    CharLinkedList list;
    std::string errMessage = "";
    try{
        list.last();
    }
    catch(const std::runtime_error &e){
        errMessage = e.what();
    }
    assert(errMessage == "cannot get last of empty LinkedList");
}

//Checks the elementAt function with a basic test
void elementAtTest(){
    CharLinkedList list("Jack",4);
    assert(list.elementAt(2) == 'c');
}

// Tests correct insertion into an empty AL.
// Afterwards, size should be 1 and element at index 0
// should be the element we inserted.
void insertAt_empty_correct() { 

    CharLinkedList list;
    list.insertAt('a', 0);
    assert(list.size() == 1);
    assert(list.elementAt(0) == 'a');

} 

// Tests incorrect insertion into an empty AL.
// Attempts to call insertAt for index larger than 0.
// This should result in an std::range_error being raised.
void insertAt_empty_incorrect() {

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList list;
    try {
    // insertAt for out-of-range index
    list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
    // if insertAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    range_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0]");
    
}

// // Tests correct insertAt for front of 1-element list.
void insertAt_front_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList list('a');

    // insert at front
    list.insertAt('b', 0);

    assert(list.size() == 2);
    assert(list.elementAt(0) == 'b');
    assert(list.elementAt(1) == 'a');
    
}

// // Tests correct insertAt for back of 1-element list.
void insertAt_back_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList list('a');

    // insert at back
    list.insertAt('b', 1);

    assert(list.size() == 2);
    assert(list.elementAt(0) == 'a');
    assert(list.elementAt(1) == 'b');
    
}

// // Tests calling insertAt for a large number of elements.
// // Not only does this test insertAt, it also checks that
// // expansion works correctly.
void insertAt_many_elements() {
    
    CharLinkedList list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        list.insertAt('a', i);
    }

    assert(list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(list.elementAt(i) == 'a');
    }
    
}

// // Tests insertion into front of a larger list
void insertAt_front_large_list() {
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList list(test_arr, 9);

    list.insertAt('y', 0);

    assert(list.size() == 10);
    assert(list.elementAt(0) == 'y');
    assert(list.toString() == "[CharLinkedList of size 10 <<yabczdefgh>>]");

}

// // Tests insertion into the back of a larger list
void insertAt_back_large_list() {

    char test_arr[10] = { 'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList list(test_arr, 10);  

    list.insertAt('x', 10);

    assert(list.size() == 11);
    assert(list.elementAt(10) == 'x');
    assert(list.toString() == 
    "[CharLinkedList of size 11 <<yabczdefghx>>]"); 

}

// // Tests insertion into the middle of a larger list
void insertAt_middle_large_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList list(test_arr, 8);

    list.insertAt('z', 3);

    assert(list.size() == 9);
    assert(list.elementAt(3) == 'z');
    assert(list.toString() ==   "[CharLinkedList of size 9 <<abczdefgh>>]");

}

// // // Tests out-of-range insertion for a non-empty list.
void insertAt_nonempty_incorrect() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8]");
    
}




// Tests when the linked list is initialized to a null pointer 
// Pushes a character to the back of the linked list and checks if it alters
// the size and content of the linked list
void pushEmptyBackTest(){
    CharLinkedList test_list;
    test_list.pushAtBack('q');
    assert(test_list.size() == 1);
    assert(test_list.toString() == "[CharLinkedList of size 1 <<q>>]");
}

// Tests when the linked list is initialized to multiple characters
// Pushes a character to the back of the linked list and checks if it alters
// the size and content of the linked list
void pushMultiBackTest(){
    CharLinkedList test_list("pushy", 5);
    test_list.pushAtBack('q');
    assert(test_list.size() == 6);
    assert(test_list.toString() == "[CharLinkedList of size 6 <<pushyq>>]");
}

// Tests when the linked list is initialized to a one character
// Pushes a character to the back of the linked list and checks if it alters
// the size and content of the linked list
void pushOneBackTest(){
    CharLinkedList test_list('p');
    test_list.pushAtBack('q');
    assert(test_list.size() == 2);
    assert(test_list.toString() == "[CharLinkedList of size 2 <<pq>>]");
}

// Tests when the linked list is initialized to a null pointer 
// Pushes a character to the front of the linked list and checks if it alters
// the size and content of the linked list
void pushEmptyFrontTest(){
    CharLinkedList test_list;
    test_list.pushAtFront('q');
    assert(test_list.size() == 1);
    assert(test_list.toString() == "[CharLinkedList of size 1 <<q>>]");
}

// Tests when the linked list is initialized to a one character
// Pushes a character to the front of the linked list and checks if it alters
// the size and content of the linked list
void pushOneFrontTest(){
    CharLinkedList test_list('J');
    test_list.pushAtFront('J');
    assert(test_list.size() == 2);
    assert(test_list.toString() == "[CharLinkedList of size 2 <<JJ>>]");
}

// Tests when the linked list is initialized to multiple characters 
// Pushes a character to the front of the linked list and checks if it alters
// the size and content of the linked list
void pushMultiFrontTest(){
    CharLinkedList test_list("Ha", 2);
    test_list.pushAtFront('K');
    assert(test_list.size() == 3);
    assert(test_list.toString() == "[CharLinkedList of size 3 <<KHa>>]");
}

void clearTest(){
    CharLinkedList test_list("Hello", 5);
    assert(not test_list.isEmpty());
    test_list.clear();
    assert(test_list.isEmpty());
    assert(test_list.toString() == "[CharLinkedList of size 0 <<>>]");
}

// Tests the removal of an element from the front of the linked list and raises
// an error if the linked list is empty
void popFromFrontError(){
    CharLinkedList test_list("John",4);
    CharLinkedList test_list2;
    test_list.popFromFront();
    std::string errMessage = "";
    try{
        test_list.elementAt(4);
    } catch (const std::range_error &e){
        errMessage = e.what();
    }
    assert(errMessage == "index (4) not in range [0..3)");

    try{
        test_list2.popFromFront();
    } catch(const std::runtime_error &e){
        errMessage = e.what();
    }
    assert(errMessage == "cannot pop from empty LinkedList");
}

void popFromFront(){
    CharLinkedList test_list("Jack", 4);
    test_list.popFromFront();
    assert(test_list.toString() == "[CharLinkedList of size 3 <<ack>>]");
}

// Tests the removal of an element from the front of the linked list and raises
// an error if the linked list is empty
void popFromBackError(){
    CharLinkedList test_list("John",4);
    CharLinkedList test_list2;
    test_list.popFromBack();
    std::string errMessage = "";
    try{
        test_list.elementAt(4);
    } catch (const std::range_error &e){
        errMessage = e.what();
    }
    assert(errMessage == "index (4) not in range [0..3)");

    try{
        test_list2.popFromBack();
    } catch(const std::runtime_error &e){
        errMessage = e.what();
    }
    assert(errMessage == "cannot pop from empty LinkedList");
}

void popFromBack(){
    CharLinkedList test_list("Jack", 4);
    test_list.popFromBack();
    assert(test_list.toString() == "[CharLinkedList of size 3 <<Jac>>]");
}


/*** InsertInOrder Function ***/

// Tests ordered insertion if there is no array
void insertInOrderNoList(){
    CharLinkedList test_list;
    test_list.insertInOrder('a');
    assert(test_list.toString() == "[CharLinkedList of size 1 <<a>>]");
}

// Tests ordered insertion if there is one element
void insertInOrderOneElement(){
    CharLinkedList test_list('p');
    test_list.insertInOrder('a');
    assert(test_list.toString() == "[CharLinkedList of size 2 <<ap>>]");
}

// Tests ordered insertion in the middle of the linked list
void insertInOrderMiddle(){
    CharLinkedList test_list("ABCDD",5);
    test_list.insertInOrder('C');
    assert(test_list.toString() == "[CharLinkedList of size 6 <<ABCCDD>>]");
}

// Tests ordered insertion at the back 
void insertInOrderBack(){
    CharLinkedList test_list("ABCCDD",6);
    test_list.insertInOrder('P');
    assert(test_list.toString() == "[CharLinkedList of size 7 <<ABCCDDP>>]");
}

// Tests ordered insertion with multiple elements
void insertInOrderMulti(){
    CharLinkedList test_list("ABCCDD",6);
    test_list.insertInOrder('P');
    test_list.insertInOrder('Z');
    test_list.insertInOrder('A');
    test_list.insertInOrder('D');
    assert(test_list.toString() =="[CharLinkedList of size 10 <<AABCCDDDPZ>>]");
}

// Tests if the formatting of the reverse prints are correct
void toReverseStringTest(){
    CharLinkedList test_list("Hello", 5);
    CharLinkedList test_list2;
    std::string message = "[CharLinkedList of size 5 <<olleH>>]";
    assert(test_list.toReverseString() == message);
    assert(test_list2.toReverseString() == "[CharLinkedList of size 0 <<>>]");
}

/*****  Remove at Function  *****/

// Remove at index 0
void removeAtFront(){
    CharLinkedList test_list("Mimsi", 5);
    test_list.removeAt(0);
    assert(test_list.toString() == "[CharLinkedList of size 4 <<imsi>>]");
}

// Removes in middle of a string
void removeAtMiddle(){
    CharLinkedList test_list("Mimsi", 5);
    test_list.removeAt(3);
    assert(test_list.toString() == "[CharLinkedList of size 4 <<Mimi>>]");
    test_list.removeAt(3);
    assert(test_list.toString() == "[CharLinkedList of size 3 <<Mim>>]");
}

// Same fucntionality as popback
void removeAtEnd(){
    CharLinkedList test_list("Mimsi", 5);
    test_list.removeAt(4);
    assert(test_list.toString() == "[CharLinkedList of size 4 <<Mims>>]");
}


void removeAtFrontError(){
    CharLinkedList test_list("Nathan", 6);
    std::string errMessage = "";
    try{
        test_list.removeAt(-1);
    } catch(const std::range_error &e){
        errMessage = e.what();
    }
    assert(errMessage == "index (-1) not in range [0..6)");
}

void removeAtEndError(){
    CharLinkedList test_list("Nathan", 6);
    std::string errMessage = "";
    try{
        test_list.removeAt(6);
    } catch(const std::range_error &e){
        errMessage = e.what();
    }
    assert(errMessage == "index (6) not in range [0..6)");
}

/***    ReplaceAt Function ***/

// Given a character and index it replaces the current index's character with
// the given one
void replaceAtFront(){
    CharLinkedList test_list("Nathan", 6);
    test_list.replaceAt('L',0);
    assert(test_list.toString() == "[CharLinkedList of size 6 <<Lathan>>]");
}
// Given a character and index it replaces the current index's character with
// the given one in the middle
void replaceAtMiddle(){
    CharLinkedList test_list("Nathan", 6);
    test_list.replaceAt('h',2);
    assert(test_list.toString() == "[CharLinkedList of size 6 <<Nahhan>>]");
}

// Given a character and index it replaces the current index's character with
// the given one at the end
void replaceAtEnd(){
    CharLinkedList test_list("Nathan", 6);
    test_list.replaceAt('k',5);
    assert(test_list.toString() == "[CharLinkedList of size 6 <<Nathak>>]");
}

// Tests the range error x < 0
void replaceAtFrontError(){
    CharLinkedList test_list("Nathan", 6);
    std::string errMessage = "";
    try{
        test_list.replaceAt('k',-1);
    } catch(const std::range_error &e){
        errMessage = e.what();
    }
    assert(errMessage == "index (-1) not in range [0..6)");
}

// Tests the range error x > SIZE
void replaceAtEndError(){
    CharLinkedList test_list("Nathan", 6);
    std::string errMessage = "";
    try{
        test_list.replaceAt('k',7);
    } catch(const std::range_error &e){
        errMessage = e.what();
    }
    assert(errMessage == "index (7) not in range [0..6)");
}


// Tests the concatenation given two, SIZE > 0, length arrays
void concatenateTest(){
    CharLinkedList test_list("cat",3);
    CharLinkedList test_list2("CHESIREs",8);
    test_list.concatenate(&test_list2);
    std::string message = "[CharLinkedList of size 11 <<catCHESIREs>>]";
    assert(test_list.toString() == message);
}

// Tests the concatenation given the first array list is empty
void concatenateEmptyFirst(){
    CharLinkedList test_list;
    CharLinkedList test_list2("cat",3);
    test_list.concatenate(&test_list2);
    assert(test_list.toString() == "[CharLinkedList of size 3 <<cat>>]");
}

// Tests the concatenation given the second array list is empty
void concatenateEmptySecond(){
    CharLinkedList test_list("cats",4);
    CharLinkedList test_list2;
    test_list.concatenate(&test_list2);
    assert(test_list.toString() == "[CharLinkedList of size 4 <<cats>>]");
}
// Tests the concatenation given the the same array list
void concatenateSelf(){
    CharLinkedList test_list("cats",4);
    test_list.concatenate(&test_list);
    assert(test_list.toString() == "[CharLinkedList of size 8 <<catscats>>]");
}

void popFromFrontEmpty(){
    CharLinkedList list('z');
    list.popFromFront();
    assert(list.size() == 0);
}

void popFromBackEmpty(){
    CharLinkedList list('z');
    list.popFromBack();
    assert(list.size() == 0);
}

// Tests the deep copy constructor with an empty linked list
void constructDeepEmpty(){
    CharLinkedList test_list;
    CharLinkedList test_list2(test_list);
    assert(test_list2.toString() == "[CharLinkedList of size 0 <<>>]");
}

// Tests the deep copy constructor with an one char linked list
void constructDeepOne(){
    CharLinkedList test_list('l');
    CharLinkedList test_list2(test_list);
    test_list.clear();
    assert(test_list2.toString() == "[CharLinkedList of size 1 <<l>>]");
}

// Tests the deep copy constructor with a multi char linked list
void constructDeepMulti(){
    CharLinkedList test_list("loops",5);
    CharLinkedList test_list2(test_list);
    test_list.clear();
    assert(test_list2.toString() == "[CharLinkedList of size 5 <<loops>>]");
}

// Test to see insertion errors after clear
void insertionAfterClear(){
    CharLinkedList test_list("Hello",5);
    test_list.clear();
    test_list.insertAt('w',0);
    std::string errMessage = "";
    assert(test_list.toString() == "[CharLinkedList of size 1 <<w>>]");
    try{
        test_list.insertAt('q',2);
    } catch(const std::range_error &e){
        errMessage = e.what();
    }
    assert(errMessage == "index (2) not in range [0..1]");
}

// Test to see deletion errors after clear
void deletionAfterClear(){
    CharLinkedList test_list("Hello",5);
    test_list.clear();
    std::string errMessage = "";
    try{
        test_list.removeAt(2);
    } catch(const std::range_error &e){
        errMessage = e.what();
    }
    assert(errMessage == "index (2) not in range [0..0)");
}

//Test to see elementAt errors given invalid indexes
void elementAtEndAndStartError(){
    CharLinkedList test_list("Hello",5);
    std::string errMessage = "";
    try{
        test_list.elementAt(5);
    } catch(const std::range_error &e){
        errMessage = e.what();
    }
    assert(errMessage == "index (5) not in range [0..5)");
    try{
        test_list.elementAt(-1);
    } catch(const std::range_error &e){
        errMessage = e.what();
    }
    assert(errMessage == "index (-1) not in range [0..5)");
}

//Test to see removeAt errors given invalid indexes
void removeAtEndAndStartError(){
    CharLinkedList test_list("Hello",5);
    std::string errMessage = "";
    try{
        test_list.removeAt(-1);
    } catch(const std::range_error &e){
        errMessage = e.what();
    }
    assert(errMessage == "index (-1) not in range [0..5)");
    try{
        test_list.removeAt(5);
    } catch(const std::range_error &e){
        errMessage = e.what();
    }
    assert(errMessage == "index (5) not in range [0..5)");

}
//Test to see replaceAt errors given invalid indexes
void replaceAtEndAndStartError(){
    CharLinkedList test_list("Hello",5);
    std::string errMessage = "";
    try{
        test_list.replaceAt('o',-1);
    } catch(const std::range_error &e){
        errMessage = e.what();
    }
    assert(errMessage == "index (-1) not in range [0..5)");
    try{
        test_list.replaceAt('3',5);
    } catch(const std::range_error &e){
        errMessage = e.what();
    }
    assert(errMessage == "index (5) not in range [0..5)");
}


// Tests the assignment operator given a null second linked list
void assignmentNull(){
    CharLinkedList test_list("cats",4);
    CharLinkedList test_list2;
    test_list = test_list2;
    assert(test_list.toString() == "[CharLinkedList of size 0 <<>>]");
}

// Tests the assignment operator given a one char second linked list
void assignmentOneChar(){
    CharLinkedList test_list("cats",4);
    CharLinkedList test_list2('p');
    test_list = test_list2;
    assert(test_list.toString() == "[CharLinkedList of size 1 <<p>>]");
}

// Tests the assignment operator given a multi char second linked list
void assignmentMultiChar(){
    CharLinkedList test_list("cats",4);
    CharLinkedList test_list2("ewwws",5);
    test_list = test_list2;
    assert(test_list.toString() == "[CharLinkedList of size 5 <<ewwws>>]");
}

// Tests the assignment operator given the same linked list
void assignmentSelf(){
    CharLinkedList test_list("cats",4);
    test_list = test_list;
    assert(test_list.toString() == "[CharLinkedList of size 4 <<cats>>]");
}

//Tests clear on an empty list
void clearEmpty(){
    CharLinkedList test_list;
    test_list.clear();
}

//Concatenates two empty lists
void catTwoEmpty(){
    CharLinkedList test_list;
    CharLinkedList test_list1;
    test_list.concatenate(&test_list1);
    assert(test_list.toString() == "[CharLinkedList of size 0 <<>>]");
}


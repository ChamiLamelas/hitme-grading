/*
 *  unit_tests.h
 *  Khoa T. Nguyen
 *  DATE CREATED
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  Purpose: Tests all the functions implemented for many edge cases
 *
 */

#include <cassert>
#include <iostream>

using namespace std;

#include "CharLinkedList.h"

//test the default constructor
void default_constructor(){
    CharLinkedList list;
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}

//test the single character constructor
void single_char_constructor(){
    CharLinkedList list = CharLinkedList('a');
    assert(list.toString() == "[CharLinkedList of size 1 <<a>>]");
}

//test the array constructor
void array_char_constructor(){
    char arr[4] = {'a', 'b', 'c', 'd'};
    CharLinkedList list = CharLinkedList(arr, 4);
    assert(list.toString() == "[CharLinkedList of size 4 <<abcd>>]");
}

//test the array constructor with an empty input array
void empty_array_constructor(){
    char arr[0] = {};
    CharLinkedList list = CharLinkedList(arr, 0);
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
    assert(list.isEmpty());
}

//test the copy constructor with a non-empty LL
void copy_constructor_nonEmpty(){
    char arr[4] = {'a', 'b', 'c', 'd'};
    CharLinkedList list = CharLinkedList(arr, 4);
    CharLinkedList copy_list = CharLinkedList(list);
    list.popFromBack();
    assert(copy_list.toString() == "[CharLinkedList of size 4 <<abcd>>]");
}

//test the copy constructor with an empty LL
void copy_constructor_empty(){
    CharLinkedList list;
    CharLinkedList copy_list = CharLinkedList(list);
    assert(copy_list.toString() == "[CharLinkedList of size 0 <<>>]");
}

//test the toString function
void toString_test(){
    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list = CharLinkedList(arr, 5);
    assert(list.toString() == "[CharLinkedList of size 5 <<abcde>>]");
}

//test the isEmpty function
void isEmpty_test(){
    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list1 = CharLinkedList(arr, 5);
    assert(not list1.isEmpty());

    CharLinkedList list2;
    assert(list2.isEmpty());
}

//test the clear function
void clear_test(){
    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list = CharLinkedList(arr, 5);
    list.clear();
    assert(list.isEmpty());
    assert(list.size() == 0);
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}

//test the size function
void size_test(){
    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list1 = CharLinkedList(arr, 5);
    assert(list1.size() == 5);

    CharLinkedList list2;
    assert(list2.size() == 0);
}

//test the first function with a non-empty LL
void first_non_empty_test(){
    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list1 = CharLinkedList(arr, 5);
    assert(list1.first() == 'a');
}

//test the error message produced by calling the first function on a
//empty LL
void first_empty_error(){
    bool runtime_error_thrown = false;
    string error_message = "";
    CharLinkedList list1 = CharLinkedList();

    try{
        list1.first();
    }catch(const std::runtime_error &e){
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot get first of empty LinkedList");
}

//test the last function with a non-empty LL
void last_non_empty_test(){
    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list1 = CharLinkedList(arr, 5);
    assert(list1.last() == 'e');
}

//test the error message produced by calling the last function on a
//empty LL
void last_empty_error(){
    bool runtime_error_thrown = false;
    string error_message = "";
    CharLinkedList list1 = CharLinkedList();

    try{
        list1.last();
    }catch(const std::runtime_error &e){
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot get last of empty LinkedList");
}

//test the elementAt function
void element_at_no_eror(){
    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list1 = CharLinkedList(arr, 5);
    assert(list1.elementAt(2) == 'c');
}

//test the error message created by elementAt function when going out of bounds
void element_at_error(){

    bool range_error_thrown = false;
    string error_message = "";

    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list1 = CharLinkedList(arr, 5);

    try{
        list1.elementAt(6);
    }catch(const std::range_error &e){
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (6) not in range [0..5)");
}

//test the error message thrown by elementAt function with an empty LL
void element_at_error_empty(){

    bool range_error_thrown = false;
    string error_message = "";

    CharLinkedList list1;

    try{
        list1.elementAt(6);
    }catch(const std::range_error &e){
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (6) not in range [0..0)");
}

//test the toReverseString function
void toReverseString_test(){
    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list1 = CharLinkedList(arr, 5);
    assert(list1.toReverseString() == "[CharLinkedList of size 5 <<edcba>>]");

    CharLinkedList list2;
    assert(list2.toReverseString() == "[CharLinkedList of size 0 <<>>]");
}

//test the pushAtBack function on a non-empty list
void pushAtBack_test(){
    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list1 = CharLinkedList(arr, 5);
    list1.pushAtBack('f');
    assert(list1.last() == 'f');
    assert(list1.toString() == "[CharLinkedList of size 6 <<abcdef>>]");
}

//test the pushAtBack function on an empty list
void pushAtBack_empty_test(){
    CharLinkedList list;
    list.pushAtBack('a');
    assert(list.last() == 'a');
    assert(list.toString() == "[CharLinkedList of size 1 <<a>>]");
}

//test the push at Front function with a non-empty LL
void pushAtFront_test(){
    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list1 = CharLinkedList(arr, 5);
    list1.pushAtFront('f');
    assert(list1.first() == 'f');
    assert(list1.toString() == "[CharLinkedList of size 6 <<fabcde>>]");
}

//test the pushAtFront function with an empty LL
void pushAtFront_empty_test(){
    CharLinkedList list;
    list.pushAtFront('a');
    assert(list.toString() == "[CharLinkedList of size 1 <<a>>]");
}

//test the insertAt fuciton with a non-empty LL and an empty LL.
void insertAt_test(){
    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list1 = CharLinkedList(arr, 5);
    list1.insertAt('f', 2);
    assert(list1.elementAt(2) == 'f');
    assert(list1.toString() == "[CharLinkedList of size 6 <<abfcde>>]");

    CharLinkedList list2;
    list2.insertAt('a', 0);
    assert(list2.toString() == "[CharLinkedList of size 1 <<a>>]");

    CharLinkedList list3 = CharLinkedList('a');
    list3.insertAt('b', 1);
    assert(list3.toString() == "[CharLinkedList of size 2 <<ab>>]");
}

//test the error message thrown when insertAt throws a range error
void insertAt_nonempty_incorrect() {
    char test_arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.insertAt('a', 42);
    } catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8]");
}


// Tests incorrect insertion into an empty LL.
// Attempts to call insertAt for index larger than 0.
// This should result in an std::range_error being raised.
void insertAt_empty_incorrect() {
    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
        // insertAt for out-of-range index
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        // if insertAt is correctly implemented, a range_error will be thrown,
        // and we will end up here
        range_error_thrown = true;
        error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0]");
}

// Tests correct insertAt for front of 1-element list.
void insertAt_front_singleton_list() {
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at front
    test_list.insertAt('b', 0);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'a');
}

// Tests correct insertAt for back of 1-element list.
void insertAt_back_singleton_list() {
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at back
    test_list.insertAt('b', 1);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
}

// Tests calling insertAt for a large number of elements.
// Not only does this test insertAt, it also checks that
// array expansion works correctly.
void insertAt_many_elements() {
    CharLinkedList test_list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.insertAt('a', i);
    }

    assert(test_list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
}

// Tests insertion into front of a larger list
void insertAt_front_large_list() {
    char test_arr[9] = {'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(test_arr, 9);

    test_list.insertAt('y', 0);

    assert(test_list.size() == 10);
    assert(test_list.elementAt(0) == 'y');
    assert(test_list.toString() == "[CharLinkedList of size 10 <<yabczdefgh>>]");
}

// Tests insertion into the back of a larger list
void insertAt_back_large_list() {
    char test_arr[10] = {'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(test_arr, 10);

    test_list.insertAt('x', 10);

    assert(test_list.size() == 11);
    assert(test_list.elementAt(10) == 'x');
    assert(test_list.toString() ==
           "[CharLinkedList of size 11 <<yabczdefghx>>]");
}

// Tests insertion into the middle of a larger list
void insertAt_middle_large_list() {
    char test_arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(test_arr, 8);

    test_list.insertAt('z', 3);

    assert(test_list.size() == 9);
    assert(test_list.elementAt(3) == 'z');
    assert(test_list.toString() == "[CharLinkedList of size 9 <<abczdefgh>>]");
}

//test insertAr with empty list
void insertAt_empty_correct() {
    CharLinkedList test_list;
    test_list.insertAt('a', 0);
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');
}

//test insertInOrder in which the char is supposed to go at the front
void insertInOrder_test_front(){
    char arr[5] = {'a', 'b', 'c', 'd', 'z'};
    CharLinkedList list1 = CharLinkedList(arr, 5);
    list1.insertInOrder('f');
    assert(list1.elementAt(4) == 'f');
    assert(list1.toString() == "[CharLinkedList of size 6 <<abcdfz>>]");
}

//test insertInOrder in which the char is supposed to go at the back
void insertInOrder_test_back(){
    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list1 = CharLinkedList(arr, 5);
    list1.insertInOrder('f');
    assert(list1.elementAt(5) == 'f');
    assert(list1.toString() == "[CharLinkedList of size 6 <<abcdef>>]");
}

//test insertInOrder in which the distinct char is supposed to go at the middle
void insertInOrder_test_mid_distict(){
    char arr[5] = {'a', 'a', 'c', 'd', 'e'};
    CharLinkedList list1 = CharLinkedList(arr, 5);
    list1.insertInOrder('b');
    assert(list1.elementAt(2) == 'b');
    assert(list1.toString() == "[CharLinkedList of size 6 <<aabcde>>]");
}

//test insertInOrder in which the duplicate char is supposed to go at the middle
void insertInOrder_test_mid_rep(){
    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list1 = CharLinkedList(arr, 5);
    list1.insertInOrder('b');
    assert(list1.elementAt(1) == 'b');
    assert(list1.toString() == "[CharLinkedList of size 6 <<abbcde>>]");
}

//test insertInOrder in which the LL is empty
void insertInOrder_empty(){
    CharLinkedList list1;
    list1.insertInOrder('b');
    assert(list1.elementAt(0) == 'b');
    assert(list1.toString() == "[CharLinkedList of size 1 <<b>>]");
}

//test popFromFront with a non-empty LL
void popFromFront_nonEmpty(){
    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list1 = CharLinkedList(arr, 5);
    list1.popFromFront();
    assert(list1.toString() == "[CharLinkedList of size 4 <<bcde>>]");
}

//tests if the right error message is thrown if popFromFront is called
//on an empty LL. 
void popFromFront_error(){
    // boolean variable to track whether runtime_error is thrown
    bool runtime_error_thrown = false;

    // boolean variable to track any error messages raised
    std::string error_message = "";
    
    CharLinkedList list;
    try {
        list.popFromFront();
    } catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

//test popFromFront with a LL size 1
void popFromFront_size1(){
    CharLinkedList list = CharLinkedList('a');
    list.popFromFront();
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}

//test popFromBack on a non-empty LL
void popFromBack_nonEmpty(){
    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list1 = CharLinkedList(arr, 5);
    list1.popFromBack();
    assert(list1.toString() == "[CharLinkedList of size 4 <<abcd>>]");
}

//tests if the right error message is thrown if popFromBack is called
//on an empty LL. 
void popFromBack_error(){
    // boolean variable to track whether runtime_error is thrown
    bool runtime_error_thrown = false;

    // boolean variable to track any error messages raised
    std::string error_message = "";
    
    CharLinkedList list;
    try {
        list.popFromBack();
    } catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

//test if popFromBack works properly on a LL size 1
void popFromBack_size1(){
    CharLinkedList list = CharLinkedList('a');
    list.popFromBack();
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}

//test removeAt
void removeAt_test(){
    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list1 = CharLinkedList(arr, 5);
    list1.removeAt(1);
    assert(list1.size() == 4);
    assert(list1.elementAt(1) == 'c');
    list1.removeAt(2);
    assert(list1.toString() == "[CharLinkedList of size 3 <<ace>>]");
}

//test the error message thrown by removeAt
void removeAt_error(){
    bool range_error_thrown = false;
    string error_message = "";
    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list1 = CharLinkedList(arr, 5);
    try{
        list1.removeAt(7);
    }catch(const std::range_error &e){
        range_error_thrown = true;
        error_message = e.what();
    }
    
    assert(range_error_thrown);
    assert(error_message == "index (7) not in range [0..5)");
}

//test replace at when it is supposed to work
void replace_at_test(){
    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list1 = CharLinkedList(arr, 5);
    list1.replaceAt('k', 2);
    assert(list1.elementAt(2) == 'k');
    assert(list1.toString() == "[CharLinkedList of size 5 <<abkde>>]");
}

//test replace at when it is supposed to throw an error
void replaceAt_error(){
    bool range_error_thrown = false;
    string error_message = "";
    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list1 = CharLinkedList(arr, 5);
    try{
        list1.replaceAt('k', 7);
    }catch(const std::range_error &e){
        range_error_thrown = true;
        error_message = e.what();
    }
    
    assert(range_error_thrown);
    assert(error_message == "index (7) not in range [0..5)");
}

//tests correct resulting LL after concetenating 2 non-empty arrays. 
void concatenate_function() {
    char arr_1[6] = {'a', 'b', 'c', 'd', 'e', 'f'};
    CharLinkedList list = CharLinkedList(arr_1, 6);
    
    char arr_2[3] = {'z', 'x', 'y'};
    CharLinkedList list2 = CharLinkedList(arr_2, 3);

    list.concatenate(&list2); // Pass the address of list2 directly
}


//tests for correct resulting LL after concatenating a Ll with an empty LL
void concatenate_list2_empty(){
    char arr_1[6] = {'a', 'b', 'c', 'd', 'e', 'f'};
    CharLinkedList list1 = CharLinkedList(arr_1, 6);

    CharLinkedList list2 = CharLinkedList();

    list1.concatenate(&list2);
    assert(list1.toString() == "[CharLinkedList of size 6 <<abcdef>>]");
}

//tests for correct resulting LL after concatenating an empty LL with a
//non-empty LL. 
void concatenate_list1_empty(){
    char arr_1[6] = {'a', 'b', 'c', 'd', 'e', 'f'};
    CharLinkedList list2 = CharLinkedList(arr_1, 6);

    CharLinkedList list1 = CharLinkedList();

    list1.concatenate(&list2);
    assert(list1.toString() == "[CharLinkedList of size 6 <<abcdef>>]");
}

//test for correct resulting LL after concatenating with itself
void concatenate_self_non_empty(){
    char arr_1[3] = {'a', 'b', 'c'};
    CharLinkedList list2 = CharLinkedList(arr_1, 3);
    list2.concatenate(&list2);
    assert(list2.toString() == "[CharLinkedList of size 6 <<abcabc>>]");
}

//test for correct resulting LL after concatenating with itself
void concatenate_self_empty(){
    CharLinkedList list;
    list.concatenate(&list);
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}
/*
 *  CharLinkedList.cpp
 *  Khoa T. Nguyen
 *  2/3/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Purpose:implementation of the functions in CharLinkedList
 *
 */

#include "CharLinkedList.h"
#include <string>
#include <stdexcept>

using namespace std;

/* name: charLinkedList
 * purpose: constructs an empty CharLinkedList (LL)
 * arguments: none
 * returns: none. It is a constructor
 * effects: declares and initializea an empty CharLinkedList
 */
CharLinkedList::CharLinkedList(){
    numItems = 0;
    front = nullptr;
    back = nullptr;
}

/* name: charLinkedList
 * purpose: constructs an empty CharLinkedList (LL)
 * arguments: a character c that is the first element of the list
 * returns: none. It is a constructor
 * effects: declares and initializea a CharLinkedList with c as the first and 
 * only element. Capacity and numItems is set to 1. 
 */
CharLinkedList::CharLinkedList(char c) {
    // Dynamically allocate memory for the first node
    front = new Node;
    front->data = c;
    front->prev = nullptr;
    front->next = nullptr;
    back = front;
    numItems = 1;
}

/* name: charLinkedList
 * purpose: constructs an empty CharLinkedList (LL)
 * arguments: a char array that contains the first elements of the list, and an
 * integer that is the size of said array
 * returns: none. It is a constructor
 * effects: none
 */
CharLinkedList::CharLinkedList(char arr[], int size) {
    if (size <= 0) {
        front = nullptr;
        numItems = 0;
        return;
    }

    front = new Node;
    front->data = arr[0];
    front->prev = nullptr;
    Node *prevNode = front;

    for (int i = 1; i < size; i++) {
        Node *currNode = new Node;
        currNode->data = arr[i];
        currNode->prev = prevNode;
        currNode->next = nullptr;
        prevNode->next = currNode;
        prevNode = currNode;
    }
    back = prevNode;
    numItems = size;
}

/* name: charLinkedList
 * purpose: constructs a CharLinkedList (LL) that is a copy of another 
 * CharLinkedList
 * arguments: address of the CharLinkedList of which to copy. 
 * returns: none. It is a constructor. 
 * effects: none
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other){

    if(other.front == nullptr){ //handles case where other is empty
        front = nullptr;
        numItems = 0;
        return;
    }

    front = new Node;
    front->data = other.front->data;
    front->prev = nullptr;
    Node *prevNode = front;

    Node *other_currNode = other.front->next;

    for (int i = 1; i < other.numItems; i++) {
        Node *currNode = new Node; //make a new node
        currNode->data = other_currNode->data; //assign data from other
        currNode->prev = prevNode; //set prev pointer of the current node
        currNode->next = nullptr; //set next pointer of the current node
        prevNode->next = currNode; //set next pointer of the previous node
        prevNode = currNode; //set the current node to be the prev node
        other_currNode = other_currNode->next; //reset other_currNode
    }

    back = prevNode;

    numItems = other.numItems;
}

/* name: operator=
 * purpose: an assignment operator that assigns data from the right hand side 
 * to the left hand side CharLinkedList
 * arguments: an CharLinkedList other
 * returns: a deep copy of CharLinkedList other
 * effects: Deallocate the memory of the left side, then make it a copy of the 
 * right hand side
 */
CharLinkedList& CharLinkedList::operator=(const CharLinkedList &other){
    if (this != &other) { // Check for self-assignment
        // Copy numItems
        if(other.front == nullptr){ //handles case where other is empty
            front = nullptr;
            numItems = 0;
            return *this;
        }
        numItems = other.numItems;

        // Allocate new memory and copy data
        destructor_helper(front); // Deallocate existing memory

        this->front = new Node;
        this->front->data = other.front->data; 
        Node *other_currNode = other.front->next;
        Node *prevNode = this->front;

        for (int i = 1; i < numItems;i++) {
            Node *currNode = new Node; //make a new node
            currNode->data = other_currNode->data; //assign data from other
            currNode->prev = prevNode; //set prev pointer of the current node
            currNode->next = nullptr; //set next pointer of the current node
            prevNode->next = currNode; //set next pointer of the previous node
            prevNode = currNode; //set the current node to be the prev node
        }

        back = prevNode;
    }
    return *this;
}

/* name: ~charLinkedList
 * purpose: free up memory allocated to LL
 * arguments: none
 * returns: none. It is a destructor
 * effects: free up memory allocated to data if data is not nullptr
 */
CharLinkedList::~CharLinkedList() {
    destructor_helper(front);
}

/* name: destructor_helper
 * purpose: delete each node from the list recursively
 * arguments: none
 * returns: none. It is a destructor
 * effects: free up memory allocated to data if data is not nullptr
 */
void CharLinkedList::destructor_helper(Node *start) {
    while (start != nullptr) {
        Node *next = start->next;
        delete start;
        start = next;
    }
    front = nullptr; // After deleting all nodes, make sure front points to 
                    //nullptr
}

/* name: toString
 * purpose: return a string representation of the LL, which also includes the 
 * size of the LL. 
 * arguments: none
 * returns: a string representation of the LL, which also includes the 
 * size of the LL. 
 * effects: nothing special really
 */
std::string CharLinkedList::toString() const {
    string str = "[CharLinkedList of size " + std::to_string(numItems) + " <<";
    if(front != nullptr){

        Node *currNode = front;
        
        for(int i = 0; i < numItems; i++){
            str+=currNode->data;
            currNode = currNode->next;
        }
    }
    str+=">>]";
    return str;
}

/* name: isEmpty
 * purpose: checks if an LL is empty
 * arguments: none
 * returns: a boolean value: true if the LL is empty, and false if it is not
 * effects: nothing special really
 */
bool CharLinkedList::isEmpty() const {
    if(front != nullptr){
        return false;
    }else{
        return true;
    }
}

/* name: clear
 * purpose: clear out the LL
 * arguments: none
 * returns: none
 * effects: deallocate the memory in data, reset front to nullptr, and reset 
 * numItems to 0.
 */
void CharLinkedList::clear(){
    destructor_helper(front);
    numItems = 0;
}

/* name: size
 * purpose: returm the number of items stored in the LL
 * arguments: none
 * returns: an integer that is the number of items stored in the LL
 * effects: nothing special
 */
int CharLinkedList::size() const {
    return numItems;
}

/* name: first
 * purpose: get the first element stored in an LL
 * arguments: none
 * returns: the first element in an LL
 * effects: throwns a runtime error if the LL is empty
 */
char CharLinkedList::first() const {
    if(isEmpty()){
        //throw a runtime error if the list is empty
        throw std::runtime_error("cannot get first of empty LinkedList");
    }
    return front->data;
}

/* name: last
 * purpose: get the last element stored in an LL
 * arguments: none
 * returns: the last element in an LL
 * effects: throwns a runtime error if the LL is empty
 */
char CharLinkedList::last() const {
    if(isEmpty()){
        //throw a runtime error if the list is empty
        throw std::runtime_error("cannot get last of empty LinkedList");
    }
    return back->data;
}

/* name: getToIndex
 * purpose: get to the node at the specified index
 * arguments: pointer to the starting node, pointer to the int of the 
 * current_index, and an int that is the goal index
 * returns: the pointer to the node at the specified index
 * effects: runs recursively
 */
CharLinkedList::Node* CharLinkedList::getToIndex(Node *start, int *curr_index, 
                                                int goal_index) const{
    if(*curr_index == goal_index){
        return start;
    }else{
        start = start->next;
        (*curr_index)++;
        return(getToIndex(start, curr_index, goal_index));
    }
}

/* name: elementAt
 * purpose: get the CharLinkedList element at the inputed index
 * arguments: integer that is the index from which to get the element
 * returns: char at the index
 * effects: throws a range error if the index is out of the range of possible
 * indices
 */
char CharLinkedList::elementAt(int index) const {
    if(index < 0 or index >= numItems){
        throw std::range_error("index (" + std::to_string(index)
         + ") not in range [0.." + std::to_string(numItems) + ")");
    }
    int curr_index = 0;
    int goal_index = index;
    return((getToIndex(front, &curr_index, goal_index))->data);
}

/* name: toReverseString
 * purpose: return a string representation of the LL but with the elements in * 
 * revered oder, which also includes the size of the LL. 
 * arguments: none
 * returns: a string representation of the LL but with the elements in * 
 * revered oder, which also includes the size of the LL. 
 * effects: nothing special
 */
string CharLinkedList::toReverseString() const {
    string str = "[CharLinkedList of size " + std::to_string(numItems) + " <<";
    if(front != nullptr){

        Node *currNode = front;
        
        for(int i = numItems-1; i > -1; i--){
            str+=elementAt(i);
            currNode = currNode->next;
        }
    }
    str+=">>]";
    return str;
}

/* name: pushAtBack
 * purpose: add an element to the back of an LL
 * arguments: character c that will be added
 * returns: none
 * effects: will update numItems accordingly
 */
void CharLinkedList::pushAtBack(char c){
    if(isEmpty()){
    // Dynamically allocate memory for the first node
        front = new Node;
        front->data = c;
        front->prev = nullptr;
        front->next = nullptr;
        numItems = 1;
        back = front;
    }else{
        //making a new node
        Node *newNode = new Node;
        newNode->data = c;

        //handling the prev and next pointers
        back->next = newNode;
        newNode->prev = back;
        newNode->next = nullptr;
        back = newNode;

        numItems++; //increment numItems
    }
}

/* name: pushAtFront
 * purpose: add an element to the front of an LL
 * arguments: character c that will be added to the front of an LL
 * returns: none
 * effects: will update numItems accordingly
 */
void CharLinkedList::pushAtFront(char c){
    if(isEmpty()){
    // Dynamically allocate memory for the first node
        front = new Node;
        front->data = c;
        front->prev = nullptr;
        front->next = nullptr;
        back = front;
        numItems = 1;
    }else{
        //making a new node
        Node *newNode = new Node;
        newNode->data = c;

        //handling the prev and next pointers
        front->prev = newNode;
        newNode->next = front;
        newNode->prev = nullptr;

        numItems++; //increment numItems
        front = newNode; //reset front pointer
    }
}

/* name: insertAt
 * purpose: insert a new element at a specified index
 * arguments: character c to be added to LL and an index at which to insert c
 * returns: none
 * effects: throws a range error if index is out of bounds, which is larger 
 * than numItems
 */
void CharLinkedList::insertAt(char c, int index){
    if(index < 0 or index > numItems){
        if(index < 0 or index >= numItems){
            throw std::range_error("index (" + std::to_string(index)
            + ") not in range [0.." + std::to_string(numItems) + "]");
        }
    }
    if(index == numItems){
        pushAtBack(c);
    }else if(index == 0){
        pushAtFront(c);
    }else{
        int currIndex = 0;
        Node *addingSite = getToIndex(front, &currIndex, index-1);

        Node *newNode = new Node;
        newNode->data = c;

        newNode->prev = addingSite;
        newNode->next = addingSite->next;

        addingSite->next->prev = newNode;
        addingSite->next = newNode;

        numItems++;
    }
}

/* name: insertInOrder
 * purpose: insert a character in a sorted LL so that all elements are in 
 * alphabetical order afterwards
 * arguments: character c to be inserted
 * returns: none
 * effects: nothing special
 */
void CharLinkedList::insertInOrder(char c){
    if(isEmpty()){
        pushAtFront(c); 
    }else if (c < front->data) {
        pushAtFront(c); //add test case to test for this
    } else {
        int i;
        for (i = 0; i < numItems - 1; i++) {
            //compare c to each pair of consecutive characters and insert 
            //accordingly
            if (c >= elementAt(i) and c <= elementAt(i + 1)) {
                insertAt(c, i + 1);
                return;
            }
        }
        if (i == numItems - 1) { //if c is larger than all of the elements in LL
                                // insert it at the back of the list
            pushAtBack(c);
        }
    }
}

/* name: popFromFront
 * purpose: delete the element at the front of an LL and moves all other 
 * elements accordingly
 * arguments: none
 * returns: none
 * effects: throws runtime error if the LL is empty
 */
void CharLinkedList::popFromFront(){
    if(isEmpty()){
        throw std::runtime_error("cannot pop from empty LinkedList");
    }else{
        if(numItems == 1){
            clear();
        }else{
            front->next->prev = nullptr;
            Node *newFront = front->next;
            front->next = nullptr;
            delete front;
            front = newFront;
            numItems--;
        }
    }
}

/* name: popFromBack
 * purpose: delete the element at the back of an LL
 * arguments: none
 * returns: none
 * effects: throws runtime error if the LL is empty
 */
void CharLinkedList::popFromBack(){
    if(isEmpty()){
        throw std::runtime_error("cannot pop from empty LinkedList");
    }else{
        if(numItems == 1){
            clear();
        }else{
            Node *newBack = back->prev;
            back->prev->next = nullptr;
            back->prev = nullptr;
            delete back;
            back = newBack;
            numItems--;
        }
    }
}

/* name: removeAt
 * purpose: remove the element at specified index and move all elements after 
 * it left 1
 * arguments: index at which to remove the element
 * returns: none
 * effects: throws a range error if the index is out of bounds
 */
void CharLinkedList::removeAt(int index){
    if(index < 0 or index >= numItems){
        throw std::range_error("index (" + std::to_string(index)
         + ") not in range [0.." + std::to_string(numItems) + ")");
    }else if(index == 0){
        popFromFront();
    }else if(index == numItems){
        popFromBack();
    }else{
        int currIndex = 0;
        Node *nodeToRemove = getToIndex(front, &currIndex, index);
        Node *newNextNode = nodeToRemove->next;
        nodeToRemove->prev->next = newNextNode;
        newNextNode->prev = nodeToRemove->prev;
        delete nodeToRemove;
        numItems--;
    }
}

/* name: replaceAt
 * purpose: replace the element at a specified index with a specified character
 * arguments: a character c to replace the element, and the index at which to 
 * do so
 * returns: none
 * effects: throws a range error if the index is out of bounds
 */
void CharLinkedList::replaceAt(char c, int index){
    if(index < 0 or index >= numItems){
        throw std::range_error("index (" + std::to_string(index)
         + ") not in range [0.." + std::to_string(numItems) + ")");
    }else{
        int currIndex = 0;
        Node *nodeToChange = getToIndex(front, &currIndex, index);
        nodeToChange->data = c;
    }
}

/* name: concatenate
 * purpose: concatenate the current LL with an LL other. other will be added to 
 * the end of the current LL. 
 * arguments: pointer to LL other
 * returns: none 
 */
void CharLinkedList::concatenate(CharLinkedList *other){
    if(other == this){ //check for self concatenation
        CharLinkedList copy = CharLinkedList(*this);
        concatenate(&copy);
        return;
    }
    if(other->isEmpty()){
        return;
    }else{
        for(int i=0; i < other->size(); i++){
            pushAtBack(other->elementAt(i));
        }
    }
}
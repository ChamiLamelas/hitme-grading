/*
 *  CharLinkedList.h
 *  Khoa T. Nguyen 
 *  2/3/2034
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  CharLinkedList is a class that represents an ordered list of characters. 
 *  The default starting state is empty, but the client can declare and 
 *  initialize an instance of CharArrayList with a char or an array of
 *  char and the size of said array. They can also access, add, remove
 *  elements stored in the CharArrayList, as well as concatenate 2 
 *  CharArrayList. 
 *
 */

#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H

#include <string>

class CharLinkedList {
    public:
        //constructors
        CharLinkedList();
        CharLinkedList(char c);
        CharLinkedList(char arr[], int size);
        CharLinkedList(const CharLinkedList &other);

        //destructor
        ~CharLinkedList();

        //assignment operator
        CharLinkedList &operator=(const CharLinkedList &other);

        //query functions
        bool isEmpty() const; //whether the list is empty or not
        void clear(); //clears the list
        int size() const; //returns the number of elements in the list
        char first() const; //returns the first character
        char last() const; //returns the last character
        char elementAt(int index) const; //returns the character at index
        std::string toString() const; 
            //returns a formatted string representation of the list

        std::string toReverseString() const; 
            //returns a formatted string representation of the reversed list

        //functions to add elements to the list
        void pushAtBack(char c);
        void pushAtFront(char c);
        void insertAt(char c, int index);
        void insertInOrder(char c);

        //functions to remove elements from the list
        void popFromFront();
        void popFromBack();
        void removeAt(int index);

        //function to replace an element in the list
        void replaceAt(char c, int index);

        //function to concatenate list with another list
        void concatenate(CharLinkedList *other);


    private: 
        struct Node{
            char data;
            Node *next;
            Node *prev;
        };

        Node *front;
        Node *back;
        int numItems;

        //private helper functions
        void destructor_helper(Node* start);
        Node* getToIndex(Node *start, int *curr_index, 
                            int goal_index) const;
};

#endif

/*
 *  CharLinkedList.cpp
 *  Suleiman Abuaqel
 *  2/3/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  The purpose of this file is implementation for the CharLinkedList. 
 *  To do: RUN THIS FOR STYLE POINTS "style_check"
 */

#include "CharLinkedList.h"
#include <iostream>
#include <sstream>

using namespace std;


/* CharLinkedList new_Node Helper Function
 *  Arguments: A character 'newData' to set as data, a Node 'next' as the next 
    node, and a Node 'back' as the back node.
 *  Description: Creates and returns a new Node on the heap with the specified 
    data,
 *               next, and back nodes.
 *  Return value: A pointer to the newly created Node.
 *  Effects: Allocates memory on the heap for a new Node.
 */

CharLinkedList::Node *CharLinkedList::new_Node(char newData, Node*next
                                                           , Node*back)
{
     Node *new_node = new Node; //make a node on the heap
     new_node->data = newData;  // set that data equal to first parameter
     new_node->next = next;     // set the next node to the node in parameter
     new_node->back = back;     //set the back node to the same back node as in
                               //parameter
     return new_node;
}

/* CharLinkedList recycleRecursive Helper Function
 *  Arguments: A Node 'curr' representing the current node in the recursion.
 *  Description: Recursively deallocates memory for each node in the linked l
 * ist, starting from the specified node.
 *  Return value: None.
 *  Effects: Frees memory on the heap for each node in the linked list.
 */

void CharLinkedList::recycleRecursive(Node *curr)
   {
     if (curr == nullptr)
     {
        return;
     }
     else
     {
        Node *next_node = curr->next;
        delete curr;
        curr_size --;
        recycleRecursive(next_node);
     }
   }

/* CharLinkedList findRecursive Helper Function
 *  Arguments: A Node 'curr' representing the current node in the recursion,
 *  an integer 'element' representing the target element to find,
 *  and an integer 'count' representing the current count in the recursion.
 *  Description: Recursively finds and returns the Node containing the
 *  specified element.
 *  Return value: A pointer to the Node containing the target element.
 *                Returns nullptr if the element is not found.
 *  Effects: None.
 */

CharLinkedList::Node *CharLinkedList::findRecursive(Node *curr, int element, 
                                                    int count) const 
{
    if(count == element) {
        return curr;
    }
    
    else
    {
        Node*next_node = curr->next;
        return findRecursive(next_node, element, (count + 1));
    }
}

/* CharLinkedList Constructor
 *  Description: Creates an empty CharLinkedList.
 *  Return value: None.
 *  Effects: Initializes front, tail, and curr_size members.
 */

CharLinkedList::CharLinkedList() //first constructor to make class
{
    front = nullptr;
    tail = nullptr;
    curr_size = 0;
}

/* CharLinkedList Constructor with Character Parameter
 *  Arguments: A character 'c' to set as the initial data for the first node.
 *  Description: Creates a CharLinkedList with a single node containing the 
 * specified character.
 *  Return value: None.
 *  Effects: Initializes front, tail, and curr_size members.
 */

CharLinkedList::CharLinkedList(char c)
{
    Node *first_node = new_Node(c, nullptr, nullptr);
    front = first_node;
    tail = first_node;
    curr_size = 1;
}

/* CharLinkedList Constructor with Character Array and Size Parameters
 *  Arguments: A character array 'arr' and an integer 'size' representing the 
    array size.
 *  Description: Creates a CharLinkedList with nodes containing characters from 
    the array, in the same order as the array.
 *  Return value: None.
 *  Effects: Initializes front, tail, and curr_size members.
 */

CharLinkedList::CharLinkedList(char arr[], int size)
{
    curr_size = 0;
    front = nullptr; //initializing the front node
    tail = nullptr; //initializing the tail node
    for (int i = size; i > 0; i--)
    {
        pushAtFront(arr[i - 1]);
    }
}

/* CharLinkedList Copy Constructor
 *  Arguments: Another CharLinkedList 'other' to copy.
 *  Description: Creates a new CharLinkedList with the same elements as the 
 *  specified CharLinkedList.
 *  Return value: None.
 *  Effects: Initializes front, tail, and curr_size members.
 */

CharLinkedList::CharLinkedList(const CharLinkedList &other)
{
    curr_size = other.curr_size;
    front = nullptr;
    tail = nullptr;
    for (int i = curr_size - 1; i >= 0; i--)
    {
        cout << "this ran" << endl;
        pushAtFront(other.elementAt(i));
        cout << "does this run" << endl;
        curr_size --;
    }
}

/* CharLinkedList Assignment Operator
 *  Arguments: Another CharLinkedList 'other' to copy.
 *  Description: Assigns the elements of the specified CharLinkedList to the
 *  current CharLinkedList.
 *  Return value: A reference to the current CharLinkedList.
 *  Effects: Modifies front, tail, and curr_size members.
 */

CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other)
{
    recycleRecursive(front);
    for (int i = 0; i < other.curr_size; i++)
    {
        pushAtBack(other.elementAt(i));
    }
    return *this;
}

/* CharLinkedList Destructor
 *  Description: Deallocates memory for all nodes in the CharLinkedList.
 *  Return value: None.
 *  Effects: Frees memory on the heap for each node in the linked list.
 */

CharLinkedList::~CharLinkedList() //destructor to delete memory on the heap
{
    recycleRecursive(front);
}

//NORMAL FUCTIONS NOW

/* CharLinkedList toString Method
 *  Description: Returns a string representation of the CharLinkedList.
 *  Return value: A string representing the CharLinkedList.
 *  Effects: None.
 */

std::string CharLinkedList::toString() const {
    std::stringstream ss;
    ss << "[CharLinkedList of size " << curr_size << " <<";
    for (Node *curr = front; curr != nullptr; curr = curr->next){              
         ss << curr->data;
    }
    ss << ">>]";
    return ss.str();
}

/* CharLinkedList toReverseString Method
 *  Description: Returns a string representation of the CharLinkedList in 
    reverse order.
 *  Return value: A string representing the reversed CharLinkedList.
 *  Effects: None.
 */

std::string CharLinkedList::toReverseString() const
{
    std::stringstream ss;
    ss << "[CharLinkedList of size " << curr_size << " <<";
    for (Node *curr = tail; curr != nullptr; curr = curr->back){
         ss << curr->data;
    }
    ss << ">>]";
    return ss.str();
}

/* CharLinkedList size Method
 *  Description: Returns the current size of the CharLinkedList.
 *  Return value: An integer representing the size of the CharLinkedList.
 *  Effects: None.
 */
int CharLinkedList::size() const
{
    return curr_size;
}

/* CharLinkedList clear Method
 *  Description: Clears the CharLinkedList, deallocating memory for all nodes.
 *  Return value: None.
 *  Effects: Frees memory on the heap for each node in the linked list.
 *           Resets front, tail, and curr_size members.
 */
void CharLinkedList::clear()
{
    recycleRecursive(front);
    front = nullptr;
    tail = nullptr;
    curr_size = 0;
}

/* CharLinkedList isEmpty Method
 *  Description: Checks if the CharLinkedList is empty.
 *  Return value: True if the CharLinkedList is empty, false otherwise.
 *  Effects: None.
 */
bool CharLinkedList::isEmpty() const
{
    if (this->size() == 0){
        return true;
    }
    else{
        return false;
    }
}

/* CharLinkedList first Method
 *  Description: Returns the first element of the CharLinkedList.
 *  Return value: The first character in the CharLinkedList.
 *  Effects: Throws a runtime error if the CharLinkedList is empty.
 */
char CharLinkedList::first() const
{
    if(isEmpty()){
        throw std::runtime_error ("cannot get first of empty LinkedList");
    }
    return front->data;
}

/* CharLinkedList last Method
 *  Description: Returns the last element of the CharLinkedList.
 *  Return value: The last character in the CharLinkedList.
 *  Effects: Throws a runtime error if the CharLinkedList is empty.
 */
char CharLinkedList::last() const
{
    if(isEmpty()){
    throw std::runtime_error ("cannot get last of empty LinkedList");
    }
    return tail->data;
}

/* CharLinkedList pushAtFront Method
 *  Arguments: A character 'c' to push at the front of the CharLinkedList.
 *  Description: Adds the specified character to the front of the 
 *  CharLinkedList
 *  Return value: None.
 *  Effects: Expands the CharLinkedList if needed.
 */
void CharLinkedList::pushAtFront(char c)
{
    Node *first_node = new_Node(c, front, nullptr);
    
    front = first_node;

    if (curr_size == 0) 
    {
        tail = first_node;
    }
    else if (curr_size == 1)
    {
        tail->back = first_node;
    }
    if (front->next != nullptr) {
        front->next->back = front;
    }
    curr_size++;
}

/* CharLinkedList pushAtBack Method
 *  Arguments: A character 'c' to push at the back of the CharLinkedList.
 *  Description: Adds the specified character to the back of the 
 * CharLinkedList.
 *  Return value: None.
 *  Effects: Expands the CharLinkedList if needed.
 */

void CharLinkedList::pushAtBack(char c)
{
     Node *last_node = new_Node(c, nullptr, tail);
     tail = last_node;
     if (curr_size == 0)
     {
        front = last_node;
     }
     else if (curr_size == 1)
     {
        front->next = last_node;
     }
     if (tail->back != nullptr)
     {
        tail->back->next = tail;
     }
     curr_size++;
}

/* CharLinkedList elementAt Method
 *  Arguments: An integer 'index' representing the position of the element to 
    retrieve.
 *  Description: Returns the element at the specified index in the 
    CharLinkedList.
 *  Return value: The character at the specified index.
 *  Effects: Throws a range error if the index is out of bounds.
 */
char CharLinkedList::elementAt(int index) const
{
    if (index >= this->size() or index < 0) {
    throw std::range_error("index (" + std::to_string(index) 
                                     + ") not in range [0.." 
                                     + std::to_string(size()) + ")");
  }
    return findRecursive(front, index, 0)->data;
}


/* CharLinkedList insertAt Method
 *  Arguments: A character 'c' to insert and an integer 'index' representing 
    the position to insert.
 *  Description: Inserts the specified character at the specified index in the 
    CharLinkedList.
 *  Return value: None.
 *  Effects: Expands the CharLinkedList if needed.
 *           Throws a range error if the index is out of bounds.
 */

void CharLinkedList::insertAt(char c, int index)
{
     if(index == 0)
    {
        pushAtFront(c);
        return;
    }
    else if(index == (curr_size))
    {
        pushAtBack(c);
        return;
    }
    if (index > curr_size or index < 0) {
    throw std::range_error("index (" + std::to_string(index) 
                                     + ") not in range [0.." 
                                     + std::to_string(curr_size) + "]");
    } 

   
    Node *found_node = findRecursive(front, index, 0);
    Node *inserted_node = new_Node(c, found_node, found_node->back);
    found_node->back->next = inserted_node;
    found_node->back = inserted_node;
    curr_size++;
}

/* CharLinkedList insertInOrder Method
 *  Arguments: A character 'c' to insert in the CharLinkedList while 
    maintaining order.
 *  Description: Inserts the specified character in the CharLinkedList in 
    ascending order.
 *  Return value: None.
 *  Effects: Expands the CharLinkedList if needed.
 */

void CharLinkedList::insertInOrder(char c)
{
    int list_index = 0;
    for (Node *curr = front; curr != nullptr; curr = curr->next)
    {
        if(c <= curr->data){
            insertAt(c, list_index);
            return;
        }
        list_index ++;
    }
    pushAtBack(c);
}

/* CharLinkedList popFromFront Method
 *  Description: Removes the first element from the CharLinkedList.
 *  Return value: None.
 *  Effects: Expands the CharLinkedList if needed.
 *           Throws a runtime error if the CharLinkedList is empty.
 */

void CharLinkedList::popFromFront()
{
    if(this->isEmpty())
    {
        throw std::runtime_error ("cannot pop from empty LinkedList");
    }
    Node *replace_node = front->next;
    delete front;
    front = replace_node;
    curr_size --;
}

/* CharLinkedList popFromBack Method
 *  Description: Removes the last element from the CharLinkedList.
 *  Return value: None.
 *  Effects: Expands the CharLinkedList if needed.
 *           Throws a runtime error if the CharLinkedList is empty.
 */

void CharLinkedList::popFromBack()
{
    if(this->isEmpty())
    {
        throw std::runtime_error ("cannot pop from empty LinkedList");
    }
    Node *replace_node = tail->back;
    delete tail;
    tail = replace_node;
    tail->next = nullptr;
    curr_size --;
}

/* CharLinkedList removeAt Method
 *  Arguments: An integer 'index' representing the position of the element to 
    remove.
 *  Description: Removes the element at the specified index from the 
    CharLinkedList.
 *  Return value: None.
 *  Effects: Expands the CharLinkedList if needed.
 *           Throws a range error if the index is out of bounds.
 */

void CharLinkedList::removeAt(int index)
{
    if(index == 0)
    {
        popFromFront();
        return;
    }
    else if(index == (curr_size - 1))
    {
        popFromBack();
        return;
    }
    if (index >= this->size() or index < 0) {
     throw std::range_error("index (" + std::to_string(index) 
                                     + ") not in range [0.." 
                                     + std::to_string(size()) + ")");
  }
    Node *found_node = findRecursive(front, index, 0);
    
    found_node->back->next = found_node->next;
    
    found_node->next->back = found_node->back;
    
    delete found_node;
    
    curr_size--;
}

/* CharLinkedList replaceAt Method
 *  Arguments: A character 'c' to replace the element and an integer 'index' 
    representing the position.
 *  Description: Replaces the element at the specified index in the 
    CharLinkedList with the specified character.
 *  Return value: None.
 *  Effects: Expands the CharLinkedList if needed. Throws a range error if the 
 *  index is out of bounds.
 */
void CharLinkedList::replaceAt(char c, int index)
{
    if(index == 0)
    {
        popFromFront();
        pushAtFront(c);
        return;
    }
    else if(index == (curr_size - 1))
    {
        popFromBack();
        pushAtBack(c);
        return;
    }
    if (index >= this->size() or index < 0) {
    throw std::range_error("index (" + std::to_string(index) 
                                     + ") not in range [0.." 
                                     + std::to_string(size()) + ")");
  }
    Node *found_node = findRecursive(front, index, 0);
    found_node->data = c;
}

/* CharLinkedList concatenate Method
 *  Arguments: A pointer to another CharLinkedList 'other' to concatenate with
    the current CharLinkedList.
 *  Description: Concatenates the specified CharLinkedList to the end of the 
    current CharLinkedList.
 *  Return value: None.
 *  Effects: Expands the CharLinkedList if needed.
 */
void CharLinkedList::concatenate(CharLinkedList *other)
{
    if(other == this)
    {
        int new_size = curr_size;
        for (int i = 0; i < new_size; i++)
        {
        pushAtBack(elementAt(i));
        }
        return;
    }
    for (int i = 0; i < other->curr_size; i++)
    {
        pushAtBack(other->elementAt(i));
    }
}
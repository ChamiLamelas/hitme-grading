/*
 *  unit_tests.h
 *  Suleiman Abuaqel
 *  2/3/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  This file contains the tests that are run on the CharLinkedList 
 * implementation to make sure that the functions run correctly
 *
 */
#include "CharLinkedList.h"

#include <cassert>
#include <iostream>
#include <iostream>
#include <string>
using namespace std;
//tests to make sure that the initial constructor works
void constructor1_test_0() {
    CharLinkedList test_list;
    cout << test_list.size();
    assert(test_list.size() == 0);
    if(test_list.isEmpty()){
        cout << "this works" << endl;
    }
    assert(test_list.isEmpty());
}

//tests to make sure that the second constructor with a char parameter works

void constructor2_test_0()
{
    CharLinkedList test_list('g');
    cout << test_list.size() << endl;
    assert(test_list.size() == 1);
    cout << test_list.toString() << endl;
     assert(test_list.toString() == "[CharLinkedList of size 1 <<g>>]");
}

//checks to make sure that constructor that takes in an array works

void constructor3_test_0()
{
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr,9);
    cout << test_list.size() << endl;
    assert(test_list.size() == 9);
    cout << "Okay" << endl;
    cout << test_list.toString() << endl;
    cout << test_list.first() << endl;
    cout << test_list.last() << endl;
    assert(test_list.toString() == "[CharLinkedList of size 9 <<abczdefgh>>]");
}

//making sure that the constructor can take in an array of 0 elements

void constructor3_test_1()
{
    char test_arr[0] = {};
    CharLinkedList test_list(test_arr,0);
    cout << test_list.size() << endl;
    assert(test_list.size() == 0);
    cout << test_list.toString() << endl;
    assert(test_list.toString() == "[CharLinkedList of size 0 <<>>]");
}


void constructor_test_3()
    {
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList other(test_arr, 9);
    CharLinkedList test_list;
    cout << "here" << endl;
    test_list=other;
    cout << "here" << endl;
    assert(test_list.size() == 9);
    cout << test_list.toString() << endl;
    assert(test_list.toString() == "[CharLinkedList of size 9 <<abczdefgh>>]");
    }


//makes sure that the clear function works

void clear_test_1()
{
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr,9);
    test_list.clear();
    cout << "yo mistake is here" << endl;
    
    cout << test_list.toString() << endl;
    assert(test_list.toString() == "[CharLinkedList of size 0 <<>>]");
}

//makes sure that the element at function works 

void elementAt_test_1()
{
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr,9);
    char my_char = test_list.elementAt(5);
    cout << my_char;
    assert(my_char = 'e');
}

//tests element at for the the last index
void elementAt_test_2()
{
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr,9);
    char my_char = test_list.elementAt(8);
    cout << my_char;
    assert(my_char = 'h');
}

//tests elementAt at the first index
void elementAt_test_3()
{
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr,9);
    char my_char = test_list.elementAt(0);
    cout << my_char;
    assert(my_char = 'a');
}

//tests copyconstructor
void copyconstructor_test_1()
{
     char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list1(test_arr,9);
    cout << test_list1.toString() << endl;
    CharLinkedList test_list(test_list1);
    cout << test_list.toString() << endl;
    assert(test_list.size() == 9);
    assert(test_list.toString() == "[CharLinkedList of size 9 <<abczdefgh>>]");
}

void copyconstructor_test_2()
{
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list1(test_arr,9);
    cout << test_list1.toString() << endl;
    CharLinkedList test_list(test_list1);
    cout << test_list.toString() << endl;
    assert(test_list.size() == 9);
    assert(test_list.toString() == "[CharLinkedList of size 9 <<abczdefgh>>]");
}

void pushAtFront_test_1() //small test for push at front
{
    CharLinkedList test_list;
    test_list.pushAtFront('g');
    cout << test_list.toString() << endl;
    assert(test_list.size() == 1);
    assert(test_list.toString() == "[CharLinkedList of size 1 <<g>>]");
    assert(test_list.first() == 'g');
    assert(test_list.last() == 'g');
}

void pushAtFront_test_2() //bigger test for push at front
{
   char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr,9);
    cout << test_list.toString() << endl;
    assert(test_list.size() == 9);
    assert(test_list.toString() == "[CharLinkedList of size 9 <<abczdefgh>>]");
    assert(test_list.first() == 'a');
    assert(test_list.last() == 'h');
}

void reverse_string_test() //makes sure that reverse string works
{
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr,9);
    cout << test_list.toString() << endl;
    assert(test_list.size() == 9);
    assert(test_list.toReverseString() ==
    "[CharLinkedList of size 9 <<hgfedzcba>>]");
    assert(test_list.first() == 'a');
    assert(test_list.last() == 'h');
}
void pushAtFront_test_3() //edge case to check what happens if it runs twice.
{
    char test_arr[2] = { 'a', 'b' };
    CharLinkedList test_list(test_arr, 2);
    cout << test_list.toString() << endl;
    assert(test_list.size() == 2);
    assert(test_list.toString() == "[CharLinkedList of size 2 <<ab>>]");
    assert(test_list.first() == 'a');
    assert(test_list.last() == 'b');
}

void pushAtBack_test_1() //small test for push at back
{
    CharLinkedList test_list;
    test_list.pushAtBack('g');
    cout << test_list.toString() << endl;
    assert(test_list.size() == 1);
    assert(test_list.toString() == "[CharLinkedList of size 1 <<g>>]");
    assert(test_list.first() == 'g');
    assert(test_list.last() == 'g');
}

void pushAtBack_test_2() //bigger test for push at back
{
    CharLinkedList test_list;
    for (int i = 0; i < 9; i++){
        test_list.pushAtBack('a' + i);
    }
    cout << test_list.toString() << endl;
    assert(test_list.size() == 9);
    assert(test_list.toString() == "[CharLinkedList of size 9 <<abcdefghi>>]");
    assert(test_list.first() == 'a');
    assert(test_list.last() == 'i');
}

void pushAtBack_test_3() //edge case to check what happens if it runs twice.
{
    CharLinkedList test_list;
    for (int i = 0; i < 2; i++){
        test_list.pushAtBack('a' + i);
    }
    cout << test_list.toString() << endl;
    assert(test_list.size() == 2);
    assert(test_list.toString() == "[CharLinkedList of size 2 <<ab>>]");
    assert(test_list.first() == 'a');
    assert(test_list.last() == 'b');
}

void insertAt_test_1() //This test failed, nvm it passed.
{
    CharLinkedList test_list;
    test_list.insertAt('g', 0);
    assert(test_list.size() == 1);
    assert(test_list.toString() == "[CharLinkedList of size 1 <<g>>]");
    assert(test_list.first() == 'g');
    assert(test_list.last() == 'g');
}
//I TEST FIRST AND LAST THROUGH OTHER TESTS
void insertAt_test_2() //makes sure we can insert at first and last element
{
    CharLinkedList test_list;
    for (int i = 0; i < 9; i++){
        test_list.pushAtBack('a');
    }
    test_list.insertAt('z',0);
    test_list.insertAt('x',(test_list.size()));
    assert(test_list.toString() == 
    "[CharLinkedList of size 11 <<zaaaaaaaaax>>]");
    assert(test_list.first() == 'z');
    assert(test_list.last() == 'x');
}

//testing insertAt when i havea range error
void insertAt_test_3()
{
    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    // insertAt for out-of-range index
    test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
    // if insertAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    range_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    cout << test_list.size() << endl;
    assert(error_message == "index (42) not in range [0..0]");
}

//making sure in_order works
void in_order_test_1()
{
    CharLinkedList test_list;
    for (int i = 0; i < 9; i++){
        test_list.pushAtBack('a' + i);
    }
    test_list.insertInOrder('d');
    test_list.insertInOrder('i');

    cout << test_list.toString() << endl;
    assert(test_list.size() == 11);
    assert(test_list.toString() == 
    "[CharLinkedList of size 11 <<abcddefghii>>]");
    assert(test_list.first() == 'a');
    assert(test_list.last() == 'i');
}

//tests popfrom front and makes sure that this works
void popfromfront_test_1()
{
    CharLinkedList test_list;
    for (int i = 0; i < 9; i++){
        test_list.pushAtBack('a' + i);
    }
    cout << test_list.toString() << endl;
    test_list.popFromFront();
    cout << test_list.size() << endl;
    assert(test_list.size() == 8);
    cout << test_list.toString() << endl;
    assert(test_list.toString() == "[CharLinkedList of size 8 <<bcdefghi>>]");
    assert(test_list.first() == 'b');
    assert(test_list.last() == 'i');
}

void popfromfront_test_2() //makes sure that it catches a throw
{
     CharLinkedList test_list;
    bool runtime_error_thrown = false; 
    std::string error_message = "";
    try{test_list.popFromFront();}
    catch(std::runtime_error &e){
        runtime_error_thrown = true;
        error_message = e.what();
    }
        assert(runtime_error_thrown);
        assert(error_message == "cannot pop from empty LinkedList");
}

void popfromback_test_1()
{
    CharLinkedList test_list; //makes sure that popfrombacl works
    for (int i = 0; i < 9; i++){
        test_list.pushAtBack('a' + i);
    }
    cout << test_list.toString() << endl;
    test_list.popFromBack();
    cout << test_list.size() << endl;
    assert(test_list.size() == 8);
    cout << "hello" << endl;
    assert(test_list.toString() == "[CharLinkedList of size 8 <<abcdefgh>>]");
    cout << "hello" << endl;
    assert(test_list.first() == 'a');
    assert(test_list.last() == 'h');
}

void removeAt_test_1() //makes sure that remove at works
{
    CharLinkedList test_list;
    for (int i = 0; i < 9; i++){
        test_list.pushAtBack('a');
    }
    test_list.removeAt(0);
    test_list.removeAt((test_list.size() - 1));
    assert(test_list.toString() == 
    "[CharLinkedList of size 7 <<aaaaaaa>>]");
    assert(test_list.first() == 'a');
    assert(test_list.last() == 'a');
}

void replace_at_test() //makes sure that replace at works
{
    CharLinkedList test_list;
    for (int i = 0; i < 9; i++){
        test_list.pushAtBack('a');
    }
    test_list.replaceAt('g', 0);
    test_list.replaceAt('g', 4);
    test_list.replaceAt('g', (test_list.size() - 1));
    cout << test_list.toString() << endl;
    assert(test_list.toString() == 
    "[CharLinkedList of size 9 <<gaaagaaag>>]");
    assert(test_list.first() == 'g');
    assert(test_list.last() == 'g');
}

void concatenate_test() //tests concatenate
{
    CharLinkedList test_list;
    CharLinkedList test_list1;
    for (int i = 0; i < 9; i++){
        test_list.pushAtBack('a' + i);
    }
    for (int i = 0; i < 9; i++){
        test_list1.pushAtBack('a' + i);
    }
    test_list.concatenate(&test_list1);
    cout << test_list.toString() << endl;;
    assert(test_list.toString() == 
    "[CharLinkedList of size 18 <<abcdefghiabcdefghi>>]");
}

void concatenate_test_2() //tests concatenate on itself
{
    CharLinkedList test_list;
    for (int i = 0; i < 9; i++){
        test_list.pushAtBack('a' + i);
    }

    test_list.concatenate(&test_list);
    cout << test_list.toString() << endl;;
    assert(test_list.toString() == 
    "[CharLinkedList of size 18 <<abcdefghiabcdefghi>>]");
}

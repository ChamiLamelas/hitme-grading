/*
 *  CharLinkedList.h
 *  Suleiman ABuaqel
 *  2/3/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  The purpose this file holds is interface for the CharLinkedList
 *
 */

#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H
#include <string>
class CharLinkedList {
     public:
        //CONSTRUCTORS AND DESTRUCTORS
         CharLinkedList();
         CharLinkedList(char c);//constructor that takes in a char
         CharLinkedList(char arr[], int size);
         CharLinkedList(const CharLinkedList &other);
         CharLinkedList &operator=(const CharLinkedList &other);
         ~CharLinkedList(); //deconstructor
         

    
         
         // This returns a bool that returns true if the List is empty
         bool isEmpty() const;
         
         // This returns the size of the list
         int size() const; 
         void clear(); //clears out linked list
         char first() const; //returns first char
         char last() const; //returns last char in list
         std::string toString() const; //converts data to a string
         std::string toReverseString() const; // to string but backwards
         void pushAtBack(char c);
         void pushAtFront(char c);
         char elementAt(int index) const;
         void insertAt(char c, int index);
         void insertInOrder(char c);
         void popFromFront();
         void popFromBack();
         void removeAt(int index);
         void replaceAt(char c, int index);
         void concatenate(CharLinkedList *other);
    
         
     private:
         int curr_size;
         struct Node {
            char data;
            Node *next;
            Node *back;
        };
         Node *front;
         Node *tail;
         Node *new_Node(char newData, Node*next, Node*back);
         void printRecHelper(struct Node *curr); 
         void recycleRecursive(Node *curr);
        Node * findRecursive(Node * current, int index, int currentIndex) 
        const;
};      

#endif


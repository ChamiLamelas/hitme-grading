/*
 *  CharLinkedList.h
 *  Theodore Yuan
 *  2/3/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Interface for CharLinkedList data structure that can hold characters in an 
 *  ordererd list where elements can be added and removed. 
 */

#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H
#include <string>

class CharLinkedList {
    public:
        // constructors
        CharLinkedList();
        CharLinkedList(char c);
        CharLinkedList(char arr[], int size);
        CharLinkedList(const CharLinkedList &other);
        
        // destructor
        ~CharLinkedList();
        
        // assignment operator
        CharLinkedList &operator=(const CharLinkedList &other);

        // methods
        bool isEmpty() const;
        void clear();
        int size() const;
        char first() const;
        char last() const;
        char elementAt(int index) const;
        std::string toString() const;
        std::string toReverseString() const;
        void pushAtBack(char c);
        void pushAtFront(char c);
        void insertAt(char c, int index);
        void insertInOrder(char c);
        void popFromFront();
        void popFromBack();
        void removeAt(int index);
        void replaceAt(char c, int index);
        void concatenate(CharLinkedList *other);

    private:
        // struct definition for a Node
        struct Node {
            char character;
            Node *next;
            Node *prev;
        };

        // pointers to the front and back of the list
        Node *front;
        Node *back;

        // private field to keep track of the list's size
        int numItems;

        // recursive helper function for the destructor
        void freeMemory(Node *curr);

        // helper function to find a Node at a given index
        Node *findNode(Node *curr, int index) const;
};

#endif

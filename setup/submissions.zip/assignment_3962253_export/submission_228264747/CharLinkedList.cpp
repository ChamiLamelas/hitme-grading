/*
 *  CharLinkedList.cpp
 *  Theodore Yuan
 *  2/3/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Implementation for a the CharLinkedList data structure that can hold 
 *  characters in an ordered list where elements can be added and removed. 
 *
 */

#include "CharLinkedList.h"
#include <sstream>
#include <stdexcept>

using namespace std;

/*
 * name:      CharLinkedList default constructor
 * purpose:   initialize an empty LinkedList
 * arguments: none
 * returns:   none
 * effects:   front to nullptr, numItems to 0
 */
CharLinkedList::CharLinkedList() {
    front = nullptr;
    back = nullptr;
    numItems = 0;
}

/*
 * name: CharLinkedList second constructor
 * purpose: initialize a CharLinkedList with one element
 * arguments: a character to be the first and only element in the list
 * returns: none
 * effects: numItems to 1, adds one node and makes the front pointer point to
 * its address
 */
CharLinkedList::CharLinkedList(char c) {
    front = nullptr;
    numItems = 0;
    pushAtBack(c);
}

/*
 * name:      CharLinkedList third constructor
 * purpose:   initialize an LinbkedList with multiple values stored in an array
 * arguments: an array of characters, the size of that array
 * returns:   none
 * effects:   numItems to size, creates nodes for each char in the array,
 * linking each one to the previous
 */
CharLinkedList::CharLinkedList(char arr[], int size) {
    front = nullptr;
    numItems = 0;
    for (int i = 0; i < size; i++) {
        pushAtBack(arr[i]);
    }
}

/*
 * name:      CharLinkedList copy constructor
 * purpose:   initialize a new LinkedList instance that is a deep copy of a 
 * specified LinkedList instance
 * arguments: An CharLinkedList object
 * returns:   none
 * effects:   numItems to other->size(), copies each element in the other linked
 * list into the new one. 
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other) {
    if (other.isEmpty()) {
        front = nullptr;
        numItems = 0;
    } else {
        front = nullptr;
        numItems = 0;
        for (int i = 0; i < other.size(); i++) {
            this->pushAtBack(other.elementAt(i));
        }
    }
}

/*
 * name:      ~CharLinkedList destructor
 * purpose:   deletes the heap-allocated memory used in the instance being
 * destroyed
 * arguments: none
 * returns:   none
 * effects:   memory of the destroyed CharLinkedList is recycled
 */
CharLinkedList::~CharLinkedList() {
    freeMemory(front);
}

/*
 * name:      freeMemory
 * purpose:   recursive helper function to delete heap-allocated memory used in
 * in the instance being destroyed
 * arguments: a pointer to the current node that has been recursed to
 * returns:   none
 * effects:   memory of the destroyed CharLinkedList is recycled
 */
void CharLinkedList::freeMemory(Node *curr) {
    if (curr == nullptr) {
        return;
    } else {
        if (curr->next != nullptr) {
            freeMemory(curr->next);
        }
        delete curr;
        numItems--;
    }
}

/*
 * name:      CharLinkedList &operator= (const CharLinkedList &other) assignment
 operator
 * purpose:   defines an assignment operator for the class that recycles heap-
 allocated memory
 * arguments: a CharArray List &other
 * returns:   none
 * effects:   memory of the old CharLinkedList is recycled, new CharLinkedList
 *            includes numItems and contents of the list that was assigned
 */ 
CharLinkedList &CharLinkedList::operator= (const CharLinkedList &other) {
    if (this == &other) {
        return *this;
    }
    if (not other.isEmpty()) {
        clear();
        for (int i = 0; i < other.size(); i++) {
            pushAtBack(other.elementAt(i));
        }
    }
    return *this;
}

/*
 * name:      isEmpty
 * purpose:   determines if a CharLinkedList is empty
 * arguments: none
 * returns:   boolean
 * effects:   None
 */ 
bool CharLinkedList::isEmpty() const {
    return numItems == 0;
}

/*
 * name:      clear
 * purpose:   removes the contents of the CharLinkedList
 * arguments: none
 * returns:   none
 * effects:   numItems to 0, memory recycled
 */ 
void CharLinkedList::clear() {
    int initSize = numItems;
    for (int i = 0; i < initSize; i++) {
        popFromBack();
    }
}

/*
 * name:      size
 * purpose:   gets the number of elements stored in the CharLinkedList
 * arguments: none
 * returns:   int with the number of elements
 * effects:   none
 */
int CharLinkedList::size() const {
    return numItems;
}

/*
 * name:      first
 * purpose:   gets the first element of a CharLinkedList
 * arguments: none
 * returns:   char that is stored in the first place in the list
 * effects:   none
 */
char CharLinkedList::first() const {
    if (isEmpty()) {
        std::stringstream ss;
        ss << "cannot get first of empty LinkedList";
        throw runtime_error(ss.str());
    } else {
        return front->character;
    }
}

/*
 * name:      last
 * purpose:   gets the last element of a CharLinkedList
 * arguments: none
 * returns:   char that is stored in the last place in the list
 * effects:   none
 */
char CharLinkedList::last() const {
    if (isEmpty()) {
        std::stringstream ss;
        ss << "cannot get last of empty LinkedList";
        throw runtime_error(ss.str());
    } else {
        return back->character;
    }
}

/*
 * name:      elementAt
 * purpose:   gets the element of a CharLinkedList at a specific index
 * arguments: an index int
 * returns:   char that is stored at the index in the list
 * effects:   none
 */
char CharLinkedList::elementAt(int index) const {
    if (index > numItems - 1 or index < 0) {
        std::stringstream ss;
        ss << "index (" << index << ") not in range [0.." << numItems << ")";
        throw range_error(ss.str());
    }
    
    Node *curr = findNode(front, index);
    return curr->character;
}

/*
 * name:      toString
 * purpose:   creates a string from the elements in the CharLinkedList
 * arguments: none
 * returns:   string that states the size and contents of the CharLinkedList
 * effects:   none
 */
std::string CharLinkedList::toString() const {
    std::stringstream ss;
    ss << "[CharLinkedList of size " << size() << " <<";

    for (int i = 0; i < numItems; i++) {
        ss << elementAt(i);
    }

    ss << ">>]";

    return ss.str();
}

/*
 * name:      toReverseString
 * purpose:   creates a string from the elements in reverse in the 
 * CharLinkedList
 * arguments: none
 * returns:   string that states the size and contents, in reverse,
 *            of the CharLinkedList
 * effects:   none
 */
std::string CharLinkedList::toReverseString() const {
    std::stringstream ss;
    ss << "[CharLinkedList of size ";
    ss << size() << " <<";
    for (int i = size() - 1; i > -1; i--) {
        ss << elementAt(i);
    }
    ss << ">>]";
    return ss.str();
}

/*
 * name:      pushAtBack
 * purpose:   adds a char to the back of a CharLinkedList
 * arguments: a char
 * returns:   none
 * effects:   increments numItems, creates a new node which is linked on to the 
 * back of the list
 */
void CharLinkedList::pushAtBack(char c) {
    Node *newNode = new Node;
    newNode->character = c;
    newNode->next = nullptr;
    
    if (front == nullptr) {
        front = newNode;
        back = newNode;
    } else {
        back->next = newNode;
        newNode->prev = back;
        back = newNode;
    }
    numItems++;
}

/*
 * name:      pushAtFront
 * purpose:   adds a char to the front of a CharLinkedList
 * arguments: a char
 * returns:   none
 * effects:   increments numItems, creates a new node which is linked onto the
 * front of the list
 */
void CharLinkedList::pushAtFront(char c) {
    Node *newNode = new Node;
    newNode->character = c;
    newNode->next = nullptr;
    newNode->prev = nullptr;

    if (isEmpty()) {
        front = newNode;
    } else {
        Node *oldFront = front;
        front = newNode;
        newNode->next = oldFront;
        oldFront->prev = front;
    }
    numItems++;
}

/*
 * name:      insertAt
 * purpose:   adds a char at a specific index of a CharLinkedList
 * arguments: a char
 * returns:   none
 * effects:   increments numItems, sets the next pointer of the Node at the 
 * index before and the prev pointer of the Node at the following index to the 
 * new node's address
 */
void CharLinkedList::insertAt(char c, int index) {
    if (index > size() or index < 0) {
        std::stringstream ss;
        ss << "index (" << index << ") not in range [0.." << size() << "]";
        throw range_error(ss.str());
        return;
    } else if (index == size()) {
        pushAtBack(c);
        return;
    } else if (index == 0) {
        pushAtFront(c);
        return;
    } else {
        Node *newNode = new Node;
        newNode->character = c;
        
        Node *curr = findNode(front, index);
        curr->prev->next = newNode;
        newNode->prev = curr->prev;
        curr->prev = newNode;
        newNode->next = curr;
        numItems++;
    }
}

/*
 * name:      insertInOrder
 * purpose:   adds a char to a sorted list in the correct place
 * arguments: a char
 * returns:   none
 * effects:   increments numItems, sets the next pointer of the Node at the 
 * index before and the prev pointer of the Node at the following index to the 
 * new node's address
 */
void CharLinkedList::insertInOrder(char c) {
    if (numItems == 0) {
        pushAtFront(c);
    } else if (c <= elementAt(0)) {
        pushAtFront(c);
    } else if (c >= elementAt(numItems - 1)) {
        pushAtBack(c);        
    } else {
        for (int i = 0; i < numItems; i++) {
            if (c < elementAt(i)) {
                insertAt(c, i);
                return;
            }
        }
    }
}

/*
 * name:      popFromFront
 * purpose:   removes the first element in the list
 * arguments: none
 * returns:   none
 * effects:   decrements numItems, changes the front pointer
 */
void CharLinkedList::popFromFront() {
    if (isEmpty()) {
        std::stringstream ss;
        ss << "cannot pop from empty LinkedList";
        throw runtime_error(ss.str());
    } else if (numItems == 1) {
        delete front;
        front = nullptr;
        back = nullptr;
    } else {
        Node *newFront = front->next;
        delete front;
        front = newFront;
        front->prev = nullptr;
    }
    numItems--;
}

/*
 * name:      popFromBack
 * purpose:   removes the last element in the list
 * arguments: none
 * returns:   none
 * effects:   decrements numItems, recycles memory associated with the deleted
 * object, reassigns back pointer
 */
void CharLinkedList::popFromBack() {
    if (isEmpty()) {
        std::stringstream ss;
        ss << "cannot pop from empty LinkedList";
        throw runtime_error(ss.str());
    } else if (numItems == 1) {
        delete front;
        front = nullptr;
        back = nullptr;
    } else {
        Node *newBack = back->prev;
        delete back;
        newBack->next = nullptr;
        back = newBack;
    }
    numItems--;
}

/*
 * name:      removeAt
 * purpose:   removes the element at a given index in the list
 * arguments: an int index
 * returns:   none
 * effects:   decrements numItems, reassigns the next pointer from the index
 * before and the prev pointer from the following index
 */
void CharLinkedList::removeAt(int index) {
    if (index > size() - 1 or index < 0) {
        std::stringstream ss;
        ss << "index (" << index << ") not in range [0.." << size() << ")";
        throw range_error(ss.str());
    } else if (index == size() - 1) {
        popFromBack();
    } else if (index == 0) {
        popFromFront();
    } else {
        Node *curr = findNode(front, index);
        curr->prev->next = curr->next;
        curr->next->prev = curr->prev;
        delete curr;
        numItems--;
    }
}

/*
 * name:      replaceAt
 * purpose:   replaces the element at a given index in the list
 * arguments: a char to replace, and an index to replace
 * returns:   none
 * effects:   changes the character field of one Node
 */
void CharLinkedList::replaceAt(char c, int index) {
    if (index > size() - 1 or index < 0) {
        std::stringstream ss;
        ss << "index (" << index << ") not in range [0.." << size() << ")";
        throw range_error(ss.str());
    } else {
        Node *curr = findNode(front, index);
        curr->character = c;
    }
}

/*
 * name:      concatenate
 * purpose:   places the contents of another CharLinkedList at the end of the 
 * one where the function is called
 * arguments: a pointer to another CharLinkedList
 * returns:   none
 * effects:   changes the contents of the CharLinkedList, changes numItems
 */
void CharLinkedList::concatenate(CharLinkedList *other) {
    int initSize = other->size();
    for (int i = 0; i < initSize; i++) {
        pushAtBack(other->elementAt(i));
    }
}

/*
 * name:      findNode
 * purpose:   helper function that returns a Node at a given index in the list
 * arguments: a pointer to the front of the list and an int index to look for
 * returns:   a pointer to the Node at the desired index
 * effects:   none
 */
CharLinkedList::Node *CharLinkedList::findNode(Node *curr, int index) const {
    if (index == 0) {
        return curr;
    } else {
        curr = curr->next;
        return findNode(curr, index - 1);
    }
}
/*
 *  unit_tests.h
 *  Theodore Yuan
 *  2/3/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  Defines functions that will serve as tests for various components of the 
 *  CharLinkedList class
 *
 */

#include <cassert>

#include "CharLinkedList.h"

using namespace std;

// Dummy test for the default constructor
void dummy_test() {
    CharLinkedList dummy_list;
    assert(dummy_list.size() == 0);
}

// Test for single char constructor
void single_char_constructor() {
    CharLinkedList test_list('a');
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');
}

// Test for constructor with an array, size and contents should match the array
void given_array_constructor() {
    char test_arr[3] = {'c', 'a', 't'};
    CharLinkedList test_list(test_arr, 3);
    assert(test_list.size() == 3);
    assert(test_list.elementAt(2) == 't');
    assert(test_list.toString() == "[CharLinkedList of size 3 <<cat>>]");

}

// Test for copy constructor with array of size 9, size and contents should
// match
void copy_constructor_test() {
    char test_arr[9] = {'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list1(test_arr, 9);
    CharLinkedList test_list2(test_list1);
    
    assert(test_list2.size() == 9);
    assert(test_list2.toString() == "[CharLinkedList of size 9 <<abczdefgh>>]");
}

// Test for copy constructor when the array being copied is empty
void empty_copy_constructor() {
    CharLinkedList test_list1;
    CharLinkedList test_list2(test_list1);

    assert(test_list2.isEmpty());
    assert(test_list2.toString() == "[CharLinkedList of size 0 <<>>]");
}

// Test for assignment operator, size and contents should match
void assignment_operator_test() {
    char test_arr[9] = {'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list1(test_arr, 9);
    CharLinkedList test_list2 = test_list1;

    assert(test_list2.size() == 9);
    assert(test_list2.toString() == "[CharLinkedList of size 9 <<abczdefgh>>]");
}

// Test for assignment operator when the LinkedList object on the right side is 
// empty
void empty_assignment_operator_test() {
    CharLinkedList test_list1;
    CharLinkedList test_list2 = test_list1;

    assert(test_list2.size() == 0);
    assert(test_list2.isEmpty());
    assert(test_list2.toString() == "[CharLinkedList of size 0 <<>>]");
}

// Test for assignment operator when the LinkedList object on the right side is 
// empty
void nonempty_lhs_assignment_op_test() {
    char test_arr1[9] = {'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h'};
    char test_arr2[5] = {'h','e','l','l','o'};
    CharLinkedList test_list1(test_arr1, 9);
    CharLinkedList test_list2(test_arr2, 5);

    test_list2 = test_list1;

    assert(test_list2.size() == 9);
    assert(test_list2.toString() == "[CharLinkedList of size 9 <<abczdefgh>>]");
}

// Test if isEmpty method works with a nonempty list, return value should be 
// false
void nonempty_isEmpty_test() {
    char test_arr[9] = {'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(test_arr, 9);
    
    assert(not test_list.isEmpty());
}

// Test if isEmpty method works with a empty list, return value should be true
void empty_isEmpty_test() {
    CharLinkedList test_list;
    assert(test_list.isEmpty());
}

// Test if clear method works, should render a nonempty list empty
void clear_test() {
    char test_arr[9] = {'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(test_arr, 9);
    
    test_list.clear();
    assert(test_list.size() == 0);
}

// Test if size method works, should return the correct sizes of CharLinkedLists
void size_test() {
    char test_arr[9] = {'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list1(test_arr, 9);
    CharLinkedList test_list2('a');
    CharLinkedList test_list3;

    assert(test_list1.size() == 9);
    assert(test_list2.size() == 1);
    assert(test_list3.size() == 0);
}

// Test if first method works on a nonempty list, should return the correct 
// first char of CharLinkedLists
void first_test() {
    char test_arr1[9] = {'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list1(test_arr1, 9);
    char test_arr2[8] = {'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list2(test_arr2, 8);

    assert(test_list1.first() == 'a');
    assert(test_list2.first() == 'b');
}

// Test if first method works on an empty list, should throw an exception
void first_on_empty_list() {
    // var to track whether runtime_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
        // call first on empty list
        test_list.first();
    }
    catch (const std::runtime_error &e) {
        // if first is correctly implemented, a runtime_error will be thrown,
        // and we will end up here
        runtime_error_thrown = true;
        error_message = e.what();
    }

    // out here, we make our assertions
    assert(runtime_error_thrown);
    assert(error_message == "cannot get first of empty LinkedList");
}

// Test if last method works on a nonempty list, should return the correct 
// last char of CharLinkedLists
void last_test() {
    char test_arr1[9] = {'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list1(test_arr1, 9);
    char test_arr2[8] = {'b', 'c', 'z', 'd', 'e', 'f', 'g', 'a'};
    CharLinkedList test_list2(test_arr2, 8);

    assert(test_list1.last() == 'h');
    assert(test_list2.last() == 'a');
}

// Test if first method works on an empty list, should throw an exception
void last_on_empty_test() {
    // var to track whether runtime_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
        // call last on empty list
        test_list.last();
    }
    catch (const std::runtime_error &e) {
        // if first is correctly implemented, a runtime_error will be thrown,
        // and we will end up here
        runtime_error_thrown = true;
        error_message = e.what();
    }

    // out here, we make our assertions
    assert(runtime_error_thrown);
    assert(error_message == "cannot get last of empty LinkedList");
}

// Test if elementAt gets the correct element of the list
void elementAt_test() {
    char test_arr1[9] = {'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list1(test_arr1, 9);
    char test_arr2[8] = {'b', 'c', 'z', 'd', 'e', 'f', 'g', 'a'};
    CharLinkedList test_list2(test_arr2, 8);

    assert(test_list1.elementAt(3) == 'z');
    assert(test_list2.elementAt(4) == 'e');
}

// Test if elementAt throws the correct error message when called out of range
// on an empty list
void empty_range_elementAt_test() {
    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
        // insertAt for out-of-range index
        test_list.elementAt(12);
    }
    catch (const std::range_error &e) {
        // if insertAt is correctly implemented, a range_error will be thrown,
        // and we will end up here
        range_error_thrown = true;
        error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (12) not in range [0..0)");
}

// Test if elementAt throws the correct error message when called out of range
// on a nonempty list
void nonEmpty_range_elementAt_test() {
    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    char test_arr[9] = {'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(test_arr, 9);
    try {
        // insertAt for out-of-range index
        test_list.elementAt(12);
    }
    catch (const std::range_error &e) {
        // if insertAt is correctly implemented, a range_error will be thrown,
        // and we will end up here
        range_error_thrown = true;
        error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (12) not in range [0..9)");
}

// toString test, should produce a string with the contents of the list
void toString_test() {
    char test_arr[5] = {'h','e','l','l','o'};
    CharLinkedList test_list(test_arr, 5);

    assert(test_list.toString() == "[CharLinkedList of size 5 <<hello>>]");
}

// toString test on an empty list, should produce message without any contents
// between the <<>>
void empty_toString_test() {
    CharLinkedList test_list;

    assert(test_list.toString() == "[CharLinkedList of size 0 <<>>]");
}

// toReverseString test, should produce a string with the contents of the list
void toReverseString() {
    char test_arr[5] = {'h','e','l','l','o'};
    CharLinkedList test_list(test_arr, 5);

    string message = test_list.toReverseString();
    assert(message == "[CharLinkedList of size 5 <<olleh>>]");
}

// toReverseString test on an empty list, should produce message without any 
// contents between the <<>>
void empty_toReverseString_test() {
    CharLinkedList test_list;

    assert(test_list.toReverseString() == "[CharLinkedList of size 0 <<>>]");
}

// pushAtBack test on an empty list
void empty_pushAtBack_test() {
    CharLinkedList test_list;
    test_list.pushAtBack('a');

    assert(test_list.size() == 1);
    assert(test_list.toString() == "[CharLinkedList of size 1 <<a>>]");
}

// pushAtBack test on nonempty list
void pushAtBack_test() {
    char test_arr[9] = {'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(test_arr, 9);
    test_list.pushAtBack('a');

    assert(test_list.size() == 10);
    string message = test_list.toString();
    assert(message == "[CharLinkedList of size 10 <<abczdefgha>>]");
}

// pushAtFront test on an empty list
void empty_pushAtFront_test() {
    CharLinkedList test_list;
    test_list.pushAtFront('a');

    assert(test_list.size() == 1);
    assert(test_list.toString() == "[CharLinkedList of size 1 <<a>>]");
}

// pushAtBack test on nonempty list
void pushAtFront_test() {
    char test_arr[9] = {'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(test_arr, 9);
    test_list.pushAtFront('a');

    assert(test_list.size() == 10);
    string message = test_list.toString();
    assert(message == "[CharLinkedList of size 10 <<aabczdefgh>>]");
}

// Tests correct insertion into an empty LL.
// Afterwards, size should be 1 and element at index 0
// should be the element we inserted.
void insertAt_empty_correct() {
    CharLinkedList test_list;
    test_list.insertAt('a', 0);
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');
}

// Tests incorrect insertion into an empty LL.
// Attempts to call insertAt for index larger than 0.
// This should result in an std::range_error being raised.
void insertAt_empty_incorrect() {
    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
        // insertAt for out-of-range index
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        // if insertAt is correctly implemented, a range_error will be thrown,
        // and we will end up here
        range_error_thrown = true;
        error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0]");
}

// Tests correct insertAt for front of 1-element list.
void insertAt_front_singleton_list() {
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at front
    test_list.insertAt('b', 0);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'a');
}

// Tests correct insertAt for back of 1-element list.
void insertAt_back_singleton_list() {
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at back
    test_list.insertAt('b', 1);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
}

// Tests calling insertAt for a large number of elements.
// Not only does this test insertAt, it also checks that
// array expansion works correctly.
void insertAt_many_elements() {
    CharLinkedList test_list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.insertAt('a', i);
    }

    assert(test_list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
}

// Tests insertion into front of a larger list
void insertAt_front_large_list() {
    char test_arr[9] = {'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(test_arr, 9);

    test_list.insertAt('y', 0);

    assert(test_list.size() == 10);
    assert(test_list.elementAt(0) == 'y');
    string message = test_list.toString();
    assert(message == "[CharLinkedList of size 10 <<yabczdefgh>>]");
}

// Tests insertion into the back of a larger list
void insertAt_back_large_list() {
    char test_arr[10] = {'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(test_arr, 10);

    test_list.insertAt('x', 10);

    assert(test_list.size() == 11);
    assert(test_list.elementAt(10) == 'x');
    std::string s = test_list.toString();
    assert(s == "[CharLinkedList of size 11 <<yabczdefghx>>]");
}

// Tests insertion into the middle of a larger list
void insertAt_middle_large_list() {
    char test_arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(test_arr, 8);

    test_list.insertAt('z', 3);

    assert(test_list.size() == 9);
    assert(test_list.elementAt(3) == 'z');
    assert(test_list.toString() == "[CharLinkedList of size 9 <<abczdefgh>>]");
}

// Tests out-of-range insertion for a non-empty list.
void insertAt_nonempty_incorrect() {
    char test_arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.insertAt('a', 42);
    } catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8]");
}

// insertInOrder test, tests that a char gets inserted in the correct middle 
// position
void insertInOrder_middle_test() {
    char test_arr[4] = {'a','b','d','e'};
    CharLinkedList test_list(test_arr, 4);

    test_list.insertInOrder('c');
    
    assert(test_list.size() == 5);
    assert(test_list.toString() == "[CharLinkedList of size 5 <<abcde>>]");
}

// insertInOrder test, tests that a char gets inserted in the correct first 
// position
void insertInOrder_first_test() {
    char test_arr[4] = {'b','c','d','e'};
    CharLinkedList test_list(test_arr, 4);

    test_list.insertInOrder('a');
    
    assert(test_list.size() == 5);
    assert(test_list.toString() == "[CharLinkedList of size 5 <<abcde>>]");
}

// insertInOrder test, tests that a char gets inserted in the correct last 
// position
void insertInOrder_last_test() {
    char test_arr[4] = {'a','b','c','d'};
    CharLinkedList test_list(test_arr, 4);

    test_list.insertInOrder('e');
    
    assert(test_list.size() == 5);
    assert(test_list.toString() == "[CharLinkedList of size 5 <<abcde>>]");
}

// popFromFront test on an empty list, should throw the correct exception
void empty_popFromFront_test() {
    // var to track whether runtime_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
        // call popFromFront on empty list
        test_list.popFromFront();
    }
    catch (const std::runtime_error &e) {
        // if first is correctly implemented, a runtime_error will be thrown,
        // and we will end up here
        runtime_error_thrown = true;
        error_message = e.what();
    }

    // out here, we make our assertions
    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

// popFromFront on non empty list, should remove the first element in the list
void popFromFront_test() {
    char test_arr[5] = {'h','e','l','l','o'};
    CharLinkedList test_list(test_arr, 5);

    test_list.popFromFront();

    assert(test_list.size() == 4);
    assert(test_list.toString() == "[CharLinkedList of size 4 <<ello>>]");
}

// popFromBack test on an empty list, should throw the correct exception
void empty_popFromBack_test() {
    // var to track whether runtime_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
        // call popFromBack on empty list
        test_list.popFromBack();
    }
    catch (const std::runtime_error &e) {
        // if first is correctly implemented, a runtime_error will be thrown,
        // and we will end up here
        runtime_error_thrown = true;
        error_message = e.what();
    }

    // out here, we make our assertions
    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

// popFromBack on non empty list multiple times, should remove the last element 
// in the list
void popFromBack_multiple_test() {
    char test_arr[5] = {'h','e','l','l','o'};
    CharLinkedList test_list(test_arr, 5);

    test_list.popFromBack();
    test_list.popFromBack();
    test_list.popFromBack();
    test_list.popFromBack();
    test_list.popFromBack();

    assert(test_list.size() == 0);
    assert(test_list.toString() == "[CharLinkedList of size 0 <<>>]");
}

// Test if popFromBack methods works, should remove the last element in the list
void popFromBack_test() {
    char test_arr[9] = {'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(test_arr, 9);
    test_list.popFromBack();

    assert(test_list.size() == 8);
    assert(test_list.toString() == "[CharLinkedList of size 8 <<abczdefg>>]");
}

// removeAt test from an empty list, should throw the correct exception
void empty_removeAt_test() {
    CharLinkedList test_list;

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.removeAt(42);
    } catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0)");   
}

// removeAt test from an empty list, should throw the correct exception
void range_error_removeAt_test() {
    char test_arr[5] = {'h','e','l','l','o'};
    CharLinkedList test_list(test_arr, 5);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.removeAt(42);
    } catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..5)");   
}

// removeAt test, should remove the correct element
void removeAt_test() {
    char test_arr[5] = {'h','e','l','l','o'};
    CharLinkedList test_list(test_arr, 5);

    test_list.removeAt(1);

    assert(test_list.size() == 4);
    assert(test_list.toString() == "[CharLinkedList of size 4 <<hllo>>]");   
}

// replaceAt test for when there is a range error, should throw the correct 
// exception
void range_error_replaceAt_test() {
    char test_arr[5] = {'h','e','l','l','o'};
    CharLinkedList test_list(test_arr, 5);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.replaceAt('a', 42);
    } catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..5)");
}

// replaceAt test, should correctly replace the element in the list
void replaceAt_test() {
    char test_arr[5] = {'h','e','l','l','o'};
    CharLinkedList test_list(test_arr, 5);

    test_list.replaceAt('p', 4);

    assert(test_list.size() == 5);
    assert(test_list.toString() == "[CharLinkedList of size 5 <<hellp>>]");   
}

// standard concat test, where a different LinkedList is used as parameter
void standard_concat_test() {
    char test_arr1[5] = {'h','e','l','l','o'};
    char test_arr2[3] = {'c','a','t'};
    
    CharLinkedList test_list1(test_arr1, 5);
    CharLinkedList test_list2(test_arr2, 3);

    test_list1.concatenate(&test_list2);

    assert(test_list1.size() == 8);
    assert(test_list1.toString() == "[CharLinkedList of size 8 <<hellocat>>]");
}

// empty concat test, where an empty Array list is used as the parameter and 
// called on another LinkedList
void empty_concat_test() {
    char test_arr1[5] = {'h','e','l','l','o'};
    
    CharLinkedList test_list1(test_arr1, 5);
    CharLinkedList test_list2;

    test_list1.concatenate(&test_list2);

    assert(test_list1.size() == 5);
    assert(test_list1.toString() == "[CharLinkedList of size 5 <<hello>>]");   
}

// self concat test, where the same LinkedList is used as a parameter and called
// on itself
void self_concat_test() {
    char test_arr1[5] = {'h','e','l','l','o'};
    
    CharLinkedList test_list1(test_arr1, 5);

    test_list1.concatenate(&test_list1);

    assert(test_list1.size() == 10);
    std::string s = test_list1.toString();
    assert(s == "[CharLinkedList of size 10 <<hellohello>>]");
}

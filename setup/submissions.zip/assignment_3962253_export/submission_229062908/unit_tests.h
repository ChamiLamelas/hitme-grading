/*
 *  unit_tests.h
 *  Henri Comer
 *  02/02
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  FILE PURPOSE HERE
 *
 */
#include "CharLinkedList.h"
#include <cassert>
#include <string>

// Tests correct size initialization after construction
void constructor_test_1() {
    CharLinkedList test_list;
    assert(test_list.size() == 0);
}

// Tests size and content after single character construction 
void constructor_test_2() {
    CharLinkedList test_list('a');
    assert(test_list.size() == 1);
    assert(test_list.first() == 'a');
}

// Tests that the constructor properly copies the inputted list
void constructor_test_3() {
    char arr[] = {'a','b','c','d'};
    CharLinkedList test_list(arr, 4);
        
    assert(test_list.first() == 'a');
    assert(test_list.last() == 'd');
}

// Tests the copy constructor
void copy_constructor_test() {
    char arr[] = {'a','b','c','d'};
    CharLinkedList test_list(arr, 4);

    CharLinkedList test_list2(test_list);
    
    assert(test_list.size() == test_list2.size());
}

// Tests the assignment operator
void assignment_operator_test() {
    char arr[] = {'a','b','c','d'};
    CharLinkedList test_list(arr, 4);

    CharLinkedList test_list2 = test_list;

    assert(test_list.size() == test_list2.size());
}

// Make sure we report an empty list correctly.
void isEmpty_test() {
    CharLinkedList test_list;
    assert(test_list.isEmpty());
}

// Tests clear method
void clear_test() {
    char arr[] = {'a','b','c','d'};
    CharLinkedList test_list(arr, 4);

    test_list.clear();
    assert(test_list.isEmpty());
}

// Tests first method and proper error message on empty list
void first_test() {
    char arr[] = {'a','b','c','d'};
    CharLinkedList test_list(arr, 4);
    assert(test_list.first() == 'a');

    bool runtime_error_thrown = false;
    std::string error_message = "";

    test_list.clear();
    try {
        test_list.first();
    } catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot get first of empty LinkedList");
}

// Tests last method and proper error message on empty list
void last_test() {
    char arr[] = {'a','b','c','d'};
    CharLinkedList test_list(arr, 4);
    assert(test_list.last() == 'd');

    bool runtime_error_thrown = false;
    std::string error_message = "";

    test_list.clear();
    try {
        test_list.last();
    } catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot get last of empty LinkedList");
}



// Tests elementAt method
void elementAt_test() {
    char arr[] = {'a','b','c','d'};
    CharLinkedList test_list(arr, 4);
    assert(test_list.elementAt(2) == 'c');
    assert(test_list.elementAt(0) == 'a');  
    assert(test_list.elementAt(3) == 'd');  
}

// Tests error cases and messages for elementAt
void elementAt_incorrect_test() {
    char arr[] = {'a','b','c','d'};
    CharLinkedList test_list(arr, 4);

    bool range_error_thrown = false;
    std::string error_message = "";

    try {
        test_list.elementAt(4);
    } catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (4) not in range [0..4)");

    range_error_thrown = false; 

    try {
        test_list.elementAt(-1);
    } catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (-1) not in range [0..4)");

    test_list.clear();
    bool runtime_error_thrown = false;
    try {
        test_list.elementAt(0);
    } catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot get element of empty LinkedList");
}


// Tests toString function
void toString_test() {
    char arr[] = {'a','b','c','d'};
    CharLinkedList test_list(arr, 4);
    assert(test_list.toString() == "[CharLinkedList of size 4 <<abcd>>]");

    test_list.clear();
    assert(test_list.toString() == "[CharLinkedList of size 0 <<>>]");
}

// Tests toReverseString function
void toReverseString_test() {
    char arr[] = {'a','b','c','d'};
    CharLinkedList test_list(arr, 4);
    std::string str = "[CharLinkedList of size 4 <<dcba>>]";
    assert(test_list.toReverseString() == str);

    test_list.clear();
    assert(test_list.toReverseString() == "[CharLinkedList of size 0 <<>>]");
}

// Tests correct insertion into an empty AL.
// Afterwards, size should be 1 and element at index 0
// should be the element we inserted.
void insertAt_empty_correct() { 

    CharLinkedList test_list;
    test_list.insertAt('a', 0);
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');

}

// Tests incorrect insertion into an empty AL.
// Attempts to call insertAt for index larger than 0.
// This should result in an std::range_error being raised.
void insertAt_empty_incorrect() {

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    // insertAt for out-of-range index
    test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
    // if insertAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    range_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0]");
    
}

// Tests correct insertAt for front of 1-element list.
void insertAt_front_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at front
    test_list.insertAt('b', 0);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'a');
    
}

// Tests correct insertAt for back of 1-element list.
void insertAt_back_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at back
    test_list.insertAt('b', 1);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    
}

// Tests calling insertAt for a large number of elements.
// Not only does this test insertAt, it also checks that
// array expansion works correctly.
void insertAt_many_elements() {
    
    CharLinkedList test_list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.insertAt('a', i);
    }

    assert(test_list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
    
}

// Tests insertion into front of a larger list
void insertAt_front_large_list() {
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);
    std::string str = "[CharLinkedList of size 10 <<yabczdefgh>>]";

    test_list.insertAt('y', 0);

    assert(test_list.size() == 10);
    assert(test_list.elementAt(0) == 'y');
    assert(test_list.toString() == str);

}

// Tests insertion into the back of a larger list
void insertAt_back_large_list() {

    char test_arr[10] = { 'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 10);  
    std::string str = "[CharLinkedList of size 11 <<yabczdefghx>>]";

    test_list.insertAt('x', 10);

    assert(test_list.size() == 11);
    assert(test_list.elementAt(10) == 'x');
    assert(test_list.toString() == str); 

}

// Tests insertion into the middle of a larger list
void insertAt_middle_large_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.insertAt('z', 3);

    assert(test_list.size() == 9);
    assert(test_list.elementAt(3) == 'z');
    assert(test_list.toString() == "[CharLinkedList of size 9 <<abczdefgh>>]");

}

// Tests out-of-range insertion for a non-empty list.
void insertAt_nonempty_incorrect() {
   
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8]");
    
}

// Tests pushAtBack method
void pushAtBack_test() {
    CharLinkedList test_list;
    test_list.pushAtBack('a');
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');

    test_list.pushAtBack('b');
    assert(test_list.toString() == "[CharLinkedList of size 2 <<ab>>]");
}

// Tests pushAtFront method
void pushAtFront_test() {
    CharLinkedList test_list;
    test_list.pushAtFront('a');
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');

    test_list.pushAtFront('b');
    assert(test_list.toString() == "[CharLinkedList of size 2 <<ba>>]");
}


// Tests insertInOrder method
void insertInOrder_test() {
    char arr[] = {'a','b','c','d'};
    CharLinkedList test_list(arr, 4);

    test_list.insertInOrder('z');
    assert(test_list.toString() == "[CharLinkedList of size 5 <<abcdz>>]");

    test_list.insertInOrder('c');
    assert(test_list.toString() == "[CharLinkedList of size 6 <<abccdz>>]");

    test_list.insertInOrder('a');
    assert(test_list.toString() == "[CharLinkedList of size 7 <<aabccdz>>]");

    test_list.clear();
    test_list.insertInOrder('z');
    assert(test_list.toString() == "[CharLinkedList of size 1 <<z>>]");
}


// Tests popFromFront method
void popFromFront_test() {
    CharLinkedList test_list;

    bool runtime_error_thrown = false;
    std::string error_message = "";
    try {
        test_list.popFromFront();
    } catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");

    test_list.pushAtBack('a');
    test_list.pushAtBack('b');
    test_list.pushAtBack('c');

    test_list.popFromFront();
    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'c');
}

// Tests popFromBack method
void popFromBack_test() {
    CharLinkedList test_list;

    bool runtime_error_thrown = false;
    std::string error_message = "";
    try {
        test_list.popFromBack();
    } catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");

    test_list.pushAtBack('a');
    test_list.pushAtBack('b');
    test_list.pushAtBack('c');

    test_list.popFromBack();
    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
}

// Tests removal of an element from the front of the list
void removeAt_front_test() {
    char arr[] = {'a','b','c','d','e'};
    CharLinkedList test_list(arr, 5);

    test_list.removeAt(0);
    assert(test_list.size() == 4);
    assert(test_list.toString() == "[CharLinkedList of size 4 <<bcde>>]");
}

// Tests removal of an element from the middle of the list
void removeAt_middle_test() {
    char arr[] = {'a','b','c','d','e'};
    CharLinkedList test_list(arr, 5);

    test_list.removeAt(2);
    assert(test_list.size() == 4);
    assert(test_list.toString() == "[CharLinkedList of size 4 <<abde>>]");
}

// Tests removal of an element from the end of the list
void removeAt_end_test() {
    char arr[] = {'a','b','c','d','e'};
    CharLinkedList test_list(arr, 5);

    test_list.removeAt(4);
    assert(test_list.size() == 4);
    assert(test_list.toString() == "[CharLinkedList of size 4 <<abcd>>]");
}

// Tests removal from an empty list
void removeAt_empty_list_test() {
    CharLinkedList test_list;

    bool range_error_thrown = false;
    std::string error_message = "";

    try {
        test_list.removeAt(0);
    } catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (0) not in range [0...0)");
}

// Tests removal with out-of-range index
void removeAt_out_of_range_test() {
    char arr[] = {'a','b','c','d','e'};
    CharLinkedList test_list(arr, 5);

    bool range_error_thrown = false;
    std::string error_message = "";

    try {
        test_list.removeAt(10);
    } catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (10) not in range [0...5)");
}


// Test functionnality of replaceAt function
void replaceAt_test() {
    char arr[] = {'a','b','c','d','e'};
    CharLinkedList test_list(arr, 5);
    test_list.replaceAt('b', 0);
    assert(test_list.elementAt(0) == 'b');

    test_list.replaceAt('z', 2);
    assert(test_list.elementAt(2) == 'z');

    
    test_list.replaceAt('z', 4);
    assert(test_list.elementAt(4) == 'z');
    assert(test_list.toString() == "[CharLinkedList of size 5 <<bbzdz>>]");
}

// Test replacing with an out-of-range index
void replaceAt_out_of_range_test() {
    CharLinkedList test_list('a');
    bool range_error_thrown = false;
    try {
        test_list.replaceAt('b', 1);
    } catch (const std::range_error &e) {
        range_error_thrown = true;
    }
    assert(range_error_thrown);
}

// Test replacing with an empty list
void replaceAt_empty_list_test() {
    CharLinkedList test_list;
    bool range_error_thrown = false;
    try {
        test_list.replaceAt('b', 0);
    } catch (const std::range_error &e) {
        range_error_thrown = true;
    }
    assert(range_error_thrown);
}

// Test replacing with a negative index
void replaceAt_negative_index_test() {
    char arr[] = {'a','b','c','d','e'};
    CharLinkedList test_list(arr, 5);
    bool range_error_thrown = false;
    try {
        test_list.replaceAt('z', -1);
    } catch (const std::range_error &e) {
        range_error_thrown = true;
    }
    assert(range_error_thrown);
}

// Test replacing with an index equal to the size of the list
void replaceAt_index_equal_to_size_test() {
    char arr[] = {'a','b','c','d','e'};
    CharLinkedList test_list(arr, 5);
    bool range_error_thrown = false;
    try {
        test_list.replaceAt('z', 5);
    } catch (const std::range_error &e) {
        range_error_thrown = true;
    }
    assert(range_error_thrown);
}

// Test concatenating two non-empty lists
void concatenate_test() {
    char arr[] = {'a','b','c','d'};
    CharLinkedList test_list(arr, 4);

    char arr2[] = {'c','a','t'};
    CharLinkedList test_list2(arr2, 3);
    test_list.concatenate(&test_list2);

    assert(test_list.toString() == "[CharLinkedList of size 7 <<abcdcat>>]");
}

// Test concatenating with an empty list
void concatenate_empty_test() {
    char arr[] = {'c','a','t'};
    CharLinkedList test_list(arr, 3);
    CharLinkedList test_list2;

    test_list.concatenate(&test_list2);

    assert(test_list.toString() == "[CharLinkedList of size 3 <<cat>>]");
}

// Test concatenating an empty list with a non-empty list
void concatenate_empty_first_test() {
    CharLinkedList test_list;
    char arr[] = {'c','a','t'};
    CharLinkedList test_list2(arr, 3);

    test_list.concatenate(&test_list2);

    assert(test_list.toString() == "[CharLinkedList of size 3 <<cat>>]");
}

// Test concatenating a list with itself
void concatenate_self_test() {
    char arr[] = {'c','a','t'};
    CharLinkedList test_list(arr, 3);

    test_list.concatenate(&test_list);

    assert(test_list.toString() == "[CharLinkedList of size 6 <<catcat>>]");
}

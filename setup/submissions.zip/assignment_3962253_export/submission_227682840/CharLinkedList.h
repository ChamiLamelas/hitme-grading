/*
 *  CharLinkedList.h
 *  Emily Nicholas
 *  January 30, 2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Purpose: contains class definition for the linked list
 *
 */

#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H
#include <string>
#include <iostream>

class CharLinkedList {
public:
    //constructors and destructors
    CharLinkedList();
    ~CharLinkedList();
    CharLinkedList(char c);
    CharLinkedList(char arr[], int size);
    CharLinkedList(const CharLinkedList &other);

    //assignment operator
    CharLinkedList& operator=(const CharLinkedList &other);

    //public methods
    int size() const;
    char elementAt(int index) const;
    bool isEmpty() const;
    char first() const;
    char last() const;
    void clear();
    void pushAtFront(char c);
    void pushAtBack(char c);
    void popFromFront();
    void popFromBack();
    void removeAt(int index);
    void replaceAt(char c, int index);
    std::string toString() const;
    std::string toReverseString() const;
    void insertAt(char c, int index);
    void insertInOrder(char c);
    void concatenate(CharLinkedList *other); 

private:
    //private member variables
    struct Node {
        char data;
        Node *next;
        Node *before;
    };
    Node *front;
    int numCharacters;

    //private methods
    void recycleRecursive(Node *curr);
    Node *newNode(char data, Node *next, Node *before);
    Node *elementAtHelper(Node *curr, int index) const;
    Node *replaceAtHelper(Node *curr, int index) const;
    
};

#endif

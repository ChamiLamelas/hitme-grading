/*
 *  unit_tests.h
 *  Emily Nicholas
 *  January 30, 2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  Purpose: performs several tests to check the functionality of 
 *           methods in the linked list class.
 *
 */

#include "CharLinkedList.h"
#include <cassert>

// checks to make sure class definition is syntactically correct before 
// starting any other functions
void dummy_test() {

}

//check to see that first constructor correctly initializes an empty
//linked list checking that its size is 0 and that its empty
void constructor_test1() {
    CharLinkedList list;
    assert(list.size() == 0);
    assert(list.isEmpty());
}

//checks to see that the second constructor correctly initializes a
//linked list with one element in it and makes sure the size is 1 and
//the element corresponds. Also that it is not empty
void contructor_test2() {
    CharLinkedList list('a');
    assert(list.size() == 1);
    assert(list.elementAt(0) == 'a');
    assert(not list.isEmpty());
}

//checks to see that the third constructor correctly initializes a 
//linked list with multiple elements
void constructor_test3() {
    char list[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(list, 9);
    assert(test_list.size() == 9);
    assert(not test_list.isEmpty());
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(3) == 'z');
    assert(test_list.elementAt(8) == 'h');
}

// checks to see that the destructor gets automatically called and 
// properly deallocates memory
void check_destructor() {
    CharLinkedList list('a');
    assert(true);
}

// check to see if the fourth constructor works; elements from the 
// referenced array should match
void check_fourth_constructor() {
    CharLinkedList original;
    original.insertAt('r', 0);
    original.insertAt('e', 1);
    original.insertAt('d', 2);

    CharLinkedList copy(original);
    assert(copy.size() == original.size());
    assert(copy.elementAt(0) == original.elementAt(0));
    assert(copy.last() == original.last());
}

//check that copy constructor works even if the other is empty
void check_fourth_constructor_empty() {
    CharLinkedList original;
    CharLinkedList copy(original);
    assert(copy.size() == original.size());
    assert(copy.isEmpty());
}

//ASSIGNMENT OPERATOR TESTS

//checking to see if assignment operator successfully changes 
//elements of list1 to those of list2
void check_assignment_operator() {
    char list_one[3] = { 'o', 'n', 'e'};
    CharLinkedList list1(list_one, 3);
    char list_two[3] = { 't', 'w', 'o'};
    CharLinkedList list2(list_two, 3);

    list1 = list2;
    assert(list1.elementAt(0) == 't');
    assert(list1.elementAt(1) == 'w');
    assert(list1.elementAt(2) == 'o');
    assert(list2.elementAt(0) == 't');
    assert(list2.elementAt(1) == 'w');
    assert(list2.elementAt(2) == 'o');
}

// checking to see if assignment operator successfully works 
// when elements in list1 and list 2 are the same
void check_assignment_operator_same() {
    char list_one[3] = { 't', 'w', 'o'};
    CharLinkedList list1(list_one, 3);
    char list_two[3] = { 't', 'w', 'o'};
    CharLinkedList list2(list_two, 3);

    list1 = list2;
    assert(list1.elementAt(0) == 't');
    assert(list1.elementAt(1) == 'w');
    assert(list1.elementAt(2) == 'o');
    assert(list2.elementAt(0) == 't');
    assert(list2.elementAt(1) == 'w');
    assert(list2.elementAt(2) == 'o');
    assert(list1.size() == 3);
    assert(list2.size() == 3);
}

// checking to see if assignment operator successfully works 
// when they are one element lists
void check_assignment_operator_one_element() {
    char list_one[1] = {'o'};
    CharLinkedList list1(list_one, 1);
    char list_two[1] = {'o'};
    CharLinkedList list2(list_two, 1);

    list1 = list2;
    assert(list1.elementAt(0) == 'o');

    assert(list2.elementAt(0) == 'o');

    assert(list1.size() == 1);
    assert(list2.size() == 1);
}

//checks to see that the assignment operator works for 
//lists of different sizes
void check_assignment_operator_differentListSize() {
    char list_one[3] = {'t', 'w', 'o'};
    CharLinkedList list1(list_one, 3);
    char list_two[4] = {'t', 'w', 'o', 'o'};
    CharLinkedList list2(list_two, 4);

    list1 = list2;
    assert(list1.elementAt(0) == 't');
    assert(list1.elementAt(0)== list2.elementAt(0));
    assert(list1.elementAt(1)== list2.elementAt(1));
    assert(list1.elementAt(2)== list2.elementAt(2));
    assert(list1.elementAt(3)== list2.elementAt(3));
    assert(list1.size() == list2.size());
}

//checks that assignment operator works when the list1 starts off
//empty and then gains values of list 2
void check_assignment_operator_emptyList1() {
    char list_one[0];
    CharLinkedList list1(list_one, 0);
    char list_two[1] = {'o'};
    CharLinkedList list2(list_two, 1);

    list1 = list2;
    assert(list1.elementAt(0) == 'o');

    assert(list2.elementAt(0) == 'o');

    assert(list1.size() == 1);
    assert(list2.size() == 1);
}

//checks that assignment operator works when the list being copied into
//the new instance is empty
void check_assignment_operator_emptyList2() {
    char list_one[1] = {'o'};
    CharLinkedList list1(list_one, 1);
    char list_two[0];
    CharLinkedList list2(list_two, 0);

    list1 = list2;
    assert(list1.isEmpty());
    assert(list2.isEmpty());

    assert(list1.size() == 0);
    assert(list2.size() == 0);
}

//FIRST TESTS

//checks that the first character of a one element list matches
void first_oneElement() {
    CharLinkedList list('a');
    assert(list.first() == 'a');
}

//checks that the first character of a one element list matches
void first_multiElement() {
    char list[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(list, 9);
    assert(test_list.first() == 'a');
}

// checks that when the first function is called on an empty
// array, it throws a runtime error with the right message
void check_firstElement_emptyList() {
    // var to track whether runtime_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    test_list.first();
    }
    catch (const std::runtime_error &e) {
    // if last is correctly implemented, a runtime_error will be thrown,
    // and we will end up here
    runtime_error_thrown = true;
    error_message = e.what();
    }
    // out here, we make our assertions
    assert(runtime_error_thrown);
    assert(error_message == "cannot get first of empty LinkedList");
}

//LAST TESTS

//checks that the last character of a one element list matches
void last_oneElement() {
    CharLinkedList list('a');
    assert(list.last() == 'a');
}

//checks that the last character of a one element list matches
void last_multiElement() {
    char list[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(list, 9);
    assert(test_list.last() == 'h');
}

// checks that when the last function is called on an empty
// array, it throws a runtime error with the right message
void check_lastElement_emptyList() {
    // var to track whether runtime_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    test_list.last();
    }
    catch (const std::runtime_error &e) {
    // if last is correctly implemented, a runtime_error will be thrown,
    // and we will end up here
    runtime_error_thrown = true;
    error_message = e.what();
    }
    // out here, we make our assertions
    assert(runtime_error_thrown);
    assert(error_message == "cannot get last of empty LinkedList");
}

//CLEAR TESTS

//checks to see that you can clear a one element list so that it is empty 
//and the size is zero
void clear_oneElement() {
    CharLinkedList list('a');
    list.clear();
    assert(list.size() == 0);
    assert(list.isEmpty());
}

//checks to see that you can clear a multi element list so that it is empty 
//and the size is zero
void clear_multiElement() {
    char list[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(list, 9);
    test_list.clear();
    assert(test_list.size() == 0);
    assert(test_list.isEmpty());
}

//checks to see that you can clear an empty element list so that it is empty 
//and the size is zero
void clear_emptyList() {
    CharLinkedList list;
    list.clear();
    assert(list.size() == 0);
    assert(list.isEmpty());
}

//PUSH AT FRONT TESTS

//checks that you can put an element at the front of the empty list; the 
//size should change to one and the element should correspond to the 
//element you wanted in the parameter
void pushAtFront_emptyList() {
    CharLinkedList list;
    list.pushAtFront('h');
    assert(list.size() == 1);
    assert(not list.isEmpty());
    assert(list.elementAt(0) == 'h');
}

//checks that you can put an element at the front of a one element list; 
//the size should change to two and the element at index 0 should correspond
// to the element you wanted in the parameter
void pushAtFront_oneElement() {
    CharLinkedList list('j');
    list.pushAtFront('r');
    assert(list.size() == 2);
    assert(list.elementAt(0) == 'r');
    assert(list.elementAt(1) == 'j');
}

//checks that you can put an element at the front of a multi element list; 
//the size should increment by 1 and the element at index 0 should correspond
// to the element you wanted in the parameter
void pushAtFront_multiElement() {
    char list[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(list, 9);
    test_list.pushAtFront('q');
    assert(test_list.size() == 10);
    assert(test_list.elementAt(0) == 'q');
}

//PUSH AT BACK TESTS

//checks that you can put an element at the back of the empty list; the 
//size should change to one and the element should correspond to the 
//element you wanted in the parameter
void pushAtBack_emptyList() {
    CharLinkedList list;
    list.pushAtBack('h');
    assert(list.size() == 1);
    assert(not list.isEmpty());
    assert(list.elementAt(0) == 'h');
}


// checks that you can put an element at the back of a one element list; 
// the size should change to two and the element at index 0 should correspond
// to the element you wanted in the parameter
void pushAtBack_oneElement() {
    CharLinkedList list('j');
    list.pushAtBack('r');
    assert(list.size() == 2);
    assert(list.elementAt(0) == 'j');
    assert(list.elementAt(1) == 'r');
}

//checks that you can put an element at the back of a multi element list; 
// the size should change and the element at index 0 should correspond
// to the element you wanted in the parameter
void pushAtBack_multiElement() {
    char list[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(list, 9);
    test_list.pushAtBack('v');
    assert(test_list.size() == 10);
    assert(test_list.elementAt(9) == 'v');
}

//ELEMENT AT TESTS

//check to see that if asked to retrieve and element greater than the size
//a range error message gets thrown
void elementAt_nonempty_incorrect_larger() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.elementAt(16);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (16) not in range [0..8)");
}

// check to see that if asked to retrieve and element less than the 0
// a range error message gets thrown
void elementAt_nonempty_incorrect_negative() {
   
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.elementAt(-3);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (-3) not in range [0..8)");
}

// makes sure no range error is thrown when the index is 0
void elementAt_0() {
    CharLinkedList list('a');
    assert(list.elementAt(0) == 'a');
}

// makes sure no range error is thrown when the index of the last
// element is chosen
void elementAt_lastElement() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);
    assert(test_list.elementAt(7) == 'h');
}

//makes sure that you cannot access an element of an empty array
void elementAt_empty_incorrect() {

    bool range_error_thrown = false;

    std::string error_message = "";

    CharLinkedList test_list;
    try {
    // insertAt for out-of-range index
    test_list.elementAt(42);
    }
    catch (const std::range_error &e) {

    range_error_thrown = true;
    error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0)");   
}

//makes sure that you cannot access an element in index 0 of an empty array
void elementAt_empty_incorrect_index0() {

    bool range_error_thrown = false;

    std::string error_message = "";

    CharLinkedList test_list;
    try {

    test_list.elementAt(0);
    }
    catch (const std::range_error &e) {

    range_error_thrown = true;
    error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (0) not in range [0..0)");   
}

//TO STRING TESTS

//checks to see if it returns the correct string of characters
//for a one element list
void test_toString_oneElement() {
    CharLinkedList list('k');
    std::string output = list.toString();
    assert(output == "[CharLinkedList of size 1 <<k>>]");
}

// checks to see if it returns the correct string of characters
// for a multi element list
void test_toString_multiElement() {
    char test_arr[9] = { 'e', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);
    std::string output = test_list.toString();
    assert(output == "[CharLinkedList of size 9 <<ebczdefgh>>]");
}

// checks to see if it returns the correct string of characters
// for an empty element list
void test_toString_empty() {
    CharLinkedList list;
    std::string output = list.toString();
    assert(output == "[CharLinkedList of size 0 <<>>]");
}

//TO REVERSE STRING TESTS

//checks to see if it returns the correct string of characters
//in reverse for a one element list
void test_toString_reverse_oneElement() {
    CharLinkedList list('k');
    std::string output = list.toReverseString();
    assert(output == "[CharLinkedList of size 1 <<k>>]");
}

// checks to see if it returns the correct string of characters
// in reverse for a multi element list
void test_toString_reverse_multiElement() {
    char test_arr[9] = { 'e', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);
    std::string output = test_list.toReverseString();
    assert(output == "[CharLinkedList of size 9 <<hgfedzcbe>>]");
}

// checks to see if it returns the correct string of characters
// in reverse for an empty element list
void test_toString_reverse_empty() {
    CharLinkedList list;
    std::string output = list.toReverseString();
    assert(output == "[CharLinkedList of size 0 <<>>]");
}

//INSERT AT TESTS

//Tests correct insertion into an empty list.
//Afterwards, size should be 1 and element at index 0
//should be the element we inserted.
void insertAt_empty_correct() { 
    CharLinkedList test_list;
    test_list.insertAt('a', 0);
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');
}

// Tests incorrect insertion into an empty list.
// Attempts to call insertAt for index larger than 0.
// This should result in an std::range_error being raised.
void insertAt_empty_incorrect() {
    // var to track whether range_error is thrown
    bool range_error_thrown = false;
    // var to track any error messages raised
    std::string error_message = "";
    CharLinkedList test_list;
    try {
    // insertAt for out-of-range index
    test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
    // if insertAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    range_error_thrown = true;
    error_message = e.what();
    }
    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0]");
}

// Tests correct insertAt for front of 1-element list.
void insertAt_front_singleton_list() {
    CharLinkedList test_list('a');
    test_list.insertAt('b', 0);
    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'a');
}

// Tests correct insertAt for back of 1-element list.
void insertAt_back_singleton_list() {
    CharLinkedList test_list('a');
    test_list.insertAt('b', 1);
    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
}

// Tests calling insertAt for a large number of elements.
// Not only does this test insertAt, it also checks that
// array expansion works correctly.
void insertAt_many_elements() {
    CharLinkedList test_list;
    for (int i = 0; i < 1000; i++) {
        test_list.insertAt('a', i);
    }
    assert(test_list.size() == 1000);
    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
}

//Tests insertion into front of a larger list
void insertAt_front_large_list() {
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);
    test_list.insertAt('y', 0);
    assert(test_list.size() == 10);
    assert(test_list.elementAt(0) == 'y');
    assert(test_list.toString() ==     
    "[CharLinkedList of size 10 <<yabczdefgh>>]");
}

// Tests insertion into the back of a larger list
void insertAt_back_large_list() {
    char test_arr[10] = { 'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 10);  
    test_list.insertAt('x', 10);
    assert(test_list.size() == 11);
    assert(test_list.elementAt(10) == 'x');
    assert(test_list.toString() == 
    "[CharLinkedList of size 11 <<yabczdefghx>>]"); 
}

//Tests insertion into the middle of a larger list
void insertAt_middle_large_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);
    test_list.insertAt('z', 3);
    assert(test_list.size() == 9);
    assert(test_list.elementAt(3) == 'z');
    assert(test_list.toString() ==     
    "[CharLinkedList of size 9 <<abczdefgh>>]");
}

// Tests out-of-range insertion for a non-empty list.
void insertAt_nonempty_incorrect() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);
    // var to track whether range_error is thrown
    bool range_error_thrown = false;
    // var to track any error messages raised
    std::string error_message = "";
    try {
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8]");
}


//POP FROM FRONT TESTS

//tests to make sure an error is thrown when you try to remove the 
//first element of an empty list
void popFromFront_emptyList() {

    // var to track whether runtime_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    test_list.popFromFront();
    }
    catch (const std::runtime_error &e) {

    runtime_error_thrown = true;
    error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

// tests to see that when an element is removed from the front 
// of a one element list, it becomes empty
void popFromFront_oneElement() {
    CharLinkedList list('l');
    list.popFromFront();
    assert(list.size() == 0);
    assert(list.isEmpty());
}

// makes sure that you can remove first element of a multi
// element list and the size decreases as expected
void popFromFront_multiElement() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);
    test_list.popFromFront();
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'c');
    assert(test_list.elementAt(6) == 'h');
    assert(test_list.size() == 7);
}

//POP FROM BACK TESTS:

//tests to make sure an error is thrown when you try to remove the 
//last element of an empty list
void popFromBack_emptyList() {

    // var to track whether runtime_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    test_list.popFromBack();
    }
    catch (const std::runtime_error &e) {

    runtime_error_thrown = true;
    error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

// tests to see that when an element is removed from the back 
// of a one element list, it becomes empty
void popFromBack_oneElement() {
    CharLinkedList list('l');
    list.popFromBack();
    assert(list.size() == 0);
    assert(list.isEmpty());
}

// checks to see that you can remove the element from the 
// back of a multi element list
void popFromBack_multiElement() {
    char test_arr[3] = { 'c' , 'a' , 'r'};
    CharLinkedList test_list(test_arr, 3);
    test_list.popFromBack();
    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'c');
    assert(test_list.elementAt(1) == 'a');
}

//REMOVE TESTS:
//checks to see if the element of a one element list is 
//successfully removed
void remove_one_element() {
    CharLinkedList list('a');
    list.removeAt(0);
    assert(list.size() == 0);
    assert(list.isEmpty());
}

// checks to see that you can remove an element from the middle
// of a multi element list
void remove_multiElement_middle() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);
    test_list.removeAt(2);
    assert(test_list.elementAt(2) == 'd');
    assert(test_list.elementAt(1) == 'b');
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(3) == 'e');
    assert(test_list.size() == 7);
}

// checks to see if it can successfully remove and element in 
// the front of a multi element list
void remove_multiElement_front() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);
    test_list.removeAt(0);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'c');
    assert(test_list.size() == 7);
}

// checks to see if it can successfully remove an element in the back
// of a multi element list
void remove_multiElement_back() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);
    test_list.removeAt(7);
    assert(test_list.elementAt(6) == 'g');
    assert(test_list.size() == 7);
}

// checks to see if the correct error is thrown when the index
// inputted is less than 0
void removeAt_nonempty_incorrect_negative() {
   
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.removeAt(-3);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (-3) not in range [0..8)");
}

// test to see if the correct range error is thrown on an empty
// list when a larger index is chosen
void removeAt_empty_incorrect() {

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    // insertAt for out-of-range index
    test_list.removeAt(42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0)");   
}


// makes sure an error is thrown when a larger input is selected
// for a multi element list
void removeAt_nonempty_incorrect_larger() {
   
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.removeAt(16);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (16) not in range [0..8)");
}

// makes sure an error is thrown when an index 0 is selected for
// an empty list
void removeAt_empty_incorrect_index0() {

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    test_list.removeAt(0);
    }
    catch (const std::range_error &e) {

    range_error_thrown = true;
    error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (0) not in range [0..0)");   
}

// makes sure an error is thrown when an index is chosen for 
// an empty list
void removeAt_empty_incorrect_index() {

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    // insertAt for out-of-range index
    test_list.removeAt(8);
    }
    catch (const std::range_error &e) {
    range_error_thrown = true;
    error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (8) not in range [0..0)");   
}

//REPLACE TESTS:
//checks to make sure it successfully replaces
//an element in a one element list
void replace_one_element() {
    CharLinkedList list('a');
    list.replaceAt('e', 0);
    assert(list.elementAt(0) == 'e');
    assert(list.size() == 1);
}

// checks to see if it can successfully replace and element in the middle
// of a multi element list
void replace_multiElement_middle() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);
    test_list.replaceAt('b' , 2);
    assert(test_list.elementAt(2) == 'b');
    assert(test_list.elementAt(1) == 'b');
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.size() == 8);
}

// checks to see if it can successfully replace and element in the front
// of a multi element list
void replace_multiElement_front() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);
    test_list.replaceAt('b' , 0);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'b');
    assert(test_list.size() == 8);
}

// checks to see if it can successfully replace and element in the back
// of a multi element list
void replace_multiElement_back() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);
    test_list.replaceAt('b' , 7);
    assert(test_list.elementAt(7) == 'b');
    assert(test_list.elementAt(6) == 'g');
    assert(test_list.size() == 8);
}

// checks to see if the correct error is thrown when the index
// inputted is less than 0
void replaceAt_nonempty_incorrect_negative() {
   
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.replaceAt('h', -3);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (-3) not in range [0..8)");
}

// test to see if the correct range error is thrown on an empty
// list when a larger index is chosen
void replaceAt_empty_incorrect() {

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    // insertAt for out-of-range index
    test_list.replaceAt('e', 42);
    }
    catch (const std::range_error &e) {
    range_error_thrown = true;
    error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0)");   
}

// checks to see if the correct error is thrown when an index that 
// is too big is chosen in a multi element list
void replaceAt_nonempty_incorrect_larger() {
   
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.replaceAt('f', 16);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (16) not in range [0..8)");
}


// checks to see that an error is printed when index 0 is selected on 
// an empty list
void replaceAt_empty_incorrect_index0() {

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    // insertAt for out-of-range index
    test_list.replaceAt('b', 0);
    }
    catch (const std::range_error &e) {
    range_error_thrown = true;
    error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (0) not in range [0..0)");   
}

// checks to see that an error is printed when a index is  
// selected on an empty list
void replaceAt_empty_incorrect_index() {

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    // insertAt for out-of-range index
    test_list.replaceAt('b', 8);
    }
    catch (const std::range_error &e) {
    range_error_thrown = true;
    error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (8) not in range [0..0)");   
}

//CONCATENATE TESTS

//checks to see that two lists can be concatenated correctly
void check_normal_concatenate() {
    CharLinkedList one;
    one.insertAt('h', 0);
    one.insertAt('o', 1);
    one.insertAt('t', 2);

    CharLinkedList two;
    two.insertAt('d', 0);
    two.insertAt('o', 1);
    two.insertAt('g', 2);

    one.concatenate(&two);
    assert(one.elementAt(3) == 'd');
    assert(one.elementAt(5) == 'g');
    assert(one.elementAt(0) == 'h');
    assert(one.size() == 6);
}

//checks that an empty list can be concatenated with a full 
//list successfully
void check_empty_concatenate() {
    CharLinkedList one;

    CharLinkedList two;
    two.insertAt('d', 0);
    two.insertAt('o', 1);
    two.insertAt('g', 2);

    one.concatenate(&two);
    assert(one.elementAt(0) == 'd');
    assert(one.size() == 3);
}

//checks that a full list can be concatenated with an empty
//list and nothing will change
void check_empty_secondList() {
    CharLinkedList one;
    one.insertAt('h', 0);
    one.insertAt('o', 1);
    one.insertAt('t', 2);

    CharLinkedList two;
    one.concatenate(&two);
    assert(one.elementAt(0) == 'h');
    assert(one.elementAt(2) == 't');
    assert(one.size() == 3);
}

// NEED TO FIX
// checks that two list of the same contents can be 
// concatenated together
void concatenate_with_itself() {
    CharLinkedList one;
    one.insertAt('h', 0);
    one.insertAt('o', 1);
    one.insertAt('t', 2);

    one.concatenate(&one);
    assert(one.elementAt(0) == 'h');
    assert(one.elementAt(2) == 't');
    assert(one.elementAt(3) == 'h');
    assert(one.size() == 6);
}

//INSERT IN ORDER TESTS:

//checks to make sure you can insert in order with an
//empty list that just puts the element at index 0
void insertInOrder_emptyArray() {
    CharLinkedList list;
    list.insertInOrder('h');
    assert(list.elementAt(0) == 'h');
    assert(list.size() == 1);
    assert(not list.isEmpty());
    assert(list.size() == 1);
}

// checks to see that an element can get inserted into the 
// front if thats the correct order
void insertInOrder_front() {
    char test_arr[3] = { 'z' , 'e' , 'd'};
    CharLinkedList test_list(test_arr, 3);
    test_list.insertInOrder('a');
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.size() == 4);
}

//checks to see that an element can get inserted into the 
//back if thats the correct order
void insertInOrder_back() {
    char test_arr[3] = { 'b' , 'e' , 'd'};
    CharLinkedList test_list(test_arr, 3);
    test_list.insertInOrder('v');
    assert(test_list.elementAt(3) == 'v');
    assert(test_list.size() == 4);
}

// checks that if the letter matches an element in the list
// already, it still gets inserted in the right spot
void insertInOrder_sameLetter() {
    char test_arr[3] = { 'b' , 'd' , 'e'};
    CharLinkedList test_list(test_arr, 3);
    test_list.insertInOrder('d');
    assert(test_list.elementAt(1) == 'd');
    assert(test_list.elementAt(2) == 'd');
    assert(test_list.size() == 4);
}

/*
 *  CharLinkedList.cpp
 *  Emily Nicholas
 *  January 30, 2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Purpose: contains the class implementation and methods for the linked
 *           list class
 *
 */

#include "CharLinkedList.h"
#include <sstream>
#include <string>
#include <iostream>

using namespace std;

//name: CharLinkedList
//purpose: default constructor that initializes an empty linked list
//arguments: none
//returns: none
//effects: initializes size to 0 and front to nullptr
CharLinkedList::CharLinkedList() {
    front = nullptr;
    numCharacters = 0;
}

//name: CharLinkedList
//purpose: constructor that takes in a single character as a parameter and
//         creates a one element linked list consisting of that character
//arguments: a single character
//returns: nothing
//effects: initializes numCharacters to one and front node pointers to nullptr
CharLinkedList::CharLinkedList(char c) {
    numCharacters = 1;
    front = new Node;
    front->data = c;
    front->next = nullptr;
    front->before = nullptr;
}

//name: CharLinkedList
//purpose: constructor that creates a multi element list by copying in 
//         elements from array argument
//arguments: array of characters and size of that array
//returns: nothing
//effects: initialzes the numCharacters as the size of 
//         the argument array
CharLinkedList::CharLinkedList(char arr[], int size) {
    numCharacters = size;
    front = nullptr;
    for (int i = 0; i < numCharacters; i++) {
        //for each element in the array arr, a new node is made and initially
        //the next and before pointers are nullptrs
        Node *newChar = newNode(arr[i], nullptr, nullptr);
        //makes sure the front is set to the first node
        if (front == nullptr) {
            front = newChar;
        } else {
            //finds the node at before the next element
            Node *previousNode = elementAtHelper(front, i-1);
            //connects the new node to the previous node
            previousNode->next = newChar;
            //assings the new nodes before pointer to the previous node
            newChar->before = previousNode;
        }
    }
}

//name: CharLinkedList
//purpose: copy constructor for the class that makes a deep copy of 
//         a given instance
//arguments: reference to a linked list
//returns: nothing
//effects: initializes numCharacters to the values it 
//         holds in the referenced list
CharLinkedList::CharLinkedList(const CharLinkedList &other) {
    numCharacters = other.numCharacters;
    front = nullptr;
    //check that other is not empty and then create a front node
    if (other.front != nullptr) {
        front = newNode(other.front->data, nullptr, nullptr);
        Node *newChar = front;
        Node *oldChar = other.front->next;
        //copy in the rest of the nodes from other
        for (int i = 0; i < other.numCharacters - 1; i++) {
            newChar->next = newNode(oldChar->data, nullptr, newChar); 
            newChar = newChar->next;
            oldChar = oldChar->next;
        }
    }
}

//name: ~CharLinkedList
//purpose: calls the recursive function that will clear up node memory
//arguments: none
//returns: nothing
//effects: clears up memory once linked list is no longer in use
CharLinkedList::~CharLinkedList() {
    recycleRecursive(front);
}

//name: recycleRecursive
//purpose: helper function that recycles each node in the list 
//         beginning at curr
//arguments: current node
//returns: nothing
//effects: deletes curr node memory
void CharLinkedList::recycleRecursive(Node *curr) {
    //base case of recursive function
    if (curr == nullptr) {
        return;
    } else {
        //save memory befor you delete it
        Node *next = curr->next;
        delete curr;
        //calls function with the next node that was saved above
        recycleRecursive(next);
    }
}

//name: CharLinkedList &operator=
//purpose: assignment operator that recycles the storage associated with the
//instance on the left of the assignment and makes a deep copy of the instance
//on the right hand side into the instance on the left hand side
//arguments: reference to an linked list that is to be copied
//returns: reference to the new instance that was made
//effects: initializes numCharacters to the other list's values
CharLinkedList& CharLinkedList::operator=(const CharLinkedList &other) {
    //check that the instances are not the same and that the front is not null
    if (this != &other) {
        Node *curr = front;
        while (curr != nullptr) {
            Node *next = curr->next;
            delete curr;
            curr = next;
        }
        front = nullptr;
        numCharacters = 0;

        Node *otherCurr = other.front;
        Node *previous = nullptr;
        //copy in the data from other to the new nodes in the list
        while(otherCurr != nullptr) {
            Node *newTemp = newNode(otherCurr->data, nullptr, previous);
            if (previous == nullptr) {
                front = newTemp;
            } else {
                previous->next = newTemp;
            }
            previous = newTemp;
            otherCurr = otherCurr->next;
        }
        numCharacters = other.numCharacters;
    }
    return *this;
}

//name: newNode
//purpose: private method that creates a new character node on the heap
//arguments: takes in the element you want in the new node, the 
//           element it points to next, and the element it points to before
//returns: returns the new node initialized with the corresponding variables
//effects: none
CharLinkedList::Node *CharLinkedList::newNode(char data, Node *next, 
Node *before) {
    Node *new_node = new Node;
    new_node->data = data;
    new_node->next = next;
    new_node->before = before;
    return new_node;
}

//name: size
//purpose: returns an integer value that is the number of characters 
//         in the list
//arguments: none
//returns: number of elements currently stored in the CharLinkedList
//effects: none
int CharLinkedList::size() const {
    return numCharacters;
}

//name: elementAt
//purpose: function that takes in an integer index and returns the element 
//in the list at the corresponding index
//arguments: index that you want to access the element from
//returns: returns the data contained in the node at the correct index
//effects: throws a range error if the index is out of bounds
char CharLinkedList::elementAt(int index) const {
    if (index < 0 or index >= numCharacters) {
        throw std::range_error("index (" + std::to_string(index) + 
        ") not in range [0.." + std::to_string(numCharacters) + ")");
    }
    //calls the recursive function giving it the front node and 
    //the index indicated
    Node *findNode = elementAtHelper(front, index);
    return findNode->data;
}

//name: elementAtHelper
//purpose: recursive helper function for elementAt that goes through nodes 
//         until it finds the element at the correct index
//arguments: takes in a current node and the index you want to find
//returns: calls the recursive function until it reaches the base case
//effects: throws a range error if the index inputted is out of bounds
CharLinkedList::Node *CharLinkedList::elementAtHelper(Node *curr, int index)
 const {
    if (curr == nullptr) {
        throw std::range_error("index (" + std::to_string(index) + 
        ") not in range [0.." + std::to_string(numCharacters) + ")");
    }
    //base case
    if (index == 0) {
        return curr;
    }
    //recursive case
    return elementAtHelper(curr->next, index - 1);
}

//name: isEmpty
//purpose: checks to see if there are any elements in the list
//arguments: none
//returns: true if the list is empty and false if not
//effects: none
bool CharLinkedList::isEmpty() const {
    if (numCharacters == 0) {
        return true;
    } else {
        return false;
    }
}

//name: first
//purpose: returns the first character in the linked list
//arguments: none
//returns: first char value in the list
//effects: if the list is empty, it will throw a runtime error and print
//         failure message
char CharLinkedList::first() const {
    if (numCharacters == 0) {
        throw std::runtime_error("cannot get first of empty LinkedList");
    }
    return front->data;
}

//name: last
//purpose: returns the last element in the linked list
//arguments: none
//returns: last char value in linked list
//effects: if the list is empty, it will throw a runtime error and print
//         failure message
char CharLinkedList::last() const {
    if (numCharacters == 0) {
        throw std::runtime_error("cannot get last of empty LinkedList");
    }
    Node *curr = front;
    //last node is the one that's next pointer is nullptr
    while (curr->next != nullptr) {
        curr = curr->next;
    }
    return curr->data;
}

//name: clear
//purpose: makes the instance into an empty linked list by following the nodes
//         and deleting them one by one
//arguments: none
//returns: nothing
//effects: linked list will become empty and therefore the size = 0
void CharLinkedList::clear() {
    //check that the list is not empty
    if(front != nullptr) {
        //save temporary pointer and iterate before you delete it
        Node *curr = front;
        front = front->next;
        delete curr;
    }
    numCharacters = 0;
}

//name: pushAtFront
//purpose: takes an element and inserts it at the start of the linked list
//arguments: a char value
//returns: none
//effects: size should increment by one; sets new node's front equal to the
//         old front and before pointer to nullptr
void CharLinkedList::pushAtFront(char c) {
    //if the list is empty, just create a new front node
    if (front == nullptr) {
        front = newNode(c, front, nullptr);
        numCharacters++;
    } else {
        //creates temporary pointer to save old front node and initializes
        //a new front maintaining pointer connections
        Node *old_front = front;
        front = newNode(c, front, nullptr);
        old_front->before = front;
        numCharacters++;
    }
}

//name: pushAtBack
//purpose: takes an element and inserts it at the end of the linked list
//arguments: a char value
//returns: none
//effects: size should increment by one; new node's next pointer is set 
//         to nullptr and before pointer is the old curr
void CharLinkedList::pushAtBack(char c) {
    //if the list is empty, the pushing at back means adding a front node
    if (front == nullptr) {
        front = newNode(c, front, nullptr);
    } else {
        //iterate to back of list and then create a new node at next pointer
        Node *curr = front;
        while (curr->next != nullptr) {
            curr = curr->next;
        }
        curr->next = newNode(c, nullptr, curr);
    }
    numCharacters++;
}

//name: toString
//purpose: returns a string which contains the characters of the 
//CharLinkedList formatted in the brackets
//arguments: none
//returns: a string including the size of the linked list and characters
//effects: outputs the message in bracketed format
std::string CharLinkedList::toString() const {
    std::string characters;
    Node *curr = front;
    //iterate through list and add data to string variable
    while(curr != nullptr) {
        characters += curr->data;
        curr = curr->next;
    }
    return "[CharLinkedList of size " + std::to_string(numCharacters) + 
    " <<" + characters + ">>]";
}

//name: toReverseString
//purpose: returns a string which contains the characters of the 
//         list in reverse
//arguments: none
//returns: a string which contains the characters of the CharLinkedList
//         in reverse order
//effects: outputs the message in bracketed format
std::string CharLinkedList::toReverseString() const {
    std::string characters;
    Node *curr = front;
    //if the list is empty
    if(curr == nullptr) {
        return "[CharLinkedList of size 0 <<>>]";
    }
    //first get to the back of the list
    while(curr->next != nullptr) {
        curr = curr->next;
    }
    //then add data to string from back to front using before pointer
    while (curr != nullptr) {
        characters += curr->data;
        curr = curr->before;
    }
    return "[CharLinkedList of size " + std::to_string(numCharacters) + 
    " <<" + characters + ">>]";
}

//name: insertAt
//purpose: takes an element and inserts it at the specified index
//         in the linked list while maintaining pointer connections
//arguments: a char value and the index where you want to insert it
//returns: none
//effects: size should increase by one; should throw a range error if the 
//         index inputted is out of bounds
void CharLinkedList::insertAt(char c, int index) {
    if (index < 0 or index > numCharacters) {
        throw std::range_error("index (" + std::to_string(index) + 
        ") not in range [0.." + std::to_string(numCharacters) + "]");
    }
    //inserting at front of list
    if (index == 0) {
        front = newNode(c, front, nullptr);
    //inserting at back of list
    } else if (index == numCharacters) {
        Node *addition = newNode(c, nullptr, nullptr);
        Node *curr = front;
        while (curr->next != nullptr) {
            curr = curr->next;
        }
        curr->next = addition;
        addition->before = curr;
    //iterate to element before and add new pointers to next and before
    } else {
        Node *addition = newNode(c,nullptr, nullptr);
        int curr_index = 0;
        Node *curr = front;
        while (curr_index < index - 1) {
            curr = curr->next;
            curr_index++;
        }
        addition->next = curr->next;
        addition->before = curr;
        curr->next = addition;
        addition->next->before = addition;
    }
    numCharacters++;
}

//name: popFromFront
//purpose: removes the first element from the linked list
//arguments: none
//returns: none
//effects: should throw a runtime error if it attempts to pop from
//         an empty linked list; size should decrement by one; memory
//         from the old list is freed with delete keyword
void CharLinkedList::popFromFront() {
    if (numCharacters == 0) {
        throw std::runtime_error("cannot pop from empty LinkedList");
    }
    if (front == nullptr) {
        throw std::runtime_error("cannot pop from empty LinkedList");
    }
    //initialize the second element as the new front then delete the old front
    Node *new_front = front->next;
    delete front;
    front = new_front;
    if (front != nullptr) {
        front->before = nullptr;
    }
    numCharacters--;
}

//name: popFromBack
//purpose: removes the last element from the linked list
//arguments: none
//returns: none
//effects: should throw a runtime error if it attempts to pop from
//         an empty linked list; size should decrement by one; memory
//         from the old list is freed with delete keyword
void CharLinkedList::popFromBack() {
    if (numCharacters == 0 or front == nullptr) {
        throw std::runtime_error("cannot pop from empty LinkedList");
    }
    Node *curr = front;
    //iterate to end of the list
    while (curr->next != nullptr) {
        curr = curr->next;
    }
    //the new back is the second to last element
    Node *new_back = curr->before;

    if (new_back != nullptr) {
        new_back->next = nullptr;
    } else {
        front = nullptr;
    }

    delete curr;
    numCharacters--;
}

//name: removeAt
//purpose: removes the element at the specified index
//arguments: the index where you want to remove the element
//returns: none
//effects: size should decrement by one; should throw a range error if 
//         the index inputted is out of bounds
void CharLinkedList::removeAt(int index) {
    if (index < 0 or index > numCharacters or front == nullptr) {
        throw std::range_error("index (" + std::to_string(index) + 
        ") not in range [0.." + std::to_string(numCharacters) + ")");
    }
    //if you are removing the first element
    if (index == 0) {
        Node *new_front = front->next;
        delete front;
        front = new_front;
        if (front != nullptr and front->next != nullptr) {
            front->before = nullptr;
            front->next->before = front;
        }
    } else {
        int curr_index = 0;
        Node *curr = front;
        while (curr_index < index) {
            curr = curr->next;
            curr_index++;
        }
        if (curr->before != nullptr) {
            curr->before->next = curr->next;
        }
        if (curr->next != nullptr) {
            curr->next->before = curr->before;
        }
        delete curr;
        }
    numCharacters--;
}

//name: replaceAt
//purpose: calls the recursive function and then takes the element and
//         replaces it at the curr node the recursive function returns
//arguments: the element value and the index you want to replace
//returns: none
//effect: should throw a range error if the index inputted is out of bounds
void CharLinkedList::replaceAt(char c, int index) {
    if (index < 0 or index >= numCharacters) {
        throw std::range_error("index (" + std::to_string(index) + 
        ") not in range [0.." + std::to_string(numCharacters) + ")");
    }
    //calls recursive function which returns the node at the position
    //you want to replace
    Node *replacement = replaceAtHelper(front, index);
    replacement->data = c;
}

//name: replaceAtHelper
//purpose: recursive helper function that finds the node where you want
//         to replace the existing node
//recursive helper function for replaceAt function
//arguments: takes in the curr node which starts at the front and the index
//           you want to find
//returns: returns the curr node at the index you want, once the base case is 
//         reached
//effects: should throw a range error if the index inputted is out of bounds
CharLinkedList::Node *CharLinkedList::replaceAtHelper(Node *curr, int index)
 const {
    if (curr == nullptr) {
        throw std::range_error("index (" + std::to_string(index) +
        ") not in range [0.." + std::to_string(numCharacters) + ")");
    }
    //base case
    if (index == 0) {
        return curr;
    }
    //recursive case
    return replaceAtHelper(curr->next, index - 1);
}

//NEED to add part about checking if the two lists are the same
//name: concatenate
//purpose:  adds a copy of the list in the parameter to the end of 
//          the list the function is called from
//arguments: pointer to the second CharLinkedList
//returns: none
//effects: the new size of the linked list should be the two list's sizes 
//         added together; have to clear up memory on heap
void CharLinkedList::concatenate(CharLinkedList *other) {
    //if other is empty then the list stays the same
    if (other == nullptr or other->front == nullptr) {
        return;
    }
    //if the list is empty then it just becomes the other list
    if (front == nullptr) {
        front = other->front;
    } else {
        Node *curr = front;
        //get to end of first instance list then connect that last node
        //to the front of the other instance
        while (curr->next != nullptr) {
            curr = curr->next;
        }
        curr->next = other->front;
    }
    numCharacters = numCharacters + other->numCharacters;
    other->front = nullptr;
    other->numCharacters = 0;
}

//name: insertInOrder
//purpose: inserts the element at the correct index in ASCII order
//arguments: char value letter
//returns: none
//effects: size is incremented by one
void CharLinkedList::insertInOrder(char c) {
    Node *element = newNode(c, nullptr, nullptr);
    //if the list is empty then the new node becomes the front node
    if (front == nullptr) {
        front = element;
        numCharacters++;
        return;
    }
    //if there is only one element in list
    if (c <= front->data) {
        element->next = front;
        front->before = element;
        front = element;
        numCharacters++;
        return;
    } 
    int insert = 0;
    Node *curr = front;
    //finds correct position to insert new node and maintains pointers
    while (insert < numCharacters and element->data > curr->data) {
        insert++;
        curr = curr->next;
    }
    if (curr == nullptr) {
        Node *temp = front;
        while (temp->next != nullptr) {
            temp = temp->next;
        }
        element->before = temp;
        temp->next = element;
    } else {
        element->before = curr->before;
        element->next = curr;
        curr->before->next = element;
        curr->before = element;
    }
    numCharacters++;
}
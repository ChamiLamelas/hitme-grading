/*
 *  CharLinkedList.cpp
 *  Angela Yan
 *  1/31/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  This file contains the contents of functions of the CharLinkedList
 *
 */

#include "CharLinkedList.h"
#include <sstream>
#include <stdexcept>
#include <iostream>

using namespace std;

// Constructers

// CharLinkedList_0
// Input: none
// Description: Constructs an empty linkedlist
// Output: none
// Effect: none
CharLinkedList::CharLinkedList(){
    front = nullptr;
    numItems = 0;
}

// CharLinkedList_1
// Input: a character
// Description: Constructs a linked list that takes a single character
// and creates a one element list consisting of that character.
// Output: none
// Effect: creates a node in heap; increase size by 1; has to input a character
CharLinkedList::CharLinkedList(char c){
    front = newNode(c, nullptr, nullptr);
    numItems = 1;
}

// CharLinkedList_2
// Input:a character array and an integar that indicates the size of the array
// Description: Constructs a character linkedlist containing the characters
// in the array
// Output: none
// Effect: Increase size by int size; needs to input a char array and a size;
// creates nodes in heap
CharLinkedList::CharLinkedList(char arr[], int size){
    Node *curr = newNode(arr[0],nullptr, nullptr);
    front = curr;
    for(int i = 1; i < size; i ++){
        Node* next_curr = newNode(arr[i], curr, nullptr);
        curr->next = next_curr; // connects the new node to curr node
        curr = curr->next; // shift curr pointer to the new node
    }
    numItems = size;
}

// CharLinkesList_3
// Input: the address of another CharLinkedList
// Description: a copy constructor for the class that makes a deep copy
// of a given instance
// Output: none
// Effect: Increase size by the size of other; needs to input another char
// linkedlist; creates nodes in heap
CharLinkedList::CharLinkedList(const CharLinkedList &other){
    numItems = other.size();
    Node *curr = newNode(other.front->info, nullptr, nullptr);
    front = curr;
    for(int i = 1; i < numItems; i++){
        Node* next_curr = newNode(other.elementAt(i), curr, nullptr);
        curr->next = next_curr;
        curr = curr->next;
    }
}

// ~CharLinkedlist
// Input: none
// Description: recycles the memory in heap
// Output: none
// Effect: recycle memory
CharLinkedList::~CharLinkedList(){
    while(front!=nullptr){
        Node* curr = front;
        front = curr->next;
        delete curr;
    }
}

// operator
// Input: the address of another charlinkedlist
// Description: This functions makes a deep copy of the instance on the
// right hand side into the instance on the left hand side
// Output: The address of a deep copy of the right hand side
// Effect: inputs another charlinkedlist; recycles the original list in memory
// and allocate a new list; changes size to the size of the input list
CharLinkedList &CharLinkedList::operator=(CharLinkedList &other){
    if(this == &other){
        return *this;
    }else{
        clear();
        // In order to use concatenate in my operator function,
        // I had to change the &other into a non const
        // CharLinkedList. Otherwise, terminal would return that CharLinkedList
        // does not match with const CharLinkedList
        concatenate(&other);
        return *this;
    }  
}

// isEmpty
// Input: none
// Description: Returns a boolean value that is true if this specific instance
// of the class is empty (has no characters) and false otherwise.
// Output: a boolean statement
// Effect: none
bool CharLinkedList::isEmpty() const{
    if(numItems == 0){
        return true;
    }else{
        return false;
    }
}

// clear
// Input: none
// Description: makes the linked list into an empty list
// Output: none
// Effect: recycles all memory in heap; reduces size to 0
void CharLinkedList::clear(){
    while(not isEmpty()){
        popFromFront();
    }
}

// size
// Input: none
// Description: returns the size of the linked list
// Output: an integar that is the size of the linked list
// Effect: outputs an integar
int CharLinkedList::size() const{
    return numItems;
};

// first
// Input: none
// Description: returns the first character of the linkedlist
// Output: the first character of the linkedlist
// Effect: raise an error if the list is empty; outputs a character
char CharLinkedList::first() const{
    if(front!=nullptr){
        return front->info;
    }else{
        throw runtime_error("cannot get first of empty LinkedList");
    }
}

// last
// Input: none
// Description: returns the last character of the linkedlist
// Output: the last character of the linkedlist
// Effect: raises an error if the list is empty; outputs a character
char CharLinkedList::last() const{
    if(numItems == 0){
        throw runtime_error("cannot get last of empty LinkedList");
    }else{
        return elementAt(numItems-1);
    }
}


// elementAt
// Input: the index of the character that the user wants to see
// Description: This function returns the character at the index that
// the user inputed
// Output: the character at the input index
// Effect: raises an error if idx is out-of-bounds of the list; needs to
// input an index; outputs a character
char CharLinkedList::elementAt(int index) const{
    if(index < 0 or index > numItems-1){
        throw range_error("index (" + to_string(index) +") not in range [0.."
        + to_string(numItems) + ")");
    }else{
        return recursion_helper(0, front, index)->info;
    }
}

// toString
// Input: none
// Description: The function returns a string which contains the characters of 
// the CharLinkedList
// Output: a string that contains the characters of the CharLinkedList
// Effect: outputs a string
std::string CharLinkedList::toString() const{
    string s = "";
    Node *curr = front;
    while (curr != nullptr) {
        s = s + curr->info;
        curr = curr->next;
    }
    
    string result = "[CharLinkedList of size " + to_string(numItems)
    + " <<" + s + ">>]";

    return result;
}

// toReverseString
// Input: none
// Description: The function returns a string which contains the characters of 
// the CharLinkedList in reverse
// Output: a string that contains the characters of the CharLinkedList 
// in reverse
// Effect: outputs a string
std::string CharLinkedList::toReverseString() const{
    string s = "";
    if(not isEmpty()){
        Node *curr = recursion_helper(0,front,numItems-1);
        while (curr != nullptr) {
            s = s + curr->info;
            curr = curr->before;
        }
    }
    
    string result = "[CharLinkedList of size " + to_string(numItems)
    + " <<" + s + ">>]";

    return result;    
}

// pushAtBack
// Input: the charcter that needs to be stored
// Description: This function stores a given character at the back of the
// current list
// Output: none
// Effect: This function causes the list's size to increase by 1; needs to
// input a character
void CharLinkedList::pushAtBack(char c){
    insertAt(c, numItems);
}

// pushAtFront
// Input: the charcter that needs to be stored
// Description: This function stores a given character at the front of the
// current list
// Output: none
// Effect: This function causes the list's size to increase by 1; needs to
// input a character
void CharLinkedList::pushAtFront(char c){
    insertAt(c, 0);
}

// insertAt
// Input: the character to stored and the position it wants to be stored
// Description: This function stores a given character at a given index in the
// list
// Output: none
// Effect: This function causes the list's size to increase by 1; needs to
// input a character and an index; raises an error message if index is out of
// range
void CharLinkedList::insertAt(char c, int index){
    if(index < 0 or index > numItems){
        throw range_error("index (" + to_string(index) +") not in range [0.."
        + to_string(numItems) + "]");
    }else{
        if(isEmpty()){
            front = newNode(c, nullptr, nullptr);
        }else if(index == 0){
                front = newNode(c, nullptr, front);
                front->next->before = front;
            }else if(index == numItems){
                Node* last = recursion_helper(0, front, index-1);
                last->next = newNode(c, last, nullptr);
            }else{
                Node* curr = recursion_helper(0, front, index);
                curr->before->next = newNode(c, curr-> before, curr);
                curr->before = curr->before->next;
            }
        numItems++;
    }
}


// insertInOrder
// Input: the character to be stored
// Description: The function takes an element and inserts it into the list in 
// ASCII order
// Output: none
// Effect: This functions increases the size by 1; inputs a character
void CharLinkedList::insertInOrder(char c){
    if(isEmpty()){
        pushAtBack(c);
    }else{
        insertAt(c, recursion_order(0, c, front));
    }      
}

// popFromFront
// Input: none
// Description: This function removes the first element from the list
// Output: none
// Effect: Triggers error when the list is empty; reduces size by 1
void CharLinkedList::popFromFront(){
    if(isEmpty()){
        throw runtime_error("cannot pop from empty LinkedList");
    }
    removeAt(0);
}

// popFromBack
// Input: none
// Description: This function removes the last element from the list
// Output: none
// Effect: Triggers error when the list is empty; reduces size by 1
void CharLinkedList::popFromBack(){
    if(isEmpty()){
        throw runtime_error("cannot pop from empty LinkedList");
    }
    removeAt(numItems-1);
}

// removeAt
// Input: an index that indicates the position of the element to be removed
// Description: The function removes the element at given index
// Output: none
// Effect: Triggers error when the list is empty; reduces size by one; 
// inputs an index
void CharLinkedList::removeAt(int index){
    if(index < 0 or index >= numItems){
        throw range_error("index (" + to_string(index) +") not in range [0.."
        + to_string(numItems) + ")");
    }
    Node *curr = recursion_helper(0, front, index);

    if(curr->before != nullptr){
        curr->before->next = curr->next;
    }else{
        front = curr->next;
    }
    if(curr->next != nullptr){
        curr->next->before = curr ->before;
    }
    delete curr;
    numItems --;
}

// replaceAt
// Input: the new element and the index of the element to be replaced
// Description: This function replaces the element at an input index with
// an imput element
// Output: none
// Effect: returns an error message if index is out of range; inputs a 
// character and an index
void CharLinkedList::replaceAt(char c, int index){
    if(index < 0 or index >= numItems){
        throw range_error("index (" + to_string(index) +") not in range [0.."
        + to_string(numItems) + ")");
    }
    recursion_helper(0, front, index)->info = c;
}

// concatenate
// Input: a pointer to another list of characters
// Description: This function adds a copy of the list pointed to by the
// parameter value to the end of the list the function was called from.
// Output: none
// Effect: increase size by the number of elements added; inputs a pointer
// to a charlinkedlist
void CharLinkedList::concatenate(CharLinkedList *other){
    if(this == other){
        int size = numItems;
        for(int j = 0; j < size; j++){
            pushAtBack(elementAt(j));
        }
    }else{
        for(int i = 0; i < other->size(); i++){
            pushAtBack(other->elementAt(i));
        } 
    }
     
}

// newNode
// Input: a character, a pointed to the node before, and a pointer to 
// the next node
// Description: This function creates a new Node in heap
// Output: a pointer to the created node in heap
// Effect: inputs a character, and 2 node pointers; outputs a node pointer
// ; creates a node in heap
CharLinkedList::Node* CharLinkedList::newNode(char c, Node* before, Node* next)
{
    Node* newNode = new Node;
    newNode->info = c;
    newNode->before = before;
    newNode->next = next;
    return newNode;
}

// recursion_helper
// Input: a integar that indicates the index that the user wants to get to,
// an integar that indicates the index of current node, and a node
// pointer
// Description: This function is a recursion that updates curr_node to
// the next node until it reaches the target index. It returns a node
// pointer at the target position.
// Output: a pointer to the node at the target index in the linkedlist
// Effect: returns a nullptr if the list is empty; inputs 2 integars and
// a node pointer; outputs a node pointer; returns an error message if
// the index is out of bound
CharLinkedList::Node* CharLinkedList::recursion_helper(int curr_num, 
Node* curr, int index) const{
    if(index < 0 or index >= numItems){
        throw range_error("index (" + to_string(index) +") not in range [0.."
        + to_string(numItems) + ")"); 
    }else{
        if(curr_num == index){
            // base case: curr reaches the node at the target index
            return curr; 
        }else{
            curr = curr->next;
            curr_num ++;
            // recurse case: curr_num + 1 and curr points to the next node
            return recursion_helper(curr_num, curr, index);
        }
    } 
}

// recursion_order
// Input: the index of the start position, a pointer to current node, 
// the input character
// Description: This function finds the index where the input character
// should be for the result list to be in ascending order
// Output: the index of the input character
// Effect: inputs an integar, a char, and a node pointer; outputs and integar;
int CharLinkedList::recursion_order(int curr_index, char c, Node *curr) const{
    if(c <= curr->info){
        // base case I: c finds the first character that is after it in the
        // ASCII order
        return curr_index;
    }else if (curr->next == nullptr){
            // base case II: reaches the end of the list
            return numItems;
        }else{
                // recursion case: If the character in curr node is before 
                // c in ASCII order, moves to next curr and index +1
                return recursion_order(curr_index + 1, c, curr->next);
            }
}




/*
 *  unit_tests.h
 *  Angela Yan
 *  1/31/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  This file contains testing function for functions implemented in
 *  CharLinkedList
 *
 */

#include "CharLinkedList.h"
#include <cassert>
#include <iostream>

// Testing constructor of an empty linkedlist & isEmpty
void constructor_test0(){
    CharLinkedList test_list;
    assert(test_list.toString()=="[CharLinkedList of size 0 <<>>]");
    assert(test_list.isEmpty());
}

// testing constructor of a one element linkedlist & isEmpty
void constructor_test1(){
    CharLinkedList test_list('p');
    assert(test_list.size()== 1);
    assert(not test_list.isEmpty());
    assert(test_list.toString()=="[CharLinkedList of size 1 <<p>>]");
}

// testing constructor with an array of elements & isEmpty & clear
void constructor_test2(){
    char arr[5] = {'-', 'o', 'h','o','-'};
    CharLinkedList test_list(arr, 5);
    assert(test_list.toString() == "[CharLinkedList of size 5 <<-oho->>]");
    test_list.clear();
    assert(test_list.isEmpty());
}

// testing clear then add
void clear(){
    char arr[5] = {'o', 'l', 'i','l','-'};
    CharLinkedList test_list(arr, 5);
    test_list.clear();
    assert(test_list.isEmpty());
    test_list.pushAtBack('p');
    assert(test_list.toString() == "[CharLinkedList of size 1 <<p>>]");
}

// testing constructer that makes a deep copy of a given instance
void constructer_test3(){
    char arr[5] = {'-', 'o', 'h','o','-'};
    CharLinkedList test_list(arr, 5);
    CharLinkedList test_list_2(test_list);
    assert(test_list_2.toString() == "[CharLinkedList of size 5 <<-oho->>]");
}

// testing overloading operater this = other in contents. Both lists are
// constructed by the same array
void operater_same_contents_array(){
    char arr[5] = {'-', 'o', 'h','o','-'};
    CharLinkedList test_list(arr, 5);
    CharLinkedList test_list_2(arr, 5);
    test_list = test_list_2;
    assert(test_list_2.toString() == "[CharLinkedList of size 5 <<-oho->>]");
    assert(test_list.toString() == "[CharLinkedList of size 5 <<-oho->>]");
}

// testing overloading operater this != other in contents. 
// They are constructed by different arrays
void operater_different_contents_array(){
    char arr[5] = {'-', 'o', 'h','o','-'};
    char array[5] = {'-', '!', 'h','!','-'};
    CharLinkedList test_list(arr, 5);
    CharLinkedList test_list_2(array, 5);
    test_list_2 = test_list;
    assert(test_list_2.toString() == "[CharLinkedList of size 5 <<-oho->>]");
    assert(test_list.toString() == "[CharLinkedList of size 5 <<-oho->>]");
}

// testing overloading operater this = other empty in contents
void operater_same_contents_empty(){
    CharLinkedList test_list;
    CharLinkedList test_list_2;
    test_list = test_list_2;
    assert(test_list_2.toString() == "[CharLinkedList of size 0 <<>>]");
    assert(test_list.toString() == "[CharLinkedList of size 0 <<>>]");
}

// testing overloading operater that this = other in contents. Both list
// are constructed by the same character
void operater_same_contents_1char(){
    CharLinkedList test_list('p');
    CharLinkedList test_list_2('p');
    test_list = test_list_2;
    assert(test_list_2.toString() == "[CharLinkedList of size 1 <<p>>]");
    assert(test_list.toString() == "[CharLinkedList of size 1 <<p>>]");
}

// testing overloading operater this = other (in address)
void operater_same_address(){
    char arr[5] = {'-', 'o', 'h','o','-'};
    CharLinkedList test_list(arr, 5);
    test_list = test_list;
    assert(test_list.toString() == "[CharLinkedList of size 5 <<-oho->>]");
}

// testing overloading operater this != other (size: this < other)
void operater_other_bigger(){
    CharLinkedList test_list;
    char arr[5] = {'o', 'l', 'h','o','-'};
    CharLinkedList test_list_2(arr, 5);
    test_list = test_list_2;
    assert(test_list_2.toString() == "[CharLinkedList of size 5 <<olho->>]");
    assert(test_list_2.toReverseString() == 
    "[CharLinkedList of size 5 <<-ohlo>>]");
    assert(test_list.toString() == "[CharLinkedList of size 5 <<olho->>]");
    assert(test_list.toReverseString() == 
    "[CharLinkedList of size 5 <<-ohlo>>]");
}

// testing overloading operater this != other (other is empty)
void operater_other_empty(){
    CharLinkedList test_list;
    char arr[5] = {'-', 'o', 'h','o','-'};
    CharLinkedList test_list_2(arr, 5);
    test_list_2 = test_list;
    assert(test_list_2.toString() == "[CharLinkedList of size 0 <<>>]");
    assert(test_list.toString() == "[CharLinkedList of size 0 <<>>]");
}

// testing overloading operater this != other (other < this in size>)
void operater_other_smaller(){
    CharLinkedList test_list('p');
    char arr[5] = {'-', 'o', 'h','o','-'};
    CharLinkedList test_list_2(arr, 5);
    test_list_2 = test_list;
    assert(test_list_2.toString() == "[CharLinkedList of size 1 <<p>>]");
    assert(test_list.toString() == "[CharLinkedList of size 1 <<p>>]");
}


// testing first in an empty list
void first_empty(){
    CharLinkedList test_list;

    // var to track whether runtime_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.first();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot get first of empty LinkedList"); 
}

// testing last in an empty list
void last_empty(){
    CharLinkedList test_list;

    // var to track whether runtime_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.last();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot get last of empty LinkedList"); 
}

// testing first in a list with contents
void first_nonempty(){
    char arr[5] = {'-', 'o', 'h','o','-'};
    CharLinkedList test_list(arr, 5);
    assert(test_list.first() == '-');
}

// testing last in a list with contents
void last_nonempty(){
    char arr[5] = {'-', 'o', 'h','o','-'};
    CharLinkedList test_list(arr, 5);
    assert(test_list.last() == '-');
}

// testing elementAt in an empty linkedlist
void elementAt_empty(){
    CharLinkedList test_list;

    // var to track whether runtime_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.elementAt(0);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (0) not in range [0..0)"); 
    
}

// testing elementAt in a nonempty linkedlist in range
void elementAt_nonempty_inrange(){
    char arr[5] = {'-', 'o', 'h','o','-'};
    CharLinkedList test_list(arr, 5);
    assert(test_list.elementAt(3) == 'o');
}

// testing element At in a nonempty linked list out of range
// this should throw an error message
void elementAt_nonempty_outrange(){
    char arr[5] = {'-', 'o', 'h','o','-'};
    CharLinkedList test_list(arr, 5);

    // var to track whether runtime_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.elementAt(-1);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (-1) not in range [0..5)"); 

}

// testing toReverseString in empty list
void toReverseString_empty(){
    CharLinkedList test_list;
    assert(test_list.toReverseString() == "[CharLinkedList of size 0 <<>>]");
}

// testing toReverseString in non-empty list
void toReverseString_nonempty(){
    char arr[5] = {'o', '0', 'o','0','0'};
    CharLinkedList test_list(arr, 5);
    assert(test_list.toReverseString() == 
    "[CharLinkedList of size 5 <<00o0o>>]");
}

// testing pushAtBack in an empty list
void pushAtBack_empty(){
    CharLinkedList test_list;
    test_list.pushAtBack('c');
    assert(test_list.toString() == 
    "[CharLinkedList of size 1 <<c>>]");
    assert(test_list.toReverseString() == 
    "[CharLinkedList of size 1 <<c>>]");
}

// testing pushAtBack in a nonempty list
void pushAtBack_nonempty(){
    char arr[5] = {'o', '0', 'o','0','0'};
    CharLinkedList test_list(arr, 5);
    test_list.pushAtBack('o');
    assert(test_list.toString() == 
    "[CharLinkedList of size 6 <<o0o00o>>]");
    assert(test_list.toReverseString() == 
    "[CharLinkedList of size 6 <<o00o0o>>]");
}

// testing pushAtBack continuously
void pushAtBack_continuously(){
    char arr[5] = {'o', '0', 'o','0','0'};
    CharLinkedList test_list(arr, 5);
    test_list.pushAtBack('o');
    test_list.pushAtBack('0');
    test_list.pushAtBack('o');
    test_list.pushAtBack('o');
    assert(test_list.toString() == 
    "[CharLinkedList of size 9 <<o0o00o0oo>>]");
    assert(test_list.toReverseString() == 
    "[CharLinkedList of size 9 <<oo0o00o0o>>]");
}

// testing pushAtBack of 2 different lists the same character
void pushAtBack_2list_same_char(){
    char arr[5] = {'o', '0', 'o','0','0'};
    CharLinkedList test_list(arr, 5);
    CharLinkedList test_list_2(arr, 5);
    test_list.pushAtBack('o');
    test_list.pushAtBack('0');
    test_list.pushAtBack('o');
    test_list.pushAtBack('o');
    
    test_list_2.pushAtBack('o');
    test_list_2.pushAtBack('0');
    test_list_2.pushAtBack('o');
    test_list_2.pushAtBack('o');
    assert(test_list.toString() == 
    "[CharLinkedList of size 9 <<o0o00o0oo>>]");
    assert(test_list_2.toString() == 
    "[CharLinkedList of size 9 <<o0o00o0oo>>]");
}

// testing pushAtBack many elements
void pushAtBack_many(){
    CharLinkedList test_list;
    for(int i = 0; i < 100; i ++){
        test_list.pushAtBack('a');
    }

    assert(test_list.size() == 100);
}

// testing pushAtFront in an empty list
void pushAtFront_empty(){
    CharLinkedList test_list;
    test_list.pushAtFront('c');
    assert(test_list.toString() == 
    "[CharLinkedList of size 1 <<c>>]");
    assert(test_list.toReverseString() == 
    "[CharLinkedList of size 1 <<c>>]");
}

// testing pushAtFront in a nonempty list
void pushAtFront_nonempty(){
    char arr[5] = {'o', '0', 'o','0','0'};
    CharLinkedList test_list(arr, 5);
    test_list.pushAtFront('o');
    assert(test_list.toString() == 
    "[CharLinkedList of size 6 <<oo0o00>>]");
    assert(test_list.toReverseString() == 
    "[CharLinkedList of size 6 <<00o0oo>>]");
}

// testing pushAtFront continuously
void pushAtFront_continuously(){
    char arr[5] = {'o', '0', 'o','0','0'};
    CharLinkedList test_list(arr, 5);
    test_list.pushAtFront('o');
    test_list.pushAtFront('0');
    test_list.pushAtFront('o');
    test_list.pushAtFront('o');
    assert(test_list.toString() == 
    "[CharLinkedList of size 9 <<oo0oo0o00>>]");
    assert(test_list.toReverseString() == 
    "[CharLinkedList of size 9 <<00o0oo0oo>>]");
}

// testing pushAtFront many elements
void pushAtFront_many(){
    CharLinkedList test_list;
    for(int i = 0; i < 100; i ++){
        test_list.pushAtFront('a');
    }

    assert(test_list.size() == 100);
}

// testing insertAt in an empty list in range
void insertAt_empty_0(){
    CharLinkedList test_list;
    test_list.insertAt('c' , 0);
    assert(test_list.toString() == 
    "[CharLinkedList of size 1 <<c>>]");
    assert(test_list.toReverseString() == 
    "[CharLinkedList of size 1 <<c>>]");
}

// testing insertAt in an empty list in range
void insertAt_empty_1(){
    CharLinkedList test_list;
    test_list.insertAt('c' , 000);
    assert(test_list.toString() == 
    "[CharLinkedList of size 1 <<c>>]");
}

// testing insertAt in an empty list out of range
void insertAt_empty_incorrect(){
    CharLinkedList test_list;

    // var to track whether runtime_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.insertAt('c', 999);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (999) not in range [0..0]"); 
}

// testing insertAt in a nonempty list out of range
void insertAt_nonempty_incorrect(){
    char arr[5] = {'o', '0', 'o','0','0'};
    CharLinkedList test_list(arr, 5);

    // var to track whether runtime_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.insertAt('c', 999);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (999) not in range [0..5]"); 
}

// testing insertAt in a nonempty list in range
void insertAt_nonempty(){
    char arr[5] = {'o', '0', 'o','0','0'};
    CharLinkedList test_list(arr, 5);
    test_list.insertAt('o' , 3);
    assert(test_list.toString() == 
    "[CharLinkedList of size 6 <<o0oo00>>]");
    assert(test_list.toReverseString() == 
    "[CharLinkedList of size 6 <<00oo0o>>]");
}

// testing insertAt at the front of a nonempty list
void insertAt_nonempty_front(){
    char arr[5] = {'o', '0', 'o','0','0'};
    CharLinkedList test_list(arr, 5);
    test_list.insertAt('o' , 0);
    assert(test_list.toString() == 
    "[CharLinkedList of size 6 <<oo0o00>>]");
    assert(test_list.toReverseString() == 
    "[CharLinkedList of size 6 <<00o0oo>>]");
}

// testing insertAt at the back of a nonempty list
void insertAt_nonempty_back(){
    char arr[5] = {'o', '0', 'o','0','0'};
    CharLinkedList test_list(arr, 5);
    test_list.insertAt('o' , 5);
    assert(test_list.toString() == 
    "[CharLinkedList of size 6 <<o0o00o>>]");
}

// testing insertAt many elements
void insertAt_many(){
    CharLinkedList test_list;
    for(int i = 0; i < 100; i ++){
        test_list.insertAt('a' , i);
    }

    assert(test_list.size() == 100);
}

// testing insertInOrder in empty list
void insertInOrder_empty(){
    CharLinkedList test_list;
    test_list.insertInOrder('p');
    assert(test_list.toString() == 
    "[CharLinkedList of size 1 <<p>>]");
}

// testing insertInOrder in nonempty list at back
void insertInOrder_nonempty_back(){
    char arr[5] = {'a', 'b', 'c','d','e'};
    CharLinkedList test_list(arr, 5);
    test_list.insertInOrder('p');
    assert(test_list.toString() == 
    "[CharLinkedList of size 6 <<abcdep>>]");
    assert(test_list.toReverseString() == 
    "[CharLinkedList of size 6 <<pedcba>>]");
}

// testing insertInOrder in nonempty list that contains the same character
// as the inserted one
void insertInOrder_nonempty_same(){
    char arr[5] = {'a', 'b', 'c','d','e'};
    CharLinkedList test_list(arr, 5);
    test_list.insertInOrder('b');
    assert(test_list.toString() == 
    "[CharLinkedList of size 6 <<abbcde>>]");
    assert(test_list.toReverseString() == 
    "[CharLinkedList of size 6 <<edcbba>>]");
}

// testing insertInOrder in nonempty list at front &Uppercase and lower case
void insertInOrder_nonempty_front(){
    char arr[5] = {'a', 'b', 'c','d','e'};
    CharLinkedList test_list(arr, 5);
    test_list.insertInOrder('A');
    assert(test_list.toString() == 
    "[CharLinkedList of size 6 <<Aabcde>>]");
}

// testing insertInOrder in nonempty list in which all characters are the same
void insertInOrder_nonempty_all_same(){
    char arr[5] = {'0', '0', '0','0','0'};
    CharLinkedList test_list(arr, 5);
    test_list.insertInOrder('0');
    assert(test_list.toString() == 
    "[CharLinkedList of size 6 <<000000>>]");
}

// testing popFromFront in an empty array
void popFromFront_empty(){
    CharLinkedList test_list;

    // var to track whether runtime_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.popFromFront();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList"); 
}

// testing popFromFront to an empty array
void popFromFront_toEmpty(){
    CharLinkedList test_list('p');
    test_list.popFromFront();
    assert(test_list.isEmpty());
}

// testing popFromFront in a list whose size is bigger than 1
void popFromFront_toNonEmpty(){
    char arr[5] = {'i', 's', 'g','e','0'};
    CharLinkedList test_list(arr, 5);
    test_list.popFromFront();
    test_list.popFromFront();
    assert(test_list.toString() == 
    "[CharLinkedList of size 3 <<ge0>>]");
    assert(test_list.toReverseString() == 
    "[CharLinkedList of size 3 <<0eg>>]");
}

// testing popFromBack in an empty array
void popFromBack_empty(){
    CharLinkedList test_list;

    // var to track whether runtime_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.popFromBack();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList"); 
}

// testing popFromBack to an empty array
void popFromBack_toEmpty(){
    CharLinkedList test_list('p');
    test_list.popFromBack();
    assert(test_list.isEmpty());
}

// testing popFromBack in a list whose size is bigger than 1
void popFromBack_toNonEmpty(){
    char arr[5] = {'i', 's', 'g','e','0'};
    CharLinkedList test_list(arr, 5);
    test_list.popFromBack();
    test_list.popFromBack();
    assert(test_list.toString() == 
    "[CharLinkedList of size 3 <<isg>>]");
    assert(test_list.toReverseString() == 
    "[CharLinkedList of size 3 <<gsi>>]");
}

// testing removeAt in an empty array
void removeAt_empty(){
    CharLinkedList test_list;

    // var to track whether runtime_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.removeAt(0);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (0) not in range [0..0)"); 
}

// testing removeAt to an empty array
void removeAt_toEmpty(){
    CharLinkedList test_list('p');
    test_list.removeAt(0);
    assert(test_list.isEmpty());
}

// testing removeAt in a list whose size is bigger than 1
// the element removed is at the front of the list
void removeAt_toNonEmpty_front(){
    char arr[5] = {'i', 's', 'g','e','0'};
    CharLinkedList test_list(arr, 5);
    test_list.removeAt(0);
    assert(test_list.toString() == 
    "[CharLinkedList of size 4 <<sge0>>]");
    assert(test_list.toReverseString() == 
    "[CharLinkedList of size 4 <<0egs>>]");
}

// testing removeAt in a list whose size is bigger than 1
// the element removed is at the back of the list
void removeAt_toNonEmpty_back(){
    char arr[5] = {'i', 's', 'g','e','0'};
    CharLinkedList test_list(arr, 5);
    test_list.removeAt(4);
    assert(test_list.toString() == 
    "[CharLinkedList of size 4 <<isge>>]");
    assert(test_list.toReverseString() == 
    "[CharLinkedList of size 4 <<egsi>>]");
    
}

// testing removeAt in a list whose size is bigger than 1
// the element removed is at the middle of the list
void removeAt_toNonEmpty_middle(){
    char arr[5] = {'i', 's', 'g','e','0'};
    CharLinkedList test_list(arr, 5);
    test_list.removeAt(2);
    assert(test_list.toString() == 
    "[CharLinkedList of size 4 <<ise0>>]");
    assert(test_list.toReverseString() == 
    "[CharLinkedList of size 4 <<0esi>>]");

}

// testing removeAt in a list whose size is bigger than 1
// the element removed is out of range
void removeAt_toNonEmpty_back_incorrect(){
    char arr[5] = {'i', 's', 'g','e','0'};
    CharLinkedList test_list(arr, 5);

    // var to track whether runtime_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.removeAt(999);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (999) not in range [0..5)"); 
}

// testing replaceAt in a nonempty list
// the element removed is out of range
void replaceAt_NonEmpty_incorrect(){
    char arr[5] = {'i', 's', 'g','e','0'};
    CharLinkedList test_list(arr, 5);

    // var to track whether runtime_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.replaceAt('p', 999);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (999) not in range [0..5)"); 
}

// testing replaceAt in a nonempty list
// the element removed is in range
void removeAt_NonEmpty_correct(){
    char arr[5] = {'i', 's', 'g','e','0'};
    CharLinkedList test_list(arr, 5);
    test_list.replaceAt('p', 2);
    assert(test_list.toString() == 
    "[CharLinkedList of size 5 <<ispe0>>]");
    assert(test_list.toReverseString() == 
    "[CharLinkedList of size 5 <<0epsi>>]");
}

// testing concatenate 2 nonempty lists
void concatenate_2nonEmpty(){
    char arr[5] = {'i', 's', 'g','e','0'};
    CharLinkedList test_list(arr, 5);
    char array[5] = {'o', 'p', 'l','k','m'};
    CharLinkedList test_list_2(array, 5);
    //CharLinkedList *other = &test_list_2;
    test_list.concatenate(&test_list_2);
    assert(test_list.toString() == 
    "[CharLinkedList of size 10 <<isge0oplkm>>]");
    assert(test_list.toReverseString() == 
    "[CharLinkedList of size 10 <<mklpo0egsi>>]");
}

// testing concatenate a nonempty list with an empty list
void concatenate_nonEmpty_empty(){
    char arr[5] = {'i', 's', 'g','e','0'};
    CharLinkedList test_list(arr, 5);
    CharLinkedList test_list_2;
    test_list.concatenate(&test_list_2);
    assert(test_list.toString() == 
    "[CharLinkedList of size 5 <<isge0>>]");
    assert(test_list.toReverseString() == 
    "[CharLinkedList of size 5 <<0egsi>>]");
    
}

// testing concatenate an empty list with a nonempty list
void concatenate_empty_nonEmpty(){
    char arr[5] = {'i', 's', 'g','e','0'};
    CharLinkedList test_list(arr, 5);
    CharLinkedList test_list_2;
    test_list_2.concatenate(&test_list);
    assert(test_list.toString() == 
    "[CharLinkedList of size 5 <<isge0>>]");
    assert(test_list.toReverseString() == 
    "[CharLinkedList of size 5 <<0egsi>>]");
}

// testing concatenate a nonempty list with itself
void concatenate_nonEmpty_itself(){
    char arr[5] = {'i', 's', 'g','e','0'};
    CharLinkedList test_list(arr, 5);
    test_list.concatenate(&test_list);
    assert(test_list.toString() == 
    "[CharLinkedList of size 10 <<isge0isge0>>]");
    assert(test_list.toReverseString() == 
    "[CharLinkedList of size 10 <<0egsi0egsi>>]");
}








/*
 *  unit_tests.h
 *  Kayla Lee (ylee35)
 *  1/31/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  FILE PURPOSE HERE
 *
 */

#include "CharLinkedList.h"
#include <cassert>

// Make sure there are no fatal errors/memory leaks in the default constructor
void defaultconstructor() {
    CharLinkedList list;
    assert(list.size() == 0);
}

// Tests correct initialization of the list with single character
void singlecharconstructor(){
    CharLinkedList list('a');

    assert(list.size() == 1);
    assert(list.elementAt(0) == 'a');
}

// Tests copy constructor, making sure that the copy hasn't changed after the
// original list has been modified.
void copyconstructor(){
    char array[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(array, 5);
    CharLinkedList copy(list);

    list.popFromFront();

    assert(copy.elementAt(0) == 'a');
}

// Tests the assignment operator with one empty array being copied from the
// nonempty array
void operatorEmpty(){
    char array[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(array, 5);
    CharLinkedList copy;

    copy = list;

    list.popFromBack();

    assert(list.toString() == "[CharLinkedList of size 4 <<abcd>>]");
    assert(copy.toString() == "[CharLinkedList of size 5 <<abcde>>]");
}

// Tests that the empty function returns true for an empty array
void emptycorrect(){
    CharLinkedList list;

    assert(list.isEmpty());
}

// Test that the empty function returns false for a nonempty array
void emptyincorrect(){
    CharLinkedList list('a');

    assert(not list.isEmpty());
}

// Tests the clear function, checking that the size is 0
void clearEmpty(){
    CharLinkedList list;
    list.clear();

    assert(list.isEmpty());
}

// Tests the clear function with a single character list
void clearSingleNonempty(){
    CharLinkedList list('a');
    list.clear();

    assert(list.isEmpty());
}

// Tests the clear function with a multiple character list
void clearNonempty(){
    char array[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(array, 5);
    list.clear(); 

    assert(list.isEmpty());
}

// Tests that an error is thrown for the first function with an empty list
void firstempty(){
    CharLinkedList list;
    bool error_thrown = false;
    string error_message;

    try {
        list.first();
    }
    catch (const std::runtime_error &e) {
        error_thrown = true;
        error_message = e.what();
    }

    assert(error_thrown);
    assert(error_message == "cannot get first of empty LinkedList");
}

// Tests the first function with a nonempty list
void firstnonempty(){
    char array[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(array, 5);

    assert(list.first() == 'a');
}

// Tests that an error is thrown for the last function with an empty list
void lastempty(){
    CharLinkedList list;
    bool error_thrown = false;
    string error_message;

    try {
        list.last();
    }
    catch (const std::runtime_error &e) {
        error_thrown = true;
        error_message = e.what();
    }

    assert(error_thrown);
    assert(error_message == "cannot get last of empty LinkedList");
}

// Test the last function with a nonempty list
void lastnonempty(){
    char array[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(array, 5);

    assert(list.last() == 'e');
}

// Tests the elementAt function with a single character list
void elementAtSingle(){
    CharLinkedList list('a');
    
    assert(list.elementAt(0) == 'a');
}

// Tests the elementAt function with an empty list and an incorrect index
void elementAtempty(){
    CharLinkedList list;
    bool error_thrown = false;
    string error_message;

    try {
        list.elementAt(0);
    }
    catch (const std::range_error &e) {
        error_thrown = true;
        error_message = e.what();
    }

    assert(error_thrown);
    assert(error_message == "index (0) not in range [0..0)");
}

// Tests the elementAt function with a nonempty list and a index that is in 
// range
void elementAtnonempty(){
    char array[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(array, 5);

    assert(list.elementAt(0) == 'a');
    assert(list.elementAt(1) == 'b');
    assert(list.elementAt(2) == 'c');
    assert(list.elementAt(3) == 'd');
    assert(list.elementAt(4) == 'e');
}

// Tests the elementAt function with a nonempty list but an out-of-range index
void elementAtIncorrect(){
    char array[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(array, 5);

    bool error_thrown = false;
    string error_message;

    try {
        list.elementAt(9);
    }
    catch (const std::range_error &e) {
        error_thrown = true;
        error_message = e.what();
    }

    assert(error_thrown);
    assert(error_message == "index (9) not in range [0..5)");
}

// Tests the toString function with an empty list
void toStringEmpty(){
    CharLinkedList list; 

    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}

// Tests the toString function with a nonempty list
void toStringNonempty(){
    char array[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(array, 5);

    assert(list.toString() == "[CharLinkedList of size 5 <<abcde>>]");
}

// Tests the toReverseString function with an empty list
void toReverseStringEmpty(){
    CharLinkedList list; 

    assert(list.toReverseString() == "[CharLinkedList of size 0 <<>>]");
}


// Test the toReverseString function with a nonempty list
void toReverseStringNonempty(){
    char array[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(array, 5);

    assert(list.toReverseString() == "[CharLinkedList of size 5 <<edcba>>]");
}

// Test the pushAtBack function with an empty list
void pushAtBackEmpty(){
    CharLinkedList list;
    list.pushAtBack('a');

    assert(list.size() == 1);
    assert(list.first() == 'a');
    assert(list.last() == 'a');
}

// Test the pushAtBack function with a single character list
void pushAtBackSingle(){
    CharLinkedList list('a');
    list.pushAtBack('d');

    assert(list.size() == 2);
    assert(list.last() == 'd');
    assert(list.elementAt(1) == 'd');
}

// Test the pushAtFront function with an empty list
void pushAtFrontEmpty(){
    CharLinkedList list;
    list.pushAtFront('a');

    assert(list.size() == 1);
    assert(list.first() == 'a');
    assert(list.last() == 'a');
}

// Test the pushAtFront function with a single character list
void pushAtFrontSingle(){
    CharLinkedList list('a');
    list.pushAtFront('d');

    assert(list.size() == 2);
    assert(list.first() == 'd');
    assert(list.elementAt(0) == 'd');
}

// Test the correct insertion into an empty list
void insertAtEmpty(){
    CharLinkedList list;
    list.insertAt('c', 0);

    assert(list.first() == 'c');
    assert(list.last() == 'c');
    assert(list.size() == 1);
}

// Tests insertion of a character into a single element list
void insertAtSingle(){
    CharLinkedList list('a');
    list.insertAt('c', 1);

    assert(list.toString() == "[CharLinkedList of size 2 <<ac>>]");
}

// Tests insertion of a character into a multiple character list
void insertAtMiddle(){
    char array[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(array, 5);
    list.insertAt('f', 3);

    assert(list.toString() == "[CharLinkedList of size 6 <<abcfde>>]");
}

// Test incorrect insertion of a character into a multiple character list 
void insertAtIncorrect(){
    char array[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(array, 5);

    bool error_thrown = false;
    string error_message;

    try {
        list.insertAt('f', 10);
    }
    catch (const std::runtime_error &e) {
        error_thrown = true;
        error_message = e.what();
    }

    assert(error_thrown);
    assert(error_message == "index (10) not in range [0..5]");
}

// Test incorrect insertion function with an empty list
void insertAtEmptyIncorrect(){
    CharLinkedList list;

    bool error_thrown = false;
    string error_message;

    try {
        list.insertAt('f', 10);
    }
    catch (const std::runtime_error &e) {
        error_thrown = true;
        error_message = e.what();
    }

    assert(error_thrown);
    assert(error_message == "index (10) not in range [0..0]");
}

// Tests correct insertion into the end of a nonempty list
void insertAtEnd(){
    char array[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(array, 5);
    list.insertAt('f', 5);

    assert(list.toString() == "[CharLinkedList of size 6 <<abcdef>>]");
}

// Tests correct insertion at the front of a nonempty list
void insertAtFront(){
    char array[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(array, 5);
    list.insertAt('f', 0);

    assert(list.toString() == "[CharLinkedList of size 6 <<fabcde>>]");
}

// Tests insertInOrder function with a character that should be placed in front
void insertInOrderFront(){
    char array[5] = {'z', 'b', 'c', 'd', 'e'};
    CharLinkedList list(array, 5);
    list.insertInOrder('a');


    assert(list.size() == 6);
    assert(list.toString() == "[CharLinkedList of size 6 <<azbcde>>]");
}

// Tests insertInOrder function with a character that is already in the list
void insertInOrderSame(){
    char array[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(array, 5);
    list.insertInOrder('c');

    assert(list.toString() == "[CharLinkedList of size 6 <<abccde>>]");
}

// Tests insertInOrder function with a character that should be in the middle
void insertInOrderMiddle(){
    char array[5] = {'a', 'c', 'g', 'z', 'b'};
    CharLinkedList list(array, 5);
    list.insertInOrder('d');

    assert(list.toString() == "[CharLinkedList of size 6 <<acdgzb>>]"); 
}

// Tests insertInOrder function with a character that should be placed at the 
// back
void insertInOrderBack(){
    char array[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(array, 5);
    list.insertInOrder('g');

    assert(list.toString() == "[CharLinkedList of size 6 <<abcdeg>>]"); 
}

// Tests insertInOrder function with an empty list
void insertInOrderEmpty(){
    CharLinkedList list;
    list.insertInOrder('g');

    assert(list.size() == 1);
    assert(list.elementAt(0) == 'g');
}

// Tests insertInOrder function with a single charater list, but the inserted
// element should be in the back
void insertInOrderSingle(){
    CharLinkedList list('c');
    list.insertInOrder('d');

    assert(list.toString() == "[CharLinkedList of size 2 <<cd>>]");
}

// Tests insertInOrder function with a single character list, but the inserted
// element should be in front
void insertInOrderSingleRev(){
    CharLinkedList list('c');
    list.insertInOrder('a');

    assert(list.toString() == "[CharLinkedList of size 2 <<ac>>]");
}

// Tests popFromFront function with an empty list
void popFromFrontEmpty(){
    CharLinkedList list;
    bool error_thrown = false;
    string error_message;

    try {
        list.popFromFront();
    }
    catch (const std::runtime_error &e) {
        error_thrown = true;
        error_message = e.what();
    }

    assert(error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

// Tests popFromFront function with a list of a single character
void popFromFrontSingle(){
    CharLinkedList list('a');
    list.popFromFront();

    assert(list.size() == 0);
    assert(list.isEmpty());
}

// Tests popFromFront function with a nonempty list
void popFromFrontNonempty(){
    char array[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(array, 5);
    list.popFromFront();
    
    assert(list.size() == 4);
    assert(list.elementAt(0) == 'b');
}

// Test the popFromFront function then test incorrect access
// to an out-of-range element
void popFromFrontAt(){
    char array[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(array, 5);
    list.popFromFront();
    
    bool error_thrown = false;
    string error_message;

    try {
        list.elementAt(4);
    }
    catch (const std::range_error &e) {
        error_thrown = true;
        error_message = e.what();
    }

    assert(error_thrown);
    assert(error_message == "index (4) not in range [0..4)");
}

// Tests popFromBack function with an empty list
void popFromBackEmpty(){
    CharLinkedList list;
    bool error_thrown = false;
    string error_message;

    try {
        list.popFromBack();
    }
    catch (const std::runtime_error &e) {
        error_thrown = true;
        error_message = e.what();
    }

    assert(error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

// Tests popFromBack function with a list of a single character
void popFromBackSingle(){
    CharLinkedList list('a');
    list.popFromBack();

    assert(list.size() == 0);
    assert(list.isEmpty());
}

// Tests popFromBack function with a nonempty lsit
void popFromBackNonempty(){
    char array[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(array, 5);
    list.popFromBack();
    
    assert(list.size() == 4);
    assert(list.elementAt(3) == 'd');
}

// Tests removeAt function for an empty list
void removeAtEmpty(){
    CharLinkedList list;

    bool error_thrown = false;
    string error_message;

    try {
        list.removeAt(0);
    }
    catch (const std::runtime_error &e) {
        error_thrown = true;
        error_message = e.what();
    }

    assert(error_thrown);
    assert(error_message == "index (0) not in range [0..0)");
}

// Test removeAt function for a nonempty list
void removeAtNonempty(){
    char array[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(array, 5);
    list.removeAt(3);

    assert(list.toString() == "[CharLinkedList of size 4 <<abce>>]");
}

// Test removeAt function for a single character list
void removeAtSingle(){
    CharLinkedList list('c');
    list.removeAt(0);

    assert(list.isEmpty());
}

// Test removeAt function for the back element of a nonempty list
void removeAtEnd(){
    char array[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(array, 5);
    list.removeAt(4);

    assert(list.toString() == "[CharLinkedList of size 4 <<abcd>>]");
}

// Test removeAt function for the front element of a nonempty list
void removeAtFront(){
    char array[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(array, 5);
    list.removeAt(0);

    assert(list.toString() == "[CharLinkedList of size 4 <<bcde>>]");
}

// Test replaceAt function for a single character list
void replaceAtSingle(){
    CharLinkedList list('c');
    list.replaceAt('d', 0);

    assert(list.first() == 'd');
    assert(list.size() == 1);
}

// Tests replaceAt function for an incorrect index
void replaceAtIncorrect(){
    char array[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(array, 5);

    bool error_thrown = false;
    string error_message;

    try {
        list.removeAt(10);
    }
    catch (const std::runtime_error &e) {
        error_thrown = true;
        error_message = e.what();
    }

    assert(error_thrown);
    assert(error_message == "index (10) not in range [0..5)");
}

// Tests replaceAt function with a nonempty list and correct index
void replaceAtCorrect(){
    char array[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(array, 5);
    list.replaceAt('f', 2);

    assert(list.toString() == "[CharLinkedList of size 5 <<abfde>>]");
}

// Tests replaceAt function with an index at the front of the list
void replaceAtFront(){
    char array[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(array, 5);
    list.replaceAt('f', 0);

    assert(list.toString() == "[CharLinkedList of size 5 <<fbcde>>]");
}

// Test replaceAt function with an index at the back of the list
void replaceAtEnd(){
    char array[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(array, 5);
    list.replaceAt('f', 4);

    assert(list.toString() == "[CharLinkedList of size 5 <<abcdf>>]");
}

// Test concatenate with an empty list to itself
void concatenateEmpty(){
    CharLinkedList list;
    list.concatenate(&list);

    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}

// Test concatenate with two empty lists
void concatenate2Empty(){
    CharLinkedList list;
    CharLinkedList otherlist;
    list.concatenate(&otherlist);

    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}

// Test concatenation of a nonempty list to an empty list
void concatenate1Empty(){
    char array[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(array, 5);
    CharLinkedList otherlist;
    list.concatenate(&otherlist);

    assert(list.toString() == "[CharLinkedList of size 5 <<abcde>>]");
}

// Test concatenation of an empty list to a nonempty list
void concatenate1EmptyReverse(){
    char array[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(array, 5);
    CharLinkedList otherlist;
    otherlist.concatenate(&list);

    assert(list.toString() == "[CharLinkedList of size 5 <<abcde>>]");
}

// Test concatenate of a nonempty list to itself
void concatenateItselfTest(){
    char array[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(array, 5);
    list.concatenate(&list);

    assert(list.toString() == "[CharLinkedList of size 10 <<abcdeabcde>>]");
}

// Test concatenate of a nonempty list to another nonempty list
void concatenateOtherTest(){
    char array1[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list1(array1, 5);
    char array2[4] = {'f', 'g', 'h', 'i'};
    CharLinkedList list2(array2, 4);
    list1.concatenate(&list2);

    assert(list1.toString() == "[CharLinkedList of size 9 <<abcdefghi>>]");
}
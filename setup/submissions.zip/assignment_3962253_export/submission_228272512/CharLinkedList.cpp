/*
 *  CharLinkedList.cpp
 *  Kayla Lee (ylee35)
 *  1/31/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  FILE PURPOSE HERE
 *
*/

#include "CharLinkedList.h"

/*
 * Default Constructor
 * Purpose: Initializes an empty list with front and back pointers pointing to
 *          nullptrs. Size is set to 0. 
 * Parameters: N/A
 * Return: N/A
*/
CharLinkedList::CharLinkedList(){
    listsize = 0; 
    front = nullptr; 
    back = nullptr; 
}

/*
 * Single Character Constructor
 * Purpose: Creates a single element list; both the front and back pointer
 *          points to the element. 
 * Parameters: Character that is inputted as the single element in the list.
 * Return: N/A
*/
CharLinkedList::CharLinkedList(char c){
    listsize = 0;
    Node *newnode = newNode(c, nullptr, nullptr);
    front = newnode;
    back = newnode;
}

/*
 * Array Constructor
 * Purpose: Creates a linked list with an inputted array of characters. 
 * Parameters: An array of characters and its size. 
 * Return: N/A
*/
CharLinkedList::CharLinkedList(char arr[], int size){
    listsize = 0; 
    front = nullptr; 
    back = nullptr;

    for (int i = 0; i < size; i++){
        pushAtBack(arr[i]);
    }
}

/*
 * Copy Constructor
 * Purpose: Creates a deep copy of another instance of the linked list class.
 * Parameters: Address of an instance of an linked list. 
 * Return: N/A
*/
CharLinkedList::CharLinkedList(const CharLinkedList &other){
    listsize = 0;
    front = nullptr;
    back = nullptr;

    for (int i = 0; i < other.listsize; i++){
        pushAtBack(other.elementAt(i)); 
    }
}

/*
 * Destructor
 * Purpose: Recycles all heap-allocated memory using a helper recursive 
 *          function. 
 * Parameters: N/A
 * Return: N/A
*/
CharLinkedList::~CharLinkedList(){
    deleteRec(front);
}

/*
 * Assignment Operator 
 * Purpose: Defines an assignment operator that makes a deep copy of the
 *          instance on the right hand side into the instance on the 
 *          left hand side. Recycles the storage associated with the instance
 *          on the left of the assignment.
 * Parameters: Address of an instance of an linked list. 
 * Return: A deep copied instance of the right hand side. 
*/
CharLinkedList &CharLinkedList::operator =(const CharLinkedList &other){
    if (this == &other){
        return *this;
    }

    clear();

    listsize = 0;
    for (int i = 0; i < other.listsize; i++){
        pushAtBack(other.elementAt(i)); 
    }
    
    return *this;
}

/*
 * isEmpty
 * Purpose: Determines if the linked list is empty. 
 * Parameters: N/A
 * Return: True if empty, false if not. 
*/
bool CharLinkedList::isEmpty() const{
    return (listsize == 0);
}

/*
 * clear
 * Purpose: Clears the linked list using a recursive helper function, setting
 *          the front and back pointers to null. 
 * Parameters: N/A
 * Return: N/A
*/
void CharLinkedList::clear(){
    deleteRec(front);
    front = nullptr;
    back = nullptr;
}

/*
 * size
 * Purpose: Gets the size of the linked list. 
 * Parameters: N/A
 * Return: An integer value of the size of the linked list.
*/
int CharLinkedList::size() const {
    return listsize;
}


/*
 * first
 * Purpose: Returns the first element of the linked list. 
 * Parameters: N/A
 * Return: N/A
 * Effects: Raises an error if the linked list is empty.
*/
char CharLinkedList::first() const {
    if (isEmpty()){
        throw runtime_error("cannot get first of empty LinkedList");
    }
    return front->character;
}

/*
 * last
 * Purpose: Returns the last element of the linked list. 
 * Parameters: N/A
 * Return: N/A
 * Effects: Raises an error if the linked list is empty.
*/
char CharLinkedList::last() const {
    if (isEmpty()){
        throw runtime_error("cannot get last of empty LinkedList");
    }
    return back->character;
}

/*
 * elementAt
 * Purpose: Takes an integer index and returns the element, a character, in 
 *          the linked list at that index. Uses a recursive helper function
 *          to find the node at that index. 
 * Parameters: Index
 * Return: Character at the provided index. 
 * Effects: Raises an error if the inputted index is not in the range of
 *          the linked list size. 
*/
char CharLinkedList::elementAt(int index) const {
    if (index < 0 or index >= listsize){
        string error; 
        error = "index (" + to_string(index) + ") not in range [0.." + 
        to_string(listsize) + ")";
        throw range_error(error);
    }

    int curr_index = 0;
    Node *element = findNodeRec(front, index, curr_index);

    return element->character;
}

/*
 * toString
 * Purpose: Returns a string of a statement including the size and elements
 *          of the linked list.  
 * Parameters: N/A
 * Return: A string that contains the characters of the linked list. 
*/
string CharLinkedList::toString() const {
    string message = "[CharLinkedList of size "; 
    message += to_string(size());
    message += " <<";
    for (int i = 0; i < size(); i++){
        message += elementAt(i);
    }
    message+= ">>]";
    return message;
}

/*
 * toReverseString
 * Purpose: Returns a string of a statement including the size and elements
 *          of the linked list in reverse. 
 * Parameters: N/A
 * Return: A string that contains the characters of the linked list. 
*/
string CharLinkedList::toReverseString() const {
    string message = "[CharLinkedList of size "; 
    message += to_string(listsize);
    message += " <<";
    for (int i = listsize - 1; i >= 0; i--){
        message += elementAt(i);
    }
    message+= ">>]";

    return message;
}

/*
 * pushAtBack
 * Purpose: Inserts a given new element after the end of the existing 
 *          elements of the linked list.
 * Parameters: Character to be inserted.
 * Return: N/A
*/
void CharLinkedList::pushAtBack(char c){
    Node *node = newNode(c, back, nullptr);

    if (listsize == 1){
        front = node;
        back = node;
        return;
    }

    back->next = node;
    back = node;
}

/*
 * pushAtFront
 * Purpose: Inserts a given new element at the front of the existing 
 *          elements of the linked list.
 * Parameters: Character to be inserted.
 * Return: N/A
*/
void CharLinkedList::pushAtFront(char c){
    Node *node = newNode(c, nullptr, front);
    
    if (listsize == 1){
        back = node;
        front = node;
        return;
    }

    front->previous = node;
    front = node; 
}

/*
 * insertAt
 * Purpose: Inserts a new character at the specified index and shifts the
 *          existing elements as necessary. The new element is then in 
 *          the index-th position. 
 * Parameters: Character to be inserted and the index it should be inserted 
 *             into.
 * Return: N/A
 * Effect: Raises an error if the inputted index is not in the range of
 *         the linked list size. 
*/
void CharLinkedList::insertAt(char c, int index){
    if (index < 0 or index > listsize){
        string error; 
        error = "index (" + to_string(index) + ") not in range [0.." + 
        to_string(listsize) + "]";
        throw range_error(error);
    }

    if (index == 0){
        pushAtFront(c);
        return;
    }

    if (index == listsize){
        pushAtBack(c);
        return;
    }

    Node *newnode = newNode(c, nullptr, nullptr);
    int curr_index = 0;
    Node *original = findNodeRec(front, index, curr_index);

    original->previous->next = newnode;
    newnode->previous = original->previous;
    original->previous = newnode;
    newnode->next = original;
}

/*
 * insertInOrder
 * Purpose: Takes an element (char) and inserts it into the linked list in 
 *          ASCII order. 
 * Parameters: Character to be inserted.
 * Return: N/A
*/
void CharLinkedList::insertInOrder(char c){
    if (isEmpty()){
        pushAtBack(c);
        return;
    }

    for (int i = 0; i < listsize; i++){
        if (elementAt(i) > c){
            insertAt(c, i);
            return;
        }
    }

    for (int i = 0; i < listsize; i++){
        if (elementAt(i) < c){
            pushAtBack(c);
            return;
        }
    }
}

/*
 * popFrontFront
 * Purpose: Removes the first element from the linked list.  
 * Parameters: N/A
 * Return: N/A
 * Effect: Raises an error if the linked list is empty. 
*/
void CharLinkedList::popFromFront(){
    if (isEmpty()){
        throw runtime_error("cannot pop from empty LinkedList");
    }

    if (listsize == 1){
        clear();
        return;
    }

    Node *oldfront; 
    oldfront = front;
    front = oldfront->next;
    listsize --;
    delete oldfront;
    front->previous = nullptr;
}

/*
 * popFromBack
 * Purpose: Removes the last element from the linked list.  
 * Parameters: N/A
 * Return: N/A
 * Effect: Raises an error if the linked list is empty. 
*/
void CharLinkedList::popFromBack(){
    if (isEmpty()){
        throw runtime_error("cannot pop from empty LinkedList");
    }

    if (listsize == 1){
        clear();
        return;
    }

    Node *oldback;
    oldback = back;
    back = oldback->previous;
    listsize --;
    delete oldback;
    back->next = nullptr;
}

/*
 * removeAt
 * Purpose: Removes the element at the specified index. 
 * Parameters: Index of the element that is to be removed. 
 * Return: N/A
 * Effect: Raises an error if the inputted index is not in the range of
 *         the linked list size. 
*/
void CharLinkedList::removeAt(int index){
    if (index < 0 or index >= listsize){
        string error; 
        error = "index (" + to_string(index) + ") not in range [0.." + 
        to_string(listsize) + ")";
        throw range_error(error);
    }

    if (index == 0){
        popFromFront();
        return;
    }
    if (index == listsize - 1){
        popFromBack();
        return;
    }

    Node *currnode = front;
    int count = 0;
    while (count != index){
        currnode = currnode->next;
        count++;
    }

    Node *currprev = currnode->previous;
    Node *currnext = currnode->next;
    currprev->next = currnode->next;
    currnext->previous = currnode->previous;

    delete currnode;
    listsize--;
}

/*
 * replaceAt
 * Purpose: Takes a character and replaces the element at the specified index 
 *          with the new element.
 * Parameters: A character to be replaced with and the index of the element 
 *             that should be removed.
 * Return: N/A
 * Effect: Raises an error if the inputted index is not in the range of
 *         the linked list size. 
*/
void CharLinkedList::replaceAt(char c, int index){
    if (index < 0 or index >= listsize){
        string error; 
        error = "index (" + to_string(index) + ") not in range [0.." + 
        to_string(listsize) + ")";
        throw range_error(error);
    }

    int curr_index = 0;
    Node *element = findNodeRec(front, index, curr_index);
    element->character = c;
}

/*
 * concatenate
 * Purpose: Adds a copy of the linked list pointed to by the parameter value
 *          to the end of the linked list the function was called from.
 * Parameters: A pointer to a second CharLinkedList that is to be copied. 
 * Return: N/A
*/
void CharLinkedList::concatenate(CharLinkedList *other){
    if (toString() == other->toString()){
        const int size = listsize;
        for (int i = 0; i < size; i++){
            pushAtBack(elementAt(i));
        }
        return;
    }

    for (int i = 0; i < other->size(); i++){
        pushAtBack(other->elementAt(i));
    }
}

/*
 * newNode
 * Purpose: Creates a new node.
 * Parameters: The character the new node should contain, a pointer to the 
 *             previous and next node of the new node. 
 * Return: Node Pointer
*/
CharLinkedList::Node *CharLinkedList::newNode(char new_character, Node 
*previous, Node *next){
    Node *new_node = new Node;
    new_node->character = new_character;
    new_node->previous = previous;
    new_node->next = next;
    listsize++;
    return new_node;
}

/*
 * findNodeRec
 * Purpose: Finds a node at a specified index using recursion and returns it.
 * Parameters: The node and index of the list the function should start looking
 *              at, the index of the node to be found. 
 * Return: Node Pointer
*/
CharLinkedList::Node *CharLinkedList::findNodeRec(Node *curr_node, int index, 
int curr_index) const {
    if (curr_index == index){
        return curr_node;
    }

    else {
        Node *next = curr_node->next;
        curr_index++;
        return findNodeRec(next, index, curr_index);
    }

    return nullptr;
}

/*
 * deleteRec
 * Purpose: Deletes the list recursively. 
 * Parameters: The node that the function should start deleting at. 
 * Return: N/A
*/
void CharLinkedList::deleteRec(Node *currnode){
    if (currnode == nullptr){
        return;
    }
    else {
        Node *next = currnode->next;
        delete currnode;
        listsize--;
        deleteRec(next);
    }
}
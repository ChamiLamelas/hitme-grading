/*
 *  CharLinkedList.cpp
 *  Lindsay Ulrey
 *  2/3/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Implement functions of CharLinkedList class,
 *  which defines a list of nodes linked with
 *  pointers.
 *
 */

#include "CharLinkedList.h"
#include <sstream>
#include <iostream>

/*
 * name: CharLinkedList default constructor
 * purpose: initialize front to nullptr
 * arguments: none
 * returns: none
 * effects: front to nullptr, size to 0
 */
CharLinkedList::CharLinkedList() {
    front = nullptr;
    numItems = 0;
}

/*
 * name: CharLinkedList one element constructor
 * purpose: create first node with input data
 * arguments: char of node
 * returns: none
 * effects: front to new node
 */
CharLinkedList::CharLinkedList(char c) {
    front = newNode(c, nullptr, nullptr);
    numItems = 1;
}

/*
 * name: CharLinkedList array constructor
 * purpose: creates multiple linked nodes with
 *          input data
 * arguments: array of chars to become nodes,
 *            size of array
 * returns: none
 * effects: front to first node, rest linked,
 *          sets size to input size
 */
CharLinkedList::CharLinkedList(char arr[], int size) {
    if (size == 1) {
        front = newNode(arr[0], nullptr, nullptr);
    }
    else {
        Node *nodes[size]; // holds pointers to newly created nodes

        // creates and stores each new node
        for (int i = 0; i < size; i++) {
            nodes[i] = newNode(arr[i], nullptr, nullptr);
        }

        // links nodes
        front = nodes[0];
        nodes[0]->next = nodes[1];

        for (int i = 1; i < size-1; i++) {
            nodes[i]->prev = nodes[i-1];
            nodes[i]->next = nodes[i+1];
        }

        nodes[size-1]->prev = nodes[size-2];
    }

    numItems = size;
}

/*
 * name: CharLinkedList copy constructor
 * purpose: creates deep copy of input list
 * arguments: CharLinkedList to copy
 * returns: none
 * effects: creates new CharLinkedList
 *          updates size
 */ 
CharLinkedList::CharLinkedList(const CharLinkedList &other) {
    numItems = 0;

    if (other.isEmpty()) {
        front = nullptr;
        numItems = 0;
    }
    else if (other.size() == 1) {
        front = newNode(other.front->data, nullptr, nullptr);
        numItems = 1;
    }
    else {
        for (int i = 0; i < other.size(); i++) {
            pushAtBack(other.elementAt(i));
        }

        numItems = other.numItems;
    }
}

/*
 * name: destructor
 * purpose: recycle memory of list
 * arguments: none
 * returns: none
 * effects: recycles memory
 */
CharLinkedList::~CharLinkedList() {
    destructorHelper(front);
    front = nullptr; // "resets" front
}

/*
 * name: destructorHelper
 * purpose: recursively deletes nodes
 * arguments: pointer to current node (start at front)
 * returns: next node
 * effects: recycles memory, decrements numItems
 */
void CharLinkedList::destructorHelper(Node *curr) {
    if (curr == nullptr) {
        return;
    }
    else {
        Node *next  = curr->next;
        delete curr;
        numItems--;
        destructorHelper(next);
    }
}

/*
 * name: CharLinkedList assignment operator
 * purpose: recycles list on left hand side,
 *          replaces with deep copy of right
 *          hand side
 * arguments: CharLinkedList to copy
 * returns: none
 * effects: recycles memory of LHS, creates
 *          copy of RHS
 */
CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other) {
    // checks if assigning to same list
    if (this == &other) {
        return *this;
    }
    
    clear(); // resets LHS

    Node *curr = other.front;
    while(curr != nullptr) {
        pushAtBack(curr->data);
        curr = curr->next;
    }

    numItems = other.numItems;

    return *this;
}

/*
 * name: isEmpty
 * purpose: indicate if list has no nodes
 * arguments: none
 * returns: none
 * effects: none
 */
bool CharLinkedList::isEmpty() const {
    if (numItems == 0) {
        return true;
    }
    else {
        return false;
    }
}

/*
 * name: clear
 * purpose: to replace instance with empty list
 * arguments: none
 * returns: none
 * effects: recycles memory of list, removes
 *          all nodes, size to 0
 */
void CharLinkedList::clear() {
    destructorHelper(front);
    front = nullptr; // "resets" front
    numItems = 0; // "resets" numItems
}

/*
 * name: size
 * purpose: to get size of list
 * arguments: none
 * returns: number of nodes of list
 * effects: none
 */
int CharLinkedList::size() const {
    return numItems;
}

/*
 * name: first
 * purpose: to get char of first node
 * arguments: none
 * returns: char of first node
 * effects: none
 */
char CharLinkedList::first() const {
    if (isEmpty()) {
        throw std::runtime_error("cannot get first of empty LinkedList");
    }
    else {
        return front->data;
    }
}

/*
 * name: last
 * purpose: to get char of last node
 * arguments: none
 * returns: char of last node
 * effects: none
 */
char CharLinkedList::last() const {
    if (isEmpty()) {
        throw std::runtime_error("cannot get last of empty LinkedList");
    }
    else {
        Node *last = getLast();
        return last->data;
    }
}

/*
 * name: elementAt
 * purpose: to get char of specified element
 * arguments: index of specified element
 * returns: char of specified node
 * effects: none
 */
char CharLinkedList::elementAt(int index) const {
    if (isEmpty() or index < 0 or index >= numItems) {
        throw std::range_error("index (" + std::to_string(index) +
        ") not in range [0.." + std::to_string(numItems) + ")");
    }
    else {
        Node *curr = getIndex(index);
        return curr->data;
    }
}

/*
 * name: toString
 * purpose: display chars of list
 * arguments: none
 * returns: string of chars of list
 * effects: none
 */
std::string CharLinkedList::toString() const {
    Node *curr = front;
    std::stringstream ss;
    ss << "[CharLinkedList of size " << std::to_string(numItems) << " <<";

    while (curr != nullptr) {
        ss << curr->data;
        curr = curr->next;
    }

    ss << ">>]";
    
    return ss.str();
}

/*
 * name: toReverseString
 * purpose: display chars of list in reverse order
 * arguments: none
 * returns: string of chars of list in reverse order
 * effects: none
 */
std::string CharLinkedList::toReverseString() const {
    Node *curr = getLast();
    std::stringstream ss;
    ss << "[CharLinkedList of size " << std::to_string(numItems) << " <<";

    while (curr != nullptr) {
        ss << curr->data;
        curr = curr->prev;
    }

    ss << ">>]";
    
    return ss.str();
}

/*
 * name: pushAtBack
 * purpose: add nodes to end of list
 * arguments: none
 * returns: none
 * effects: makes new node and adds to end
 */
void CharLinkedList::pushAtBack(char c) {

    if (isEmpty()) {
        front = newNode(c, nullptr, nullptr);
    }
    else {
        Node *last = getLast();
        last->next = newNode(c, last, nullptr);
    }
}

/*
 * name: pushAtFront
 * purpose: add nodes to front of list
 * arguments: none
 * returns: none
 * effects: makes new node and adds to front
 */
void CharLinkedList::pushAtFront(char c) {
    front = newNode(c, nullptr, front);
}

/*
 * name: insertAt
 * purpose: add specified node in input location
 * arguments: char of node, index to insert at
 * returns: none
 * effects: makes new node and adds to specified
 *          location
 */
void CharLinkedList::insertAt(char c, int index) {
    if (index < 0 or index > numItems) {
        throw std::range_error("index (" + std::to_string(index) + 
        ") not in range [0.." + std::to_string(numItems) + "]");
    }
    else if (isEmpty()) {
        front = newNode(c, nullptr, nullptr);
    }
    else if (index == 0) {
        pushAtFront(c);
    }
    else if (index == numItems) {
        pushAtBack(c);
    }
    else {
        Node *before = getIndex(index-1);
        Node *after = getIndex(index);

        Node *newItem = newNode(c, before, after);

        // fixes pointers of before and after
        before->next = newItem;
        after->prev = newItem;
    }   
}

/*
 * name: insertInOrdeer
 * purpose: add specified node in correct location
 *          based on ASCII order
 * arguments: char of node
 * returns: none
 * effects: makes new node and adds to correct
 *          location
 */
void CharLinkedList::insertInOrder(char c) {
    if (isEmpty()) {
        pushAtFront(c);
    }
    else {
        int index = 0;
        Node *curr = front;

        while ((index < numItems) and (curr->data <= c)) {
            curr = curr->next;
            index++;
        }

        insertAt(c, index);
    }
}

/*
 * name: popFromFront
 * purpose: removes first node
 * arguments: none
 * returns: none
 * effects: delete first node, reassign
 *          front, decrement numItems
 */
void CharLinkedList::popFromFront() {
    if (isEmpty()) {
        throw std::runtime_error("cannot pop from empty LinkedList");
    }
    else {
        Node *oldFront = front;
        front = front->next;
        delete oldFront;
        numItems--;
    }
}

/*
 * name: popFromBack
 * purpose: removes last node
 * arguments: none
 * returns: none
 * effects: delete last node, reassign
 *          pointer of new last,
 *          decrement numItems
 */
void CharLinkedList::popFromBack() {
    if (isEmpty()) {
        throw std::runtime_error("cannot pop from empty LinkedList");
    }
    else if (numItems == 1) {
        clear();
    }
    else {
        Node *oldBack = getLast();
        Node *newBack = oldBack->prev;
        delete oldBack;
        newBack->next = nullptr;
        numItems--;
    }
}

/*
 * name: removeAt
 * purpose: removes specified node
 * arguments: index of node to remove
 * returns: none
 * effects: delete specified node, reassign
 *          necessary pointers, decrement numItems
 */
void CharLinkedList::removeAt(int index) {
    if (isEmpty() or index < 0 or index >= numItems) {
        throw std::range_error("index (" + std::to_string(index) + 
        ") not in range [0.." + std::to_string(numItems) + ")");
    }
    else if (index == 0) {
        popFromFront();
    }
    else if (index == numItems) {
        popFromBack();
    }
    else {
        Node *curr = getIndex(index);
        Node *before = curr->prev;
        Node *after = curr->next;
        delete curr;
        before->next = after;
        after->prev = before;
        numItems--;
    }
}

/*
 * name: replaceAt
 * purpose: replaces char of specified node with
 *          input char
 * arguments: char of "new" node, index of node to replace
 * returns: none
 * effects: changes char of specified node
 */
void CharLinkedList::replaceAt(char c, int index) {
    if (isEmpty() or index < 0 or index >= numItems) {
        throw std::range_error("index (" + std::to_string(index) + 
        ") not in range [0.." + std::to_string(numItems) + ")");
    }
    else {
        Node *curr = getIndex(index);
        curr->data = c;
    }
}

/*
 * name: concetenate
 * purpose: "add" two lists together
 * arguments: pointer to list to concatenate
 * returns: none
 * effects: adds new list to end of current list
 */
void CharLinkedList::concatenate(CharLinkedList *other) {
    Node *curr = other->front;
    int size = other->numItems;
    for (int i = 0; i < size; i++) {
        pushAtBack(curr->data);
        curr = curr->next;
    }
}

/*
 * name: newNode
 * purpose: create a new node with specified pointers
 * arguments: character for node, pointer to previous
 *            and subsequent nodes
 * returns: pointer to newly created node
 * effects: makes a node and adds it to the list
 *          increments numItems
 */
CharLinkedList::Node *CharLinkedList::newNode(char c, Node *bef, Node *aft) {
    Node *newItem = new Node;
    newItem->data = c;
    newItem->prev = bef;
    newItem->next = aft;

    numItems++;

    return newItem;
}

/*
 * name: getLast
 * purpose: to get last node
 * arguments: none
 * returns: pointer to last node
 * effects: none
 */
CharLinkedList::Node *CharLinkedList::getLast() const {
    Node *curr = front;

    while (curr->next != nullptr) {
        curr = curr->next;
    }

    return curr;
}

/*
 * name: getIndex
 * purpose: to get node at specified index
 * arguments: none
 * returns: pointer to specified node
 * effects: none
 */
CharLinkedList::Node *CharLinkedList::getIndex(int index) const {
    Node *curr = front;
    return indHelp(curr, index, 0);
}

/*
 * name: indHelp
 * purpose: recursively loop through list until
 *          reach target node
 * arguments: none
 * returns: pointer to specified node
 * effects: none
 */
CharLinkedList::Node *CharLinkedList::indHelp(Node *c, int ind, int i) const {
    if (i == ind) {
        return c;
    }
    else {
        return indHelp(c->next, ind, i+1);
    }
}
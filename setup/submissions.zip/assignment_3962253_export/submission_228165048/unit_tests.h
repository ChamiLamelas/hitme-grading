/*
 *  unit_tests.h
 *  Lindsay Ulrey
 *  2/4/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  Automatically runs tests below with command unit-test.
 *  Displays results and outputs of tests.
 * 
 */

#include "CharLinkedList.h"
#include <cassert>
#include <iostream>

// tests: default constructor, size, isEmpty
void default_check() {
    CharLinkedList test;

    assert(test.size() == 0);
    assert(test.isEmpty());
}

// tests: one node constructor, elemAt
void one_node_check() {
    CharLinkedList test('A');

    assert(test.size() == 1);
    assert(test.elementAt(0) == 'A');
}

// tests: mult node constructor, size
void mult_node_check() {
    char arr[] = {'a', 'b', 'c'};
    CharLinkedList test(arr, 3);
    
    assert(test.size() == 3);
}

// tests: mult node constructor, clear, size, isEmpty
void clear_check() {
    char arr[] = {'a', 'b', 'c'};
    CharLinkedList test(arr, 3);
    test.clear();
    
    assert(test.size() == 0);
    assert(test.isEmpty());
}

// tests: mult node constructor, elementAt
void large_list() {
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    for (int i = 0; i < 9; i++) {
        assert(test_list.elementAt(i) == test_arr[i]);
    }
}

// tests: copy constructor for single node
void copy_one_check() {
    CharLinkedList one('A');
    CharLinkedList two(one);

    assert(two.elementAt(0) == one.elementAt(0));
    assert(two.size() == 1);
}

// tests: copy constructor for multiple nodes
void copy_mult_check() {
    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList one(arr, 5);
    CharLinkedList two(one);

    assert(one.toString() == two.toString());
    assert(one.size() == two.size());
}

// tests: copy constructor using empty list
void copy_with_empty() {
    CharLinkedList one;
    CharLinkedList two(one);

    assert(one.toString() == two.toString());
    assert(one.size() == two.size());
}

// tests: assignment operator with one node list
void assignment_op_one() {
    CharLinkedList one('a');
    CharLinkedList two('b');

    one = two;

    assert(one.elementAt(0) == 'b');
}

// tests: assignment operator for larger lists of same size
void assignment_op_mult() {
    char arr1[5] = {'a', 'b', 'c', 'd', 'e'};
    char arr2[5] = {'f', 'g', 'h', 'i', 'j'};
    CharLinkedList one(arr1, 5);
    CharLinkedList two(arr2, 5);

    one = two;

    assert(one.toString() == two.toString());
    assert(one.size() == two.size());
}

// tests: assignment operator for assigning smaller list
//        to larger
void assignment_op_small_big() {
    char arr1[5] = {'a', 'b', 'c', 'd', 'e'};
    char arr2[3] = {'f', 'g', 'h'};
    CharLinkedList one(arr1, 5);
    CharLinkedList two(arr2, 3);

    one = two;

    assert(one.toString() == two.toString());
    assert(one.size() == two.size());
}

// tests: assignment operator for assigning larger list
//        to smaller
void assignment_op_big_small() {
    char arr1[5] = {'a', 'b', 'c', 'd', 'e'};
    char arr2[3] = {'f', 'g', 'h'};
    CharLinkedList one(arr1, 5);
    CharLinkedList two(arr2, 3);

    two = one;

    assert(two.toString() == one.toString());
    assert(two.size() == one.size());
}

// tests: first on empty list
void first_empty() {
    CharLinkedList test;

    // var to track whether error is thrown
    bool error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test.first();
    }
    catch (const std::runtime_error &e) {
        error_thrown = true;
        error_message = e.what();
    }

    assert(error_thrown);
    assert(error_message == "cannot get first of empty LinkedList");
}

// tests: first
void first_correct() {
    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList test(arr, 5);

    assert(test.first() == 'a');
}

// tests: last on empty list
void last_empty() {
    CharLinkedList test;

    // var to track whether error is thrown
    bool error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test.last();
    }
    catch (const std::runtime_error &e) {
        error_thrown = true;
        error_message = e.what();
    }

    assert(error_thrown);
    assert(error_message == "cannot get last of empty LinkedList");
}

// tests: last
void last_correct() {
    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList test(arr, 5);

    assert(test.last() == 'e');
}

// tests: elementAt, first, last
void elementAt_correct() {
    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList test(arr, 5);

    assert(test.elementAt(0) == 'a');
    assert(test.elementAt(0) == test.first());
    assert(test.elementAt(4) == 'e');
    assert(test.elementAt(4) == test.last());
    assert(test.elementAt(2) == 'c');
}

// tests: elementAt with index out of range on high end
void elementAt_range_high() {
    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList test(arr, 5);

    // var to track whether error is thrown
    bool error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test.elementAt(5);
    }
    catch (const std::range_error &e) {
        error_thrown = true;
        error_message = e.what();
    }

    assert(error_thrown);
    assert(error_message == "index (5) not in range [0..5)");
}

// tests: elementAt with index out of range on low end
void elementAt_range_low() {
    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList test(arr, 5);

    // var to track whether error is thrown
    bool error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test.elementAt(-1);
    }
    catch (const std::range_error &e) {
        error_thrown = true;
        error_message = e.what();
    }

    assert(error_thrown);
    assert(error_message == "index (-1) not in range [0..5)");
}

// tests: elementAt with empty list
void elementAt_empty() {
    CharLinkedList test;

    // var to track whether error is thrown
    bool error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test.elementAt(2);
    }
    catch (const std::range_error &e) {
        error_thrown = true;
        error_message = e.what();
    }

    assert(error_thrown);
    assert(error_message == "index (2) not in range [0..0)");
}

// tests: toReverseString
void reverse_correct() {
    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList test(arr, 5);

    test.insertAt('z', 1);

    assert(test.toReverseString() == 
        "[CharLinkedList of size 6 <<edcbza>>]");
}

// tests: pushAtBack on empty list
void push_back_empty() {
    CharLinkedList test;

    test.pushAtBack('a');
    test.pushAtBack('b');

    assert(test.size() == 2);
    assert(test.elementAt(1) == 'b');
}

// tests: pushAtFront on empty list
void push_front_empty() {
    CharLinkedList test;

    test.pushAtFront('o');
    test.pushAtFront('l');
    test.pushAtFront('l');
    test.pushAtFront('e');
    test.pushAtFront('h');

    assert(test.size() == 5);
    assert(test.elementAt(0) == 'h');
    assert(test.toString() == 
        "[CharLinkedList of size 5 <<hello>>]");
}

// tests: pushAtFront on mult node list
void push_front_mult() {
    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList test(arr, 5);

    test.pushAtFront('y');
    test.pushAtFront('z');

    assert(test.size() == 7);
    assert(test.elementAt(0) == 'z');
    assert(test.toString() == 
        "[CharLinkedList of size 7 <<zyabcde>>]");
}

// tests: insertAt multiple times
void insert_mult() {
    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList test(arr, 5);

    test.insertAt('z', 1);
    test.insertAt('t', 1);

    assert(test.elementAt(1) == 't');
}

// Tests correct insertion into an empty AL.
// Afterwards, size should be 1 and element at index 0
// should be the element we inserted.
void insertAt_empty_correct() { 

    CharLinkedList test_list;
    test_list.insertAt('a', 0);
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');

}

// Tests incorrect insertion into an empty AL.
// Attempts to call insertAt for index larger than 0.
// This should result in an std::range_error being raised.
void insertAt_empty_incorrect() {

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
        // insertAt for out-of-range index
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        // if insertAt is correctly implemented, a range_error will be thrown,
        // and we will end up here
        range_error_thrown = true;
        error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0]");
    
}

// Tests correct insertAt for front of 1-element list.
void insertAt_front_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at front
    test_list.insertAt('b', 0);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'a');
    
}

// Tests correct insertAt for back of 1-element list.
void insertAt_back_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at back
    test_list.insertAt('b', 1);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    
}

// Tests calling insertAt for a large number of elements.
void insertAt_many_elements() {
    
    CharLinkedList test_list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.insertAt('a', i);
    }

    assert(test_list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
    
}

// Tests insertion into front of a larger list
void insertAt_front_large_list() {
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    test_list.insertAt('y', 0);

    assert(test_list.size() == 10);
    assert(test_list.elementAt(0) == 'y');
    assert(test_list.toString() == 
        "[CharLinkedList of size 10 <<yabczdefgh>>]");

}

// Tests insertion into the back of a larger list
void insertAt_back_large_list() {

    char test_arr[10] = { 'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 10);  

    test_list.insertAt('x', 10);

    assert(test_list.size() == 11);
    assert(test_list.elementAt(10) == 'x');
    assert(test_list.toString() == 
        "[CharLinkedList of size 11 <<yabczdefghx>>]"); 

}

// Tests insertion into the middle of a larger list
void insertAt_middle_large_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.insertAt('z', 3);

    assert(test_list.size() == 9);
    assert(test_list.elementAt(3) == 'z');
    assert(test_list.toString() == "[CharLinkedList of size 9 <<abczdefgh>>]");

}

// Tests out-of-range insertion for a non-empty list.
void insertAt_nonempty_incorrect() {
   
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8]");
    
}

// tests: insertInOrder where char c should be front
void insert_order_first() {
    char arr[4] = {'b', 'c', 'd', 'e'};
    CharLinkedList test(arr, 4);

    test.insertInOrder('a');

    assert(test.elementAt(0) == 'a');
    assert(test.toString() == 
        "[CharLinkedList of size 5 <<abcde>>]");
}

// tests: insertInOrder where char c should be in middle
void insert_order_middle() {
    char arr[4] = {'a', 'b', 'd', 'e'};
    CharLinkedList test(arr, 4);

    test.insertInOrder('c');

    assert(test.elementAt(2) == 'c');
    assert(test.toString() == 
        "[CharLinkedList of size 5 <<abcde>>]");
}

// tests: insertInOrder where char c should be end
void insert_order_last() {
    char arr[4] = {'b', 'c', 'd', 'e'};
    CharLinkedList test(arr, 4);

    test.insertInOrder('f');

    assert(test.elementAt(4) == 'f');
    assert(test.toString() == 
        "[CharLinkedList of size 5 <<bcdef>>]");
}

// tests: insertInOrder on empty list
void insert_order_empty() {
    CharLinkedList test;

    test.insertInOrder('!');

    assert(test.elementAt(0) == '!');
    assert(test.toString() == 
        "[CharLinkedList of size 1 <<!>>]");
}

// tests: insertInOrder with uppercase chars
void insert_order_upper() {
    char arr[4] = {'a', 'b', 'd', 'e'};
    CharLinkedList test(arr, 4);

    test.insertInOrder('D');
    test.insertInOrder('A');

    assert(test.size() == 6);
    assert(test.toString() == 
        "[CharLinkedList of size 6 <<ADabde>>]");
}

// tests: insertInOrder with special chars
void insert_order_special() {
    char arr[4] = {'a', 'b', 'd', 'e'};
    CharLinkedList test(arr, 4);

    test.insertInOrder('&');
    test.insertInOrder('P');
    test.insertInOrder(')');

    assert(test.size() == 7);
    assert(test.toString() == 
        "[CharLinkedList of size 7 <<&)Pabde>>]");
}

// tests: popFromFront on empty list
void pop_front_empty() {
    CharLinkedList test('a');

    // var to track whether range_error is thrown
    bool error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test.popFromFront(); // now list is empty
        test.popFromFront();
    }
    catch (const std::runtime_error &e) {
        error_thrown = true;
        error_message = e.what();
    }

    assert(error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

// tests: popFromFront on mult node list
void pop_front_mult() {
    char arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test(arr, 8);

    test.popFromFront();
    test.popFromFront();

    assert(test.size() == 6);
    assert(test.toString() == "[CharLinkedList of size 6 <<cdefgh>>]");
}

// tests: popFromFront with pushAtFront
void pop_push_front() {
    char arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test(arr, 8);

    test.pushAtFront('Z');
    test.popFromFront();

    assert(test.size() == 8);
    assert(test.toString() == "[CharLinkedList of size 8 <<abcdefgh>>]");
}

// tests: popFromBack on empty list
void pop_back_empty() {
    CharLinkedList test('a');

    // var to track whether range_error is thrown
    bool error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test.popFromBack(); // now list is empty
        test.popFromBack();
    }
    catch (const std::runtime_error &e) {
        error_thrown = true;
        error_message = e.what();
    }

    assert(error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

// tests: popFromBack on mult node list
void pop_mult() {
    char arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test(arr, 8);

    test.insertAt('Z', 8);
    test.popFromBack();

    assert(test.size() == 8);
    assert(test.toString() == "[CharLinkedList of size 8 <<abcdefgh>>]");
}

// tests: popFromBack with pushAtBack
void pop_push_back() {
    char arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test(arr, 8);

    test.popFromBack();
    test.pushAtBack('z');

    assert(test.size() == 8);
    assert(test.toString() == "[CharLinkedList of size 8 <<abcdefgz>>]");
}

// tests: removeAt on empty list
void removeAt_empty() {
    CharLinkedList test;

    // var to track whether range_error is thrown
    bool error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test.removeAt(0);
    }
    catch (const std::range_error &e) {
        error_thrown = true;
        error_message = e.what();
    }

    assert(error_thrown);
    assert(error_message == "index (0) not in range [0..0)");
}

// tests: removeAt on list of one node
void removeAt_one_correct() {
    CharLinkedList test('a');

    test.removeAt(0);

    assert(test.size() == 0);
    assert(test.toString() == 
        "[CharLinkedList of size 0 <<>>]");
}

// tests: removeAt on list of one node, out of range
void removeAt_one_incorrect() {
    CharLinkedList test('a');

    // var to track whether range_error is thrown
    bool error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test.removeAt(0); // now list is empty
        test.removeAt(0);
    }
    catch (const std::range_error &e) {
        error_thrown = true;
        error_message = e.what();
    }

    assert(error_thrown);
    assert(error_message == "index (0) not in range [0..0)");
}

// tests: removeAt with index out of range on lower end
void removeAt_lower() {
    char arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test(arr, 8);

    // var to track whether range_error is thrown
    bool error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test.removeAt(-1);
    }
    catch (const std::range_error &e) {
        error_thrown = true;
        error_message = e.what();
    }

    assert(error_thrown);
    assert(error_message == "index (-1) not in range [0..8)");
}

// tests: removeAt with index out of range on higher end
void removeAt_higher() {
    char arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test(arr, 8);

    // var to track whether range_error is thrown
    bool error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test.removeAt(8);
    }
    catch (const std::range_error &e) {
        error_thrown = true;
        error_message = e.what();
    }

    assert(error_thrown);
    assert(error_message == "index (8) not in range [0..8)");
}

// tests: removeAt with one node to make empty list
void removeAt_one() {
    CharLinkedList test('a');

    test.removeAt(0);

    assert(test.isEmpty());
}

// tests: removeAt with mult nodes
void removeAt_mult() {
    char arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test(arr, 8);

    test.removeAt(0);
    test.removeAt(3);

    assert(test.size() == 6);
    assert(test.toString() == 
        "[CharLinkedList of size 6 <<bcdfgh>>]");
}

// tests: replaceAt on empty list
void replaceAt_empty() {
    CharLinkedList test;

    // var to track whether range_error is thrown
    bool error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test.replaceAt('a', 0);
    }
    catch (const std::range_error &e) {
        error_thrown = true;
        error_message = e.what();
    }

    assert(error_thrown);
    assert(error_message == "index (0) not in range [0..0)");
}

// tests: replaceAt with index out of range on lower end
void replaceAt_lower() {
    char arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test(arr, 8);

    // var to track whether range_error is thrown
    bool error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test.replaceAt('a', -1);
    }
    catch (const std::range_error &e) {
        error_thrown = true;
        error_message = e.what();
    }

    assert(error_thrown);
    assert(error_message == "index (-1) not in range [0..8)");
}

// tests: replaceAt with index out of range on higher end
void replaceAt_higher() {
    char arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test(arr, 8);

    // var to track whether range_error is thrown
    bool error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test.replaceAt('a', 8);
    }
    catch (const std::range_error &e) {
        error_thrown = true;
        error_message = e.what();
    }

    assert(error_thrown);
    assert(error_message == "index (8) not in range [0..8)");
}

// tests: replaceAt with index extremely out of range on higher end
void replaceAt_higher_two() {
    char arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test(arr, 8);

    // var to track whether range_error is thrown
    bool error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test.replaceAt('a', 100);
    }
    catch (const std::range_error &e) {
        error_thrown = true;
        error_message = e.what();
    }

    assert(error_thrown);
    assert(error_message == "index (100) not in range [0..8)");
}

// tests: replaceAt to change a word completely
void replaceAt_word() {
    char arr[3] = {'o', 'n', 'e'};
    CharLinkedList test(arr, 3);

    test.replaceAt('t', 0);
    test.replaceAt('w', 1);
    test.replaceAt('o', 2);

    assert(test.toString() == 
        "[CharLinkedList of size 3 <<two>>]");
}

// tests: replaceAt with special chars and adding chars
void replaceAt_special() {
    char arr[3] = {'o', 'n', 'e'};
    CharLinkedList test(arr, 3);

    test.replaceAt('!', 0);
    test.replaceAt('2', 1);
    test.pushAtBack('3');
    test.replaceAt('4', 3);

    assert(test.toString() == 
        "[CharLinkedList of size 4 <<!2e4>>]");
}

// tests: concatenate, adding to empty list
void concat_to_empty() {
    char arr[3] = {'c', 'a', 't'};
    CharLinkedList test_word(arr, 3);
    CharLinkedList test_empty;
    
    test_empty.concatenate(&test_word);

    assert(test_empty.toString() == 
        "[CharLinkedList of size 3 <<cat>>]");
}

// tests: concatenate, adding an empty list to a non-empty list
void concat_add_empty() {
    char arr[3] = {'c', 'a', 't'};
    CharLinkedList test_word(arr, 3);
    CharLinkedList test_empty;
    
    test_word.concatenate(&test_empty);

    assert(test_word.toString() == 
        "[CharLinkedList of size 3 <<cat>>]");
}

// tests: concatenate, adding an empty list to another empty list
void concat_both_empty() {
    CharLinkedList test_empty_one;
    CharLinkedList test_empty_two;
    
    test_empty_one.concatenate(&test_empty_two);

    //assert(test_empty_one.toString() == test_empty_two.toString());
    assert(test_empty_one.isEmpty());
}

// tests: concatenate with two non-empty lists
void concat_non_empty() {
    char arr1[8] = {'C', 'H', 'E', 'S', 'H', 'I', 'R', 'E'};
    char arr2[3] = {'c', 'a', 't'};
    CharLinkedList one(arr1, 8);
    CharLinkedList two(arr2, 3);
    
    one.concatenate(&two);

    assert(one.size() == 11);
    assert(one.toString() ==
        "[CharLinkedList of size 11 <<CHESHIREcat>>]");
}

// tests: concatenate with self
void concat_self() {
    char arr1[8] = {'C', 'H', 'E', 'S', 'H', 'I', 'R', 'E'};
    CharLinkedList one(arr1, 8);
    
    one.concatenate(&one);

    assert(one.size() == 16);
    assert(one.toString() ==
        "[CharLinkedList of size 16 <<CHESHIRECHESHIRE>>]");
}

// tests: concatenate with special chars
void concat_special() {
    char arr1[3] = {'c', 'a', 't'};
    char arr2[3] = {'!', '&', '$'};
    CharLinkedList one(arr1, 3);
    CharLinkedList two(arr2, 3);
    
    one.concatenate(&two);

    assert(one.size() == 6);
    assert(one.toString() ==
        "[CharLinkedList of size 6 <<cat!&$>>]");
}
/*
 *  CharLinkedList.h
 *  Lindsay Ulrey
 *  2/3/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Outlines variables and functions of CharLinkedList object,
 *  a linked list of node objects, chained together with
 *  pointers.
 *
 */

#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H

#include <string>

class CharLinkedList {
public:
    // constructors and destructor
    CharLinkedList();
    CharLinkedList(char c);
    CharLinkedList(char arr[], int size);
    CharLinkedList(const CharLinkedList &other);
    ~CharLinkedList();

    // assignment operator
    CharLinkedList &operator=(const CharLinkedList &other);

    bool isEmpty() const;
    void clear();
    int size() const;
    char first() const;
    char last() const;
    char elementAt(int index) const;
    std::string toString() const;
    std::string toReverseString() const;
    void pushAtBack(char c);
    void pushAtFront(char c);
    void insertAt(char c, int index);
    void insertInOrder(char c);
    void popFromFront();
    void popFromBack();
    void removeAt(int index);
    void replaceAt(char c, int index);
    void concatenate(CharLinkedList *other);
private:
    struct Node {
        char data;
        Node *prev;
        Node *next;
    };

    Node *front; // points to first node
    int numItems; // number of nodes

    // destructor helper funtion
    void destructorHelper(Node *curr);

    // helper function that makes and returns
    // pointer to specified node
    Node *newNode(char c, Node *bef, Node *aft);

    // finds and returns pointer to last node
    Node *getLast() const;

    // finds and returns pointer to node at
    // specified index node recursively
    Node *getIndex(int index) const;
    Node *indHelp(Node *c, int ind, int i) const;
};

#endif
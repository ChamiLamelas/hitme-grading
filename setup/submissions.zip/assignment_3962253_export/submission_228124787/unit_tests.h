/*
 *  unit_tests.h
 *  Rene Zhao (nzhao05)
 *  2024/02/06
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  Purpose: Tests each of the functions in CharLinkedList. 
 *
 */


#include "CharLinkedList.h"
#include <cassert>

// Tests whether default constructor works
void default_constructor() {
    CharLinkedList test_list;
}

// Tests whether default constructor with isEmpty and has size 0
void default_constructor_contentheck() {
    CharLinkedList test_list;

    assert(test_list.isEmpty());
    assert(test_list.size() == 0);
}

// Tests whether second constructor with one char argument works
void char_constructor() {
    CharLinkedList test_list('a');
}

// Tests the second constructor
// Size should be 1 and the given char should be at index 0
void char_constructor_contentcheck() {
    CharLinkedList test_list('a');

    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');
}

// Tests whether third constructor with array and its size arguments works
void arr_constructor() {
    char test_arr[] = {'a', 'b', 'c'};
    CharLinkedList test_list(test_arr, 3);
}

// Tests the third constructor with a non-empty array
// Size should be equal to size of given array, elements should be at equal
// index as they are in the array
void arr_constructor_contentcheck_nonempty() {
    char test_arr[] = {'1', 'B', ')'};
    CharLinkedList test_list(test_arr, 3);

    assert(test_list.size() == 3);
    assert(test_list.elementAt(0) == '1');
    assert(test_list.elementAt(1) == 'B');
    assert(test_list.elementAt(2) == ')');
}

// Tests the third constructor with an empty array
// Size should be 0 and isEmpty should be true
void arr_constructor_contentcheck_empty() {
    char test_arr[] = {};
    CharLinkedList test_list(test_arr, 0);

    assert(test_list.size() == 0);
    assert(test_list.isEmpty());
}

// Tests the third constructor with an empty array when user input negative
// size
void arr_constructor_contentcheck_negativesize() {
    char test_arr[] = {};
    CharLinkedList test_list(test_arr, -1);

    assert(test_list.size() == 0);
    assert(test_list.isEmpty());
}

// Tests whether the copy constructor works
void cpy_constructor() {
    char cpy_arr[] = {'a', 'b', 'c'};
    CharLinkedList cpy_list(cpy_arr, 3);
    CharLinkedList test_list = cpy_list;
}

// Tests the copy constructor with a nonempty list
// Size should be equal to size of given array, elements should be at equal
// index as they are in the array
void cpy_constructor_contentcheck_nonempty() {
    char cpy_arr[] = {'A', '&', '4'};
    CharLinkedList cpy_list(cpy_arr, 3);
    CharLinkedList test_list = cpy_list;

    assert(test_list.size() == 3);
    assert(test_list.elementAt(0) == 'A');
    assert(test_list.elementAt(1) == '&');
    assert(test_list.elementAt(2) == '4');
}

// Tests the copy constructor with an empty list
// Size should be zero
void cpy_constructor_contentcheck_empty() {
    char cpy_arr[] = {};
    CharLinkedList cpy_list(cpy_arr, 0);
    CharLinkedList test_list = cpy_list;

    assert(test_list.size() == 0);
    assert(test_list.isEmpty());
}

// Tests findIndex by finding an element in a non-empty list
// Makes the helper function and Node struct temporarily public when testing
/*void findIndex_nonempty() {
    char test_arr[] = {'1', 'B', ')'};
    CharLinkedList test_list(test_arr, 3);
    CharLinkedList::Node *one = test_list.findIndex(test_list.front, 0);
    CharLinkedList::Node *two = test_list.findIndex(test_list.front, 1);
    CharLinkedList::Node *three = test_list.findIndex(test_list.front, 2);

    assert(one->c == '1');
    assert(two->c == 'B');
    assert(three->c == ')');
}

// Tests newNode by creating a new node in the middle of a non-empty list
// Makes the helper function and Node struct temporarily public when testing
void newNode_nonempty_middle() {
    char test_arr[] = {'1', 'B', ')'};
    CharLinkedList test_list(test_arr, 3);
    test_list.newNode('a', test_list.front, 
        test_list.findIndex(test_list.front, 1));

    assert(test_list.elementAt(1) == 'a');
    assert(test_list.size() == 4);
}

// Tests newNode by creating a new node in the front of a non-empty listg
void newNode_nonempty_front() {
    char test_arr[] = {'1', 'B', ')'};
    CharLinkedList test_list(test_arr, 3);
    test_list.newNode('a', nullptr, test_list.front);

    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == '1');
    assert(test_list.size() == 4);
}

// Tests newNode by creating a new node in the back of a non-empty listg
void newNode_nonempty_back() {
    char test_arr[] = {'1', 'B', ')'};
    CharLinkedList test_list(test_arr, 3);
    test_list.newNode('a', test_list.findIndex(test_list.front, 2), nullptr);

    assert(test_list.elementAt(2) == ')');
    assert(test_list.elementAt(3) == 'a');
    assert(test_list.size() == 4);
}

// Tests newNode by creating a new node in an empty list
void newNode_empty() {
    CharLinkedList test_list;
    test_list.newNode('a', nullptr, nullptr);

    assert(test_list.elementAt(0) == 'a');
    assert(test_list.size() == 1);
}*/

// Tests size function with a non-empty list
void size_nonempty() {
    char test_arr[] = {'a', 'b', 'c'};
    CharLinkedList test_list(test_arr, 3);

    assert(test_list.size() == 3);
}

// Tests size function with an empty list
void size_empty() {
    CharLinkedList test_list;

    assert(test_list.size() == 0);
}

// Tests elementAt by correctly finding an element in the middle of non-empty
// list
// Also tests helper function findIndex
void elementAt_correct_middle() {
    char test_arr[] = {'a', 'b', 'c'};
    CharLinkedList test_list(test_arr, 3);

    assert(test_list.elementAt(1) == 'b');
}

// Tests elementAt by correctly finding an element in the front of non-empty
// list
void elementAt_correct_front() {
    char test_arr[] = {'a', 'b', 'c'};
    CharLinkedList test_list(test_arr, 3);

    assert(test_list.elementAt(0) == 'a');
}

// Tests elementAt by correctly finding an element in the back of non-empty
// list
void elementAt_correct_back() {
    char test_arr[] = {'a', 'b', 'c'};
    CharLinkedList test_list(test_arr, 3);

    assert(test_list.elementAt(2) == 'c');
}

// Tests elementAt by incorrectly finding zero index in an empty list
void elementAt_incorrect_empty_zero() {
    bool range_error_thrown = false;
    std::string error_message = "";

    CharLinkedList test_list;

    try {
        test_list.elementAt(0);
    }
    catch (const std::runtime_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (0) not in range [0..0)");
}

// Tests elementAt by incorrectly finding non-zero index in an empty list
void elementAt_incorrect_empty_nonzero() {
    bool range_error_thrown = false;
    std::string error_message = "";

    CharLinkedList test_list;

    try {
        test_list.elementAt(6);
    }
    catch (const std::runtime_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (6) not in range [0..0)");
}

// Tests elementAt by incorrectly finding out-of-range index in a non-empty list
void elementAt_incorrect_nonempty() {
    bool range_error_thrown = false;
    std::string error_message = "";

    char test_arr[] = {'a', 'b', 'c'};
    CharLinkedList test_list(test_arr, 3);

    try {
        test_list.elementAt(5);
    }
    catch (const std::runtime_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (5) not in range [0..3)");
}

// Tests first by correctly accessing first element from non-empty list
void first_correct_nonempty() {
    char test_arr[] = {'o', 'y', 'A'};
    CharLinkedList test_list(test_arr, 3);

    assert(test_list.first() == 'o');
}

// Tests first by correctly accessing first element from an 1-element list
void first_correct_one() {
    CharLinkedList test_list('0');

    assert(test_list.first() == '0');
}

// Tests first by incorrectly accessing first element from empty list
void first_incorrect_empty() {
    bool runtime_error_thrown = false;
    std::string error_message = "";

    CharLinkedList test_list;

    try {
        test_list.first();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot get first of empty LinkedList");
}

// Tests last by correctly getting the last element from a non-empty list
void last_correct_nonempty() {
    char test_arr[] = {'x', 'y', 'z'};
    CharLinkedList test_list(test_arr, 3);

    assert(test_list.last() == 'z');
}

// Tests last by correctly getting the last element from an 1-element list
void last_correct_one() {
    CharLinkedList test_list('j');

    assert(test_list.last() == 'j');
}

// Tests last by incorrectly getting the last element from an empty list
void last_incorrect_empty() {

    bool runtime_error_thrown = false;
    std::string error_message = "";

    CharLinkedList test_list;

    try {
        test_list.last();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot get last of empty ArrayList");

}

// Tests isEmpty with an empty list
void isEmpty_empty() {
    CharLinkedList test_list;

    assert(test_list.isEmpty());
}

// Tests isEmpty with a non-empty list
void isEmpty_nonempty() {
    char test_arr[] = {'a', 'b', 'c'};
    CharLinkedList test_list(test_arr, 3);

    assert(not test_list.isEmpty());
}

// Tests clear with an empty list
// Also tests the recycleHelper helper function
void clear_empty() {
    CharLinkedList test_list;
    test_list.clear();

    assert(test_list.isEmpty());
    assert(test_list.size() == 0);
}

// Tests clear with a non-empty list
void clear_nonempty() {
    char test_arr[] = {'a', 'b', 'c'};
    CharLinkedList test_list(test_arr, 3);
    test_list.clear();

    assert(test_list.isEmpty());
    assert(test_list.size() == 0);
}

// Tests pushAtBack by adding an element to a non-empty list
void pushAtBack_nonempty() {
    char test_arr[] = {'E', 'm', 'i', 'l'};
    CharLinkedList test_list(test_arr, 4);
    test_list.pushAtBack('y');

    assert(test_list.elementAt(4) == 'y');
    assert(test_list.size() == 5);
}

// Tests pushAtBack by adding an element to an empty list
void pushAtBack_empty() {
    CharLinkedList test_list;
    test_list.pushAtBack('g');

    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'g');
}

// Tests pushAtBack by adding an element to a 1-element list
void pushAtBack_one() {
    CharLinkedList test_list('7');
    test_list.pushAtBack('1');

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == '7');
    assert(test_list.elementAt(1) == '1');
}

// Tests pushAtFront by adding an element to a non-empty list
void pushAtFront_nonempty() {
    char test_arr[] = {'m', 'i', 'l', 'y'};
    CharLinkedList test_list(test_arr, 4);
    test_list.pushAtFront('e');

    assert(test_list.elementAt(0) == 'e');
    assert(test_list.size() == 5);
}

// Tests pushAtFront by adding an element to an empty list
void pushAtFront_empty() {
    CharLinkedList test_list;
    test_list.pushAtFront('g');

    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'g');
}

// Tests pushAtFront by adding an element to a 1-element list
void pushAtFront_one() {
    CharLinkedList test_list('7');
    test_list.pushAtFront('1');

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == '1');
    assert(test_list.elementAt(1) == '7');
}

// Tests correct insertion into an empty AL.
// Afterwards, size should be 1 and element at index 0
// should be the element we inserted.
void insertAt_empty_correct() { 
    CharLinkedList test_list;
    test_list.insertAt('a', 0);

    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');
}

// Tests incorrect insertion into an empty AL.
// Attempts to call insertAt for index larger than 0.
// This should result in an std::range_error being raised.
void insertAt_empty_incorrect() {
    bool range_error_thrown = false;

    std::string error_message = "";

    CharLinkedList test_list;
    try {
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0]");
}

// Tests correct insertAt for front of 1-element list.
void insertAt_front_singleton_list() {
    CharLinkedList test_list('a');
    test_list.insertAt('b', 0);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'a');
}

// Tests correct insertAt for back of 1-element list.
void insertAt_back_singleton_list() {
    CharLinkedList test_list('a');
    test_list.insertAt('b', 1);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
}

// Tests calling insertAt for a large number of elements.
// Not only does this test insertAt, it also checks that
// array expansion works correctly.
void insertAt_many_elements() {
    CharLinkedList test_list;
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.insertAt('a', i);
    }

    assert(test_list.size() == 1000);
    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
}

// Tests insertion into front of a larger list
void insertAt_front_large_list() {
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);
    test_list.insertAt('y', 0);

    assert(test_list.size() == 10);
    assert(test_list.elementAt(0) == 'y');
    assert(test_list.toString() == 
        "[CharLinkedList of size 10 <<yabczdefgh>>]");
}

// Tests insertion into the back of a larger list
void insertAt_back_large_list() {
    char test_arr[10] = { 'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 10);  
    test_list.insertAt('x', 10);

    assert(test_list.size() == 11);
    assert(test_list.elementAt(10) == 'x');
    assert(test_list.toString() == 
    "[CharLinkedList of size 11 <<yabczdefghx>>]"); 
}

// Tests insertion into the middle of a larger list
void insertAt_middle_large_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);
    test_list.insertAt('z', 3);

    assert(test_list.size() == 9);
    assert(test_list.elementAt(3) == 'z');
    assert(test_list.toString() == "[CharLinkedList of size 9 <<abczdefgh>>]");
}

// Tests out-of-range insertion for a non-empty list.
void insertAt_nonempty_incorrect() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    bool range_error_thrown = false;

    std::string error_message = "";

    try {
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8]");
}

// Tests insertInOrder by inserting an element in an empty list
void insertInOrder_empty() {
    CharLinkedList test_list;
    test_list.insertInOrder('e');

    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'e');
}

// Tests insertInOrder by inserting an element in a non-empty list
void insertInOrder_nonempty_middle() {
    char test_arr[] = {'a', 'b', 'd', 'e'};
    CharLinkedList test_list(test_arr, 4);
    test_list.insertInOrder('c');

    assert(test_list.size() == 5);
    assert(test_list.elementAt(2) == 'c');
    assert(test_list.elementAt(1) == 'b');
    assert(test_list.elementAt(3) == 'd');
}

// Tests insertInOrder by inserting an element in a non-empty list
// The character should be inserted in the first of the list
void insertInOrder_nonempty_first() {
    char test_arr[] = {'b', 'c', 'd', 'e'};
    CharLinkedList test_list(test_arr, 4);
    test_list.insertInOrder('a');

    assert(test_list.size() == 5);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    assert(test_list.elementAt(2) == 'c');
}

// Tests insertInOrder by inserting an element in a non-empty list
// The character should be inserted in the last of the list
void insertInOrder_nonempty_last() {
    char test_arr[] = {'a', 'b', 'c', 'd'};
    CharLinkedList test_list(test_arr, 4);
    test_list.insertInOrder('e');

    assert(test_list.size() == 5);
    assert(test_list.elementAt(2) == 'c');
    assert(test_list.elementAt(3) == 'd');
    assert(test_list.elementAt(4) == 'e');
}

// Tests insertInOrder by inserting an element in a non-empty list, which
// itself isn't arranged in order
void insertInOrder_nonempty_notordered() {
    char test_arr[] = {'Z', 'E', 'D'};
    CharLinkedList test_list(test_arr, 3);
    test_list.insertInOrder('A');

    assert(test_list.size() == 4);
    assert(test_list.elementAt(0) == 'A');
    assert(test_list.elementAt(1) == 'Z');
    assert(test_list.elementAt(2) == 'E');
}

// Tests insertInOrder by inserting an element in a non-empty list
// consisting of numbers
void insertInOrder_nonempty_numbers() {
    char test_arr[] = {'1', '5', '7'};
    CharLinkedList test_list(test_arr, 3);
    test_list.insertInOrder('3');

    assert(test_list.size() == 4);
    assert(test_list.elementAt(0) == '1');
    assert(test_list.elementAt(1) == '3');
    assert(test_list.elementAt(2) == '5');
}

// Tests insertInOrder by inserting an element in a non-empty list
// consisting of upper and lowercase letters
void insertInOrder_nonempty_upperandlowercase() {
    char test_arr[] = {'Z', 'e', 'D'};
    CharLinkedList test_list(test_arr, 3);
    test_list.insertInOrder('a');

    assert(test_list.size() == 4);
    assert(test_list.elementAt(0) == 'Z');
    assert(test_list.elementAt(1) == 'a');
    assert(test_list.elementAt(2) == 'e');
}

// Tests popFromFront by correctly removing an element from a non-empty list
void popFromFront_correct_nonempty() {
    char test_arr[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList test_list(test_arr, 5);
    test_list.popFromFront();

    assert(test_list.size() == 4);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(3) == 'e');
}

// Tests popFromFront by correctly removing an element from an 1-element list
void popFromFront_correct_one() {
    char test_arr[] = {')'};
    CharLinkedList test_list(test_arr, 1);
    test_list.popFromFront();

    assert(test_list.size() == 0);
    assert(test_list.isEmpty());
}

// Tests popFromFront by running it multiple times
void popFromFront_correct_multiplerun() {
    char test_arr[] = {'z', 'a', '*'};
    CharLinkedList test_list(test_arr, 3);
    test_list.popFromFront();
    test_list.popFromFront();
    test_list.popFromFront();

    assert(test_list.size() == 0);
    assert(test_list.isEmpty());
}

// Tests popFromFront by incorrectly removing an element from an empty list
void popFromFront_incorrect_empty() {
    bool runtime_error_thrown = false;
    std::string error_message = "";

    CharLinkedList test_list;

    try {
        test_list.popFromFront();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

// Tests popFromBack by correctly removing an element from a non-empty list
void popFromBack_correct_nonempty() {
    char test_arr[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList test_list(test_arr, 5);
    test_list.popFromBack();

    assert(test_list.size() == 4);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(3) == 'd');
}

// Tests popFromBack by correctly removing an element from an 1-element list
void popFromBack_correct_one() {
    char test_arr[] = {'z'};
    CharLinkedList test_list(test_arr, 1);
    test_list.popFromBack();

    assert(test_list.size() == 0);
    assert(test_list.isEmpty());
}

// Tests popFromBack by running it multiple times
void popFromBack_correct_multiplerun() {
    char test_arr[] = {'z', 'a', '*'};
    CharLinkedList test_list(test_arr, 3);
    test_list.popFromBack();
    test_list.popFromBack();
    test_list.popFromBack();

    assert(test_list.size() == 0);
    assert(test_list.isEmpty());
}

// Tests popFromBack by incorrectly removing an element from an empty list
void popFromBack_incorrect_empty() {
    bool runtime_error_thrown = false;
    std::string error_message = "";

    CharLinkedList test_list;

    try {
        test_list.popFromBack();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

// Tests removeAt by correctly removing an element from middle of a non-empty
// list
void removeAt_correct_nonempty_middle() {
    char test_arr[] = {'1', 'B', 'c'};
    CharLinkedList test_list(test_arr, 3);
    test_list.removeAt(1);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == '1');
    assert(test_list.elementAt(1) == 'c');
}

// Tests removeAt by correctly removing an element from front of a non-empty
// list
void removeAt_correct_nonempty_front() {
    char test_arr[] = {'1', 'B', 'c'};
    CharLinkedList test_list(test_arr, 3);
    test_list.removeAt(0);
    
    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'B');
    assert(test_list.elementAt(1) == 'c');
}

// Tests removeAt by correctly removing an element from back of a non-empty
// list
void removeAt_correct_nonempty_back() {
    char test_arr[] = {'1', 'B', 'c'};
    CharLinkedList test_list(test_arr, 3);
    test_list.removeAt(2);
    
    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == '1');
    assert(test_list.elementAt(1) == 'B');
}

// Tests removeAt by incorrectly removing an element from an empty list
void removeAt_incorrect_empty() {
    bool range_error_thrown = false;
    std::string error_message = "";
    CharLinkedList test_list;
    try {
        test_list.removeAt(0);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (0) not in range [0..0)");
}

// Tests removeAt by incorrectly removing an element at out-of-range index
// of a non-empty list
void removeAt_incorrect_nonempty() {
    bool range_error_thrown = false;
    std::string error_message = "";
    char test_arr[] = {'1', 'B', 'c'};
    CharLinkedList test_list(test_arr, 3);
    try {
        test_list.removeAt(10);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (10) not in range [0..3)");
}

// Tests removeAt by correctly removing an element from a 1-element list
void removeAt_correct_one() {
    CharLinkedList test_list('l');
    test_list.removeAt(0);

    assert(test_list.isEmpty());
    assert(test_list.size() == 0);
}

// Tests removeAt by correctly removing an element from a large list
// also tests insertAt
void removeAt_correct_large() {
    CharLinkedList test_list;

    // always insert characters at the back of list
    for (int i = 0; i < 1000; i++) {
        test_list.insertAt('a', i);
    }

    // always remove characters at the front of list because size decreases
    for (int i = 0; i < 1000; i++) {
        test_list.removeAt(0);
    }

    assert(test_list.isEmpty());
    assert(test_list.size() == 0);
}

// Tests replaceAt by correctly replacing an element in the middle of non-empty
// list
void replaceAt_correct_nonempty_middle() {
    char test_arr[] = {'1', 'B', 'c'};
    CharLinkedList test_list(test_arr, 3);
    test_list.replaceAt('b', 1);

    assert(test_list.size() == 3);
    assert(test_list.elementAt(0) == '1');
    assert(test_list.elementAt(1) == 'b');
    assert(test_list.elementAt(2) == 'c');
}

// Tests replaceAt by correctly replacing an element in the front of non-empty
// list
void replaceAt_correct_nonempty_front() {
    char test_arr[] = {'1', 'B', 'c'};
    CharLinkedList test_list(test_arr, 3);
    test_list.replaceAt('b', 0);

    assert(test_list.size() == 3);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'B');
    assert(test_list.elementAt(2) == 'c');
}

// Tests replaceAt by correctly replacing an element in the back of non-empty
// list
void replaceAt_correct_nonempty_back() {
    char test_arr[] = {'1', 'B', 'c'};
    CharLinkedList test_list(test_arr, 3);
    test_list.replaceAt('b', 2);

    assert(test_list.size() == 3);
    assert(test_list.elementAt(0) == '1');
    assert(test_list.elementAt(1) == 'B');
    assert(test_list.elementAt(2) == 'b');
}

// Tests replaceAt by incorrectly replacing an element in an empty list
void replaceAt_incorrect_empty() {
    bool range_error_thrown = false;
    std::string error_message = "";
    CharLinkedList test_list;
    try {
        test_list.replaceAt('a', 0);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (0) not in range [0..0)");
}

// Tests replaceAt by incorrectly replacing an element in a non-empty list
void replaceAt_incorrect_nonempty() {
    bool range_error_thrown = false;
    std::string error_message = "";
    char test_arr[] = {'1', 'B', 'c'};
    CharLinkedList test_list(test_arr, 3);
    try {
        test_list.replaceAt('a', 10);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (10) not in range [0..3)");
}

// Tests replaceAt by correctly running it multiple times
void replaceAt_correct_nonempty_multiplerun() {
    char test_arr[] = {'1', 'B', 'c'};
    CharLinkedList test_list(test_arr, 3);
    test_list.replaceAt('b', 2);
    test_list.replaceAt('1', 2);
    test_list.replaceAt('a', 2);
    test_list.replaceAt('g', 2);
    test_list.replaceAt('h', 2);

    assert(test_list.size() == 3);
    assert(test_list.elementAt(0) == '1');
    assert(test_list.elementAt(1) == 'B');
    assert(test_list.elementAt(2) == 'h');
}

// Tests toString with a non-empty list
void toString_nonempty() {
    char test_arr[] = {'W', 'i', 'l', 'l'};
    CharLinkedList test_list(test_arr, 4);

    assert(test_list.toString() == "[CharLinkedList of size 4 <<Will>>]");
}

// Tests toString with an empty list
void toString_empty() {
    CharLinkedList test_list;

    assert(test_list.toString() == "[CharLinkedList of size 0 <<>>]");
}

// Tests toReverseString and reverseHelper with a non-empty list
void toReverseString_nonempty() {
    char test_arr[] = {'W', 'i', 'l'};
    CharLinkedList test_list(test_arr, 3);

    assert(test_list.toReverseString() == "[CharLinkedList of size 3 <<liW>>]");
}

// Tests toReverseString and reverseHelper with an empty list
void toReverseString_empty() {
    CharLinkedList test_list;

    assert(test_list.toReverseString() == "[CharLinkedList of size 0 <<>>]");
}

// Test concatenate by copying a non-empty list into a non-empty list
// also tests the toString function
void concatenate_nonempty_nonempty() {
    char test_arr1[] = {'1', 'B', 'c', 'E'};
    CharLinkedList test_list1(test_arr1, 4);
    char test_arr2[] = {'a', '2', 'd'};
    CharLinkedList test_list2(test_arr2, 3);
    test_list1.concatenate(&test_list2);

    assert(test_list1.size() == 7);
    assert(test_list1.toString() == 
           "[CharLinkedList of size 7 <<1BcEa2d>>]");
}

// Test concatenate by copying an empty list into an empty list
void concatenate_empty_empty() {
    CharLinkedList test_list1;
    CharLinkedList test_list2;
    test_list1.concatenate(&test_list2);

    assert(test_list1.size() == 0);
    assert(test_list1.toString() == 
           "[CharLinkedList of size 0 <<>>]");
}

// Test concatenate by copying an empty list into a non-empty list
void concatenate_empty_nonempty() {
    char test_arr1[] = {'1', 'B', 'c', 'E'};
    CharLinkedList test_list1(test_arr1, 4);
    CharLinkedList test_list2;
    test_list1.concatenate(&test_list2);

    assert(test_list1.size() == 4);
    assert(test_list1.toString() == 
           "[CharLinkedList of size 4 <<1BcE>>]");
}

// Test concatenate by copying a non-empty list into an empty list
void concatenate_nonempty_empty() {
    char test_arr1[] = {'1', 'B', 'c', 'E'};
    CharLinkedList test_list1(test_arr1, 4);
    CharLinkedList test_list2;
    test_list2.concatenate(&test_list1);
    
    assert(test_list1.size() == 4);
    assert(test_list1.toString() == 
           "[CharLinkedList of size 4 <<1BcE>>]");
}
/*
 *  CharLinkedList.cpp
 *  Rene Zhao (nzhao05)
 *  2024/02/06
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Purpose: This file contains an implementation of the CharLinkedList class.
 *
 */

#include "CharLinkedList.h"
#include <string>
#include <sstream>
#include <stdexcept>

using namespace std;

/* 
 * name:      CharLinkedList default constructor
 * purpose:   initialize an empty linked list
 * arguments: none
 * returns:   none
 * effects:   size set to 0 and front set to nullptr
 */
CharLinkedList::CharLinkedList() {
    front = nullptr;
    listSize = 0;
}

/* 
 * name:      CharLinkedList constructor
 * purpose:   initialize a linked list with one element
 * arguments: the first char
 * returns:   none
 * effects:   size set to 1 and front set to the given character
 */
CharLinkedList::CharLinkedList(char c) {
    front = new Node{c, nullptr, nullptr};
    listSize = 1;
}

/* 
 * name:      CharLinkedList constructor
 * purpose:   initialize a linked list based on an array
 * arguments: the array and its size
 * returns:   none
 * effects:   size set to the same size as the array,
 *            front set to the first element in the array
 */
CharLinkedList::CharLinkedList(char arr[], int size) {
    // consider if the given array is empty, should create an empty list
    if (size <= 0) {
        front = nullptr;
        this->listSize = 0;
        return;
    }
    
    // Node curr and curr_previous keeps track of where we are at the list
    Node *curr = nullptr;
    Node *curr_previous = nullptr;

    for (int i = 0; i < size; i++) {
        // creates backward reference from current node to previous node;
        // the pointer to previous node remains nullptr if this is first node;
        // the pointer to next node remains nullptr if this is last node;
        curr = new Node{arr[i], curr_previous, nullptr};
        if (i == 0) {
            front = curr;
        } else {
            // creates the forward reference from previous node to current node
            // the previous node's pointer to next node isn't nullptr anymore
            curr_previous->next = curr;
        }
        // by updating curr_previous to the curr node, it will also update
        // new_curr in the next loop becuase new_curr is initialized based on 
        // curr_previous
        curr_previous = curr;
    }

    this->listSize = size;
}

/* 
 * name:      CharLinkedList copy constructor
 * purpose:   initialize a linked list by deep copying another linked list
 * arguments: the copied linked list
 * returns:   none
 * effects:   size, front, and each node identical to the given linked list
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other) {
    if (other.listSize == 0) {
        front = nullptr;
        listSize = 0;
        return;
    }

    Node *new_curr = nullptr;
    Node *new_previous = nullptr;
    // keeps track of where we are at the copied list
    Node *cpy_curr = other.front;

    for (int i = 0; i < other.listSize; i++) {
        new_curr = new Node{cpy_curr->c, new_previous, nullptr};
        if (i == 0) {
            front = new_curr;
        } else {
            new_previous->next = new_curr;
        }
        new_previous = new_curr;
        cpy_curr = cpy_curr->next;
    }

    listSize = other.listSize;
}

/* 
 * name:      CharLinkedList deconstructor
 * purpose:   free memory associated with CharLinkedList
 * arguments: none
 * returns:   none
 * effects:   free memory allocated by CharArrayList instances
 */
CharLinkedList::~CharLinkedList() {
    recycleHelper(front);
}

/* 
 * name:      recycleHelper
 * purpose:   a recursive helper function that frees all memory subsequent to
 *            a given index
 * arguments: pointer to the current node
 * returns:   none
 * effects:   free memeory from each node, goes on recursively, helper function
 *            used in destructor
 */
void CharLinkedList::recycleHelper(Node *curr) {
    // base case
    if (curr == nullptr) return;
    // recursive case
    else {
        Node *next = curr->next;
        delete curr;
        recycleHelper(next);
    }
}

/* 
 * name:      findIndex
 * purpose:   a recursive helper function that goes to a specific index
 * arguments: pointer to the current node, the given index
 * returns:   none
 * effects:   helper function used in elementAt and replaceAt
 */
CharLinkedList::Node *CharLinkedList::findIndex(Node *curr, int index) const {
    // base case
    // sometimes when index is passed in as listSize - 1, and listSize is 0,
    // index could be -1, but the list should still be treated as empty
    if (index <= 0) {
        return curr;
    } else { // recursive case
        index--;
        return findIndex(curr->next, index);
    }
}

/* 
 * name:      reverseHelper
 * purpose:   a recursive helper function that prints every character
 *            subsequent to a given index
 * arguments: pointer to the current node
 * returns:   none (indirectly) prints out each character
 * effects:   every character from the end of list to the given index
 */
std::string CharLinkedList::reverseHelper(Node *curr, std::string p) const {
    // base case: at the back of list
    if (curr == nullptr) return p;
    // recursive case: adds the following characteres before current character
    else {
        return reverseHelper(curr->next, curr->c + p);
    }
}

/* 
 * name:      newNode
 * purpose:   a helper function that creates a new node in the list
 * arguments: the character of the new node, its previous and next node
 * returns:   none
 * effects:   comparing to initializing node with Node{}, this function
 *            helps increase size by 1 and update front pointer
 */
CharLinkedList::Node *CharLinkedList::newNode(char ch, Node *pre, Node *nex) {
    Node *new_node = new Node{ch, pre, nex};

    if (pre != nullptr) {
        pre->next = new_node;
    } else {
        front = new_node;
    }

    if (nex != nullptr) {
        nex->previous = new_node;
    }

    listSize++;

    return new_node;
}

/* 
 * name:      size
 * purpose:   a getter of the size of the list
 * arguments: none
 * returns:   the size of the list
 * effects:   if list is empty, return 0
 */
int CharLinkedList::size() const {
    return listSize;
}

/* 
 * name:      elementAt
 * purpose:   gets the element at a given position in the list
 * arguments: index of the element
 * returns:   the character at the index
 * effects:   needs to throw exception when index is out of range
 */
char CharLinkedList::elementAt(int index) const {
    if (index < 0 or index >= listSize) {
        std::string error = "index (" + std::to_string(index) + 
                            ") not in range [0.." + std::to_string(listSize) + 
                            ")";
        throw std::range_error(error);
    }

    Node *find = this->findIndex(front, index);
    return find->c;
}

/* 
 * name:      first
 * purpose:   gives the first element from the list
 * arguments: none
 * returns:   the first character
 * effects:   needs to throw exception when first element doesn't exist
 */
char CharLinkedList::first() const {
    if (listSize < 1) {
        throw runtime_error("cannot get first of empty LinkedList");
    }
    return front->c;
}

/* 
 * name:      last
 * purpose:   gives the last element from the list
 * arguments: none
 * returns:   the first character
 * effects:   needs to throw exception when last element doesn't exist;
 *            uses the findIndex helper function
 */
char CharLinkedList::last() const {
    if (listSize < 1) {
        throw std::runtime_error("cannot get last of empty ArrayList");
    }
    Node *last = findIndex(front, listSize - 1);
    return last->c;
}

/* 
 * name:      isEmpty
 * purpose:   check whether the list is empty with no characters
 * arguments: none
 * returns:   true if list is empty and false otherwise
 * effects:   none
 */
bool CharLinkedList::isEmpty() const {
    if (listSize == 0) {
        return true;
    }
    return false;
}

/* 
 * name:      clear
 * purpose:   deletes everything in the list
 * arguments: none
 * returns:   none
 * effects:   decreases the size to 0
 */
void CharLinkedList::clear() {
    recycleHelper(front);
    front = nullptr;
    listSize = 0;
}

/* 
 * name:      pushAtBack
 * purpose:   adds an element to the back of the list
 * arguments: the added character
 * returns:   none
 * effects:   increases the size by 1, make the next pointer of the original 
 *            last node point to the new last node
 */
void CharLinkedList::pushAtBack(char c) {
    Node *back = findIndex(front, listSize - 1);
    newNode(c, back, nullptr);
}

/* 
 * name:      pushAtFront
 * purpose:   adds an element to the front of the list
 * arguments: the added character
 * returns:   none
 * effects:   increases the size by 1, make the previous pointer of the 
 *            original first node point to the new first node
 */
void CharLinkedList::pushAtFront(char c) {
    newNode(c, nullptr, front);
}

/* 
 * name:      insertAt
 * purpose:   inserts a given element at a given position in the list
 * arguments: a character and index of the element
 * returns:   none
 * effects:   increases the size by 1
 */
void CharLinkedList::insertAt(char c, int index) {
    if (index < 0 or index > listSize) {
        std::string error = "index (" + std::to_string(index) + 
                            ") not in range [0.."
                            + std::to_string(listSize) + "]";
        throw std::range_error(error);
    }

    if (index == 0) { 
        pushAtFront(c);
    } else {
        Node *new_previous = findIndex(front, index - 1);
        Node *new_next = findIndex(front, index);
        newNode(c, new_previous, new_next);
    }
}

/* 
 * name:      insertInOrder
 * purpose:   inserts a given element in the first correct ASCII order
 * returns:   none
 * effects:   increases size by 1; uses insertAt as a helper function
 */
void CharLinkedList::insertInOrder(char c) {
    if (listSize == 0) {
        insertAt(c, 0);
    } else {
        // find the insertion index
        int index = 0;
        Node *curr = front;
        while (index < listSize and c > curr->c) {
            index++;
            curr = curr->next;
        }

        insertAt(c, index);
    }
}

/* 
 * name:      popFromFront
 * purpose:   deletes the first element from the list
 * arguments: none
 * returns:   none
 * effects:   decreases the size by 1, and throws exception when first element 
 *            doesn't exit
 */
void CharLinkedList::popFromFront() {
    if (listSize < 1) {
        throw std::runtime_error("cannot pop from empty LinkedList");
    }

    // store the origina old front node, update the new one, and delete the old
    // one
    Node *old_front = front;
    front = front->next;

    // if there's no element left after popping, no need to link to previous 
    // node
    if (listSize > 1) front->previous = nullptr;

    delete old_front;
    listSize--;
}

/* 
 * name:      popFromBack
 * purpose:   deletes the last element from the list
 * arguments: none
 * returns:   none
 * effects:   decreases the size by 1, and throws exception when last element 
 *            doesn't exit
 */
void CharLinkedList::popFromBack() {
    if (listSize < 1) {
        throw std::runtime_error("cannot pop from empty LinkedList");
    }

    // if there's only one node in the list, the list is now empty
    if (listSize == 1) {
        delete front;
        front = nullptr;
    } else {
        Node *new_back = findIndex(front, listSize - 2);
        delete new_back->next;
        new_back->next = nullptr;
    }

    listSize--;
}

/* 
 * name:      removeAt
 * purpose:   deletes the character at given index
 * arguments: index of deleted character
 * returns:   none
 * effects:   decreases the size by 1, and throws exception when index 
 *            doesn't exit
 */
void CharLinkedList::removeAt(int index) {
    if (index < 0 or index >= listSize) {
        std::string error = "index (" + std::to_string(index) 
                            + ") not in range [0.."
                            + std::to_string(listSize) + ")";
        throw std::range_error(error);
    }

    if (index == 0) {
        popFromFront();
    } else if (index == listSize - 1) {
        popFromBack();
    } else {
        Node *remove = findIndex(front, index);
        remove->previous->next = remove->next;
        remove->next->previous = remove->previous;
        delete remove;
        listSize--;
    }
}

/* 
 * name:      replaceAt
 * purpose:   replaces the original char with a new char at a given position
 * arguments: the new character and its index
 * returns:   none
 * effects:   the size should be unchanged, and if the index is out of range, 
 *            needs to throw an error; uses private helper function findIndex
 */
void CharLinkedList::replaceAt(char c, int index) {
    if (index < 0 or index >= listSize) {
        std::string error = "index (" + std::to_string(index) 
                            + ") not in range [0.."
                            + std::to_string(listSize) + ")";
        throw std::range_error(error);
    }
    
    Node *replace = findIndex(front, index);
    replace->c = c;
}

/* 
 * name:      toString
 * purpose:   turns the list of character into a string
 * arguments: none
 * returns:   a string containing the size of list and each character in list
 * effects:   none
 */
std::string CharLinkedList::toString() const {
    std::stringstream ss;
    ss << "[CharLinkedList of size " << listSize << " <<";
    for (Node *curr = front; curr != nullptr; curr = curr->next) {
        ss << curr->c;
    }
    ss << ">>]";

    return ss.str();
}

/* 
 * name:      toReverseString
 * purpose:   turns the list of character into a string in reversed order
 * arguments: none
 * returns:   a string containing the size of list and each character in 
 *            reversed order
 * effects:   none
 */
std::string CharLinkedList::toReverseString() const {
    std::stringstream ss;
    ss << "[CharLinkedList of size " << listSize << " <<"
       << reverseHelper(front, "") << ">>]";

    return ss.str();
}

/* 
 * name:      overloaded assignment operator
 * purpose:   allows a deep copy of CharLinkedList when using "="
 * arguments: the copied linked list
 * returns:   the new array list
 * effects:   if the two array list is already the same, than return the old one
 */
CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other) {
    // return the list itself if it is being copied to itself
    if (this == &other) return *this;

    // clear the original list
    clear();

    if (other.listSize == 0) return *this;

    // copy over the list just like in the copy constructor
    Node *new_curr = nullptr;
    Node *new_previous = nullptr;
    Node *cpy_curr = other.front;

    for (int i = 0; i < other.listSize; i++) {
        new_curr = new Node{cpy_curr->c, new_previous, nullptr};
        if (i == 0) {
            front = new_curr;
        } else {
            new_previous->next = new_curr;
        }
        new_previous = new_curr;
        cpy_curr = cpy_curr->next;
    }

    listSize = other.listSize;

    return *this;
}

/* 
 * name:      concatenate
 * purpose:   copies the char in second array list into the first one
 * arguments: the copied array list
 * returns:   the original array lsit
 * effects:   a list can concatenate itself
 */
void CharLinkedList::concatenate(CharLinkedList *other) {
    if (listSize == 0) {
        *this = *other;
        return;
    } else if (other->size() == 0) {
        return;
    } else {
        for (int index = 0; index < other->size(); index++) {
            pushAtBack(other->elementAt(index));
        }
    }
}
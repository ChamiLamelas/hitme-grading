/*
 *  CharLinkedList.h
 *  Rene Zhao (nzhao05)
 *  2024/02/06
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Purpose:
 * 
 *  CharLinkedList is a class that contains a list of characters, which each
 *      of them is a node containing a pointer to previous and next node. 
 *  Clients can choose from four constructors to initialize the list as empty
 *      or with few elements.
 *  Clients can obtain, add, or remove characters from the first, last, or given
 *      index in the list. Clients can also obtian qualities of the list, such 
 *      as its size and whether it is empty. Other functions allow clients to 
 *      insert a character in ASCII order, clearing the list, replacing a 
 *      specific character, converting the list into a string, converting the 
 *      list into a reversed string, deep copying one list to another, and 
 *      combining two lists.
 * 
 */

#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H

#include <string>

class CharLinkedList {
public:

    // constructors
    CharLinkedList();
    CharLinkedList(char c);
    CharLinkedList(char arr[], int size);
    CharLinkedList(const CharLinkedList &other);

    // destructor
    ~CharLinkedList();

    int size() const;
    char elementAt(int index) const;
    char first() const;
    char last() const;
    bool isEmpty() const;
    void clear();
    void pushAtBack(char c);
    void pushAtFront(char c);
    void insertAt(char c, int index);
    void insertInOrder(char c);
    void popFromFront();
    void popFromBack();
    void removeAt(int index);
    void replaceAt(char c, int index);
    std::string toString() const;
    std::string toReverseString() const;
    CharLinkedList &operator=(const CharLinkedList &other);
    void concatenate(CharLinkedList *other);

private:
    struct Node {
        char c;
        Node *previous;
        Node *next;
    };

    Node *front;
    int listSize;

    // helper functions
    void recycleHelper(Node *curr);
    Node *findIndex(Node *curr, int index) const;
    std::string reverseHelper(Node *curr, std::string p) const;
    Node *newNode(char ch, Node *pre, Node *nex); 
};

#endif

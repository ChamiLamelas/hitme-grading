/*  unit_tests.h
 *  Armaan Sikka
 *  2/3/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  A testing file for your Linked List class that uses the unit_test framework
 *
 */

#include "CharLinkedList.h"
#include <cassert>

void constructor_test() {
    CharLinkedList list;
}

void charConstructor_test() {
    CharLinkedList list('A');
    assert(list.toString() == "[CharLinkedList of size 1 <<A>>]");
}

void listConstructor_test() {
    CharLinkedList list('A');
    list.pushAtBack('B');
    list.pushAtBack('C');

    CharLinkedList list2(list);

    assert(list2.toString() == "[CharLinkedList of size 3 <<ABC>>]");
}

void size_test() {
    CharLinkedList list;
    assert(list.size() == 0);

    CharLinkedList list2('A');
    list2.pushAtBack('l');
    assert(list2.size() == 2);
}

void isEmpty_test() {
    CharLinkedList list;
    assert(list.isEmpty());
}

void clear_test() {
    CharLinkedList list('A');
    list.clear();
    assert(list.isEmpty());
}

void first_test() {
    CharLinkedList list('A');
    list.pushAtFront('N');
    assert(list.first() == 'N');

    bool err_thrown = false;
    std::string err_msg = "";
    CharLinkedList list2;

    try {
        list2.first();
    } catch (const std::runtime_error &e) {
        err_thrown = true;
        err_msg = e.what();
    }

    assert(err_thrown);
    assert(err_msg == "cannot get first of empty LinkedList");
}

void last_test() {
    CharLinkedList list('A');
    list.pushAtBack('l');
    list.pushAtBack('i');
    list.pushAtBack('c');
    list.pushAtBack('e');
    assert(list.last() == 'e');

    bool err_thrown = false;
    std::string err_msg = "";
    CharLinkedList list2;

    try {
        list2.last();
    } catch (const std::runtime_error &e) {
        err_thrown = true;
        err_msg = e.what();
    }

    assert(err_thrown);
    assert(err_msg == "cannot get last of empty LinkedList");
}

void elementAt_test() {
    CharLinkedList list('A');
    list.pushAtBack('l');
    list.pushAtBack('i');
    list.pushAtBack('c');
    list.pushAtBack('e');

    assert(list.elementAt(2) == 'i');
}

void elementAt_incorrect() {
    bool err_thrown = false;
    std::string err_msg = "";
    CharLinkedList list2;

    try {
        list2.elementAt(2);
    } catch (const std::range_error &e) {
        err_thrown = true;
        err_msg = e.what();
    }

    assert(err_thrown);
    assert(err_msg == "index (2) not in range [0..0)");
}

void toReverseString_test() {
    CharLinkedList list('A');
    list.pushAtBack('l');
    list.pushAtBack('i');
    list.pushAtBack('c');
    list.pushAtBack('e');

    assert(list.toReverseString() == "[CharLinkedList of size 5 <<ecilA>>]");
}

void toReverseString_empty() {
    CharLinkedList list;
    assert(list.toReverseString() == "[CharLinkedList of size 0 <<>>]");
}

void insertAt_middle_test() {
    CharLinkedList list('A');
    list.pushAtBack('l');
    list.pushAtBack('c');
    list.pushAtBack('e');
    list.insertAt('i', 2);

    assert(list.toString() == "[CharLinkedList of size 5 <<Alice>>]");
}

void insertAt_back_test() {
    CharLinkedList list('A');
    list.pushAtBack('l');
    list.pushAtBack('i');
    list.pushAtBack('c');
    list.insertAt('e', 4);

    assert(list.toString() == "[CharLinkedList of size 5 <<Alice>>]");
}

void insertAt_front_test() {
    CharLinkedList list('l');
    list.pushAtBack('i');
    list.pushAtBack('c');
    list.pushAtBack('e');
    list.insertAt('A', 0);

    assert(list.toString() == "[CharLinkedList of size 5 <<Alice>>]");
}

void insertAt_incorrect() {
    CharLinkedList list('A');
    bool err_thrown = false;
    std::string err_msg = "";

    try {
        list.insertAt('i', 2);
    } catch (const std::range_error &e) {
        err_thrown = true;
        err_msg = e.what();
    }

    assert(err_thrown);
    assert(err_msg == "index (2) not in range [0..1]");
}

void insertAt_frontAndBack() {
    CharLinkedList list;
    list.insertAt('a', 0);
    list.insertAt('b', 1);


    assert(list.toString() == "[CharLinkedList of size 2 <<ab>>]");
}

void insertInOrder_test() {
    CharLinkedList list('A');
    list.pushAtBack('B');
    list.pushAtBack('D');
    list.pushAtBack('E');
    list.pushAtBack('F');
    list.insertInOrder('C');

    assert(list.toString() == "[CharLinkedList of size 6 <<ABCDEF>>]");
}

void insertInOrder_emptylist() {
    CharLinkedList list;
    list.insertInOrder('B');

    assert(list.toString() == "[CharLinkedList of size 1 <<B>>]");
}

void popFromBack_test_incorrect() {
    CharLinkedList list;
    bool err_thrown = false;
    std::string err_msg = "";

    try {
        list.popFromBack();
    } catch (const std::runtime_error &e) {
        err_thrown = true;
        err_msg = e.what();
    }

    assert(err_thrown);
    assert(err_msg == "cannot pop from empty LinkedList");
}

void popFromFront_test_incorrect() {
    CharLinkedList list;
    bool err_thrown = false;
    std::string err_msg = "";

    try {
        list.popFromFront();
    } catch (const std::runtime_error &e) {
        err_thrown = true;
        err_msg = e.what();
    }

    assert(err_thrown);
    assert(err_msg == "cannot pop from empty LinkedList");
}

void popFromFront_test() {
    CharLinkedList list('A');
    list.pushAtBack('A');
    list.pushAtBack('B');
    list.pushAtBack('C');
    list.popFromFront();

    assert(list.toString() == "[CharLinkedList of size 3 <<ABC>>]");
}

void popFromBack_test() {
    CharLinkedList list('X');
    list.pushAtBack('Y');
    list.pushAtBack('Z');
    list.pushAtBack('Z');
    list.popFromBack();

    assert(list.toString() == "[CharLinkedList of size 3 <<XYZ>>]");
}

void replaceAt_test() {
    CharLinkedList list('A');
    list.pushAtBack('B');
    list.pushAtBack('B');
    list.pushAtBack('D');

    list.replaceAt('C', 2);

    assert(list.toString() == "[CharLinkedList of size 4 <<ABCD>>]");
}

void replaceAt_emptylist() {
    CharLinkedList list;
    bool err_thrown = false;
    std::string err_msg = "";

    try {
        list.replaceAt('c', 2);
    } catch (const std::range_error &e) {
        err_thrown = true;
        err_msg = e.what();
    }

    assert(err_thrown);
    assert(err_msg == "index (2) not in range [0..0)");
}

void concatenate_test() {
    CharLinkedList list('A');
    list.pushAtBack('B');
    list.pushAtBack('C');

    CharLinkedList list2(list);

    list.concatenate(&list2);

    assert(list.toString() == "[CharLinkedList of size 6 <<ABCABC>>]");
}

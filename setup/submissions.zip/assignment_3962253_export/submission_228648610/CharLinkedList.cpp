/*
 *  CharLinkedList.cpp
 *  Armaan Sikka
 *  2/3/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Function definitions for CharLinkedList class.
 *
 */

#include "CharLinkedList.h"
#include <sstream>
#include <stdexcept>

using namespace std;

/* Purpose: Initialises an empty LinkedList */
CharLinkedList::CharLinkedList() {
    front = nullptr;
    back = nullptr;
    currSize = 0;
}

/* Purpose: Initialises a LinkedList with a single character*/
CharLinkedList::CharLinkedList(char c) {
    Node *newNode = new Node;
    newNode->data = c;
    newNode->next = nullptr;
    newNode->previous = nullptr;
    front = newNode;
    back = newNode;
    currSize = 1;
}

/* Purpose: Initialises a LinkedList that contains the characters in the given
 *          array of characters
 */
CharLinkedList::CharLinkedList(char arr[], int size) {
    for (int i = 0; i < currSize; i++) {
        pushAtBack(arr[i]);
    }
}

/* Purpose: Initialises a LinkedList that is identical to another LinkedList*/
CharLinkedList::CharLinkedList(const CharLinkedList &other) {
    front = nullptr;
    back = nullptr;
    currSize = 0;

    Node *curr = other.front;

    while (curr != nullptr) {
        pushAtBack(curr->data);
        curr = curr->next;
    }
}

/* Purpose: Calls a helper function to clean up memory of LinkedList upon 
 *          destruction.
 */
CharLinkedList::~CharLinkedList() {
    recycle_CLL(front);
}

/* recycle_CLL
 *    Purpose: private helper function that recursively deletes the LinkedList
 * Parameters: The front/first Node in the LinkedList
 *    Returns: None
 */
void CharLinkedList::recycle_CLL(Node *curr) {
    if(curr == nullptr) {
        return;

    } else {
        Node *next = curr->next;
        recycle_CLL(next);
        delete curr;
    }
}

/* &operator=
 *    Purpose: recycles the storage associated with the instance on the left of
 *             the assignment and makes a deep copy of the instance on the right
 *             hand side into the instance on the left hand side
 * Parameters: The address of another LinkedList
 *    Returns: A LinkedList
 */
CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other) {
    if (this == &other) {
        return *this;
    }

    *front = *other.front;
    *back = *other.back;
    currSize = other.currSize;
    return *this;
}

/* iterateTo
 *    Purpose: private helper function that iterates through the LinkedList
 *             to find the required character
 * Parameters: The front/first Node of the LinkedList, the index of the char to
 *             return, and a count to keep track of the iteration of the
 *             LinkedList.
 *    Returns: A character type
 */
char CharLinkedList::iterateTo(int index, Node *curr, int count) const {
    if (count == index) {
        return curr->data;

    } else {
        Node *next = curr->next;
        count++;
        return iterateTo(index, next, count);
    }
}

/* toString
 *    Purpose: converts the LinkedList into a string type and returns the string
 *             as well as its size
 * Parameters: None
 *    Returns: A string with the format "[CharLinkedList of size (SIZE) <<(LIST)
 *             >>]"
 */
std::string CharLinkedList::toString() const {
    std::stringstream ss;
    ss << "[CharLinkedList of size ";
    ss << currSize;
    ss << " <<";
    Node *curr = front;

    for (int i = 0; i < currSize; i++) {
        if (curr == nullptr) {
            ss << ">>]";
            return ss.str();
        }
        ss << curr->data;
        curr = curr->next;
    }

    ss << ">>]";
    return ss.str();
}

/* toReverseString
 *    Purpose: converts the LinkedList into the reverse order of what the
 *             toString function would print the LinkedList characters in
 *             but in the same format
 * Parameters: None
 *    Returns: A string with the format "[CharLinkedList of size (SIZE) 
 *             <<(REVERSED_LIST)>>]"
 */
std::string CharLinkedList::toReverseString() const {
    std::stringstream ss;
    ss << "[CharLinkedList of size ";
    ss << currSize;
    ss << " <<";
    Node *curr = back;

    for (int i = 0; i < currSize; i++) {
        if (curr == nullptr) {
            ss << ">>]";
            return ss.str();
        }
        ss << curr->data;
        curr = curr->previous;
    }

    ss << ">>]";
    return ss.str();
}

/* size
 *    Purpose: access and return the size of the LinkedList
 * Parameters: None
 *    Returns: An integer value of the size of the LinkedList
 */
int CharLinkedList::size() {
    return currSize;
}

/* isEmpty
 *    Purpose: To let the user know whether the LinkedList is empty or not
 * Parameters: None
 *    Returns: A boolean value of whether the LinkedList is empty or not
 */
bool CharLinkedList::isEmpty() {
    if (currSize == 0) {
        return true;
    }
    return false;
}

/* clear
 *    Purpose: To clear the LinkedList when called of all Nodes
 * Parameters: None
 *    Returns: None
 */
void CharLinkedList::clear() {
    currSize = 0;
}

/* pushAtBack
 *    Purpose: Add a Node/character at the back of the LinkedList
 * Parameters: A character that the user wishes to insert at the back
 *    Returns: None
 */
void CharLinkedList::pushAtBack(char c) {
    Node *newNode = new Node;
    newNode->data = c;
    newNode->next = nullptr;
    newNode->previous = back;

    if (currSize == 0) {
        front = newNode;
    } else {
        back->next = newNode;
    }

    back = newNode;
    currSize++;
}

/* pushAtFront
 *    Purpose: Add a node/character to the front of the LinkedList
 * Parameters: The character that the user wishes to insert at the front
 *    Returns: None
 */
void CharLinkedList::pushAtFront(char c) {
    Node *newNode = new Node;
    newNode->data = c;
    newNode->next = front;
    newNode->previous = nullptr;
    front = newNode;

    if (currSize == 0) {
        back = newNode;
    }

    currSize++;
}

/* first
 *    Purpose: A function the user can use to return the character value of the
 *             first element in the LinkedList
 * Parameters: None
 *    Returns: The character value of the first element in the LinkedList
 */
char CharLinkedList::first() {
    if (currSize == 0) {
        throw std::runtime_error("cannot get first of empty LinkedList");
    }

    return front->data;
}

/* last
 *    Purpose: A function the user can use to return the character value of the
 *             lsat element in the LinkedList
 * Parameters: None
 *    Returns: The character value of the last character in the LinkedList
 */
char CharLinkedList::last() {
    if (currSize == 0) {
        throw std::runtime_error("cannot get last of empty LinkedList");
    }

    return back->data;
}

/* elementAt
 *    Purpose: A function the user can use to obtain the character value of the
 *             element at the specified index
 * Parameters: An integer value of the index
 *    Returns: The character value of the element at the specified index
 */
char CharLinkedList::elementAt(int index) const {
    if (index < 0 or index >= currSize) {
        throw std::range_error("index (" + std::to_string(index) +
                        ") not in range [0.." + std::to_string(currSize) + ")");
    }

    char thing = this->iterateTo(index, front, 0);
    return thing;
}

/* insertAt
 *    Purpose: A function the user can use to insert a specific character at a
 *             specific index in the LinkedList
 * Parameters: The character and the index at which the user wants to insert
 *    Returns: None
 */
void CharLinkedList::insertAt(char c, int index) {
    if (index < 0 or index > currSize) {
        throw std::range_error("index (" + std::to_string(index) +
                        ") not in range [0.." + std::to_string(currSize) + "]");
    }

    if (index == 0) {
        pushAtFront(c);

    } else if (index == currSize) {
        pushAtBack(c);

    } else {
        Node *curr = front;
        for (int i = 0; i < index; i++) {
            curr = curr->next;
        }

        Node *newNode = new Node;
        newNode->data = c;
        newNode->previous = curr->previous;
        curr->previous = newNode;
        newNode->previous->next = newNode;
        newNode->next = curr;
        currSize++;
    }
}

/* insertInOrder
 *    Purpose: A function the user can use to insert a character in order of its
 *             ASCII value
 * Parameters: The character that the user wishes to insert in order to the
 *             LinkedList
 *    Returns: None
 */
void CharLinkedList::insertInOrder(char c) {
    if (currSize == 0) {
        pushAtBack(c);

    } else {
        Node *curr = front;
        int index = 0;

        while (c > curr->data) {
            curr = curr->next;
            index++;
        }
        insertAt(c, index);
    }
}

/* popFromFront
 *    Purpose: To remove the element at the start/front of the list
 * Parameters: None
 *    Returns: None
 */
void CharLinkedList::popFromFront() {
    if (currSize == 0) {
        throw std::runtime_error("cannot pop from empty LinkedList");
    }

    removeAt(0);
}

/* popFromBack
 *    Purpose: To remove the element at the end/back of the list
 * Parameters: None
 *    Returns: None
 */
void CharLinkedList::popFromBack() {
    if (currSize == 0) {
        throw std::runtime_error("cannot pop from empty LinkedList");
    }

    removeAt(currSize - 1);    
}

/* removeAt
 *    Purpose: To remove the element at the specified index
 * Parameters: The integer value of the index of the element to be removed
 *    Returns: None
 */
void CharLinkedList::removeAt(int index) {
    // throws range_error if the index specified is out of range
    if (index == 0 and currSize == 0) {
        throw std::range_error("index (" + std::to_string(index) +
                        ") not in range [0.." + std::to_string(currSize) + ")");
    } else if (index < 0 or index >= currSize) {
        throw std::range_error("index (" + std::to_string(index) +
                        ") not in range [0.." + std::to_string(currSize) + ")");
    }

    if (index == 0) {
        Node *curr = front;
        front = curr->next;
        curr->previous = nullptr;
        delete curr;
        currSize--;

    } else if (index == (currSize - 1)) {
        Node *curr = back;
        back = curr->previous;
        back->next = nullptr;
        delete curr;
        currSize--;

    } else {
        Node *curr = front;

        for (int i = 0; i < index; i++) {
            curr = curr->next;
        }
        
        curr->previous->next = curr->next;
        curr->next->previous = curr->previous;
        delete curr;
        currSize--;
    }
}

/* replaceAt
 *    Purpose: To replace the character at the specified index with the
 *             specified character.
 * Parameters: The integer value of the index of the element to be removed and
 *             the character to replace it with.
 *    Returns: None
 */
void CharLinkedList::replaceAt(char c, int index) {
    // throws range_error if the index specified is out of range
    if (index == 0 and currSize == 0) {
        throw std::range_error("index (" + std::to_string(index) +
                        ") not in range [0.." + std::to_string(currSize) + ")");
    } else if (index < 0 or index >= currSize) {
        throw std::range_error("index (" + std::to_string(index) +
                        ") not in range [0.." + std::to_string(currSize) + ")");
    }

    replaceAtHelper(index, front, 0, c);
}

/* replaceAtHelper
 *    Purpose: private helper function that iterates through the LinkedList
 *             to find the required element to replace
 * Parameters: The front/first Node of the LinkedList, the index of the char to
 *             return, a count to keep track of the iteration of the
 *             LinkedList, and the character to replace the specified element at
 *             the specified index with.
 *    Returns: None
 */
void CharLinkedList::replaceAtHelper(int index, Node *curr, int count, char c) {
    if (count == index) {
        curr->data = c;
        return;

    } else {
        curr = curr->next;
        count++;
        return replaceAtHelper(index, curr, count, c);
    }
}

/* concatenate
 *    Purpose: To add a copy of LinkedList passed as a parameter to the
 *             LinkedList the function is called on
 * Parameters: A pointer to another LinkedList
 *    Returns: None
 */
void CharLinkedList::concatenate(CharLinkedList *other) {
    if (this == other) {
        CharLinkedList newlist(*other);
        Node *curr = newlist.front;
        this->back->next = curr;
        curr->previous = this->back;
        this->back = newlist.back;

    } else {
        Node *curr = other->front;
        while (curr != nullptr) {
            this->pushAtBack(curr->data);
            curr = curr->next;
        }
    }
}

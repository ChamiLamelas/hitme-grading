/*
 *  CharLinkedList.h
 *  Armaan Sikka
 *  2/3/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Class declaration for a CharLinkedList for HW2.
 *
 */

#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H

#include <string>

class CharLinkedList {
public:
    CharLinkedList();
    CharLinkedList(char c);
    CharLinkedList(char [], int size);
    CharLinkedList(const CharLinkedList &other);
    ~CharLinkedList();

    CharLinkedList &operator=(const CharLinkedList &other);

    int size();
    bool isEmpty();
    void clear();
    char first();
    char last();
    void pushAtBack(char c);
    void pushAtFront(char c);
    std::string toString() const;
    std::string toReverseString() const;
    char elementAt(int index) const;
    void insertAt(char c, int index);
    void insertInOrder(char c);
    void popFromFront();
    void popFromBack();
    void removeAt(int index);
    void replaceAt(char c, int index);
    void concatenate(CharLinkedList *other);


private:
    struct Node {
        char data;
        Node *next;
        Node *previous;
    };

    Node *front;
    Node *back;
    int currSize;

    void recycle_CLL(Node *curr);
    char iterateTo(int num, Node *curr, int count) const;
    void replaceAtHelper(int index, Node *curr, int count, char c);
};

#endif

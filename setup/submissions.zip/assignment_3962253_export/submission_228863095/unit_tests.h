/*
 * unit_tests.h
 *
 *
 *
 * edited by: Anamol Kaspal 2/7/2024
 * Uses Matt Russell's unit_test framework to test the CharLinkedList class.
 * This tests edge cases along with each of the functions.
 */

#include <cassert>
#include "CharLinkedList.h"

/********************************************************************\
*                       CHAR LINKED LIST TESTS                       *
\********************************************************************/

// Insert into an empty list
void insertAt_empty_correct() {
    CharLinkedList test_list;
    test_list.insertAt('a', 0);
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');
}

// Attempt insert into an empty list at an out-of-range index
void insertAt_empty_incorrect() {
    bool range_error_thrown = false;
    std::string error_message = "";

    CharLinkedList test_list;
    try {
        test_list.insertAt('a', 42);
    } catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0]");
}

// Insert at the front of a single-element list
void insertAt_front_singleton_list() {
    CharLinkedList test_list;
    test_list.pushAtBack('a');
    test_list.insertAt('b', 0);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'a');
}

// Insert at the back of a single-element list
void insertAt_back_singleton_list() {
    CharLinkedList test_list;
    test_list.pushAtBack('a');
    test_list.insertAt('b', 1);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
}

// Insert 1000 elements at the back
void insertAt_many_elements() {
    CharLinkedList test_list;

    for (int i = 0; i < 1000; i++) {
        test_list.insertAt('a', i);
    }

    assert(test_list.size() == 1000);
    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
}

// Insert at the front of a larger list
void insertAt_front_large_list() {
    CharLinkedList test_list;
    test_list.pushAtBack('a');
    test_list.pushAtBack('b');
    test_list.pushAtBack('c');
    test_list.insertAt('y', 0);

    assert(test_list.size() == 4);
    assert(test_list.elementAt(0) == 'y');
    // Use toString() to check the complete list structure
    assert(test_list.toString() == "[CharLinkedList of size 4 <<yabc>>]");
}



// Attempt insert into a non-empty list at an out-of-range index
void insertAt_nonempty_incorrect() {
    bool range_error_thrown = false;
    std::string error_message = "";

    CharLinkedList test_list;
    test_list.pushAtBack('a');
    try {
        test_list.insertAt('a', 42);
    } catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..1]");
}

// Test the default constructor
void constructor_default() {
    CharLinkedList test_list;
    assert(test_list.size() == 0);
    assert(test_list.isEmpty());
}

// Test the constructor with a single character
void constructor_single_char() {
    CharLinkedList test_list('x');
    assert(test_list.size() == 1);
    assert(test_list.first() == 'x');
    assert(test_list.last() == 'x');
}

// Test the constructor with an array of characters
void constructor_char_array() {
    char arr[] = {'a', 'b', 'c'};
    CharLinkedList test_list(arr, 3);
    assert(test_list.size() == 3);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    assert(test_list.elementAt(2) == 'c');
}

// Test the copy constructor
void constructor_copy() {
    char arr[] = {'a', 'b', 'c'};
    CharLinkedList original(arr, 3);
    CharLinkedList copy = original;
    assert(copy.size() == 3);
    assert(copy.elementAt(0) == 'a');
    assert(copy.elementAt(1) == 'b');
    assert(copy.elementAt(2) == 'c');
}

// Test the isEmpty function on an empty list
void isEmpty_empty_list() {
    CharLinkedList test_list;
    assert(test_list.isEmpty());
}

// Test the isEmpty function on a non-empty list
void isEmpty_non_empty_list() {
    CharLinkedList test_list('a');
    assert(test_list.size() > 0);
}

// Test the clear function on a non-empty list
void clear_non_empty_list() {
    CharLinkedList test_list;
    test_list.pushAtBack('a');
    test_list.pushAtBack('b');
    test_list.clear();
    assert(test_list.isEmpty());
}

// Test the first function on a non-empty list
void first_non_empty_list() {
    CharLinkedList test_list;
    test_list.pushAtBack('a');
    assert(test_list.first() == 'a');
}

// Test the first function throws an exception on an empty list
void first_empty_list() {
    bool exception_thrown = false;
    CharLinkedList test_list;
    try {
        test_list.first();
    } catch (const std::runtime_error&) {
        exception_thrown = true;
    }
    assert(exception_thrown);
}

// Test the last function on a non-empty list
void last_non_empty_list() {
    CharLinkedList test_list;
    test_list.pushAtBack('a');
    test_list.pushAtBack('b');
    assert(test_list.last() == 'b');
}

// Test the last function throws an exception on an empty list
void last_empty_list() {
    bool exception_thrown = false;
    CharLinkedList test_list;
    try {
        test_list.last();
    } catch (const std::runtime_error&) {
        exception_thrown = true;
    }
    assert(exception_thrown);
}

// Test the popFromFront function on a list with multiple elements
void popFromFront_multiple_elements() {
    CharLinkedList test_list;
    test_list.pushAtBack('a');
    test_list.pushAtBack('b');
    test_list.popFromFront();
    assert(test_list.size() == 1);
    assert(test_list.first() == 'b');
}

// Test the popFromBack function on a list with multiple elements
void popFromBack_multiple_elements() {
    CharLinkedList test_list;
    test_list.pushAtBack('a');
    test_list.pushAtBack('b');
    test_list.popFromBack();
    assert(test_list.size() == 1);
    assert(test_list.last() == 'a');
}

// Test the toString method for an empty list
void toString_empty() {
    CharLinkedList test_list;
    assert(test_list.toString() == "[CharLinkedList of size 0 <<>>]");
}

// Test the toString method for a non-empty list
void toString_non_empty() {
    CharLinkedList test_list;
    test_list.pushAtBack('a');
    test_list.pushAtBack('b');
    assert(test_list.toString() == "[CharLinkedList of size 2 <<ab>>]");
}

// Test the toReverseString method for an empty list
void toReverseString_empty() {
    CharLinkedList test_list;
    assert(test_list.toReverseString() == "[CharLinkedList of size 0 <<>>]");
}

// Test the toReverseString method for a non-empty list
void toReverseString_non_empty() {
    CharLinkedList test_list;
    test_list.pushAtBack('a');
    test_list.pushAtBack('b');
    assert(test_list.toReverseString() == "[CharLinkedList of size 2 <<ba>>]");
}

// Test removeAt throws an exception when index is out of bounds
void removeAt_out_of_bounds() {
    bool exception_thrown = false;
    CharLinkedList test_list;
    test_list.pushAtBack('a');
    try {
        test_list.removeAt(2);
    } catch (const std::range_error&) {
        exception_thrown = true;
    }
    assert(exception_thrown);
}

// Test replaceAt in a list with multiple elements
void replaceAt_multiple_elements() {
    CharLinkedList test_list;
    test_list.pushAtBack('a');
    test_list.pushAtBack('b');
    test_list.replaceAt('z', 1); // Replace 'b' with 'z'
    assert(test_list.elementAt(1) == 'z');
}

// Test replaceAt throws an exception when index is out of bounds
void replaceAt_out_of_bounds() {
    bool exception_thrown = false;
    CharLinkedList test_list;
    test_list.pushAtBack('a');
    try {
        test_list.replaceAt('z', 2);
    } catch (const std::range_error&) {
        exception_thrown = true;
    }
    assert(exception_thrown);
}

// Test removing from an empty list throws an exception
void removeAt_empty_list() {
    bool exception_thrown = false;
    CharLinkedList test_list;
    try {
        test_list.removeAt(0);
    } catch (const std::range_error& e) {
        exception_thrown = true;
    }
    assert(exception_thrown);
}

// Test inserting in order into an empty list correctly places the element
void insertInOrder_empty_list() {
    CharLinkedList test_list;
    test_list.insertInOrder('a');
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');
}

// Test inserting in order into a populated list maintains sorted order
void insertInOrder_populated_list() {
    CharLinkedList test_list;
    test_list.pushAtBack('a');
    test_list.pushAtBack('c');
    test_list.insertInOrder('b');
    assert(test_list.size() == 3);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    assert(test_list.elementAt(2) == 'c');
}
// Insert at the back of a larger list
void insertAt_back_large_list() {
    CharLinkedList test_list;
    test_list.pushAtBack('a');
    test_list.pushAtBack('b');
    test_list.pushAtBack('c');
    test_list.insertAt('x', 3);

    assert(test_list.size() == 4);
    assert(test_list.elementAt(3) == 'x');
    assert(test_list.toString() == "[CharLinkedList of size 4 <<abcx>>]");
}

// Test concatenate on two non-empty lists
void concatenate_non_empty_lists() {
    CharLinkedList list1;
    list1.pushAtBack('a');
    list1.pushAtBack('b');

    CharLinkedList list2;
    list2.pushAtBack('c');
    list2.pushAtBack('d');

    list1.concatenate(&list2);
    assert(list1.toString() == "[CharLinkedList of size 4 <<abcd>>]");
}


// Test insertInOrder in a non-empty sorted list
void insertInOrder_non_empty_sorted_list() {
    CharLinkedList test_list;
    test_list.pushAtBack('a');
    test_list.pushAtBack('c');
    test_list.insertInOrder('b');
    assert(test_list.elementAt(1) == 'b');
}

// Test removeAt in a list with multiple elements
void removeAt_multiple_elements() {
    CharLinkedList test_list;
    test_list.pushAtBack('a');
    test_list.pushAtBack('b');
    test_list.pushAtBack('c');
    test_list.removeAt(1); // Remove 'b'
    assert(test_list.elementAt(1) == 'c');
    assert(test_list.size() == 2);
}

// Insert in the middle of a larger list
void insertAt_middle_large_list() {
    CharLinkedList test_list;
    test_list.pushAtBack('a');
    test_list.pushAtBack('b');
    test_list.pushAtBack('d');
    test_list.insertAt('c', 2);

    assert(test_list.size() == 4);
    assert(test_list.elementAt(2) == 'c');
    assert(test_list.toString() == "[CharLinkedList of size 4 <<abcd>>]");
}

// Test the elementAt method for a LinkedList with 4 characters
void testInsertAt() {
    CharLinkedList list;
    list.pushAtBack('a');
    list.pushAtBack('b');
    list.pushAtBack('d'); 
    list.insertAt('c', 2); // Should insert 'c' between 'b' and 'd'

 
    assert(list.elementAt(2) == 'c');
    // Verify list size is correct
    assert(list.size() == 4);
    // Verify list structure
    assert(list.toString() == "[CharLinkedList of size 4 <<abcd>>]");
}

// Test the elementAt method for a LinkedList with 4 characters
void testElementRetrieval() {
    CharLinkedList list;
    list.pushAtBack('a');
    list.pushAtBack('b');
    list.pushAtBack('c');
    list.pushAtBack('d');

    // Verify each element is retrievable and correct
    assert(list.elementAt(0) == 'a');
    assert(list.elementAt(1) == 'b');
    assert(list.elementAt(2) == 'c');
    assert(list.elementAt(3) == 'd');
}

// Test the toString method for a LinkedList with 4 characters
void testToString() {
    CharLinkedList list;
    list.pushAtBack('a');
    list.pushAtBack('b');
    list.pushAtBack('c');
    list.pushAtBack('d');

    // Verify the string representation is correct
    assert(list.toString() == "[CharLinkedList of size 4 <<abcd>>]");
}

// Test the size method after adding characters to an empty list
void testSize() {
    CharLinkedList test_list;
    assert(test_list.size() == 0); // Test empty list has size 0
    
    test_list.pushAtBack('a');
    assert(test_list.size() == 1); // Test size after adding one element
    
    test_list.pushAtBack('b');
    assert(test_list.size() == 2); // Test size after adding another element
}

// test the pushAtBack method by adding characters to an empty list
void testPushAtBack() {
    CharLinkedList test_list;
    test_list.pushAtBack('a');
    assert(test_list.last() == 'a'); // Test if 'a' is correctly added at
    
    test_list.pushAtBack('b');
    assert(test_list.last() == 'b'); // Test if 'b' is correctly added at 
    assert(test_list.size() == 2);   // Make sure the size is updated correctly
}

// test the pushAtFront method by adding characters to an empty list
void testPushAtFront() {
    CharLinkedList test_list;
    test_list.pushAtFront('b');
    assert(test_list.first() == 'b'); // Test if 'b' is correctly added
    
    test_list.pushAtFront('a');
    assert(test_list.first() == 'a'); 
    assert(test_list.elementAt(1) == 'b'); // Make sure 'b' is second element
    assert(test_list.size() == 2);         // Make sure size is updated
}

// tests to see if the function can concetenate with itself
void concatenateWithItself() {
    CharLinkedList list;
    // Populate the list
    list.pushAtBack('X');
    list.pushAtBack('Y');
    list.pushAtBack('Z');

    // Expected size before concatenation
    int expectedSizeBefore = 3;
    assert(list.size() == expectedSizeBefore);

    // Perform concatenation with itself
    list.concatenate(&list);

    // Expected size after concatenation is double the initial size
    int expectedSizeAfter = expectedSizeBefore * 2;
    assert(list.size() == expectedSizeAfter);

    // Verify the content of the list after concatenation
    assert(list.elementAt(0) == 'X');
    assert(list.elementAt(1) == 'Y');
    assert(list.elementAt(2) == 'Z');
    assert(list.elementAt(3) == 'X');
    assert(list.elementAt(4) == 'Y');
    assert(list.elementAt(5) == 'Z');
}
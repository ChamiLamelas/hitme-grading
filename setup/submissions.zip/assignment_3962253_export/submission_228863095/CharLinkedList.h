/*
 *  CharLinkedList.h
 *  Anamol Kaspal akaspa02
 *  2/7/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  This file contains the interface for the CharLinkedList class.
 *
 */

// CharLinkedList.h
#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H

#include <stdexcept>
#include <string>

class CharLinkedList {
public:
    // Constructors
    CharLinkedList(); // Default constructor
    CharLinkedList(char c); // Constructor with a single character
    CharLinkedList(char arr[], int size); // Constructor with character array
    CharLinkedList(const CharLinkedList& other); // Copy constructor

    // Destructor
    ~CharLinkedList();

    // Assignment operator
    CharLinkedList& operator=(const CharLinkedList& other);

    // Public member functions
    bool isEmpty() const;
    void clear();
    int size() const;
    char first() const;
    char last() const;
    char elementAt(int index) const;
    std::string toString() const;
    std::string toReverseString() const;
    void pushAtBack(char c);
    void pushAtFront(char c);
    void insertAt(char c, int index);
    void insertInOrder(char c);
    void popFromFront();
    void popFromBack();
    void removeAt(int index);
    void replaceAt(char c, int index);
    void concatenate(CharLinkedList* other);

private:
    // Node structure for the doubly linked list
    struct Node {
        char data;
        Node* next;
        Node* prev;
        Node(char data, Node* next = nullptr, Node* prev = nullptr) : data(data)
        , next(next), prev(prev) {}
    };

    Node* head; // Pointer to the first node
    Node* tail; // Pointer to the last node
    int listSize; // Size of the list
    void deleteNodesRecursively(Node* node);
    char elementAtRecursive(Node* node, int index) const;
    void replaceAtRecursive(Node* node, char c, int index);
   
};

#endif // CHAR_LINKED_LIST_H

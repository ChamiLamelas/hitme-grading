/*
 *  CharLinkedList.cpp
 *  Anamol Kaspal akaspa02
 *  2/7/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  This file contains the implementation for the CharLinkedList class.
 *  It includes constructors, a destructor, and methods for manipulating
 *  and accessing characters in the linked list.
 *
 */

#include "CharLinkedList.h"

/**
 * Default Constructor:
 * Purpose: Initializes an empty CharLinkedList.
 * Arguments: None.
 * Returns: None.
 * Effects: Creates an empty list with head and tail pointing to nullptr, 
 *          listSize set to 0.
 */

CharLinkedList::CharLinkedList() : head(nullptr), tail(nullptr), listSize(0) {}

/**
 * Single Character Constructor:
 * Purpose: Initializes a CharLinkedList with a single character.
 * Arguments: A char value.
 * Returns: None.
 * Effects: Creates a list with one node containing the provided character, 
 *          setting both head and tail to point to this node, and listSize to 1.
 */
CharLinkedList::CharLinkedList(char c) : head(new Node(c)), tail(head), 
listSize(1) {}

/**
 * Character Array Constructor:
 * Purpose: Initializes a CharLinkedList with an array of characters.
 * Arguments: An array of char and its size as int.
 * Returns: None.
 * Effects: Creates a list containing all characters from the array, 
 * from head to tail, setting listSize to the number of elements in the array.
 */
CharLinkedList::CharLinkedList(char arr[], int size) : CharLinkedList() {
    for (int i = 0; i < size; ++i) {
        pushAtBack(arr[i]);
    }
}

/**
 * Copy Constructor:
 * Purpose: Initializes a CharLinkedList as a deep copy of another list.
 * Arguments: A constant reference to another CharLinkedList.
 * Returns: None.
 * Effects: Copies all elements from the given list into the new list
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other) : CharLinkedList() {
    for (Node* current = other.head; current != nullptr;
    current = current->next) {
        pushAtBack(current->data);
    }
}


/**
 * Destructor:
 * Purpose: Destroys a CharLinkedList instance.
 * Arguments: None.
 * Returns: None.
 * Effects: Deallocates all dynamically allocated memory associated
 */

CharLinkedList::~CharLinkedList() {
    deleteNodesRecursively(head);
    head = tail = nullptr;
    listSize = 0;
}


/**
 * deleteNodesRecursively:
 * Purpose: Recursively deletes all nodes from the list, used by the destructor.
 * Arguments: A pointer to the current node (Node* node).
 * Returns: None.
 * Effects: Recursively traverses the list from the given node to the end, 
 * deleting each node.
 */
void CharLinkedList::deleteNodesRecursively(Node* node) {
    if (node != nullptr) {
        deleteNodesRecursively(node->next);
        delete node;
    }
}

/**
 * Assignment Operator:
 * Purpose: Assigns the content of another CharLinkedList to this instance.
 * Arguments: A constant reference to another CharLinkedList (&other).
 * Returns: A reference to the current instance (*this).
 * Effects: Clears the current list and copies all elements from 'other' to list
 */

CharLinkedList& CharLinkedList::operator=(const CharLinkedList &other) {
    if (this != &other) {
        clear();
        for (Node* current = other.head; current != nullptr;
        current = current->next) {
            pushAtBack(current->data);
        }
    }
    return *this;
}

/**
 * isEmpty:
 * Purpose: Checks if the list is empty.
 * Arguments: None.
 * Returns: A bool indicating if the list is empty (true) or not (false).
 * Effects: None.
 */
bool CharLinkedList::isEmpty() const {
    return listSize == 0;
}

/**
 * clear:
 * Purpose: Removes all elements from the list.
 * Arguments: None.
 * Returns: None.
 * Effects: Clears the list, setting head and tail to nullptr and listSize to 0.
 */
void CharLinkedList::clear() {
    Node* current = head;
    while (current != nullptr) {
        Node* next = current->next;
        delete current;
        current = next;
    }
    head = tail = nullptr;
    listSize = 0;
}

/**
 * size:
 * Purpose: Gets the number of elements in the list.
 * Arguments: None.
 * Returns: An int representing the number of elements in the list.
 * Effects: None.
 */
int CharLinkedList::size() const {
    return listSize;
}


/**
 * first:
 * Purpose: Retrieves the first character in the list.
 * Arguments: None.
 * Returns: The char stored in the first node.
 * Effects: Throws a std::runtime_error if the list is empty.
 */

char CharLinkedList::first() const {
    if (isEmpty()) throw std::runtime_error
    ("cannot get first of empty LinkedList");
    return head->data;
}

/**
 * last:
 * Purpose: Retrieves the last character in the list.
 * Arguments: None.
 * Returns: The char stored in the last node.
 * Effects: Throws a std::runtime_error if the list is empty.
 */
char CharLinkedList::last() const {
    if (isEmpty()) throw std::runtime_error
    ("cannot get last of empty LinkedList");
    return tail->data;
}


/**
 * pushAtBack:
 * Purpose: Adds a character to the end of the list.
 * Arguments: A char to be added.
 * Returns: None.
 * Effects: Adds a new node containing the character at the end of the list,
 *          adjusts tail accordingly, and increments listSize.
 */

void CharLinkedList::pushAtBack(char c) {
    insertAt(c, size()); 
}


/**
 * pushAtFront:
 * Purpose: Inserts a character at the beginning of the list.
 * Arguments: A char value (c).
 * Returns: None.
 * Effects: Adds a new node containing 'c' at the head of the list, 
 * adjusting pointers accordingly, and increments listSize.
 */
void CharLinkedList::pushAtFront(char c) {
    insertAt(c, 0); 
}

/**
 * insertAt:
 * Purpose: Inserts a character at a specified index in the list.
 * Arguments: A char value (c) and an integer index (index).
 * Returns: None.
 * Effects: Inserts 'c' at the given index, shifting other elements as necessary
 *          Adjusts head or tail if needed.
 */
void CharLinkedList::insertAt(char c, int index) {
    if (index < 0 or index > listSize) {
        throw std::range_error("index (" + std::to_string(index) + 
        ") not in range [0.." + std::to_string(listSize) + "]");
    }
    Node* newNode = new Node(c);
    if (index == 0) {
        newNode->next = head;
        if (head != nullptr) head->prev = newNode;
        head = newNode;
        if (listSize == 0) tail = newNode;
    } else if (index == listSize) {
        tail->next = newNode;
        newNode->prev = tail;
        tail = newNode;
    } else {
        Node* current = head;
        for (int i = 0; i < index; i++) current = current->next;
        newNode->next = current;
        newNode->prev = current->prev;
        current->prev->next = newNode;
        current->prev = newNode;
    }
    listSize++;
}



/**
 * popFromFront:
 * Purpose: Removes the first element from the list.
 * Arguments: None.
 * Returns: None.
 * Effects: Removes the head node of the list, adjusting pointers 
 * and decrementing listSize. Throws runtime_error if the list is empty.
 */
void CharLinkedList::popFromFront() {
    if (isEmpty()) {
        throw std::runtime_error("cannot pop from empty LinkedList");
    }
    Node* temp = head;
    if (head == tail) {
        head = tail = nullptr;
    } else {
        head = head->next;
        head->prev = nullptr;
    }
    delete temp;
    listSize--;
}

/**
 * popFromBack:
 * Purpose: Removes the last element from the list.
 * Arguments: None.
 * Returns: None.
 * Effects: Removes the tail node of the list, adjusting pointers and 
 * decrementing listSize. Throws runtime_error if the list is empty.
 */
void CharLinkedList::popFromBack() {
    if (isEmpty()) {
        throw std::runtime_error("cannot pop from empty LinkedList");
    }
    Node* temp = tail;
    if (head == tail) { // Single element
        head = tail = nullptr;
    } else {
        tail = tail->prev;
        tail->next = nullptr;
    }
    delete temp;
    listSize--;
}


/**
 * replaceAt:
 * Purpose: Replaces the element at a specific index with a new character.
 * Arguments: A char value (c) and an integer index (index).
 * Returns: None.
 * Effects: Updates the data of the node at 'index' with 'c'. 
 * Throws range_error if index is out of bounds.
 */
void CharLinkedList::replaceAt(char c, int index) {
    if (index < 0 or index >= listSize) {
        throw std::range_error("index (" + std::to_string(index) +
         ") not in range [0.." + std::to_string(listSize) + ")");
    }
    replaceAtRecursive(head, c, index);
}

/**
 * replaceAtRecursive:
 * Purpose: Recursively replaces the element at a index with a new character.
 * Arguments: A pointer to the current node (Node* node),
 *            a char value (c), and an integer index (index).
 * Returns: None.
 * Effects: Recursively finds the node at 'index' and updates its data with 'c'.
 */
void CharLinkedList::replaceAtRecursive(Node* node, char c, int index) {
    if (index == 0) {
        node->data = c;
        return;
    }
    replaceAtRecursive(node->next, c, index - 1);
}


/**
 * concatenate:
 * Purpose: Concatenates another CharLinkedList to the end of this list.
 * Arguments: A pointer to another CharLinkedList (other).
 * Returns: None.
 * Effects: Appends all elements of 'other' to the end of this list. 
 * Handles self-concatenation by making a temporary copy.
 */
void CharLinkedList::concatenate(CharLinkedList *other) {
    if (this == other) {
        CharLinkedList temp(*other); 
        for (Node* current = temp.head; current != nullptr;
        current = current->next) {
            pushAtBack(current->data);
        }
    } else {
        for (Node* current = other->head; current != nullptr;
        current = current->next) {
            pushAtBack(current->data);
        }
    }
}


/**
 * elementAt:
 * Purpose: Returns the character at a specified index in the list.
 * Arguments: An integer index (index).
 * Returns: The char at the specified index.
 * Effects: Throws range_error if index is out of bounds.
 */

char CharLinkedList::elementAt(int index) const {
    if (index < 0 or index >= listSize) {
        throw std::range_error("index (" + std::to_string(index) 
        + ") not in range [0.." + std::to_string(listSize) + ")");
    }
    return elementAtRecursive(head, index);
}
/**
 * elementAtRecursive: (helper function for elementAt)
 * Purpose: Recursively retrieves the character at a specified index in the list
 * Arguments: A pointer to the current node (Node* node) and an integer index 
 * Returns: The char at the specified index.
 * Effects: Recursively traverses the list and return the character at 'index'.
 */
char CharLinkedList::elementAtRecursive(Node* node, int index) const {
    if (index == 0) return node->data;
    return elementAtRecursive(node->next, index - 1);
}

/**
 * toString:
 * Purpose: Creates a string representation of the list.
 * Arguments: None.
 * Returns: A std::string representing the list contents.
 * Effects: Constructs a string detailing the size and elements of the list.
 */

std::string CharLinkedList::toString() const {
    std::string result = "[CharLinkedList of size " + 
    std::to_string(listSize) + " <<";
    Node* current = head;
    while (current != nullptr) {
        result += current->data;
        if (current->next != nullptr) result += "";
        current = current->next;
    }
    result += ">>]";
    return result;
}

/**
 * toReverseString:
 * Purpose: Creates a reverse string representation of the list.
 * Arguments: None.
 * Returns: A std::string representing the list contents in reverse order.
 * Effects: Constructs a string detailing the size and elements in reverse
 */
std::string CharLinkedList::toReverseString() const {
    std::string result = "[CharLinkedList of size " + 
    std::to_string(listSize) + " <<";
    Node* current = tail;
    while (current != nullptr) {
        result += current->data;
        if (current->prev != nullptr) result += "";
        current = current->prev;
    }
    result += ">>]";
    return result;
}

/**
 * insertInOrder:
 * Purpose: Inserts a character in sorted (ascending) order based on ASCII
 * Arguments: A char value (c).
 * Returns: None.
 * Effects: Inserts 'c' into the list maintaining ascending order. 
 *          Adjusts pointers and increments listSize.
 */
void CharLinkedList::insertInOrder(char c) {
    if (isEmpty() or c <= head->data) {
        pushAtFront(c);
        return;
    }
    Node* current = head;
    while (current->next != nullptr and current->next->data < c) {
        current = current->next;
    }
    // Handle insertion at the end
    if (current->next == nullptr) {
        pushAtBack(c);
    } else {
        // Correct insertion in the middle to avoid double free
        Node* newNode = new Node(c);
        newNode->next = current->next;
        newNode->prev = current;
        if (current->next != nullptr) {
            current->next->prev = newNode;
        }
        current->next = newNode;
        listSize++;
    }
}



/**
 * removeAt:
 * Purpose: Removes the element at a specific index from the list.
 * Arguments: An integer index (index).
 * Returns: None.
 * Effects: Removes the node at 'index', adjusting pointers as necessary,
 *          decrements listSize. Throws range_error if index is out of bounds.
 */
void CharLinkedList::removeAt(int index) {
    if (index < 0 or index >= listSize) {
        throw std::range_error("index (" + std::to_string(index) + 
        ") not in range [0.." + std::to_string(listSize) + ")");
    }
    if (index == 0) {
        popFromFront();
        return;
    }
    if (index == listSize - 1) {
        popFromBack();
        return;
    }
    Node* current = head;
    for (int i = 0; i < index; ++i) {
        current = current->next;
    }
    current->prev->next = current->next;
    current->next->prev = current->prev;
    delete current;
    --listSize;
}

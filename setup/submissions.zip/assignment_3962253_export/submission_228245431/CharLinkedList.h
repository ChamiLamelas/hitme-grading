/*
 *  CharLinkedList.h
 *  Jeffrey Li
 *  2/2/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Interface for doubly linked list.
 *
 */

#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H

#include <string>

class CharLinkedList {
    public:
        //constructors
        CharLinkedList();
        CharLinkedList(char c);
        CharLinkedList(char arr[], int size);
        CharLinkedList(const CharLinkedList &other);

        //destructor
        ~CharLinkedList();

        //access operations
        bool isEmpty() const;
        void clear();
        int size() const;
        char first() const;
        char last() const;
        char elementAt(int index) const;

        //printing operations
        std::string toString() const;
        std::string toReverseString() const;

        //insert operations
        void pushAtBack(char c);
        void pushAtFront(char c);
        void insertAt(char c, int index);
        void insertInOrder(char c);

        //removal operations
        void popFromFront();
        void popFromBack();
        void removeAt(int index);

        //misc. operations
        void replaceAt(char c, int index);
        void concatenate(CharLinkedList *other);
        CharLinkedList &operator=(const CharLinkedList &other);

    private:
        struct Node {
            char c;
            Node *next;
            Node *prev;
        };

        int lsize;
        Node *front;

        //helper functions
        CharLinkedList::Node *nodeAtIndex(int index, Node *curr) const;
        void destroyList(Node *front);
        CharLinkedList::Node *getLast(Node *curr) const;
};

#endif

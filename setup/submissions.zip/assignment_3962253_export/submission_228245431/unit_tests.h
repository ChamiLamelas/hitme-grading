/*
 *  unit_tests.h
 *  Jeffrey Li
 *  2/3/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  unit tests for linked list data structure
 *
 */

#include "CharLinkedList.h"
#include <cassert>
#include <iostream>

void default_con() {
    CharLinkedList list;
}

void default_con_isEmpty() {
    CharLinkedList list;
    assert(list.isEmpty());
}

void one_char_con_first() {
    CharLinkedList list('a');
    assert(list.elementAt(0) == 'a');
}

void multi_con_first() {
    char arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList list(arr, 8);
    assert(list.elementAt(0) == 'a');
}

void multi_con_last() {
    char arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList list(arr, 8);
    assert(list.elementAt(7) == 'h');
}

void multi_con_size() {
    char arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList list(arr, 8);
    assert(list.size() == 8);
}

void multi_con_empty() {
    char arr[0] = {};
    CharLinkedList list(arr, 0);
    assert(list.isEmpty());
}

void copy_con_empty() {
    CharLinkedList list;
    CharLinkedList copy(list);
    assert(copy.isEmpty());
}

void copy_con_one_char() {
    CharLinkedList list('a');
    CharLinkedList copy(list);
    assert(copy.first() == 'a');
}

void copy_con_multi_char() {
    char arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList list(arr, 8);
    CharLinkedList copy(list);
    assert(list.toString() == "[CharLinkedList of size 8 <<abcdefgh>>]");
}

void empty_false() {
    CharLinkedList list('a');
    assert(not list.isEmpty());
}

void empty_true() {
    CharLinkedList list;
    assert(list.isEmpty());
}

void empty_size() {
    CharLinkedList list;
    assert(list.size() == 0);
}

void one_char_size() {
    CharLinkedList list('a');
    assert(list.size() == 1);
}

void empty_first_error() {
    CharLinkedList list;
    bool runtime_error_thrown = false;

    std::string error_message = "";

    try {
        list.first();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot get first of empty LinkedList");
}

void one_char_first() {
    CharLinkedList list('a');
    assert(list.first() == 'a');
}

void multi_char_first() {
    char arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList list(arr, 8);
    assert(list.first() == 'a');
}

void empty_last_error() {
    CharLinkedList list;
    bool runtime_error_thrown = false;

    std::string error_message = "";

    try {
        list.last();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot get last of empty LinkedList");
}

void one_char_last() {
    CharLinkedList list('a');
    assert(list.last() == 'a');
}

void multi_char_last() {
    char arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList list(arr, 8);
    assert(list.last() == 'h');
}

void empty_popFront_error() {
    CharLinkedList list;
    bool runtime_error_thrown = false;

    std::string error_message = "";

    try {
        list.popFromFront();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

void one_char_popFront() {
    CharLinkedList list('a');
    list.popFromFront();
    assert(list.isEmpty());
}

void multi_char_popFront() {
    char arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList list(arr, 8);
    list.popFromFront();
    assert(list.first() == 'b');
}

void multi_char_popFront_twice() {
    char arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList list(arr, 8);
    list.popFromFront();
    list.popFromFront();
    assert(list.first() == 'c');
}

void empty_toString() {
    CharLinkedList list;
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}

void one_char_toString() {
    CharLinkedList list('a');
    assert(list.toString() == "[CharLinkedList of size 1 <<a>>]");
}

void multi_char_toString() {
    char arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList list(arr, 8);
    assert(list.toString() == "[CharLinkedList of size 8 <<abcdefgh>>]");
}

void empty_reverseString() {
    CharLinkedList list;
    assert(list.toReverseString() == "[CharLinkedList of size 0 <<>>]");
}

void one_char_reverseString() {
    CharLinkedList list('a');
    assert(list.toReverseString() == "[CharLinkedList of size 1 <<a>>]");
}

void multi_char_reverseString() {
    char arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList list(arr, 8);
    assert(list.toReverseString() == "[CharLinkedList of size 8 <<hgfedcba>>]");
}

void empty_insert() {
    CharLinkedList list;
    list.insertAt('a', 0);
    assert(list.elementAt(0) == 'a');
}

void one_char_insert_back() {
    CharLinkedList list ('a');
    list.insertAt('b', 1);
    assert(list.elementAt(1) == 'b');
}

void one_char_insert_front() {
    CharLinkedList list ('a');
    list.insertAt('b', 0);
    assert(list.elementAt(0) == 'b');
}

void multi_char_insert_mid() {
    char arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList list(arr, 8);
    list.insertAt('a', 4);
    assert(list.elementAt(4) == 'a');
}

void multi_char_insert_mid_twice() {
    char arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList list(arr, 8);
    list.insertAt('a', 4);
    list.insertAt('a', 4);
    assert(list.toString() == "[CharLinkedList of size 10 <<abcdaaefgh>>]");
}

void empty_pushFront() {
    CharLinkedList list;
    list.pushAtFront('a');
    assert(list.elementAt(0) == 'a');
}

void empty_pushFront_twice() {
    CharLinkedList list;
    list.pushAtFront('a');
    list.pushAtFront('b');
    assert(list.elementAt(0) == 'b');
}

void empty_pushFront_thrice() {
    CharLinkedList list;
    list.pushAtFront('a');
    list.pushAtFront('b');
    list.pushAtFront('c');
    assert(list.elementAt(0) == 'c');
}

void empty_pushBack() {
    CharLinkedList list;
    list.pushAtBack('a');
    assert(list.last() == 'a');
}

void empty_pushBack_twice() {
    CharLinkedList list;
    list.pushAtBack('a');
    list.pushAtBack('b');
    assert(list.last() == 'b');
}

void empty_pushBack_thrice() {
    CharLinkedList list;
    list.pushAtBack('a');
    list.pushAtBack('b');
    list.pushAtBack('c');
    assert(list.last() == 'c');
}

void empty_popBack_error() {
    CharLinkedList list;
    bool runtime_error_thrown = false;

    std::string error_message = "";

    try {
        list.popFromBack();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

void one_char_popBack() {
    CharLinkedList list('a');
    list.popFromBack();
    assert(list.isEmpty());
}

void multi_char_popBack() {
    char arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList list(arr, 8);
    list.popFromBack();
    assert(list.last() == ('g'));
}

void multi_char_popBack_twice() {
    char arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList list(arr, 8);
    list.popFromBack();
    list.popFromBack();
    assert(list.last() == ('f'));
}

void empty_replace_error() {
    CharLinkedList list;
    bool range_error_thrown = false;

    std::string error_message = "";

    try {
        list.replaceAt('a', 0);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (0) not in range [0..0)");
}

void one_char_replace() {
    CharLinkedList list('a');
    list.replaceAt('b', 0);
    assert(list.toString() == "[CharLinkedList of size 1 <<b>>]");
}

void multi_char_replace() {
    char arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList list(arr, 8);
    list.replaceAt('f', 3);
    assert(list.toString() == "[CharLinkedList of size 8 <<abcfefgh>>]");
}

void empty_clear() {
    CharLinkedList list;
    list.clear();
    assert(list.isEmpty());
}

void one_char_clear() {
    CharLinkedList list('a');
    list.clear();
    assert(list.isEmpty());
}

void multi_char_clear() {
    char arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList list(arr, 8);
    list.clear();
    assert(list.isEmpty());
}

void empty_insertOrder() {
    CharLinkedList list;
    list.insertInOrder('a');
    assert(list.toString() == "[CharLinkedList of size 1 <<a>>]");
}

void one_char_insertOrder_before() {
    CharLinkedList list('b');
    list.insertInOrder('a');
    assert(list.toString() == "[CharLinkedList of size 2 <<ab>>]");
}

void one_char_insertOrder_after() {
    CharLinkedList list('a');
    list.insertInOrder('b');
    assert(list.toString() == "[CharLinkedList of size 2 <<ab>>]");
}

void one_char_insertOrder_same() {
    CharLinkedList list('a');
    list.insertInOrder('a');
    assert(list.toString() == "[CharLinkedList of size 2 <<aa>>]");
}

void multi_char_insertOrder_middle() {
    char arr[7] = {'a', 'b', 'c', 'd', 'f', 'g', 'h'};
    CharLinkedList list(arr, 7);
    list.insertInOrder('e');
    assert(list.toString() == "[CharLinkedList of size 8 <<abcdefgh>>]");
}

void multi_char_insertOrder_back() {
    char arr[7] = {'a', 'b', 'c', 'd', 'e', 'f', 'g'};
    CharLinkedList list(arr, 7);
    list.insertInOrder('h');
    assert(list.toString() == "[CharLinkedList of size 8 <<abcdefgh>>]");
}

void multi_char_insertOrder_front() {
    char arr[7] = {'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList list(arr, 7);
    list.insertInOrder('a');
    assert(list.toString() == "[CharLinkedList of size 8 <<abcdefgh>>]");
}

void empty_remove_error() {
    CharLinkedList list;
    bool range_error_thrown = false;

    std::string error_message = "";

    try {
        list.removeAt(0);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (0) not in range [0..0)");
}

void empty_remove_error_2() {
    CharLinkedList list;
    bool range_error_thrown = false;

    std::string error_message = "";

    try {
        list.removeAt(1);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (1) not in range [0..0)");
}

void one_char_remove() {
    CharLinkedList list('a');
    list.removeAt(0);
    assert(list.isEmpty());
}

void multi_char_remove_front() {
    char arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList list(arr, 8);
    list.removeAt(0);
    assert(list.toString() == "[CharLinkedList of size 7 <<bcdefgh>>]");
}

void multi_char_remove_middle() {
    char arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList list(arr, 8);
    list.removeAt(4);
    assert(list.toString() == "[CharLinkedList of size 7 <<abcdfgh>>]");
}

void multi_char_remove_back() {
    char arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList list(arr, 8);
    list.removeAt(7);
    assert(list.toString() == "[CharLinkedList of size 7 <<abcdefg>>]");
}

void multi_char_remove_middle_twice() {
    char arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList list(arr, 8);
    list.removeAt(4);
    list.removeAt(3);
    assert(list.toString() == "[CharLinkedList of size 6 <<abcfgh>>]");
}

void empty_copy() {
    CharLinkedList list;
    CharLinkedList copy = list;
    assert(copy.isEmpty());
}

void one_char_copy() {
    CharLinkedList list('a');
    CharLinkedList copy = list;
    assert(copy.first() == 'a');
}

void multi_char_copy() {
    char arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList list(arr, 8);
    CharLinkedList copy = list;
    assert(list.toString() == "[CharLinkedList of size 8 <<abcdefgh>>]");
}

void empty_concat_empty() {
    CharLinkedList list;
    CharLinkedList other;
    list.concatenate(&other);
    assert(list.isEmpty());
}

void empty_concat_one_char() {
    CharLinkedList list;
    CharLinkedList other('a');
    list.concatenate(&other);
    assert(list.toString() == "[CharLinkedList of size 1 <<a>>]");
}

void one_char_concat_empty() {
    CharLinkedList list('a');
    CharLinkedList other;
    list.concatenate(&other);
    assert(list.toString() == "[CharLinkedList of size 1 <<a>>]");
}

void empty_concat_self() {
    CharLinkedList list;
    list.concatenate(&list);
    assert(list.isEmpty());
}

void one_char_concat_self() {
    CharLinkedList list('a');
    list.concatenate(&list);
    assert(list.toString() == "[CharLinkedList of size 2 <<aa>>]");
}

void concatenate_test5() {
    char arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList list(arr, 8);
    CharLinkedList other;
    list.concatenate(&other);
    assert(list.toString() == "[CharLinkedList of size 8 <<abcdefgh>>]");
}

void empty_concat_multi_char() {
    CharLinkedList list;
    char arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList other(arr, 8);
    list.concatenate(&other);
    assert(list.toString() == "[CharLinkedList of size 8 <<abcdefgh>>]");
}

void multi_char_concat_multi_char() {
    char arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList list(arr, 8);
    CharLinkedList other(arr, 8);
    list.concatenate(&other);
    assert(list.toString() ==
    "[CharLinkedList of size 16 <<abcdefghabcdefgh>>]");
}

void multi_char_concat_self() {
    char arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList list(arr, 8);
    list.concatenate(&list);
    assert(list.toString() ==
    "[CharLinkedList of size 16 <<abcdefghabcdefgh>>]");
}

void empty_eleAt_error() {
    CharLinkedList list;
    bool range_error_thrown = false;

    std::string error_message = "";

    try {
        list.elementAt(0);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (0) not in range [0..0)");
}

void one_char_eleAt() {
    CharLinkedList list('a');
    assert(list.elementAt(0) == 'a');
}

void multi_char_eleAt() {
    char arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList list(arr, 8);
    assert(list.elementAt(4) == 'e');
}
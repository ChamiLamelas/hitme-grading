/*
 *  CharLinkedList.cpp
 *  Jeffrey Li
 *  2/2/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Implement a doubly linked list data structure.
 *
 */

#include "CharLinkedList.h"
#include <sstream>
#include <string>

using namespace std;

//name: CharLinkedList
//purpose: default constructor
//arguments: none
//returns: none
//effects: front = nullptr, lsize = 0
CharLinkedList::CharLinkedList() {
    front = nullptr;
    lsize = 0;
}

//name: CharLinkedList
//purpose: one node constructor
//arguments: character
//returns: none
//effects: front = curr, lsize = 1
CharLinkedList::CharLinkedList(char c) {
    Node *curr = new Node();
    front = curr;
    curr->c = c;
    curr->next = nullptr;
    curr->prev = nullptr;
    lsize = 1;
}

//name: CharLinkedList
//purpose: multiple node constructor
//arguments: character array, size
//returns: none
//effects: front = curr, lsize = size
CharLinkedList::CharLinkedList(char arr[], int size) {
    front = nullptr;
    lsize = 0;
    for (int i = 0; i < size; i++) {
        pushAtBack(arr[i]);
    }
}

//name: CharLinkedList
//purpose: copy constructor
//arguments: dereferenced linked list
//returns: none
//effects: copies info of original list
CharLinkedList::CharLinkedList(const CharLinkedList &other) {
    lsize = 0;
    front = nullptr;
    for (int i = 0; i < other.size(); i++) {
        pushAtBack(other.elementAt(i));
    }
}

//name: CharLinkedList
//purpose: destructor
//arguments: none
//returns: none
//effects: all nodes deleted, lsize = 0
CharLinkedList::~CharLinkedList() {
    destroyList(front);
    lsize = 0;
}

//name: isEmpty
//purpose: checks if list has 0 nodes
//arguments: none
//returns: true or false
//effects: none
bool CharLinkedList::isEmpty() const {
    return lsize == 0;
}

//name: clear
//purpose: clears data in every node
//arguments: none
//returns: none
//effects: all data = '\0'
void CharLinkedList::clear() {
    Node *next = front;
    while (lsize > 0) {
        //"clear" node by setting c = '\0'
        next->c = '\0';
        lsize --;
        next = next->next;
    }
}

//name: size
//purpose: finds size of list
//arguments: none
//returns: size of list
//effects: none
int CharLinkedList::size() const {
    return lsize;
}

//name: first
//purpose: finds char in first node
//arguments: none
//returns: first char
//effects: none
char CharLinkedList::first() const {
    if (isEmpty()) {
        throw runtime_error("cannot get first of empty LinkedList");
    } else {
        return front->c;
    }
}

//name: last
//purpose: finds char in last node
//arguments: none
//returns: last char
//effects: none
char CharLinkedList::last() const {
    if (isEmpty()) {
        throw runtime_error("cannot get last of empty LinkedList");
    } else {
        Node *last = getLast(front);
        return last->c;
    }
}

//name: pushAtFront
//purpose: adds a node to the front of the list
//arguments: char to add
//returns: none
//effects: size ++, changes front pointer
void CharLinkedList::pushAtFront(char c) {
    Node *curr = new Node();
    curr->c = c;
    curr->next = front;
    curr->prev = nullptr;
    front = curr;
    lsize ++;
}

//name: pushAtBack
//purpose: adds a node to the end of the list
//arguments: char to add
//returns: none
//effects: size ++
void CharLinkedList::pushAtBack(char c) {
    Node *curr = new Node();
    curr->c = c;
    Node *last;
    curr->next = nullptr;
    //if list empty, just add
    if (front == nullptr) {
        front = curr;
        lsize ++;
        return;
    }
    last = getLast(front);
    last->next = curr;
    curr->prev = last;
    lsize ++;
}

//name: popFromFront
//purpose: removes the front node
//arguments: none
//returns: none
//effects: size --, changes front pointer
void CharLinkedList::popFromFront() {
    if (isEmpty()) {
        throw runtime_error("cannot pop from empty LinkedList");
    } else {
        //temp node to track old front
        Node *temp = front;
        //reassign front
        front = front->next;
        delete temp;
        lsize --;
    }
}

//name: popFromBack
//purpose: removes the last node
//arguments: none
//returns: none
//effects: size --
void CharLinkedList::popFromBack() {
    Node *last;
    Node *del;
    if (isEmpty()) {
        throw runtime_error("cannot pop from empty LinkedList");
    } else if (lsize == 1) {
        del = getLast(front);
        front = nullptr;
        delete del;
    } else {
        del = getLast(front);
        last = del->prev;
        //update last node
        last->next = nullptr;
        delete del;
    }
    lsize --;
}

//name: removeAt
//purpose: remove node at desired index
//arguments: index
//returns: none
//effects: size --
void CharLinkedList::removeAt(int index) {
    Node *del;
    Node *prev;
    if (index >= lsize or index < 0) {
        throw range_error("index (" + std::to_string(index) +
            ") not in range [0.." + std::to_string(lsize) + ")");
    } else {
        if (index == 0) {
            popFromFront();
        } else {
            //node to delete
            del = nodeAtIndex(index, front);
            prev = nodeAtIndex(index - 1, front);
            //point previous node to node after del
            prev->next = del->next;
            delete del;
            lsize --;
        }
    }
}

//name: elementAt
//purpose: finds element at desired index
//arguments: index
//returns: char at index
//effects: none
char CharLinkedList::elementAt(int index) const {
    if (index >= lsize or index < 0) {
        throw range_error("index (" + std::to_string(index) +
            ") not in range [0.." + std::to_string(lsize) + ")");
    } else {
        Node *curr = nodeAtIndex(index, front);
        return curr->c;
    }
}

//name: insertAt
//purpose: insert a node at desired index
//arguments: char, index
//returns: none
//effects: size ++
void CharLinkedList::insertAt(char c, int index) {
    Node *curr;
    Node *next;
    if (index > lsize or index < 0) {
        throw range_error("index (" + std::to_string(index) +
            ") not in range [0.." + std::to_string(lsize) + "]");
    } else {
        if (index == 0) {
            pushAtFront(c);
        } else {
            curr = new Node();
            curr->c = c;
            next = nodeAtIndex(index - 1, front);
            //sandwich curr in between index - 1th and original indexth node
            curr->next = next->next;
            next->next = curr;
            curr->prev = next;
            lsize ++;
        }
    }
}

//name: insertInOrder
//purpose: inserts char in alphabetical order
//arguments: char to add
//returns: none
//effects: size ++
void CharLinkedList::insertInOrder(char c) {
    if (isEmpty()) {
        pushAtBack(c);
    } else {
        //check for first char that c comes before
        for (int i = 0; i < lsize; i++) {
            if (c < elementAt(i)) {
                insertAt(c, i);
                return;
            }
        }
        pushAtBack(c);
    }
}

//name: toString
//purpose: turns elements in linked list into a string
//arguments: none
//returns: string form of list
//effects: none
std::string CharLinkedList::toString() const {
    Node *next = front;
    std::stringstream ss;
    ss << "[CharLinkedList of size " << lsize << " <<";
    if (isEmpty()) {
        ss << ">>]";
    } else {
        while (next->next != nullptr) {
            ss << next->c;
            next = next->next;
        }
        ss << next->c << ">>]";
    }
    return ss.str();
}

//name: toReverseString
//purpose: turns elements in linked list into a backwards string
//arguments: none
//returns: backwards string form of list
//effects: none
std::string CharLinkedList::toReverseString() const {
    Node *last;
    std::stringstream ss;
    ss << "[CharLinkedList of size " << lsize << " <<";
    if (isEmpty()) {
        ss << ">>]";
    } else {
        last = getLast(front);
        //start from last node, print backwards
        while (last->prev != nullptr) {
            ss << last->c;
            last = last->prev;
        }
        ss << last->c << ">>]";
    }
    return ss.str();
}

//name: replaceAt
//purpose: replace an element at a desired node
//arguments: char, index
//returns: none
//effects: none
void CharLinkedList::replaceAt(char c, int index) {
    if (index >= lsize or index < 0) {
        throw range_error("index (" + std::to_string(index) +
            ") not in range [0.." + std::to_string(lsize) + ")");
    } else {
        Node *curr = nodeAtIndex(index, front);
        curr->c = c;
    }
}

//name: concatenate
//purpose: joins two lists, one after another
//arguments: pointer to another list
//returns: none
//effects: increases size
void CharLinkedList::concatenate(CharLinkedList *other) {
    //copy of size to prevent infinite loop when concatenating onto self
    int otherSize = other->size();
    for (int i = 0; i < otherSize; i++) {
        pushAtBack(other->elementAt(i));
    }
}

//name: operator=
//purpose: creates = operator for lists
//arguments: pointer to another list
//returns: pointer to copy of list
//effects: copies info of original list
CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other) {
    lsize = 0;
    front = nullptr;
    for (int i = 0; i < other.size(); i++) {
        pushAtBack(other.elementAt(i));
    }
    return *this;
}

//name: nodeAtIndex
//purpose: finds node at desired index
//arguments: index, pointer to node
//returns: pointer to found node
//effects: none
CharLinkedList::Node *CharLinkedList::nodeAtIndex(int index, Node *curr) const {
    if (index == 0) {
        return curr;
    } else {
        return nodeAtIndex(index - 1, curr->next);
    }
}

//name: destroyList
//purpose: deletes all items in list
//arguments: pointer to node
//returns: none
//effects: none
void CharLinkedList::destroyList(Node *front) {
    Node *next;
    if (front == nullptr) {
        return;
    } else {
        next = front;
        front = front->next;
        delete next;
        destroyList(front);
    }
}

//name: getLast
//purpose: finds last node in list
//arguments: pointer to node
//returns: pointer to last node in list
//effects: none
CharLinkedList::Node *CharLinkedList::getLast(Node *curr) const {
    if (curr->next == nullptr) {
        return curr;
    } else {
        return getLast(curr->next);
    }
}
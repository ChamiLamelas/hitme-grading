/*
 *  unit_tests.h
 *  Victor Anavian
 *  2/4/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  A file of all tests and function calls from our interface meant to test
 * code in small incraments called units.
 *
 */
#include "CharLinkedList.h"
#include <cassert>
#include <string>

// ------------------------------ constructor tests----------------
// test constructing an empty list
void constructor1_test(){
    CharLinkedList mylist;
}
// test constructor for a single element
void constructor2_test(){
    CharLinkedList mylist('a');
    assert(mylist.size() == 1);
}

// test constructor given array
void constructor3_test(){
    char test_word[6] = { 'a', 'b', 'c', 'd', 'e', 'f' };
    CharLinkedList mylist(test_word, 6);
    assert(mylist.size() == 6);
    assert(mylist.first() == 'a');
    assert(mylist.last() == 'f');
    assert(mylist.toString() == "[CharLinkedList of size 6 <<abcdef>>]");
}
// test copy constructor given a different full AL
void copy_constructor_test1(){
    char test_word[6] = { 'a', 'b', 'c', 'd', 'e', 'f' };
    CharLinkedList mylist1(test_word,6);
    CharLinkedList mylist2(mylist1);
    assert(mylist2.size() == 6);
    assert(mylist2.first() == 'a');
    assert(mylist2.last() == 'f');
    assert(mylist2.toString() == "[CharLinkedList of size 6 <<abcdef>>]");
}

// test copy constructor given an empty list
void copy_constructor_test2(){
    CharLinkedList mylist1;
    CharLinkedList mylist2(mylist1);
    assert(mylist2.size() == 0);
    assert(mylist2.toString() == "[CharLinkedList of size 0 <<>>]");
}

// use operator to change empty list into a full one
void overload_assignment_test1(){
    CharLinkedList mylist;
    char test_word[6] = { 'a', 'b', 'c', 'd', 'e', 'f' };
    CharLinkedList mylist2(test_word,6);
    mylist = mylist2;
    assert(mylist.size() == 6);
    assert(mylist.first() == 'a');
    assert(mylist.last() == 'f');
}
// use operator to change full list into an empty one
void overload_assignment_test2(){
    bool range_error_thrown = false;
    CharLinkedList mylist;
    char test_word[6] = { 'a', 'b', 'c', 'd', 'e', 'f' };
    CharLinkedList mylist2(test_word,6);
    mylist2 = mylist;
    assert(mylist2.size() == 0);
    try
    {
        mylist2.elementAt(0);
    }
    catch(const std::range_error& e)
    {
        std::cerr << e.what() << '\n';
        range_error_thrown = true;
    }
    assert(range_error_thrown);
    assert(mylist2.toString() == "[CharLinkedList of size 0 <<>>]");
}

// test overload operator given 2 full LL
void overload_assignment_test3(){
    char test_word[6] = {'z', 'y', 'x', 'w' ,'v', 'u'};
    CharLinkedList mylist(test_word, 6);
    char test_word2[6] = { 'a', 'b', 'c', 'd', 'e', 'f' };
    CharLinkedList mylist2(test_word2,6);
    mylist = mylist2;
    assert(mylist.size() == 6);
    assert(mylist.first() == 'a');
    assert(mylist.last() == 'f');
    assert(mylist.toString() == "[CharLinkedList of size 6 <<abcdef>>]");
}

// Test assignment operator given the same thing
void overload_assignment_test4(){
    char test_word[6] = {'z', 'y', 'x', 'w' ,'v', 'u'};
    CharLinkedList mylist(test_word, 6);
    CharLinkedList mylist2(test_word, 6);
    mylist2 = mylist;
    assert(mylist.size() == 6);
    assert(mylist.first() == 'z');
    assert(mylist.last() == 'u');
    assert(mylist.toString() == "[CharLinkedList of size 6 <<zyxwvu>>]");
}

//---------------------------Size function tests------------------

// test size function when list is empty
void size_empty(){
    CharLinkedList mylist;
    assert(mylist.size() == 0);
}

//  test size function when theres 1 element
void size_1char(){
    CharLinkedList mylist('a');
    assert(mylist.size() == 1);
    mylist.popFromBack();
    assert(mylist.size() == 0);
}

// test size function with full list
void size_full_list(){
    char test_word[3] = {'a', 'b', 'c'};
    CharLinkedList mylist(test_word, 3);
    assert(mylist.size() == 3);
    assert(mylist.first() == 'a');
    assert(mylist.last() == 'c');
}
// ------------------------First function tests--------------------

// test First function with empty list
void First_empty(){
    CharLinkedList mylist;
    bool runtime_error_thrown = false;
    try
    {
        mylist.first();
    }
    catch(const std::runtime_error& e)
    {
        std::cerr << e.what() << '\n';
        runtime_error_thrown = true;
    }
    assert(runtime_error_thrown);
}

// test first function with 1 element list
void First_1char(){
    CharLinkedList mylist('a');
    assert(mylist.first() == 'a');
}

// test first function with full list
void First_full_list(){
    char test_word[3] = {'a', 'b', 'c'};
    CharLinkedList mylist(test_word, 3);
    assert(mylist.size() == 3);
    assert(mylist.first() == 'a');
    mylist.popFromFront();
    assert(mylist.first() == 'b');
}
// ------------------------------ Last function test -----------------

// test First function with empty list
void Last_empty(){
    CharLinkedList mylist;
    bool runtime_error_thrown = false;
    try
    {
        mylist.first();
    }
    catch(const std::runtime_error& e)
    {
        std::cerr << e.what() << '\n';
        runtime_error_thrown = true;
    }
    assert(runtime_error_thrown);
}

// test first function with 1 element list
void Last_1char(){
    CharLinkedList mylist('a');
    assert(mylist.last() == 'a');
}

// test first function with full list
void Last_Full_list(){
    char test_word[3] = {'a', 'b', 'c'};
    CharLinkedList mylist(test_word, 3);
    assert(mylist.size() == 3);
    assert(mylist.last() == 'c');
    mylist.popFromBack();
    assert(mylist.last() == 'b');
}
// ----------------------isEmpty function tests--------------------- -

// test if isempty works with empty list
void Empty_test_emptylist(){
    CharLinkedList mylist;
    assert(mylist.size() == 0);
    assert(mylist.isEmpty());
}

void Empty_test_full_list(){
    CharLinkedList mylist('a');
    bool full = true;
    assert(mylist.size() == 1);
    if (mylist.isEmpty())
    {
        full == false;
    }
    assert(full);
}

// ------------------------- element at function tests ---------------------
// check if element at throws error when checkin empty array
void elementAt_empty(){
    CharLinkedList mylist;
    bool range_error_thrown = false;
    try
    {
        mylist.elementAt(0);
    }
    catch(const std::range_error& e)
    {
        range_error_thrown = true;
        std::cerr << e.what() << '\n';
    }
    assert(range_error_thrown);
    
}

// check if element at throws error when our of scope of full list
void elementAt_1char_incorrect(){
    CharLinkedList mylist('a');
    bool range_error_thrown = false;
    try
    {
        mylist.elementAt(2);
    }
    catch(const std::range_error& e)
    {
        range_error_thrown = true;
        std::cerr << e.what() << '\n';
    }
    assert(range_error_thrown);
}

// make sure element at works with a 1 element list
void elementAt_1char_correct(){
    CharLinkedList mylist('a');
    assert(mylist.elementAt(0) == 'a');
}

//make sure function works with a full list
void elementAt_full_list(){
    char test_word[3] = {'a', 'b', 'c'};
    CharLinkedList mylist(test_word, 3);
    assert(mylist.elementAt(2) == 'c');
    assert(mylist.elementAt(0) == mylist.first());
}

//----------------------------- PushAtBack tests-----------------

// see if pushatback can work on an empty array
void pushAtBack_empty(){
    CharLinkedList mylist;
    mylist.pushAtBack('a');
    assert(mylist.size() == 1);
    assert(mylist.elementAt(0) == 'a');
    assert(mylist.toString() == "[CharLinkedList of size 1 <<a>>]");
}

// make sure that pushatback works on a single element
void pushAtBack_1char(){
    CharLinkedList mylist('a');
    mylist.pushAtBack('b');
    assert(mylist.size() == 2);
    assert(mylist.elementAt(1) == 'b');
    assert(mylist.toString() == "[CharLinkedList of size 2 <<ab>>]");
}

// make sure that pushatback works on full list
void pushAtBack_full_list(){
    char test_word[3] = {'a', 'b', 'c'};
    CharLinkedList mylist(test_word, 3);
    assert(mylist.size() == 3);
    mylist.pushAtBack('z');
    assert(mylist.last() == 'z');
    assert(mylist.size() == 4);
    assert(mylist.toString() == "[CharLinkedList of size 4 <<abcz>>]");
}

//----------------------------- PushAtFront tests-----------------
// see if pushatfront can work on an empty array
void pushAtFront_empty(){
    CharLinkedList mylist;
    mylist.pushAtFront('a');
    assert(mylist.size() == 1);
    assert(mylist.elementAt(0) == 'a');
    assert(mylist.toString() == "[CharLinkedList of size 1 <<a>>]");
}

// make sure that pushatfront works on a single element
void pushAtFront_1char(){
    CharLinkedList mylist('a');
    mylist.pushAtFront('b');
    assert(mylist.size() == 2);
    assert(mylist.elementAt(1) == 'a');
    assert(mylist.toString() == "[CharLinkedList of size 2 <<ba>>]");
}

// make sure that pushatfront works on full list
void pushAtFront_full_list(){
    char test_word[3] = {'a', 'b', 'c'};
    CharLinkedList mylist(test_word, 3);
    assert(mylist.size() == 3);
    mylist.pushAtFront('z');
    assert(mylist.first() == 'z');
    assert(mylist.size() == 4);
    assert(mylist.toString() == "[CharLinkedList of size 4 <<zabc>>]");
}

//-------------------------------Insert at tests---------------------------
// make sure that insertat works with an empty array
void insertAt_empty_correct() { 
    CharLinkedList test_list;
    test_list.insertAt('a', 0);
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');

}

// make sure that insert at throws an error from an empty array
void insertAt_empty_incorrect() {

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    // insertAt for out-of-range index
    test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
    // if insertAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    range_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0]");
    
}

// Tests correct insertAt for front of 1-element list.
void insertAt_front_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at front
    test_list.insertAt('b', 0);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'a');
    
}

// Tests correct insertAt for back of 1-element list.
void insertAt_back_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at back
    test_list.insertAt('b', 1);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    
}

// Tests calling insertAt for a large number of elements.
// Not only does this test insertAt, it also checks that
// array expansion works correctly.
void insertAt_many_elements() {
    
    CharLinkedList test_list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.insertAt('a', i);
    }

    assert(test_list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
    
}

// Tests insertion into front of a larger list
void insertAt_front_large_list() {
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    test_list.insertAt('y', 0);

    assert(test_list.size() == 10);
    assert(test_list.elementAt(0) == 'y');
    string message = "[CharLinkedList of size 10 <<yabczdefgh>>]";
    assert(test_list.toString() == message);

}

// Tests insertion into the back of a larger list
void insertAt_back_large_list() {

    char test_arr[10] = { 'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 10);  

    test_list.insertAt('x', 10);

    assert(test_list.size() == 11);
    assert(test_list.elementAt(10) == 'x');
    assert(test_list.toString() == 
    "[CharLinkedList of size 11 <<yabczdefghx>>]"); 

}

// Tests insertion into the middle of a larger list
void insertAt_middle_large_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.insertAt('z', 3);

    assert(test_list.size() == 9);
    assert(test_list.elementAt(3) == 'z');
    assert(test_list.toString() == "[CharLinkedList of size 9 <<abczdefgh>>]");

}

// Tests out-of-range insertion for a non-empty list.
void insertAt_nonempty_incorrect() {
   
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8]");
    
}
//----------------------tostring fucntion tests------------------------
//test if tostring works with an empty AL
void toString_test_empty_AL(){
    CharLinkedList mylist;
    assert(mylist.toString() == "[CharLinkedList of size 0 <<>>]");
}
// Thest is tostring works with a full AL
void toString_test_AL(){
    char test_word[6] = { 'a', 'b', 'c', 'd', 'e', 'f' };
    CharLinkedList mylist(test_word, 6);
    assert(mylist.toString() == "[CharLinkedList of size 6 <<abcdef>>]");
}

//-----------------------toReverseString function tests ----------------
// Test if function works with a full AL
void toReverseString_test_AL(){
    char test_word[6] = { 'a', 'b', 'c', 'd', 'e', 'f' };
    CharLinkedList mylist(test_word, 6);
    string message = "[CharLinkedList of size 6 <<fedcba>>]";
    assert(mylist.toReverseString() == message);
}
// test is toreverse string works with an empty AL
void toReverseString_test_empty_AL(){
    CharLinkedList mylist;
    assert(mylist.toString() == "[CharLinkedList of size 0 <<>>]");
}

//---------------------------- insertInOrder tests ----------------------

// see if first letter can change order
void insertInOrder_first_letter(){
    char test_word[6] = { 'g', 'b', 'c', 'd', 'e', 'f' };
    CharLinkedList mylist(test_word, 6);
    mylist.insertInOrder('a');
    assert(mylist.size() == 7);
    assert(mylist.toString() == "[CharLinkedList of size 7 <<agbcdef>>]");
}

// see if capital and lowercase letters are factored in when ordering
void insertInOrder_middle_letter(){
    char test_word[6] = { 'A', 'B', 'c', 'e', 'f', 'g' };
    CharLinkedList mylist(test_word, 6);
    mylist.insertInOrder('d');
    cout << mylist.toString() << endl;
    assert(mylist.toString() == "[CharLinkedList of size 7 <<ABcdefg>>]");
}

// see if function is able to add at the end
void insertInOrder_final_letter(){
    char test_word[6] = { 'a', 'b', 'C', 'D', 'e', 'f' };
    CharLinkedList mylist(test_word, 6);
    mylist.insertInOrder('q');
    assert(mylist.toString() == "[CharLinkedList of size 7 <<abCDefq>>]");
}

// check that function can insert into empty list
void insertInOrder_Empty_AL(){
    CharLinkedList mylist;
    mylist.insertInOrder('a');
    assert(mylist.size() == 1);
    assert(mylist.toString() == "[CharLinkedList of size 1 <<a>>]");
}

// see if capital is automatically put first
void insertInOrder_first_captial(){
    char test_word[6] = { 'a', 'B', 'c', 'd', 'E', 'f' };
    CharLinkedList mylist(test_word, 6);
    mylist.insertInOrder('V');
    assert(mylist.toString() == "[CharLinkedList of size 7 <<VaBcdEf>>]");
}

//see if captial letters get ordered
void insertInOrder_final_capital(){
    char test_word[6] = { 'A', 'B', 'C', 'D', 'E', 'F' };
    CharLinkedList mylist(test_word, 6);
    mylist.insertInOrder('K');
    assert(mylist.toString() == "[CharLinkedList of size 7 <<ABCDEFK>>]");
}

// check to make sure capital are before lowercase
void insertInOrder_middle_capital(){
    char test_word[6] = { 'A', 'B', 'c', 'e', 'E', 'F' };
    CharLinkedList mylist(test_word, 6);
    mylist.insertInOrder('F');
        cout << mylist.toString() << endl;
    assert(mylist.toString() == "[CharLinkedList of size 7 <<ABFceEF>>]");
}

// check to see if a capital can be inserted into an empty list
void insertInOrder_empty_AL_capital(){
    CharLinkedList mylist;
    mylist.insertInOrder('A');
    assert(mylist.size() == 1);
    assert(mylist.toString() == "[CharLinkedList of size 1 <<A>>]");
}

//------------------ popfrom front tests-----------------------------
//see if pop from front gives error when AL is empty
void popfromfront_empty_test(){
    CharLinkedList mylist;
    bool runtime_error_thrown = false;
    try{
        mylist.popFromFront();
    }
    catch(const std::runtime_error &e){
        std::cerr << e.what() << '\n';
        runtime_error_thrown = true;
    }
    assert(runtime_error_thrown);
}

// see if function will remove first element of existing AL
void popfromfront_large_test(){
    char test_word[6] = { 'a', 'b', 'c', 'd', 'e', 'f' };
    CharLinkedList mylist(test_word, 6);
    mylist.insertAt('g', 0);
    assert(mylist.size() == 7);
    assert(mylist.toString() == "[CharLinkedList of size 7 <<gabcdef>>]");
    mylist.popFromFront();
    assert(mylist.size() == 6);
    assert(mylist.toString() == "[CharLinkedList of size 6 <<abcdef>>]");
}

// see if popfrom front will be able to remove only element of list
void popFromFront_1char(){
    CharLinkedList mylist('a');
    assert(mylist.size() == 1);
    mylist.popFromFront();
    assert(mylist.size() == 0);
}

// ---------------------------popfromback tets---------------------
// see if function creates error when removing from empty AL
void popfromback_empty_test(){
    CharLinkedList mylist;
    bool runtime_error_thrown = false;
    try{
        mylist.popFromBack();
    }
    catch(const std::runtime_error &e){
        std::cerr << e.what() << '\n';
        runtime_error_thrown = true;
    }
    assert(runtime_error_thrown);
}

// make sure that function removes last element of AL
void popfromback_large_test(){
    char test_word[6] = { 'a', 'b', 'c', 'd', 'e', 'f' };
    CharLinkedList mylist(test_word, 6);
    mylist.insertAt('g', 0);
    assert(mylist.size() == 7);
    assert(mylist.toString() == "[CharLinkedList of size 7 <<gabcdef>>]");
    mylist.popFromBack();
    cout << "here" << endl;
    
    assert(mylist.size() == 6);
    cout << mylist.toString() << endl;
    assert(mylist.toString() == "[CharLinkedList of size 6 <<gabcde>>]");
}

// make sure that function can remove only element in list
void popFromBack_1char(){
    CharLinkedList mylist('a');
    assert(mylist.size() == 1);
    mylist.popFromBack();
    // cout << "here" << endl;
    cout << mylist.toString() << endl;
    assert(mylist.toString() == "[CharLinkedList of size 0 <<>>]");
    // cout << "ME TOO" << endl;
    assert(mylist.size() == 0);
}

//-----------------------------removeat tets----------------------------
// see if error is given when removing from empty list
void remove_out_of_range_empty_AL(){
    CharLinkedList mylist;
    bool range_error_thrown = false;
    try{
        mylist.removeAt(9);
    }
    catch(const std::range_error &e){
        std::cerr << e.what() << '\n';
        range_error_thrown = true;
    }
    assert(range_error_thrown);
}
// see if single element is removed correctly from small list
void remove_correct_small_AL(){
    CharLinkedList mylist('a');
    assert(mylist.size() == 1);
    mylist.removeAt(0);
    assert(mylist.size() == 0);
}
// see if element is removed correctly from larger list
void remove_correct_large_AL(){
    char test_word[6] = { 'a', 'b', 'c', 'd', 'e', 'f' };
    CharLinkedList mylist(test_word, 6);
    mylist.removeAt(3);
    assert(mylist.size() == 5);
    assert(mylist.toString() == "[CharLinkedList of size 5 <<abcef>>]");
}
// see if all elements can be removed with function
void remove_all_elements(){
    char test_word[6] = { 'a', 'b', 'c', 'd', 'e', 'f' };
    CharLinkedList mylist(test_word, 6);
    assert(mylist.size() == 6);
    int elements = mylist.size();
    for (int i = 0; i < elements; i++)
    {
        mylist.removeAt(0);
    }
    assert(mylist.size() == 0);
    assert(mylist.toString() == "[CharLinkedList of size 0 <<>>]");
}
// see if last element can be removed with function
void remove_last_element(){
    char test_word[6] = { 'a', 'b', 'c', 'd', 'e', 'f' };
    CharLinkedList mylist(test_word, 6);
    assert(mylist.size() == 6);
    mylist.removeAt(5);
    assert(mylist.size() == 5);
    assert(mylist.toString() == "[CharLinkedList of size 5 <<abcde>>]");
}
// see if error is given with out of range index
void remove_incorrect_large_AL(){
    char test_word[6] = { 'a', 'b', 'c', 'd', 'e', 'f' };
    CharLinkedList mylist(test_word, 6);
    assert(mylist.size() == 6);
    bool range_error_thrown = false;
    try
    {
        mylist.removeAt(6);
    }
    catch(const std::range_error& e)
    {
        std::cerr << e.what() << '\n';
        range_error_thrown = true;
    }
    assert(range_error_thrown);
}

// ----------------------------replaceat tests----------------------
// see if error is given when function is given out of range index
void replaceAt_incorrect_large_AL(){
    char test_word[6] = { 'a', 'b', 'c', 'd', 'e', 'f' };
    CharLinkedList mylist(test_word, 6);
    bool range_error_thrown = false;
    try{
        mylist.replaceAt('a', 9);
    }
    catch(const std::range_error &e){
        std::cerr << e.what() << '\n';
        range_error_thrown = true;
    }
    assert(range_error_thrown);
}

// see if error is given when removing from empty list
void replaceAt_incorrect_empty_array(){
    CharLinkedList mylist;
    bool range_error_thrown = false;
    try
    {
        mylist.replaceAt('a', 0);
    }
    catch(const std::range_error& e)
    {
        std::cerr << e.what() << '\n';
        range_error_thrown = true;
    }
    assert(range_error_thrown);
}

// see if function replaces element of single element list
void replaceAt_correct_small_AL(){
    CharLinkedList mylist('a');
    mylist.replaceAt('b', 0);
    assert(mylist.toString() == "[CharLinkedList of size 1 <<b>>]");
}

// see if error is given when going out of range of list
void replaceAt_last_element_incorrect(){
    CharLinkedList mylist('b');
    bool range_error_thrown = false;
    try
    {
        mylist.replaceAt('c', 1);
    }
    catch(const std::range_error& e)
    {
        std::cerr << e.what() << '\n';
        range_error_thrown = true;
    }
    assert(range_error_thrown);
}

// see if element is replaced in a larger list
void replaceAt_correct_large_AL(){
    char test_word[6] = { 'a', 'b', 'c', 'd', 'e', 'f' };
    CharLinkedList mylist(test_word, 6);
    mylist.replaceAt('z',4);
    assert(mylist.size() == 6);
    assert(mylist.toString() == "[CharLinkedList of size 6 <<abcdzf>>]");
}

// see if every element can be replaced
void replaceat_every_element(){
    char test_word[6] = { 'a', 'b', 'c', 'd', 'e', 'f' };
    CharLinkedList mylist(test_word, 6);
    for (int i = 0; i < mylist.size(); i++)
    {
        mylist.replaceAt('z',i);
        assert(mylist.elementAt(i) == 'z');
    }
    assert(mylist.toString() == "[CharLinkedList of size 6 <<zzzzzz>>]"); 
}
// ----------------------------clear tests----------------------------
// see if a full list can be cleared
void clear_full_AL(){
    char test_word[6] = { 'a', 'b', 'c', 'd', 'e', 'f' };
    CharLinkedList mylist(test_word, 6);
    mylist.clear();
    cout << "HELLO" << endl;
    assert(mylist.size() == 0);
}

// see if an empty list can be cleared
void clear_empty_AL(){
    CharLinkedList mylist;
    mylist.clear();
    assert(mylist.size() == 0);
}

// see if a cleared list can be reused like normal
void clear_AL_and_reuse(){
    char test_word[6] = { 'a', 'b', 'c', 'd', 'e', 'f' };
    CharLinkedList mylist(test_word, 6);
    mylist.clear();
    mylist.pushAtBack('a');
    assert(mylist.size() == 1);
    assert(mylist.toString() == "[CharLinkedList of size 1 <<a>>]");
}

// -------------------------concatenate tests-----------------------
// make sure 2 empty lists can be fused
void concatenate_empty_ALs(){
    CharLinkedList mylist;
    CharLinkedList mylist2;
    mylist.concatenate(&mylist2);
    assert(mylist.toString() == "[CharLinkedList of size 0 <<>>]");
}

// try to fuse full base with empty list
void concatenate_AL_empty_AL(){
    char test_word[6] = { 'a', 'B', 'c', 'd', 'E', 'f' };
    CharLinkedList mylist(test_word, 6);
    CharLinkedList mylist2;
    mylist.concatenate(&mylist2);
    assert(mylist.toString() == "[CharLinkedList of size 6 <<aBcdEf>>]");
}

// try to fuse empty base with full list
void concatenate_emptyAL_AL(){
    CharLinkedList mylist;
    char test_word[6] = { 'a', 'B', 'c', 'd', 'E', 'f' };
    CharLinkedList mylist2(test_word, 6);
    mylist.concatenate(&mylist2);
    assert(mylist.toString() == "[CharLinkedList of size 6 <<aBcdEf>>]");
}

// try to fuse two full lists
void concatenate_AL_capital_AL(){
    char test_word[6] = { 'a', 'b', 'c', 'd', 'e', 'f' };
    CharLinkedList mylist(test_word, 6);
    char test_word2[6] = { 'A', 'B', 'C', 'D', 'E', 'F' };
    CharLinkedList mylist2(test_word2, 6);
    mylist.concatenate(&mylist2);
    string message = "[CharLinkedList of size 12 <<abcdefABCDEF>>]";
    assert(mylist.toString() == message);
}

// try to fuse one list and one letter
void concatenate_AL_letter(){
    char test_word[6] = { 'A', 'b', 'C', 'D', 'e', 'F' };
    CharLinkedList mylist(test_word, 6);
    CharLinkedList mylist2('z');
    mylist.concatenate(&mylist2);
    assert(mylist.toString() == "[CharLinkedList of size 7 <<AbCDeFz>>]");
}



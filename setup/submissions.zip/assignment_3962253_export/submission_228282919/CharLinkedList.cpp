/*
 *  CharLinkedList.cpp
 *  Victor Anavian
 *  2/4/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  This file defines all of the functions for the .h interface and contains
    and code that makes all the functions work as intended. 
 *
 */

#include "CharLinkedList.h"
#include <string>
#include <iostream>

using namespace std;

// Name : CharLinkedList
// input: none
// output: none
// Description : Create an empty linked list with nothing
//
CharLinkedList::CharLinkedList(){
    front = nullptr;
    back = nullptr;
    num_elements = 0;
}
// Name : CharLinkedList
// input: data given by user
// output: none
// Description : Create a linked list from the given data that is 1 element
// large.
CharLinkedList::CharLinkedList(char c){
    Node *new_node = newNode(c, nullptr, nullptr);
    front = new_node;
    back = new_node;
    num_elements = 1;
}

// Name : CharLinkedList
// input: an array of characters that is data, the size of the list
// output: none
// Description : Create a list of specified size and fill it with the specified
// data.
CharLinkedList::CharLinkedList(char arr[], int size){
    Node *new_node = newNode(arr[0], nullptr, nullptr);
    front = new_node;
    back = new_node;
    num_elements = 1;
    for (int i = 1; i < size; i++)
    {
        pushAtBack(arr[i]);
    }
}

// Name : CharLinkedList
// input: Another instance of a linked list
// output: none
// Description : Create a new list from a given instance of a linked list
// and copy all of its data into our new list.
CharLinkedList::CharLinkedList(const CharLinkedList &other){
    front = nullptr;
    back = nullptr;
    num_elements = 0;
    Node *other_curr = other.front;
    for (int i = 0; i < other.num_elements; i++)
    {
        pushAtBack(other_curr->data);
        other_curr = other_curr->next_node;
    }
}

// Name : 
// input:
// output:
// Description : 
//
CharLinkedList::Node *CharLinkedList::newNode(char givenchar, Node *next, 
                                              Node *prev ){
    Node *new_node = new Node;
    new_node->next_node = next;
    new_node->prev_node = prev;
    new_node->data = givenchar;
    return new_node;
}

// Name : Overload assignment operator
// input: Another instance of a linked list
// output: none
// Description : assign the "=" symbol to be able to set two linked lists 
// equal to each other
CharLinkedList& CharLinkedList::operator=(const CharLinkedList &other){
    if (this == &other)
    {
        return *this;
    }
    clear();
    Node *other_curr = other.front;
    for (int i = 0; i < other.num_elements; i++)
    {
        pushAtBack(other_curr->data);
        other_curr = other_curr->next_node;
    }
    return *this;
}

// Name : ~CharLinkedList
// input: none
// output: none
// Description : Delete the current linked list
//
CharLinkedList::~CharLinkedList(){
    deconstruct_helper(front);
}

// Name : deconstruct_helper
// input: the front most node
// output: none
// Description :  Recursively delete all of the nodes in the list
//
void CharLinkedList::deconstruct_helper(Node* currnode){
    if (currnode == nullptr)
    {
        return;
    }else{
        Node *temp_node = currnode->next_node;
        delete currnode;
        deconstruct_helper(temp_node);
    } 
}

// Name : isEmpty
// input: none
// output: a boolean value 
// Description : Check if the list is empty or not and return a boolean value
//
bool CharLinkedList::isEmpty() const{
    if (num_elements == 0)
    {   
        return true;
    }else{  
        return false;
    }    
}

// Name : size
// input: none
// output: the number of elements in the list
// Description : return the number of elements there are in the list
//
int CharLinkedList::size() const{
    return num_elements;
}

// Name : first
// input: none
// output: the data that the first node is holding
// Description : Return the data that the first node is holding if the first
// node exists
char CharLinkedList::first() const{
    if (num_elements == 0)
    {
        throw runtime_error("cannot get first of empty LinkedList");
    }
    return front->data;
}

//Name : last
// input: none
// output: the data that the last node is holding
// Description : Return the data that the last node is holding if the last
// node exists 
//
char CharLinkedList::last() const{
    if (num_elements == 0)
    {
        throw runtime_error("cannot get last of empty LinkedList");
    }
    return back->data;
}

// Name : finder
// input: the index of the node wanted, an empty counter to count through the
// list, and the front node to start.
// output: The node at the given index
// Description : Recursively find the node that is wanted from the given
// index.
CharLinkedList::Node *CharLinkedList::finder(int index, int counter,
                                                Node *curr) const {
    if (index == counter)
    {
        return curr;
    }else{
        counter++;
        return finder(index, counter, curr->next_node);
    }
}

// Name : elementAt
// input: the index of the node that is wanted
// output: the data held by the wanted node
// Description : cycle through the list to find the node at the given index
// and return the data that the node contains.
char CharLinkedList::elementAt(int index) const{
    if (index < 0 or index >= num_elements)
    {
        string message = "index (";
        message += to_string(index);
        message += ") not in range [0..";
        message += to_string(num_elements);
        message += ")";
        throw range_error(message);
    }else{
        int Index_counter = 0;
        return finder(index, Index_counter, front)->data;
    }
}

// Name : toString
// input: none
// output: a string containing the message
// Description : print out a message and all the elements in the list in 
// sequential order as a string.
string CharLinkedList::toString() const{
    string all_data = "";
    string message = "[CharLinkedList of size ";
    message += to_string(num_elements);
    message += " <<";
    message += String_helper(all_data);
    message += ">>]";
    return message;
}

// Name : String_helper
// input: an empty string which to add onto
// output: a string with all the elements in order.
// Description : Help the toreversestring function by returning all the 
// elements of the list in string form
string CharLinkedList::String_helper(string all_data) const{
    Node* curr = front;
    while (curr != nullptr)
    {
        all_data += curr->data;
        curr = curr->next_node;
    }
    return all_data;
}
// Name : toReverseString
// input: none
// output: a string containing the message
// Description : print out a message and all the elements in the list in 
// reverse order as a string
string CharLinkedList::toReverseString() const{
    string all_data = "";
    string message = "[CharLinkedList of size ";
    message += to_string(num_elements);
    message += " <<";
    message += ReverseString_helper(all_data);
    message += ">>]";
    return message;
}
// Name : ReverseString_helper
// input: an empty string which to add
// output: a string with all the elemnts in reverse order.
// Description : Help the toreversestring function by returning all the 
// elements of the list in string form
string CharLinkedList::ReverseString_helper(string all_data) const{
    Node* curr = back;
    while (curr != nullptr)
    {
        all_data += curr->data;
        curr = curr->prev_node;
    }
    return all_data;
}
// Name : pushAtBack
// input: the given data : c
// output: none
// Description : createa a new node at the back of our list with "c". 
//
void CharLinkedList::pushAtBack(char c){
    if (back == nullptr)
    {
        Node *new_node = newNode(c, nullptr, nullptr);
        front = new_node;
        back = new_node;
        num_elements++;
    }else{
        Node *new_node = newNode(c, nullptr, back);
        back->next_node = new_node;
        num_elements++;
        back = new_node;
    }
}
// Name : pushAtFront
// input: the given data
// output: none
// Description : Create a new node at the front of our list with the given data
//
void CharLinkedList::pushAtFront(char c){
    if (front == nullptr)
    {
        Node *new_node = newNode(c, nullptr, nullptr);
        front = new_node;
        back = new_node;
        num_elements++;
    }else{
        Node *new_node = newNode(c, front, nullptr);
        front->prev_node = new_node;
        num_elements++;
        front = new_node;
    }
}
// Name : insertAt
// input: some data c and the index at which to insert it at
// output: none
// Description :  Insert the given data by creating a new node with the given
// data.
void CharLinkedList::insertAt(char c, int index){
    if (index < 0 or index > num_elements)
    {
        string message = "index (";
        message += to_string(index);
        message += ") not in range [0..";
        message += to_string(num_elements);
        message += "]";
        throw range_error(message);
    }else{
        if (index == 0)
        {
            pushAtFront(c);
        }else if (index == num_elements)
        {
            pushAtBack(c);
        }else{
            int counter = 0;
            Node *indexed_node = finder(index, counter, front);
            Node *new_node = newNode(c, indexed_node, indexed_node->prev_node);
            new_node->prev_node->next_node = new_node;
            new_node->next_node->prev_node = new_node;
            num_elements++;
        }
    }
}

// Name : insertOrder_helper
// input: The first node and the data given
// output: the index at which to insert
// Description : Find the index at which to insert the data.
//
int CharLinkedList::insertOrder_helper(Node* curr, char c){
    for (int i = 0; i < num_elements; i++)
    {
        if (c < curr->data)
        {
            return i;
        }
        curr = curr->next_node;
    }
    return num_elements;
}

// Name : insertInOrder
// input: a data value 
// output: none
// Description : Find the correct index in which the given data should fit into
// the list if it were to follow the ASCII index
void CharLinkedList::insertInOrder(char c){
    int index = 0;
    index = insertOrder_helper(front, c);
    insertAt(c, index);
}

// Name : popFromFront
// input: none
// output: none
// Description : Remove the first node from the front of the list
//
void CharLinkedList::popFromFront(){
    if (num_elements == 0)
    {
        throw runtime_error("cannot pop from empty LinkedList");
    }else{
        if (front == back)
        {
            delete back;
            num_elements--;
            front = nullptr;
            back = nullptr;
        }else{
            Node* temp_node = front->next_node;
            delete front;
            temp_node->prev_node = nullptr;
            front = temp_node;
            num_elements--;
        }
    }
}
// Name : popFromBack
// input: none
// output: none
// Description : Remove the last node from the back of the list 
void CharLinkedList::popFromBack(){
    if (num_elements == 0)
    {
        throw runtime_error("cannot pop from empty ArrayList");
    }else{
        if (front == back)
        {
            delete back;
            num_elements--;
            front = nullptr;
            back = nullptr;
        }else{
            Node* temp_node = back->prev_node;
            delete back;
            temp_node->next_node = nullptr;
            back = temp_node;
            num_elements--;
        }
    }
}
// Name : removeAT
// input: index of the node we are trying to remove
// output: none
// Description : Remove the node at the index given by the user. If the index
// is the front or back, we can use our previous functions.
void CharLinkedList::removeAt(int index){
    if (index < 0 or index >= num_elements)
    {
        string message = "index (";
        message += to_string(index);
        message += ") not in range [0..";
        message += to_string(num_elements);
        message += ")";
        throw range_error(message);
    }else{
        if (index == 0)
        {
            popFromFront();
        }else if (index == num_elements - 1)
        {
            popFromBack();
        }else{
            int counter = 0;
            Node *temp_node = finder(index, counter, front);
            temp_node->prev_node->next_node = temp_node->next_node;
            temp_node->next_node->prev_node = temp_node->prev_node;
            delete temp_node;
            num_elements--;
        }
    }
}

// Name : replaceAT
// input: data given my user, index of node
// output: none
// Description :  Replace the node at the index that is given by the user 
// with the data that is given by the user. We can use finder 
void CharLinkedList::replaceAt(char c, int index){
    if (index < 0 or index >= num_elements)
    {
        string message = "index (";
        message += to_string(index);
        message += ") not in range [0..";
        message += to_string(num_elements);
        message += ")";
        throw range_error(message);
    }else{
        int counter = 0;
        Node *temp_node = finder(index, counter, front);
        temp_node->data = c;
    }
}

// Name : clear
// input: none
// output: none
// Description : Clear the list of all nodes and get it ready to be used again
void CharLinkedList::clear(){
    deconstruct_helper(front);
    front = nullptr;
    back = nullptr;
    num_elements = 0;
}

// Name : concatenate
// input: Another instance of a linked list
// output: none
// Description : Add the elements of the given linked list and add it to an 
// existing one.
void CharLinkedList::concatenate(CharLinkedList *other){
    if (other->front != nullptr)
    {
        Node *other_curr = other->front;
        for (int i = 0; i < other->num_elements; i++)
        {
            pushAtBack(other_curr->data);
            other_curr = other_curr->next_node;
        }
    }
}

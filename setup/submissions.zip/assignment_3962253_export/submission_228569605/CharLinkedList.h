/*
 *  CharLinkedList.h
 *  Willa Andrade
 *  2/5/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  This program includes the interface for the CharLinkedList class, which
 *  allows users to access, add, and delete characters from a list. 
 *
 */

#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H

#include <string>
#include "stdexcept"

class CharLinkedList {
    public: 
        CharLinkedList();
        CharLinkedList(char c);
        CharLinkedList(char arr[], int size);
        CharLinkedList(const CharLinkedList &other);

        ~CharLinkedList();

        CharLinkedList &operator=(const CharLinkedList &other);

        bool isEmpty() const;
        void clear();
        int size() const;
        char first() const;
        char last() const;
        char elementAt(int index) const;
        std::string toString() const;
        std::string toReverseString() const;
        void pushAtBack(char c);
        void pushAtFront(char c);
        void insertAt(char c, int index);
        void insertInOrder(char c);
        void popFromFront();
        void popFromBack();
        void removeAt(int index);
        void replaceAt(char c, int index);
        void concatenate(CharLinkedList *other);

    private:
        struct Node {
            char      info;
            Node      *next;
            Node      *prev;
        };
    
        Node *front;
        Node *back;
        int mySize;
        Node *makeNextNode(Node *myPrev, char arr[], int size);
        void destruct(Node *curr_node);
        Node *findNodeFromFront(Node *curr_node, int index) const;
        Node *findNodeFromBack(Node *curr_node, int index) const;
        Node *findNode(int index) const;
        int findIndexAlphaOrder(int index, char c, Node *curr_node) const;
        void throwRangeError(int index, char endBracket) const;
};

#endif

/*
 *  unit_tests.h
 *  Willa Andrade
 *  2/5/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  Uses Matt Russell's unit_test framework to test the CharLinkedList class.
 *
 */
#include "CharLinkedList.h"
#include <cassert>

//tests that default constructor successfully creates a list object
void default_constructor(){
    CharLinkedList test_list;
}

//checks that info associated with empty list is correct after using
//default constructor
void default_constructor_info(){
    CharLinkedList test_list;
    std::string correct_output = "[CharLinkedList of size 0 <<>>]";
    assert(test_list.toString() == correct_output);
}

//checks that constructor & destructor work for one element list
void single_char_constructor(){
    CharLinkedList test_list('a');
}

//checks that constructor & destructor work on a medium size list
void char_arr_constructor(){
    char chars[10] = {'a','b','r','h','f','j','i','w','u','i'};
    CharLinkedList test_list(chars, 10);
}

//checks that the single char constructor correctly initializes one element, 
//the size, and the front and back pointers
void single_char_constructor_values(){
    CharLinkedList test_list('a');
    assert(test_list.first() == 'a');
    assert(test_list.last() == 'a');
    assert(test_list.size() == 1);
}

//checks that the char Linked constructor correctly initializes all elements, 
//the size, and the front and back pointers
void char_arr_constructor_values(){
    const int SIZE = 10;
    std::string str_size = std::to_string(SIZE);
    char chars[SIZE] = {'a','b','c','d','e','f','g','h','i','j'};
    CharLinkedList test_list(chars, SIZE);
    
    std::string correct = "[CharLinkedList of size " 
                            + str_size + " <<abcdefghij>>]";
    std::string result = test_list.toString();
    assert(result == correct);
    assert(test_list.first() == chars[0]);
    assert(test_list.last() == chars[SIZE - 1]);
}

//copy constructor
void copyConstr(){
    char arr[] = {'a', 'b', 'c'};
    CharLinkedList test_list(arr, 3);
    CharLinkedList copy_list(test_list);
}

//checks to make sure all member variables of the copy are equal to the 
//member variables of the original. 
void copyConstr_varCheck(){
    char arr[] = {'a', 'b', 'c'};
    CharLinkedList original_list(arr, 3);
    CharLinkedList copy_list(original_list);
    assert(copy_list.size() == original_list.size());
    for(int i = 0; i < original_list.size(); i++){
        assert(original_list.elementAt(i) == copy_list.elementAt(i));
    }
}

//checks to make sure a deep, rather than shallow, copy was made. 
void copyConstr_isDeepCopy(){
    char arr[] = {'a', 'b', 'c'};
    CharLinkedList original_list(arr, 3);
    CharLinkedList copy_list(original_list);
    copy_list.pushAtBack('s');
    assert(original_list.size() == 3);
}


//checks that size works on an empty list
void size_empty(){
    CharLinkedList test_list;
    assert(test_list.size() == 0);
}

//checks that size works on a singleton list
void size_singleton(){
    CharLinkedList test_list('a');
    assert(test_list.size() == 1);
}

//checks that size works on a medium list
void size_medium(){
    const int SIZE = 10;
    char chars[SIZE] = {'a','b','c','d','e','f','g','h','i','j'};
    CharLinkedList test_list(chars, SIZE);
    assert(test_list.size() == SIZE);
}

//checks that size works on a large list
void size_large(){
    CharLinkedList test_list;
    const int SIZE = 5000;
    for(int i = 0; i < SIZE; i++){
        test_list.pushAtBack('a');
    }
    assert(test_list.size() == SIZE);
}


//checks that first works on an empty list
void first_empty(){
    CharLinkedList test_list;
    bool error_thrown;
    std::string error_message; 
    std::string correct_message = "cannot get first of empty LinkedList";
    try{
        test_list.first();
    } catch (std::runtime_error &e){
        error_thrown = true;
        error_message = e.what();
    }
    assert(error_thrown);
    assert(error_message == correct_message);
}

//checks that first works on a singleton list
void first_singleton(){
    const char FIRST = 'a';
    CharLinkedList test_list(FIRST);
    assert(test_list.first() == FIRST);
}

//checks that first works on a medium list
void first_medium(){
    const int SIZE = 10;
    const char FIRST = 'a';
    char chars[SIZE] = {FIRST,'b','c','d','e','f','g','h','i','j'};
    CharLinkedList test_list(chars, SIZE);
    assert(test_list.first() == FIRST);
}

//checks that first works on a large list. 
void first_large(){
    const int SIZE = 5000;
    const char FIRST = 'a';
    CharLinkedList test_list(FIRST);
    for(int i = 0; i < SIZE ; i++){
        test_list.pushAtBack('b');
    }
    assert(test_list.first() == FIRST);
}


//checks that last works on an empty list
void last_empty(){
    CharLinkedList test_list;
    bool error_thrown;
    std::string error_message; 
    std::string correct_message = "cannot get last of empty LinkedList";
    try{
        test_list.last();
    } catch (std::runtime_error &e){
        error_thrown = true;
        error_message = e.what();
    }
    assert(error_thrown);
    assert(error_message == correct_message);
}

//checks that last works on a singleton list
void last_singleton(){
    const char LAST = 'a';
    CharLinkedList test_list(LAST);
    assert(test_list.last() == LAST);
}

//checks that last works on a medium list
void last_medium(){
    const int SIZE = 10;
    const char LAST = 'j';
    char chars[SIZE] = {'a','b','c','d','e','f','g','h','i', LAST};
    CharLinkedList test_list(chars, SIZE);
    assert(test_list.last() == LAST);
}

//checks that last works on a large list. 
void last_large(){
    const int SIZE = 5000;
    const char LAST = 'b';
    CharLinkedList test_list;
    for(int i = 0; i < SIZE ; i++){
        test_list.pushAtBack('a');
    }
    test_list.pushAtBack(LAST);
    assert(test_list.last() == LAST);
}


//checks that toString works on an empty list
void toString_empty(){
    CharLinkedList test_list;
    const std::string EXPECTED_RESULT = "[CharLinkedList of size 0 <<>>]";
    std::string result = test_list.toString();
    assert(result == EXPECTED_RESULT);
}

//checks that toString works on a singleton list
void toString_singleton(){
    CharLinkedList test_list('a');
    const std::string EXPECTED_RESULT = "[CharLinkedList of size 1 <<a>>]";
    std::string result = test_list.toString();
    assert(result == EXPECTED_RESULT);
}

//checks that toString works on a medium sized list
void toString_medium(){
    const int SIZE = 10;
    std::string str_size = std::to_string(SIZE);
    char chars[SIZE] = {'a','b','c','d','e','f','g','h','i','j'};
    CharLinkedList test_list(chars, SIZE);
    const std::string EXPECTED_RESULT = "[CharLinkedList of size " 
                                            + str_size +" <<abcdefghij>>]";
    std::string result = test_list.toString();
    assert(result == EXPECTED_RESULT);
}

//checks that toString works on a large list
void toString_large(){
    const int SIZE = 5000;
    std::string str_size = std::to_string(SIZE);
    CharLinkedList test_list;
    std::string str_a = "";
    for(int i = 0; i < SIZE; i++){
        test_list.pushAtBack('a');
        str_a += "a";
    }
    const std::string EXPECTED_RESULT = "[CharLinkedList of size " + str_size 
                                            + " <<" + str_a + ">>]";
    std::string result = test_list.toString();
    assert(result == EXPECTED_RESULT);
}

//test that the compiler is happy with pushAtBack being called on an empty list
void pushAtBack_canBeCalled(){
    CharLinkedList test_list;
    test_list.pushAtBack('a');
}

//test that pushAtBack succcessfully adds one node to an empty list
void pushAtBack_emptyList(){
    CharLinkedList test_list;
    test_list.pushAtBack('a');
    assert(test_list.size() == 1);
    assert(test_list.first() == 'a');
}

//test that pushAtBack adds one node to the back of a singleton list
void pushAtBack_singleton(){
    CharLinkedList test_list('a');
    test_list.pushAtBack('b');
    assert(test_list.size() == 2);
    assert(test_list.first() == 'a');
    assert(test_list.last() == 'b');
}

//test that pushAtBack adds one node to the back of a medium size list

void pushAtBack_medium(){
    const int SIZE = 10;
    char chars[SIZE] = {'a','b','c','d','e','f','g','h','i','j'};
    std::string result = "abcdefghijk";
    CharLinkedList test_list(chars, SIZE);
    test_list.pushAtBack('k');
    for(int i = 0; i < SIZE + 1; i++){
        assert(test_list.elementAt(i) == result[i]);
    }
}


//test that pushAtBack adds nodes to the back of a large list
void pushAtBack_large(){
    const int SIZE = 5000;
    CharLinkedList test_list; 
    for(int i = 0; i < SIZE - 1; i++){
        test_list.pushAtBack('a');
    }
    test_list.pushAtBack('b');
    assert(test_list.size() == SIZE);
    assert(test_list.first() == 'a');
    assert(test_list.last() == 'b');
}

//checks that isEmpty returns true with 0 element list
void isEmpty_emptyList(){
    CharLinkedList test_list;
    assert(test_list.isEmpty());
}

//checks that isEmpty returns false with singleton list
void isEmpty_singleton(){
    CharLinkedList test_list('a');
    assert(not(test_list.isEmpty()));
}

//checks that isEmpty returns false with 10 elements
void isEmpty_medium(){
    const int SIZE = 10;
    char chars[SIZE] = {'a','b','c','d','e','f','g','h','i','j'};
    CharLinkedList test_list(chars, SIZE);
    assert(not(test_list.isEmpty()));
}

//checks that isEmpty returns false with 5000 elements
void isEmpty_large(){
    const int SIZE = 5000;
    CharLinkedList test_list; 
    for(int i = 0; i < SIZE - 1; i++){
        test_list.pushAtBack('a');
    }
    assert(not(test_list.isEmpty()));
}


//checks that elementAt throws an error if index < 0
void elementAt_indexLessThanZero(){
    CharLinkedList test_list;
    bool error_thrown = false;
    std::string error_message;
    std::string expected_message = "index (-1) not in range [0..0)";
    try{
        test_list.elementAt(-1);
    }catch (std::range_error &e){
        error_thrown = true;
        error_message = e.what();
    }
    assert(error_thrown);
    assert(error_message == expected_message);
}

//checks that elementAt throws an error if index = 0 on empty list
void elementAt_indexZeroEmptyList(){
    CharLinkedList test_list;
    bool error_thrown = false;
    std::string error_message;
    std::string expected_message = "index (0) not in range [0..0)";
    try{
        test_list.elementAt(0);
    }catch (std::range_error &e){
        error_thrown = true;
        error_message = e.what();
    }
    assert(error_thrown);
    assert(error_message == expected_message);
}

//checks that elementAt throws an error if index = 1 on singleton list
void elementAt_indexOneSingleton(){
    CharLinkedList test_list('a');
    bool error_thrown = false;
    std::string error_message;
    std::string expected_message = "index (1) not in range [0..1)";
    try{
        test_list.elementAt(1);
    }catch (std::range_error &e){
        error_thrown = true;
        error_message = e.what();
    }
    assert(error_thrown);
    assert(error_message == expected_message);
}

//checks that elementAt throws an error if index = 10 on list of size 10
void elementAt_indexEqualsSize(){
    const int SIZE = 10;
    char chars[SIZE] = {'a','b','c','d','e','f','g','h','i','j'};
    CharLinkedList test_list(chars, SIZE);
    bool error_thrown = false;
    std::string error_message;
    std::string expected_message = "index (10) not in range [0..10)";
    try{
        test_list.elementAt(10);
    }catch (std::range_error &e){
        error_thrown = true;
        error_message = e.what();
    }
    assert(error_thrown);
    assert(error_message == expected_message);
}

//checks that elementAt throws an error if index = 10,000 on list of size 5000
void elementAt_indexGreaterThanSize(){
    const int SIZE = 5000;
    CharLinkedList test_list;
    for(int i = 0; i < SIZE; i++){
        test_list.pushAtBack('a');
    }
    bool error_thrown = false;
    std::string error_message;
    std::string expected_message = "index (10000) not in range [0..5000)";
    try{
        test_list.elementAt(10000);
    }catch (std::range_error &e){
        error_thrown = true;
        error_message = e.what();
    }
    assert(error_thrown);
    assert(error_message == expected_message);
}

//checks that elementAt returns correct value on singleton list
void elementAt_singleton(){
    CharLinkedList test_list('a');
    assert(test_list.elementAt(0) == 'a');
}
//checks that elementAt returns correct value at back of list os size 2
void elementAt_backOfListOfTwo(){
    char chars[2] = {'a', 'b'};
    CharLinkedList test_list(chars, 2);
    assert(test_list.elementAt(1) == 'b');
}

//checks that elementAt returns correct value at front of medium list
void elementAt_frontOfList(){
    const int SIZE = 10;
    char chars[SIZE] = {'a','b','c','d','e','f','g','h','i','j'};
    CharLinkedList test_list(chars, SIZE);
    assert(test_list.elementAt(0) == 'a');
}

//checks that elementAt returns correct value at back of medium list
void elementAt_backOfList(){
    const int SIZE = 10;
    char chars[SIZE] = {'a','b','c','d','e','f','g','h','i','j'};
    CharLinkedList test_list(chars, SIZE);
    assert(test_list.elementAt(SIZE - 1) == 'j');
}

//checks that elementAt returns correct value for middle of medium list
void elementAt_middleOfList(){
    const int SIZE = 10;
    char chars[SIZE] = {'a','b','c','d','e','f','g','h','i','j'};
    CharLinkedList test_list(chars, SIZE);
    assert(test_list.elementAt(5) == 'f');
}

//checks that elementAt returns correct value for front of large list
void elementAt_frontOfLarge(){
    const int SIZE = 5000;
    CharLinkedList test_list('a');
    for(int i = 0; i < SIZE - 1; i++){
        test_list.pushAtBack('b');
    }
    assert(test_list.elementAt(0) == 'a');
}

//checks that elementAt returns correct value for back of large list
void elementAt_backOfLarge(){
    const int SIZE = 5000;
    CharLinkedList test_list;
    for(int i = 0; i < SIZE - 1; i++){
        test_list.pushAtBack('b');
    }
    test_list.pushAtBack('c');
    assert(test_list.elementAt(SIZE - 1) == 'c');
}

//checks that elementAt returns correct value for middle of a large list
void elementAt_middleOfLarge(){
    const int SIZE = 5000;
    CharLinkedList test_list;
    for(int i = 0; i < SIZE / 2; i++){
        test_list.pushAtBack('b');
    }
    test_list.pushAtBack('c');
    for(int i = SIZE / 2; i < SIZE; i++){
        test_list.pushAtBack('b');
    }   
    assert(test_list.elementAt(SIZE / 2) == 'c');
}


//checks that clear can be called on an empty list
void clear_empty(){
    CharLinkedList test_list;
    test_list.clear();
    assert(test_list.size() == 0);
}

//checks that clear works when called on singleton list
void clear_singleton(){
    CharLinkedList test_list('a');
    test_list.clear();
    assert(test_list.isEmpty());
    bool error_thrown = false;
    try{
        test_list.first();
    } catch (std::runtime_error &e){
        error_thrown = true;
    }
    assert(error_thrown);
}

//checks that clear works when called on medium list
void clear_medium(){
    const int SIZE = 10;
    char chars[SIZE] = {'a','b','c','d','e','f','g','h','i','j'};
    CharLinkedList test_list(chars, SIZE);
    test_list.clear();
    assert(test_list.isEmpty());
    test_list.pushAtBack('z');
    assert(test_list.first() == 'z');
    assert(test_list.last() == 'z');
}

//checks that clear works when called on a large list
void clear_large(){
    const int SIZE = 5000;
    CharLinkedList test_list;
    for(int i = 0; i < SIZE; i++){
        test_list.pushAtBack('a');
    }
    test_list.clear();
    assert(test_list.isEmpty());
    test_list.pushAtBack('z');
    assert(test_list.first() == 'z');
    assert(test_list.last() == 'z');
}

//checks that toReverseString works on an empty list
void toReverseString_empty(){
    CharLinkedList test_list;
    const std::string EXPECTED_RESULT = "[CharLinkedList of size 0 <<>>]";
    std::string result = test_list.toReverseString();
    assert(result == EXPECTED_RESULT);
}

//checks that toReverseString works on a singleton list
void toReverseString_singleton(){
    CharLinkedList test_list('a');
    const std::string EXPECTED_RESULT = "[CharLinkedList of size 1 <<a>>]";
    std::string result = test_list.toReverseString();
    assert(result == EXPECTED_RESULT);
}

//checks that toReverseString works on a medium sized list
void toReverseString_medium(){
    const int SIZE = 10;
    std::string str_size = std::to_string(SIZE);
    char chars[SIZE] = {'a','b','c','d','e','f','g','h','i','j'};
    CharLinkedList test_list(chars, SIZE);
    const std::string EXPECTED_RESULT = "[CharLinkedList of size " 
                                            + str_size +" <<jihgfedcba>>]";
    std::string result = test_list.toReverseString();
    assert(result == EXPECTED_RESULT);
}

//checks that toReverseString works on a large list
void toReverseString_large(){
    const int SIZE = 5000;
    std::string str_size = std::to_string(SIZE);
    CharLinkedList test_list('b');
    std::string str_a = "b";
    for(int i = 0; i < SIZE - 1; i++){
        test_list.pushAtFront('a');
        str_a += "a";
    }
    const std::string EXPECTED_RESULT = "[CharLinkedList of size " + str_size 
                                            + " <<" + str_a + ">>]";
    std::string result = test_list.toReverseString();
    assert(result == EXPECTED_RESULT);
}


//test that the compiler is happy with pushAtFront being called on an empty list
void pushAtFront_canBeCalled(){
    CharLinkedList test_list;
    test_list.pushAtFront('a');
}

//test that pushAtFront succcessfully adds one node to an empty list
void pushAtFront_emptyList(){
    CharLinkedList test_list;
    test_list.pushAtFront('a');
    assert(test_list.size() == 1);
    assert(test_list.first() == 'a');
}

//test that pushAtFront adds one node to the front of a singleton list
void pushAtFront_singleton(){
    CharLinkedList test_list('b');
    test_list.pushAtFront('a');
    assert(test_list.size() == 2);
    assert(test_list.first() == 'a');
    assert(test_list.last() == 'b');
}

//test that pushAtFront adds one node to the front of a medium size list

void pushAtFront_medium(){
    const int SIZE = 10;
    char chars[SIZE] = {'a','b','c','d','e','f','g','h','i','j'};
    std::string result = "kabcdefghij";
    CharLinkedList test_list(chars, SIZE);
    test_list.pushAtFront('k');
    for(int i = 0; i < SIZE + 1; i++){
        assert(test_list.elementAt(i) == result[i]);
    }
}


//test that pushAtFront adds nodes to the front of a large list
void pushAtFront_large(){
    const int SIZE = 5000;
    CharLinkedList test_list; 
    for (int i = 0; i < SIZE - 1; i++){
        test_list.pushAtFront('b');
    }
    test_list.pushAtFront('a');
    assert(test_list.size() == SIZE);
    assert(test_list.first() == 'a');
    assert(test_list.last() == 'b');
}

//checks to make sure correct error is thrown when called on empty list
void popFromFront_emptyList(){
    CharLinkedList test_list;
    bool error_thrown = false;
    std::string error_message = "";
    std::string expected_message = "cannot pop from empty LinkedList";
    try{
        test_list.popFromFront();
    } catch (std::runtime_error &e){
        error_thrown = true;
        error_message = e.what();
    }
    assert(error_thrown);
    assert(error_message == expected_message);
}

//checks to make sure popFromFront can be called on singleton list
void popFromFront_singletonCall(){
    CharLinkedList test_list('a');
    test_list.popFromFront();
}

//checks that popFromFront reassigns front and back pointers correctly
void popFromFront_singletonReassignValues(){
    CharLinkedList test_list('a');
    test_list.popFromFront();
    bool inaccessible = false;
    try{
        test_list.first();
    } catch (std::runtime_error){
        inaccessible = true;
    }
    assert(inaccessible);
    assert(test_list.size() == 0);
    test_list.pushAtFront('b');
    assert(test_list.first() == 'b');
}

//checks that no pointers to elements lost after popFromFront
void popFromFront_medium(){
    char chars[10] = {'a','b','c','d','e','f','g','h','i','j'};
    CharLinkedList test_list(chars, 10);
    
    test_list.popFromFront();
    std::string char_result = "bcdefghij";
    std::string correct = "[CharLinkedList of size 9 <<" + char_result + ">>]";
    std::string result = test_list.toString();
    assert(result == correct);
    
    test_list.popFromFront();
    char_result = "cdefghij";
    correct = "[CharLinkedList of size 8 <<" + char_result + ">>]";
    result = test_list.toString();
    assert(result == correct);
    
    for(int i = 0; i < 8; i++){
        test_list.popFromFront();
    }
    char_result = "";
    correct = "[CharLinkedList of size 0 <<" + char_result + ">>]";
    result = test_list.toString();
    assert(result == correct);
}

//checks to make sure correct error is thrown when called on empty list
void popFromBack_emptyList(){
    CharLinkedList test_list;
    bool error_thrown = false;
    std::string error_message = "";
    std::string expected_message = "cannot pop from empty LinkedList";
    try{
        test_list.popFromBack();
    } catch (std::runtime_error &e){
        error_thrown = true;
        error_message = e.what();
    }
    assert(error_thrown);
    assert(error_message == expected_message);
}

//checks to make sure popFromBack can be called on singleton list
void popFromBack_singletonCall(){
    CharLinkedList test_list('a');
    test_list.popFromBack();
}

//checks that popFromBack reassigns front and back pointers correctly
void popFromBack_singletonReassignValues(){
    CharLinkedList test_list('a');
    test_list.popFromBack();
    bool inaccessible = false;
    try{
        test_list.first();
    } catch (std::runtime_error){
        inaccessible = true;
    }
    assert(inaccessible);
    assert(test_list.size() == 0);
    test_list.pushAtBack('b');
    assert(test_list.last() == 'b');
}

//checks that no pointers to elements lost after popFromBack
void popFromBack_medium(){
    char chars[10] = {'a','b','c','d','e','f','g','h','i','j'};
    CharLinkedList test_list(chars, 10);
    
    test_list.popFromBack();
    std::string char_result = "abcdefghi";
    std::string correct = "[CharLinkedList of size 9 <<" + char_result + ">>]";
    std::string result = test_list.toString();
    assert(result == correct);
    

    test_list.popFromBack();
    char_result = "abcdefgh";
    correct = "[CharLinkedList of size 8 <<" + char_result + ">>]";
    result = test_list.toString();
    assert(result == correct);
    
    for(int i = 0; i < 8; i++){
        test_list.popFromBack();
    }
    char_result = "";
    correct = "[CharLinkedList of size 0 <<" + char_result + ">>]";
    result = test_list.toString();
    assert(result == correct);
}


// Tests correct insertion into an empty AL.
// Afterwards, size should be 1 and element at index 0
// should be the element we inserted.
void insertAt_empty_correct() { 

    CharLinkedList test_list;
    test_list.insertAt('a', 0);
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');

}

// Tests incorrect insertion into an empty AL.
// Attempts to call insertAt for index larger than 0.
// This should result in an std::range_error being raised.
void insertAt_empty_incorrect() {

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    // insertAt for out-of-range index
    test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
    // if insertAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    range_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0]");
    
}

// Tests correct insertAt for front of 1-element list.
void insertAt_front_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at front
    test_list.insertAt('b', 0);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'a');
    
}

// Tests correct insertAt for back of 1-element list.
void insertAt_back_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at back
    test_list.insertAt('b', 1);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    
}

// Tests calling insertAt for a large number of elements.
// Not only does this test insertAt, it also checks that
// Linked expansion works correctly.
void insertAt_many_elements() {
    
    CharLinkedList test_list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.insertAt('a', i);
    }

    assert(test_list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
    
}

// Tests insertion into front of a larger list
void insertAt_front_large_list() {
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    test_list.insertAt('y', 0);

    assert(test_list.size() == 10);
    assert(test_list.elementAt(0) == 'y');
    assert(test_list.toString() == 
                                "[CharLinkedList of size 10 <<yabczdefgh>>]");

}

// Tests insertion into the back of a larger list
void insertAt_back_large_list() {

    char test_arr[10] = { 'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 10);  

    test_list.insertAt('x', 10);

    assert(test_list.size() == 11);
    assert(test_list.elementAt(10) == 'x');
    assert(test_list.toString() == 
    "[CharLinkedList of size 11 <<yabczdefghx>>]"); 

}

// Tests insertion into the middle of a larger list
void insertAt_middle_large_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);
    
    test_list.insertAt('z', 3);

    assert(test_list.size() == 9);
    assert(test_list.elementAt(3) == 'z');
    assert(test_list.toString() ==  "[CharLinkedList of size 9 <<abczdefgh>>]");

}

// Tests out-of-range insertion for a non-empty list.
void insertAt_nonempty_incorrect() {
   
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8]");
    
}

// Tests correct insertion into an empty Arr.
// Afterwards, size should be 1 and element at index 0
// should be the element we inserted.
void insertInOrder_empty_correct() { 
    CharLinkedList test_list;
    test_list.insertInOrder('a');
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');

}


// Tests correct insertAt for back of 1-element list.
void insertInOrder_back_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at front
    test_list.insertInOrder('b');

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    
}

// Tests correct insertAt for front of 1-element list.
void insertInOrder_front_singleton_list() {
    
    CharLinkedList test_list('b');

    test_list.insertInOrder('a');

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    
}

// Tests calling insertAt for a large number of elements.
void insertInOrder_many_elements() {
    std::string randletters = "figjerigwunerfjiaeypdfberipgehp";
    CharLinkedList test_list;
    for(int i = 0; i < randletters.length(); i++){
        test_list.pushAtBack(randletters[i]);
    }
    test_list.insertInOrder('x');
    test_list.insertInOrder('z');
    std::string xzAdded = "figjerigwunerfjiaexypdfberipgehpz";
    for(int i = 0; i < test_list.size(); i++){
        assert(test_list.elementAt(i) == xzAdded[i]);
    }
}


//Test if (correct) error is thrown on arr of size 0
void removeAt_emptyArr(){
    CharLinkedList test_list; 
    bool error_thrown = false;
    std::string error_msg;
    try{
        test_list.removeAt(0);
    }catch(std::range_error &e){
        error_thrown = true;
        error_msg = e.what();
    }
    assert(error_thrown);
    assert(error_msg == "index (0) not in range [0..0)");
}

//test if correct error is thrown on large Linkeds when index is negative
void removeAt_outOfBoundsNeg(){
    std::string randletters = "figjerigwunerfjiaeypdfberipgehp";
    CharLinkedList test_list;
    for(int i = 0; i < randletters.length(); i++){
        test_list.pushAtBack(randletters[i]);
    }
    bool error_thrown;
    std::string error_msg;
    try{
        test_list.removeAt(-1);
    }catch(std::range_error &e){
        error_thrown = true;
        error_msg = e.what();
    }
    assert(error_thrown);
    assert(error_msg == "index (-1) not in range [0..31)");
}

//test if correct error is thrown when index >= numItems
void removeAt_outOfBoundsPos(){
    std::string randletters = "figjerigwunerfjiaeypdfberipgehp";
    CharLinkedList test_list;
    for(int i = 0; i < randletters.length(); i++){
        test_list.pushAtBack(randletters[i]);
    }
    bool error_thrown;
    std::string error_msg;
    try{
        test_list.removeAt(50);
    }catch(std::range_error &e){
        error_thrown = true;
        error_msg = e.what();
    }
    assert(error_thrown);
    assert(error_msg == "index (50) not in range [0..31)");
}

//Expected behavior: once an element is removed, a different element can be
//pushed to that index
void removeAt_oneElemArr(){
    CharLinkedList test_list('a');
    assert(test_list.size() == 1);
    test_list.removeAt(0);
    assert(test_list.size() == 0);
    test_list.pushAtBack('b');
    assert(test_list.first() == 'b');
}

//test multiple calls, to the front, middle, and back of the Linked remove 
//the correct elements in large Linked
void removeAt_largeArr(){
    std::string alpha = "abcdefghijklmnopqrstuvwxyz";
    std::string lettersRemoved = "bcefghijkmnopqrstuvwxyz";
    CharLinkedList test_list;
    for(int i = 0; i < alpha.length(); i++){
        test_list.pushAtBack(alpha[i]);
    }
    test_list.removeAt(3);
    test_list.removeAt(10);
    test_list.removeAt(23);
    test_list.removeAt(0);
    for(int i = 0; i < test_list.size(); i++){
        assert(test_list.elementAt(i)== lettersRemoved[i]);
    }
}

//Test that making a deep copy of an empty arr d on an empty arr cresults 
//in c remaining empty, even when d is then added to
void equalsOperator_twoEmpty(){
    CharLinkedList copy;
    CharLinkedList original;
    copy = original;
    original.pushAtBack('a');
    assert(copy.size() == 0);
}

//Test that making a deep copy of an empty Linked results in the copy 
//also having size == 0, even when the other Linked is added to
void equalsOperator_turnEmpty(){
    char arr[3] = {'a','b','c'};
    CharLinkedList copy(arr, 3);
    CharLinkedList original;
    copy = original;
    original.pushAtBack('a');
    assert(copy.size() == 0);
}

//Test that making a deep copy of a 5 element Linked on a previously empty 
//Linked updates the size and numItems of the initially empty Linked
void equalsOperator_fill5(){
    char arr[5] = {'a','b','c','d','e'};
    CharLinkedList original(arr, 5);
    CharLinkedList copy;
    copy = original;
    original.clear();
    assert(copy.size() == 5);  
}

//Test that copies are always deep
void equalsOperator_isDeep(){
    char arr[5] = {'a','b','c','d','e'};
    CharLinkedList original(arr, 5);
    CharLinkedList copy;
    copy = original;
    original = copy;
    original.clear();
    assert(copy.size() == 5);
    assert(original.size() == 0);
}

//Expected behavior: throws a std::range error "index (0) not in range [0..0)"
void replaceAt_emptyArr(){
    CharLinkedList c; 
    bool error_thrown = false;
    std::string error_msg;
    try{
        c.replaceAt('a', 0);
    }catch(std::range_error &e){
        error_thrown = true;
        error_msg = e.what();
    }
    assert(error_thrown);
    assert(error_msg == "index (0) not in range [0..0)");
}

//Expected behavior: throws a std::range_error "index (-1) not in range [0..31)"
void replaceAt_outOfBoundsNeg(){
    std::string randletters = "figjerigwunerfjiaeypdfberipgehp";
    CharLinkedList c;
    for(int i = 0; i < randletters.length(); i++){
        c.pushAtBack(randletters[i]);
    }
    bool error_thrown;
    std::string error_msg;
    try{
        c.replaceAt('a', -1);
    }catch(std::range_error &e){
        error_thrown = true;
        error_msg = e.what();
    }
    assert(error_thrown);
    assert(error_msg == "index (-1) not in range [0..31)");
}

//Expected behavior: throws a std::range_error when index is greater than or 
//equal to size
void replaceAt_outOfBoundsPos(){
    std::string randletters = "figjerigwunerfjiaeypdfberipgehp";
    CharLinkedList c;
    for(int i = 0; i < randletters.length(); i++){
        c.pushAtBack(randletters[i]);
    }
    bool error_thrown;
   std::string error_msg;
    try{
        c.replaceAt('a', 50);
    }catch(std::range_error &e){
        error_thrown = true;
        error_msg = e.what();
    }
    assert(error_thrown);
    assert(error_msg == "index (50) not in range [0..31)");
}

//Test if correctly replaces element at index in arr of length 1
void replaceAt_oneElemArr(){
    CharLinkedList c('a');
    c.replaceAt('b', 0);
    assert(c.size() == 1);
    assert(c.first() == 'b');
}

//Test if correctly replaces element at index in large Linked
void replaceAt_largeArr(){
    std::string alpha = "abcdefghijklmnopqrstuvwxyz";
    std::string lettersReplaced = "zbcdefghijklmmopqrstuvwxya";
    CharLinkedList c;
    for(int i = 0; i < alpha.length(); i++){
        c.pushAtBack(alpha[i]);
    }
    c.replaceAt('z', 0);
    c.replaceAt('a', 25);
    c.replaceAt('m', 13);
    for(int i = 0; i < c.size(); i++){
        assert(c.elementAt(i)== lettersReplaced[i]);
    }
}


/* NOTE: The following tests are for private functions.
 *       They will cause errors unless the word "private:" on line 47 of
 *       CharLinkedList.h is commented out, so that unit_tests.h can access
 *       the functions.
 */
/*

// checks that findNodeFromFront works on a singleton list (it is not
// equipped to handle an empty list, because it is not necessary within its
// proper use)

void findNodeFromFront_singleton(){
    CharLinkedList test_list('a');
    CharLinkedList::Node *result = 
                            test_list.findNodeFromFront(test_list.front, 0);
    assert(result->info == 'a');
}

//checks that findNodeFromFront works on a medium size list
void findNodeFromFront_medium(){
    const int SIZE = 10;
    char chars[SIZE] = {'a','b','c','d','e','f','g','h','i','j'};
    CharLinkedList test_list(chars, SIZE);
    CharLinkedList::Node *front = 
                        test_list.findNodeFromFront(test_list.front, 0);
    CharLinkedList::Node *back = 
                        test_list.findNodeFromFront(test_list.front, SIZE - 1); 
    CharLinkedList::Node *middle = 
                        test_list.findNodeFromFront(test_list.front, SIZE / 2);
    assert(front->info == chars[0]);
    assert(back->info == chars[SIZE - 1]);
    assert(middle->info == chars[SIZE / 2]);                            
}

//checks that findNodeFromBack works on a singleton list (it is not
// equipped to handle an empty list, because it is not necessary within its
// proper use)
void findNodeFromBack_singleton(){
    CharLinkedList test_list('a');
    CharLinkedList::Node *result = 
                            test_list.findNodeFromBack(test_list.back, 0);
    assert(result->info == 'a');
}

//checks that findNodeFromBack works on a medium size list
void findNodeFromBack_medium(){
    const int SIZE = 10;
    char chars[SIZE] = {'a','b','c','d','e','f','g','h','i','j'};
    CharLinkedList test_list(chars, SIZE);
    CharLinkedList::Node *front = 
                    test_list.findNodeFromBack(test_list.back, SIZE - 1);
    CharLinkedList::Node *back = 
                    test_list.findNodeFromBack(test_list.back, 0); 
    CharLinkedList::Node *middle = 
                    test_list.findNodeFromBack(test_list.back, (SIZE / 2) - 1);
    assert(front->info == chars[0]);
    assert(back->info == chars[SIZE - 1]);
    assert(middle->info == chars[SIZE / 2]);                            
}

*/
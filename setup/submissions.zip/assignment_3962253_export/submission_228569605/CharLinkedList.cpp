/*
 *  CharLinkedList.cpp
 *  Willa Andrade
 *  2/5/2024
 *
 *  CS 15 HW 2 CharLinkedLists
 *
 *  This program provides the implementation for the CharLinkedList class. This 
 *  class creates a list of characters of variable size where users can access,
 *  add, and delete characters from the list. 
 *
 */

#include "CharLinkedList.h"

/* name: Default constructor
 * purpose: creates a new empty list.
 * arguments: none
 * returns: none
 * effects: sets front to be nullptr
 */
CharLinkedList::CharLinkedList(){
    front = nullptr;
    back = nullptr;
    mySize = 0;
}

/* name: Single character constructor
 * purpose: creates a list with a single element 
 * arguments: char to be added to list
 * returns: none
 * effects: sets front and back to point to the element added to the list
 */
CharLinkedList::CharLinkedList(char c){
    Node *new_node = new Node;
    new_node->info = c;
    new_node->next = nullptr;
    new_node->prev = nullptr;
    
    front = new_node;
    back = new_node;
    mySize = 1;
}

/* name: Character array constructor
 * purpose: creates a list of a specific size, and 
 *          fills list with elements from a provided array
 * arguments: Array of chars representing chars to be in list, in that order.
 *            Also, an integer representing the size of the array provided. 
 * returns: none
 * effects: sets front to point to the first item in the list, and back to point
 *          to the last item in the list
 */
CharLinkedList::CharLinkedList(char arr[], int size){
    if (size == 0){
        front = nullptr;
        back = nullptr;
        mySize = 0;
    } else {
        mySize = 1;
        Node *new_node = new Node;
        new_node->info = arr[0];
        new_node->prev = nullptr;
        new_node->next = makeNextNode(new_node, arr + 1, size - 1);
        front = new_node;
    }
}

/* name: Copy constructor
 * purpose: Creates a deep copy of a pre-existing list
 * arguments: address of pre-existing list to copy data from
 * returns: none
 * effects: creates a new, separate list that contains all the same elements as
 *          the first list
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other){
    front = nullptr;
    back = nullptr;
    mySize = 0;
    for(int i = 0; i < other.size(); i++){
        pushAtBack(other.elementAt(i));
    }
}

/* name: Destructor
 * purpose: deletes all memory associated with a CharLinkedList
 * arguments: none
 * returns: none
 * effects: trying to access memory freed by the destructor will cause 
 *          an invalid read error
 */
CharLinkedList::~CharLinkedList(){
    if(front != nullptr){
        destruct(front);
    }
}

/* name: Assignment operator
 * purpose: Recycles the storage associated with the instance on the left of the
 *          assignment and makes a deep copy of the instance on the right
 *          hand side into the instance on the left hand side.
 * arguments: the address of instance on the right hand side 
 * returns: none
 * effects: 
 */
CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other){
    clear();
    for(int i = 0; i < other.size(); i++){
        pushAtBack(other.elementAt(i));
    }
    return *this;
}

/* name: isEmpty
 * purpose: determines whether the list is empty
 * arguments: none
 * returns: bool value representing whether the list is empty
 */
bool CharLinkedList::isEmpty() const{
    return mySize == 0;
}

/* name: clear
 * purpose: makes the instance into an empty list
 * arguments: none
 * effects: all elements previously in list are deleted and inaccessible
 */
void CharLinkedList::clear(){
    if(not(isEmpty())){
        destruct(front);
        front = nullptr;
        back = nullptr;
        mySize = 0;
    }
}

/* name: size
 * purpose: calculates size (number of elements) of the list
 * returns: integer representing size
 */
int CharLinkedList::size() const{
    return mySize;
}

/* name: first
 * purpose: finds the first element in the list
 * returns: character at index 0 of list
 * effects: if called on empty list, throws a C++ std::runtime_error exception 
 *          with the message “cannot get first of empty LinkedList”
 */
char CharLinkedList::first() const{
    if(front != nullptr){
        return front->info;
    } else {
        throw std::runtime_error("cannot get first of empty LinkedList");
    }
}

/* name: last
 * purpose: finds the first element in the list
 * returns: character at index [size-1]
 * effects: if called on empty list, throws a C++ std::runtime_error exception 
 *          with the message “cannot get last of empty LinkedList”
 */
char CharLinkedList::last() const{
    if(back != nullptr){
        return back->info;
    } else {
        throw std::runtime_error("cannot get last of empty LinkedList");
    }
}

/* name: elementAt
 * purpose: finds the element at a provided index
 * arguments: index at which to find element (note: 0-based indexing)
 * returns: the character at that index
 * effects: If the index is out of range it throws a C++ std::range_error 
 *          exception with the message “index (IDX) not in range [0..SIZE)” 
 *          where IDX is the index that was given and SIZE is the size of the 
 *          linked list.
 */
char CharLinkedList::elementAt(int index) const{
    if((index >= mySize) or (index < 0)){
        throwRangeError(index, ')');
    }else{
        Node *result = findNode(index);
        return result->info;
    }
}

/* name: toString
 * purpose: converts list of characters into a string in the same order as the 
            list
 * returns: an std::string in the format: 
 *          [CharLinkedList of size 5 <<Alice>>]
 */
std::string CharLinkedList::toString() const{
    std::string fromList = "";
    Node *curr_node = front;
    while(curr_node != nullptr){
        fromList += curr_node->info;
        curr_node = curr_node->next;
    }
    std::string size = std::to_string(mySize);
    return "[CharLinkedList of size " + size + " <<" + fromList + ">>]";
}

/* name: toReverseString
 * purpose: converts list of characters into a string in reverse order
            of the list
 * returns: an std::string in the format:
 *          [CharLinkedList of size 5 <<ecilA>>]
 */
std::string CharLinkedList::toReverseString() const{
    std::string fromList = "";
    Node *curr_node = back;
    while (curr_node != nullptr){
        fromList += curr_node->info;
        curr_node = curr_node->prev;
    }
    std::string size = std::to_string(mySize);
    return "[CharLinkedList of size " + size + " <<" + fromList + ">>]";
}

/* name: pushAtBack
 * purpose: inserts the given new element after the end of the existing 
            elements of the list.
 * arguments: element (character) to be added to the list
 * effects: increases the size of the list by one
 */
void CharLinkedList::pushAtBack(char c){
    //regardless of whether the list is empty- make a new node, set its info, 
    //next, and prev, and reassign back to point to the new node
    Node *new_node = new Node;
    new_node->info = c;
    new_node->prev = back;
    new_node->next = nullptr;
    back = new_node;

    //if the list was empty, then also assign front to point to the new node.
    //otherwise, make (the node behind the new node)->next point to the new node
    if (isEmpty()){
        front = new_node;
    } else {
        new_node->prev->next = new_node;
    }
    
    mySize++;
}

/* name: pushAtFront
 * purpose: inserts the given new element before the first element of the 
            existing list
 * arguments: element (character) to be added to the list
 * effects: increases the size of the list by one
 */
void CharLinkedList::pushAtFront(char c){
    Node *new_node = new Node;
    new_node->info = c;
    new_node->next = front;
    new_node->prev = nullptr;
    front = new_node;

    if (isEmpty()) {
        back = new_node;
    } else {
        new_node->next->prev = new_node;
    }
    mySize++;
}

/* name: insertAt
 * purpose: inserts the new element at the specified index
 * arguments: element (character) to be added to the list, and an integer 
 *            representing the index at which to add the element. 
 *            Note: elements can be inserted at index [mySize], it will result
 *                  in the element being pushed at back. 
 * effects: increases the size of the list by one.
 *          if the index is out of range it throws a C++ std::range_error 
 *          exception.
 */
void CharLinkedList::insertAt(char c, int index){
    if(index > mySize or index < 0){
        throwRangeError(index, ']');
    } else if (index == 0){
        pushAtFront(c);
    } else if (index == mySize){
        pushAtBack(c);
    } else {
        Node *new_node = new Node;
        new_node->info = c;
        
        Node *myPrev = findNode(index)->prev;
        Node *myNext = findNode(index);
       
        myPrev->next = new_node;
        new_node->prev = myPrev;

        myNext->prev = new_node;
        new_node->next = myNext;

        mySize++;
    }
}

/* name: insertInOrder
 * purpose: given a char, inserts it into the list in ASCII order
 * arguments: character to be added to list
 * effects: increases the size of the list by one
 *          assumes the list is correctly sorted in ascending order
 */
void CharLinkedList::insertInOrder(char c){
    int index = findIndexAlphaOrder(0, c, front);
    insertAt(c, index);
}

/* name: popFromFront
 * purpose: removes the first element from the list
 * effects: decrements the size of the list by one. 
 *          if the list is empty it throws a C++ std::runtime_error exception 
 *          with the message “cannot pop from empty LinkedList”.
 */
void CharLinkedList::popFromFront(){
    if(isEmpty()){
        throw std::runtime_error("cannot pop from empty LinkedList");
    } else {
        Node *new_front = front->next;
        delete front;
        front = new_front;
    }
    mySize--;
}

/* name: popFromBack
 * purpose: removes the last element from list
 * effects: decrements the size of the list by one. 
 *          if the list is empty it throws a C++ std::runtime_error exception 
 *          with the message “cannot pop from empty LinkedList”.
 */
void CharLinkedList::popFromBack(){
    if (isEmpty()){
        throw std::runtime_error("cannot pop from empty LinkedList");
    } else {
        Node *new_back = back->prev;
        delete back;
        back = new_back;
        
    }
    if (mySize == 1){
        front = nullptr;
    } else {
        back->next = nullptr;
    }
    mySize--;
}

/* name: removeAt
 * purpose: removes the element at the specified index
 * arguments: index at which element should be removed
 * effects: decrements the size of the list by one.
 *          if the index is out of range it should throw a 
 *          C++ std::range_error exception.
 */
void CharLinkedList::removeAt(int index){
    if(index >= mySize or index < 0){
        throwRangeError(index, ')');
    } else if (index == 0){
        popFromFront();
    } else if (index == mySize - 1){
        popFromBack();
    } else {
        Node *toDelete = findNode(index);
        Node *myPrev = toDelete->prev;
        Node *myNext = toDelete->next;
        myPrev->next = myNext;
        myNext->prev = myPrev;
        delete toDelete;
        mySize--;
    }   
}
/* name: replaceAt
 * purpose: replaces the element at the specified index with the new element
 * arguments: character to replace the element at a specific index, and 
 *            an integer representing that index. 
 * effects: if the index is out of range it throws a 
 *          C++ std::range_error exception .
 */
void CharLinkedList::replaceAt(char c, int index){ 
    if (index >= mySize or index < 0){
        throwRangeError(index, ')');
    } else {
        findNode(index)->info = c;
    }

}

/* name: concatenate
 * purpose: adds a copy of the list pointed to by the parameter value to the 
 *          end of the list the function was called from
 * arguments: pointer to the list to copy values from
 * effects: increases the size of the list the function was called from by the 
 *          size of the list pointed to by the parameter value. 
 *          Note: parameter value can be a pointer to the same list the function
 *                was called from, in which case the values from the list are 
 *                copied: 
 *                ex: list containing {a, b, c} now contains {a, b, c, a, b, c}
 */
void CharLinkedList::concatenate(CharLinkedList *other){
    int otherSize = other->size();
    for(int i = 0; i < otherSize; i++){
        this->pushAtBack(other->elementAt(i));
    }
}

/* name: makeNextNode
 * purpose: helper function for char array constructor. 
            recursively adds elements (characters) to a list.
 * arguments: pointer to the previous element, array of chars representing 
 *            chars not yet added to list, and the size of that array   
 * returns: pointer to the element it just added to the list
 * effects: size gets incremented each time an element is added
 */
CharLinkedList::Node *CharLinkedList::makeNextNode(Node *myPrev, 
                                               char arr[], int size){
    if(size == 0){
        back = myPrev;
        return nullptr;
    } else {
        mySize++;
        Node *new_node = new Node;
        new_node->info = arr[0];
        new_node->prev = myPrev;
        new_node->next = makeNextNode(new_node, arr + 1, size - 1);
        return new_node;
    }
}

/* name: destruct
 * purpose: helper function for destructor. recursively deletes memory 
            associated with elements
 * arguments: pointer to an element from which to delete all following elements
              and itself.
 */
void CharLinkedList::destruct(Node *curr_node){
    if(curr_node->next != nullptr){
        destruct(curr_node->next);
    }
    delete curr_node;
}

/* name: findNode
 * purpose: finds a node in the list, given its index. 
 * arguments: the index of the node to find
 * returns: a pointer to node at given index
 */
CharLinkedList::Node *CharLinkedList::findNode(int index) const{
    Node *result;
    if(index < mySize / 2){
        result = findNodeFromFront(front, index);
    } else {
        result = findNodeFromBack(back, mySize - 1 - index);
    }
    return result;
}

/* name: findnodeFromFront
 * purpose: helper function for findNode. returns a pointer to an element in 
            the list at the provided index
 * arguments: a pointer from which to start looking, an integer amount of 
 *            elements away
 * returns: a pointer to the element at the provided index
 */
CharLinkedList::Node *CharLinkedList::findNodeFromFront(Node *curr_node,
                                                     int index) const{
    if(index == 0){
        return curr_node;
    }else{
        curr_node = curr_node->next;
        return findNodeFromFront(curr_node, index - 1);
    }
}

/* name: findnodeFromBack
 * purpose: helper function for findNode. traverses list until it finds the 
            node indicated by the index integer
 * arguments: a pointer from which to start looking, an integer amount of 
 *            elements away
 * returns: a pointer to the element at the provided index
 */
CharLinkedList::Node *CharLinkedList::findNodeFromBack(Node *curr_node,
                                                     int index) const{
    if(index == 0){
        return curr_node;
    }else{
        curr_node = curr_node->prev;
        return findNodeFromBack(curr_node, index - 1);
    }
}


/* name: findIndexAlphaOrder
 * purpose: helper function for insertAt. finds the index at which an element
            should be inserted to be in alphabetic order
 * arguments: integer index- should always be called with index = 0. character
 *            that will be added to list later. Pointer to the start of the list
 * returns: integer representing index at which the new node should be inserted
 *          as to be in alphabetical order
 */
int CharLinkedList::findIndexAlphaOrder(int index, char c, 
                                        CharLinkedList::Node *curr_node) const{
    if(curr_node == nullptr or curr_node->info >= c){
        return index;
    }
    return findIndexAlphaOrder(index + 1, c, curr_node->next);
}

/* name: throwRangeError
 * purpose: helper function, throws a range error with specific message
 * arguments: integer representing the index that was incorrectly accessed, char
 *            representing whether function that called this allows index 
 *            [mySIZE] to be accessed 
 * returns: none
 * effects: throws range error
 */
void CharLinkedList::throwRangeError(int index, char endBracket) const{
    std::string str_index = std::to_string(index);
    std::string str_size = std::to_string(mySize);
        
    throw std::range_error("index (" + str_index  
                            + ") not in range [0.." + str_size + endBracket);
}
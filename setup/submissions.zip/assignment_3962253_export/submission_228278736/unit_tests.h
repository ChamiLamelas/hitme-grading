/*
 *  unit_tests.h
 *  Will Kaminski
 *  2/6/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  The purpose of this file is to create tests which properly test for specific
 *       cases to test the fucntions I created in CharLinkedList.cpp for the
 *       linked list data structure.
 *
 */
// Allow for asserts
#include <cassert>
//Include the linked list implementation.
#include "CharLinkedList.h"

/*
 * name:      testDefaultConstructor
 * purpose:   Test default constructor to initialize a LinkedList
 * arguments: none
 * returns:   none
 * effects:   Initializes a new LinkedList
 */
void testDefaultConstructor() {
    //Create a LinkedList
    CharLinkedList list;
    //Check if it is empty and size is 0
    assert(list.isEmpty());
    assert(list.size() == 0);
}

/*
 * name:      testConstructorChar
 * purpose:   Test constructor to initialize a LinkedList with a char
 * arguments: none
 * returns:   none
 * effects:   Initializes a new LinkedList
 */
 void testConstructorChar() {
    //Create a list with one character
    CharLinkedList list('a');
    //Check the list not empty, check fucntions: first last size and elementat
    assert(not list.isEmpty());
    assert(list.size() == 1);
    assert(list.first() == 'a');
    assert(list.last() == 'a');
    assert(list.elementAt(0) == 'a');
}

/*
 * name:      testConstructorArray
 * purpose:   Test constructor to initialize a LinkedList with an array
 * arguments: none
 * returns:   none
 * effects:   Initializes a new LinkedList
 */
 void testConstructorArray() {
    //Create an array and create a list with the chars
    char arr[] = {'a', 'b', 'c', 'd'};
    CharLinkedList list(arr, 4);
    //Check all of the previous functions should be the proper outputs
    assert(not list.isEmpty());
    assert(list.size() == 4);
    assert(list.first() == 'a');
    assert(list.last() == 'd');
    assert(list.elementAt(2) == 'c');
}

/*
 * name:      testCopyConstructor
 * purpose:   Test constructor to initialize a LinkedList with a copy
 * arguments: none
 * returns:   none
 * effects:   Initializes a new LinkedList
 */
void testCopyConstructor() {
    //Create a list and check pushatback and then copy to another list
    CharLinkedList list1('a');
    list1.pushAtBack('b');
    list1.pushAtBack('c');

    CharLinkedList list2(list1);
    //Check that everything is equal
    assert(list1.size() == list2.size());
    assert(list1.first() == list2.first());
    assert(list1.last() == list2.last());
    assert(list1.elementAt(1) == list2.elementAt(1));
}

/*
 * name:      test_size_empty
 * purpose:   Test to see size when list empty
 * arguments: none
 * returns:   none
 * effects:   Initializes a new LinkedList and checks size
 */
 void test_size_empty() {
    //Create a list and check that size is none
    CharLinkedList test_list;
    assert(test_list.size() == 0);
}

/*
 * name:      test_size_nonempty
 * purpose:   Test to see size when list is not empty
 * arguments: none
 * returns:   none
 * effects:   Initializes a new LinkedList, adds a value, and checks size
 */
 void test_size_nonempty() {
    //Create a list with a char and check for proper size.
    CharLinkedList test_list('a');
    assert(test_list.size() == 1);
}

/*
 * name:      test_first_nonempty
 * purpose:   Test to get first value
 * arguments: none
 * returns:   none
 * effects:   Initializes a new LinkedList, adds a value, and calls for it
 */
 void test_first_nonempty() {
    //Create a list with a char and check if return correct first value
    CharLinkedList test_list('a');
    assert(test_list.first() == 'a');
}

/*
 * name:      test_last_nonempty
 * purpose:   Test to get last value
 * arguments: none
 * returns:   none
 * effects:   Initializes a new LinkedList, adds a value, and calls for it
 */
 void test_last_nonempty() {
    //Create a list with a char and call for the last char
    CharLinkedList test_list('a');
    assert(test_list.last() == 'a');
}

/*
 * name:      test_elementAt_valid_index
 * purpose:   Test to call for value at an index
 * arguments: none
 * returns:   none
 * effects:   Initializes a new LinkedList, adds a value, and calls for it
 */
 void test_elementAt_valid_index() {
    //Create a longer list and request a valid index
    CharLinkedList test_list("abcdef", 6);
    assert(test_list.elementAt(3) == 'd');
}

/*
 * name:      test_elementAt_invalid_index
 * purpose:   Test to call for value at an index that does not exist
 * arguments: none
 * returns:   none
 * effects:   Initializes a new LinkedList and calls for value
 */
 void test_elementAt_invalid_index() {
    //Create a longer list and create a true false for the assert
    CharLinkedList test_list("abcdef", 6);
    bool error_thrown = false;
    //Try to get an error and if so instead of reporting it change the var value
    try {
        test_list.elementAt(10); // Index out of range
    } catch (const std::range_error& e) {
        error_thrown = true;
    }
    assert(error_thrown);
}

/*
 * name:      test_concatenate
 * purpose:   Test to concatenate two LinkedLists
 * arguments: none
 * returns:   none
 * effects:   Initializes 2 new LinkedLists and merge them
 */
 void test_concatenate() {
    //Create two lists and merge them
    CharLinkedList list1("abc", 3);
    CharLinkedList list2("def", 3);
    list1.concatenate(&list2);
    //Check if lists are equal
    assert(list1.size() == 6);
    assert(list1.toString() == "[CharLinkedList of size 6 <<abcdef>>]");
}

/*
 * name:      test_pushAtBack
 * purpose:   Test to add value to back
 * arguments: none
 * returns:   none
 * effects:   Initializes a LinkedList and add value to back
 */
void test_pushAtBack() {
    //Create a list and push a value to the back
    CharLinkedList test_list;
    test_list.pushAtBack('a');
    //Test if proper results are true
    assert(test_list.size() == 1);
    assert(test_list.last() == 'a');
    //Add another char and check again
    test_list.pushAtBack('b');
    assert(test_list.size() == 2);
    assert(test_list.last() == 'b');
}

/*
 * name:      test_pushAtFront
 * purpose:   Test to add value to front
 * arguments: none
 * returns:   none
 * effects:   Initializes a LinkedList and add value to front
 */
void test_pushAtFront() {
    //Create a list and push a value to the front
    CharLinkedList test_list;
    test_list.pushAtFront('a');
    //Test if proper results are true
    assert(test_list.size() == 1);
    assert(test_list.first() == 'a');
    //Add another char and check again
    test_list.pushAtFront('b');
    assert(test_list.size() == 2);
    assert(test_list.first() == 'b');
}

/*
 * name:      test_popFromFront
 * purpose:   Test to remove value from front
 * arguments: none
 * returns:   none
 * effects:   Initializes a LinkedList and removes value from front
 */
 void test_popFromFront() {
    //Create a list and remove from front
    CharLinkedList test_list("abc", 3);
    test_list.popFromFront();
    //Check for proper size and first letter.
    assert(test_list.size() == 2);
    assert(test_list.first() == 'b');
    //Repeat this twice until list is empty to also check the empty list case
    test_list.popFromFront();
    assert(test_list.size() == 1);
    assert(test_list.first() == 'c');

    test_list.popFromFront();
    assert(test_list.size() == 0);
    //Create another error variable
    bool error_thrown = false;
    //Try to remove from empty list to test for error and if so catch it
    try {
        test_list.popFromFront(); // Should throw error
    } catch (const std::runtime_error& e) {
        error_thrown = true;
    }
    assert(error_thrown);
}

/*
 * name:      test_popFromBack
 * purpose:   Test to remove value from back
 * arguments: none
 * returns:   none
 * effects:   Initializes a LinkedList and removes value from back
 */
 void test_popFromBack() {
    //Create a list and remove from back
    CharLinkedList test_list("abc", 3);
    test_list.popFromBack();
    //Check for proper size and last letter.
    assert(test_list.size() == 2);
    assert(test_list.last() == 'b');
     //Repeat this twice until list is empty to also check the empty list case
    test_list.popFromBack();
    assert(test_list.size() == 1);
    assert(test_list.last() == 'a');

    test_list.popFromBack();
    assert(test_list.size() == 0);
    //Create another error variable
    bool error_thrown = false;
    //Try to remove from empty list to test for error and if so catch it
    try {
        test_list.popFromBack(); // Should throw error
    } catch (const std::runtime_error& e) {
        error_thrown = true;
    }
    assert(error_thrown);
}

/*
 * name:      test_removeAt
 * purpose:   Test to remove certain value
 * arguments: none
 * returns:   none
 * effects:   Initializes a LinkedList and removes a certain value
 */
 void test_removeAt() {
    //Create a list and remove from random index
    CharLinkedList test_list("abcdef", 6);
    test_list.removeAt(2);
    //Check for proper size and last letter.
    assert(test_list.size() == 5);
    assert(test_list.elementAt(2) == 'd');
    //Repeat this twice until list is empty to also check the empty list case
    test_list.removeAt(0);
    assert(test_list.size() == 4);
    assert(test_list.elementAt(0) == 'b');

    test_list.removeAt(3);
    assert(test_list.size() == 3);
    assert(test_list.elementAt(2) == 'e');
    //Create another error variable
    bool error_thrown = false;
    //Try to remove from empty list to test for error and if so catch it
    try {
        test_list.removeAt(5); // Index out of range
    } catch (const std::range_error& e) {
        error_thrown = true;
    }
    assert(error_thrown);
}
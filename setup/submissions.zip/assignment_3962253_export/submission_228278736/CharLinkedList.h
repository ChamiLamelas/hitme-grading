/*
 *  CharLinkedList.h
 *  Will Kaminski
 *  2/6/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  The purpose of this file is to create a skeleton of definitions for the
 *       private and public variables and functions needed go create the linked
 *       list data structure.
 *
 */

#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H

//Inlcude proper packages to use std and throw errors.
#include <iostream>
using namespace std;

class CharLinkedList {
    private:
    //The basic node buildign block for the LinkedList.
        struct Node 
        {
            //The actual character
            char data;
            //The next and previous node
            Node* next;
            Node* prev;
            //A function inside of the struct to create a new node.
            //I put it in the struct so it is easy to call.
            Node(char value)
            {
                //Initialize values
                data = value;
                next = nullptr;
                prev = nullptr; 
            }
        };
        //Create a front, back, and size to the LinkedList.
        Node* head;
        Node* tail;
        int listSize;

        //Private recursive functions to help with clear, element at, and
        //      replace at.
        void clearRec(Node* node);
        char elementAtRec(Node* node, int index) const;
        void replaceAtRec(Node* node, char c, int index);

    public:
    //The four constructors and one destructor
        CharLinkedList();
        CharLinkedList(char c);
        CharLinkedList(char arr[], int size);
        CharLinkedList(const CharLinkedList &other);
        ~CharLinkedList();
        //Overloaded assignment operator
        CharLinkedList &operator=(const CharLinkedList &other);
        //The public functions needed for a LinkedList
        bool isEmpty() const;
        void clear();
        int size() const;
        char first() const;
        char last() const;
        char elementAt(int index) const;
        std::string toString() const;
        std::string toReverseString() const;
        void pushAtBack(char c);
        void pushAtFront(char c);
        void insertAt(char c, int index);
        void insertInOrder(char c);
        void popFromFront();
        void popFromBack();
        void removeAt(int index);
        void replaceAt(char c, int index);
        void concatenate(CharLinkedList *other);
};

#endif

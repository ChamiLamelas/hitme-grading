/*
 *  CharLinkedList.cpp
 *  Will Kaminski
 *  2/6/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  The purpose of this file is to properly implement the required public
 *      functions for a LinkedList data structure.
 *
 */

#include "CharLinkedList.h"

/*
 * name:      CharLinkedList
 * purpose:   Default constructor to create a LinkedList object
 * arguments: none
 * returns:   none
 * effects:   Creates a LinkedList and initializes proper values
 */
CharLinkedList::CharLinkedList() {
    //Initialize values
    head = nullptr;
    tail = nullptr;
    listSize = 0;
}

/*
 * name:      CharLinkedList
 * purpose:   Constructor to create a LinkedList object with a char
 * arguments: a char
 * returns:   none
 * effects:   Creates a LinkedList and initializes proper values
 */
CharLinkedList::CharLinkedList(char c) {
    //Initialize values and add the char to the list
    head = nullptr;
    tail = nullptr;
    listSize = 0;
    pushAtBack(c);
}

/*
 * name:      CharLinkedList
 * purpose:   Constructor to create a LinkedList object with an array and size
 * arguments: an array and an integer
 * returns:   none
 * effects:   Creates a LinkedList and initializes proper values
 */
CharLinkedList::CharLinkedList(char arr[], int size) {
    //Initialize values
    head = nullptr;
    tail = nullptr;
    listSize = 0;
    //Add values from the list
    for (int i = 0; i < size; ++i) {
        pushAtBack(arr[i]);
    }
}

/*
 * name:      CharLinkedList
 * purpose:   Copy constructor to create a LinkedList object as a copy
 * arguments: pointer to other list
 * returns:   none
 * effects:   Creates a LinkedList and copies over values from an existing one
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other) {
    //Initializes values
    head = nullptr;
    tail = nullptr;
    listSize = 0;
    //Creates pointer to other list's values
    Node* current = other.head;
    //Push back values from other array
    while (current != nullptr) {
        pushAtBack(current->data);
        current = current->next;
    }
}

/*
 * name:      ~CharLinkedList
 * purpose:   Dectructor to delete LinkedList object
 * arguments: none
 * returns:   none
 * effects:   Deletes the LinkedList object from the heap
 */
CharLinkedList::~CharLinkedList() {
    //Calls on a recursive function
    clear();
}

/*
 * name:      Overloaded Assignment Operator
 * purpose:   Reassigns the "=" to perform a deep copy when referring to Linked-
 *                  List objects.
 * arguments: pointer to a list
 * returns:   pointer to new list
 * effects:   Performs a deep copy to create a LinkedList
 */
CharLinkedList& CharLinkedList::operator=(const CharLinkedList &other) {
    //Checkk if it is copying over a new list
    if (this != &other) {
        //Put in proper copied values
        clear();
        Node* current = other.head;
        while (current != nullptr) {
            pushAtBack(current->data);
            current = current->next;
        }
    }
    //Return pointer to new list
    return *this;
}

/*
 * name:      isEmpty
 * purpose:   Check if a list is empty
 * arguments: none
 * returns:   bool
 * effects:   none
 */
bool CharLinkedList::isEmpty() const {
    //Return true if size is none
    return listSize == 0;
}

/*
 * name:      clear
 * purpose:   Delete the list
 * arguments: none
 * returns:   none
 * effects:   Deletes the list
 */
void CharLinkedList::clear() {
    //Calls on clear recursive helper function
    clearRec(head);
    //Reset all values
    head = nullptr;
    tail = nullptr;
    listSize = 0;
}

/*
 * name:      clear
 * purpose:   Delete the list
 * arguments: none
 * returns:   none
 * effects:   Deletes the list
 */
void CharLinkedList::clearRec(Node* node) {
    //If none not empty call on the function again and then delete the node
    if (node != nullptr) {
        clearRec(node->next);
        delete node;
    }
}

/*
 * name:      size
 * purpose:   Check size of list
 * arguments: none
 * returns:   int
 * effects:   none
 */
int CharLinkedList::size() const {
    //Return size
    return listSize;
}

/*
 * name:      first
 * purpose:   Get first char in list
 * arguments: none
 * returns:   char
 * effects:   none
 */
char CharLinkedList::first() const {
    //Throw error if emoty else return the data on the front
    if (isEmpty()) {
        throw std::runtime_error("cannot get first of empty LinkedList");
    }
    return head->data;
}

/*
 * name:      last
 * purpose:   Get last char in list
 * arguments: none
 * returns:   char
 * effects:   none
 */
char CharLinkedList::last() const {
    //Check if list empty else return last char
    if (isEmpty()) {
        throw std::runtime_error("cannot get last of empty LinkedList");
    }
    return tail->data;
}

/*
 * name:      elementAt
 * purpose:   Get certain char in list
 * arguments: none
 * returns:   char
 * effects:   none
 */
char CharLinkedList::elementAt(int index) const {
    //If index out of range throw error else call on recursive helper function
    if (index < 0 or index >= listSize) {
        throw std::range_error("index (" + std::to_string(index) + 
        ") not in range [0.." + std::to_string(listSize) + ")");
    }
    return elementAtRec(head, index);
}

/*
 * name:      elementAtRec
 * purpose:   Get certain char in list recursivley
 * arguments: A pointer to a node and an int
 * returns:   char
 * effects:   none
 */
char CharLinkedList::elementAtRec(Node* node, int index) const {
    //Base case if index is 0 return the data at that node
    if (index == 0) {
        return node->data;
    }
    //Else call on the function again withh the next node and a lower index.
    return elementAtRec(node->next, index - 1);
}

/*
 * name:      concatenate
 * purpose:   Combine two lists into one
 * arguments: A pointer to another list
 * returns:   none
 * effects:   Add two lists together
 */
void CharLinkedList::concatenate(CharLinkedList *other) {
    //Get the other node's front
    Node* current = other->head;
    //Until finished add values to list
    while (current != nullptr) {
        pushAtBack(current->data);
        current = current->next;
    }
}

/*
 * name:      toString
 * purpose:   Output a string from the chars in the list
 * arguments: none
 * returns:   string
 * effects:   none
 */
std::string CharLinkedList::toString() const {
    std::string result = "[CharLinkedList of size " +
     std::to_string(listSize) + " <<";
    Node* current = head;
    while (current != nullptr) {
        result += current->data;
        current = current->next;
    }
    result += ">>]";
    return result;
}

/*
 * name:      toReverseString
 * purpose:   Output a reverse string from the chars in the list
 * arguments: none
 * returns:   string
 * effects:   none
 */
std::string CharLinkedList::toReverseString() const {
    std::string result = "[CharLinkedList of size " +
     std::to_string(listSize) + " <<";
    Node* current = tail;
    while (current != nullptr) {
        result += current->data;
        current = current->prev;
    }
    result += ">>]";
    return result;
}

/*
 * name:      pushAtBack
 * purpose:   Add a char to the back of the list
 * arguments: char
 * returns:   none
 * effects:   Add a char to the back of the list
 */
void CharLinkedList::pushAtBack(char c) {
    //Create a new node
    Node* newNode = new Node(c);
    //Add to front if empty else add to back and reshuffle next, prev, and size
    if (isEmpty()) {
        head = newNode;
    } else {
        tail->next = newNode;
        newNode->prev = tail;
    }
    tail = newNode;
    listSize++;
}

/*
 * name:      pushAtFront
 * purpose:   Add a char to the front of the list
 * arguments: char
 * returns:   none
 * effects:   Add a char to the front of the list
 */
void CharLinkedList::pushAtFront(char c) {
    //Create a new node with proper value
    Node* newNode = new Node(c);
    //Add to front if empty else add to front and reshuffle next, prev, and size
    if (isEmpty()) {
        tail = newNode;
    } else {
        head->prev = newNode;
        newNode->next = head;
    }
    head = newNode;
    listSize++;
}

/*
 * name:      popFromFront
 * purpose:   Remove char from front
 * arguments: none
 * returns:   none
 * effects:   Remove char from front
 */
void CharLinkedList::popFromFront() {
    //If empty throw error
    if (isEmpty()) {
        throw std::runtime_error("cannot pop from empty LinkedList");
    }
    //Remove node and readjust size and prev and  head.
    Node* temp = head;
    head = head->next;
    if (head != nullptr) {
        head->prev = nullptr;
    } 
    else 
    {
        tail = nullptr;
    }
    delete temp;
    listSize--;
}

/*
 * name:      popFromBack
 * purpose:   Remove char from back
 * arguments: none
 * returns:   none
 * effects:   Remove char from back
 */
void CharLinkedList::popFromBack() {
    //If empty throw error
    if (isEmpty()) {
        throw std::runtime_error("cannot pop from empty LinkedList");
    }
    Node* temp = tail;
    tail = tail->prev;
    //Remove node and readjust size and prev and head.
    if (tail != nullptr) {
        tail->next = nullptr;
    } 
    else 
    {
        head = nullptr;
    }
    delete temp;
    listSize--;
}

/*
 * name:      removeAt
 * purpose:   Remove char from certain index
 * arguments: int index
 * returns:   none
 * effects:   Remove char from certain index
 */
void CharLinkedList::removeAt(int index) {
    //If index out of bounds throw error
    if (index < 0 or index >= listSize) {
        throw std::range_error("index (" + std::to_string(index) +
         ") not in range [0.." + std::to_string(listSize) + ")");
    }
    //Else pop from front or back
    if (index == 0) {
        popFromFront();
    } 
    else if (index == listSize - 1) 
    {
        popFromBack();
    } 
    else 
    {
        //Else create new node and readjust new pointers.
        Node* current = head;
        for (int i = 0; i < index; i++) {
            current = current->next;
        }
        current->prev->next = current->next;
        current->next->prev = current->prev;
        //Remove current and adjust size
        delete current;
        listSize--;
    }
}

/*
 * name:      replaceAt
 * purpose:   Replace char from certain index
 * arguments: char and an int
 * returns:   none
 * effects:   Replace char from certain index
 */
void CharLinkedList::replaceAt(char c, int index) {
    //If index out of bounds throw error
    if (index < 0 or index >= listSize) {
        throw std::range_error("index (" + std::to_string(index) +
         ") not in range [0.." + std::to_string(listSize) + ")");
    }
    //Call on recursive helper function
    replaceAtRec(head, c, index);
}

/*
 * name:      replaceAtRec
 * purpose:   Replace char from certain index
 * arguments: A pointer to a node, a char, and an int
 * returns:   none
 * effects:   Replace char from certain index
 */
void CharLinkedList::replaceAtRec(Node* node, char c, int index) {
    //Base case if index is zero set that node's data as the char
    if (index == 0) {
        node->data = c;
    } 
    else 
    {
        //Call function using next node, same char, and lower index.
        replaceAtRec(node->next, c, index - 1);
    }
}

/*
 * name:      insertAt
 * purpose:   Insert character in list at a certain position
 * arguments: A char and an int
 * returns:   none
 * effects:   Insert character in list at a certain position
 */
void CharLinkedList::insertAt(char c, int index) {
    //If index out of bounds throw an error
    if (index < 0 or index > listSize) {
        throw std::range_error("index (" + std::to_string(index) +
         ") not in range [0.." + std::to_string(listSize) + "]");
    }
    //If in front or back call on functions
    if (index == 0) {
        pushAtFront(c);
    } 
    else if (index == listSize) 
    {
        pushAtBack(c);
    } 
    else 
    {
        //Create a new node and find proper value
        Node* current = head;
        for (int i = 0; i < index; i++) 
        {
            current = current->next;
        }
        //Rearrange poiters to proper nodes
        Node* newNode = new Node(c);
        newNode->prev = current->prev;
        newNode->next = current;
        current->prev->next = newNode;
        current->prev = newNode;
        listSize++;
    }
}

/*
 * name:      insertInOrder
 * purpose:   Insert character in ordered list at a certain position
 * arguments: A char
 * returns:   none
 * effects:   Insert character in ordered list at a certain position
 */
void CharLinkedList::insertInOrder(char c) {
    //Create a new node
    Node* current = head;
    //Run until the new node value is in correct alphabetical placement
    while (current != nullptr and c > current->data) {
        current = current->next;
    }
    //If node in front or back call correct functions
    if (current == nullptr) {
        pushAtBack(c);
    } 
    else if (current == head) 
    {
        pushAtFront(c);
    } 
    else 
    {
        //Else create new node and properly rearange pointers.
        Node* newNode = new Node(c);
        newNode->next = current;
        newNode->prev = current->prev;
        current->prev->next = newNode;
        current->prev = newNode;
        listSize++;
    }
}
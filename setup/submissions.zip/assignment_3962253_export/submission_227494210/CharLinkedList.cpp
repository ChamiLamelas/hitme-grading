/*
 *  CharLinkedList.cpp
 *  William Bix von Goeler
 *  Feb 4th, 2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  An implementation of the LinkedList interface, this LinkedList can be used
 *  to store the Char data type.
 *
 */

#include "CharLinkedList.h"


/******************************************************************************\
*                          CHAR LINKED LIST FUNCTIONS                          *
\******************************************************************************/

//                         ▻▻▻▻▻▻ CONSTRUCTORS ◅◅◅◅◅◅                         \\

/* Node Constructor
 *    Purpose: Create a Node that automaticly fills itself with data
 * Parameters: The character to store, the prev and next links
 *    Returns: A prefilled node
 */
CharLinkedList::Node::Node(char newData, Node *newPrev, Node *newNext) {
    data = newData;
    prev = newPrev;
    next = newNext;
}

/* Default Constructor
 *    Purpose: Builds a default linkedlist
 * Parameters: None
 *    Returns: None
 */
CharLinkedList::CharLinkedList() {
    // Set all data to defaults
    front = nullptr;
    back = nullptr;
    numItems  = 0;
}

/* Character Constructor
 *    Purpose: Builds a size one linkedlist
 * Parameters: The one character to add
 *    Returns: None
 */
CharLinkedList::CharLinkedList(char c) {
    // Create One node and set it as front and back of list
    Node *newNode = new Node(c, nullptr, nullptr);
    front = newNode;
    back = newNode;
    numItems = 1;
}

/* Array Constructor
 *    Purpose: Builds a linkedlist using data from an array
 * Parameters: the array to copy, and that arrays size
 *    Returns: None
 */
CharLinkedList::CharLinkedList(char arr[], int size) {
    numItems = 0;
    front = nullptr;
    back = nullptr;
    // Itterate through user provided array adding each element to linkedlist
    for (int i = 0; i < size; i++) {
        pushAtBack(arr[i]);
    }
}

/* Copy Constructor
 *    Purpose: Creat a new linkedlist that is a deep copy of provided list
 * Parameters: The CharLinkedList to copy
 *    Returns: None
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other) {
    front = nullptr;
    back = nullptr;
    numItems = 0;
    int other_size = other.size();        
    // Itterate through user provided list, add each element to new linkedlist
    if(not other.isEmpty()) {
        for (int i = 0; i < other_size; i++) {
            char new_char = other.elementAt(i);
            pushAtBack(new_char);
        }
    }
}


//                          ▻▻▻▻▻▻ DESTRUCTOR ◅◅◅◅◅◅                          \\

/* Destructor
 *    Purpose: clean all nodes from heap memory
 * Parameters: None
 *    Returns: None
 */
CharLinkedList::~CharLinkedList() {
    Node *curr = front;
    Node *nextNode = nullptr;
    // Recurse through list deleting each elemment front to back
    if (curr != nullptr) {
        while (curr->next != nullptr) {
            nextNode = curr->next;
            delete curr;
            curr = nextNode;
        }
        //Delete the last node
        delete curr;
    }
}


//                     ▻▻▻▻▻▻ ASSIGNMENT OPERATORS ◅◅◅◅◅◅                     \\

/* Assignment Operator
 *    Purpose: Make a deep copy of the rhs list, into the lhs.
 * Parameters: None
 *    Returns: None
 */
CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other) {
    // If setting list equal to itself do nothing
    if (this == &other) {
        return *this;
    }
    // Clear the lhs list, freeing all heap memory
    clear();
    //Iterate through rhs list adding each element to lhs
    int other_size = other.size(); // save size rather than running each loop
    if(not other.isEmpty()) {
        for (int i = 0; i < other_size; i++) {
            char new_char = other.elementAt(i);
            pushAtBack(new_char);
        }
    }
    return *this;
}


//                      ▻▻▻▻▻▻ CONSTANT FUNCTIONS ◅◅◅◅◅◅                      \\

/* isEmpty
 *    Purpose: check if list is empty
 * Parameters: None
 *    Returns: true for empty, false otherwise
 */
bool CharLinkedList::isEmpty() const {
    return (numItems == 0);
}

/* size
 *    Purpose: Report the size of list as int
 * Parameters: None
 *    Returns: value of private numItems int
 */
int CharLinkedList::size() const {
    return numItems;
}

/* first
 *    Purpose: Report first charachter in list
 * Parameters: None
 *    Returns: Return first charachter in list
 */
char CharLinkedList::first() const {
    // Check if list is empty
    errorHelper('f', 0);
    return front->data;
}

/* first
 *    Purpose: Report last charachter in list
 * Parameters: None
 *    Returns: Return last charachter in list
 */
char CharLinkedList::last() const {
    // Check if list is empty
    errorHelper('l', 0);
    return back->data;
}

/* elementAt
 *    Purpose: Report charachter at index
 * Parameters: index of charachter
 *    Returns: Return charachter at index
 */
char CharLinkedList::elementAt(int index) const {
    // Check if index is in range
    errorHelper('e', index);
    return getNode(index)->data;
}

/* toString
 *    Purpose: Report the state of the list as a string
 * Parameters: None
 *    Returns: A string with the state of the list
 */
string CharLinkedList::toString() const {
    stringstream ss;
    ss << "[CharLinkedList of size " << numItems << " <<";
    Node *curr = front;
    // Recurse through list adding charachters to stringstream front to back
    while (curr != nullptr) {
        ss << curr->data;
        curr = curr->next;
    }
    ss << ">>]";
    return ss.str();
}

/* toReverseString
 *    Purpose: Report the state of the list as a string
 * Parameters: None
 *    Returns: A string with the state of the list from back to front
 */
string CharLinkedList::toReverseString() const {
    stringstream ss;
    ss << "[CharLinkedList of size " << numItems << " <<";
    Node *curr = back;
    // Recurse through list back to front adding each character to stringstream
    while (curr != nullptr) {
        ss << curr->data;
        curr = curr->prev;
    }
    ss << ">>]";
    return ss.str();
}


//                    ▻▻▻▻▻▻ MANIPULATION FUNCTIONS ◅◅◅◅◅◅                    \\

/* pushAtFront
 *    Purpose: Add a new charachter to front of list
 * Parameters: char to add
 *    Returns: none
 */
void CharLinkedList::pushAtFront(char c) {
    Node *newNode;
    // If list is empty set new charachter as front and back
    if (front == nullptr) {
        newNode = new Node(c, nullptr, nullptr);
        back = newNode;
    } else { // Add to front connecting to previous front
        newNode = new Node(c, nullptr, front);
        front->prev = newNode;
    }
    front = newNode;
    numItems++;

}

/* pushAtBack
 *    Purpose: Add a new charachter to back of list
 * Parameters: char to add
 *    Returns: none
 */
void CharLinkedList::pushAtBack(char c) {
    // If list is empty run pushAtFront
    if (front == nullptr) {
        pushAtFront(c);
    } else { // Otherwise create a new node and set it as the new back of list
        Node *newNode = new Node(c, back, nullptr);
        back->next = newNode;
        back = newNode;
        numItems++;
    }
}

/* insertAt
 *    Purpose: Add a new charachter to certain index in list
 * Parameters: char to add
 *    Returns: none
 */
void CharLinkedList::insertAt(char c, int index) {
    // Check if index is in Range
    errorHelper('i', index);
    // If pushing to front or list is empty call pushAtFront Function
    if (index == 0 or isEmpty()) {
        pushAtFront(c);
    } else if (index == numItems) { // If pushing to back call pushAtBack
        pushAtBack(c);
    } else {
        // Find node at index
        Node *curr = getNode(index);
        Node *behind = curr->prev;
        Node *newNode = new Node(c, behind, curr);
        // Connect newNode to previous node at index and the node behind it
        behind->next = newNode;
        curr->prev = newNode;
        numItems++;
    }
}

/* insertInOrder
 *    Purpose: Add a new charachter to alphabedical order in presorted list
 * Parameters: char to add
 *    Returns: none
 */
void CharLinkedList::insertInOrder(char c) {
    if (isEmpty()) {
        pushAtFront(c);
    } else {
        Node *curr = front;
        int index_counter = 0;
        // Recurse through list
        while (curr != nullptr) {
            // If the current nodes char is greater insert new char there
            if (c < curr->data) {
                insertAt(c, index_counter);
                return;
            }
            curr = curr->next;
            index_counter++;
        }
        // If newChar greater than all items add to back
        pushAtBack(c);
    }
}

/* clear
 *    Purpose: Removes all items from list, recycling heap memory
 * Parameters: none
 *    Returns: none
 */
void CharLinkedList::clear() {
    if (not isEmpty()) {
        Node *curr = front;
        Node *nextNode = nullptr;
        // Recurse through list deleting each item
        while (curr->next != nullptr) {
            nextNode = curr->next;
            delete curr;
            curr = nextNode;
        }
        // Delete the last item
        delete curr;
        // Reset all pointers and numItems
        front = nullptr;
        back = nullptr;
        numItems = 0;
    }
}

/* popFromFront
 *    Purpose: remove first Char of list
 * Parameters: none
 *    Returns: none
 */
void CharLinkedList::popFromFront() {
    // Check if list is empty
    errorHelper('p', 0);
    if (numItems == 1) { // One Item List
        delete front;
        front = nullptr;
        back = nullptr;
    } else { // Delete front, set new front, and set newfront prev pointer null
        front = front->next;
        delete front->prev;
        front->prev = nullptr;
    }
    numItems--;
}

/* popFromBack
 *    Purpose: remove last Char of list
 * Parameters: none
 *    Returns: none
 */
void CharLinkedList::popFromBack() {
    // Check if list is empty
    errorHelper('p', 0);
    if (numItems == 1) {
        delete back;
        front = nullptr;
        back = nullptr;
    } else { // Delete back, set new back, and set newback next pointer to null
        back = back->prev;
        delete back->next;
        back->next = nullptr;
    }
    numItems--;
}

/* removeAt
 *    Purpose: remove a Char at specified index
 * Parameters: index to remove at
 *    Returns: none
 */
void CharLinkedList::removeAt(int index) {
    // Check if Index is in Range
    errorHelper('e', index);
    if (not isEmpty()) {
        if (index == 0) { // If index is front call popFromFront
            popFromFront();
        } else if (index == (numItems - 1)) { // If back call popFromBack
            popFromBack();
        } else {
            // Otherwise link prev and next and delete item at index
            Node *curr = getNode(index);
            Node *behind = curr->prev;
            behind->next = curr->next;
            curr->next->prev = behind;
            delete curr;
            numItems--;
        }
    }
}

/* replaceAt
 *    Purpose: replace a Char at specified index
 * Parameters: index to replace at
 *    Returns: none
 */
void CharLinkedList::replaceAt(char c, int index) {
    // Check if index is in range
    errorHelper('e', index);
    // Set char at index to new charachter
    getNode(index)->data = c;
}

/* concatenate
 *    Purpose: Add a copy of the list pointed to to end of the current list
 * Parameters: list to add
 *    Returns: none
 */
void CharLinkedList::concatenate(CharLinkedList *other) {
    int other_size = other->size();
    // Itterate through other list adding each element at back of curr list
    if (other_size > 0) {
        for (int i = 0; i < other_size; i++) {
            char new_char = other->elementAt(i);
            pushAtBack(new_char);
        }
    }
}


//                       ▻▻▻▻▻▻ HELPER FUNCTIONS ◅◅◅◅◅◅                       \\

/* getNode
 *    Purpose: Private function to find address of node at index
 * Parameters: index to find
 *    Returns: A pointer to the node at the specified index
 */
CharLinkedList::Node *CharLinkedList::getNode(int index) const {
    // Check if index is in range
    if (index < numItems and index >= 0) {
        Node *curr;
        // If index is first half of list start from front
        if ((index < numItems / 2) or (numItems < 5)) {
            curr = front;
            // Recurse through list index times
            for (int i = 0; i < index; i++) {
                curr = curr->next;
            }
        // If index is second half of list start from back
        } else {
            curr = back;
            // Recurse through list from back untill index is reached
            for (int i = (numItems - 1); i > index; i--) {
                curr = curr->prev;
            }
        }
        return curr;
    } else {
        // If index out of range return nullptr
        return nullptr;
    }
}

/* errorHelper
*    Purpose: Private function to handle all error checking
* Parameters: Char representing the type of error to check for, and an index
*             for checking in range errors.
*    Returns: None
*
*  Error Codes:
*          f: (first) -> "cannot get first of empty LinkedList".
*          l: (last) -> "cannot get last of empty LinkedList".
*          p: (pop) -> "cannot pop from empty LinkedList".
*          i: (range inclusive) -> "index (IDX) not in range [0..SIZE]"
*          e: (range exclusive) -> "index (IDX) not in range [0..SIZE)"     
*/
void CharLinkedList::errorHelper(char type, int index) const {
    if (isEmpty() and (type == 'f' or type == 'l' or type == 'p')) {
        if (type == 'f') { // Empty First Check
            throw runtime_error("cannot get first of empty LinkedList");
        }
        if (type == 'l') { // Empty Last Check
            throw runtime_error("cannot get last of empty LinkedList");
        }
        if (type == 'p') { // Empty Pop Check
            throw runtime_error("cannot pop from empty LinkedList");
        }
    }
    if ((type == 'i') or (type == 'e')) { // Range Error Checks
        string bracketType = ""; // Var for Inclusive or Exclusive Brackets
        if (type == 'i' and (index < 0 or index > numItems)) {
            bracketType = "]"; // If inclusive and invalid set brackets
        }
        if (type == 'e' and (index < 0 or index >= numItems)) {
            bracketType = ")"; // If exclusive and invalid set brackets
        }
        if (bracketType != "") { // If brackets have been set throw error
            std::stringstream ss;
            ss << "index (" << index << ") not in range [0..";
            ss << numItems << bracketType; // Add correct brackets to message
            throw range_error(ss.str()); // Throw the error
        }
    }
}

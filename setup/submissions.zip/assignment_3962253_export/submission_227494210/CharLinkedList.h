/*
 *  CharLinkedList.h
 *  William Bix von Goeler
 *  Feb 4th, 2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  CharLinkedList is a class that stores a list of Chars. Clients can perform
 *  a variety of operations to manipulate and get information from the list 
 *
 */

#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H

#include <string>
#include <stdexcept>
#include <sstream>
#include <iostream>
using namespace std;



class CharLinkedList {
public:
    //                     ⧈⧈⧈⧈⧈ CONSTRUCTORS ⧈⧈⧈⧈⧈
    CharLinkedList();
    CharLinkedList(char c);
    CharLinkedList(char arr[], int size);
    CharLinkedList(const CharLinkedList &other);

    //                      ⧈⧈⧈⧈⧈ DESTRUCTOR ⧈⧈⧈⧈⧈
    ~CharLinkedList();

    //                 ⧈⧈⧈⧈⧈ ASSIGNMENT OPERATOR ⧈⧈⧈⧈⧈
    CharLinkedList &operator=(const CharLinkedList &other);

    //                   ⧈⧈⧈⧈⧈ CONST FUNCTIONS ⧈⧈⧈⧈⧈
    bool isEmpty() const;
    int size() const;
    char first() const;
    char last() const;
    char elementAt(int index) const;
    string toString() const;
    string toReverseString() const;

    //             ⧈⧈⧈⧈⧈ DATA MANIPULATION FUNCTIONS ⧈⧈⧈⧈⧈
    void pushAtBack(char c);
    void pushAtFront(char c);
    void insertAt(char c, int index);
    void insertInOrder(char c);
    void popFromFront();
    void popFromBack();
    void removeAt(int index);
    void clear();
    void replaceAt(char c, int index);
    void concatenate(CharLinkedList *other);

private:
    struct Node {
        Node(char newData, Node *newPrev, Node *newNext);
        char data;
        Node *prev;
        Node *next;
    };
    
    // Private Functions
    Node *getNode(int index) const;
    void errorHelper(char type, int index) const;
    // Private Variables
    Node *front;
    Node *back;
    int numItems;

};

#endif

/*
 *  unit_tests.h
 *  William Bix von Goeler
 *  Feb 4th, 2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  Runs extensive tests on each member function of CharLinkedList Object
 *
 */

#include "CharLinkedList.h"
#include <cassert>


/******************************************************************************\
*                            CHAR LINKED LIST TESTS                            *
\******************************************************************************/

// Tests for Constructors, Size, and isEmpty

void constructor_test_0() {
    CharLinkedList list;
}

void constructor_test_1() {
    CharLinkedList list;
    assert(list.size() == 0);
    assert(list.isEmpty());
}

void char_constructor_test_0() {
    CharLinkedList test_list('a');
}

void char_constructor_test_1() {
    CharLinkedList test_list('a');
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');
}

void arr_constructor_test_0() {
    char test_arr[9] = {'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(test_arr, 9);
}

void arr_constructor_test_1() {
    char test_arr[9] = {'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(test_arr, 9);
    assert(test_list.toString() == "[CharLinkedList of size 9 <<abczdefgh>>]");
}

void arr_constructor_test_empty() {
    char test_arr[0] = {};
    CharLinkedList test_list(test_arr, 0);
}

void copy_constructor_test() {
    char test_arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list1(test_arr, 5);
    CharLinkedList list2(list1);
    assert(list1.toString() == list2.toString());
    list1.popFromBack();
    assert(list1.toString() != list2.toString());
}

void copy_constructor_test_empty() {
    CharLinkedList list1;
    CharLinkedList list2(list1);
    assert(list1.toString() == list2.toString());
}


// Test for Assignment Opperator

void asop_test() {
    char test_arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list1(test_arr, 5);
    CharLinkedList list2 = list1;

    assert(list1.toString() == list2.toString());
    list1.popFromBack();
    assert(list1.toString() != list2.toString());
}

void empty_asop_test() {
    CharLinkedList list1;
    CharLinkedList list2 = list1;
    assert(list1.toString() == list2.toString());
}


// Tests for first

void first_test() {
    CharLinkedList test_list;
    test_list.pushAtBack('a');
    assert(test_list.first() == 'a');
}

void first_test_empty() {
    bool runtime_error_thrown = false;
    string error_message = "";

    CharLinkedList test_list;
    try {
        // insertAt for out-of-range index
        test_list.first();
    }
    catch (const runtime_error &e) {
        // if insertAt is correctly implemented, a range_error will be thrown,
        // and we will end up here
        runtime_error_thrown = true;
        error_message = e.what();
    }

    // out here, we make our assertions
    assert(runtime_error_thrown);
    assert(error_message == "cannot get first of empty LinkedList");
}


// Tests for last

void last_test() {
    CharLinkedList test_list;
    test_list.pushAtBack('a');
    assert(test_list.last() == 'a');
}

void last_test_large() {
    char test_arr[9] = {'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(test_arr, 9);
    assert(test_list.last() == 'h');
}

void last_test_empty() {
    bool runtime_error_thrown = false;
    string error_message = "";

    CharLinkedList test_list;
    try {
        // insertAt for out-of-range index
        test_list.last();
    }
    catch (const runtime_error &e) {
        // if insertAt is correctly implemented, a range_error will be thrown,
        // and we will end up here
        runtime_error_thrown = true;
        error_message = e.what();
    }

    // out here, we make our assertions
    assert(runtime_error_thrown);
    assert(error_message == "cannot get last of empty LinkedList");
}


// Tests for pushAtBack

void pushAtBack_test_empty() {
    CharLinkedList test_list;
    test_list.pushAtBack('a');
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');
}

void pushAtBack_test_large() {
    char test_arr[9] = {'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(test_arr, 9);
    test_list.pushAtBack('a');
    assert(test_list.last() == 'a');
}


// Tests for pushAtFront

void pushAtFront_test_empty() {
    CharLinkedList test_list;
    test_list.pushAtFront('a');
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');
}

void pushAtFront_test_large() {
    char test_arr[9] = {'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(test_arr, 9);
    test_list.pushAtFront('a');
    assert(test_list.first() == 'a');
}


// Tests for toString

void toString_test_oneElem() {
    CharLinkedList list;
    list.pushAtBack('a');
    assert(list.toString() == "[CharLinkedList of size 1 <<a>>]");
}

void toString_test_multipleElem() {
    CharLinkedList list;
    list.pushAtBack('a');
    list.pushAtBack('b');
    list.pushAtBack('c');
    assert(list.toString() == "[CharLinkedList of size 3 <<abc>>]");
}

void toString_test_empty() {
    CharLinkedList list;
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}


// Tests for elementAt

void elementAt_test() {
    CharLinkedList list;
    list.pushAtBack('a');
    assert(list.elementAt(0) == 'a');
}

void elementAt_test_empty() {
    bool range_error_thrown = false;

    std::string error_message = "";

    CharLinkedList test_list;
    try {
        char temp_char = test_list.elementAt(0);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (0) not in range [0..0)");
}

void elementAt_test_large() {
    char test_arr[9] = {'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(test_arr, 9);
    assert(test_list.elementAt(5) == 'e');
}

void elementAt_test_first() {
    char test_arr[9] = {'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(test_arr, 9);
    assert(test_list.elementAt(0) == 'a');
}

void elementAt_test_last() {
    char test_arr[9] = {'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(test_arr, 9);
    assert(test_list.elementAt(8) == 'h');
}

void elementAt_test_outOfBounds() {
    bool range_error_thrown = false;

    std::string error_message = "";

    char test_arr[9] = {'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(test_arr, 9);

    try {
        char temp_char = test_list.elementAt(50);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (50) not in range [0..9)");
}


// Tests For InsertAt

void insertAt_empty_correct() {
    CharLinkedList test_list;
    test_list.insertAt('a', 0);
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');
}

void insertAt_empty_incorrect() {
    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
        // insertAt for out-of-range index
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        // if insertAt is correctly implemented, a range_error will be thrown,
        // and we will end up here
        range_error_thrown = true;
        error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0]");
}

void insertAt_front_singleton_list() {
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at front
    test_list.insertAt('b', 0);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'a');
}

void insertAt_back_singleton_list() {
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at back
    test_list.insertAt('b', 1);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
}

void insertAt_many_elements() {
    CharLinkedList test_list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.insertAt('a', i);
    }

    assert(test_list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
}

void insertAt_front_large_list() {
    char test_arr[9] = {'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(test_arr, 9);

    test_list.insertAt('y', 0);

    assert(test_list.size() == 10);
    assert(test_list.elementAt(0) == 'y');
    assert(test_list.toString() == 
    "[CharLinkedList of size 10 <<yabczdefgh>>]");
}

void insertAt_back_large_list() {
    char test_arr[10] = {'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(test_arr, 10);

    test_list.insertAt('x', 10);

    assert(test_list.size() == 11);
    assert(test_list.elementAt(10) == 'x');
    assert(test_list.toString() ==
           "[CharLinkedList of size 11 <<yabczdefghx>>]");
}

void insertAt_middle_large_list() {
    char test_arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(test_arr, 8);

    test_list.insertAt('z', 3);

    assert(test_list.size() == 9);
    assert(test_list.elementAt(3) == 'z');
    assert(test_list.toString() == "[CharLinkedList of size 9 <<abczdefgh>>]");
}

void insertAt_nonempty_incorrect() {
    char test_arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.insertAt('a', 42);
    } catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8]");
}


// Tests for clear

void clear_test() {
    CharLinkedList test_list('a');
    test_list.clear();
    assert(test_list.isEmpty());
}

void clear_test_large() {
    char test_arr[9] = {'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(test_arr, 9);
    test_list.clear();
    assert(test_list.isEmpty());
}

void clear_test_empty() {
    CharLinkedList test_list;
    test_list.clear();
    assert(test_list.isEmpty());
}


// Tests for toReverseString

void toReverseString_test_oneElem() {
    CharLinkedList list;
    list.pushAtBack('a');
    assert(list.toReverseString() == "[CharLinkedList of size 1 <<a>>]");
}

void toReverseString_test_multipleElem() {
    CharLinkedList list;
    list.pushAtBack('a');
    list.pushAtBack('b');
    list.pushAtBack('c');
    assert(list.toReverseString() == "[CharLinkedList of size 3 <<cba>>]");
}

void toReverseString_test_empty() {
    CharLinkedList list;
    assert(list.toReverseString() == "[CharLinkedList of size 0 <<>>]");
}


// Tests for insertInOrder

void insertInOrder_test_empty() {
    CharLinkedList test_list;
    test_list.insertInOrder('a');
    assert(test_list.first() == 'a');
}

void insertInOrder_test_standard() {
    char test_arr[9] = {'a', 'b', 'c', 'd', 'f', 'g', 'h', 'i', 'j'};
    CharLinkedList test_list(test_arr, 9);
    test_list.insertInOrder('e');
    assert(test_list.toString() == 
    "[CharLinkedList of size 10 <<abcdefghij>>]");
}

void insertInOrder_test_middle() {
    CharLinkedList test_list;
    test_list.pushAtBack('b');
    test_list.insertInOrder('a');
    test_list.insertInOrder('c');
    test_list.insertInOrder('b');
    assert(test_list.toString() == "[CharLinkedList of size 4 <<abbc>>]");
}

void insertInOrder_test_front() {
    char test_arr[9] = {'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j'};
    CharLinkedList test_list(test_arr, 9);
    test_list.insertInOrder('a');
    assert(test_list.toString() == 
    "[CharLinkedList of size 10 <<abcdefghij>>]");
}

void insertInOrder_test_back() {
    char test_arr[9] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i'};
    CharLinkedList test_list(test_arr, 9);
    test_list.insertInOrder('j');
    assert(test_list.toString() == 
    "[CharLinkedList of size 10 <<abcdefghij>>]");
}


// Tests for popFromFront/Back and removeAt

void popFrontEmpty() {
    bool runtime_error_thrown = false;

    std::string error_message = "";

    CharLinkedList test_list;
    try {
        test_list.popFromFront();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

void popFrontOne() {
    CharLinkedList test_list;
    test_list.pushAtBack('a');
    test_list.popFromFront();
    assert(test_list.size() == 0);
}

void popFrontLarge() {
    char test_arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList test_list(test_arr, 5);
    test_list.popFromFront();
    assert(test_list.toString() == "[CharLinkedList of size 4 <<bcde>>]");
}

void popBackEmpty() {
    bool runtime_error_thrown = false;

    std::string error_message = "";

    CharLinkedList test_list;
    try {
        test_list.popFromBack();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

void popBackOne() {
    CharLinkedList test_list;
    test_list.pushAtBack('a');
    test_list.popFromBack();
    assert(test_list.size() == 0);
}

void popBackLarge() {
    char test_arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList test_list(test_arr, 5);
    test_list.popFromBack();
    assert(test_list.toString() == "[CharLinkedList of size 4 <<abcd>>]");
}

void removeAtEmpty() {
    bool range_error_thrown = false;

    std::string error_message = "";

    CharLinkedList test_list;
    try {
        test_list.removeAt(0);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (0) not in range [0..0)");
}

void removeAtOne() {
    CharLinkedList test_list;
    test_list.pushAtBack('a');
    test_list.removeAt(0);
    assert(test_list.size() == 0);
}

void removeAtLarge() {
    char test_arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList test_list(test_arr, 5);
    test_list.removeAt(2);
    assert(test_list.toString() == "[CharLinkedList of size 4 <<abde>>]");
}

void removeAtFront() {
    char test_arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList test_list(test_arr, 5);
    test_list.removeAt(0);
    assert(test_list.toString() == "[CharLinkedList of size 4 <<bcde>>]");
}

void removeAtBack() {
    char test_arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList test_list(test_arr, 5);
    test_list.removeAt(4);
    assert(test_list.toString() == "[CharLinkedList of size 4 <<abcd>>]");
}

void removeAtOOB() {
    bool range_error_thrown = false;

    std::string error_message = "";

    char test_arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList test_list(test_arr, 5);

    try {
        test_list.removeAt(20);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (20) not in range [0..5)");
}

void removeAtSize() {
    bool range_error_thrown = false;

    std::string error_message = "";

    char test_arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList test_list(test_arr, 5);

    try {
        test_list.removeAt(5);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (5) not in range [0..5)");
}


// Tests for replaceAt

void replaceAtEmpty() {
    bool range_error_thrown = false;

    std::string error_message = "";

    CharLinkedList test_list;
    try {
        test_list.replaceAt('a', 0);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (0) not in range [0..0)");
}

void replaceAtOne() {
    CharLinkedList test_list;
    test_list.pushAtBack('a');
    test_list.replaceAt('b', 0);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.size() == 1);
}

void replaceAtFront() {
    char test_arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList test_list(test_arr, 5);
    test_list.replaceAt('z', 0);
    assert(test_list.toString() == "[CharLinkedList of size 5 <<zbcde>>]");
}

void replaceAtBack() {
    char test_arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList test_list(test_arr, 5);
    test_list.replaceAt('z', 4);
    assert(test_list.toString() == "[CharLinkedList of size 5 <<abcdz>>]");
}

void replaceAtLarge() {
    char test_arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList test_list(test_arr, 5);
    test_list.replaceAt('z', 2);
    assert(test_list.toString() == "[CharLinkedList of size 5 <<abzde>>]");
}

void replaceAtOOB() {
    bool range_error_thrown = false;

    std::string error_message = "";

    char test_arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList test_list(test_arr, 5);

    try {
        test_list.replaceAt('z', 20);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (20) not in range [0..5)");
}

void replaceAtSize() {
    bool range_error_thrown = false;

    std::string error_message = "";

    char test_arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList test_list(test_arr, 5);

    try {
        test_list.replaceAt('z', 5);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (5) not in range [0..5)");
}


// Test concatenate
void concatenate_test() {
    CharLinkedList list1;
    list1.pushAtBack('a');
    list1.pushAtBack('b');
    list1.pushAtBack('c');

    CharLinkedList list2;
    list2.pushAtBack('d');
    list2.pushAtBack('e');
    list2.pushAtBack('f');

    list1.concatenate(&list2);
    assert(list1.toString() == "[CharLinkedList of size 6 <<abcdef>>]");
}

void concatenate_test_self() {
    CharLinkedList list1;
    list1.pushAtBack('a');
    list1.pushAtBack('b');
    list1.pushAtBack('c');

    list1.concatenate(&list1);
    assert(list1.toString() == "[CharLinkedList of size 6 <<abcabc>>]");
}

void concatenate_test_empty1() {
    CharLinkedList list1;

    CharLinkedList list2;
    list2.pushAtBack('d');
    list2.pushAtBack('e');
    list2.pushAtBack('f');

    list1.concatenate(&list2);
    assert(list1.toString() == "[CharLinkedList of size 3 <<def>>]");
}

void concatenate_test_empty2() {
    CharLinkedList list1;
    list1.pushAtBack('a');
    list1.pushAtBack('b');
    list1.pushAtBack('c');

    CharLinkedList list2;

    list1.concatenate(&list2);
    assert(list1.toString() == "[CharLinkedList of size 3 <<abc>>]");
}

void concatenate_test_empty3() {
    CharLinkedList list1;
    CharLinkedList list2;

    list1.concatenate(&list2);
    assert(list1.toString() == "[CharLinkedList of size 0 <<>>]");
}



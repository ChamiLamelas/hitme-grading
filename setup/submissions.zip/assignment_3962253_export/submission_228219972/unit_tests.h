/*
 *  unit_tests.h
 *  Lauren Wu
 *  February 3, 2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  This file contains 82 unit tests to test the functionality of the
 *  CharLinkedList class.
 *
 */

 #include "CharLinkedList.h"
 #include "CharLinkedList.h"
 #include <cassert>

// Ensure the class is properly implemented
void dummyTest() {
    return;
}

// Test default constructor to ensure no fatal errors/memory leaks occur
void constructor_test1() {
    CharLinkedList test_list;
}

// Test toString function on an empty linked list
void toString_test_empty() {
    CharLinkedList test_list;
    assert(test_list.toString() == "[CharLinkedList of size 0 <<>>]");
}

// Test toString function on a single element linked list
void toString_test_single() {
    CharLinkedList test_list('c');
    assert(test_list.toString() == "[CharLinkedList of size 1 <<c>>]");
}

// Test toString function on a multi element linked list
void toString_test_multi() {
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList test_list(arr, 3);
    assert(test_list.toString() == "[CharLinkedList of size 3 <<abc>>]");
}

// Test copy constructor with an empty linked list
void copy_constructor_empty() {
    CharLinkedList test_list;
    CharLinkedList test_list2(test_list);
    assert(test_list.toString() == test_list2.toString());
}

// Test copy constructor with a single-element linked list
void copy_constructor_single() {
    CharLinkedList test_list('a');
    CharLinkedList test_list2(test_list);
    assert(test_list.toString() == test_list2.toString());
}

// Test copy constructor with a multi-element linked list
void copy_constuctor_multi() {
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList test_list(arr, 3);
    CharLinkedList test_list2(test_list);
    assert(test_list.toString() == test_list2.toString());
}

// Test the assignment operator copies each node correctly and recycles memory
void assignment_operator_test_multi() {
    CharLinkedList test_list('c');
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList test_list2(arr, 3);
    test_list = test_list2;
    assert(test_list.toString() == test_list2.toString());
}

// Test that running isEmpty on an empty linked list returns true
void isEmpty_true() {
    CharLinkedList test_list;
    assert(test_list.isEmpty());
}

// Test that running isEmpty on a non-empty linked list returns false
void isEmpty_false() {
    CharLinkedList test_list('a');
    assert(not test_list.isEmpty());
}

// Test that clearing an empty list does not have any unexpected results
void clear_empty() {
    CharLinkedList test_list;
    test_list.clear();
    assert(test_list.isEmpty());
}

// Test running clear on a single-element list creates an empty list
void clear_single() {
    CharLinkedList test_list('a');
    test_list.clear();
    assert(test_list.isEmpty());
}

// Test running clear on a multi-element list creates an empty list
void clear_multi() {
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList test_list(arr, 3);
    test_list.clear();
    assert(test_list.isEmpty());
}

// Test that running size on an empty list returns 0
void size_empty() {
    CharLinkedList test_list;
    assert(test_list.size() == 0);
}

// Test that running size on a single element list returns 1
void size_single() {
    CharLinkedList test_list('a');
    assert(test_list.size() == 1);
}

// Test that running size on a five-element list returns 5
void size_multi() {
    char arr[5] = {'a', 'l', 'i', 'c', 'e'};
    CharLinkedList test_list(arr, 5);
    assert(test_list.size() == 5);
}

// Test that running first on an empty list throws a runtime_error
void first_incorrect() {
    // var to track whether runtime_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;

    try {
    // first() with an empty CharLinkedList
    test_list.first();
    }
    catch (const std::runtime_error &e) {
    // if first is correctly implemented, a runtime_error will be thrown,
    // and we will end up here
    runtime_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(runtime_error_thrown);
    assert(error_message == "cannot get first of empty LinkedList");
}

// Test that running first on a single-element list returns expected char
void first_single() {
    CharLinkedList test_list('a');
    assert(test_list.first() == 'a');
}


// Test that running first on a multi-element list returns expected char
void first_multi() {
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList test_list(arr, 3);
    assert(test_list.first() == 'a');
}

// Test that running last on an empty list throws a runtime_error
void last_incorrect() {
    // var to track whether runtime_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;

    try {
    // last() with an empty CharLinkedList
    test_list.last();
    }
    catch (const std::runtime_error &e) {
    // if last is correctly implemented, a runtime_error will be thrown,
    // and we will end up here
    runtime_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(runtime_error_thrown);
    assert(error_message == "cannot get last of empty LinkedList");
}

// Test that running last on a single-element list returns expected char
void last_single() {
    CharLinkedList test_list('a');
    assert(test_list.first() == 'a');
}

// Test that running last on a multi-element list returns expected char
void last_multi() {
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList test_list(arr, 3);
    assert(test_list.last() == 'c');
}


// Attempt to access an element in an empty list
void elementAt_empty() {
    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;

    try {
    // elementAt() with an empty CharLinkedList
    test_list.elementAt(3);
    }
    catch (const std::range_error &e) {
    // if elementAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    range_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (3) not in range [0..0)");
}

// Attempt to access an element out of range
void elementAt_out_of_range() {
    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList test_list(arr, 3);

    try {
    // elementAt() with an empty CharLinkedList
    test_list.elementAt(5);
    }
    catch (const std::range_error &e) {
    // if elementAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    range_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (5) not in range [0..3)");
}

// Attempt to access an element at a negative index
void elementAt_negative() {
    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList test_list(arr, 3);

    try {
    // elementAt() with an empty CharLinkedList
    test_list.elementAt(-1);
    }
    catch (const std::range_error &e) {
    // if elementAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    range_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (-1) not in range [0..3)");
}

// Attempt to access an element from a single element list
void element_at_single() {
    CharLinkedList test_list('a');
    assert(test_list.elementAt(0) == 'a');
}

// Attempt to access an element from a multi element list
void element_at_multi() {
    char arr[5] = {'a', 'l', 'i', 'c', 'e'};
    CharLinkedList test_list(arr, 5);
    assert(test_list.elementAt(2) == 'i');
}

// Test toReverseString on an empty list
void toReverseString_empty () {
    CharLinkedList test_list;
    assert(test_list.toReverseString() == "[CharLinkedList of size 0 <<>>]");
}

// Test toReverseString on a single-element list
void toReverseString_single () {
    CharLinkedList test_list('a');
    assert(test_list.toReverseString() == "[CharLinkedList of size 1 <<a>>]");
}

// Test toReverseString on a multi-element list
void toReverseString_multi () {
    char arr[5] = {'a', 'l', 'i', 'c', 'e'};
    CharLinkedList test_list(arr, 5);
    assert(test_list.toReverseString() == 
        "[CharLinkedList of size 5 <<ecila>>]");
}

// Test pushAtBack on an empty list
void pushAtBack_empty() {
    CharLinkedList test_list;
    test_list.pushAtBack('a');
    assert(test_list.toString() == "[CharLinkedList of size 1 <<a>>]");
}

// Test pushAtBack on a single element list
void pushAtBack_single() {
    CharLinkedList test_list('a');
    test_list.pushAtBack('b');
    assert(test_list.toString() == "[CharLinkedList of size 2 <<ab>>]");
}

// Test pushAtBack on a multi-element list
void pushAtBack_multi() {
    // create a non-empty list
    char arr[4] = {'A', 'l', 'i', 'c'};
    CharLinkedList test_list(arr, 4);

    // assert pushAtBack() adds the correct char to the linked list
    test_list.pushAtBack('e');
    assert(test_list.toString() == "[CharLinkedList of size 5 <<Alice>>]");
}


// Test pushing a new node to the front of an empty list
void pushAtFront_empty() {
    CharLinkedList test_list;
    test_list.pushAtFront('a');
    assert(test_list.toString() == "[CharLinkedList of size 1 <<a>>]");
}

void pushAtFront_single() {
    CharLinkedList test_list('a');
    test_list.pushAtFront('b');
    assert(test_list.toString() == "[CharLinkedList of size 2 <<ba>>]");
}

void pushAtFront_multi() {
    // create a non-empty list
    char arr[4] = {'l', 'i', 'c', 'e'};
    CharLinkedList test_list(arr, 4);

    // assert pushAtBack() adds the correct char to the linked list
    test_list.pushAtFront('A');
    assert(test_list.toString() == "[CharLinkedList of size 5 <<Alice>>]");
}

// Tests correct insertion into an empty AL.
// Afterwards, size should be 1 and element at index 0
// should be the element we inserted.

void insertAt_empty_correct() { 

    CharLinkedList test_list;
    test_list.insertAt('a', 0);
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');

}


// Tests incorrect insertion into an empty AL.
// Attempts to call insertAt for index larger than 0.
// This should result in an std::range_error being raised.
void insertAt_empty_incorrect() {

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    // insertAt for out-of-range index
    test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
    // if insertAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    range_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0]");
    
}


// Tests correct insertAt for front of 1-element list.
void insertAt_front_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at front
    test_list.insertAt('b', 0);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'a');
    
}

// Tests correct insertAt for back of 1-element list.
void insertAt_back_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at back
    test_list.insertAt('b', 1);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    
}

// Tests calling insertAt for a large number of elements.
// Not only does this test insertAt, it also checks that
// list expansion works correctly.
void insertAt_many_elements() {
    
    CharLinkedList test_list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.insertAt('a', i);
    }

    assert(test_list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
    
}

// Tests insertion into front of a larger list
void insertAt_front_large_list() {
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    test_list.insertAt('y', 0);

    assert(test_list.size() == 10);
    assert(test_list.elementAt(0) == 'y');
    assert(test_list.toString() == 
    "[CharLinkedList of size 10 <<yabczdefgh>>]");

}

// Tests insertion into the back of a larger list
void insertAt_back_large_list() {

    char test_arr[10] = { 'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 10);  

    test_list.insertAt('x', 10);

    assert(test_list.size() == 11);
    assert(test_list.elementAt(10) == 'x');
    assert(test_list.toString() == 
    "[CharLinkedList of size 11 <<yabczdefghx>>]"); 

}

// Tests insertion into the middle of a larger list
void insertAt_middle_large_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.insertAt('z', 3);

    assert(test_list.size() == 9);
    assert(test_list.elementAt(3) == 'z');
    assert(test_list.toString() == "[CharLinkedList of size 9 <<abczdefgh>>]");

}

// Tests out-of-range insertion for a non-empty list.
void insertAt_nonempty_incorrect() {
   
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8]");
    
}


// Tests insertInOrder on an empty linked list
void insertInOrder_empty() { 

    CharLinkedList test_list;
    test_list.insertInOrder('a');
    assert(test_list.toString() == "[CharLinkedList of size 1 <<a>>]");

}

// Tests insertInOrder to the front of a single-element linked list
void insertInOrder_front_single() {
    
    // initialize 1-element list
    CharLinkedList test_list('b');

    // insert to front of linked list
    test_list.insertInOrder('a');

    assert(test_list.toString() == "[CharLinkedList of size 2 <<ab>>]");
    
}

// Tests insertInOrder to the back of a single-element linked list
void insertInOrder_back_single() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert to back of linked list
    test_list.insertInOrder('b');

    assert(test_list.toString() == "[CharLinkedList of size 2 <<ab>>]");
    
}

// Tests insertInOrder to the front of a multi-element linked list with a
// duplicate letter
void insertInOrder_multiple_front() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    // insert to front of linked list
    test_list.insertInOrder('a');

    assert(test_list.toString() == "[CharLinkedList of size 9 <<aabcdefgh>>]");
}

// Tests insertInOrder to the middle of a multi-element linked list
void insertInOrder_multiple_middle() {
    char test_arr[7] = { 'a', 'b', 'c', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 7);

    // insert to front of linked list
    test_list.insertInOrder('d');

    assert(test_list.toString() == "[CharLinkedList of size 8 <<abcdefgh>>]");
}

// Tests insertInOrder to the back of a multi-element linked list
void insertInOrder_multiple_back() {
    char test_arr[7] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g' };
    CharLinkedList test_list(test_arr, 7);

    // insert to front of linked list
    test_list.insertInOrder('h');

    assert(test_list.toString() == "[CharLinkedList of size 8 <<abcdefgh>>]");
}

// Tests popFromFront on an empty linked list to check for runtime_error catch
void popFromFront_empty() {
    // var to track whether runtime_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;

    try {
    // popFromFront() with an empty CharLinkedList
    test_list.popFromFront();
    }
    catch (const std::runtime_error &e) {
    // if popFromtFront is correctly implemented, a runtime_error will be
    // thrown, and we will end up here
    runtime_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

// Tests popFromFront on a single-element linked list
void popFromFront_single() {
    // initiaze single element linked list
    CharLinkedList test_list('a');

    // pop first element
    test_list.popFromFront();

    // assert the list is now empty
    assert(test_list.isEmpty());
}

// Tests popFromFront on a multi-element linked list
void popFromFront_multi() {
    // initiaze multiple element linked list
    char test_arr[7] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g' };
    CharLinkedList test_list(test_arr, 7);

    // pop first element
    test_list.popFromFront();

    // assert the first element has been popped off and the size has decreased
    assert(test_list.toString() == "[CharLinkedList of size 6 <<bcdefg>>]");
}


// Tests popFromBack on an empty linked list to check for runtime_error catch
void popFromBack_empty() {
    // var to track whether runtime_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;

    try {
    // popFromBack() with an empty CharLinkedList
    test_list.popFromBack();
    }
    catch (const std::runtime_error &e) {
    // if popFromBack is correctly implemented, a runtime_error will be thrown,
    // and we will end up here
    runtime_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

// Test popFromBack on a single-element linked list
void popFromBack_single() {
    // initiaze single element linked list
    CharLinkedList test_list('a');

    // pop first element
    test_list.popFromBack();

    // assert the list is now empty
    assert(test_list.isEmpty());
}

// Test popFromBack on a multi-element linked list
void popFromBack_multi() {
    // initiaze multiple element linked list
    char test_arr[7] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g' };
    CharLinkedList test_list(test_arr, 7);

    // pop first element
    test_list.popFromBack();

    // assert the first element has been popped off and the size has decreased
    assert(test_list.toString() == "[CharLinkedList of size 6 <<abcdef>>]");
}

// Test removeAt on an empty list to check for range error catch
void removeAt_empty() {
    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;

    try {
    // popFromBack() with an empty CharLinkedList
    test_list.removeAt(0);
    }
    catch (const std::range_error &e) {
    // if removeAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    range_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (0) not in range [0..0)");
}

// Test out-of-range removeAt on a single-element linked list
 void removeAt_single_incorrect() {
    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list('a');

    try {
    // removeAt() out of range
    test_list.removeAt(2);
    }
    catch (const std::range_error &e) {
    // if removeAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    range_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (2) not in range [0..1)");
}

// Test negative index removeAt on a single-element linked list
 void removeAt_negative() {
    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list('a');

    try {
    // removeAt() out of range
    test_list.removeAt(-1);
    }
    catch (const std::range_error &e) {
    // if removeAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    range_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (-1) not in range [0..1)");
}

// Test in-range removeAt on a single-element linked list
void removeAt_single_correct() {

    // initialize single element linked list
    CharLinkedList test_list ('a');

    // removeAt() the first element
    test_list.removeAt(0);

    // assert the list is now empty
    assert(test_list.isEmpty());
}

// Test out-of-range removeAt on a multi-element list
void removeAt_multi_incorrect() {
    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    // initiaze multiple element linked list
    char test_arr[7] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g'};
    CharLinkedList test_list(test_arr, 7);

    try {
    // removeAt() out of range
    test_list.removeAt(7);
    }
    catch (const std::range_error &e) {
    // if removeAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    range_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (7) not in range [0..7)");
}

// Test in-range removeAt on a multi-element list
void removeAt_multi_correct() {
    // initiaze multiple element linked list
    char test_arr[7] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g' };
    CharLinkedList test_list(test_arr, 7);

    // remove element at index 3
    test_list.removeAt(3);

    // assert the third element has been removed and the size has decreased
    assert(test_list.toString() == "[CharLinkedList of size 6 <<abcefg>>]");
}

// Test replaceAt on an empty list to check for range_error catch
void replaceAt_empty() {
    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;

    try {
    // replaceAt() with an empty CharLinkedList
    test_list.replaceAt('a', 0);
    }
    catch (const std::range_error &e) {
    // if replaceAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    range_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (0) not in range [0..0)");
}

// test out-of-range replaceAt on a single-element linked list
void replaceAt_single_incorrect() {
    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list('a');

    try {
    // replaceAt() out of range
    test_list.replaceAt('b', 2);
    }
    catch (const std::range_error &e) {
    // if replaceAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    range_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (2) not in range [0..1)");
}

// test in-range replaceAt on a single element list
void replaceAt_single_correct() {
    // initialize single element linked list
    CharLinkedList test_list ('a');

    // replaceAt() the first element with a new char
    test_list.replaceAt('b', 0);

    // assert the list has made the correct swap and is the same size
    assert(test_list.toString() == "[CharLinkedList of size 1 <<b>>]");
}

// test out-of-range replaceAt on a multi element list
void replaceAt_multi_incorrect() {
    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    // initialize a multi-element linked list
    char test_arr[7] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g' };
    CharLinkedList test_list(test_arr, 7);

    try {
    // replaceAt() out of range
    test_list.replaceAt('z', 10);
    }
    catch (const std::range_error &e) {
    // if replaceAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    range_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (10) not in range [0..7)");
}

// test replaceAt on a multi element list at a negative index
void replaceAt_multi_negative() {
    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    // initialize a multi-element linked list
    char test_arr[7] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g' };
    CharLinkedList test_list(test_arr, 7);

    try {
    // replaceAt() out of range
    test_list.replaceAt('z', -1);
    }
    catch (const std::range_error &e) {
    // if replaceAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    range_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (-1) not in range [0..7)");
}

// test in-range replaceAt at front of a multi element list
void replaceAt_multi_front() {
    // initialize multi element linked list
    char test_arr[7] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g' };
    CharLinkedList test_list(test_arr, 7);

    // replaceAt() the first element with a new char
    test_list.replaceAt('z', 0);

    // assert the list has made the correct swap and is the same size
    assert(test_list.toString() == "[CharLinkedList of size 7 <<zbcdefg>>]");
}

// test in-range replaceAt in the middle of a multi element list
void replaceAt_multi_middle() {
    // initialize multi element linked list
    char test_arr[7] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g' };
    CharLinkedList test_list(test_arr, 7);

    // replaceAt() the first element with a new char
    test_list.replaceAt('z', 3);

    // assert the list has made the correct swap and is the same size
    assert(test_list.toString() == "[CharLinkedList of size 7 <<abczefg>>]");
}

// test in-range replaceAt at the end of a multi element list
void replaceAt_multi_end() {
    // initialize multi element linked list
    char test_arr[7] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g' };
    CharLinkedList test_list(test_arr, 7);

    // replaceAt() the first element with a new char
    test_list.replaceAt('z', 6);

    // assert the list has made the correct swap and is the same size
    assert(test_list.toString() == "[CharLinkedList of size 7 <<abcdefz>>]");
}

// Assert concatenating two empty linked lists will produce an empty linked list
void concatenate_empty_empty() {

    // initialize two empty linked lists
    CharLinkedList list_1;
    CharLinkedList list_2;

    list_1.concatenate(&list_2);
    assert(list_1.isEmpty());
}

// Assert concatenating an empty linked list and a single element linked list
// will produce the correct result
void concatenate_empty_single() {
    CharLinkedList list_1;
    CharLinkedList list_2('a');

    list_1.concatenate(&list_2);
    std::string product = list_1.toString();
    assert(product == "[CharLinkedList of size 1 <<a>>]");
}

// Assert concatenating an empty linked list and a muli-element linked list
// will produce the correct result
void concatenate_empty_multi() {
    CharLinkedList list_1;
    char test_arr[8] = { 'C', 'H', 'E', 'S', 'H', 'I', 'R', 'E' };
    CharLinkedList list_2(test_arr, 8);

    list_1.concatenate(&list_2);
    std::string product = list_1.toString();
    assert(product == "[CharLinkedList of size 8 <<CHESHIRE>>]");
}

// Assert concatenating a single-element linked list and an empty linked list
// will produce the correct result
void concatenate_single_empty() {
    // initialize one single element linked list and one empty
    CharLinkedList list_1('a');
    CharLinkedList list_2;

    // concatenate list_1 with list_2 and assert it produces the expected output
    list_1.concatenate(&list_2);
    std::string product = list_1.toString();
    assert(product == "[CharLinkedList of size 1 <<a>>]");
}

// Assert concatenating two single-element linked lists will produce the 
// correct result
void concatenate_single_single() {
    // initialize two single element linked lists
    CharLinkedList list_1('a');
    CharLinkedList list_2('b');

    // concatenate list_1 with list_2 and assert it produces the expected output
    list_1.concatenate(&list_2);
    std::string product = list_1.toString();
    assert(product == "[CharLinkedList of size 2 <<ab>>]");
}

// Assert concatenating a single-element linked list and a multi-element linked 
// list will produce the correct result
void concatenate_single_multi() {

    // initialize one single element linked list and one multi-element
    CharLinkedList list_1('C');
    char test_arr[7] = { 'H', 'E', 'S', 'H', 'I', 'R', 'E' };
    CharLinkedList list_2(test_arr, 7);

    // concatenate list_1 with list_2 and assert it produces the expected output
    list_1.concatenate(&list_2);
    std::string product = list_1.toString();
    assert(product == "[CharLinkedList of size 8 <<CHESHIRE>>]");
}

// Assert concatenating a multi-element linked list and an empty linked list
// will produce the correct result
void concatenate_multi_empty() {
    // initialize two multi-element lists
    char test_arr[8] = { 'C', 'H', 'E', 'S', 'H', 'I', 'R', 'E' };
    CharLinkedList list_1(test_arr, 8);
    CharLinkedList list_2;

    // concatenate list_1 with list_2 and assert it produces the expected output
    list_1.concatenate(&list_2);
    std::string product = list_1.toString();
    assert(product == "[CharLinkedList of size 8 <<CHESHIRE>>]");

}

// Assert concatenating a multi-element linked list and a single-element linked 
// list will produce the correct result
void concatenate_multi_single() {
    // initialize two multi-element lists
    char test_arr[8] = { 'C', 'H', 'E', 'S', 'H', 'I', 'R', 'E' };
    CharLinkedList list_1(test_arr, 8);
    CharLinkedList list_2('a');

    // concatenate list_1 with list_2 and assert it produces the expected output
    list_1.concatenate(&list_2);
    std::string product = list_1.toString();
    assert(product == "[CharLinkedList of size 9 <<CHESHIREa>>]");

}

// Assert concatenating two multi-element linked lists will produce the correct 
// result
void concatenate_multi_multi() {

    // initialize two multi-element lists
    char test_arr[8] = { 'C', 'H', 'E', 'S', 'H', 'I', 'R', 'E' };
    CharLinkedList list_1(test_arr, 8);
    char test_arr_2[3] = { 'c', 'a', 't' };
    CharLinkedList list_2(test_arr_2, 3);

    // concatenate list_1 with list_2 and assert it produces the expected output
    list_1.concatenate(&list_2);
    std::string product = list_1.toString();
    assert(product == "[CharLinkedList of size 11 <<CHESHIREcat>>]");
}


// Assert concatenating a multi-element linked list with itself will produce the
// correct result
void concatenate_same_string() {
    // initialize a multi-element string
    char test_arr[4] = { 'a', 'b', 'c', 'd' };
    CharLinkedList list_1(test_arr, 4);

    // concatenate list_1 with list_2 and assert it produces the expected output
    list_1.concatenate(&list_1);
    std::string product = list_1.toString();
    assert(product == "[CharLinkedList of size 8 <<abcdabcd>>]");
}


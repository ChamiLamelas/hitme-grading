/*
 *  CharLinkedList.cpp
 *  Lauren Wu
 *  February 3, 2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Implement the different methods for the CharLinkedList class as defined in
 *  CharLinkedList.h. This includes multiple constructors, a destructor,
 *  private helper functions, and methods that will add, remove, and access
 *  nodes, as well as perform actions such as converting the list contents to a
 *  string or concatenating two lists.
 *
 */

#include "CharLinkedList.h" 
#include <stdexcept>
#include <iostream>
#include <string>
#include <sstream>

/*
 * name:      CharLinkedList default constructor
 * purpose:   initialize an empty CharLinkedList
 * arguments: none
 * returns:   none
 * effects:   set front to nullptr and size to 0
 */
CharLinkedList::CharLinkedList() {
    this->front = nullptr;
    this->tail = nullptr;
    this->numItems = 0;
}

/*
 * name:      CharLinkedList single element constructor
 * purpose:   initialize a CharLinkedList with a signle element
 * arguments: char c
 * returns:   none
 * effects:   Create a new linked list with the specified char as the single
 *            element
 */
CharLinkedList::CharLinkedList(char c) {
    // Create a new node in memory for the char passed in
    Node *new_node = new Node;
    new_node->info = c;
    new_node->next = nullptr;
    new_node->prev = nullptr;
    this->front = new_node;
    this->tail = new_node;
    this->numItems = 1;
}

/*
 * name:      CharLinkedList multi element constructor
 * purpose:   initialize a CharLinkedList containing the characters in the array
 *            that was passed in as a parameter
 * arguments: array of characters, int representing the length of the array
 * returns:   none
 * effects:   Create a new linked list with multiple elements
 */
CharLinkedList::CharLinkedList(char arr[], int size) {
    this->front = nullptr;

    // Iterate through the array and create a new node for each char
    // Add each node into the list
    for (int i = size; i > 0; i--) {
        Node *new_node = new Node;
        new_node->info = arr[i - 1];
        new_node->next = this->front;
        if (front) {
            new_node->next->prev = new_node;
        }
        if (i == size) {
            this->tail = new_node;
        }
        this->front = new_node;
    }
    this->front->prev = nullptr;

    // Set numItems
    numItems = size;
}

/*
 * name:      copyNodes
 * purpose:   Copy the nodes from one instance of CharLinkedList into this one
 * arguments: Address of the linked list to be copied
 * returns:   none
 * effects:   Copies nodes from another linked list
 */
void CharLinkedList::copyNodes(const CharLinkedList &other) {
    // Create pointers to hold places in the linked lists
    Node *last = nullptr;
    Node *curr = other.front;

    // Account for the empty list
    if (not other.front) {
        this->front = nullptr;
    }

    // Copy in each of the other nodes
    while (curr) {
    Node *new_node = new Node{curr->info, nullptr, last};
    if (not last) {
        front = new_node;
    } else {
        last->next = new_node;
    }
    curr = curr->next;
    last = new_node;
    }
    this->tail = last;
    this->numItems = other.numItems;
    }

/*
 * name:      CharLinkedList Copy Constructor
 * purpose:   Create a new CharLinkedList instance that is a deep copy of the
 *            linked list parameter
 * arguments: none
 * returns:   none
 * effects:   Creates a new linked list that is identical to the parapeter
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other) {
    this->copyNodes(other);
}

/*
 * name:      CharLinkedList Destructor
 * purpose:   free memory associated with CharLinkedList 
 * arguments: none
 * returns:   none
 * effects:   free memory allocated by CharLinkedList instances
 */
CharLinkedList::~CharLinkedList() {
    this->freeNodes();
}

/*
 * name:      CharLinkedList Assignment Operator
 * purpose:   create a deep copy of a CharLinkedList instance 
 * arguments: a pointer to a CharLinked List to be copied
 * returns:   none
 * effects:   Recycle store associated with LHS of assignment and make a deep
              copy of RHS into the instance on the LHS
 */
CharLinkedList& CharLinkedList::operator=(const CharLinkedList &other) {
    if (this == &other) {
        return *this;
    }
    this->freeNodes();
    this->copyNodes(other);
    return *this;
}

/*
 * name:      toString
 * purpose:   create a string that conveys the size of the linked list and the
              chars stored in its nodes
 * arguments: none
 * returns:   a string with the size and contents of the list
 * effects:   none
 */
std::string CharLinkedList::toString() const {
    std::stringstream ss;
    ss << "[CharLinkedList of size " << this->numItems << " <<";

    // Iterate through each node and add its char to the stringstream
    Node *curr = this->front;
    while (curr) {
        ss << curr->info;
        curr = curr->next;
    }

    ss << ">>]";
    return ss.str();
}

/*
 * name:      isEmpty
 * purpose:   determine whether the instance of CharLinkedList is empty
 * arguments: none
 * returns:   a boolean representing whether the list is empty or not
 * effects:   none
 */
bool CharLinkedList::isEmpty() const {
    if (this->front) {
        return false;
    } else {
        return true;
    }
}

/*
 * name:      freeNodes
 * purpose:   recursively delete the memory allocated to each nodes
 * arguments: none
 * returns:   a boolean representing whether the list is empty or not
 * effects:   free memory associated with this instance of CharLinkedList
 */
void CharLinkedList::freeNodes() {
    // Base case: one node that has a null next pointer
    if (not this->front) {
        return;
    } else {
        Node *next = this->front->next;
        delete this->front;
        front = next;
        this->freeNodes();
    }
}


/*
 * name:      clear
 * purpose:   make this instance into an empty linked list
 * arguments: none
 * returns:   a boolean representing whether the list is empty or not
 * effects:   delete the memory allocated by each node, set numItems to 0
 */
void CharLinkedList::clear() {
    this->freeNodes();
    this->numItems = 0;
}

/*
 * name:      size
 * purpose:   determine the number of nodes in the linked list
 * arguments: none
 * returns:   an int representing the number of nodes
 * effects:   none
 */
int CharLinkedList::size() const {
    return this->numItems;
}

/*
 * name:      first
 * purpose:   return the first char in the linked list
 * arguments: none
 * returns:   the char in the first node of the linked list
 * effects:   none
 */
char CharLinkedList::first() const {

    // check for runtime_error
    if (not front) {
        std::string error_message = "cannot get first of empty LinkedList";
        throw std::range_error(error_message);
    }

    // return char in first node
    return this->front->info;
}

/*
 * name:      last
 * purpose:   return the last char in the linked list
 * arguments: none
 * returns:   the char in the last node of the linked list
 * effects:   none
 */
char CharLinkedList::last() const {
    // check for runtime_error
    if (not front) {
        std::string error_message = "cannot get last of empty LinkedList";
        throw std::range_error(error_message);
    }

    // return char in last node
    return this->tail->info;
}

/*
 * name:      elementAt
 * purpose:   return the char at the given index in the linked list
 * arguments: none
 * returns:   the char in the given index of the linked list
 * effects:   none
 */
char CharLinkedList::elementAt(int index) const {
    // Check for range_error
    if (index > numItems or index < 0) {
        std::stringstream ss;
        ss << "index (" << index << ") not in range [0.." << numItems << ")";
        std::string error_message = ss.str();
        throw std::range_error(error_message);
    }

    // Iterate through each node in the linked list until the index is reached
    Node *curr = this->front;
    for (int i = 0; i < index; i++) {
        curr = curr->next;
    }
    
    // Return the char at the specified index
    return curr->info;
}

/*
 * name:      toReverseString
 * purpose:   provide a string containing the chars in each node in reverse
 *            order
 * arguments: none
 * returns:   a string containing size and the reversed chars
 * effects:   none
 */
std::string CharLinkedList::toReverseString() const {
    std::stringstream ss;
    ss << "[CharLinkedList of size " << this->numItems << " <<";

    // Iterate through each node and add its char to the stringstream
    Node *curr = this->tail;
    while (curr) {
        ss << curr->info;
        curr = curr->prev;
    }

    ss << ">>]";
    return ss.str();
}

/*
 * name:      pushAtBack
 * purpose:   add a new node to the back of the linked list
 * arguments: char to be the info in the new node
 * returns:   none
 * effects:   adds new node, increments numItems, adjusts tail pointer
 */
void CharLinkedList::pushAtBack(char c) {
    // Initialize a new node with provided char as info
    Node *new_node = new Node{c, nullptr};

    // Link the current tail and the new node, update the tail pointer
    if (this->front) {
        new_node->prev = this->tail;
        this->tail->next = new_node;
        this->tail = new_node;
    } else {
        this->front = new_node;
        this->tail = new_node;
        new_node->prev = nullptr;
    }

    // Increment numItems
    numItems++;
}

/*
 * name:      pushAtFront
 * purpose:   add a new node to the front of the linked list
 * arguments: char to be the info in the new node
 * returns:   none
 * effects:   adds new node, increments numItems, adjusts front pointer
 */
void CharLinkedList::pushAtFront(char c) {
    // Initialize a new node with provided char as info
    Node *new_node = new Node{c};
    new_node->prev = nullptr;

    // Link the current front and the new node, update the front pointer
    if (this->front) {
        new_node->next = this->front;
        this->front->prev = new_node;
        this->front = new_node;
    } else {
        this->front = new_node;
        this->tail = new_node;
        new_node->next = nullptr;
    }

    // Increment numItems
    numItems++;
}

/*
 * name:      findNode
 * purpose:   recursively cycle through the nodes until arriving at the node
 *            at the specified index
 * arguments: int representing the index of the node to return, pointer to 
 *            front node
 * returns:   a pointer to the node at specified index
 * effects:   none
 */
CharLinkedList::Node *CharLinkedList::findNode(Node *curr, int index) {
    // Base case: index is zero, return first node
    if (index == 0) {
        return curr;
    }
    // Recursive step:: decrement index, run again passing in next node
    else {
        index--;
        return findNode(curr->next, index);
    }
}

/*
 * name:      insertAt
 * purpose:   insert a node at the specified index with given char as info
 * arguments: char to be node info, an int representing desired index
 * returns:   none
 * effects:   adds a new node at given index, increments numItems
 */
void CharLinkedList::insertAt(char c, int index) {
    // Check for range_error
    if (index > numItems or index < 0) {
        std::stringstream ss;
        ss << "index (" << index << ") not in range [0.." << numItems << "]";
        std::string error_message = ss.str();
        throw std::range_error(error_message);
    }

    // Check if inserting at front or back
    if (index == 0) {
        pushAtFront(c);
    } else if (index == (numItems)) {
        pushAtBack(c);
    }
    else {
        // Initialize the new node
        Node *new_node = new Node{c};

        // Update next and prev pointers of adjacent nodes
        // Otherwise find the node at correct index and insert node before it
        Node *after = findNode(this->front, index);
        Node *before = after->prev;
        before->next = after->prev = new_node;
        new_node->prev = before;
        new_node->next = after;

        // Increment numItems
        numItems++;
    }
 }

/*
 * name:      insertInOrder
 * purpose:   insert element into the list in ASCII order
 * arguments: char to be node info
 * returns:   none
 * effects:   adds a new node in correct ascending order, increments numItems
 */
void CharLinkedList::insertInOrder(char c) {
    // If the list is empty, add a node at the front
    if (not this->front) {
        pushAtFront(c);
    } else {
        // If the list is not empty, compare each node to find the char that
        // will succeed the new node
        Node *curr = this->front;
        int index = 0;
        while (c > curr->info and index < numItems) {
            if (curr->next){
                curr = curr->next;
            }
            index++;
        }
        // Insert new node into the linked list
        insertAt(c, index);
    }
 }

/*
 * name:      popFromFront
 * purpose:   remove the first node in the linked list
 * arguments: none
 * returns:   none
 * effects:   removes first node, adjust front pointer, decrement numItems
 */
void CharLinkedList::popFromFront() {
    // Check for an empty list
    if (not this->front) {
        std::string error_message = "cannot pop from empty LinkedList";
        throw std::runtime_error(error_message);
    }

    // Check for a signle element list
    if (this->front == this->tail) {
        this->clear();
    } else {
        // Create a pointer to save the address of the current second node
        Node *temp = this->front->next;

        // Recycle the memory allocated to the front node
        delete this->front;
        this->front = temp;
        this->front->prev = nullptr;
        numItems--;
    }
}

/*
 * name:      popFromBack
 * purpose:   remove the last node in the linked list
 * arguments: none
 * returns:   none
 * effects:   removes last node, adjust tail pointer, decrement numItems
 */
void CharLinkedList::popFromBack() {
    // Check for an empty list
    if (not this->front) {
        std::string error_message = "cannot pop from empty LinkedList";
        throw std::runtime_error(error_message);
    }

    // Check for single element list
    if (this->front == this->tail) {
        this->clear();
    } else {
        // Create a pointer to save the address of the second to last node
        Node *temp = this->tail->prev;

        // Recycle the memory allocated to the back node
        delete this->tail;
        this->tail = temp;
        this->tail->next = nullptr;
        numItems--;
    }
}

/*
 * name:      removeAt
 * purpose:   remove the element at the specified index
 * arguments: int representing the index to remove at
 * returns:   none
 * effects:   removes specified nodes, update adjacent pointers, decrement 
 *            numItems
 */
void CharLinkedList::removeAt(int index) {
    // Check if the provided index is out of range
    if (index >= numItems or index < 0) {
        std::stringstream ss;
        ss << "index (" << index << ") not in range [0.." << numItems << ")";
        std::string error_message = ss.str();
        throw std::range_error(error_message);
    }

    // Check if index is front or back of linked list
    if (index == 0) {
        popFromFront();
    } else if (index == (numItems - 1)) {
        popFromBack();
    } else {
        // Find the node at the specified index
        Node *curr = findNode(this->front, index);

        // Store adjacent nodes in pointers
        Node *before = curr->prev;
        Node *after = curr->next;

        // Remove given node and reassign pointers
        delete curr;
        before->next = after;
        after->prev = before;

        // decrement numItems
        numItems--;
    }
}

/*
 * name:      replaceAt
 * purpose:   replace the element at the specified index with given char
 * arguments: char to replace with, int representing the index to replace at
 * returns:   none
 * effects:   replaces info at given element with provided char
 */
 void CharLinkedList::replaceAt(char c, int index) {
    // Check if index is out of range
    if (index >= numItems or index < 0) {
        std::stringstream ss;
        ss << "index (" << index << ") not in range [0.." << numItems << ")";
        std::string error_message = ss.str();
        throw std::range_error(error_message);
    }

    // Find the node at the specified element
    Node *curr = findNode(front, index);

    // Replace info with new char
    curr->info = c;
 }

/*
 * name:      concatenate
 * purpose:   replace the element at the specified index with given char
 * arguments: char to replace with, int representing the index to replace at
 * returns:   none
 * effects:   replaces info at given element with provided char
 */
 void CharLinkedList::concatenate(CharLinkedList *other) {
    // Create a copy of the second list to connect to the first
    CharLinkedList copy(*other);

    // Check if either linked list is empty
    if (other->isEmpty()) {
        return;
    } else if (this->isEmpty()) {
        *this = copy;
        return;
    }

    // Loop through the copy list and add each element to the end of this 
    // instance
    while (copy.front) {
        char c = copy.front->info;
        this->pushAtBack(c);
        copy.popFromFront();
    }
 }
/*
 *  CharLinkedList.h
 *  Lauren Wu
 *  February 3, 2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Define the interface the CharLinkedList class to be implemented in 
 *  CharLinkedList.cpp. This class will create a doubly linked list of nodes
 *  that can dynamically expand, hold characters, and perform operations such as
 *  concatenating two lists.
 *
 */
 
#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H

#include <string>

class CharLinkedList {
public:
    // Constructors
    CharLinkedList();
    CharLinkedList(char c);
    CharLinkedList(char arr[], int size);
    CharLinkedList(const CharLinkedList &other);

    // Destructor
    ~CharLinkedList();

    // Assignment Operator
    CharLinkedList &operator=(const CharLinkedList &other);

    // Functions
    std::string toString() const;
    bool isEmpty() const;
    void clear();
    int size() const;
    char first() const;
    char last() const;
    char elementAt(int index) const;
    std::string toReverseString() const;
    void pushAtBack(char c);
    void pushAtFront(char c);
    void insertAt(char c, int index);
    void insertInOrder(char c);
    void popFromFront();
    void popFromBack();
    void removeAt(int index);
    void replaceAt(char c, int index);
    void concatenate(CharLinkedList *other);

private:
    struct Node {
        char info;
        Node *next;
        Node *prev;
    };

    Node *front;
    Node *tail;
    int numItems;

    // Helper functions
    void copyNodes(const CharLinkedList &other);
    void freeNodes();
    Node *findNode(Node *curr, int index);
};

#endif

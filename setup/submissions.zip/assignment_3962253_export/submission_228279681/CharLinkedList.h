/*
 *  CharLinkedList.h
 *  Chaz (Charles) Beauchamp
 *  Created February 2nd, 2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  This header file defines a CharLinkedList consisting of character elements.
 *  It contains a multitude of functions allowing the client to access
 *  and manipulate any elements in the LinkedLists. 
 *
 */

#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H

#include <string>

class CharLinkedList {
 public:
 
    CharLinkedList();

    CharLinkedList(char c);

    CharLinkedList(char arr[], int size);

    CharLinkedList(const CharLinkedList &other);

    ~CharLinkedList();

    CharLinkedList &operator=(const CharLinkedList &other);

    bool isEmpty() const;

    void clear();

    int size() const;

    char first() const;

    char last() const;

    char elementAt(int index) const;

    std::string toString() const;

    std::string toReverseString() const;

    void pushAtBack(char c);

    void pushAtFront(char c);

    void insertAt(char c, int index);

    void insertInOrder(char c);

    void popFromFront();

    void popFromBack();

    void removeAt(int index);

    void replaceAt(char c, int index);

    void concatenate(CharLinkedList *other);
    

private:
    
    struct Node {
        char data;
        Node *next;
        Node *previous;
    };
    
    int numItems;
    
    Node *front;

    Node *back;

    

    void recycleRecursive(Node *curr);

    char elemRecursiveHelper(int target_index, int curr_index, 
    Node *curr_node) const;

};

#endif

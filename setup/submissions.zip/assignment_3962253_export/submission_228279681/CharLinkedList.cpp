/*
 *  CharLinkedList.cpp
 *  Chaz (Charles) Beauchamp
 *  February 2nd, 2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  This file implements a LinkedList consisting of character elements
 *
 */

#include "CharLinkedList.h"
#include <sstream>
#include <iostream>

using namespace std;

/*
 * name:      CharLinkedList default constructor
 * purpose:   initialize an empty LinkedList
 * arguments: none
 * returns:   none
 * effects:   numItems to 0 (also updates numItems and sets front and back)
 */

CharLinkedList::CharLinkedList() {

    front = nullptr;
    back = nullptr;
    numItems = 0;
}

/*
 * name:      CharLinkedList single character constructor
 * purpose:   initialize a LinkedList with a single character
 * arguments: none
 * returns:   none
 * effects:   numItems to 1, and sets front and back pointers
 *            to the inputted node
 */

CharLinkedList::CharLinkedList(char c) {
    // create new node and set vars
    Node *nnode = new Node;

    nnode->data = c;

    nnode->next = nullptr;

    nnode->previous = nullptr;
    
    front = nnode;

    back = nnode;

    // update size of list
    numItems = 1; 
}

/*
 * name:      CharLinkedList arr and size constructor
 * purpose:   initialize a LinkedList from an array and its size
 * arguments: none
 * returns:   none
 * effects:   numItems to size, sets front and back to first and last nodes
 */

CharLinkedList::CharLinkedList(char arr[], int size) {
    
    front = nullptr;
    back = nullptr;
    numItems = 0;
    
    for (int i = 0; i < size; i++)
    {
    // create new node and set vars
    pushAtBack(arr[i]);
    }    
}

/*
 * name:      CharLinkedList copy constructor
 * purpose:   allows deep copy of CharLinkedList to create new list
 * arguments: reference to second CharLinkedList
 * returns:   none
 * effects:   generates new CLL and copies original's data
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other) { 
    numItems = 0;
    Node *ofront = other.front;

    while (ofront != nullptr)
    {
        pushAtBack(ofront->data);
        ofront = ofront->next;
    }
}

/* 
 * CharLinkedList destructor
 * Purpose: Free heap-allocated memory of 'this'
 * Parameters: None
 * Returns: None
 */
CharLinkedList::~CharLinkedList() {
    
    if (numItems > 0)
    {
        recycleRecursive(front);     
    } 
}

/*
 * name:      CharLinkedList overloaded assignment operator
 * purpose:   allows deep copy of between currently existing CharLinkedLists
 * arguments: none
 * returns:   none
 * effects:   copies from between two CharLinkedLists
 */
CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other) {

    // Check the two lists aren't equal
    if (this != &other) {

        // empty node if necessary

        if (this->front != nullptr and this->back != nullptr)
        {
        this->recycleRecursive(front);
        }
        
        numItems = 0;
        Node *ofront = other.front;

        // copy data 
        while (ofront != nullptr)
        {
            pushAtBack(ofront->data);
            ofront = ofront->next;
        }

    }   
    return *this;
}

/*
 * name:      isEmpty
 * purpose:   determines if the CharLinkedList is empty or not
 * arguments: none
 * returns:   true if CharLinkedList contains no elements, false otherwise
 * effects:   none
 */
bool CharLinkedList::isEmpty() const {
     if (numItems == 0) {
        return true;
    } else {
        return false;
    }   
}

/*
 * name:      clear
 * purpose:   render a given CharLinkedList empty
 * arguments: none
 * returns:   none
 * effects:   empties CLL and sets numItems to 0
 */
void CharLinkedList::clear() {
    
    if (numItems > 0)
    {
        recycleRecursive(front);
    }
    
        numItems = 0;
}

/* 
 * name:      size
 * purpose:   determine the number of items in the CharLinkedList
 * arguments: none
 * returns:   number of elements currently stored in the CharLinkedList
 * effects:   none
 */
int CharLinkedList::size() const {
    return numItems; 
}

/* 
 * name:      first
 * purpose:   determines the first character in the CharLinkedList
 * arguments: none
 * returns:   first element currently stored in the CharLinkedList
 * effects:   none
 */
char CharLinkedList::first() const {
    if (numItems == 0)
    {
        throw runtime_error("cannot get first of empty LinkedList");
    }    
    return front->data;
}

/* 
 * name:      last
 * purpose:   determines the last character in the CharLinkedList
 * arguments: none
 * returns:   last element currently stored in the CharLinkedList
 * effects:   none
 */
char CharLinkedList::last() const {
    
    if (numItems == 0)
    {
        throw runtime_error("cannot get last of empty LinkedList");
    }
    
    return back->data;
};

/* 
 * name:      elementAt
 * purpose:   finds the character at a given index in the CharLinkedList
 * arguments: index
 * returns:   element stored in given integer index of the CharLinkedList
 * effects:   none
 */
char CharLinkedList::elementAt(int index) const {
     if (index < 0 or index > numItems - 1)
    {
        throw range_error("index (" + std::to_string(index) + 
        ") not in range [0.." + std::to_string(numItems) + ")");
    }

    return elemRecursiveHelper(index, 0, front);    
}

/* 
 * toString
 * Purpose: Report the state of the list as a string
 * Parameters: None
 * Returns: A string with the state of the list
 */
std::string CharLinkedList::toString() const {
    std::stringstream ss;
    ss << "[CharLinkedList of size " << this->numItems << " <<";

    Node *curr = this->front;
    while (curr != nullptr) {
        ss << curr->data;
        curr = curr->next;
    }

    ss << ">>]";

    return ss.str();
}

/* 
 * toReverseString
 * Purpose: Reverses LinkedList then reports its state as a string
 * Parameters: None
 * Returns: A string with the state of the reversed list
 */
std::string CharLinkedList::toReverseString() const {
    std::stringstream ss;
    ss << "[CharLinkedList of size " << this->numItems << " <<";

    Node *curr = this->back;
    while (curr != nullptr and front != curr) {
        cerr << curr->data;
        ss << curr->data;
        curr = curr->previous;
        cerr << curr->data;
    }

    if (numItems == 0)
    {
        ss << ">>]";
    } else {
        ss << this->front->data << ">>]";
    }
    
    return ss.str();
}

/* pushAtBack
 * Purpose: Adds a character to the back of the list
 * Parameters: The character to be added to the list
 * Returns: None
 */
void CharLinkedList::pushAtBack(char c) {

    // Create node to be added
    Node *nnode = new Node;

    // Create node to keep track of spot in list
    Node *temp = back;

    // set node vars 
    nnode->data = c;

    // access last node in list
    if (numItems == 0)
    {

        front = nnode;
        back = nnode;
        nnode->previous = nullptr;
        nnode->next = nullptr;       

    } else
    {

        temp->next = nnode;
        nnode->previous = temp;
        nnode->next = nullptr;
        back = nnode;
    }

    // update size of list
    numItems ++;
}

/*
 * name:      pushAtFront
 * purpose:   push the provided character into the front of the CharLinkedList
 * arguments: a character to add to the front of the list
 * returns:   none
 * effects:   increases num elements of CharLinkedList by 1,
 *            adds element to list
 */

void CharLinkedList::pushAtFront(char c) {   

    // create new node
    Node *nnode = new Node;

    // set node vars
    nnode->data = c;
    
    nnode->next = front;
    nnode->previous = nullptr;

    // set front elem to new node
    if (numItems >= 1) {
        front->previous = nnode; 
    }

    front = nnode;

    // update size of list
    numItems ++;

    // If size of list is 1, set nnode = to back
    if (numItems == 1)
    {
        back = nnode;
    }
}

/*
 * name:      insertAt
 * purpose:   inserts provided character into the CharLinkedList at given index
 * arguments: a character and the index at which to add it to the list
 * returns:   none
 * effects:   increases num elements of CharLinkedList by 1,
 *            adds element to list
 */

void CharLinkedList::insertAt(char c, int index) {
    
    if (index < 0 or index > numItems) {
        throw range_error("index (" + std::to_string(index) + 
        ") not in range [0.." + std::to_string(numItems) + "]" );
    }   
    // make new node

    if (index == 0)
    {
        pushAtFront(c);
        return;
    }
    if (index == numItems)
    {
        pushAtBack(c);
        return;
    }
    Node *nnode = new Node;
    nnode->data = c;
    
    // go through list
    Node *curr = front;
    int curr_index = 0;
    
    while (curr_index < index - 1)
    {
        curr = curr->next;
        curr_index++;
    }

    nnode->next = curr->next;
    nnode->previous = curr;
    
    if (curr->next != nullptr)
    {
        curr->next->previous = nnode;
    } else {
        back = nnode;
    }
    
    curr->next = nnode;
    
    numItems++;
    
}

/*
 * name:      insertInOrder
 * purpose:   inserts provided character into the CharLinkedList in ASCII order
 * arguments: a character to the list
 * returns:   none
 * effects:   increases num elements of CharLinkedList by 1,
 *            adds element to list
 */
void CharLinkedList::insertInOrder(char c) {
    if (numItems == 0)
    {
        pushAtBack(c);
    } else {
    
        Node *curr = front;
        int curr_index = 0;

        while (int(c) >= int(curr->data) and (curr_index < numItems - 1))
            {
            curr = curr->next;
            curr_index++;
            }

        if (int(c) < int(elementAt(curr_index))) 
        insertAt(c, curr_index);
    }
};

/*
 * name:      popFromFront
 * purpose:   removes character from front of list
 * arguments: none
 * returns:   none
 * effects:   removes first element in list, subtracts 1 from numItems
 */
void CharLinkedList::popFromFront() {

    if (numItems == 0)
    {
        throw runtime_error("cannot pop from empty LinkedList");
    }

    if (numItems == 1)
    {
        delete front;
        front = nullptr;
        back = nullptr;
        numItems = 0;
    } else {
        front = front->next;
        delete front->previous;
        front->previous = nullptr;
        numItems --;
    }
};

/*
 * name:      popFromBack
 * purpose:   removes character from end of list
 * arguments: none
 * returns:   none
 * effects:   removes last element in list, subtracts 1 from numItems
 */

void CharLinkedList::popFromBack() {
    if (numItems == 0)
    {
        throw runtime_error("cannot pop from empty LinkedList");
    }

    if (numItems == 1)
    {
        delete front;
        front = nullptr;
        back = nullptr;
        numItems = 0;
    } else {

        back = back->previous;
        delete back->next;
        back->next = nullptr;
        numItems --;
    }
}

/*
 * name:      removeAt
 * purpose:   removes character at provided index
 * arguments: the index at which to remove element
 * returns:   none
 * effects:   removes specified element in list
 */
void CharLinkedList::removeAt(int index) {

     if (numItems == 0)
    {
        throw range_error("index (" + std::to_string(index) + 
        ") not in range [0.." + std::to_string(numItems) + ")" );
    } else {

        if (index < 0 or index > numItems - 1) {
            throw range_error("index (" + std::to_string(index) + 
            ") not in range [0.." + std::to_string(numItems) + ")" );
        }

         // if at front pop from front, if at back pop from back, else...
        if (index == 0)
        {
            popFromFront();
            return;
        } else if (index == numItems - 1)
            {
                popFromBack();
                return;
            }
        else {
            Node *temp = front;
            int curr_index = 0;
            while (curr_index != index)
            {
                temp = temp->next;
                curr_index++;
            }
      
            temp->previous->next = temp->next;
            temp->next->previous = temp->previous;
            delete temp;
            numItems--;
            }
        }
    }

/*
 * name:      replaceAt
 * purpose:   replaces character at provided index with given character
 * arguments: a character and the index at which to replace it with
 * returns:   none
 * effects:   replaces specified element in list
 */
void CharLinkedList::replaceAt(char c, int index) {

     if (numItems == 0)
    {
        if (index > 0) {
        throw range_error("index (" + std::to_string(index) + 
        ") not in range [0.." + std::to_string(numItems) + ")" );
    }
        pushAtBack(c);
    
    } else {

    if (index < 0 or index > numItems - 1) {
        throw range_error("index (" + std::to_string(index) + 
        ") not in range [0.." + std::to_string(numItems) + ")" );
    }

        Node *temp = front;
        int curr_index = 0;
        while (curr_index != index)
        {
            temp = temp->next;
            curr_index++;
        }

        temp->data = c;
    }
}

/*
 * name:      concatenate
 * purpose:   concatenates two Linked Lists
 * arguments: pointer to second Linked List
 * returns:   none
 * effects:   adds nodes of second list to those of first and
 *            increases number of items by number of nodes in second list
 */

void CharLinkedList::concatenate(CharLinkedList *other) {
    int curr_index = 0;
    Node *temp = other->front;
    int orignumItems = other->numItems;

    // loop through each node in other
    while (curr_index < orignumItems)
    {
        pushAtBack(temp->data);
        temp = temp->next;
        curr_index++;
    }   
}

/*
 * Helper function for CharLinkedList destructor
 * Purpose: Recursively free heap-allocated memory for each node
 * Parameters: None
 * Returns: None
 */
void CharLinkedList::recycleRecursive(Node *curr) {
    if (curr == nullptr)
    {
        return;
    } 
    else 
    {
        Node *next = curr->next;
        delete curr;
        recycleRecursive(next);
    }
}

/* 
 * name:      elementAt helper function
 * purpose:   recursive function to help find 
 *            the character at a given index in the CharLinkedList
 * arguments: node to begin at
 * returns:   element stored in given integer index of the CharLinkedList
 * effects:   none
 */

char CharLinkedList::elemRecursiveHelper(int target_index, int curr_index,
Node *curr_node) const {

    //   if curr and target arent equal - call recursively on curr-node->next
    // increase curr index by 1
        
    if (curr_index != target_index)
    {   
        curr_node = curr_node->next;
        curr_index++;
        return elemRecursiveHelper(target_index, curr_index, curr_node);
    } 
        return curr_node->data;
}


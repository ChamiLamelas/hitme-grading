/*
 *  CharLinkedList.cpp
 *  Jennifer Luo
 *  02.03.23
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Purpose: Functions for the implementation of a linked list that allows the 
 *           user to manipulate a list.
 *
 */

#include "CharLinkedList.h"
#include <sstream>
#include <iostream>
using namespace std;

/*
 * name:      CharLinkedList default constructor
 * purpose:   initialize an empty CharLinkedList
 * arguments: none
 * returns:   none
 * effects:   sets front and back pointers to nullptr and list_size to 0
 */
CharLinkedList::CharLinkedList() 
{
    front = nullptr;
    back = nullptr;
    list_size = 0;
}

/*
 * name:      LinkedList constructor
 * purpose:   initialize a CharLinkedList with character c
 * arguments: a character to initialize the CharLinkedList
 * returns:   none
 * effects:   sets front and back pointers to the first node and list_size to 1
 */
CharLinkedList::CharLinkedList(char c) 
{
    Node *new_node = newNode(c, nullptr, nullptr);
    front = new_node;
    back = new_node;
    list_size = 1;
}

/*
 * name:      LinkedList constructor
 * purpose:   initialize a CharLinkedList with array arr[]
 * arguments: an array of characters and array size to initialize the 
 *              CharLinkedList
 * returns:   none
 * effects:   sets front and back pointers, sets list_size to size
 */
CharLinkedList::CharLinkedList(char arr[], int size) 
{
    front = nullptr;
    back = nullptr;
    list_size = 0;
    for (int i = 0 ; i < size; i++) {
        pushAtBack(arr[i]);
    }
}

/*
 * name:      backNode
 * purpose:   gets the last node of the linked list
 * arguments: none
 * returns:   returns the back node
 * effects:   none
 */
CharLinkedList::Node *CharLinkedList::backNode() 
{
    Node *curr = front;
    for (int i = 0; i < list_size - 1; i++) {
        curr = curr->next;
    }
    return curr;
}

/*
 * name:      LinkedList constructor
 * purpose:   create copy of other CharLinkedList
 * arguments: address of other CharLinkedList to initialize the CharLinkedList
 * returns:   none
 * effects:   list_size to size of other and initializes the front and back 
 *              nodes
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other) 
{
    if (other.size() > 0) {
        list_size = other.size();
        front = copyRecursive(other.front);
        back = backNode();
    }
}

/*
 * name:      assignment operator
 * purpose:   makes a deep copy of other CharLinkedList
 * arguments: the address of other CharLinkedList
 * returns:   none
 * effects:   list_size to other size and initializes CharLinkedList to
 *              that of the other CharLinkedList
 */
CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other) 
{
    if (this == &other) {
        return *this;
    }

    copyRecursive(front);

    list_size = other.size();
    front = copyRecursive(other.front);
    back = backNode();
    return *this;
}

/*
 * name:      copyRecursive
 * purpose:   helper function for the assignment operator
 * arguments: the pointer to the current node
 * returns:   returns the first node of the linked list
 * effects:   creates a linked list
 */
CharLinkedList::Node *CharLinkedList::copyRecursive(Node *curr)
{
    if (curr == nullptr) {
        return nullptr;
    }
    Node *new_node = newNode(curr->value, curr, copyRecursive(curr->next));
    return new_node;
}

/*
 * name:      newNode
 * purpose:   creates a new node
 * arguments: the character, previous node, and next node of the new node
 * returns:   the new node
 * effects:   creates a new node
 */
CharLinkedList::Node *CharLinkedList::newNode(char newData, Node *prev_node, 
Node *next) {
    //allocate new node on heap using struct in headerfile
    Node *new_node = new Node; 
    new_node->value = newData;
    new_node->prev = prev_node;
    new_node->next = next;

    return new_node;
}

/*
 * name:      LinkedList destructor
 * purpose:   frees up memory on the heap
 * arguments: none
 * returns:   none
 * effects:   deletes the data from this
 */
CharLinkedList::~CharLinkedList()
{
    recycleRecursive(front);
}

/*
 * name:      recycleRecursive
 * purpose:   helper function for the destructor
 * arguments: the pointer to the current node
 * returns:   none
 * effects:   deletes the linked list
 */
void CharLinkedList::recycleRecursive(Node *curr)
{
    if (curr == nullptr) {
        return;
    } else {
        Node *next = curr->next;
        recycleRecursive(next);
        delete curr;
    }
}

/*
 * name:      isEmpty
 * purpose:   determines if the CharLinkedList is empty
 * arguments: none
 * returns:   true if CharLinkedList contains no elements, false otherwise
 * effects:   none
 */
bool CharLinkedList::isEmpty() const 
{
    return list_size == 0;
}

/*
 * name:      clear
 * purpose:   clears the list
 * arguments: none
 * returns:   none
 * effects:   sets list size to 0
 */
void CharLinkedList::clear() 
{
    list_size = 0;
}

/*
 * name:      size
 * purpose:   determine the number of items in the CharLinked
 * arguments: none
 * returns:   the size of the CharLinkedList
 * effects:   none
 */
int CharLinkedList::size() const 
{
    return list_size;
}

/*
 * name:      first
 * purpose:   determine the first item of the CharLinkedList
 * arguments: none
 * returns:   the first element of the CharLinkedList and throws a runtime_error
 *              if the CharLinkedList is empty
 * effects:   none
 */
char CharLinkedList::first() const 
{
    if (isEmpty()) {
        throw std::runtime_error("cannot get first of empty LinkedList");
    } else {
        return elementAt(0);
    }
}

/*
 * name:      last
 * purpose:   determine the last item of the CharLinkedList
 * arguments: none
 * returns:   the last element of the CharLinkedList and throws a runtime_error
 *              if the CharLinkedList is empty
 * effects:   none
 */
char CharLinkedList::last() const 
{
    if (isEmpty()) {
        throw std::runtime_error("cannot get last of empty LinkedList");
    } else {
        return elementAt(list_size - 1);
    }
}

/*
 * name:      elementAt
 * purpose:   determine the element at the input index
 * arguments: the index of the element we want to get
 * returns:   the element of the CharLinkedList at the given index and throws a 
 *              runtime_error if the size of the CharLinkedList is empty
 * effects:   none
 */
char CharLinkedList::elementAt(int index) const 
{
    //checks if the index is valid, throws a range error otherwise
    if (index < 0 or index >= list_size) {
        stringstream ss;
        ss << "index (" << index << ") not in range [0.." << list_size << ")";
        throw std::range_error(ss.str());
    }
    //gets the value at the given index
    Node *curr = front;
    return elementAtRecursive(index, 0, curr)->value;
}

/*
 * name:      elementAtRecursive
 * purpose:   recursive helper function to elementAt
 * arguments: the index to stop at, the current index, and the current node
 * returns:   the element of the CharLinkedList at the given index
 * effects:   none
 */
CharLinkedList::Node *CharLinkedList::elementAtRecursive(int target_index, 
int index, Node *curr) const
{
    if (index == list_size) {
        return nullptr;
    }
    if (index == target_index) {
        return curr;
    }
    return elementAtRecursive(target_index, index + 1, curr->next);
}

/*
 * name:      toString
 * purpose:   turns the list into a string, and returns it
 * arguments: none
 * returns:   a string representation of the list
 * effects:   none
 */
std::string CharLinkedList::toString() const 
{
    Node *curr = front;
    std::stringstream ss;
    ss << "[CharLinkedList of size " << list_size << " <<";
    while (curr != nullptr) {
        ss << curr->value;
        curr = curr->next;
    }
    ss << ">>]";
    return ss.str();
}

/*
 * name:      toReverseString
 * purpose:   turns the list into a reversed string, and returns it
 * arguments: none
 * returns:   a string representation of a reversed list
 * effects:   none
 */
std::string CharLinkedList::toReverseString() const 
{
    Node *curr = back;
    std::stringstream ss;
    ss << "[CharLinkedList of size " << list_size << " <<";
    for (int i = list_size - 1; i >= 0; i--) {
        ss << elementAt(i);
    }
    ss << ">>]";
    return ss.str();
}

/*
 * name:      pushAtBack
 * purpose:   push the provided char into the back of the CharLinkedList
 * arguments: a char to add to the back of the list
 * returns:   none
 * effects:   increases num elements of CharLinkedList by 1,
 *            adds element to end of list
 */
void CharLinkedList::pushAtBack(char c) 
{
    Node *new_node;
    //appends a new character to the end of the list
    if (list_size == 0) {
        //creates first node
        new_node = newNode(c, nullptr, nullptr);
        front = new_node;
    } else {
        //inserts new node to the end of the list
        Node *prev_node;
        prev_node = back;
        new_node = newNode(c, prev_node, nullptr);
        prev_node->next = new_node;
    }
    back = new_node;
    list_size++;
}

/*
 * name:      pushAtFront
 * purpose:   push the provided char into the front of the CharLinkedList
 * arguments: a char to add to the front of the list
 * returns:   none
 * effects:   increases num elements of CharLinkedList by 1,
 *            adds element to front of list
 */
void CharLinkedList::pushAtFront(char c) 
{
    Node *new_node;
    //appends a new character to the list
    if (list_size == 0) {
        //creates first node
        new_node = newNode(c, nullptr, nullptr);
        back = new_node;
    } else {
        //inserts new node to the front of the list
        Node *next_node = front;
        new_node = newNode(c, nullptr, next_node);
    }
    front = new_node;
    list_size++;
}

/*
 * name:      insertAt
 * purpose:   insert the provided char into the CharLinkedList at a given index
 * arguments: a char to add to list and the index at which we want to add it at
 * returns:   none
 * effects:   increases num elements of CharLinkedList by 1,
 *            adds element to the list at given index
 */
void CharLinkedList::insertAt(char c, int index) 
{
    //check if index is within the range
    if (index > list_size or index < 0) {
        stringstream ss;
        ss << "index (" << index << ") not in range [0.." << list_size << "]";
        throw std::range_error(ss.str());
    }
    //inserts character in list
    if (index == 0) {
        pushAtFront(c);
    } else if (index == list_size) {
        pushAtBack(c);
    } else {
        Node *curr = front;
        Node *prev_node = front;
        for (int i = 0; i < index; i++) {
            curr = curr->next;
            if (i != index - 1) {
                prev_node = prev_node->next;
            }
        }
        //creates new node to be inserted
        Node *new_node = newNode(c, prev_node, curr);
        prev_node->next = new_node;
        curr->prev = new_node;
        list_size++;
    }
}

/*
 * name:      insertInOrder
 * purpose:   insert the provided char into the CharLinkedList so that the 
 *              CharLinkedList is ordered
 * arguments: a char to add to list
 * returns:   none
 * effects:   increases num elements of LinkedList by 1,
 *            adds element to the list so that the CharLinkedList is in order
 */
void CharLinkedList::insertInOrder(char c) 
{
    Node *curr = front;
    bool add_to_end = true;
    for (int i = 0; i < list_size; i++) {
        if (curr->value > c) {
            insertAt(c, i);
            add_to_end = false;
            i = list_size;
        }
        curr = curr->next;
    }
    //pushes character at back if it is never inserted
    if (add_to_end) {
        pushAtBack(c);
    }
}

/*
 * name:      popFromFront
 * purpose:   removes the first item of the list
 * arguments: none
 * returns:   throws range_error if LinkedList is empty
 * effects:   decreases num elements of LinkedList by 1,
 *            removes the first element from the list
 */
void CharLinkedList::popFromFront() 
{
    if (list_size == 0) {
        throw std::runtime_error("cannot pop from empty LinkedList");
    }
    Node *front_node = front;
    front = front_node->next;
    delete front_node;
    list_size--;
}

/*
 * name:      popFromBack
 * purpose:   removes the last item of the list
 * arguments: none
 * returns:   throws range_error if LinkedList is empty
 * effects:   decreases num elements of LinkedList by 1,
 *            removes the last element from the list
 */
void CharLinkedList::popFromBack() 
{
    if (list_size == 0) {
        throw std::runtime_error("cannot pop from empty LinkedList");
    }
    //decrease list size
    list_size--;
    //gets rid of back node
    Node *back_node = back;
    Node *new_back = backNode();
    new_back->next = nullptr;
    back = new_back;
    delete back_node;
}

/*
 * name:      removeAt
 * purpose:   removes the element of the list at the given index
 * arguments: the index of the element we want to remove
 * returns:   throws range_error if the given index is out of bounds
 * effects:   decreases num elements of LinkedList by 1,
 *            removes the element at the given index from the list
 */
void CharLinkedList::removeAt(int index) 
{
    //check if index is within the range
    if (index < 0 or index >= list_size) {
        stringstream ss;
        ss << "index (" << index << ") not in range [0.." << list_size << ")";
        throw std::range_error(ss.str());
    }
    //inserts character in list
    if (index == 0) {
        popFromFront();
    } else if (index == list_size - 1) {
        popFromBack();
    } else {
        Node *curr = front;
        Node *prev_node = front;
        for (int i = 0; i < index; i++) {
            curr = curr->next;
            prev_node = curr->prev;
        }
        //gets rid of node
        prev_node->next = curr->next;
        Node *next_node = curr->next;
        next_node->prev = prev_node;
        delete curr;
        list_size--;
    }
}

/*
 * name:      replaceAt
 * purpose:   replaces the element of the list at the given index with the given
 *              char c
 * arguments: the index of the element we want to replace and the char we want 
 *              to replace it with
 * returns:   throws range_error if the given index is out of bounds
 * effects:   replaces the element at the given index from the list with given
 *              character
 */
void CharLinkedList::replaceAt(char c, int index) {
    removeAt(index);
    insertAt(c, index);
}

/*
 * name:      concatenate
 * purpose:   concatenates a linked list with the other linked list
 * arguments: a pointer to the other CharLinkedList
 * returns:   none
 * effects:   adds a copy of the linked list pointed to by the parameter value 
 *              to the end of the linked list the function was called from
 */
void CharLinkedList::concatenate(CharLinkedList *other) {
    
    int other_size = other->size();
    for (int i = 0; i < other_size; i++) {
        char elem = other->elementAt(i);
        pushAtBack(elem);
    }
}
/*
 *  CharLinkedList.h
 *  Jennifer Luo
 *  02.04.2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Purpose: Define functions and variables for the implementation of a 
 *           linked list
 *
 */

#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H
#include <string>

class CharLinkedList {
public:
    CharLinkedList();
    CharLinkedList(char c);
    CharLinkedList(char arr[], int size);
    CharLinkedList(const CharLinkedList &other);

    ~CharLinkedList();
    CharLinkedList &operator=(const CharLinkedList &other);
    bool isEmpty() const;
    void clear();
    int size() const;
    char first() const;
    char last() const;
    char elementAt(int index) const;
    std::string toString() const;
    std::string toReverseString() const;
    void pushAtBack(char c);
    void pushAtFront(char c);
    void insertAt(char c, int index);
    void insertInOrder(char c);
    void popFromFront();
    void popFromBack();
    void removeAt(int index);
    void replaceAt(char c, int index);
    void concatenate(CharLinkedList *other);
    void printList();

private:
    struct Node {
        Node *prev;
        Node *next;
        char value;
    };

    Node *front;
    Node *back;
    int list_size;

    Node *newNode(char newData, Node *prev_node, Node *next);
    void recycleRecursive(Node *curr);
    Node *copyRecursive(Node *curr);
    Node *backNode();
    Node *elementAtRecursive(int target_index, int index, Node *prev) const;
};

#endif

/*
 * unit_tests.h
 *
 * CS 15 homework 1
 * by Tyler Calabrese, January 2021
 *
 * edited by: Milod Kazerounian, January 2022
 *
 * Uses Matt Russell's unit_test framework to test the CharArrayList class.
 *
 * Instructions for using testing framework can be found at in CS 15's lab
 * 1 -- both in the spec and in the provided ArrayList_tests.h and Makefile.
 * More in-depth information for those who are curious as to how it works can
 * be found at http://www.github.com/mattrussell2/unit_test.
 */
#include "CharLinkedList.h"
#include <cassert>
#include <string>
#include <ostream>

/********************************************************************\
*                       CHAR ARRAY LIST TESTS                        *

\********************************************************************/

/* To give an example of thorough testing, we are providing
 * the unit tests below which test the insertAt function. Notice: we have
 * tried to consider all of the different cases insertAt may be
 * called in, and we test insertAt in conjunction with other functions!
 *
 * You should emulate this approach for all functions you define.
 */


/* Tests correct identification of first and last
* Should identify that 'a' is the first and 'e' is the last element.
*/

/*tests the first() function which should throw an error given that the 
list is empty and should get the first node given a linked list*/
void test_first() {
    CharLinkedList test_empty;
    bool error_thrown;
    std::string error_message = "";
    try {
        test_empty.first();
    } catch (const std::runtime_error &e) {
        error_thrown = true;
        error_message = e.what();
    }
    assert(error_thrown);
    assert(error_message == "cannot get first of empty LinkedList");
    
    CharLinkedList test_one('a');
    assert(test_one.first() == 'a');
}

/*tests elementAt() which throws an error if the index is invalid and gets the
element otherwise*/
void test_elementAt() {
    char temp[4] = {'a','c','d','e'};
    CharLinkedList test_list(temp, 4);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(test_list.size() - 1) == 'e');

    bool range_error_thrown = false;
    std::string error_message = "";
    try {
        test_list.elementAt(test_list.size() + 1);
    } catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (5) not in range [0..4)");
}

/* Tests removeAt
* Tests removeAt when the index is invalid, removes when valid
*/
void test_removeAt() {
    char temp[4] = {'a','c','d','e'};
    CharLinkedList test_list(temp, 4);
    bool range_error_thrown = false;
    std::string error_message = "";
    try {
        test_list.removeAt(test_list.size() + 1);
    } catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (5) not in range [0..4)");
    test_list.removeAt(2);

    assert(test_list.toString() == "[CharLinkedList of size 3 <<ace>>]");
    test_list.removeAt(0);
    test_list.removeAt(test_list.size() - 1);
    assert(test_list.toString() == "[CharLinkedList of size 1 <<c>>]");
    range_error_thrown = false;
    try {
        test_list.removeAt(-1);
    } catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (-1) not in range [0..1)");
}

/* Tests replaceAt
* Should give back errors when given invalid indexes and replaces the value
* when given a valid index
*/
void test_replaceAt() {
    char temp[4] = {'a','c','d','e'};
    CharLinkedList test_list(temp, 4);
    bool range_error_thrown = false;
    std::string error_message = "";
    try {
        test_list.replaceAt('a', test_list.size() + 1);
    } catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (5) not in range [0..4)");
    test_list.replaceAt('b', 1);
    assert(test_list.toString() == "[CharLinkedList of size 4 <<abde>>]");
    test_list.replaceAt('f', 0);
    test_list.replaceAt('g', test_list.size() - 1);
    assert(test_list.toString() == "[CharLinkedList of size 4 <<fbdg>>]");
    range_error_thrown = false;
    try {
        test_list.replaceAt('a', -1);
    } catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (-1) not in range [0..4)");
}

/* Tests toString and toReverseString
* Should return a string representation of lists of size 0, 1, and 7
*/
void test_toString() {
    CharLinkedList empty_list;
    assert(empty_list.toString() == "[CharLinkedList of size 0 <<>>]");
    CharLinkedList list('a');
    assert(list.toString() == "[CharLinkedList of size 1 <<a>>]");
    char temp[7] = {'a','b','c','d','e','f','g'};
    CharLinkedList list1(temp, 7);
    assert(list1.toString() == "[CharLinkedList of size 7 <<abcdefg>>]");
}

/* Tests first() and last()
* Should the first and last elements of list
*/
void test_basic_first_last() {
    char temp[4] = {'a','c','d','e'};
    CharLinkedList test_list(temp, 4);

    char temp2[3] = {'f','g','h'};
    CharLinkedList test_list2(temp2, 3);
    
    assert(test_list.first() == 'a');
    assert(test_list.last() == 'e');
}

/* Tests whether error thrown given invalid index for first and last
* Should throw runtime error messages
*/
void test_first_last_runtime_error() {
    //test first
    bool runtime_error_thrown = false;
    std::string error_message = "";
    CharLinkedList test_list;
    try {
        test_list.first();
    } catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }
    test_list.toString();
    assert(runtime_error_thrown);
    assert(error_message == "cannot get first of empty LinkedList");

    //test last
    runtime_error_thrown = false;
    try {
        test_list.last();
    } catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }
    test_list.toString();
    assert(runtime_error_thrown);
    assert(error_message == "cannot get last of empty LinkedList");
}

/* Tests concatenation of array lists
* Should concatenate the array list the function runs on with the input list
* and return 8 when concatenating test_list with itself and 11 when 
* concatenating that with test_list2
*/
void test_concatenate() {
    char temp[4] = {'a','c','d','e'};
    char temp2[3] = {'f','g','h'};

    CharLinkedList test_list(temp, 4);
    CharLinkedList test_list2(temp2, 3);

    test_list.concatenate(&test_list);
    assert(test_list.size() == 8);
    test_list.concatenate(&test_list2);
    assert(test_list.size() == 11);
}

/* test concatenate() on empty lists
* should give size 0 and no error
*/
void test_concatenate_empty() {
    CharLinkedList test_list;
    CharLinkedList test_list2;
    test_list.concatenate(&test_list2); 
    assert(test_list.size() == 0);
}

/* test concatenate() on one empty and one non-empty list
*/
void test_concatenation_one_empty() {
    char temp[4] = {'a','c','d','e'};
    CharLinkedList test_list(temp, 4);
    CharLinkedList test_list2;

    test_list.concatenate(&test_list2);
    test_list2.concatenate(&test_list);

    assert(test_list.toString() == "[CharLinkedList of size 4 <<acde>>]");
    assert(test_list2.toString() == "[CharLinkedList of size 4 <<acde>>]");
}

/* Tests pushAtFront and pushAtBack
* Should add 'a' to the front and 'c' to the back of the array list to make 
* string "abc" when toString() is called
*/
void test_push() {
    CharLinkedList test_list('b');
    test_list.pushAtFront('a');
    test_list.pushAtBack('c');
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(test_list.size() - 1) == 'c');
    assert(test_list.elementAt(1) == 'b');
}

/* Tests popFromFront and popFromBack()
* Should remove 'H' from the front and 'y' from the back of the array list to 
* make string "app" when toString() is called
*/
void test_pop() {
    char temp[5] = {'H','a','p','p','y'};
    CharLinkedList test_list(temp, 5);
    test_list.popFromFront();
    test_list.popFromBack();
    assert(test_list.toString() == "[CharLinkedList of size 3 <<app>>]");
}

/* Tests popFromFront and popFromBack() given an empty linked list
* Should give an error
*/
void test_emptypop() {
    CharLinkedList emptylist;
    bool runtime_thrown = false;
    std::string error_message = "";
    try {
        emptylist.popFromBack();
    } catch (const std::runtime_error &e) {
        runtime_thrown = true;
        error_message = e.what();
    }
    assert(runtime_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
    runtime_thrown = false;
    error_message = "";
    try {
        emptylist.popFromFront();
    } catch (const std::runtime_error &e) {
        runtime_thrown = true;
        error_message = e.what();
    }
    assert(runtime_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

/* Tests toString and toReverseString
* Should return a string representation of the array of size 5 ("Happy" for a
* simple toString and "yppaH" when reversing the string
*/
void test_to_strings() {
    char temp[5] = {'H','a','p','p','y'};
    CharLinkedList test_list(temp, 5);

    assert(test_list.toReverseString() == "[CharLinkedList of size 5 <<yppaH>>]"
        );
    assert(test_list.toString() == "[CharLinkedList of size 5 <<Happy>>]");
}

/* Tests removeAt and replaceAt
* Should remove 'H' from the array list and replace the first 'p' with 'l'
*/
void test_remove_replace() {
    char temp[5] = {'H','a','p','p','y'};
    CharLinkedList test_list(temp, 5);

    test_list.removeAt(0);
    assert(test_list.size() == 4);
    assert(test_list.elementAt(0) == 'a');

    test_list.replaceAt('l', 1);
    assert(test_list.elementAt(1) == 'l');
}

/* Tests insertInOrder
* Should insert 'c' in between 'b' and 'd' at index 2 and 3
*/
void test_insertInOrder() {
    char temp[5] = {'a','b','d','e','f'};
    CharLinkedList test_list(temp, 5);

    test_list.insertInOrder('b');
    // test_list.insertInOrder('c');

    assert(test_list.elementAt(2) == 'b');
    // assert(test_list.elementAt(3) == 'c');
    assert(test_list.toString() == "[CharLinkedList of size 6 <<abbdef>>]");
}

/* Tests clear and isEmpty
* Afterwards, test_list should be empty and the other two array lists shoud not 
* be
*/
void test_clear() {
    CharLinkedList test_list('b');
    CharLinkedList test_list2(test_list);
    CharLinkedList test_list3 = test_list;

    test_list.clear();
    assert(test_list.isEmpty());
    assert(test_list2.isEmpty() == 0);
    assert(test_list3.isEmpty() == 0);
}

/* Tests clear() on empty and tests size()
* Afterwards, test_list should be empty and the other two array lists shoud not 
* be
*/
void test_clear_empty() {
    CharLinkedList test;
    test.clear();
    assert(test.size() == 0);
    assert(test.isEmpty());
}


// Tests correct insertion into an empty AL.
// Afterwards, size should be 1 and element at index 0
// should be the element we inserted.

void insertAt_empty_correct() { 

    CharLinkedList test_list;
    assert(test_list.isEmpty() == 1);
    test_list.insertAt('a', 0);
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');

}

/*tests the insertAt function when inserted on the size and at 0
should just add to the back and front
*/
void insertAt_size() {
    CharLinkedList test_list('a');
    test_list.insertAt('b', test_list.size());
    assert(test_list.elementAt(test_list.size() - 1) == 'b');

    test_list.insertAt('c', 0);
    assert(test_list.elementAt(0) == 'c');
}

// Tests incorrect insertion into an empty AL.
// Attempts to call insertAt for index larger than 0.
// This should result in an std::range_error being raised.
void insertAt_empty_incorrect() {

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    // insertAt for out-of-range index
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
    // if insertAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
        range_error_thrown = true;
        error_message = e.what();
    }

    // out here, we make our assertions
    test_list.toString();
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0]");
    
}

// // Tests correct insertAt for front of 1-element list.
void insertAt_front_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at front
    test_list.insertAt('b', 0);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'a');
    
}

// // Tests correct insertAt for back of 1-element list.
void insertAt_back_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at back
    test_list.insertAt('b', 1);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    
}

// // Tests calling insertAt for a large number of elements.
// // Not only does this test insertAt, it also checks that
// // array expansion works correctly.
void insertAt_many_elements() {
    
    CharLinkedList test_list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.insertAt('a', i);
    }

    assert(test_list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
    
}

void removeAt_many_elements() {
    
    CharLinkedList test_list;

    // insert 1000 elements
    for (int i = 0; i < 10000; i++) {
        // always insert at the back of the list
        test_list.insertAt('a', i);
    }

    for (int i = 0; i < 10000; i++) {
        test_list.removeAt((test_list.size() - 1)/2);
    }
    
}

// // Tests insertion into front of a larger list
void insertAt_front_large_list() {
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    test_list.insertAt('y', 0);

    assert(test_list.size() == 10);
    assert(test_list.elementAt(0) == 'y');
    assert(test_list.toString() == "[CharLinkedList of size 10 <<yabczdefgh>>]"
    );

}

// // Tests insertion into the back of a larger list
void insertAt_back_large_list() {

    char test_arr[10] = { 'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 10);  

    test_list.insertAt('x', 10);

    assert(test_list.size() == 11);
    assert(test_list.elementAt(10) == 'x');
    assert(test_list.toString() == 
    "[CharLinkedList of size 11 <<yabczdefghx>>]"); 

}

// // Tests insertion into the middle of a larger list
void insertAt_middle_large_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.insertAt('z', 3);

    assert(test_list.size() == 9);
    assert(test_list.elementAt(3) == 'z');
    assert(test_list.toString() == "[CharLinkedList of size 9 <<abczdefgh>>]");

}

// // Tests out-of-range insertion for a non-empty list.
void insertAt_nonempty_incorrect() {
   
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8]");

}
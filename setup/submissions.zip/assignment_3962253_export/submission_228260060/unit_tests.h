/*
 *  unit_tests.h
 *  Cooper Wallman
 *  Created on 2/3/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  Tests proper functionality and edge cases of each possible linkedList
 *  function. 
 *
 */

#include "CharLinkedList.h"
#include <cassert>
#include <iostream>
#include <string>
#include <stdexcept>

using namespace std;

// Tests the empty constructor
void empty_constructor_test() 
{
    CharLinkedList list;

    assert(list.isEmpty());
}

// Tests the single character constructor
void single_constructor_test()
{
    CharLinkedList list('a');

    assert(list.size() == 1);
    assert(list.elementAt(0) == 'a');
}

// Tests the multiple element constructor
void list_constructor_test()
{
    char array[3] = {'a', 'b', 'c'};
    CharLinkedList list(array, 3);

    assert(list.elementAt(0) == 'a');
    assert(list.elementAt(1) == 'b');
    assert(list.elementAt(2) == 'c');
}

// Tests a correct instance of the elementAt() function
void elementAt_correct()
{
    char array[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(array, 5);

    assert(list.elementAt(0) == 'a');
    assert(list.elementAt(1) == 'b');
    assert(list.elementAt(2) == 'c');
    assert(list.elementAt(3) == 'd');
    assert(list.elementAt(4) == 'e');
}

// Tests out of range error for elementAt()
void elementAt_incorrect()
{
    char array[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(array, 5);

    // Error message test
    bool range_error_thrown = false;
    std::string error_message = "";
    try {
        list.elementAt(10);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (10) not in range [0..5)");
}

// Tests that toString is working
void toString_correct()
{
    char array[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(array, 5);

    assert(list.toString() == "[CharLinkedList of size 5 <<abcde>>]");
}

// Tests that toReverseString is working
void toReverseString_correct()
{
    char array[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(array, 5);

    assert(list.toReverseString() == "[CharLinkedList of size 5 <<edcba>>]");
}

// Tests correct instance of first
void first_correct()
{
    char array[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(array, 5);

    assert(list.first() == 'a');
}

// Tests the case of trying to find the first element of empty list
void first_incorrect_empty()
{
    CharLinkedList list;
    
    // Error message test
    bool runtime_error_thrown = false;
    std::string error_message = "";
    try {
        list.first();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot get first of empty LinkedList");
}

// Tests correct instance of last
void last_correct()
{
    char array[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(array, 5);

    assert(list.last() == 'e');
}

// Tests the case of trying to find the last element of empty list
void last_incorrect_empty()
{
    CharLinkedList list;
    
    // Error message test
    bool runtime_error_thrown = false;
    std::string error_message = "";
    try {
        list.last();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot get last of empty LinkedList");
}

// Tests functionality of clear function
void clear_test()
{
    char array[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(array, 5);

    list.clear();

    assert(list.isEmpty());
    assert(list.size() == 0);
}

// Tests proper pushAtBack() functionality
void pushAtBack_test()
{
    char array[3] = {'a', 'b', 'c'};
    CharLinkedList list(array, 3);
    
    // Case where push back on list with multiple elements
    list.pushAtBack('d');
    assert(list.last() == 'd');
    
    // Case where list pushes back its own element
    list.pushAtBack(list.elementAt(0));
    assert(list.last() == 'a');
    assert(list.size() == 5);
    
    list.clear();
    
    // Case where list pushes back on empty list
    list.pushAtBack('a');
    assert(list.last() == 'a');
}

// Tests proper pushAtFront() functionality
void pushAtFront_test()
{
    char array[3] = {'a', 'b', 'c'};
    CharLinkedList list(array, 3);
    
    // Case where push front on list with multiple elements
    list.pushAtFront('d');
    assert(list.first() == 'd');
    
    // Case where list pushes front its own element
    list.pushAtFront(list.last());
    assert(list.first() == 'c');
    assert(list.size() == 5);
    
    list.clear();
    
    // Case where list pushes front on empty list
    list.pushAtFront('a');
    assert(list.first() == 'a');
}

// Tests correct insertion into an empty LL.
// Afterwards, size should be 1 and element at index 0
// should be the element we inserted.
void insertAt_empty_correct() 
{ 
    CharLinkedList list;
    list.insertAt('a', 0);
    assert(list.size() == 1);
    assert(list.elementAt(0) == 'a');

}

// Tests incorrect insertion into an empty LL.
// Attempts to call insertAt for index larger than 0.
// This should result in an std::range_error being raised.
void insertAt_empty_incorrect() 
{
    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList list;

    try {
        // insertAt for out-of-range index
        list.insertAt('a', -1);
    }
    catch (const std::range_error &e) {
        // if insertAt is correctly implemented, a range_error will be thrown,
        // and we will end up here
        range_error_thrown = true;
        error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (-1) not in range [0..0]");
}

// Tests correct insertAt for front of 1-element list.
void insertAt_front_singleton_list() 
{
    
    // initialize 1-element list
    CharLinkedList list('a');

    // insert at front
    list.insertAt('b', 0);

    assert(list.size() == 2);
    assert(list.elementAt(0) == 'b');
    assert(list.elementAt(1) == 'a');
    
}

// Tests correct insertAt for back of 1-element list.
void insertAt_back_singleton_list() 
{
    // initialize 1-element list
    CharLinkedList list('a');

    // insert at back
    list.insertAt('b', 1);

    assert(list.size() == 2);
    assert(list.elementAt(0) == 'a');
    assert(list.elementAt(1) == 'b');
    
}

// Tests calling insertAt for a large number of elements.
// Not only does this test insertAt, it also checks that
// array expansion works correctly.
void insertAt_many_elements() 
{
    
    CharLinkedList list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        list.insertAt('a', i);
    }

    assert(list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(list.elementAt(i) == 'a');
    }
    
}

// Tests insertion into front of a larger list
void insertAt_front_large_list() 
{
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList list(test_arr, 9);

    list.insertAt('y', 0);

    assert(list.size() == 10);
    assert(list.elementAt(0) == 'y');
    assert(list.toString() == "[CharLinkedList of size 10 <<yabczdefgh>>]");

}

// Tests insertion into the back of a larger list
void insertAt_back_large_list() 
{
    char test_arr[10] = { 'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList list(test_arr, 10);  

    list.insertAt('x', 10);

    assert(list.size() == 11);
    assert(list.elementAt(10) == 'x');
    assert(list.toString() == 
    "[CharLinkedList of size 11 <<yabczdefghx>>]"); 
}

// Tests insertion into the middle of a larger list
void insertAt_middle_large_list() 
{
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList list(test_arr, 8);

    list.insertAt('z', 3);

    assert(list.size() == 9);
    assert(list.elementAt(3) == 'z');
    assert(list.toString() == "[CharLinkedList of size 9 <<abczdefgh>>]");

}

// Tests out-of-range insertion for a non-empty list.
void insertAt_nonempty_incorrect() 
{
   
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8]");
}

// Tests insertInOrder() case with inserting at the front of list
void insertInOrder_test_first()
{
    char test_arr[7] = { 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList list(test_arr, 7);
    
    list.insertInOrder('a');
    assert(list.first() == 'a');
}

// Tests insertion of character at middle element, last element, and
// where character encountered is same as inputted
void insertInOrder_test_middleLastSame()
{
    char test_arr2[7] = { 'a', 'b', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList list(test_arr2, 7); 
    
    list.insertInOrder('c');
    assert(list.elementAt(2) == 'c');   
    
    list.insertInOrder('z');
    assert(list.last() == 'z');

    list.insertInOrder('z');
    assert(list.last() == 'z');
    assert(list.elementAt(9) == 'z');

    list.insertInOrder('b');
    assert(list.elementAt(2) == 'b');
    assert(list.elementAt(1) == 'b');
}

// Tests popFromFront() on list with many elements
void popFromFront_test()
{
    char test_arr[7] = { 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList list(test_arr, 7);
    
    list.popFromFront();
    
    // Ensures correct first element and size
    assert(list.size() == 6);
    assert(list.first() == 'c');
    
    // Tests popping from front twice in a row
    list.popFromFront();
    
    assert(list.size() == 5);
    assert(list.first() == 'd');    
}

// Tests case where popping from empty list
void popFromFront_incorrect_empty()
{
    CharLinkedList list;
    
    bool runtime_error_thrown = false;
    std::string error_message = "";
    try {
        list.popFromFront();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

// Tests popFromFront() on a single element list
void popFromFront_singleElement()
{
    CharLinkedList list('a');
    
    list.popFromFront();
    assert(list.isEmpty());
}

// Tests popFromBack() on list with many elements
void popFromBack_test()
{
    char test_arr[7] = { 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList list(test_arr, 7);
    
    list.popFromBack();
    
    assert(list.size() == 6);
    assert(list.last() == 'g');
    
    // Tests popping from front twice in a row
    list.popFromBack();
    
    assert(list.size() == 5);
    assert(list.last() == 'f'); 
}

// Tests case where popping from empty list
void popFromBack_incorrect_empty()
{
    CharLinkedList list;
    
    bool runtime_error_thrown = false;
    std::string error_message = "";
    try {
        list.popFromBack();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

// Tests popFromBack() on a single element list
void popFromBack_singleElement()
{
    CharLinkedList list('a');
    list.popFromBack();
    assert(list.isEmpty());
}

// Tests out of bounds removalAt()
void removeAt_incorrect() 
{
    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList list;
    try {
    // insertAt for out-of-range index
        list.removeAt(-1);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (-1) not in range [0..0)");
}

// Tests correct removeAt for front of 1-element list.
void removeAt_front_singleton_list() 
{
    // initialize 1-element list
    CharLinkedList list('a');

    // remove at front
    list.removeAt(0);

    assert(list.isEmpty()); 
}

// Tests removal at front of a larger list
void removeAt_front() 
{
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList list(test_arr, 9);

    list.removeAt(0);

    assert(list.size() == 8);
    assert(list.elementAt(0) == 'b');
}

// Tests removal at the back of a larger list
void removeAt_back_large_list() 
{
    char test_arr[10] = { 'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList list(test_arr, 10);  

    list.removeAt(9);

    assert(list.size() == 9);
    assert(list.elementAt(8) == 'g');
    assert(list.toString() == "[CharLinkedList of size 9 <<yabczdefg>>]"); 
}

// Tests removal at the middle of a larger list
void removeAt_middleOfLargeList() 
{
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList list(test_arr, 8);

    list.removeAt(3);

    assert(list.size() == 7);
    assert(list.elementAt(3) == 'e');
    assert(list.toString() == "[CharLinkedList of size 7 <<abcefgh>>]");

    list.removeAt(3);
    assert(list.toString() == "[CharLinkedList of size 6 <<abcfgh>>]");
}

// Tests out-of-range removal for a non-empty list.
void removeAt_nonempty_incorrect() 
{
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        list.removeAt(42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8)");  
}

// Tests out of bounds replacement
void replaceAt_incorrect() {
    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList list;
    try {
    // insertAt for out-of-range index
        list.replaceAt('a', -1);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (-1) not in range [0..0)");
}

// Tests correct replacement for front of 1-element list.
void replaceAt_front_singleton_list() {
    // initialize 1-element list
    CharLinkedList list('a');

    // insert at front
    list.replaceAt('b', 0);

    assert(list.size() == 1);
    assert(list.elementAt(0) == 'b'); 
}

// Tests replacement at the front of a larger list
void replaceAt_front() {
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList list(test_arr, 9);

    list.replaceAt('z', 0);

    assert(list.size() == 9);
    assert(list.elementAt(0) == 'z');
    assert(list.toString() == "[CharLinkedList of size 9 <<zbczdefgh>>]");
}

// Tests replacement at the back of a larger list
void replaceAt_back_large_list() 
{
    char test_arr[10] = { 'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList list(test_arr, 10);  

    list.replaceAt('p', 9);

    assert(list.size() == 10);
    assert(list.elementAt(9) == 'p');
    assert(list.toString() == 
    "[CharLinkedList of size 10 <<yabczdefgp>>]"); 
}

// Tests replacement at the middle of a larger list
void replaceAt_middleOfLargeList() 
{
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList list(test_arr, 8);

    list.replaceAt('z', 3);

    assert(list.size() == 8);
    assert(list.elementAt(3) == 'z');
    assert(list.toString() == "[CharLinkedList of size 8 <<abczefgh>>]");

    // Double replacement test
    list.replaceAt('z', 4);
    assert(list.toString() == "[CharLinkedList of size 8 <<abczzfgh>>]");
}

// // Tests out-of-range replacement for a non-empty list.
void replaceAt_nonempty_incorrect() 
{
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        list.replaceAt('a', 42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8)");  
}

// Tests concatenation of two equally sized lists
void concatenate_test() 
{
    char test_arr[3] = { 'a', 'b', 'c' };
    CharLinkedList list(test_arr, 3);

    char second_arr[3] = { 'd', 'e', 'f' };
    CharLinkedList second_list(second_arr, 3);   

    // Pass in address to second list
    list.concatenate(&second_list);

    assert(list.size() == 6);
    assert(list.toString() == "[CharLinkedList of size 6 <<abcdef>>]");
}

// Tests concatenation of empty list and full list
void concatenate_test_emptyFirst() 
{
    CharLinkedList list;

    char second_arr[3] = { 'd', 'e', 'f' };
    CharLinkedList second_list(second_arr, 3);   

    list.concatenate(&second_list);

    assert(list.size() == 3);
    assert(list.toString() == "[CharLinkedList of size 3 <<def>>]");
}

// Tests concatenation of full list and empty list
void concatenate_test_emptySecond() 
{
    char test_arr[3] = { 'a', 'b', 'c' };
    CharLinkedList list(test_arr, 3);

    CharLinkedList second_list; 

    list.concatenate(&second_list);

    assert(list.size() == 3);
    assert(list.toString() == "[CharLinkedList of size 3 <<abc>>]");
}

// Tests concatenation of two empty lists
void concatenate_bothEmpty()
{;
    CharLinkedList list;

    CharLinkedList second_list; 

    list.concatenate(&second_list);

    assert(list.isEmpty());
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}

// Tests the case where list is added to itself
void concatenate_withSelf()
{
    char test_arr[3] = { 'a', 'b', 'c' };
    CharLinkedList list(test_arr, 3);

    list.concatenate(&list);
    assert(list.toString() == "[CharLinkedList of size 6 <<abcabc>>]");
}

// Tests list concatenation of two different sizes and two concatenations
// in a row
void concatenate_twoSizes()
{
    char test_arr[3] = { 'a', 'b', 'c' };
    CharLinkedList list(test_arr, 3);

    char second_arr[6] = { 'd', 'e', 'f', 'g', 'h', 'i' };
    CharLinkedList second_list(second_arr, 6);

    char third_arr[5] = { 'j', 'k', 'l', 'm', 'n' }; 
    CharLinkedList third_list(third_arr, 5);

    list.concatenate(&second_list);
    assert(list.toString() == "[CharLinkedList of size 9 <<abcdefghi>>]");

    list.concatenate(&third_list);
    assert(list.toString() == 
    "[CharLinkedList of size 14 <<abcdefghijklmn>>]");
}

// Tests list concatenation of two different sizes and then a concatenation
// with itself
void concatenate_twoSizesThenSelf()
{
    char test_arr[3] = { 'a', 'b', 'c' };
    CharLinkedList list(test_arr, 3);

    char second_arr[6] = { 'd', 'e', 'f', 'g', 'h', 'i' };
    CharLinkedList second_list(second_arr, 6);

    list.concatenate(&second_list);
    assert(list.toString() == "[CharLinkedList of size 9 <<abcdefghi>>]");

    list.concatenate(&list);
    assert(list.toString() == 
    "[CharLinkedList of size 18 <<abcdefghiabcdefghi>>]");
}

// Tests functionality of copy constructor
void copy_constructor_test()
{
    char array[3] = {'a', 'b', 'c'};
    CharLinkedList list(array, 3);

    CharLinkedList copy(list);

    assert(copy.toString() == "[CharLinkedList of size 3 <<abc>>]");
}

// Tests non-empty/empty example of operator
void operator_test()
{
    char array[3] = {'a', 'b', 'c'};
    CharLinkedList list(array, 3);

    CharLinkedList list2;

    list2 = list;

    cout << list2.toString() << endl;

    assert(list2.toString() == list.toString());
}

// Tests non-empty/non-empty example of operator
void operator_test_nonEmpty()
{
    char array[3] = {'a', 'b', 'c'};
    CharLinkedList list(array, 3);

    char array2[3] = {'d', 'e', 'f'};
    CharLinkedList list2(array2, 3);

    list2 = list;

    assert(list2.toString() == list.toString());
}

// Tests empty/non-empty example of operator
void operator_test_turnEmpty()
{
    char array[3] = {'a', 'b', 'c'};
    CharLinkedList list(array, 3);

    CharLinkedList list2;

    list = list2;

    assert(list2.toString() == list.toString());
}

// Tests empty/empty example of operator
void operator_test_bothEmpty()
{
    CharLinkedList list;

    CharLinkedList list2;

    list = list2;

    assert(list2.toString() == list.toString());
}
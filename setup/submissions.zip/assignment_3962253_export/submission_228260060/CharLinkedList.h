/*
 *  CharLinkedList.h
 *  Cooper Wallman
 *  Created on 2/3/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Header file to show all of the possible functions on CharLinkedList, in
 *  addition to the private functions that make those possible. The user can
 *  peer into this file as a function directory of sorts.
 *
 */

#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H

#include <string>

class CharLinkedList 
{
public:
    // Constructors
    CharLinkedList();
    CharLinkedList(char c);
    CharLinkedList(char arr[], int size);
    CharLinkedList(const CharLinkedList &other);
    
    // Assignment Operator
    CharLinkedList &operator=(const CharLinkedList &other);

    // Destructor
    ~CharLinkedList();

    // Functions
    bool isEmpty() const;
    void clear();

    int size() const;

    char first() const;
    char last() const;
    
    char elementAt(int index) const;    

    std::string toString() const;
    std::string toReverseString() const;

    void pushAtBack(char c);
    void pushAtFront(char c);

    void insertAt(char c, int index);
    void insertInOrder(char c);

    void popFromFront();
    void popFromBack();

    void removeAt(int index);
    void replaceAt(char c, int index);
    
    void concatenate(CharLinkedList *other); 
private:
    // Node struct
    struct Node {
        Node *next;
        char character;
        Node *previous;
    };

    // Private variables/pointers
    Node *front = nullptr;
    Node *back = nullptr;
    int listSize = 0;

    // Helper functions
    Node *newNode(Node *previous, char character, Node *next); 

    Node *searchElement(Node *start, int index, int counter) const; 

    void initialize(Node *current, int size, int counter, char arr[]);

    void initializeAssignment(Node *current, int size, int counter);

    void deleter(Node *current);  

    int findOrderIndex(Node *current, int counter, char c);          
};

#endif

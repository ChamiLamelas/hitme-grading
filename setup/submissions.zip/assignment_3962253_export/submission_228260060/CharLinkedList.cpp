/*
 *  CharLinkedList.cpp
 *  Cooper Wallman
 *  Created on 2/3/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  All of the coded functions for the linked list ADT
 *
 */

#include "CharLinkedList.h"

#include <sstream>
#include <string>
#include <iostream>
#include <stdexcept>

using namespace std;

/*
 * name:      CharLinkedList::CharLinkedList()
 * purpose:   initialize empty list
 * arguments: none
 * returns:   none
 * effects:   Creates an empty character linked list
 */
CharLinkedList::CharLinkedList()
{
    // Empty linked list will have front and back point to nullptr
    front = nullptr;
    back = nullptr;
    listSize = 0;
}

/*
 * name:      CharLinkedList::CharLinkedList(char c) 
 * purpose:   initialize singe character element list
 * arguments: character c that will be inputted into the list
 * returns:   none
 * effects:   Creates a 1-sized character linked list with a single character
 */
CharLinkedList::CharLinkedList(char c) 
{
    // Makes front a new node with stored character, previous and next pointers
    // point to nullptr
    front = newNode(nullptr, c, nullptr);
    back = front;
    listSize++;
}

/*
 * name:      CharLinkedList::CharLinkedList(char arr[], int size)
 * purpose:   initialize list with multiple elements
 * arguments: array containing multiple elements that will be put into list,
 *            along with size of parameter array 
 * returns:   none
 * effects:   Creates a character linked list with multiple elements, same size
 *            as the parameter array
 */
CharLinkedList::CharLinkedList(char arr[], int size)
{
    // Checks if list is not a single element
    if (size != 1) 
    {
        // Sets front and back nodes to store first and last elements of array
        front = newNode(nullptr, arr[0], nullptr);
        back = newNode(nullptr, arr[size - 1], nullptr);
        // Call to private helper function
        initialize(front, size, 1, arr);
    }
    else 
    {
        // If single element list, made front store only element in array and
        // make back point to front
        front = newNode(nullptr, arr[0], nullptr);
        back = front;
    }
    
    // Store size of array listSize for linkedList
    listSize = size;
}

/*
 * name:      CharLinkedList::initialize(Node *current, int size, 
 *                                       int counter, char arr[])
 * purpose:   initialize list with multiple elements for when list is 
 *            not single element list using recursion, private helper function 
 *            called in constructor                               
 * arguments: pointer to current node of list, size of inputted array, a counter
 *            variable, and the inputted array 
 * returns:   none
 * effects:   Creates a character linked list with multiple elements, same size
 *            as the parameter array
 */
void CharLinkedList::initialize(Node *current, int size, 
                                int counter, char arr[])
{
    Node *temp = newNode(current, arr[counter], back);

    // Checks if its the first run of the recursive function    
    if (counter == 0)
    {
        // Make front point to new node next
        front->next = temp;
        // Make back point backwards to new node
        back->previous = temp;
        counter++;
        return initialize(temp, size, counter, arr);
    }
    else if (counter < size - 1)
    {
        // Make current and back point to temp, 
        // effectively creating an insertion
        current->next = temp;
        back->previous = temp;
        counter++;
        return initialize(temp, size, counter, arr);
    }
    else 
    {
        delete temp;
        return;
    }
}

/*
 * name:      CharLinkedList::CharLinkedList(const CharLinkedList &other)
 * purpose:   make a deep copy of parameter linked list
 * arguments: linked list address intended to be copied
 * effects:   Creates a deep copy of the inputted parameter array list
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other)
{
    // Iterate through other, make deep copy of other using elementAt/insertAt
    for (int i = 0; i < other.size(); i++)
    {
        insertAt(other.elementAt(i), i);
    }
    
}

/*
 * name:      CharLinkedList::~CharLinkedList()
 * purpose:   delete any memory off of the heap
 * arguments: none
 * returns:   none
 * effects:   Deletes used memory off of heap
 */
CharLinkedList::~CharLinkedList() 
{
    // Deletes memory off of heap using private helper function
    deleter(back);
}

/*
 * name:      CharLinkedList::deleter(Node *current)
 * purpose:   delete any memory off of the heap, private helper function called
 *            in the destructor
 * arguments: Node pointer to current node
 * returns:   none
 * effects:   Deletes used memory off of heap
 */
void CharLinkedList::deleter(Node *current)
{
    // Function recurses from the back of the list
    if (isEmpty())
    {
        return;
    }
    else
    {
        // Set back to second to last item in list
        back = current->previous;
        // Delete current 
        delete current;
        listSize--;
        
        // Recurse with new last item of the linkedList
        return deleter(back);
    }
}

/*
 * name:     CharLinkedList &CharLinkedList::operator=(const CharArrayList 
 *                                                     &other)
 * purpose:   turn LHS linked list into deep copy of RHS linked list
 * arguments: address of RHS linked list
 * effects:   Turns left hand side into a deep copy of the parameter linekd list
 */ 
CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other)
{
    // Check if LHS is = to RHS (LHS is its own argument)
    if (this == &other) 
    {
        return *this;
    }
    else if (other.isEmpty())
    {
        // If argument list is empty, then to copy it is the same as clearing
        // the LHS
        clear();
        return *this;
    }
    
    if (listSize != 0)
    {
        // Clear out LHS if it isn't already empty
        deleter(back);
    }

    // Populate LHS with RHS contents
    for (int i = 0; i < other.size(); i++)
    {
        pushAtBack(other.elementAt(i));
    }

    return *this;
}

/*
 * name:      *CharLinkedList::newNode()
 * purpose:   creates a new node with the inputted arguments
 * arguments: node pointer to the previous node, the character to be stored in
 *            the node, and a node pointer to the next node in the linked list
 * returns:   the created node with the corresponding parameters
 * effects:   Creates a new node to be stored in the linked list as an element
 */
CharLinkedList::Node *CharLinkedList::newNode(Node *previous, char character, 
                                                                  Node *next)
{
    // Populate data of new node with information from arguments
    Node *new_node = new Node;
    new_node->character = character;
    new_node->next = next;
    new_node->previous = previous;

    return new_node;
}

/*
 * name:      CharLinkedList::isEmpty() const
 * purpose:   find out whether list is empty
 * arguments: none
 * returns:   boolean dictating whether list is empty or not
 * effects:   Finds whether linked list is empty or not, 
 *            doesn't change contents of list
 */
bool CharLinkedList::isEmpty() const 
{
    if (listSize == 0) {
        return true;
    }
    else {
        return false;
    }
}

/*
 * name:      CharLinkedList::size() const
 * purpose:   to tell how large list is
 * arguments: none
 * returns:   Integer of how many items are in the list
 * effects:   Reads private numItems variable to find how many elements are in
 *            current list
 */
int CharLinkedList::size() const 
{
    return listSize;
}

/*
 * name:      CharLinkedList::elementAt(int index) const
 * purpose:   to find the character at a certain index in a list
 * arguments: integer representing index character is at
 * returns:   Character at particular index or error message
 * effects:   Finds particular character at certain index of list
 */
char CharLinkedList::elementAt(int index) const
{
    // Checks either if array is empty or if parameter index exceeds number of
    // items or if index is negative
    if ((isEmpty()) or (index >= listSize) or (index < 0)) {
        // Throws range error message
        throw std::range_error("index (" + std::to_string( index ) + 
        ") not in range [0.." + std::to_string( listSize ) + ")");
    }
    else {
        if (index == 0)
        {
            return front->character;
        }
        else if (index == listSize - 1)
        {
            return back->character;
        }
        else {
            // Private helper function finds node at index
            Node *element = searchElement(front, index, 0);
            return element->character;
        }
    }
}

/*
 * name:      *CharLinkedList::searchElement()
 * purpose:   finds the character at an element in the linked list, private
 *            helper function for elementAt()
 * arguments: a pointer to the node that will be used to start the recursion, 
 *            integer variable storing the index that will be found, and a
 *            counter integer variable to keep track of recursions
 * returns:   A pointer to the node of the corresponding node at the index
 * effects:   Finds node at desired index
 */
CharLinkedList::Node *CharLinkedList::searchElement(Node *start, int index, 
                                                    int counter) const
{
    if (index == counter)
    {
        return start;
    }
    else
    {
        counter++;
        // Recurses through linkedList to find node at index
        return searchElement(start->next, index, counter);
    }
}

/*
 * name:      CharLinkedList::toString() const
 * purpose:   convert linked list into string
 * arguments: none
 * returns:   String containing list converted into string along with the number
 *            of characters in the formed string
 * effects:   Turns list into a string and stores how many elements are in list
 */
std::string CharLinkedList::toString() const 
{
    std::stringstream ss;
    
    // Takes in formatted formatted string into ss along with numItems
    ss << "[CharLinkedList of size " << listSize << " <<";
    
    // Checks if elements is empty
    if (not isEmpty()) {
        // Takes in all elements in elements pointer as a string in ss
        for (int i = 0; i < listSize; i++)
        {
            ss << elementAt(i);
        }
    }
    
    ss << ">>]";
    
    // Returns ss string
    return ss.str();
}

/*
 * name:      CharLinkedList::toReverseString() const
 * purpose:   convert linked list into reversed string
 * arguments: none
 * returns:   Reversed string containing list converted into string along with 
 *            the number of characters in the formed string
 * effects:   Turns list into a string and stores how many elements are in list
 */
std::string CharLinkedList::toReverseString() const 
{
    std::stringstream ss;
    
    // Takes in formatted formatted string into ss along with numItems
    ss << "[CharLinkedList of size " << listSize << " <<";
    
    // Checks if elements is empty
    if (not isEmpty()) {
        // Takes in all elements in elements pointer as a string in ss
        for (int i = listSize - 1; i > -1; i--)
        {
            ss << elementAt(i);
        }
    }
    
    ss << ">>]";
    
    // Returns ss string
    return ss.str();
}

/*
 * name:      CharLinkedList::first() const
 * purpose:   find first element of list
 * arguments: none
 * returns:   Character at first element of list or error message
 * effects:   Finds first element of list
 */
char CharLinkedList::first() const
{
    if (not isEmpty()) {
        return front->character;
    }
    else {
        throw std::runtime_error("cannot get first of empty LinkedList");
    }
}

/*
 * name:      CharLinkedList::last() const
 * purpose:   find last element of list
 * arguments: none
 * returns:   Character at last element of list or error message
 * effects:   Finds last element of list
 */
char CharLinkedList::last() const
{
    if (not isEmpty()) {
        return back->character;
    }
    else {
        throw std::runtime_error("cannot get last of empty LinkedList");
    }
}

/*
 * name:      CharLinkedList::clear()
 * purpose:   makes list empty
 * arguments: none
 * returns:   none
 * effects:   Clears out list by deleting all contents
 */
void CharLinkedList::clear() 
{
    deleter(back);

    front = nullptr;
    back = nullptr;
}

/*
 * name:      CharLinkedList::pushAtBack(char c)
 * purpose:   appends character to the end of list
 * arguments: Character that will be appended
 * returns:   none
 * effects:   Adds specified character to the end of the list
 */
void CharLinkedList::pushAtBack(char c) 
{
    if (not isEmpty())
    {
        Node *newBack = newNode(back, c, nullptr);
        back->next = newBack;
        back = newBack; 
    }
    else {
        Node *newBack = newNode(nullptr, c, nullptr);
        front = newBack;
        back = newBack;
    }
    
    listSize++;
}

/*
 * name:      CharLinkedList::pushAtFront(char c)
 * purpose:   appends character to the front of list
 * arguments: Character that will be appended
 * returns:   none
 * effects:   Adds specified character to the beginning of the list
 */
void CharLinkedList::pushAtFront(char c) 
{
    if (not isEmpty())
    {
        Node *newFront = newNode(nullptr, c, front);
        front->previous = newFront;
        front = newFront; 
    }
    else {
        Node *newFront = newNode(nullptr, c, nullptr);
        front = newFront;
        back = newFront;
    }

    listSize++;
}

/*
 * name:      CharLinkedList::insertAt(char c, int index)
 * purpose:   inserts character at a location of list
 * arguments: Character that will be inserted, insert location
 * returns:   nothing, or an error message
 * effects:   Inserts specified character to the specified index of the list
 */
void CharLinkedList::insertAt(char c, int index)
{
    if ((index > listSize) or (index < 0)) {
        throw std::range_error("index (" + std::to_string( index ) + 
        ") not in range [0.." + std::to_string( listSize ) + "]");
    }
    else 
    {
        if (index == 0) 
        {
            pushAtFront(c);
        }
        else if ((index == listSize - 1) or (index == listSize))
        {
            pushAtBack(c);
        }
        else 
        {
            // Gets node pointer by calling helper function from above
            Node *element = searchElement(front, index, 0);
            // Initializes new node pointing to previous of element and element
            // so that we can insert the new node in front of the found element
            Node *newInsert = newNode(element->previous, c, element);
            element->previous->next = newInsert;
            element->previous = newInsert;

            listSize++;
        }
    }
}

/*
 * name:      CharLinkedList::insertInOrder(char c)
 * purpose:   inserts character at location in ASCII order
 * arguments: Character that will be inserted
 * returns:   none
 * effects:   Inserts specified character based on ASCII order in the list
 */
void CharLinkedList::insertInOrder(char c)
{
    // Private recursive function similar to searchElement, but finds index
    // rather than pointer to node
    int index = findOrderIndex(front, 0, c);

    insertAt(c, index);
}

/*
 * name:      CharLinkedList::findOrderIndex(Node *current, int counter, char c)
 * purpose:   finds character at location based on ASCII order
 * arguments: Current node, counter integer, character that will be inserted
 * returns:   integer representing index that element should be added
 * effects:   Privately helps insertInOrder function by finding index that 
 *            character should be inserted at based on ASCII.
 */
int CharLinkedList::findOrderIndex(Node *current, int counter, char c)
{
    if ((c <= current->character) or (counter == listSize - 1)) 
    {
        
        return counter;
    }
    else 
    {
        counter++;
        // Recurse if conditional is not met
        return findOrderIndex(current->next, counter, c);
    }
}

/*
 * name:      CharLinkedList::popFromFront()
 * purpose:   to shorten list by one at the front
 * arguments: none
 * returns:   nothing, or an error message
 * effects:   List is truncated at the front
 */
void CharLinkedList::popFromFront()
{
    if (listSize == 1)
    {
        clear();
    }
    else if (not isEmpty())
    {
        // Make newFront point to same previous and next as front
        Node *newFront = front->next;
        newFront->previous = nullptr;
        // Delete old front
        delete front;
        // Store newFront as front
        front = newFront;
        listSize--;
    }
    else 
    {
        throw std::runtime_error("cannot pop from empty LinkedList");
    }
}

/*
 * name:      CharLinkedList::popFromBack()
 * purpose:   to shorten list by one at the back
 * arguments: none
 * returns:   nothing, or an error message
 * effects:   List is truncated at the back
 */
void CharLinkedList::popFromBack()
{
    if (listSize == 1)
    {
        clear();
    }
    else if (not isEmpty())
    {
        // Make newBack point to same previous and next as back
        Node *newBack = back->previous;
        newBack->next = nullptr;
        // Delete old back
        delete back;
        // Store newBack as back
        back = newBack;
        listSize--;
    }
    else 
    {
        throw std::runtime_error("cannot pop from empty LinkedList");
    }
}

/*
 * name:      CharLinkedList::removeAt(int index)
 * purpose:   to remove character from list at certain index
 * arguments: index where character will be removed
 * returns:   nothing, or an error message
 * effects:   Character in list at specified index is removed
 */
void CharLinkedList::removeAt(int index)
{
    if ((isEmpty()) or (index >= listSize) or (index < 0)) 
    {
        throw std::range_error("index (" + std::to_string( index ) + 
        ") not in range [0.." + std::to_string( listSize ) + ")");
    }
    else if (index == 0) 
    {
        popFromFront();
    }
    else if (index == listSize - 1) 
    {
        popFromBack();
    }
    else
    {
        // Find node at index being removed
        Node *removal = searchElement(front, index, 0);
        // Chain together previous and next pointers as if removal node wasn't
        // there
        removal->previous->next = removal->next;
        removal->next->previous = removal->previous;

        // Delete node
        delete removal;

        listSize--;
    }
}

/*
 * name:      CharLinkedList::replaceAt(char c, int index)
 * purpose:   to replace a character from list at certain index with another
 *            specified character
 * arguments: index where character will be replaced, character that will 
 *            replace it
 * returns:   nothing, or an error message
 * effects:   Character in list at specified index is replaced with specified
 *            character
 */
void CharLinkedList::replaceAt(char c, int index)
{
    if ((isEmpty()) or (index >= listSize) or (index < 0)) {
        throw std::range_error("index (" + std::to_string( index ) + 
        ") not in range [0.." + std::to_string( listSize ) + ")");
    }
    
    Node *replace = searchElement(front, index, 0);
    replace->character = c;
}

/*
 * name:      CharLinkedList::concatenate(CharLinkedList *other)
 * purpose:   to concatenate one list with another or itself
 * arguments: pointer to other list or itself
 * returns:   none
 * effects:   Elements of parameter list are added to the end of the main list
 */
void CharLinkedList::concatenate(CharLinkedList *other)
{
    int initial = other->size();
    
    for (int i = 0; i < initial; i++)
    {
        pushAtBack(other->elementAt(i));
    }
}
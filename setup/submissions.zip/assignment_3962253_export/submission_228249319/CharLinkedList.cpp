/*
 *  CharLinkedList.cpp
 *  Brendan Roy
 *  2/1/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Implement a doubly linked list of characters seen in CharLinkedList.h
 *
 */

#include "CharLinkedList.h"
#include <string>
#include <stdexcept>



/*
 * name:      CharLinkedList empty list constructor
 * purpose:   creates an instance of an empty CharLinkedList
 * arguments: none
 * returns:   none; it is a constructor
 * effects:   creates an instance of an empty CharLinkedList
 */
CharLinkedList::CharLinkedList(){
    // initialize private values
    listSize = 0;
    front.next = nullptr;
    back.last = nullptr;
}

/*
 * name:      CharLinkedList single char constructor
 * purpose:   creates an instance of a CharLinkedList with one element
 * arguments: a character "c"
 * returns:   none; it is a constructor
 * effects:   creates an instance of an CharLinkedList with one element
 */
CharLinkedList::CharLinkedList(char a){
    // initialize private values
    listSize = 1;
    Node *newNode = new Node();
    newNode->data = a;
    newNode->next = nullptr;
    front.next = newNode;
    back.last = newNode;
}

/*
 * name:      CharLinkedList array of chars constructor
 * purpose:   creates an instance of a CharLinkedList using values from a char[]
 * arguments: an array of characters, and the size of the array
 * returns:   none; it is a constructor
 * effects:   creates an instance of a CharLinkedList with several elements
 */
CharLinkedList::CharLinkedList(char arr[], int size){
    front.next = nullptr;
    back.last = nullptr;
    listSize = 0;
    for (int i = 0; i < size; i++){ // add elements of arr to the list
        pushAtBack(arr[i]);   
    }
}

/*
 * name:      CharLinkedList copy constructor
 * purpose:   creates an instance of a CharLinkedList that is equal to another
 * arguments: a CharLinkedList
 * returns:   none; it is a constructor
 * effects:   makes an instance of a CharLinkedList as a deep copy of the other
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other){
    listSize = 0;
    
    // make a deep copy of other
    Node *curr = other.front.next;
    for (int i = 0; i < other.listSize; i++){
        pushAtBack(curr->data);
        curr = curr->next;
    } 
}

/*
 * name:      CharLinkedList overload assignment operator
 * purpose:   sets two CharLinkedLists equal to each other
 * arguments: a CharLinkedList
 * returns:   a CharLinkedList with the same values as the "other" list
 * effects:   sets two CharLinkedLists equal to each other
 */
CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other){
    if (listSize > 0){ 
        freeMemory(front.next); // delete the old list
        front.next = nullptr;
        back.last = nullptr;
    }
    listSize = 0;
    if (other.listSize == 0){ // accounts for empty other list edge case
        return *this;
    }
    // make a deep copy of other
    Node *curr = other.front.next;
    while (curr != nullptr){
        pushAtBack(curr->data);
        curr = curr->next;
    }
    return *this;
}

/*
 * name:      pushAtBack
 * purpose:   add an element to the back of the list
 * arguments: a character "c"
 * returns:   void
 * effects:   none
 */
void CharLinkedList::pushAtBack(char c){
    Node *newNode = new Node();
    newNode->data = c;
    newNode->next = nullptr;
    
    if (listSize == 0){ // account for empty list edge case
        front.next = newNode;
        back.last = newNode;
        listSize++;
        return;
    }

    // switch pointers to add to the back of the list
    newNode->last = back.last;
    back.last->next = newNode;
    back.last = newNode;
   
    listSize++;
}

/*
 * name:      CharLinkedList destructor
 * purpose:   frees memory allocated by a CharLinkedList
 * arguments: none
 * returns:   none
 * effects:   frees memory allocated by a CharLinkedList
 */
CharLinkedList::~CharLinkedList(){
    if (front.next != nullptr){
        freeMemory(front.next);
    }
}

/*
 * name:      freeMemory
 * purpose:   deallocates all of the list's memory; destructor calls it
 * arguments: the front of the list
 * returns:   void
 * effects:   deletes all nodes in the list after curr
 */
void CharLinkedList::freeMemory(Node *curr){
    if (curr->next != nullptr){
        freeMemory(curr->next);
    }
    delete curr;    
}

/*
 * name:      elementAt
 * purpose:   gets the element at the index
 * arguments: none
 * returns:   the character that is at the inputted index
 * effects:   throws an exception if the index is out of bounds
 */
char CharLinkedList::elementAt(int index) const{
    if (index < 0 or index >= listSize){
        std::string error = "index (" + std::to_string(index) + ") not in range"
                            + " [0.." + std::to_string(listSize) + ")";
        throw std::range_error(error);
    }
    return nodeAt(front.next, index)->data; // returns data of the Node at index
}

/*
 * name:      clear
 * purpose:   empties a CharLinkedList
 * arguments: none
 * returns:   void
 * effects:   all memory is freed and there are no more elements in the list
 */
void CharLinkedList::clear(){
    if (listSize == 0){
        return;
    }
    listSize = 0;
    freeMemory(front.next);
    front.next = nullptr;
    back.last = nullptr;
}

/*
 * name:      toString
 * purpose:   get a CharLinkedList in string form
 * arguments: none
 * returns:   a string showing the size and elemenets of the list
 * effects:   none
 */
std::string CharLinkedList::toString() const{
    std::string result = "<<";
    Node *curr = front.next;
    while (curr != nullptr){ // add each element to the final string
        result += curr->data;
        curr = curr->next;
    }
    result += ">>]";
    
    return "[CharLinkedList of size " + std::to_string(listSize) + " " + result;
}


/*
 * name:      toReverseString
 * purpose:   get a CharLinkedList in string form in backwards order
 * arguments: none
 * returns:   string showing the size and elemenets of the list in reverse order
 * effects:   none
 */
std::string CharLinkedList::toReverseString() const{
    std::string result = "<<";
    Node *curr = back.last;
    while (curr != nullptr){ // add each element to the final string
        result += curr->data;
        curr = curr->last;
    }
    result += ">>]";
    
    return "[CharLinkedList of size " + std::to_string(listSize) + " " + result;
}

/*
 * name:      isEmpty
 * purpose:   tells if a list has any elements in it or not
 * arguments: none
 * returns:   a bool; true if there are no elements, false if there are
 * effects:   none
 */
bool CharLinkedList::isEmpty() const{
    return listSize == 0;
}

/*
 * name:      last
 * purpose:   returns the last element in the list
 * arguments: none
 * returns:   the character that is last in the list
 * effects:   throws an exception if the list is empty
 */
char CharLinkedList::last() const{
    if (isEmpty()){
        throw std::runtime_error("cannot get last of empty LinkedList");
    }
    return back.last->data;
}

/*
 * name:      first
 * purpose:   returns the first element in the list
 * arguments: none
 * returns:   the character that is first in the list
 * effects:   throws an exception if the list is empty
 */
char CharLinkedList::first() const{
    if (isEmpty()){
        throw std::runtime_error("cannot get first of empty LinkedList");
    }
    return front.next->data;
}

/*
 * name:      size
 * purpose:   get the size of a CharLinkedList
 * arguments: none
 * returns:   an integer representing the size of the list
 * effects:   none
 */
int CharLinkedList::size() const{
    return listSize;
}

/*
 * name:      pushAtFront
 * purpose:   add an element to the front of the list
 * arguments: a character "c"
 * returns:   void
 * effects:   a Node is added to the front of the list
 */
void CharLinkedList::pushAtFront(char c) {
    Node *newNode = new Node();
    newNode->data = c;

    // switch pointers to add in the new Node
    newNode->next = front.next;
    if (listSize == 0){ // deal with empty list edge case
        back.last = newNode;
    } else{ 
        front.next->last = newNode;
    }
    front.next = newNode;
    listSize++;
}

/*
 * name:      popFromBack
 * purpose:   remove the back element from the list
 * arguments: none
 * returns:   void
 * effects:   throws an exception if the list is empty
 */
void CharLinkedList::popFromBack(){
    if (isEmpty()){
        throw std::runtime_error("cannot pop from empty LinkedList");
    }
    if (listSize == 1){ // if the list has one element, clear it
        clear();
        return;
    }
    // switch pointers and delete the last Node
    Node *temp = back.last;
    back.last = back.last->last;
    back.last->next = nullptr;
    delete temp;
    listSize--;
}

/*
 * name:      popFromFront
 * purpose:   remove the front element from the list
 * arguments: none
 * returns:   void
 * effects:   throws an exception if the list is empty
 */
void CharLinkedList::popFromFront(){
    if (isEmpty()){
        throw std::runtime_error("cannot pop from empty LinkedList");
    }
    // switch pointers to get skip over and then delete the first Node
    Node *temp = front.next;
    front.next = front.next->next;
    delete temp;
    listSize--;
}

/*
 * name:      removeAt
 * purpose:   remove the element at the given index from the list
 * arguments: an integer representing the index of the to-be-removed element
 * returns:   void
 * effects:   throws an exception if the index is out of bounds
 */
void CharLinkedList::removeAt(int index){
    // check if the index is valid
    if (index < 0 or index >= listSize){
        std::string error = "index (" + std::to_string(index) + ") not in range"
                            + " [0.." + std::to_string(listSize) + ")";
        throw std::range_error(error);
    }
    // check if it a removal from the front
    if (index == 0){
        popFromFront();
        return;
    }
    // check if it a removal from the back
    if (index == listSize - 1){
        popFromBack();
        return;
    }

    Node *curr = front.next;
    for (int i = 0; i < index - 1; i++){ // get curr to the removal point
        curr = curr->next;
    }
    // switch the pointers to skip over the removed Node. Delete removed Node
    Node *temp = curr->next;
    curr->next = curr->next->next;
    curr->next->next->last = curr;
    delete temp;
    listSize--;
}


/*
 * name:      concatenate
 * purpose:   add elements from one list to another
 * arguments: a pointer to the other CharLinkedList
 * returns:   void
 * effects:   combines the two lists with the other coming after
 */
void CharLinkedList::concatenate(CharLinkedList *other){
    /* NOTE TO GRADERS: Yes, I know that the two pieces of code below do the
    *                  same thing. For an unknown reason, my test would never
    *                  finish running if I didn't make a separate case for 
    *                  concatenating itself. It confused me.
    */
    if (this == other){
        if (listSize == 0){
            return;
        }
        CharLinkedList list = *this;
        Node *curr = list.front.next;
        while (curr != nullptr){ 
            pushAtBack(curr->data);
            curr = curr->next;
        }
        return;
    }
    Node *curr = other->front.next;
    while (curr != nullptr){ // add the other list's elements to the back
        pushAtBack(curr->data);
        curr = curr->next;
    }
}

/*
 * name:      insertAt
 * purpose:   add an element at an inputted index
 * arguments: a character "c" and the index number
 * returns:   void
 * effects:   throws an exception if the index is out of bounds
 */
void CharLinkedList::insertAt(char c, int index){
    // check if the index is valid
    if (index < 0 or index > listSize){
        std::string error = "index (" + std::to_string(index) + ") not in range"
                            + " [0.." + std::to_string(listSize) + "]";
        throw std::range_error(error);
    }
    // insert into the front if index is 0
    if (index == 0){
        pushAtFront(c);
    }
    // insert into the back if index is listSize
    else if (index == listSize){
        pushAtBack(c);
    }
    else {
        Node *curr = front.next;
        Node *newNode = new Node();
        newNode->data = c;
        for (int i = 0; i < index - 1; i++){ // get curr to insertion point
            curr = curr->next;
        }
        // switch the pointers to accomadate the new Node
        newNode->next = curr->next;
        newNode->last = curr;
        curr->next = newNode;
        newNode->next->last = newNode;
        listSize++;
    }
}

/*
 * name:      insertInOrder
 * purpose:   add an element to the list according to ASCII order
 * arguments: a character "c"
 * returns:   void
 * effects:   none
 */
void CharLinkedList::insertInOrder(char c){
    Node *curr = front.next;
    int count = 0;

    // iterate through the list and insert c according to ASCII values
    while (curr != nullptr){ 
        if (c <= curr->data){
            insertAt(c, count);
            return;
        }
        count++;
        curr = curr->next;
    }
    // insert at the back if it goes no where else
    pushAtBack(c);
}

/*
 * name:      nodeAt
 * purpose:   find the Node at the original given index
 * arguments: a pointer to the current Node and the wanted index in the list
 * returns:   a pointer to the node at the original given index
 * effects:   none
 */
CharLinkedList::Node* CharLinkedList::nodeAt(Node *curr, int idx) const{
    // return the node once we have reached the index
    if (idx == 0){
        return curr;
    } 
    // count down indices while counting up positions in the list
    return nodeAt(curr->next, idx - 1); 
    
}

/*
 * name:      replaceAt
 * purpose:   replace one element of the list with an inputted one
 * arguments: a character "c" and an integer index
 * returns:   void
 * effects:   throws an exception if the list is empty. 
 *            replaces the element at index with c
 */
void CharLinkedList::replaceAt(char c, int index){
    // check if the index is valid
    if (index < 0 or index >= listSize){
        std::string error = "index (" + std::to_string(index) + ") not in range"
                            + " [0.." + std::to_string(listSize) + ")";
        throw std::range_error(error);
    }
    // set the node's data at the index to be the given character
    nodeAt(front.next, index)->data = c; 
}
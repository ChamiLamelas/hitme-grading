/*
 *  unit_tests.h
 *  Brendan Roy
 *  2/1/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  Unit tests for the CharLinkedList class
 *
 */

#include "CharLinkedList.h"
#include <cassert>



// Tests correct insertion into an empty AL.
// Afterwards, size should be 1 and element at index 0
// should be the element we inserted.
void insertAt_empty_correct() { 

    CharLinkedList test_list;
    test_list.insertAt('a', 0);
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');

}

// Tests incorrect insertion into an empty AL.
// Attempts to call insertAt for index larger than 0.
// This should result in an std::range_error being raised.
void insertAt_empty_incorrect() {

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    // insertAt for out-of-range index
    test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
    // if insertAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    range_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0]");
    
}

// Tests correct insertAt for front of 1-element list.
void insertAt_front_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at front
    test_list.insertAt('b', 0);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'a');
    
}

// Tests correct insertAt for back of 1-element list.
void insertAt_back_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at back
    test_list.insertAt('b', 1);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    
}

// Tests calling insertAt for a large number of elements.
// Not only does this test insertAt, it also checks that
// array expansion works correctly.
void insertAt_many_elements() {
    
    CharLinkedList test_list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.insertAt('a', i);
    }

    assert(test_list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
    
}

//Tests insertion into front of a larger list
void insertAt_front_large_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g'};
    CharLinkedList test_list(test_arr, 8);

    test_list.insertAt('y', 0);

    assert(test_list.size() == 9);
    assert(test_list.elementAt(0) == 'y');
    assert(test_list.toString() == "[CharLinkedList of size 9 <<yabczdefg>>]");

}

// Tests insertion into the back of a larger list
void insertAt_back_large_list() {

    char test_arr[10] = { 'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 10);  

    test_list.insertAt('x', 10);

    assert(test_list.size() == 11);
    assert(test_list.elementAt(10) == 'x');
    assert(test_list.toString() == 
    "[CharLinkedList of size 11 <<yabczdefghx>>]"); 

}

// Tests insertion into the middle of a larger list
void insertAt_middle_large_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.insertAt('z', 3);

    assert(test_list.size() == 9);
    assert(test_list.elementAt(3) == 'z');
    assert(test_list.toString() == "[CharLinkedList of size 9 <<abczdefgh>>]");

}

// Tests out-of-range insertion for a non-empty list.
void insertAt_nonempty_incorrect() {
   
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8]");
    
}
// tests the first() function called on an empty list. Should throw an error.
void testFirst_emptyList(){
    CharLinkedList list;
    // var to track whether range_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";
    try {
        list.first();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "cannot get first of empty LinkedList");
}
// tests the first() function called on a list with one element.
void testFirst_oneItemList(){
    CharLinkedList list = CharLinkedList('a');
    assert(list.first() == 'a');

}
// tests the first() function called on a list with several elements.
void testFirst_manyItemList(){
    char longList[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(longList, 5);
    assert(list.first() == 'a');
}

// tests the last() function called on an empty list. Should throw an error.
void testLast_emptyList(){
    CharLinkedList list;

    // var to track whether range_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";
    try {
        list.last();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "cannot get last of empty LinkedList");
}
// tests the last() function called on a list with one element.
void testLast_oneItemList(){
    CharLinkedList list = CharLinkedList('a');
    assert(list.last() == 'a');

}
// tests the last() function called on a list with several elements.
void testLast_manyItemList(){
    char longList[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(longList, 5);
    assert(list.last() == 'e');
}

// tests the size() function called on an empty list.
void testSize_emptyList(){
    CharLinkedList list;
    assert(list.size() == 0);
}

// tests the size() function called on a list with one element.
void testSize_oneItemList(){
    CharLinkedList list('a');
    assert(list.size() == 1);
}

// tests the size() function called on a list with several elements.
void testSize_manyItemList(){
    char longList[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(longList, 5);
    assert(list.size() == 5);
}

// tests the elementAt() function called on a list with many elements.
// should retrieve the first element in the list.
void testElementAt_first(){
    char longList[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(longList, 5);
    assert(list.elementAt(0) == 'a');
}

// tests the elementAt() function called on a list with many elements.
// should retrieve the last element in the list.
void testElementAt_last(){
    char longList[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(longList, 5);
    assert(list.elementAt(4) == 'e');
}

// tests the elementAt() function called on a list with many elements.
// should retrieve the third element in the list.
void testElementAt_middle(){
    char longList[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(longList, 5);
    assert(list.elementAt(2) == 'c');
}

// tests the elementAt() function on an empty list. Should throw an error.
void testElementAt_emptyList(){
    CharLinkedList list;

        // var to track whether range_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";
    try {
        list.elementAt(0);
    }
    catch (const std::range_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "index (0) not in range [0..0)");


}
// tests the elementAt() function on a nonempty list. 
// Should throw an error as the index is too large
void testElementAt_outOfBoundsPositive(){
    char longList[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(longList, 5);

    // var to track whether range_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";
    try {
        list.elementAt(5);
    }
    catch (const std::range_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "index (5) not in range [0..5)");
}

// tests the elementAt() function on a nonempty list. 
// Should throw an error as the index is too small
void testElementAt_outOfBoundsNegative(){
    char longList[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(longList, 5);

    // var to track whether range_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";
    try {
        list.elementAt(-1);
    }
    catch (const std::range_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "index (-1) not in range [0..5)");
}

// tests the pushAtBack() function on an empty list.
void testPushAtBack_emptyList(){
    CharLinkedList list;
    list.pushAtBack('a');
    assert(list.elementAt(0) == 'a');
}
// tests the pushAtBack() function on a list with one element
void testPushAtBack_oneItemList(){
    CharLinkedList list('a');
    list.pushAtBack('b');
    assert(list.elementAt(1) == 'b');
}


// tests the pushAtBack() function on a list with several elements.
void testPushAtBack_longList(){
    char longList[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(longList, 5);
    list.pushAtBack('a');
    assert(list.elementAt(5) == 'a');
}

// tests the pushAtFront() function on an empty list.
void testPushAtFront_emptyList(){
    CharLinkedList list;
    list.pushAtFront('a');
    assert(list.elementAt(0) == 'a');
}

// tests the pushAtFront() function on a list with one element
void testPushAtFront_oneItemList(){
    CharLinkedList list('a');
    list.pushAtFront('b');
    assert(list.elementAt(0) == 'b');
}

// tests the pushAtBack() function on a list with many elements
void testPushAtFront_longList(){
    char longList[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(longList, 5);
    list.pushAtFront('e');
    assert(list.elementAt(0) == 'e');
}

// tests the insertInOrder() function on an empty list
void testInOrder_emptyList(){
    CharLinkedList list;
    list.insertInOrder('a');
    assert(list.elementAt(0) == 'a');
}

// tests the insertInOrder() function on a nonempty list.
// should insert at back. The back char is the same as the inserted char
void testInOrder_longListEnd(){
    char longList[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(longList, 5);
    list.insertInOrder('e');
    assert(list.toString() == "[CharLinkedList of size 6 <<abcdee>>]");
    //assert(list.elementAt(1) == 'a');
}

// tests the insertInOrder() function on a nonempty list. 
// should insert at front. The front char is the same as the inserted char
void testInOrder_longListFront(){
    char longList[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(longList, 5);
    list.insertInOrder('a');
    assert(list.toString() == "[CharLinkedList of size 6 <<aabcde>>]");
    assert(list.elementAt(1) == 'a');
}

// tests the insertInOrder() function on a nonempty list. Inserts in middle.
void testInOrder_longListMiddle(){
    char longList[] = {'a', 'b', 'c', 'd', 'f'};
    CharLinkedList list(longList, 5);
    list.insertInOrder('e');
    assert(list.toString() == "[CharLinkedList of size 6 <<abcdef>>]");
}

// tests the insertInOrder() function on a nonempty list. 
// should insert at front. The front char is different than the inserted char
void testInOrder_longListFrontDifChar(){
    char longList[] = {'b', 'b', 'c', 'd', 'e'};
    CharLinkedList list(longList, 5);
    list.insertInOrder('a');
    assert(list.toString() == "[CharLinkedList of size 6 <<abbcde>>]");  
}

// tests the insertInOrder() function on a nonempty list. 
// should insert at back. The back char is different than the inserted char
void testInOrder_longListEndDifChar(){
    char longList[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(longList, 5);
    list.insertInOrder('z');
    assert(list.toString() == "[CharLinkedList of size 6 <<abcdez>>]");
    
}

// tests the insertInOrder() function on an empty list
void testInsertInOrderEmpty(){
    CharLinkedList list;
    list.insertInOrder('z');    
    assert(list.toString() == "[CharLinkedList of size 1 <<z>>]");
}

// tests the popFromFront() function on an empty list. Should throw an error.
void testPopFromFront_emptyList(){
    CharLinkedList list; 
    
    // var to track whether range_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";
    try {
        list.popFromFront();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");

}
// tests the popFromFront() function on a list with one element
void testPopFromFront_oneItemList(){
    CharLinkedList list('a'); 
    list.popFromFront();
    assert(list.isEmpty());
}
// tests the popFromFront() function on a list with several elements
void testPopFromFront_longList(){
    char longList[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(longList, 5); 
    list.popFromFront();
    assert(list.toString() == "[CharLinkedList of size 4 <<bcde>>]");
}
// tests the popFromBack() function on an empty list. Should throw an error.
void testPopFromBack_emptyList(){
    CharLinkedList list; 
    
    // var to track whether range_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";
    try {
        list.popFromBack();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");

}

// tests the popFromBack() function on a list with one element
void testPopFromBack_oneItemList(){
    CharLinkedList list('a'); 
    list.popFromBack();
    assert(list.isEmpty());
}
// tests the popFromBack() function on a list with several elements
void testPopFromBack_longList(){
    char longList[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(longList, 5); 
    list.popFromBack();
    assert(list.toString() == "[CharLinkedList of size 4 <<abcd>>]");
}
// tests the removeAt() function on an empty list. Should throw an error.
void testRemoveAt_emptyList(){
    CharLinkedList list;
    
    // var to track whether range_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";
    try {
        list.removeAt(0);
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "index (0) not in range [0..0)");

}
// tests the removeAt() function on a nonempty list.
// should throw an error as the index is too large
void testRemoveAt_outOfBoundsPositive(){
    char longList[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(longList, 5);
    
    // var to track whether range_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";
    try {
        list.removeAt(5);
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "index (5) not in range [0..5)");

}
// tests the removeAt() function on a nonempty list.
// should throw an error as the index is too small
void testRemoveAt_outOfBoundsNegative(){
    char longList[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(longList, 5);
    
    // var to track whether range_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";
    try {
        list.removeAt(-1);
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "index (-1) not in range [0..5)");

}

// tests the removeAt() function on a list with one element
void testRemoveAt_oneItemList(){
    CharLinkedList list('a');
    list.removeAt(0);
    assert(list.isEmpty());
}
// tests the removeAt() function on a nonempty list. Removes from the front
void testRemoveAt_longListFront(){
    char longList[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(longList, 5);
    list.removeAt(0);
    assert(list.toString() == "[CharLinkedList of size 4 <<bcde>>]");
}
// tests the removeAt() function on a nonempty list. Removes from the back
void testRemoveAt_longListBack(){
    char longList[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(longList, 5);
    list.removeAt(4);
    assert(list.toString() == "[CharLinkedList of size 4 <<abcd>>]");
}
// tests the removeAt() function on a nonempty list. Removes from the middle
void testRemoveAt_longListMiddle(){
    char longList[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(longList, 5);
    list.removeAt(2);
    assert(list.toString() == "[CharLinkedList of size 4 <<abde>>]");
}
// tests the replaceAt() function on an empty list. Should throw an error.
void testReplaceAt_emptyList(){
    CharLinkedList list;
    
    // var to track whether range_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";
    try {
        list.replaceAt('a', 0);
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "index (0) not in range [0..0)");

}
// tests the replaceAt() function on a nonempty list.
// should throw an error because index is too large
void testReplaceAt_outOfBoundsPositive(){
    char longList[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(longList, 5);
    
    // var to track whether range_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";
    try {
        list.replaceAt('a', 5);
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "index (5) not in range [0..5)");

}
// tests the replaceAt() function on a nonempty list.
// should throw an error because index is too small
void testReplaceAt_outOfBoundsNegative(){
    char longList[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(longList, 5);
    
    // var to track whether range_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";
    try {
        list.replaceAt('a', -1);
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "index (-1) not in range [0..5)");
}
// tests the replaceAt() function on a nonempty list. Replaces at the back
void testReplaceAt_longListBack(){
    char longList[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(longList, 5);
    list.replaceAt('a', 4);
    assert(list.toString() == "[CharLinkedList of size 5 <<abcda>>]");
}
// tests the replaceAt() function on a nonempty list. Replaces at the front
void testReplaceAt_longListFront(){
    char longList[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(longList, 5);
    list.replaceAt('d', 0);
    assert(list.toString() == "[CharLinkedList of size 5 <<dbcde>>]");
}
// tests the replaceAt() function on a nonempty list. Replaces in the middle
void testReplaceAt_longListMiddle(){
    char longList[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(longList, 5);
    list.replaceAt('d', 2);
    assert(list.toString() == "[CharLinkedList of size 5 <<abdde>>]");
}

// tests the concatenate() function on an empty first list
void testConcatenate_emptyFirstList(){
    CharLinkedList list1;
    CharLinkedList list2('a');
    list1.concatenate(&list2);
    assert(list1.toString() == "[CharLinkedList of size 1 <<a>>]");
}

// tests the concatenate() function on an empty second list
void testConcatenate_emptySecondList(){
    CharLinkedList list1('a');
    CharLinkedList list2;
    list1.concatenate(&list2);
    assert(list1.toString() == "[CharLinkedList of size 1 <<a>>]");
}
// tests the concatenate() function with a one item first list
void testConcatenate_oneItemFirstList(){
    CharLinkedList list1('a');
    
    char longList[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list2(longList, 5);


    list1.concatenate(&list2);
    assert(list1.toString() == "[CharLinkedList of size 6 <<aabcde>>]");
}
// tests the concatenate() function with a one item second list
void testConcatenate_oneItemSecondList(){
    CharLinkedList list1('a');
    
    char longList[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list2(longList, 5);


    list2.concatenate(&list1);
    assert(list2.toString() == "[CharLinkedList of size 6 <<abcdea>>]");
}

// tests the concatenate() function with a nonempty list on itself
void testConcatenate_sameList(){    
    char longList[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list2(longList, 5);
    list2.concatenate(&list2);
    assert(list2.toString() == "[CharLinkedList of size 10 <<abcdeabcde>>]");
}
// tests the concatenate() function with two lists with several elements each
void testConcatenate_twoLongList(){    
    char longList[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list1(longList, 5);

    char longList2[] = {'v', 'w', 'x', 'y', 'z'};
    CharLinkedList list2(longList2, 5);

    list1.concatenate(&list2);
   
    assert(list1.toString() == "[CharLinkedList of size 10 <<abcdevwxyz>>]");
}
// tests the toString() function on a list with one element
void testToString_oneItemList(){
    CharLinkedList list('a');
    assert(list.toString() == "[CharLinkedList of size 1 <<a>>]");
}
// tests the toString() function on an empty list
void testToString_emptyList(){
    CharLinkedList list;
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}
// tests the toString() function on a list with several elements
void testToString_longList(){
    char longList[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(longList, 5);

    assert(list.toString() == "[CharLinkedList of size 5 <<abcde>>]");
}

// tests the toReverseString() function on a list with one element
void testReverseToString_oneItemList(){
    CharLinkedList list('a');
    assert(list.toReverseString() == "[CharLinkedList of size 1 <<a>>]");
}
// tests the toReverseString() function on an empty list
void testReverseToString_emptyList(){
    CharLinkedList list;
    assert(list.toReverseString() == "[CharLinkedList of size 0 <<>>]");
}
// tests the toReverseString() function on a list with several elements
void testReverseToString_longList(){
    char longList[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(longList, 5);

    assert(list.toReverseString() == "[CharLinkedList of size 5 <<edcba>>]");
}
//tests the clear() function on a list with one element
void testClear_oneItemList(){
    CharLinkedList list('a');
    list.clear();
    assert(list.isEmpty());
}
// tests the clear() function on a list with several elements
void testClear_longList(){
    char longList[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(longList, 5);
    list.clear();
    assert(list.isEmpty());
}

// tests the copy constructor on a list with one element
void testCopyConstructor_oneItemList(){
    CharLinkedList list('a');
    CharLinkedList list2(list);

    assert(list2.toString() == "[CharLinkedList of size 1 <<a>>]");
}
// tests the copy constructor on a list with several elements
void testCopyConstructor_longList(){
    CharLinkedList list('a');
    list.pushAtBack('b');
    list.pushAtBack('b');
    list.pushAtBack('b');
    CharLinkedList list2 = list;
    assert(list2.toString() == "[CharLinkedList of size 4 <<abbb>>]");
}


// tests the overload assignment operator on a list with several elements
void testEqualsOperator_longList(){
    CharLinkedList list('a');
    list.pushAtBack('b');
    list.pushAtBack('b');
    list.pushAtBack('b');
    CharLinkedList list2;
    list2 = list;
    assert(list2.toString() == "[CharLinkedList of size 4 <<abbb>>]");
}

// tests the overload assignment operator on a list with one element
void testEqualsOperator_oneItemList(){
    CharLinkedList list('a');    
    CharLinkedList list2;
    list2 = list;
    assert(list2.toString() == "[CharLinkedList of size 1 <<a>>]");
}

// tests the overload assignment operator on two long lists
void testEqualsOperator_twoLongLists(){
    char longList[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(longList, 5);

    char longList2[] = {'v', 'w', 'x', 'y', 'z'};    
    CharLinkedList list2(longList2, 5);
    list2 = list;
    assert(list2.toString() == "[CharLinkedList of size 5 <<abcde>>]");
}
// tests overload assignment operator on one long list and a one element list
void testEqualsOperator_oneLongList(){
    char longList[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(longList, 5);

    CharLinkedList list2('a');
    list2 = list;
    assert(list2.toString() == "[CharLinkedList of size 5 <<abcde>>]");
}
// tests overload assignment operator on a one element list and a long list
void testEqualsOperator_oneLongListOtherWay(){
    char longList[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(longList, 5);

    CharLinkedList list2('a');
    list = list2;
    assert(list.toString() == "[CharLinkedList of size 1 <<a>>]");
}


/*
 *  CharLinkedList.cpp
 *  Megan Chung (mchung06)
 *  2/1/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  To implement the CharLinkedList class in CharLinkedList.h
 *
 */

#include "CharLinkedList.h"
#include <sstream>
#include <iostream> 
using namespace std;

/*
 * name:      CharLinkedList
 * purpose:   To build an empty constructor.
 * arguments: none.
 * returns:   nothing.
 * effects:   Sets the size, capacity, and list pointer of the CharLinkedList.
 */
CharLinkedList::CharLinkedList(){

    //initializing private member variables
    front = nullptr;
    back = nullptr;
    nsize = 0;

}

/*
 * name:      CharLinkedList
 * purpose:   To create a one element linked list consisting of that character
 * arguments: a character c representing a new element in the list.
 * returns:   nothing. 
 * effects:   Creates a one element CharLinkedList and initializes
 *            its variables.
 */
CharLinkedList::CharLinkedList(char c){

    //creating a new node on the heap and initializing it
    Node *currnode = newNode(c, nullptr, nullptr); 

    //initializing private member variables
    currnode->next = nullptr;
    currnode->previous = nullptr; 
    front = currnode;
    back = currnode;
    nsize = 1;
}

/*
 * name:      CharLinkedList
 * purpose:   To create an linked list containing the characters in the 
 *            passed-in linked.
 * arguments: an linked of characters and the integer length of that linked 
 *            of characters
 * returns:   nothing. 
 * effects:   Creates a CharLinkedList from an linked of chars and initializes
 *            its variables.
 */
CharLinkedList::CharLinkedList(char arr[], int insize){

    //initializing private member variables
    nsize = 0;
    back = nullptr;
    front = nullptr;

    //creating a list with the elements in the array
    for (int i = 0; i < insize; i++){
        pushAtBack(arr[i]);    
    }

}

/*
 * name:      CharLinkedList
 * purpose:   To make a deep copy of a given instance.
 * arguments: The address of a CharLinkedList called "other"
 * returns:   nothing.
 * effects:   Creates a deep copy of an instance. 
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other){

    //initializing private member variables to copy those of the other list
    nsize = 0;
    back = nullptr;
    front = nullptr;
    char new_char; 

    //copying each element from other and creating a new list with them
    for (int i = 0; i < other.nsize; i++){

        new_char = other.elementAt(i); 
        pushAtBack(new_char);
    }
} 

/*
 * name:      ~CharLinkedList
 * purpose:   To build a destructor that destroys/deletes/recycles all 
 *            heap-allocated data
 * arguments: none.
 * returns:   nothing.
 * effects:   Erases the CharLinkedList from the heap. 
 */
CharLinkedList::~CharLinkedList(){
    
    recursive_delete(front); 
}

/*
 * name:      recursive_delete
 * purpose:   To build a destructor that destroys/deletes/recycles all 
 *            heap-allocated data
 * arguments: a node pointer
 * returns:   nothing.
 * effects:   Erases the CharLinkedList nodes from the heap. 
 */
void CharLinkedList::recursive_delete(Node *curr){
   
    if (curr == nullptr){
        return; 
    }
    recursive_delete(curr->next);

    delete curr;
}

/*
 * name:      &CharLinkedList::operator=
 * purpose:   To define an assignment operator that recycles the storage
 *            associated with the instance
 * arguments: The address of another CharLinkedList
 * returns:   a pointer to the object on the left-hand side.
 * effects:   releases dynamically allocated memory associated with the object
 * on the left-hand side, creates a new copy of the object on the right-hand
 * side (including stuff on the heap its pointing to) and assigns this new 
 * copy to the object on the left-hand side
 */
CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other){

    recursive_delete(front); 
    
    //initializing private member variables to copy those of the other list
    nsize = 0;
    back = nullptr;
    front = nullptr;

    if (this == &other){
        return *this;
    }

    char new_char; 

    //copying each element from other and creating a new list with them
    for (int i = 0; i < other.nsize; i++){

        new_char = other.elementAt(i); 
        pushAtBack(new_char);
    }

    //returns the object on the left-hand side
    return *this; 
}

/*
 * name:      newNode
 * purpose:   To create a new node and assign its pointers.
 * arguments: a character c, a node pointer to the next node, a node pointer
 *            to the previous node
 * returns:   the new node.
 * effects:   creates a new node on the heap. 
 */
CharLinkedList::Node *CharLinkedList::newNode(char c, Node *next, \
    Node *previous){
    
    Node *new_node = new Node;
    new_node->c = c;

    //assigning pointers
    new_node->next = next;
    new_node->previous = previous;

    return new_node;
}

/*
 * name:      get_node_front
 * purpose:   To access a node at a specified element starting from the 
 *            front using recursion.
 * arguments: an integer index, a node pointer to the starting node
 * returns:   the node at the index.
 * effects:   accesses a node at a specific element in the list. 
 */
CharLinkedList::Node *CharLinkedList::get_node_front(int index, \
    Node *start_node) const{
    
    //initializing
    Node *curr = start_node; 

    //creating a stringstream for the error output
    stringstream error; 
    error << "index (" << index << ") not in range [0.." << nsize << ")";

    //checking for a valid index
    if (index < 0 or index >= nsize){
        throw range_error(error.str());

    }

    //if front node
    if (index == 0){
        return start_node; 
    }

    //recursive call
    return get_node_front(index - 1, curr->next);
    
}

/*
 * name:      get_node_back
 * purpose:   To access a node at a specified element starting from the 
 *            back using recursion.
 * arguments: an integer index, a node pointer to the starting node
 * returns:   the node at the index.
 * effects:   accesses a node at a specific element in the list. 
 */
CharLinkedList::Node *CharLinkedList::get_node_back(int index, \
    Node *start_n) const{
   
   //initializing
    Node *curr = start_n; 

    //creating a stringstream for the error output
    stringstream error; 
    error << "index (" << index << ") not in range [0.." << nsize << ")";

    //checking for a valid index
    if (index < 0 or index >= nsize){

        throw range_error(error.str());
    }

    // if front index
    if (index == 0){
        return start_n; 
    }

    //recursive call
    return get_node_back(index - 1, curr->previous);
}

/*
 * name:      isEmpty
 * purpose:   To determine if this specific instance of the class
 *            is empty or not. 
 * arguments: none.
 * returns:   a boolean value that is true if this specific instance of 
 *            the class is empty (has no characters) and false otherwise.
 * effects:   none. 
 */
bool CharLinkedList::isEmpty() const{

    if (front == nullptr){

        return true;
    }

    return false;
}

/*
 * name:      clear
 * purpose:   To make the instance into an empty linked list. 
 * arguments: none.
 * returns:   nothing.
 * effects:   deletes the nodes in linked list.
 */
void CharLinkedList::clear(){

    recursive_delete(front);
    front = nullptr;
    nsize = 0;
}

/*
 * name:      size
 * purpose:   To return the number of chars in the linked list.
 * arguments: none.
 * returns:   an integer value that is the number of characters 
 *            in the linked list
 * effects:   none.
 */
int CharLinkedList::size() const{

    return nsize;
}

/*
 * name:      first
 * purpose:   To find the first char in the linked list.
 * arguments: none.
 * returns:   The first char in the linked list.
 * effects:   if empty, throws std::runtime_error
 */
char CharLinkedList::first() const{

    if (isEmpty()){
        throw runtime_error("cannot get first of empty LinkedList");
    } 

    return front->c; 
}

/*
 * name:      last
 * purpose:   To find the last char in the linked list.
 * arguments: none.
 * returns:   the last char in the linked list
 * effects:   if empty, throws std::runtime_error
 */
char CharLinkedList::last() const{

    if (isEmpty()){
        throw runtime_error("cannot get last of empty LinkedList");
    }

    return back->c; 
}

/*
 * name:      elementAt
 * purpose:   To find a char at a specific index in the linked list.
 * arguments: an integer index
 * returns:   the element (char) in the linked list at the given index
 * effects:   if invalid index, throws std::range_error
 */
char CharLinkedList::elementAt(int index) const{
    
    //creating a stringstream for the error output
    stringstream error; 
    error << "index (" << index << ") not in range [0.." << nsize << ")";

    //checking for a valid index
    if (index < 0 or index >= nsize){

        throw range_error(error.str());

    }
    //making a temp node pointer
    Node *my_node; 

    //get a node starting from the front or back of the list
    if(index > nsize/2){
        my_node = get_node_back(nsize - index -1, back);

    } else {
        my_node = get_node_front(index, front);
    }

    return my_node->c;

}

/*
 * name:      toString
 * purpose:   To output the CharLinkedList as a string
 * arguments: none.
 * returns:   a string containing the chars of CharLinkedList
 * effects:   Creates a string of the chars in a CharLinkedList. 
 */
string CharLinkedList::toString() const{

    //creating a stringstream for the error output
    stringstream tstring; 
    tstring << "[CharLinkedList of size " << size() << " <<";
    
    //looping over the elements and adding each char to the string
    for (int i = 0; i < nsize; i++){
        tstring << elementAt(i); 
    }

    tstring << ">>]"; 
    
    return tstring.str(); 
    
}

/*
 * name:      toReverseString
 * purpose:   To output the CharLinkedList as a string in reversed order.
 * arguments: none.
 * returns:   a string containing the chars of CharLinkedList in reverse.
 * effects:   Creates a string of the chars in a CharLinkedList reversed. 
 */
string CharLinkedList::toReverseString() const{

    //creating a stringstream for the error output
    stringstream rstring; 
    rstring << "[CharLinkedList of size " << size() << " <<"; 

    //looping over the elements and adding each char to the string in reverse
    for (int i = nsize - 1; i > -1; i--){

        rstring << elementAt(i); 
    }
    rstring << ">>]";

    return rstring.str(); 
}

/*
 * name:      pushAtBack
 * purpose:   To insert the given element after the end of the 
 *            existing elements
 * arguments: an element (char)
 * returns:   nothing.
 * effects:   Inserts a given element at the back of a CharLinkedList. 
 */
void CharLinkedList::pushAtBack(char c){

    if(isEmpty()){

        //making a new node and assigning the back and front pointers to it
        back = newNode(c, nullptr, back);
        front = back; 

    } else {

        //making a new node and assigning it to the back's next pointer
        back->next = newNode(c, nullptr, back);

        //assigning the back pointer
        back = back->next; 
    }

    nsize++; 
}

/*
 * name:      pushAtFront
 * purpose:   To insert the given element in front of the existing elements
 * arguments: an element (char)
 * returns:   nothing.
 * effects:   Inserts a given element at the front of a CharLinkedList. 
 */
void CharLinkedList::pushAtFront(char c){

    if(isEmpty()){

        //making a new node and assigning the front and back pointers to it
        front = newNode(c, front, nullptr);
        back = front; 

    } else {

        //making a new node and assigning it to the front's previous pointer
        front->previous = newNode(c, front, nullptr); 

        //assigning the front pointer
        front = front->previous; 
    }

    nsize++;
}

/*
 * name:      insertAt
 * purpose:   To insert the new element at the specified index and 
 *            shift the existing elements as necessary. 
 * arguments: an element (char) and an integer index
 * returns:   nothing.
 * effects:   Inserts a given element at the given index of a CharLinkedList.
 *            Throws std::range_error if inputted index is invalid.
 */
void CharLinkedList::insertAt(char c, int index){
   
    //creating a stringstream for the error output
    stringstream error; 
    error << "index (" << index << ") not in range [0.." << nsize << "]";

    //checking for valid index 
    if (index < 0 or index > nsize){
        throw range_error(error.str());
    }

    if(index == 0){
        pushAtFront(c); 
        return; 
    }

    if(index == nsize){
        pushAtBack(c);
        return;
    }

    //making temporary node pointers
    Node *original = nullptr; 
    Node *before = nullptr; 

    //get a node starting from the front or back of the list
    if(index > nsize/2){
        original = get_node_back(nsize - index -1, back);
        before = original->previous;

    } else {
        original = get_node_front(index, front);
        before = original->previous;
    }

    //making a new node 
    Node *inserted = newNode(c, original, before); 
    
    //setting the original node's previous to the newly inserted node
    original->previous = inserted;

    //setting the next pointer to the newly inserted node
    before->next = inserted; 

    nsize++;

}

/*
 * name:      insertInOrder
 * purpose:   To insert the new element in ASCII order and shift the 
 *            existing elements as necessary. 
 * arguments: an element (char)
 * returns:   nothing.
 * effects:   Inserts a given element in ASCII order. 
 */
void CharLinkedList::insertInOrder(char c){

    //inserting at the front if the list is empty
    if (isEmpty()){
        insertAt(c, 0);
    }

    //inserting the letter at the index of the element c is less than
    for (int i = 0; i < nsize; i++){

        if (c < elementAt(i)){

            insertAt(c, i); 
            return;

        } 
    }

    //adding to the back if c is greater than all elements
    pushAtBack(c);
}

/*
 * name:      popFromFront
 * purpose:   To remove the first element from the linked list. 
 * arguments: none.
 * returns:   nothing.
 * effects:   removes the first element from the linked list and 
 *            throws std::runtime_error if the list is empty.
 */
void CharLinkedList::popFromFront(){

    //removing first element of the list
    if (isEmpty()){
        throw runtime_error("cannot pop from empty LinkedList");
    }

    //assigning the front pointer to the next node
    front = front->next;

    //delete the original front node
    delete front->previous; 

    //set the new front's previous pointer
    front->previous = nullptr;
}

/*
 * name:      popFromBack
 * purpose:   To remove the last element from the linked list. 
 * arguments: none.
 * returns:   nothing.
 * effects:   removes the last element from the linked list and 
 *            throws std::runtime_error if the list is empty.
 */
void CharLinkedList::popFromBack(){

    //decrementing the size to "remove" the last element of the list
    if (isEmpty()){
        throw runtime_error("cannot pop from empty LinkedList");
    }
    
    //assigning the back pointer to the previous node
    back = back->previous;

    //delete the original back node
    delete back->next;

    //set the new back's next pointer
    back->next = nullptr;

}

/*
 * name:      removeAt
 * purpose:   To remove an element at a specified index from the linked list. 
 * arguments: an integer index
 * returns:   nothing.
 * effects:   removes element at specified index and throws a std::range_error
 *            if invalid index
 */
void CharLinkedList::removeAt(int index){
    //creating a stringstream for the error output
    stringstream error; 
    error << "index (" << index << ") not in range [0.." << nsize << ")";
    //checking for valid index
    if (index < 0 or index >= nsize){
        throw range_error(error.str());
    }
    //making temp node pointers
    Node *original;
    Node *before; 
    Node *after;
    //get a node from the front or back of the list and saving pointers
    if (index > nsize/2){
        original = get_node_back(nsize - index - 1, back);
        before = original->previous;
        after = original->next;
    } else {
        original = get_node_front(index, front);
        before = original->previous;
        after = original->next;
    }
    //setting the next pointer of the node before original to the node after
    before->next = after;
    //setting the prev pointer of the node after original to the node before
    after->previous = before;
    delete original;
    nsize--;
}

/*
 * name:      replaceAt
 * purpose:   To replace an element at a specified index from the linked list.
 * arguments: an element(char) and an integer index
 * returns:   nothing.
 * effects:   replaces element at specified index and throws a 
 *            std::range_error if invalid index
 */
void CharLinkedList::replaceAt(char c, int index){

    removeAt(index);
    insertAt(c, index); 
}

/*
 * name:      concatenate
 * purpose:   To add a copy of the linked list pointed to by the parameter 
 *            value to the end of the linked list the function was called from
 * arguments: a pointer to a second CharLinkedList
 * returns:   nothing.
 * effects:   adds a copy of one linked list to the back of another. 
 */
void CharLinkedList::concatenate(CharLinkedList *other){

    int osize = other->size();

    //adding elements from the other list to the back of the original list.
    for (int i = 0; i <  osize; i++){
       
        pushAtBack(other->elementAt(i));  
    }

}




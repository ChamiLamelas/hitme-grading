/*
 *  unit_tests.h
 *  Megan Chung (mchung06)
 *  2/1/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  To test the functions implemented in CharLinkedList.cpp
 *
 */


#include "CharLinkedList.h"
#include <cassert>

/********************************************************************\
*                       CHAR ARRAY LIST TESTS                        *
\********************************************************************/

/* testing the basic constructor */
void test_constructor(){
    CharLinkedList my_list; 
}

/* testing the one element input constructor */
void test_second_con(){
    CharLinkedList test_list('a');
    assert(test_list.size() == 1);
}

/* testing the input array constructor */
void test_third_con(){
    char test_arr[3] = { 'a', 'b', 'c'};
    CharLinkedList test_list(test_arr, 3);
    assert(test_list.size() == 3);
}

/* testing the deep copy constructor */
void test_deep_copy(){
    char test_arr[3] = { 'a', 'b', 'c'};
    CharLinkedList test_list(test_arr, 3);

    CharLinkedList copy_list(test_list); 

    assert(copy_list.toString() == "[CharLinkedList of size 3 <<abc>>]");


}

/* testing assignment operator */
void test_assignment_operator(){
    char test_arr[3] = { 'a', 'b', 'c'};
    CharLinkedList test_list(test_arr, 3);

    char copy_arr[3] = { 'd', 'e', 'f'};
    CharLinkedList copy_list(copy_arr, 3);

    copy_list = test_list;

    assert(copy_list.toString() == "[CharLinkedList of size 3 <<abc>>]");
}

// void test_get_node_front(){

//     CharLinkedList test_list('a');
//     assert(test_list.get_node_front(0, test_list.front)->c == 'a');

// }

// void test_get_node_back(){

//     CharLinkedList test_list('a');
//     assert(test_list.get_node_back(0, test_list.back)->c == 'a');

// }

// void test_get_node_front_empty(){

//     CharLinkedList test_list;
    // std::string error_message = "";

    // try {
    //     test_list.test_list.get_node_front(0, test_list.front);
    // }
    // catch (const std::range_error &e) {
    //     error_message = e.what();
    // }

// }

// void test_get_node_back_empty(){    
    // CharLinkedList test_list;
    // std::string error_message = "";

    // try {
    //     test_list.test_list.get_node_back(0, test_list.back);
    // }
    // catch (const std::range_error &e) {
    //     error_message = e.what();
    // }


// }

/* testing isEmpty*/
void test_empty(){
    CharLinkedList test_list;
    assert(test_list.isEmpty()); 
}

/* testing a false isEmpty */
void test_false_empty(){
    CharLinkedList test_list('a');
    assert(not (test_list.isEmpty())); 
}

/* testing clear */
void test_clear(){
    CharLinkedList test_list;
    test_list.insertAt('a', 0);
    test_list.clear();
    assert(test_list.size() == 0);
    assert(test_list.isEmpty());
}

/* testing clear */
void test_clear_elem(){
    CharLinkedList test_list('a');
    test_list.clear();
    assert(test_list.isEmpty());
}

/* testing clear with an empty array */
void test_emptyc(){
    CharLinkedList test_list;
    test_list.clear();
    assert(test_list.isEmpty()); 
}

/* testing clear on a big list */
void test_bigc(){

    char test_arr[8] = { 'a', 'c', 'd', 'e', 'f', 'g', 'h', 'i'};
    CharLinkedList test_list(test_arr, 8);
    test_list.clear();
    assert(test_list.isEmpty()); 
}

/* testing size */
void test_size(){
    CharLinkedList test_list('a');
    assert(test_list.size() == 1);
}

/* testing size on a big list */
void test_bigs(){

    char test_arr[8] = { 'a', 'c', 'd', 'e', 'f', 'g', 'h', 'i'};
    CharLinkedList test_list(test_arr, 8);
  
    assert(test_list.size() == 8); 
}

/* testing size on an empty list */
void test_emptys(){
    CharLinkedList test_list;
    assert(test_list.size() == 0);
}

/* testing first */
void test_first(){
    CharLinkedList test_list('a');
    test_list.insertAt('b', 1);
    assert(test_list.first() == 'a');
}

/* testing first on an empty list */
void test_emptyfirst(){

    CharLinkedList test_list;
    std::string error_message = "";

    try {
        test_list.first();
    }
    catch (const std::runtime_error &e) {
        error_message = e.what();
    }

}

/* testing last */
void test_last(){
    CharLinkedList test_list('a');
    test_list.insertAt('b', 1);
    assert(test_list.last() == 'b');
}

/* testing last on an empty list */
void test_emptylast(){
   CharLinkedList test_list;
    std::string error_message = "";

    try {
        test_list.last();
    }
    catch (const std::runtime_error &e) {
        error_message = e.what();
    } 
}

/* testing elementAt */
void test_elementat(){
    CharLinkedList test_list('a');
    test_list.insertAt('b', 1);
    assert(test_list.elementAt(0) == 'a');
}

/* testing elementAt on a big list*/
void test_elementatbig(){
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);
    assert(test_list.elementAt(0) == 'a');
}

/* testing elementAt on an empty list */
void test_empty_ea(){

    CharLinkedList test_list;
    std::string error_message = "";

    try {
        test_list.elementAt(0);
    }
    catch (const std::range_error &e) {
        error_message = e.what();
    }
}

/* testing toString */
void test_tostring(){

    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    assert(test_list.toString() == "[CharLinkedList of size 8 <<abcdefgh>>]");

}

/* testing toString on an empty list */
void test_emptyTsrting(){
    
    CharLinkedList test_list;
    assert(test_list.toString() == "[CharLinkedList of size 0 <<>>]");
    

}

/* testing toReverseString */
void test_toReverseString(){

    char test_arr[3] = { 'a', 'b', 'c'};
    CharLinkedList test_list(test_arr, 3);

    assert(test_list.toReverseString() == 
    "[CharLinkedList of size 3 <<cba>>]");

}

/* testing toReverseString on a long list */
void test_longtoRstring(){

    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);    

    assert(test_list.toReverseString() ==
     "[CharLinkedList of size 8 <<hgfedcba>>]");

}

/* testing toReverseString on an empty list */
void test_emptyRsrting(){
    
    CharLinkedList test_list;
    assert(test_list.toReverseString() == "[CharLinkedList of size 0 <<>>]");
}

/* testing pushBack */
void test_pushback(){

    CharLinkedList test_list('a');
    test_list.pushAtBack('b');
    assert(test_list.last() == 'b');
}

void test_insert(){

    CharLinkedList test_list('a');
    test_list.insertAt('b', 1);
    assert(test_list.last() == 'b');
}

/* testing pushBack on an empty list */
void test_empty_pb(){

    CharLinkedList test_list;
    test_list.pushAtBack('b');
    assert(test_list.elementAt(0) == 'b');
}

/* testing pushFront */
void test_pushfront(){
    CharLinkedList test_list('a');
    test_list.pushAtFront('b');
    assert(test_list.first() == 'b');
}

/* testing pushFront on an empty list */
void test_empty_pf(){

    CharLinkedList test_list;
    test_list.pushAtFront('b');
    assert(test_list.elementAt(0) == 'b');
}

/* testing insertInOrder */
void test_insertInOrder(){

    char test_arr[3] = { 'a', 'c', 'd'};
    CharLinkedList test_list(test_arr, 3);

    test_list.insertInOrder('b');

    std::cerr << test_list.toString() << std::endl;

    assert(test_list.toString() == "[CharLinkedList of size 4 <<abcd>>]");

}

void test_insert_extra(){

    char test_arr[3] = { 'a', 'c', 'd'};
    CharLinkedList test_list(test_arr, 3);

    test_list.insertAt('b', 1);

    std::cerr << test_list.toString() << std::endl;

    assert(test_list.toString() == "[CharLinkedList of size 4 <<abcd>>]");


}
 
/* testing insertInOrder on a long list */
void test_longiio(){

    char test_arr[8] = { 'a', 'c', 'd', 'e', 'f', 'g', 'h', 'i'};
    CharLinkedList test_list(test_arr, 8);

    test_list.insertInOrder('b');

    assert(test_list.toString() == "[CharLinkedList of size 9 <<abcdefghi>>]");

}

/* testing insertInOrder on an empty list */
void test_emptyiio(){

    CharLinkedList test_list;
    test_list.insertInOrder('b');

    assert(test_list.elementAt(0) == 'b');
}

/* testing popFront */
void test_popfront(){

    char test_arr[3] = { 'a', 'b', 'c'};
    CharLinkedList test_list(test_arr, 3);

    test_list.popFromFront();

    std::cout << test_list.first() << std::endl;
    assert(test_list.first() == 'b'); 
}

/* testing popFront on an empty list */
void test_emptypf(){

    CharLinkedList test_list;

    std::string error_message = "";

    try {
        test_list.popFromFront();
    }
    catch (const std::runtime_error &e) {
        error_message = e.what();
    }
}

/* testing popBack */
void test_popback(){

    char test_arr[3] = { 'a', 'b', 'c'};
    CharLinkedList test_list(test_arr, 3);

    test_list.popFromBack();

    assert(test_list.last() == 'b');
}

/* testing popBack on an empty list */
void test_emptypb(){

    CharLinkedList test_list;
    std::string error_message = "";

    try {
        test_list.popFromBack();
    }
    catch (const std::runtime_error &e) {
        error_message = e.what();
    } 
}

/* testing removeAt */
void test_removeAt(){
    
    char test_arr[3] = { 'a', 'b', 'c'};
    CharLinkedList test_list(test_arr, 3);

    test_list.removeAt(1);

    assert(test_list.elementAt(1) == 'c');
}

/* testing removeAt on an empty list */
void test_emptyra(){

    CharLinkedList test_list;
    std::string error_message = "";

    try {
        test_list.removeAt(0);
    }

    catch (const std::range_error &e) {
        error_message = e.what();
    }
}

/* testing replaceAt */
void test_replaceAt(){

    char test_arr[3] = { 'a', 'b', 'c'};
    CharLinkedList test_list(test_arr, 3);

    test_list.replaceAt('z', 1);

    assert(test_list.elementAt(1) == 'z');
    assert(test_list.toString() == "[CharLinkedList of size 3 <<azc>>]");
}

/* testing replaceAt on an empty list */
void test_emptyrea(){

    CharLinkedList test_list;
    std::string error_message = "";

    try {
        test_list.replaceAt('a', 0);
    }

    catch (const std::range_error &e) {
        error_message = e.what();
    } 
}

/* testing concatenate */
void test_concatenate(){

    char test_arr[2] = { 'c', 'o'};
    CharLinkedList test_list(test_arr, 2);

    char test_arr2[2] = { 'o', 'l'};
    CharLinkedList test_list2(test_arr2, 2);

    test_list.concatenate(&test_list2); 
    std::cout << test_list.toString() << std::endl;
    assert(test_list.toString() == "[CharLinkedList of size 4 <<cool>>]");
}

/* testing concatenate (calling on an empty list) */
void test_empty1concat(){

    CharLinkedList test_list;

    char test_arr[2] = { 'h', 'i'};
    CharLinkedList test_list2(test_arr, 2);

    test_list.concatenate(&test_list2);

    assert(test_list.toString() == "[CharLinkedList of size 2 <<hi>>]");
}

/* testing call concatenate (passing in an empty list) */
void test_empty2concat(){

    char test_arr[2] = { 'h', 'i'};
    CharLinkedList test_list(test_arr, 2);

    CharLinkedList test_list2;

    test_list.concatenate(&test_list2);

    assert(test_list.toString() == "[CharLinkedList of size 2 <<hi>>]");
}

/* testing concatenate on itself */
void test_concat_self(){

    char test_arr[2] = { 'h', 'i'};
    CharLinkedList test_list(test_arr, 2);


    test_list.concatenate(&test_list);

    assert(test_list.toString() == "[CharLinkedList of size 4 <<hihi>>]");
}

// Tests correct insertion into an empty AL.
// Afterwards, size should be 1 and element at index 0
// should be the element we inserted.
void insertAt_empty_correct() { 

    CharLinkedList test_list;
    test_list.insertAt('a', 0);
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');

}

// Tests incorrect insertion into an empty AL.
// Attempts to call insertAt for index larger than 0.
// This should result in an std::range_error being raised.
void insertAt_empty_incorrect() {

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
        // insertAt for out-of-range index
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        // if insertAt is correctly implemented, a range_error will be thrown,
        // and we will end up here
        range_error_thrown = true;
        error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0]");
    
}
 
// Tests correct insertAt for front of 1-element list.
void insertAt_front_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at front
    test_list.insertAt('b', 0);

    assert(test_list.size() == 2);
    assert(test_list.last() == 'a');
    assert(test_list.first() == 'b');
    
}

// Tests correct insertAt for back of 1-element list.
void insertAt_back_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at back
    test_list.insertAt('b', 1);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    
}

// Tests calling insertAt for a large number of elements.
// Not only does this test insertAt, it also checks that
// array expansion works correctly.
void insertAt_many_elements() {
    
    CharLinkedList test_list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.insertAt('a', i);
    }

    assert(test_list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
    
}

// Tests insertion into front of a larger list
void insertAt_front_large_list() {
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    test_list.insertAt('y', 0);

    assert(test_list.size() == 10);
    assert(test_list.elementAt(0) == 'y');
    assert(test_list.toString() == 
    "[CharLinkedList of size 10 <<yabczdefgh>>]");

}

// Tests insertion into the back of a larger list
void insertAt_back_large_list() {

    char test_arr[10] = { 'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 10);  

    test_list.insertAt('x', 10);

    assert(test_list.size() == 11);
    assert(test_list.elementAt(10) == 'x');
    assert(test_list.toString() == 
    "[CharLinkedList of size 11 <<yabczdefghx>>]"); 

}

// Tests insertion into the middle of a larger list
void insertAt_middle_large_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.insertAt('z', 3);

    assert(test_list.size() == 9);
    assert(test_list.elementAt(3) == 'z');
    assert(test_list.toString() == "[CharLinkedList of size 9 <<abczdefgh>>]");

}

// Tests out-of-range insertion for a non-empty list.
void insertAt_nonempty_incorrect() {
   
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.insertAt('a', 42);
    }

    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8]");
    
}

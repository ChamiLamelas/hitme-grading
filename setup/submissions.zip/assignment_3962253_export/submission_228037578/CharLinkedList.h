/*
 *  CharLinkedList.h
 *  Emerson Wang
 *  2/6/24
 *
 *  COMP 15 HW 2 
 *
 *  CharLinkedList is a doubly linked list of characters,
 *  meaning each element has a previous and a next pointer.
 *  The linked list can be initialized as empty, with one 
 *  element, with multiple elements, or as a copy of another
 *  list. Elements can be added with insertAt, pushAtBack,
 *  pushAtFront. Elements can be removed with removeAt, 
 *  popAtFront, and popAtBack. They can be replaced with
 *  replaceAt. The index of the list starts at 0, and ends 
 *  at numItems - 1.
 *  Linked lists are more efficient than array lists when 
 *  performing operations at the front. 
 */
#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H
#include <string>

class CharLinkedList {
public:
    CharLinkedList();
    CharLinkedList(char c);
    CharLinkedList(char arr[], int size);
    CharLinkedList(const CharLinkedList &other);
    ~CharLinkedList();

    CharLinkedList& operator=(const CharLinkedList& other);
    
    bool isEmpty() const;
    void clear();
    int size() const;
    char first() const;
    char last() const;
    char elementAt(int index) const;
    std::string toString() const;
    std::string toReverseString() const;
    void pushAtBack(char c);
    void pushAtFront(char c);
    void insertAt(char c, int index);
    void insertInOrder(char c);

    void popFromFront();
    void popFromBack();
    void removeAt(int index);
    void replaceAt(char c, int index);
    void concatenate(CharLinkedList *other);
    
private:
    struct Node {
        char info;
        Node *next;
        Node *prev;
        std::string toString() { return std::string(1, info); };
    };
    Node *front;
    int numItems;
    void recursive_destructor_helper(Node *currNode);
    char recursive_element_helper(Node *currNode, int index) const;
    void recursive_replace_helper(Node *curr, int index, char c);
};
#endif
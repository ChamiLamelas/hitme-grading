/*
 *  CharLinkedList.cpp
 *  Emerson Wang
 *  2/6/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  This cpp file implements the CharLinkedList described in 
 *  CharLinkedList.h. The destructor, elementAt, and replaceAt
 *  functions are implemented recursively. Because there is no
 *  back pointer, operations at the back of the list may take
 *  longer
 *
 */

#include "CharLinkedList.h"
#include <sstream>
#include "stdexcept"
#include <iostream>
#include <string>
using namespace std;
/*
 * name:      CharLinkedList
 * purpose:   constructor of an empty CharLinkedList
 * arguments: none
 * returns:   an empty CharLinkedList
 */
CharLinkedList::CharLinkedList() {
    front = nullptr;
    
    numItems = 0;
}
/*
 * name:      CharLinkedList
 * purpose:   constructor of a CharLinkedList with one char
 * arguments: one
 * returns:   a CharLinkedList with one character
 */
CharLinkedList::CharLinkedList(char c) {
    numItems = 1;
    front = new Node();
    front->info = c;
    front->next = nullptr;
    front->prev = nullptr;
}
/*
 * name:      CharLinkedList
 * purpose:   constructor of a CharLinkedList with multiple chars
 * arguments: an array and the size of the array
 * returns:   a CharLinkedList with multiple character
 */
CharLinkedList::CharLinkedList(char arr[], int size){
    numItems = 0;
    front = nullptr;
    for(int i = 0; i < size; i++)
    {
        pushAtBack(arr[i]);
    }
}
/*
 * name:      CharLinkedList
 * purpose:   a copy constructor of another CharLinkedList
 * arguments: another CharLinkedList
 * returns:   a CharLinkedList that is a copy of another
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other){
    numItems = 0;
    front = nullptr;
    for(int i = 0; i < other.size(); i++)
    {
        pushAtBack(other.elementAt(i));
    }
}
/*
 * name:      operator=
 * purpose:   sets this CharLinkedList equal to another
 * arguments: another CharLinkedList
 * returns:   this
 * effects:   deletes already existing data and copies data 
 *            from other
 */

CharLinkedList& CharLinkedList::operator=(const CharLinkedList& other){
    clear();
    for(int i = 0; i < other.size(); i++)
    {
        pushAtBack(other.elementAt(i));
    }
    return *this;
}

/*
 * name:      ~CharLinkedList
 * purpose:   CharLinkedList destructor
 * arguments: none
 * returns:   none
 * effects:   clears space when CharLinkedList goes out of scope
              calls a private recursive helper function
 */
CharLinkedList::~CharLinkedList() {
    if(front != nullptr)
    {
        recursive_destructor_helper(front);
    }
}
    
/*
 * name:      size
 * purpose:   returns the size of the CharLinkedList
 * arguments: none
 * returns:   integer of size of CharLinkedList
 * effects:   none
 */
int CharLinkedList::size() const {
    return numItems;
}
/*
 * name:      clear
 * purpose:   clears the CharLinkedList
 * arguments: none
 * returns:   integer of size of CharLinkedList
 * effects:   clears the previous data on the heap
              using a private recursive destructor helper
 */
void CharLinkedList::clear(){
    numItems = 0;
    recursive_destructor_helper(front);
    front = nullptr;
}
/*
 * name:      first
 * purpose:   returns the first element of the LinkedList
 * arguments: none
 * returns:   the first element of the LinkedList
 * effects:   throws an error if LinkedList is empty
 */
char CharLinkedList::first() const{
    if (front == nullptr)
    {
        throw runtime_error("cannot get first of empty LinkedList");
    }
    return elementAt(0);
}
/*
 * name:      last
 * purpose:   returns the last element of the LinkedList
 * arguments: none
 * returns:   the last element of the LinkedList
 * effects:   throws an error if LinkedList is empty
 */
char CharLinkedList::last() const{
    if (front == nullptr)
    {
        throw runtime_error("cannot get last of empty LinkedList");
    }
    return elementAt(numItems-1);
}
/*
 * name:      elementAt
 * purpose:   returns an element of the LinkedList
 * arguments: integer index
 * returns:   the element at the given index
 * effects:   throws an error if LinkedList is empty or if the index 
              is out of range
              calls a private recursive helper function
 */
char CharLinkedList::elementAt(int index) const{

    if (front == nullptr or index < 0 or index >= numItems) {
        throw range_error("index (" + std::to_string(index) + ") not in range "\
        "[0.." + std::to_string(numItems) + ")");
    }
    return recursive_element_helper(front, index);
}
/*
 * name:      isEmpty
 * purpose:   returns true if LinkedList is empty
 * arguments: none
 * returns:   true if LinkedList is empty
 * effects:   none
 */
bool CharLinkedList::isEmpty() const {
    return(numItems == 0);
}
/*
 * name:      toString
 * purpose:   returns LinkedList as string representation
 * arguments: none
 * returns:   LinkedList as string representation
 * effects:   none
 */
std::string CharLinkedList::toString() const {
    std::stringstream ss;
    ss << "[CharLinkedList of size ";
    ss << numItems;
    ss << " <<";

    for(int i = 0; i < numItems; i++)
    {
        ss << elementAt(i);
    }
    ss << ">>]";
    return ss.str();
}
/*
 * name:      toReverseString
 * purpose:   returns LinkedList as string representation
              back to front
 * arguments: none
 * returns:   LinkedList as string representation back to front
 * effects:   none
 */
std::string CharLinkedList::toReverseString() const {
    std::stringstream ss;
    ss << "[CharLinkedList of size ";
    ss << numItems;
    ss << " <<";

    for(int i = numItems-1; i >= 0; i--)
    {
        ss << elementAt(i);
    }
    ss << ">>]";
    return ss.str();
}
/*
 * name:      pushAtBack
 * purpose:   adds element to back of LinkedList
 * arguments: character elem
 * returns:   none
 * effects:   calls insertAt
 */
void CharLinkedList::pushAtBack(char elem) {
    insertAt(elem, numItems);
}
/*
 * name:      pushAtFront
 * purpose:   adds element to front of LinkedList
 * arguments: character elem
 * returns:   none
 * effects:   calls insertAt
 */
void CharLinkedList::pushAtFront(char elem) {
    insertAt(elem, 0);
}
/*
 * name:      insertAt
 * purpose:   inserts element at given index
 * arguments: character elem and integer index
 * returns:   none
 * effects:   allocates data on the heap to add element
 */
void CharLinkedList::insertAt(char c, int index){
    if (index < 0 or index > numItems) {
        throw range_error("index (" + std::to_string(index) + ") not in range "\
        "[0.." + std::to_string(numItems) + "]");
    }
     //find node at index
    else if(numItems == 0)
    {
        front = new Node();
        front->info = c;
        front->next = nullptr;
        front->prev = nullptr;
    }
    else if(index == 0)
    {
        Node *curr = new Node();
        curr->info = front->info;
        curr->next = front->next;
        front->next = curr;
        curr->prev = front;
        front->info = c;
        front->prev = nullptr;
    }
    else if(index == numItems)
    {
        Node *last_node = front;
        for(int i = 0; i < numItems-1; i++)
        {
            last_node = last_node->next;
        }
        Node *curr = new Node();
        last_node->next = curr;
        curr->info = c;
        curr->next = nullptr;
        curr->prev = last_node;
    }
    else{
        Node *newNode = new Node();
        newNode->info = c;
        Node *currNode = front;
        for(int i = 0; i < index-1; i++)
        {
            currNode = currNode->next;
        }
        newNode->next = currNode->next;
        newNode->prev = currNode;
        currNode->next = newNode;
        newNode->next->prev = newNode;
        
    }
   //Update size
    numItems++;
}
/*
//  * name:      insertInOrder
//  * purpose:   inserts element at alphabetcially correct position
//  * arguments: character c
//  * returns:   none
//  * effects:   calls insertAt
//  */
void CharLinkedList::insertInOrder(char c){
    bool inserted = false;
    for(int i = 0; i < numItems; i++)
    {
        if (c < elementAt(i) and not(inserted))
        {
            insertAt(c, i);
            inserted = true;
        }
    }
    if(not (inserted)){
        pushAtBack(c);
    }
}
/*
 * name:      popFromFront
 * purpose:   deletes first element
 * arguments: none
 * returns:   none
 * effects:   calls removeAt, throws runtime error if empty
 */
void CharLinkedList::popFromFront() {
    if(front == nullptr){
        throw runtime_error("cannot pop from empty LinkedList");
    }
    removeAt(0);
}
/*
 * name:      popFromBack
 * purpose:   deletes last element
 * arguments: none
 * returns:   none
 * effects:   calls removeAt, throws runtime error if empty
 */
void CharLinkedList::popFromBack() {
    if(front == nullptr){
        throw runtime_error("cannot pop from empty LinkedList");
    }
    removeAt(numItems-1);
}
/*
 * name:      removeAt
 * purpose:   deletes element at given index
 * arguments: integer index
 * returns:   none
 * effects:   throws range error if given index not correct
 */
void CharLinkedList::removeAt(int index) {
    if (index < 0 or index >= numItems or front == nullptr) {
        throw range_error("index (" + std::to_string(index) + ") not in range "\
        "[0.." + std::to_string(numItems) + ")");
    }
    else if(index == 0)
    {
        if(numItems == 1){
            delete front;
            front = nullptr;
        }
        else{
            front = front->next;
            delete front->prev;
        }
    }
    else if(index == numItems-1)
    {
        Node *currNode = front;
        for(int i = 0; i < index-1; i++)
        {
            currNode = currNode->next;
        }
        delete currNode->next;
        currNode->next = nullptr;
    }
    else{
        Node *beforeNode = front;
        for(int i = 0; i < index-1; i++)
        {
            beforeNode = beforeNode->next;
        }
        Node *afterNode = beforeNode;
        for(int i = 0; i < 2; i++)
        {
            afterNode = afterNode->next;
        }
        delete beforeNode->next;
        beforeNode->next = afterNode;
        afterNode->prev = beforeNode;

    }
    numItems--;
}

/*
 * name:      replaceAt
 * purpose:   replaces element at given index
 * arguments: character c, integer index
 * returns:   none
 * effects:   throws range error if given index not correct
              calls a private recursive helper function
 */
void CharLinkedList::replaceAt(char c, int index) {
    if (front == nullptr or index < 0 or index >= numItems) {
        throw range_error("index (" + std::to_string(index) + ") not in range "\
        "[0.." + std::to_string(numItems) + ")");
    }
    return recursive_replace_helper(front, index, c);
}
/*
 * name:      concatenate
 * purpose:   concatenates one LinkedList (other) onto this one
 * arguments: another LinkedList
 * returns:   none
 * effects:   sets an original size to ensure self-concat is possible
 */
void CharLinkedList::concatenate(CharLinkedList *other) {
    int original_size = other->size();
    for(int i = 0; i < original_size; i++)
    {
        pushAtBack(other->elementAt(i));
    }
}
/*
 * name:      recursive_destructor_helper
 * purpose:   recursively recycles all memory once allocated
 * arguments: the current node
 * returns:   none
 * effects:   recurses to the end of the list, and deletes the
 *            list back to front
              returns if the currNode is nullptr or the list is 
              empty
 */
void CharLinkedList::recursive_destructor_helper(Node *currNode) {
    if(currNode == nullptr){
        return;
    }
    else
    {
        recursive_destructor_helper(currNode->next);
        delete currNode;
    }
}
/*
 * name:      recursive_element_helper
 * purpose:   recursively finds the element index away from the 
              the current node
 * arguments: the current node and integer index
 * returns:   a character from the element index away from
              the current node.
 * effects:   recurses to the next node, incrementing index by -1
              ends recursion if the index is zero
 */
char CharLinkedList::recursive_element_helper(Node *currNode, int index) const{
    if(index == 0){
        return currNode->info;
    }
    else
    {
        return recursive_element_helper(currNode->next, index-1);
    }
}
/*
 * name:      recursive_replace_helper
 * purpose:   recursively finds the element index away from the 
              the current node and replaces it
 * arguments: the current node, integer index and the new character
 * returns:   nothing
 * effects:   recurses to the next node, incrementing index by -1
              ends recursion if the index is zero, replacing the info
              at currNode
              similar to recursive_element_helper
 */
void CharLinkedList::recursive_replace_helper(Node *curr, int index, char c) {
    if(index == 0){
        curr->info = c;
    }
    else
    {
        recursive_replace_helper(curr->next, index-1, c);
    }
}

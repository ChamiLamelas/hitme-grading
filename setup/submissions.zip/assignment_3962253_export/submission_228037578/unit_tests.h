/*
 *  unit_tests.h
 *  Emerson Wang
 *  2/1/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  Uses Matt Russell's unit_test framework to test the CharLinkedList class.
 *
 * 
 */
 #include "CharLinkedList.h"
#include <cassert>
#include <iostream>
#include <string>
using namespace std;
/********************************************************************\
*                       CHAR LINKED LIST TESTS                        *
\********************************************************************/


// Tests all constructor types and asserts their size
// and an element
void constructor_test_0() {
    CharLinkedList list;
    assert(list.size() == 0);
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}
void constructor_test_1() {
    CharLinkedList test_list('a');
    assert(test_list.size() == 1);
    assert(test_list.toString() == "[CharLinkedList of size 1 <<a>>]");
}
void constructor_test_2() {
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);
    assert(test_list.size() == 9);
    assert(test_list.toString() == "[CharLinkedList of size 9 <<abczdefgh>>]");
}
void constructor_test_3() {
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList first_list(test_arr, 9);
    CharLinkedList test_list(first_list);
    assert(test_list.size() == 9);
    assert(test_list.toString() == "[CharLinkedList of size 9 <<abczdefgh>>]");
}
// Tests equals operator
void equals_test(){
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList first_list(test_arr, 9);
    CharLinkedList test_list;
    test_list = first_list;
    assert(test_list.size() == 9);
    assert(test_list.toString() == "[CharLinkedList of size 9 <<abczdefgh>>]");
}
// Tests clear and isEmpty
void clear_test(){
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList list(test_arr, 9);
    list.clear();
    assert(list.size() == 0);
    assert(list.isEmpty());
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
} 
// Tests first and last functions
void first_working_test(){
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList list(test_arr, 9);
    assert(list.first() == 'a');
}
void first_error_test(){
    CharLinkedList list;
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
    // insertAt for out-of-range index
    list.first();
    }
    catch (const std::runtime_error &e) {
    // if insertAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    runtime_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(runtime_error_thrown);
    assert(error_message == "cannot get first of empty LinkedList");
}
void last_working_test(){
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList list(test_arr, 9);
    assert(list.last() == 'h');
}
void last_error_test(){
    CharLinkedList list;
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
    // insertAt for out-of-range index
    list.last();
    }
    catch (const std::runtime_error &e) {
    // if insertAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    runtime_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(runtime_error_thrown);
    assert(error_message == "cannot get last of empty LinkedList");
}
// tests elementAt failures (elementAt is used successfully in other tests)
void elementAt_fail_test(){
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList list(test_arr, 9);
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
    // insertAt for out-of-range index
        list.elementAt(98);
    }
    catch (const std::runtime_error &e) {
    // if insertAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    range_error_thrown = true;
    error_message = e.what();
    }
    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (98) not in range [0..9)");
}
void elementAt_fail_test2(){
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList list(test_arr, 9);
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
    // insertAt for out-of-range index
        list.elementAt(9);
    }
    catch (const std::runtime_error &e) {
    // if insertAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    range_error_thrown = true;
    error_message = e.what();
    }
    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (9) not in range [0..9)");
}
void elementAt_fail_test3(){
    CharLinkedList list;
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
    // insertAt for out-of-range index
        list.elementAt(0);
    }
    catch (const std::runtime_error &e) {
    // if insertAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    range_error_thrown = true;
    error_message = e.what();
    }
    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (0) not in range [0..0)");
}
// tests reverse string (regular string already tested in constructor tests)
void reverse_string_test(){
    char test_arr[8] = {'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList list(test_arr, 8);
    assert(list.toReverseString() == "[CharLinkedList of size 8 <<hgfedzcb>>]");
}
// tests pushAtBack and pushAtFront
void push_test(){
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList list(test_arr, 9);
    list.pushAtBack('b');
    list.pushAtBack('b');
    list.pushAtFront('f');
    list.pushAtFront('f');
    assert(list.size() == 13);
    assert(list.toString() == "[CharLinkedList of size 13 <<ffabczdefghbb>>]");
}
void push_b_test_empty(){
    CharLinkedList list;
    list.pushAtBack('b');
    assert(list.size() == 1);
    assert(list.toString() == "[CharLinkedList of size 1 <<b>>]");
}

void push_f_test_empty(){
    CharLinkedList list;
    list.pushAtFront('f');
    assert(list.size() == 1);
    assert(list.toString() == "[CharLinkedList of size 1 <<f>>]");
}

// Tests correct insertion into an empty AL.
// Afterwards, size should be 1 and element at index 0
// should be the element we inserted.
void insertAt_empty_correct() { 
    CharLinkedList test_list;
    test_list.insertAt('a', 0);
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');

}

// Tests incorrect insertion into an empty AL.
// Attempts to call insertAt for index larger than 0.
// This should result in an std::range_error being raised.
void insertAt_empty_incorrect() {

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    // insertAt for out-of-range index
    test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
    // if insertAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    range_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0]");
    
}

// Tests correct insertAt for front of 1-element list.
void insertAt_front_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at front
    test_list.insertAt('b', 0);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'a');
    
}

// Tests correct insertAt for back of 1-element list.
void insertAt_back_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at back
    test_list.insertAt('b', 1);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    
}

// Tests calling insertAt for a large number of elements.
// Not only does this test insertAt, it also checks that
// Linked expansion works correctly.
void insertAt_many_elements() {
    
    CharLinkedList test_list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.insertAt('a', i);
    }

    assert(test_list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
    
}

// Tests insertion into front of a larger list
void insertAt_front_large_list() {
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    test_list.insertAt('y', 0);

    assert(test_list.size() == 10);
    assert(test_list.elementAt(0) == 'y');
    assert(test_list.toString() == 
    "[CharLinkedList of size 10 <<yabczdefgh>>]");

}

// Tests insertion into the back of a larger list
void insertAt_back_large_list() {

    char test_arr[10] = { 'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 10);  

    test_list.insertAt('x', 10);

    assert(test_list.size() == 11);
    assert(test_list.elementAt(10) == 'x');
    assert(test_list.toString() == 
    "[CharLinkedList of size 11 <<yabczdefghx>>]"); 

}

// Tests insertion into the middle of a larger list
void insertAt_middle_large_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.insertAt('z', 3);

    assert(test_list.size() == 9);
    assert(test_list.elementAt(3) == 'z');
    assert(test_list.toString() == 
    "[CharLinkedList of size 9 <<abczdefgh>>]");

}

// Tests out-of-range insertion for a non-empty list.
void insertAt_nonempty_incorrect() {
   
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8]");
    
}
// test insertInOrder
void insertInOrder_test(){
    char test_arr[7] = { 'a', 'h', 'k', 'o', 'r', 'u', 'z' };
    CharLinkedList test_list(test_arr, 7);
    test_list.insertInOrder('c');
    assert(test_list.toString() == "[CharLinkedList of size 8 <<achkoruz>>]");
}
void insertInOrder_test2(){
    char test_arr[7] = { 'a', 'h', 'k', 'o', 'r', 'u', 'z' };
    CharLinkedList test_list(test_arr, 7);
    test_list.insertInOrder('z');
    assert(test_list.toString() == "[CharLinkedList of size 8 <<ahkoruzz>>]");
}
void popFromFront_test1(){
    char test_arr[7] = { 'a', 'h', 'k', 'o', 'r', 'u', 'z' };
    CharLinkedList test_list(test_arr, 7);
    test_list.popFromFront();
    test_list.popFromFront();
    test_list.popFromFront();
    test_list.popFromFront();
    test_list.popFromFront();
    test_list.popFromFront();
    test_list.popFromFront();
    assert(test_list.toString() == "[CharLinkedList of size 0 <<>>]");
    assert(test_list.size() == 0);
}
void popFromFront_test2(){
    CharLinkedList test_list;
    // var to track whether range_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.popFromFront();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}
void popFromBack_test1(){
    char test_arr[7] = { 'a', 'h', 'k', 'o', 'r', 'u', 'z' };
    CharLinkedList test_list(test_arr, 7);
    test_list.popFromBack();
    test_list.popFromBack();
    test_list.popFromBack();
    test_list.popFromBack();
    test_list.popFromBack();
    test_list.popFromBack();
    test_list.popFromBack();
    assert(test_list.toString() == "[CharLinkedList of size 0 <<>>]");
    assert(test_list.size() == 0);
}
void popFromBack_test2(){
    CharLinkedList test_list;
    // var to track whether range_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.popFromBack();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}
// test removeAt (partially tested in popFront and popBack methods)
void removeAt_test(){
    char test_arr[7] = { 'a', 'h', 'k', 'o', 'r', 'u', 'z' };
    CharLinkedList test_list(test_arr, 7);
    test_list.removeAt(3);
    assert(test_list.toString() == "[CharLinkedList of size 6 <<ahkruz>>]");
}
void removeAt_failtest1(){
    CharLinkedList test_list;
    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.removeAt(0);
    }
    catch (const std::runtime_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (0) not in range [0..0)");
    
}
void removeAt_failtest2(){
    char test_arr[7] = { 'a', 'h', 'k', 'o', 'r', 'u', 'z' };
    CharLinkedList test_list(test_arr, 7);
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.removeAt(92);
    }
    catch (const std::runtime_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (92) not in range [0..7)");
    
}
// replaceAt tests
void replaceAt_test(){
    char test_arr[7] = { 'a', 'h', 'k', 'o', 'r', 'u', 'z' };
    CharLinkedList test_list(test_arr, 7);
    test_list.replaceAt('m', 3);
    assert(test_list.toString() == "[CharLinkedList of size 7 <<ahkmruz>>]");
}
void replaceAt_failtest1(){
    CharLinkedList test_list;
    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.replaceAt('m', 3);
    }
    catch (const std::runtime_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (3) not in range [0..0)");
    
}
void replaceAt_failtest2(){
    char test_arr[7] = { 'a', 'h', 'k', 'o', 'r', 'u', 'z' };
    CharLinkedList test_list(test_arr, 7);
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.replaceAt('m', 7);
    }
    catch (const std::runtime_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (7) not in range [0..7)");
    
}
//concatenate test
void concatenate_test(){
    char arr1[5] = { 'h', 'e', 'l', 'l', 'o' };
    char arr2[6] = { 'w', 'o', 'r', 'l', 'd', 's' };
    CharLinkedList list1(arr1, 5);
    CharLinkedList list2(arr2, 6);
    list1.concatenate(&list2);
    assert(list1.toString() == "[CharLinkedList of size 11 <<helloworlds>>]");
    assert(list2.toString() == "[CharLinkedList of size 6 <<worlds>>]");
}
void concatenate_test2(){
    char arr1[5] = { 'h', 'e', 'l', 'l', 'o' };
    CharLinkedList list1(arr1, 5);
    list1.concatenate(&list1);
    assert(list1.toString() == "[CharLinkedList of size 10 <<hellohello>>]");
}

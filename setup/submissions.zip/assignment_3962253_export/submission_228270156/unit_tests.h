/*
 *  unit_tests.h
 *  Eliana Longoria-Valenzuela 
 *  1.31.24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  this file tests the induvidual functions
 *
 */

#include "CharLinkedList.h"
#include <cassert>
#include <string>
#include <stdexcept>

#include <iostream>

using namespace std;

//test default contructor 
void LinkedList_test_constr()
{
    CharLinkedList list;
    assert(list.size() == 0);
}
//test one char constructor 
void LinkedList_test_constr2()
{
    CharLinkedList list('a');
    assert(list.size() == 1);
}

//test arr constructor 
void LinkedList_test_constr3()
{
    char arr[3] = {'c','a','t'};
    CharLinkedList list(arr,3);
    assert(list.size() == 3);
}

//test size function after push and pop 
void LinkedList_test_size_after()
{
    char arr[3] = {'c','a','t'};
    CharLinkedList list(arr,3);
    list.pushAtBack('3');
    list.pushAtFront('d');
    assert(list.size() == 5);
    list.popFromBack();
    list.popFromBack();
    list.popFromBack();
    assert(list.size() == 2);

}
//test first function after pushes and pops 
void LinkedList_test_first_after()
{
    char arr[3] = {'c','a','t'};
    CharLinkedList list(arr,3);
    list.pushAtBack('3');
    list.pushAtFront('d');
    list.pushAtFront('a');
    assert(list.first() == 'a');
    list.popFromBack();
    list.popFromBack();
    list.popFromFront();
    assert(list.first() == 'd');

 }
//test clear function on emtpy list 
void LinkedList_test_clear_empty()
{
    CharLinkedList list;
    list.clear();
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}
//test clear on non-empty array 
void LinkedList_test_clear_nonempty()
{
    char arr[3] = {'c','a','t'};
    CharLinkedList list(arr,3);
    list.clear();
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}
//test clear function on longer non-emtpy list
void LinkedList_test_clear_nonempty2()
{
    char arr[10] = {'c','a','t','4','f','3','&','h','g','f'};
    CharLinkedList list(arr,10);
    list.clear();
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}
//test assignment operator
void LinkedList_test_assignment_operator()
{
    char arr[3] = {'c','a','t'};
    CharLinkedList list(arr,3);
    CharLinkedList copy;
    copy = list;
    assert(copy.toString() == "[CharLinkedList of size 3 <<cat>>]");
}
//test assignment operator pt2
void LinkedList_test_assignment_operator2()
{
    char arr[5] = {'b','i','l','l','z'};
    CharLinkedList list(arr,5);
    CharLinkedList copy;
    copy = list;
    assert(copy.toString() == "[CharLinkedList of size 5 <<billz>>]");
}
//test copy constructor 
void LinkedList_test_copyConstrct()
{
    char arr[5] = {'b','i','l','l','z'};
    CharLinkedList list(arr,5);
    CharLinkedList copy = list;
    std::cerr<<copy.toString()<<std::endl;
    assert(copy.toString() == "[CharLinkedList of size 5 <<billz>>]");
}
//test to String 
void LinkedList_test_ToString()
{
    char arr[3] = {'c','a','t'};
    CharLinkedList list(arr,3);
    assert(list.toString() == "[CharLinkedList of size 3 <<cat>>]");
}

// test reverse string 
void LinkedList_test_toReverseString()
{
    char arr[3] = {'c','a','t'};
    CharLinkedList list(arr,3);
    assert(list.toReverseString() == "[CharLinkedList of size 3 <<tac>>]");
}

// test reverse string 
void LinkedList_test_toReverseString_part2()
{
    char arr[6] = {'d','p','z','c','e','f'};
    CharLinkedList list(arr,6);
    assert(list.toReverseString() == "[CharLinkedList of size 6 <<feczpd>>]");
}

// test reverse empty string 
void LinkedList_test_toReverseString_empty()
{
    CharLinkedList list;
    // std::cerr<<list.toReverseString()<<std::endl;
    assert(list.toReverseString() == "[CharLinkedList of size 0 <<>>]");
}
// test reverse one char string 
void LinkedList_test_toReverseString_one()
{
    CharLinkedList list('c');
    // std::cerr<<list.toReverseString()<<std::endl;
    assert(list.toReverseString() == "[CharLinkedList of size 1 <<c>>]");
}


//test the clear function size 
void LinkedList_test_clear()
{
    char arr[3] = {'c','a','t'};
    CharLinkedList list(arr,3);
    assert(list.size() == 3);
    list.clear();
    assert(list.size() == 0);
}
//test if list is empty 
void LinkedList_test_isEmpty_false()
{
    char arr[3] = {'c','a','t'};
    CharLinkedList list(arr,3);
    assert(not list.isEmpty());
}
//test if emtpy is true
void LinkedList_test_isEmpty_true()
{
    CharLinkedList list;
    assert(list.isEmpty());
}
//test if empty after the clear function is called
void LinkedList_test_isEmpty_after_clear()
{
    char arr[3] = {'c','a','t'};
    CharLinkedList list(arr,3);
    list.clear();
    assert(list.isEmpty());
}
//test first of list
void LinkedList_test_first()
{
    char arr[3] = {'c','a','t'};
    CharLinkedList list(arr,3);
    assert(list.first() == 'c');
}
//test first of emtpy 
void LinkedList_test_first_empty()
{
    bool runtime_error_thrown = false;
    std::string error_message = "";
    try 
    {
        CharLinkedList list;
        assert(list.first() == 'c');
    }
    catch(const runtime_error &list)
    {
        runtime_error_thrown = true;
        error_message = list.what();
    }
}

//test last of empty list
void LinkedList_test_last_empty()
{
    bool runtime_error_thrown = false;
    std::string error_message = "";
    try 
    {
        char arr[3] = {'c','a','t'};
        CharLinkedList list(arr,3);
        assert(list.last() == 't');
    }
    catch(const runtime_error &list)
    {
        runtime_error_thrown = true;
        error_message = list.what();
    }
}

//test pushAtBack on empty list
void LinkedList_pushAtBack_test_empty()
{
    CharLinkedList list;
    list.pushAtBack('c');
    assert(list.first() == 'c');
}
//test pushatback on list
void LinkedList_pushAtBack_3arr()
{
    char arr[3] = {'c','a','t'};
    CharLinkedList list(arr,3);
    list.pushAtBack('s');
    assert(list.toString() == "[CharLinkedList of size 4 <<cats>>]");
}
//test pushatfront on list

void LinkedList_pushAtFront_3arr()
{
    char arr[3] = {'c','a','t'};
    CharLinkedList list(arr,3);
    list.pushAtFront('s');
    assert(list.toString() == "[CharLinkedList of size 4 <<scat>>]");
}
//test pushatfront on list size 

void LinkedList_pushAtFront_empty()
{
    CharLinkedList list;
    list.pushAtFront('c');
    assert(list.first() == 'c');
     assert(list.size() == 1);
 }
//test popfront of list 
void LinkedList_popFront()
{
    char arr[3] = {'c','a','t'};
    CharLinkedList list(arr,3);
    list.popFromFront();
    assert(list.toString() == "[CharLinkedList of size 2 <<at>>]");
}
//testing popFront with only one char
void LinkedList_popFront_one()
{
    char arr[1] = {'c'};
    CharLinkedList list(arr,1);
    list.popFromFront();
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}
//test popfront at empty list
void LinkedList_popFront_emtpy()
{
    bool runtime_error_thrown = false;
    std::string error_message = "";
    try 
    {CharLinkedList list;
    list.popFromFront();
    assert(list.toString() == "[CharLinkedList of size 2 <<at>>]");}
    catch(const runtime_error &list)
    {
        runtime_error_thrown = true;
        error_message = list.what();
    }
}

//test popback at empty 
void LinkedList_popBack_empty()
{
    bool runtime_error_thrown = false;
    std::string error_message = "";
    try 
    {CharLinkedList list;
    list.popFromBack();
    assert(list.toString() == "[CharLinkedList of size 2 <<at>>]");}
    catch(const runtime_error &list)
    {
        runtime_error_thrown = true;
        error_message = list.what();
    }
}
//test popback from list
void LinkedList_popFromBack()
{
    char arr[3] = {'c','a','t'};
    CharLinkedList list(arr,3);
    list.popFromBack();
    assert(list.toString() == "[CharLinkedList of size 2 <<ca>>]");
}

//testing popBack w only one char
void LinkedList_popBack_one()
{
    char arr[1] = {'c'};
    CharLinkedList list(arr,1);
    list.popFromBack();
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}

//test element at in normal list
void LinkedList_elementAt()
{
    char arr[3] = {'c','a','t'};
    CharLinkedList list(arr,3);
    assert(list.elementAt(1) == 'a');
}
//test element in larger list 
void LinkedList_elementAt_more()
{
    char arr[9] = {'c','a','t','s','t','d','f','g','h'};
    CharLinkedList list(arr,9);
    assert(list.elementAt(5) == 'd');
}
//test elementAt on empty list 
void LinkedList_elementAt_empty()
{
    bool range_error_thrown = false;
     std::string error_message = "";
     try 
    {
    CharLinkedList list;
    assert(list.elementAt(0) == 'd');
     }
     catch (const range_error &list)
     {
        range_error_thrown = true;
        error_message = list.what();
     }
}
//test elementAt out of bounds index
void LinkedList_elementAt_out_of_bounds()
{
    bool range_error_thrown = false;
     std::string error_message = "";
     try 
    {
    CharLinkedList list;
    assert(list.elementAt(4) == 'd');
     }
     catch (const range_error &list)
     {
        range_error_thrown = true;
        error_message = list.what();
     }
}
//test elementAt negative index
void LinkedList_elementAt_negative()
{
    bool range_error_thrown = false;
     std::string error_message = "";
     try 
    {
    CharLinkedList list;
    assert(list.elementAt(-1) == 'd');
     }
     catch (const range_error &list)
     {
        range_error_thrown = true;
        error_message = list.what();
     }
}
//test removeAt 
void LinkedList_removeAt()
{
    bool range_error_thrown = false;
    std::string error_message = "";
    try 
    {
        char arr[3] = {'c','a','t'};
        CharLinkedList list(arr,3);
        list.removeAt(1);
        assert(list.toString() == "[CharLinkedList of size 2 <<ct>>]");
    }
    catch(const range_error &list)
    {
        range_error_thrown = true;
        error_message = list.what();
    }
}
//test removeAt on empty list 
void LinkedList_removeAt_empty()
{
    bool range_error_thrown = false;
    std::string error_message = "";
    try 
    {
         CharLinkedList list;
        list.removeAt(1);
        assert(list.toString() == "[CharLinkedList of size 2 <<ct>>]");
    }
    catch (const range_error &list)
    {
        range_error_thrown = true;
        error_message = list.what();
    }
}
//test removeAt on larger list
void LinkedList_removeAt_more()
{
    char arr[9] = {'c','a','t','s','t','d','f','g','h'};
    CharLinkedList list(arr,9);
    list.removeAt(5);
    assert(list.toString() == "[CharLinkedList of size 8 <<catstfgh>>]");
}
//test removeAt in front
void LinkedList_removeAt_front()
{
    char arr[9] = {'c','a','t','s','t','d','f','g','h'};
    CharLinkedList list(arr,9);
    list.removeAt(0);
    assert(list.toString() == "[CharLinkedList of size 8 <<atstdfgh>>]");
}
//test removeAt back element 
void LinkedList_removeAt_back()
{
    char arr[9] = {'c','a','t','s','t','d','f','g','h'};
    CharLinkedList list(arr,9);
    list.removeAt(8);
    assert(list.toString() == "[CharLinkedList of size 8 <<catstdfg>>]");
 }
//test insertAt large list
void LinkedList_InsertAt_()
{
    char arr[9] = {'c','a','t','s','t','d','f','g','h'};
    CharLinkedList list(arr,9);
    list.insertAt('$',6);
    assert(list.toString() == "[CharLinkedList of size 10 <<catstd$fgh>>]");
}
//test insertAt on empty list 
void LinkedList_InsertAt_empty()
{
    CharLinkedList list;
    list.insertAt('$',0);
    assert(list.toString() == "[CharLinkedList of size 1 <<$>>]");
}
//test insertAt on back of list 
void LinkedList_InsertAt_back()
{
    char arr[2] = {'c','a'};
    CharLinkedList list(arr,2);
    list.insertAt('t',2);
    assert(list.toString() == "[CharLinkedList of size 3 <<cat>>]");
}
//test insertAt in the front 
void LinkedList_InsertAt_front()
{
    char arr[2] = {'c','a'};
    CharLinkedList list(arr,2);
    list.insertAt('s',0);
    assert(list.toString() == "[CharLinkedList of size 3 <<sca>>]");
}
//test insertAt negative index
void LinkedList_InsertAt_negative()
{
    bool range_error_thrown = false;
    std::string error_message = "";
    try 
    {
    char arr[2] = {'c','a'};
    CharLinkedList list(arr,2);
    list.insertAt('t',-1);
    assert(list.toString() == "[CharLinkedList of size 3 <<cat>>]");
    }
    catch(const range_error &list)
    {
        range_error_thrown = true; 
        error_message = list.what();
    }
}
//test insertAt out of bounds
void LinkedList_InsertAt_outOfBounds()
{
    bool range_error_thrown = false;
    std::string error_message = "";
    try 
    {
    char arr[2] = {'c','a'};
    CharLinkedList list(arr,2);
    list.insertAt('t',46);
    assert(list.toString() == "[CharLinkedList of size 3 <<cat>>]");
    }
    catch(const range_error &list)
    {
        range_error_thrown = true; 
        error_message = list.what();
    }
}
//test insertinOrder normal 
void LinkedList_InsertinOrder_()
{
    char arr[4] = {'a','b','m','n'};
    CharLinkedList list(arr,4);
    list.insertInOrder('c');
    assert(list.toString() == "[CharLinkedList of size 5 <<abcmn>>]");
}
// //test insertinOrder long list 
// void LinkedList_InsertinOrder_2()
// {
//     char arr[13] = {'A','B','C','D','E','F','G','X','Y','Z','b','d','z'};
//     CharLinkedList list(arr,13);
//     list.insertInOrder('a');
//     assert(list.toString() == "[CharLinkedList of size 14 
//              <<ABCDEFGXYZabdz>>]");
// }

//test insertinOrder duplicates 
void LinkedList_InsertinOrder_3()
{
    char arr[13] = {'A','B','C','D','E','F','G','X','Y','Z','b','d','z'};
    CharLinkedList list(arr,13);
    list.insertInOrder('D');
    assert(list.toString() == "[CharLinkedList of size 14 <<ABCDDEFGXYZbdz>>]");
}

//test insertInOrder on empty list 
void LinkedList_InsertinOrder_empty()
{
    CharLinkedList list;
    list.insertInOrder('c');
    std::cerr<<list.toString()<<std::endl;
    assert(list.toString() == "[CharLinkedList of size 1 <<c>>]");
}
//test insertInOrder on back of list
void LinkedList_InsertinOrder_back()
{
    char arr[2] = {'a','b'};
    CharLinkedList list(arr,2);
    list.insertInOrder('c');
    assert(list.toString() == "[CharLinkedList of size 3 <<abc>>]");
}

//test insertInOrder on front of list 
void LinkedList_InsertinOrder_front()
{
    char arr[2] = {'b','c'};
    CharLinkedList list(arr,2);
    list.insertInOrder('a');
    assert(list.toString() == "[CharLinkedList of size 3 <<abc>>]");
}

//test insertInOrder with mixed chars
void LinkedList_InsertinOrder_front_capital()
{
    char arr[4] = {'$','!','D','a'};
    CharLinkedList list(arr,4);
    list.insertInOrder('A');
    assert(list.toString() == "[CharLinkedList of size 5 <<$!ADa>>]");
}
//test duplicate letters InsertInOrder
void LinkedList_InsertinOrder_duplicates()
{
    char arr[6] = {'a','b','b','b','c','c'};
    CharLinkedList list(arr,6);
    list.insertInOrder('c');
    assert(list.toString() == "[CharLinkedList of size 7 <<abbbccc>>]");
}

//test replace 
void LinkedList_replaceAt_()
{
    char arr[4] = {'a','b','m','d'};
    CharLinkedList list(arr,4);
    list.replaceAt('c',2);
    assert(list.toString() == "[CharLinkedList of size 4 <<abcd>>]");
}

//test replace with same character 
void LinkedList_replaceAt_same()
{
    char arr[4] = {'a','b','m','d'};
    CharLinkedList list(arr,4);
    list.replaceAt('m',2);
    assert(list.toString() == "[CharLinkedList of size 4 <<abmd>>]");
}
//test replace with index at front
void LinkedList_replaceAt_front()
{
    char arr[4] = {'a','b','m','d'};
    CharLinkedList list(arr,4);
    list.replaceAt('c',0);
    assert(list.toString() == "[CharLinkedList of size 4 <<cbmd>>]");
}

//test replace with index in back 
void LinkedList_replaceAt_back()
{
    char arr[4] = {'a','b','m','d'};
    CharLinkedList list(arr,4);
    list.replaceAt('c',3);
    assert(list.toString() == "[CharLinkedList of size 4 <<abmc>>]");
}
//test replaceAt with one char in list
void LinkedList_replaceAt_oneChar()
{
    char arr[1] = {'a'};
    CharLinkedList list(arr,1);
    list.replaceAt('c',0);
    assert(list.toString() == "[CharLinkedList of size 1 <<c>>]");
}
//test replace at emtpy list
void LinkedList_replaceAt_empty()
{
    bool range_error_thrown = false;
    std::string error_message = "";

    try 
    {
        CharLinkedList list;
        list.replaceAt('c',0);
        assert(list.toString() == "[CharLinkedList of size 1 <<c>>]");
    }
    catch(const range_error &list)
    {
        range_error_thrown = true; 
        error_message = list.what();
    }
    
}
void LinkedList_replaceAt_outOfBounds()
{
    bool range_error_thrown = false;
    std::string error_message = "";

    try 
    {
        CharLinkedList list;
        list.replaceAt('c',4);
        assert(list.toString() == "[CharLinkedList of size 1 <<c>>]");
    }
    catch(const range_error &list)
    {
        range_error_thrown = true; 
        error_message = list.what();
    }
    
}
void LinkedList_replaceAt_outOfBounds2()
{
    bool range_error_thrown = false;
    std::string error_message = "";

    try 
    {
        char arr[4] = {'a','b','m','d'};
        CharLinkedList list(arr,4);
        list.replaceAt('c',6);
        assert(list.toString() == "[CharLinkedList of size 1 <<c>>]");
    }
    catch(const range_error &list)
    {
        range_error_thrown = true; 
        error_message = list.what();
    }
    
}
//test concatenation with the same lists 
void LinkedList_concat_()
{
    char arr[4] = {'a','b','m','d'};
    CharLinkedList list(arr,4);
    char other[4] = {'a','b','m','d'};
    CharLinkedList otherL = CharLinkedList(other,4);
    list.concatenate(&otherL);
    assert(list.toString() == "[CharLinkedList of size 8 <<abmdabmd>>]");

}
//test concat. with two emtpy lists
void LinkedList_concat_empties()
{
    CharLinkedList list;
    CharLinkedList otherL;
    list.concatenate(&otherL);
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");

}
//test concat. with two list with varying characters
void LinkedList_concat_characters()
{
    char arr[4] = {'a','!','*','M'};
    CharLinkedList list(arr,4);
    char other[4] = {'3','b','K','?'};
    CharLinkedList otherL = CharLinkedList(other,4);
    list.concatenate(&otherL);
    assert(list.toString() == "[CharLinkedList of size 8 <<a!*M3bK?>>]");
}
//test concat. with different sizes
void LinkedList_concat_diffSizes()
{
    char arr[2] = {'a','!'};
    CharLinkedList list(arr,2);
    char other[7] = {'3','b','K','?','5','r','W'};
    CharLinkedList otherL = CharLinkedList(other,7);
    list.concatenate(&otherL);
    assert(list.toString() == "[CharLinkedList of size 9 <<a!3bK?5rW>>]");
}


//test concat. with one empty
void LinkedList_concat_oneEmpty()
{
    CharLinkedList list;
    char other[7] = {'3','b','K','?','5','r','W'};
    CharLinkedList otherL = CharLinkedList(other,7);
    list.concatenate(&otherL);
    assert(list.toString() == "[CharLinkedList of size 7 <<3bK?5rW>>]");
}
//test concat. with one empty one full added on 
void LinkedList_concate_otherEmpty()
{
    CharLinkedList other;
    char arr[7] = {'3','b','K','?','5','r','W'};
    CharLinkedList list = CharLinkedList(arr,7);
    other.concatenate(&list);
    assert(other.toString() == "[CharLinkedList of size 7 <<3bK?5rW>>]");
}
//test concat. with itself
void LinkedList_concate_itself()
{
    char arr[3] = {'3','b','K'};
    CharLinkedList list(arr,3);
    list.concatenate(&list);
    assert(list.toString() == "[CharLinkedList of size 6 <<3bK3bK>>]");
}
//test concat. empty list with itself
void LinkedList_concate_itself_empty()
{
    CharLinkedList list;
    list.concatenate(&list);
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}
//test concat. empty list with a nullptr
void LinkedList_concate_nullptr()
{
    CharLinkedList list;
    list.concatenate(nullptr);
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}

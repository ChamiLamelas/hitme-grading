/*
 *  CharLinkedList.h
 *  Eliana Longoria-Valenzuela 
 *  1.31.24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  define the class CharLinkedList's public and private variables
 *
 */

#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H
#include <string>

using namespace std;

class CharLinkedList {
    public: 
    CharLinkedList();
    CharLinkedList(char c);
    CharLinkedList(char arr[],int size);
    CharLinkedList(const CharLinkedList &other);
    CharLinkedList &operator=(const CharLinkedList &other);
    ~CharLinkedList();
    int size() const;
    bool isEmpty();
    void clear();
    char first();
    char last();
    std::string toString() const;
    std::string toReverseString() const;
    void pushAtBack(char c);
    void pushAtFront(char c);
    void popFromBack();
    void popFromFront();
    char elementAt(int index) const;
    void removeAt(int index);
    void insertAt(char c, int index);
    void insertInOrder(char c);
    void replaceAt(char c,int index);
    void concatenate(CharLinkedList *other);


    private:
    struct Node
        {
            char c; 
            Node *next;           
            Node *before;

        };
    void destructor_helper(Node *curr);
    CharLinkedList::Node* elementAtHelper(Node *curr,int currIndex,int index) 
                        const;
    void replaceAtHelper(Node *curr,int currIndex,int index,char c);
    void makeNewNode(char c);
    void operatorHelper(Node *curr,Node *otherCurr);
    Node *front;
    int numNodes;
};

#endif

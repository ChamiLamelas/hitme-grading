/*
 *  CharLinkedList.cpp
 *  Eliana Longoria-Valenzuela 
 *  1.31.24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Providing the user a full interface to dynamically interact 
 *      with Linked Lists 
 *
 */

#include "CharLinkedList.h"
#include <sstream>
#include <string>
#include <stdexcept>
#include <iostream>

using namespace std;

//default constructor 
CharLinkedList::CharLinkedList()
{
    front = nullptr;
    numNodes = 0;
}
//single Node constructor 
CharLinkedList::CharLinkedList(char c)
{
    front = new Node;
    front->c = c;
    front->next = nullptr;
    front->before = nullptr;
    numNodes = 1;
}
//array constructor 
CharLinkedList::CharLinkedList(char arr[],int size)
{
    front = nullptr;
    numNodes = 0;
    Node *curr;

    for (int i = 0; i < size;i++)
    {
        if (front == nullptr)
        {
            front = new Node;
            curr = front;
            curr->before = nullptr;
        }
        else 
        {
            curr->next = new Node;
            curr->next->before = curr;
            curr = curr->next;
        }
        curr->c = arr[i];
        curr->next = nullptr;
        numNodes++;
    }
}
//copy constructor 
CharLinkedList::CharLinkedList(const CharLinkedList &other)
{
    front = nullptr;
    numNodes = 0; 
    *this = other;
}
/*
 * name:      operator=
 * purpose:   defines the '=' operator in order  
 * arguments: another CharLinkedList that the user wants to make a 
 *              deep copy of
 * affects:     creates a deep copy of the parameter CharLinkedList 
 *              and recycles the nodes onto a new array
 */
CharLinkedList& CharLinkedList:: operator=(const CharLinkedList &other)
{
    if (this == &other){
        return *this;
    }
    Node *curr = front;
    Node *otherCurr = other.front;
    operatorHelper(curr,otherCurr);
    numNodes = other.numNodes;
    return *this;
}
/*
 * name:      operatorHelper
 * purpose:   goes through the other LinkedList and copies each Node
 * arguments: the front Node for each LinkedList
 * affects:     recycles the nodes of the other LinkedList one-by-one 
 */
void CharLinkedList::operatorHelper(Node *curr,Node *otherCurr)
{
    while(otherCurr != nullptr)
    {
        if (curr == nullptr){
            curr = new Node;
            curr->c = otherCurr->c;
            curr->next = nullptr;
            front = curr;

        }
        if (otherCurr->next != nullptr){
            curr->next = new Node;
            curr->next->before = curr;
            curr->next->c = otherCurr->next->c;
            curr->next->next = nullptr;
        }
        curr = curr->next;
        otherCurr = otherCurr->next;
    }

}
//destructor 
CharLinkedList::~CharLinkedList()
{
    destructor_helper(front);
}
/*
 * name:      destructor_helper 
 * purpose:   a helper function to the operator: deletes the nodes one
 *              by one   
 * arguments: a node representing the current node the function is 
 *              evaluating 
 * affects:     deletes the memory of each node in the LinkedList
 */
void CharLinkedList::destructor_helper(Node *curr)
{
    if (curr != nullptr)
    {
        Node *temp = curr->next;
        delete curr;
        destructor_helper(temp);
    }
}
/*
 * name:      makeNewNode
 * purpose:   helper function when creating a new Node
 * arguments: char c that represents the character in this new Node
 * affects:     creates a brand new node and defines the pointer front to 
 *                  it
 */
void CharLinkedList::makeNewNode(char c)
{
    Node *curr = new Node;
    curr -> c = c;
    curr->before = nullptr;
    curr -> next = nullptr;
    front = curr;
}

/*
 * name:      size
 * purpose:     to get the size of the Linked List
 * returns:     an int representing the size of the LinkedList
 */
int CharLinkedList::size() const
{
    return numNodes;
}
/*
 * name:      toString
 * purpose:   to print out of String containing the size and the 
 *              characters of each Node in order 
 * returns:    a string containing the size and characters of each node
 */
std::string CharLinkedList::toString() const
{
    std::string str = "[CharLinkedList of size ";
    str = str + std::to_string(numNodes) + " <<";

    Node *curr = front;    
    while (curr != nullptr)
    {
        str += (curr->c);
        curr = curr->next;
    }
    str += ">>]";
    return str;
}
/*
 * name:      toString
 * purpose:   prints out a String with size and characters
 * return:      a string with size and the character of each node in    
 *              reverse order
 */
std::string CharLinkedList::toReverseString() const
{
    std::string str = "[CharLinkedList of size ";
    str += std::to_string(numNodes) + " <<";
    Node *curr = front;  
    if (front != nullptr)
    {
        curr = elementAtHelper(front,0,numNodes-1);
        while (curr != nullptr)
        {
            str += (curr->c);
            curr = curr->before;
        }
    }
    str += ">>]";
    return str;

}
/*
 * name:      isEmpty 
 * purpose:   checks to see if there are nodes in the LinkedList
 * returns:     a bool representing if there are any nodes in the 
 *              LinkedList
 */
bool CharLinkedList::isEmpty()
{
    if (front != nullptr)
    {
        return false;
    }
    else 
    {
        return true;
    }
}
/*
 * name:      clear
 * purpose:   to delete all nodes 
 * affects:    deletes all nodes and data in given LinkedList
 */
void CharLinkedList::clear()
{
    Node *curr = front;
    while (curr != nullptr)
    {
        Node *temp = curr;
        curr = curr->next;
        delete temp;
    }
    front = nullptr;
    numNodes = 0;
}
/*
 * name:      first
 * purpose:     retrieve the first Node character
 * return:     a char belonging to the first node of the LinkedList
 */
char CharLinkedList::first()
{
    if (front != nullptr)
    {
        return front->c;
    }
    else 
    {
        throw std::runtime_error("cannot get first of empty LinkedList");
    }
}
/*
 * name:      last
 * purpose:   retrieve the last Node character
 * returns:     the character of the last Node 
 */
char CharLinkedList::last()
{
    if (front != nullptr)
    {
        Node *curr = front; 
        while (curr->next != nullptr)
        {
            curr = curr->next;
        }
        return curr->c;
    }
    else 
    {
        throw std::runtime_error("cannot get last of empty LinkedList");
    }
}
/*
 * name:      pushAtBack
 * purpose:   adds a new Node to the back of the LinkedList
 * arguments: char c that represents the character in this new Node
 * affects:     creates a new node (with all corresponding pointers to 
 *              previous nodes) with argument char c 
 */
void CharLinkedList::pushAtBack(char c)
{
    if (front == nullptr)
    {
        makeNewNode(c);

    }
    else 
    {
        Node *curr = front; 
        while (curr->next != nullptr)
        {
            curr = curr->next;
        }
        curr->next = new Node;
        curr->next->before = curr;
        curr->next->next = nullptr;
        curr->next->c = c;
    }
    numNodes++;
}

/*
 * name:      pushAtFront
 * purpose:   adds a new Node to the front of the LinkedList
 * arguments: char c that represents the character in this new Node
 * affects:     creates a new node, point front to it, and subsequently 
 *              'move over' other nodes to come after it
 */
void CharLinkedList::pushAtFront(char c)
{
    if (front != nullptr)
    {
        Node *temp = new Node;
        temp -> c = c;
        front->before = temp;
        temp->next = front;
        front = temp;
        numNodes++;
    }
    else
    {
        makeNewNode(c);
        numNodes++;
    }
}
/*
 * name:      popFromBack
 * purpose:   delete the Node at the back of the LinkedList
 * affects:     deletes the node in the back of the list and assignes 
 *              the second to last node's next pointer to nullptr
 */
void CharLinkedList::popFromBack()
{
    if (numNodes != 0){
        if (numNodes == 1){
            delete front;
            front = nullptr;
        }
        else {
            Node *curr = front; 
            curr = elementAtHelper(front, 0, numNodes-1);
            if (curr->before != nullptr)
            {
                curr->before->next = nullptr;

            }
            delete curr;
        }
        numNodes--;
    }
    else {
        throw std::runtime_error("cannot pop from empty LinkedList");
    }
}
/*
 * name:      popFromFront
 * purpose:   delete the front Node
 * affects:    deletes the front node, assigns the front pointer to the 
 *              second Node, and subsequently move over the other Nodes
 */
void CharLinkedList::popFromFront()
{
    if (numNodes != 0)
    {
        Node *temp = front->next;
        delete front;
        front = temp;
        numNodes--;
    }
    else 
    {
        throw std::runtime_error("cannot pop from empty LinkedList");
    }
}
/*
 * name:      elementAt
 * purpose:   find the char of a node at a specified index 
 * arguments: int index representing the index which the user wants to 
 *              identify the char.
 * returns:     a char c representing the char at that specified index
 */
char CharLinkedList::elementAt(int index) const
{
    if (numNodes == 0)
    {
        throw std::range_error("index ("  + std::to_string(index) + 
        ") not in range [0.." + std::to_string(numNodes) + ")");
    }
    int currIndex = 0;
    Node *curr = nullptr;
    if (index < numNodes and index >= 0 and front != nullptr)
        {
            curr = elementAtHelper(front,currIndex,index);
            return curr->c;
        }
    else {
        throw std::range_error("index ("  + std::to_string(index) + 
        ") not in range [0.." + std::to_string(numNodes) + ")");
    }
}
/*
 * name:      elementAtHelper
 * purpose:   helper function to identify a node at a specific element
 * arguments: a node curr representing the current Node, an int currIndex
 *              representing an int that helps the program keep track of 
 *              where in the LinkedList it is, and an int index 
 *                  representing the intended index 
 * returns:     the node in the specified index
 */
CharLinkedList::Node* CharLinkedList::elementAtHelper(Node *curr, 
                    int currIndex,int index) const
{
    if (currIndex == index)
    {
        return curr;
    }
    else 
    {
       return elementAtHelper(curr->next,currIndex+1,index);
    }
}
/*
 * name:      removeAt
 * purpose:   deletes a node at a given index
 * arguments: int index representing an index where the user wants the  
 *              node removed 
 * affects:     deletes specified node and attaches previous and 
 *                  following nodes to eachother 
 *              
 */
void CharLinkedList::removeAt(int index)
{
    if (numNodes == 0){
        throw std::range_error("index ("  + std::to_string(index) + 
        ") not in range [0.." + std::to_string(numNodes) + ")");
    }
    if (index < numNodes and index >= 0 and front != nullptr){
        int currIndex = 0;
        Node *curr = front;
        curr = elementAtHelper(front,currIndex,index);
        if (index == numNodes -1){
                popFromBack();
            } 
        else if (index == 0){
                popFromFront();
            }
        else {
                curr->before->next = curr->next;
                curr->next->before = curr->before;
                delete curr;
                numNodes--;
            }
    }
    else{
        throw std::range_error("index ("  + std::to_string(index) + 
        ") not in range [0.." + std::to_string(numNodes) + ")");
    }
}
/*
 * name:      insertAt
 * purpose:   inserts a node at a specified index
 * arguments: char c that represents the character in this new Node, 
 *              and an int index representing the index where the user
 *              wants to place the new node.
 * affects:     creates a new node and inserts it into the LinkedList 
 *                  --additionally moves other nodes to accomodate  
 */
void CharLinkedList::insertAt(char c,int index){
    if (index <= numNodes and index >= 0){
        int currIndex = 0;
        Node *curr = front;
        if (index == 0){
                pushAtFront(c);
            }
        else if (index == numNodes)//adding to the back
        {
            pushAtBack(c);
        }
        else {   
            curr = elementAtHelper(front,currIndex,index-1);
            Node *temp = new Node;
            temp -> c = c;
            temp->next = curr->next;
            curr->next = temp;
            temp->before = curr;
            curr->next->before = temp;
            numNodes++;
            }
    }
    else {
        throw std::range_error("index ("  + std::to_string(index) + 
        ") not in range [0.." + std::to_string(numNodes) + "]");
    }
}
/*
 * name:      insertInOrder
 * purpose:   inserts a node in the correct ASCII value order
 * arguments: char c that represents the character in this new Node
 * affects:     creates a brand new node and adds it to the index 
 *              where it will be ordered
 */
void CharLinkedList::insertInOrder(char c)
{
    Node *curr = front;
    int currIndex = 0;
    bool done = false;
    if (curr == nullptr or (curr->c > c)){
        pushAtFront(c);//smaller than the first
        done = true;
    }
    else {
        while (curr->next != nullptr and not done){
            if ((curr->c <= c) and (curr->next->c >= c)){
                    insertAt(c,currIndex+1);
                    done = true;
                }
            else {
                    curr = curr->next;
                    currIndex++;
                }
        }
    }
    if (not done and curr->c < c){
        pushAtBack(c);// if its larger than the last
    }
}

/*
 * name:      replaceAt
 * purpose:   replaces one Node with another 
 * arguments: char c that represents the character in this new Node and 
 *              int index that represents the index the user wants to 
 *              swap 
 * affects:     replaces the old Node's data with this new nodes 
 */
void CharLinkedList::replaceAt(char c,int index)
{
    int currIndex = 0;
    Node *found = nullptr;
    char a = '\0';
    if (index < numNodes and index >= 0 and front != nullptr)
    {
        found = elementAtHelper(front,currIndex,index);
        found->c = c;
    }
    else {
        if (numNodes == 0){
            numNodes = 1;
        }
        throw std::range_error("index ("  + std::to_string(index) + 
        ") not in range [0.." + std::to_string(numNodes) + ")");
    }   
    
}
/*
 * name:      concatenate 
 * purpose:   combines two CharLinkedLists into one 
 * arguments: a CharLinkedList that the user wants combined with the 
 *              current LinkedList
 * affects:     adds each Node of the other LinkedList to the current 
 *              LinkedList 
 */
void CharLinkedList::concatenate(CharLinkedList *add)
{
    if (add != nullptr)
    {
        int otherSize = add->size();

        for (int i = 0; i < otherSize;i++)
        {
            pushAtBack(add->elementAt(i));
        }
    }
}

/*
 * unit_tests.h
 *
 * CS 15 homework 2
 * by Tyler Calabrese, January 2021
 *
 * edited by: Milod Kazerounian, January 2022
 * edited by: Anna Flores (aflore07), February 2024
 *
 * Uses Matt Russell's unit_test framework to test the CharLinkedList class.
 *
 * Instructions for using testing framework can be found at in CS 15's lab
 * 1 -- both in the spec and in the provided ArrayList_tests.h and Makefile.
 * More in-depth information for those who are curious as to how it works can
 * be found at http://www.github.com/mattrussell2/unit_test.
 */
#include <cassert>
#include <iostream>
using namespace std;

#include "CharLinkedList.h"

/* To give an example of thorough testing, we are providing
 * the unit tests below which test the insertAt function. Notice: we have
 * tried to consider all of the different cases insertAt may be
 * called in, and we test insertAt in conjunction with other functions!
 *
 * You should emulate this approach for all functions you define.
 */



/* Constructors */


/* basic constructor */
void constructor_test_0(){
    CharLinkedList list;
}

/* constructor with char */
void constructor_test_1(){
    CharLinkedList list('a');
}

/* constructor with array of chars */
void constructor_test_2(){
    char arr[4] = {'a', 'b', 'c', 'd'};
    CharLinkedList list(arr, 4);
}

/* constructor for a copy of another CharLinkedList */
void constructor_test_copy(){
    char arr[4] = {'a', 'b', 'c', 'd'};
    CharLinkedList A(arr, 4);
    CharLinkedList B(A);
    assert(B.toString() == "[CharLinkedList of size 4 <<abcd>>]");
}



/* isEmpty */



/* Basic test for isEmpty. */
void isEmpty_test(){
    CharLinkedList list;
    assert(list.isEmpty());
}



/* clear */



/* Basic test for clear. */
void clear_test(){
    char arr[4] = {'a', 'b', 'c', 'd'};
    CharLinkedList list(arr, 4);
    list.clear();
    assert(list.isEmpty());
}



/* size */



/* Basic test for size. */
void size_test(){
    char arr[4] = {'a', 'b', 'c', 'd'};
    CharLinkedList list(arr, 4);
    assert(list.size() == 4);
}

void size_empty_test(){
    CharLinkedList list;
    assert(list.size() == 0);
}



/* first */



/* Basic test for first. */
void first_test(){
    char arr[4] = {'a', 'b', 'c', 'd'};
    CharLinkedList list(arr, 4);
    assert(list.first() == 'a');
}

/* Tests runtime_error handling in first.  */
void first_fail_test(){
    CharLinkedList test_list;

    // var to track whether runtime_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.first();
    } catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot get first of empty LinkedList");
}



/* last */



/* Basic test for last. */
void last_test(){
    char arr[4] = {'a', 'b', 'c', 'd'};
    CharLinkedList list(arr, 4);
    assert(list.last() == 'd');
}

/* Tests runtime_error handling in last. */
void last_fail_test(){
    CharLinkedList test_list;

    // var to track whether runtime_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.last();
    } catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot get last of empty LinkedList");
}



/* elementAt */



/* Basic test for elementAt. */
void elementAt_test(){
    char arr[4] = {'a', 'b', 'c', 'd'};
    CharLinkedList list(arr, 4);
    assert(list.elementAt(3) == 'd');
}

/* Tests range_error handling in elementAt. */
void elementAt_fail_test(){
    char arr[4] = {'a', 'b', 'c', 'd'};
    CharLinkedList test_list(arr, 4);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.elementAt(4);
    } catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (4) not in range [0..4)");
}

void elementAt_empty_test(){
    CharLinkedList test_list;

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.elementAt(0);
    } catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (0) not in range [0..0)");
}




/* toString */



/* Basic test for toString. */
void toString_test(){
    char arr[4] = {'a', 'b', 'c', 'd'};
    CharLinkedList list(arr, 4);
    assert(list.toString() == "[CharLinkedList of size 4 <<abcd>>]");
}

/* Tests output with an array of size 0 with 0 items. */
void toString_test_empty(){
    CharLinkedList list;
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}



/* toReverseString */



/* Basic test for toReverseString. */
void toReverseString_test(){
    char arr[4] = {'a', 'b', 'c', 'd'};
    CharLinkedList list(arr, 4);
    assert(list.toReverseString() == "[CharLinkedList of size 4 <<dcba>>]");
}



/* pushAtBack */



/* Basic test for pushAtBack. */
void pushAtBack_test(){
    char arr[4] = {'a', 'b', 'c', 'd'};
    CharLinkedList list(arr, 4);
    list.pushAtBack('e');
    assert(list.toString() == "[CharLinkedList of size 5 <<abcde>>]");
}

void pushAtBack_empty(){
    CharLinkedList list;
    list.pushAtBack('a');
    assert(list.toString() == "[CharLinkedList of size 1 <<a>>]");
}

void pushAtBack_one(){
    CharLinkedList list('a');
    list.pushAtFront('a');
    assert(list.toString() == "[CharLinkedList of size 2 <<aa>>]");
}

void pushAtBack_many_elements() {
    CharLinkedList test_list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.pushAtBack('a');
    }

    assert(test_list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
}



/* pushAtFront */



/* Basic test for pushAtFront. */
void pushAtFront_test(){
    char arr[4] = {'a', 'b', 'c', 'd'};
    CharLinkedList list(arr, 4);
    list.pushAtFront('z');
    assert(list.toString() == "[CharLinkedList of size 5 <<zabcd>>]");
}

void pushAtFront_empty(){
    CharLinkedList list;
    list.pushAtFront('a');
    assert(list.toString() == "[CharLinkedList of size 1 <<a>>]");
}

void pushAtFront_one(){
    CharLinkedList list('a');
    list.pushAtFront('a');
    assert(list.toString() == "[CharLinkedList of size 2 <<aa>>]");
}

void pushAtFront_many_elements() {
    CharLinkedList test_list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        test_list.pushAtFront('a');
    }

    assert(test_list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
}



/* insertAt */



/* Basic test for insertAt. */
void insertAt_test(){
    char arr[4] = {'a', 'b', 'c', 'd'};
    CharLinkedList list(arr, 4);
    list.insertAt('z', 2);
    assert(list.toString() == "[CharLinkedList of size 5 <<abzcd>>]");
}

// Tests correct insertion into an empty AL.
// Afterwards, size should be 1 and element at index 0
// should be the element we inserted.
void insertAt_empty_correct() {
    CharLinkedList test_list;
    test_list.insertAt('a', 0);
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');
}

// Tests incorrect insertion into an empty AL.
// Attempts to call insertAt for index larger than 0.
// This should result in an std::range_error being raised.
void insertAt_empty_incorrect() {
    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
        // insertAt for out-of-range index
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        // if insertAt is correctly implemented, a range_error will be thrown,
        // and we will end up here
        range_error_thrown = true;
        error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0]");
}

// Tests correct insertAt for front of 1-element list.
void insertAt_front_singleton_list() {
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at front
    test_list.insertAt('b', 0);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'a');
}

// Tests correct insertAt for back of 1-element list.
void insertAt_back_singleton_list() {
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at back
    test_list.insertAt('b', 1);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
}

// Tests calling insertAt for a large number of elements.
// Not only does this test insertAt, it also checks that
// array expansion works correctly.
void insertAt_many_elements() {
    CharLinkedList test_list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.insertAt('a', i);
    }

    assert(test_list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
}

// Tests insertion into front of a larger list
void insertAt_front_large_list() {
    char test_arr[9] = {'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(test_arr, 9);

    test_list.insertAt('y', 0);

    assert(test_list.size() == 10);
    assert(test_list.elementAt(0) == 'y');
    assert(test_list.toString() == "[CharLinkedList of \
// size 10 <<yabczdefgh>>]");
}

// Tests insertion into the back of a larger list
void insertAt_back_large_list() {
    char test_arr[10] = {'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(test_arr, 10);

    test_list.insertAt('x', 10);

    assert(test_list.size() == 11);
    assert(test_list.elementAt(10) == 'x');
    assert(test_list.toString() ==
           "[CharLinkedList of size 11 <<yabczdefghx>>]");
}

// Tests insertion into the middle of a larger list
void insertAt_middle_large_list() {
    char test_arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(test_arr, 8);

    test_list.insertAt('z', 3);
    
    assert(test_list.size() == 9);
    assert(test_list.elementAt(3) == 'z');
    assert(test_list.toString() == "[CharLinkedList of size 9 <<abczdefgh>>]");
}

// Tests out-of-range insertion for a non-empty list.
void insertAt_nonempty_incorrect() {
    char test_arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.insertAt('a', 42);
    } catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8]");
}



/* insertInOrder */



void insertInOrder_test_0(){
    char arr[4] = {'a', 'b', 'd', 'e'};
    CharLinkedList list(arr, 4);
    list.insertInOrder('c');
    assert(list.toString() == "[CharLinkedList of size 5 <<abcde>>]");
}

void insertInOrder_test_1(){
    char arr[4] = {'a', 'b', 'c', 'd'};
    CharLinkedList list(arr, 4);
    list.insertInOrder('e');
    assert(list.toString() == "[CharLinkedList of size 5 <<abcde>>]");
}

/* empty list */
void insertInOrder_test_2(){
    CharLinkedList list;
    list.insertInOrder('a');
    assert(list.toString() == "[CharLinkedList of size 1 <<a>>]");
}



/* popFromFront */



void popFromFront_test(){
    char arr[4] = {'a', 'b', 'c', 'd'};
    CharLinkedList list(arr, 4);
    list.popFromFront();
    assert(list.toString() == "[CharLinkedList of size 3 <<bcd>>]");
}

void popFromFront_empty_test(){
    CharLinkedList test_list;
    
    // var to track whether range_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.popFromFront();
    } catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

void popFromFront_one_test(){
    CharLinkedList list('a');
    list.popFromFront();
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}

void popFromFront_many_elements() {
    CharLinkedList test_list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.insertAt('a', i);
    }

    for (int i = 0; i < 1000; i++){
        test_list.popFromFront();
    }

    assert(test_list.isEmpty());
}



/* popFromBack */



void popFromBack_test(){
    char arr[4] = {'a', 'b', 'c', 'd'};
    CharLinkedList list(arr, 4);
    list.popFromBack();
    assert(list.toString() == "[CharLinkedList of size 3 <<abc>>]");
}

void popFromBack_empty_test(){
    CharLinkedList test_list;
    
    // var to track whether range_error is thrown
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.popFromBack();
    } catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

void popFromBack_one_test(){
    CharLinkedList list('a');
    list.popFromBack();
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}

void popFromBack_many_elements() {
    CharLinkedList test_list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.insertAt('a', i);
    }

    for (int i = 0; i < 1000; i++){
        test_list.popFromBack();
    }

    assert(test_list.isEmpty());
}



/* removeAt */



/* Basic test for removeAt. */
void removeAt_test(){
    char arr[4] = {'a', 'b', 'c', 'd'};
    CharLinkedList list(arr, 4);
    list.removeAt(1);
    assert(list.toString() == "[CharLinkedList of size 3 <<acd>>]");
}

/* removeAt on index 0 */
void removeAt_first_test(){
    char arr[4] = {'a', 'b', 'c', 'd'};
    CharLinkedList list(arr, 4);
    list.removeAt(0);
    assert(list.toString() == "[CharLinkedList of size 3 <<bcd>>]");
}

/* removeAt with an empty list */
void removeAt_empty_list_test(){
    CharLinkedList test_list;
    
    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.removeAt(0);
    } catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (0) not in range [0..0)");

}

/* removeAt with only one element */
void removeAt_one_element_test(){
    CharLinkedList list('a');
    list.removeAt(0);
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}



/* replaceAt */



/* basic replaceAt test */
void replaceAt_test(){
    char arr[4] = {'a', 'b', 'c', 'd'};
    CharLinkedList list(arr, 4);
    list.replaceAt('a', 1);
    assert(list.toString() == "[CharLinkedList of size 4 <<aacd>>]");
}

/* replaceAt with an empty list; error should be thrown */
void replaceAt_empty_test(){
    CharLinkedList test_list;

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.replaceAt('a', 0);
    } catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (0) not in range [0..0)");
}

/* replaceAt with an index that is too large */
void replaceAt_error_test(){
    char test_arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.replaceAt('a', 8);
    } catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (8) not in range [0..8)");
}



/* concatenate */



/* basic concatenate test */
void concatenate_test(){
    char a[5] = {'h', 'e', 'l', 'l', 'o'};
    char b[5] = {'W', 'O', 'R', 'L', 'D'};
    
    CharLinkedList A(a, 5);
    CharLinkedList B(b, 5);

    A.concatenate(&B);

    assert(A.toString() == "[CharLinkedList of size 10 <<helloWORLD>>]");
}

/* concatenates an empty array */
void concatenate_empty_array(){
    char b[4] = {'t', 'e', 's', 't'};
    
    CharLinkedList A;
    CharLinkedList B(b, 4);

    A.concatenate(&B);

    assert(A.toString() == "[CharLinkedList of size 4 <<test>>]");
}

/* concatenates the list itself */
void concatenate_same_array(){
    CharLinkedList A('a');

    A.concatenate(&A);

    assert(A.toString() == "[CharLinkedList of size 2 <<aa>>]");
}


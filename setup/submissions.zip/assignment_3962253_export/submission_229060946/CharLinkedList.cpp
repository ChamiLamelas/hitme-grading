/*
 *  CharLinkedList.cpp
 *  Anna Flores (aflore07)
 *  02/07/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  This is the implementation of the CharArrayList class. It defines all of
 *  the functions used in the class.
 *  These functions perfor m a variety of tasks, including appending chars to
 *  a list, removing chars from a list, and returning queried values. 
 *
 */

#include "CharLinkedList.h"
#include <string>
#include <iostream>

/*
 * name:      CharLinkedList, default constructor
 * purpose:   creates a new blank CharLinkedList
 * arguments: none
 * returns:   none
 * effects:   creates new CharLinkedList
 */
CharLinkedList::CharLinkedList(){
    front = nullptr;
    back = nullptr;
    numItems = 0;
}

/*
 * name:      CharLinkedList, single character constructor
 * purpose:   creates a new CharLinkedList from given char
 * arguments: char to be put in list
 * returns:   none
 * effects:   creates new CharLinkedList, more memory allocated
 */
CharLinkedList::CharLinkedList(char c){
    front = nullptr;
    back = nullptr;

    front = newNode(c, nullptr, nullptr);
    back = front;
    numItems = 1;
}

/*
 * name:      CharLinkedList, array and size constructor
 * purpose:   creates a new CharLinkedList from existing array and array size
 * arguments: array of chars, size of array of chars
 * returns:   none
 * effects:   Creates a new CharLinkedList, more memory allocated
 */
CharLinkedList::CharLinkedList(char arr[], int size){
    front = nullptr;
    back = nullptr;
    numItems = size;
        
    front = newNode(arr[0], nullptr, nullptr);
    Node *curr = front;
    for (int i = 1; i < size; i++){
        Node *tmp_node = newNode(arr[i], nullptr, curr);
        curr->next = tmp_node;
        curr = curr->next;
    }
    back = curr;
}

/*
 * name:      CharLinkedList, copy constructor
 * purpose:   creates a new CharLinkedList copied from existing CharLinkedList
 * arguments: CharLinkedList to be copied
 * returns:   none
 * effects:   creates a new CharLinkedList, more memory allocated
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other){
    numItems = other.numItems;
    front = other.front;
}

/*
 * name:      ~CharLinkedList
 * purpose:   destructor for  the class
 * arguments: none
 * returns:   none
 * effects:   frees memory
 */
CharLinkedList::~CharLinkedList(){
    recycleRecursive(front);
}

/*
 * name:      operator
 * purpose:   defines a 
 * arguments: CharLinkedList to be copied
 * returns:   copied CharLinkedList
 * effects:   allows for  deep copy
 */
CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other){
    if (this == &other){
        return *this;
    }

    numItems = other.numItems;
    *front = *other.front;
    *back = *other.back;
    return *this;
}

/*
 * name:      isEmpty
 * purpose:   determines whether or not list is empty
 * arguments: none
 * returns:   boolean true if  empty false if  full
 * effects:   none
 */
bool CharLinkedList::isEmpty() const{
    if(numItems == 0){
        return true;
    } else {
        return false;
    }
}

/*
 * name:      clear
 * purpose:   removes all elements from the list
 * arguments: none
 * returns:   none
 * effects:   list becomes empty
 */
void CharLinkedList::clear(){
    int total = numItems;
    for (int i = 0; i < total; i++){
        popFromBack();
    }
    numItems = 0;
}

/*
 * name:      size
 * purpose:   returns the number of items in the list
 * arguments: none
 * returns:   numItems
 * effects:   none
 */
int CharLinkedList::size() const{
    return numItems;
}

/*
 * name:      first
 * purpose:   returns the character at the beginning of the list
 * arguments: none
 * returns:   char at data[0] (beginning of list)
 * effects:   none
 */
char CharLinkedList::first() const{
    if (numItems == 0){
         throw std::runtime_error("cannot get first of empty LinkedList");
    } else {
        return front->data;
    }
}

/*
 * name:      last
 * purpose:   returns the character at the end of the list
 * arguments: none
 * returns:   char at data[numItems - 1] (end of list)
 * effects:   none
 */
char CharLinkedList::last() const{
    if (numItems == 0){
        throw std::runtime_error("cannot get last of empty LinkedList");
    } else {
        return back->data;
    }
}

/*
 * name:      elementAt
 * purpose:   returns the character at a specified index
 * arguments: int index of the char
 * returns:   char at data[index]
 * effects:   none
 */
char CharLinkedList::elementAt(int index) const{
    if (numItems <= index or index < 0){
        throw std::range_error("index ("
                               + std::to_string(index)
                               + ") not in range [0.."
                               + std::to_string(numItems) + ")");
    }
    Node *target = getNode(front, 0, index);
    return target->data;
}

/*
 * name:      toString
 * purpose:   prints out a string containing all of the characters
 * arguments: none
 * returns:   [CharLinkedList of size x <<y>>]
 * effects:   none
 */
std::string CharLinkedList::toString() const{
    std::string total;
    Node *curr = front;
    for (int i = 0; i < numItems; i++){
        if (curr == nullptr){
            return total;
        }
        total = total + curr->data;
        curr = curr->next;
    }
    std::string out = "[CharLinkedList of size " + std::to_string(numItems)
        + " <<" + total + ">>]";
    return out;
}

/*
 * name:      toReverseString
 * purpose:   prints out the reverse of toString()
 * arguments: none
 * returns:   string containing all characters in a string and reversed
 * effects:   none
 */
std::string CharLinkedList::toReverseString() const{
    std::string total;
    Node *curr = back;
    for (int i = 0; i < numItems; i++){
        if (curr == nullptr){
            return total;
        }
        total = total + curr->data;
        curr = curr->prev;
    }
    std::string out = "[CharLinkedList of size " + std::to_string(numItems)
        + " <<" + total + ">>]";
    return out;
}

/*
 * name:      pushAtBack
 * purpose:   inserts a character at the end of a list
 * arguments: char to be inserted
 * returns:   none
 * effects:   list increases by 1
 */
void CharLinkedList::pushAtBack(char c){
    if (numItems == 0){
        back = newNode(c, nullptr, nullptr);
        front = back;
        numItems++;
        return;
    }
    Node *new_node = newNode(c, nullptr, back);
    back->next = new_node;
    back = new_node;
    numItems++;
}

/*
 * name:      pushAtFront
 * purpose:   inserts a character at the front of a list
 * arguments: char to be inserted
 * returns:   none
 * effects:   list increases by 1, all other chars shif t for ward 1
 */
void CharLinkedList::pushAtFront(char c){
    if (numItems == 0){
        front = newNode(c, nullptr, nullptr);
        back = front;
        numItems++;
        return;
    }
    Node *new_node = newNode(c, front, nullptr);
    front->prev = new_node;
    front = new_node;
    numItems++;
}

/*
 * name:      insertAt
 * purpose:   inserts a character at a specif ied point in the list
 * arguments: char to be inserted and index where it will be inserted
 * returns:   none
 * effects:   list increases by 1
 */
void CharLinkedList::insertAt(char c, int index){
    if (numItems < index or index < 0){
        throw std::range_error("index ("
                               + std::to_string(index)
                               + ") not in range [0.."
                               + std::to_string(numItems) + "]");
    }
    if (numItems == 0 and index == 0){
        front = newNode(c, nullptr, nullptr);
        back = front;
        numItems++;
        return;
    }
    Node *curr = front;
    for (int i = 0; i < index - 1; i++){
        curr = curr->next;
    }
    Node *new_node = newNode(c, curr->next, curr);
    curr->next->prev = new_node;
    curr->next = new_node;
    numItems++;
}

/*
 * name:      insertInOrder
 * purpose:   insert the given char in ASCII order
 * arguments: char to be inserted
 * returns:   none
 * effects:   increases list size by 1
 */
void CharLinkedList::insertInOrder(char c){
    Node *curr = front;
    while(curr->data != c){
        curr = curr->next;
    }
    Node *new_node = newNode(c, curr, curr->prev);
    curr->prev->next = new_node;
    curr->prev = new_node;
    curr = new_node;
    delete new_node;
    numItems++;
}

/*
 * name:      popFromFront
 * purpose:   removes the char at the front of a list
 * arguments: none
 * returns:   none
 * effects:   decreases list size by one, all chars shif t back by 1
 */
void CharLinkedList::popFromFront(){
    if (numItems == 0){
        throw std::runtime_error("cannot pop from empty LinkedList");
    } else if (numItems == 1){
        Node *old_front = front;
        back = nullptr;
        front = back;
        numItems = 0;
        delete old_front;
    } else {
        Node *old_front = front;
        front = front->next;
        front->prev = nullptr;
        delete old_front;
        numItems--;
    }
}

/*
 * name:      popFromBack
 * purpose:   removes the char at the end of a list
 * arguments: none
 * returns:   none
 * effects:   decreases list size by 1
 */
void CharLinkedList::popFromBack(){
    if (numItems == 0){
        throw std::runtime_error("cannot pop from empty LinkedList");
    } else if (numItems == 1){
        Node *old_back = back;
        front = nullptr;
        back = front;
        numItems = 0;
        delete old_back;
    } else {
        Node *old_back = back;
        back = back->prev;
        back->next = nullptr;
        delete old_back;
        numItems--;
    }
}

/*
 * name:      removeAt
 * purpose:   removes the char at a specified index
 * arguments: int index of char to be removed
 * returns:   none
 * effects:   decreases list size by 1
 */
void CharLinkedList::removeAt(int index){
    if (index < 0 or numItems <= index){
        throw std::range_error("index ("
                               + std::to_string(index)
                               + ") not in range [0.."
                               + std::to_string(numItems) + ")");
    }

    Node *curr = front;
    for(int i = 0; i < index; i++){
        curr = curr->next;
    }
    curr->prev->next = curr->next;
    delete curr;
    numItems--;
}

/*
 * name:      replaceAt
 * purpose:   replaces the char at a given index with a given char
 * arguments: char the character that will be inserted, int index
 * returns:   none
 * effects:   none
 */
void CharLinkedList::replaceAt(char c, int index){
        if (index < 0 or numItems <= index){
        throw std::range_error("index ("
                               + std::to_string(index)
                               + ") not in range [0.."
                               + std::to_string(numItems) + ")");
    }
    Node *replace = getNode(front, 0, index);
    replace->data = c;
}

/*
 * name:      concatenate
 * purpose:   combines two array lists
 * arguments: CharLinkedList to be combined with
 * returns:   none
 * effects:   none
 */
void CharLinkedList::concatenate(CharLinkedList *other){
}

void CharLinkedList::recycleRecursive(Node *curr){
    if (curr == nullptr){
        return;
    }
    Node *next = curr->next;
    delete curr;
    recycleRecursive(next);
}

CharLinkedList::Node *CharLinkedList::newNode(char c, Node *next, Node *prev){
    Node *new_node = new Node;
    new_node->data = c;
    new_node->next = next;
    new_node->prev = prev;

    return new_node;
}

CharLinkedList::Node *CharLinkedList::getNode(Node *curr, int current,
                                              int index) const{
    if (current == index){
        return curr;
    } else {
        return getNode(curr->next, current + 1, index);
    }
}
    

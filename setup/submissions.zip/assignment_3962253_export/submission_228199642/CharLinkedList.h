/*
 *  CharLinkedList.h
 *  Soph Paris sparis01
 *  Jan 30 - 2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  The purpose of this file is to declare functions necessary for the linked
 *  list to be created and then work correctly based on user's wants. 
 *  CharLinkedList is a class that contains a dynamic linked list of char nodes,
 *  users can add, delete, and replace nodes of the linked list.
 *
 */

#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H
#include <iostream>
#include <sstream>
#include <stdexcept>
#include <string>

class CharLinkedList {
public:
    //constructors
    CharLinkedList();
    CharLinkedList(char c);
    CharLinkedList(char arr[], int size);
    CharLinkedList(const CharLinkedList &other);

    //destructor
    ~CharLinkedList();

    //copy operator
    CharLinkedList &operator=(const CharLinkedList &other);

    //condition operation
    bool isEmpty() const;

    //empty operation
    void clear();

    //access operations
    int size() const;
    char first() const;
    char last() const;
    char elementAt(int index) const;

    //string operations
    std::string toString() const;
    std::string toReverseString() const;

    //insertion operations
    void pushAtBack(char c);
    void pushAtFront(char c);
    void insertAt(char c, int index);
    void insertInOrder(char c);
    void concatenate(CharLinkedList *other);

    //removal operations
    void popFromFront();
    void popFromBack();
    void removeAt(int index);

    //replacement operation
    void replaceAt(char c, int index);

private:

    struct Node {
        char data;
        Node *next;
        Node *prev;
    };

    int numNodes;
    Node *front;
    Node *back;
    Node *find_ind_front(int index, Node *curr, int iteration) const;
    Node *find_ind_back(int index, Node *curr, int iteration) const;
    Node *newNode(char c, Node *next, Node *prev);
    void murderNodes(Node *curr);
    void insert_helper(char c, Node *next);

};

#endif

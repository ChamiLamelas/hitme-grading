/*
 *  CharLinkedList.cpp
 *  Soph Paris sparis01
 *  Jan 30 - 2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  This file implements the methods declared in CharLinkedList.h in order for 
 *  the linked list to be created and then work correctly.  It only can contain 
 *  characters / char elements.
 *
 */
#include "CharLinkedList.h"
#include <iostream>
#include <sstream>
#include <stdexcept>
#include <string>

//constructors

//Name: CharLinkedList
//Purpose: Constructs an empty linked list
//Agruments: none
//Output: none
//Effects: none
CharLinkedList::CharLinkedList() {
    //initalize private variables
    numNodes = 0;
    front = nullptr;
    back = nullptr;
}

//Name: CharLinkedList
//Purpose: Creates an linked list with one element.
//Agruments: A char variable input by the user.
//Output: none
//Effects: none
CharLinkedList::CharLinkedList(char c) {
    //initalize numNodes, create a new node
    numNodes = 0;
    newNode(c, nullptr, nullptr);
}

//Name: newNode
//Purpose: Creates an new node in the linked list.
//Agruments: A char variable input by the user, the address of next node in the
//  array list, and the address of the previous node in the array list
//Output: the address of the new node
//Effects: none
CharLinkedList::Node *CharLinkedList::newNode(char c, Node *next, Node *prev) {
    //allocate memory for a new node, and sets it prev and next elements
    Node *newNode = new Node;
    newNode->next = next;
    newNode->prev = prev;
    newNode->data = c;
    numNodes++;
    //assure that if the prev or next node inputted are a nullptr that the
    //new node is set to the front/back respectively
    if (prev == nullptr) {
        front = newNode;
    } if (next == nullptr) {
        back = newNode;
    }
    return newNode;

}

//Name: CharLinkedList
//Purpose: Creates an linked list from the user's inputted array and size.
//Agruments: The desired array of chars and size from user.
//Output: none.
//Effects: none.
CharLinkedList::CharLinkedList(char arr[], int size){
    //initalize private variables
    numNodes = 0;
    front = nullptr;
    back = nullptr;
    //cycle through array and add a node to the back of the list with each
    //index
    if (size > 0) {
        for (int i = 0; i < size; i++) {
            pushAtBack(arr[i]);
        }
    } 
}

//Name: CharLinkedList
//Purpose: Creates an linked list by copying a pre-existing linked list.
//Agruments: Existing linked list that the user wants to copy.
//Output: none.
//Effects: none
CharLinkedList::CharLinkedList(const CharLinkedList &other) {
    //initalize private variables
    numNodes = 0;
    front = nullptr;
    back = nullptr;
    if (not other.isEmpty()) {
        int size = other.size();
        //cycle through list, add a node to the back of the list with each index
        for (int i = 0; i < size; i++) {
            pushAtBack(other.elementAt(i));
        }
    } 
}

//destructor

//Name: ~CharLinkedList
//Purpose: Clean up the dynamically allocated memory associated with linked list
//Agruments: none
//Output: none
//Effects: none
CharLinkedList::~CharLinkedList() {
    murderNodes(back);
}

//destructor helper

//Name: murderNodes
//Purpose: cycles through linked list and deletes nodes
//Agruments: the "curr" node, which must be the current back node.
//Output: none
//Effects: none
void CharLinkedList::murderNodes(Node *curr){
    //assure not deleting nodes of an empty list
    if (numNodes > 0) {
        //start at back and temporarily store its prev node. delete back,
        //decrement numNodes, recurse.
        Node *temp = curr->prev;
        delete curr;
        numNodes--;
        murderNodes(temp);
    }
}

//copy operator

//Name: &CharLinkedList::operator=
//Purpose: Assures the "=" operator will create a deep-copy of linked lists if  
//user input CharLinkedList 1 = pre_existing_list.
//Agruments: The linked list that the user wants to make a deep copy of.
//Output: Returns the deep copy linked list of the inputted linked list.
//Effects: none
CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other){
    if (not isEmpty()) {
        //clean up list's memory
        murderNodes(back);
        numNodes = 0;
    }
    //cycle through other, given its not empty, add node at back for each index
    if (not other.isEmpty()) {
        int size = other.size();
        for (int i = 0; i < size; i++) {
            pushAtBack(other.elementAt(i));
        }
    } 
    return *this;
}

//condition operation

//Name:isEmpty
//Purpose: Determine if the linked list has elements
//Agruments: none
//Output: True or False
//Effects: none
bool CharLinkedList::isEmpty() const {
    return numNodes == 0;
}

//empty operation

//Name: clear
//Purpose: Removes all of the elements of the linked list.
//Agruments: none
//Output: none
//Effects: none
void CharLinkedList::clear() {
    if (not isEmpty()){
        murderNodes(back);
    }
}

//access operations

//Name: size
//Purpose: Allow users to access the number of nodes/size of the linked list.
//Agruments: none
//Output: The int number of items of the linked list.
//Effects: none
int CharLinkedList::size() const {
    return numNodes;
}

//Name: first
//Purpose: Accesses the first element of the linked list.
//Agruments: none
//Output: The char variable that is first in the linked list.
//Effects: Raises an error if the linked list is empty.
char CharLinkedList::first() const {
    if (isEmpty()) {
        throw std::runtime_error("cannot get first of empty LinkedList");
    } 
    return front->data;
}

//Name: last
//Purpose: Accesses the last element of the linked list.
//Agruments: none
//Output: The char variable that is last in the linked list.
//Effects: Raises an error if the linked list is empty
char CharLinkedList::last() const {
    if (isEmpty()) {
        throw std::runtime_error("cannot get last of empty LinkedList");
    } 
    return back->data;
}

//Name: find_ind_front
//Purpose: Finds the node at user's index by starting at the front of list
//Agruments: user inputted index, the current front node, the count/iteration
//  of the recursion.
//Output: The address of the node at that index.
//Effects: none
CharLinkedList::Node *CharLinkedList::
find_ind_front(int ind, Node *curr, int count) const {
    //base case 1, found desired index
    if (count == ind) {
        return curr;
    } 
    //base case 2, index wasn't found
    if (count > ind or curr == nullptr) {
        return nullptr;
    }
    //increment, move to next node, recurse.
    count++;
    return find_ind_front(ind, curr->next, count);
}

//Name: find_ind_back
//Purpose: Finds the node at user's index by starting at the last of list
//Agruments: user inputted index, the current last node, the count/iteration
//  of the recursion.
//Output: The address of the node at that index.
//Effects: none
CharLinkedList::Node *CharLinkedList::
find_ind_back(int ind, Node *curr, int count) const {
    //base case 1, found desired index
    if (count < ind or curr == nullptr) {
        return nullptr;
    }
    //base case 2, index wasn't found
    if (count == ind) {
        return curr;
    } 
    //decrement, move to prev node, recurse.
    return find_ind_back(ind, curr->prev, count - 1);
}

//Name: elementAt
//Purpose: Finds the char at user's desired index.
//Agruments: A user provided index.
//Output: The char variable at user's index within the linked list.
//Effects: Raises an error if index is out of bounds.
char CharLinkedList::elementAt(int index) const {
    if (isEmpty() or index >= numNodes or index < 0){
        throw std::range_error("index (" + std::to_string(index) + 
        ") not in range [0.." + std::to_string(numNodes) + ")");
    } 
    //simple cases
    if (index == 0) {
        return first();
    }
    if (index == numNodes - 1) {
        return last();
    }

    //search from front or back of list depending on index.
    if (numNodes / 2 >= index) {
        return find_ind_front(index, front, 0)->data;
    } else {
        return find_ind_back(index, back, numNodes - 1)->data;
        
    }
}

//string operations

//Name: toString
//Purpose: Creates a standard string output from the linked list's contents.
//Agruments: none
//Output: The string with standard output, and linked list contents and size
//Effects: none
std::string CharLinkedList::toString() const {
    std::string contents = "";
    std::string size = std::to_string(numNodes);
    //add all elements of the list into the null string, increment index
    for (int i = 0; i < numNodes; i++) {
        contents = contents + elementAt(i);
    }
    //add the necessary text/output into the originally null string
    contents = "[CharLinkedList of size " + size + " <<" + contents;
    contents = contents + ">>]";
    return contents;
}

//Name: toReverseString
//Purpose: Creates standard string output from reverse of linked list's contents
//Agruments: none
//Output: String of standard output, and linked list reversed contents and size
//Effects: none
std::string CharLinkedList::toReverseString() const {
    std::string contents = "";
    std::string size = std::to_string(numNodes);
    //add all elements of the list into the null string, increment index
    for (int i = 0; i < numNodes; i++) {
        contents = elementAt(i) + contents;
    }
    //add the necessary text/output into the originally null string
    contents = "[CharLinkedList of size " + size + " <<" + contents;
    contents = contents + ">>]";
    return contents;
}

//insertion operations

//Name: pushAtBack
//Purpose: creates a new node as the last element of the linked list.
//Agruments: none
//Output: The char variable that will be last in the linked list.
//Effects: none
void CharLinkedList::pushAtBack(char c) {
    //store current back, create new node with a prev of current back.
    Node *temp = back;
    newNode(c,nullptr, back);
    if (numNodes > 1) {
        //set the previous back's next to the new back/ new node's address
        temp->next = back;
    }
}

//Name: pushAtFront
//Purpose: creates a new node as the first element of the linked list.
//Agruments: none
//Output: The char variable that will be first in the linked list.
//Effects: none
void CharLinkedList::pushAtFront(char c) {
    //store current front, create new node with a next of current front.
    Node *temp = front;
    newNode(c,front, nullptr);
    if (numNodes > 1) {
        //set the previous front's prev to the new front/ new node's address
        temp->prev = front;
    }
}

//Name: insertAt
//Purpose: Inserts a char at the desired index of the linked list.
//Agruments: The user's desired char, and the index they want it located at.
//Output: none
//Effects: Raises an error if the index is out of bounds
void CharLinkedList::insertAt(char c, int index) { //fixxxxxx
    if (index < 0 or index > numNodes) {
        throw std::range_error("index (" + std::to_string(index) + 
        ") not in range [0.." + std::to_string(numNodes) + "]");
    } 
    Node *temp_next;
    //simple cases
    if (index == 0) {
        pushAtFront(c);
    } else if (index == numNodes) {
        pushAtBack(c);
    } 
    //search for index from front or back, then make current node at that
    //index the next of the new node.
    else if (numNodes / 2 >= index) {
        temp_next = find_ind_front(index, front, 0);
        insert_helper(c, temp_next);
    } else {
        temp_next = find_ind_back(index, back, numNodes - 1);
        insert_helper(c, temp_next);
    }
}

//Name: insert_helper
//Purpose: Updates the next and prev elements of nodes
//Agruments: The user's desired char, and the current node at desired index
//Effects: none
void CharLinkedList::insert_helper(char c, Node *temp_next) {
    Node *temp_prev, *newN;
    temp_prev = temp_next->prev;
    //make a new node with the next being the current node at that index, and 
    //the prev being the node just after it
    newN = newNode(c, temp_next, temp_prev);
    //update the pre-existing nodes so they point to the new node.
    temp_prev->next = newN;
    temp_next->prev = newN;
}

//Name: insertInOrder
//Purpose: Inserts a char so that it's in alphabetical order in linked list.
//Agruments: The user's desired char.
//Output: none
//Effects: none
void CharLinkedList::insertInOrder(char c) {
    //simple case
    if (isEmpty()) {
        pushAtFront(c);
    } else {
        //store the current number of items so the loop doesn't become infinite
        int size = numNodes;
        //cycle through the data until finding the correct location, insert
        for (int i = 0; i < size; i++) {
            if (c <= elementAt(i)) {
                insertAt(c, i);
                i = size + 1;
            } else if (i == numNodes - 1) {
                //if a location isn't found, insert at the end of linekd list.
                insertAt(c, i + 1);
            }
        }
    }
}

//Name: concatenate
//Purpose: Adds elements of linked list to the back of this linked list
//Agruments: The linked list the user wants to be added to the back.
//Output: none
//Effects: none
void CharLinkedList::concatenate(CharLinkedList *other) {
    if (not other->isEmpty()) {
        //add each node's char to the back of current linked list with
        //pushAtBack 
        for (int i = 0; i < other->size(); i++) {
            pushAtBack(other->elementAt(i));
        }
    }
}

//removal operations

//Name: popFromFront
//Purpose: Removes the first element of the linked list
//Agruments: none
//Output: none
//Effects: Raises an error if the linked list is empty.
void CharLinkedList::popFromFront() {
    if (isEmpty()) {
        throw std::runtime_error("cannot pop from empty LinkedList");
    } 

    //store old front, update its next node to the new front. delete old front.
    Node *old_front = front;
    front = old_front->next;
    delete old_front;
    numNodes--;
    //just to assure no garbage data is stored
    if (not isEmpty()){
        front->prev = nullptr;
    }
}

//Name: popFromBack
//Purpose: Removes the last element of the linked list
//Agruments: none
//Output: none
//Effects: Raises an error if the linked list is empty.
void CharLinkedList::popFromBack() {
    if (isEmpty()) {
        throw std::runtime_error("cannot pop from empty LinkedList");
    } 
    //store old back, update its next node to the new back. delete old back.
    Node *old_back = back;
    back = old_back->prev;
    delete old_back;
    numNodes--;

    //just to assure no garbage data is stored
    if (not isEmpty()){
        back->next = nullptr;
    }
}

//Name: removeAt
//Purpose: Removes the node at the user's desired index.
//Agruments: none
//Output: none
//Effects: Raises an error if the index is out of bounds
void CharLinkedList::removeAt(int index) {
        if (index < 0 or index >= numNodes) {
        throw std::range_error("index (" + std::to_string(index) + 
        ") not in range [0.." + std::to_string(numNodes) + "]");
    } 
    Node *remove;
    //simple cases 
    if (index == 0) {
        popFromFront();
    } else if (index == numNodes - 1) {
        popFromBack();
    } 
    //search for current element, update its prev and next to point to eachother
    //delete node and update numNodes
    else if (numNodes / 2 >= index) {
        remove = find_ind_front(index, front, 0);
        remove->next->prev = remove->prev;
        remove->prev->next = remove->next;
        numNodes--;
        delete remove;
    } else {
        remove = find_ind_back(index, back, numNodes - 1);
        remove->next->prev = remove->prev;
        remove->prev->next = remove->next;
        numNodes--;
        delete remove;
    }
}

//replacement operation

//Name: replaceAt
//Purpose: Replaces the node at the index with user's char
//Agruments: The desired char of the user and the index they want it to go.
//Output: none
//Effects: Raises an error if the index is out of bounds.
void CharLinkedList::replaceAt(char c, int index){
    if (isEmpty() or index >= numNodes or index < 0){
        std::cout << numNodes << " index: " << index << std::endl;
        throw std::range_error("index (" + std::to_string(index) + 
        ") not in range [0.." + std::to_string(numNodes) + ")");
    } 
    Node *replacing;
    //find current node at index, update its char data value.
    if (numNodes / 2 >= index) {
        //recursive helper function
        replacing = find_ind_front(index, front, 0); 
    } else {
        //recursive helper function
        replacing = find_ind_back(index, back, numNodes - 1); 
    }
    replacing->data = c;
}

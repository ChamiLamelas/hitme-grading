/*
 *  unit_tests.h
 *  Soph Paris sparis01
 *  Jan 30 - 2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 * The purpose of this file is to test the CharLinkedList class.
 *
 */
#include "CharLinkedList.h"
#include <cassert>

//Name: constructor_test
//Purpose: Tests if the constructor actually makes an array list.
void constructor_test() {
    CharLinkedList list;
    assert (list.isEmpty());
    assert (list.size() == 0);

}

//empty

//Name: first_naturally_empty
//Purpose: Tests if the first function throws the correct error on an empty list
void first_naturally_empty() {
    bool runtime_error_thrown = false;
    std::string error_message = "";
    CharLinkedList list;

    try {
        list.first();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "cannot get first of empty LinkedList");
}
//Name: first_naturally_one
//Purpose: Tests if the first function works correctly with one element list
void first_naturally_one() {
    CharLinkedList list('a');
    assert(list.first() == 'a');
}
//Name: first_naturally_one_removed
//Purpose: Tests if the first function works correctly with one element list
// that then has an element removed
void first_naturally_one_removed() {
    CharLinkedList list('a');
    assert(list.first() == 'a');
    list.popFromFront();
    bool runtime_error_thrown = false;
    std::string error_message = "";

    try {
        list.first();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "cannot get first of empty LinkedList");
}

//Name: first_unnaturally_two_removed
//Purpose: Tests if the first function works correctly with one element list
// that then has an element added then removed twice. checks for error
void first_unnaturally_two_removed() {
    CharLinkedList list('a');
    assert(list.first() == 'a');
    list.pushAtFront('2');
    assert(list.first() == '2');
    list.popFromFront();
    assert(list.first() == 'a');
    list.popFromFront();
    bool runtime_error_thrown = false;
    std::string error_message = "";

    try {
        list.first();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "cannot get first of empty LinkedList");
}

//Name: first_large_test
//Purpose: Tests if the first function works correctly on large list.
void first_large_test() {
    CharLinkedList list('a');
    for (int i = 0; i < 1000; i++) {
        list.pushAtFront('a');
    }
    assert(list.first() == 'a');
}

//Name: last_naturally_empty
//Purpose: Tests if the last function throws the correct error on an empty list
void last_naturally_empty() {
    bool runtime_error_thrown = false;
    std::string error_message = "";
    CharLinkedList list;

    try {
        list.last();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "cannot get last of empty LinkedList");
}
//Name: last_naturally_one
//Purpose: Tests if last function works correctly with one element list
void last_naturally_one() {
    CharLinkedList list('~');
    assert(list.last() == '~');
}
//Name: last_naturally_one_removed
//Purpose: Tests if the last function works correctly with one element list
// that then has an element removed
void last_naturally_one_removed() {
    CharLinkedList list('a');
    assert(list.last() == 'a');
    list.popFromFront();
    bool runtime_error_thrown = false;
    std::string error_message = "";

    try {
        list.last();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "cannot get last of empty LinkedList");
}
//Name: last_unnaturally_two_removed
//Purpose: Tests if the last function works correctly with one element list
// that then has an element added then removed twice. checks for error
void last_unnaturally_two_removed() {
    CharLinkedList list('a');
    assert(list.last() == 'a');
    list.pushAtFront('2');
    assert(list.last() == 'a');
    list.popFromFront();
    assert(list.last() == 'a');
    list.popFromFront();
    bool runtime_error_thrown = false;
    std::string error_message = "";

    try {
        list.last();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "cannot get last of empty LinkedList");
}
//Name: last_large_test
//Purpose: Tests if the last function works correctly on large list.
void last_large_test() {
    CharLinkedList list('a');
    for (int i = 0; i < 1000; i++) {
        list.pushAtFront('a');
    }
    assert(list.last() == 'a');
}
//Name: elementAt_naturally_empty
//Purpose: Test that elementAt throws an error when empty
void elementAt_naturally_empty() {
    bool range_error_thrown = false;
    std::string error_message = "";
    CharLinkedList list;

    try {
        list.elementAt(0);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (0) not in range [0..0)");
}

//Name: elementAt_naturally_one
//Purpose: Test that elementAt accesses first of one element list.
void elementAt_naturally_one() {
    CharLinkedList list('#');
    assert(list.elementAt(0) == '#');
}

//Name: elementAt_naturally_one_removed
//Purpose: Test that elementAt throws an error when index is out of bounds
//removed and then empty
void elementAt_naturally_one_removed() {
    CharLinkedList list('a');
    assert(list.elementAt(0) == 'a');
    list.popFromFront();
    bool range_error_thrown = false;
    std::string error_message = "";

    try {
        list.elementAt(4000);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (4000) not in range [0..0)");
}

//Name: elementAt_unnaturally_two_removed
//Purpose: Test elementAt with other functions, and that it throws an error
// with smaller out of bounds index
void elementAt_unnaturally_two_removed() {
    CharLinkedList list('a');
    assert(list.elementAt(0) == 'a');
    list.pushAtFront('2');
    assert(list.elementAt(1) == 'a');
    list.popFromFront();
    assert(list.elementAt(0) == 'a');
    list.popFromFront();
    bool range_error_thrown = false;
    std::string error_message = "";

    try {
        list.elementAt(-1);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (-1) not in range [0..0)");
}

//Name: elementAt_unnaturally_access_front_middle_back
//Purpose: Tests elementAt works with alterations to list. Also that it works
// at front, middle, and back.
void elementAt_unnaturally_access_front_middle_back() {
    CharLinkedList list('a');
    assert(list.elementAt(0) == 'a');
    list.pushAtFront('2');
    assert(list.elementAt(1) == 'a');
    list.pushAtFront('#');
    assert(list.elementAt(1) == '2');
    list.pushAtFront('0');
    assert(list.elementAt(2) == '2');
}

//Name: elementAt_large_test
//Purpose: Tests elementAt with a large list
void elementAt_large_test() {
    CharLinkedList list('a');
    for (int i = 0; i < 400; i++) {
        list.pushAtBack('2');
    }
    assert(list.elementAt(0) == 'a');
    assert(list.elementAt(4) == '2');
    assert(list.elementAt(40) == '2');
    assert(list.elementAt(399) == '2');
}

//Name: elementAt_outOfBounds
//Purpose: Tests elementAt with out of bounds indices
void elementAt_outOfBounds() {
    CharLinkedList list('a');
    bool range_error_thrown = false;
    std::string error_message = "";

    try {
        list.elementAt(1);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (1) not in range [0..1)");
}

//Name: constructor2_test
//Purpose: Tests the one node constructor.
void constructor2_test() {
    CharLinkedList list('a');
    assert (not list.isEmpty());
    assert (list.size() == 1);
}

//Name: toString_naturally_empty
//Purpose: Tests toString with an empty list
void toString_naturally_empty() {
    CharLinkedList list;
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}

//Name: toString_naturally_one
//Purpose: Tests toString with an one element list
void toString_naturally_one() {
    CharLinkedList list('#');
    assert(list.toString() == "[CharLinkedList of size 1 <<#>>]");
}

//Name: toString_unnaturally_two_removed
//Purpose: Tests toString with alterations to list
void toString_unnaturally_two_removed() {
    CharLinkedList list('a');
    assert(list.toString() == "[CharLinkedList of size 1 <<a>>]");
    list.pushAtBack('2');
    assert(list.toString() == "[CharLinkedList of size 2 <<a2>>]");
    list.popFromFront();
    assert(list.toString() == "[CharLinkedList of size 1 <<2>>]");
    list.popFromFront();
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}

//Name: largetoString
//Purpose: Tests toString with a large list.
void largetoString() {
    char arr[12] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l'};
    CharLinkedList list(arr, 12);
    assert(list.size() == 12);
    assert(list.toString() == "[CharLinkedList of size 12 <<abcdefghijkl>>]");
}

//Name: pushAtBack_naturally_empty
//Purpose: Tests the function on a one element list.
void pushAtBack_naturally_empty() {
    CharLinkedList list;
    list.pushAtBack('0');
    assert(list.toString() == "[CharLinkedList of size 1 <<0>>]");
}

//Name: pushAtBack__naturally_one
//Purpose: Tests the function on a two element list.
void pushAtBack__naturally_one() {
    CharLinkedList list('#');
    list.pushAtBack('0');
    assert(list.toString() == "[CharLinkedList of size 2 <<#0>>]");
}

//Name: pushAtBack__large
//Purpose:  Tests the function on a large list.
void pushAtBack__large() {
    CharLinkedList list;
    list.pushAtBack('a');
    list.pushAtBack('b');
    list.pushAtBack('c');
    list.pushAtBack('d');
    assert(list.toString() == "[CharLinkedList of size 4 <<abcd>>]");
}

//Name: pushAtFront_naturally_empty
//Purpose: Tests the function on a one element list.
void pushAtFront_naturally_empty() {
    CharLinkedList list;
    list.pushAtFront('0');
    assert(list.toString() == "[CharLinkedList of size 1 <<0>>]");
}

//Name: pushAtFront__naturally_one
//Purpose: Tests the function on a two element list.
void pushAtFront__naturally_one() {
    CharLinkedList list('0');
    list.pushAtFront('#');
    assert(list.toString() == "[CharLinkedList of size 2 <<#0>>]");
}

//Name: popFromFront__naturally_empty
//Purpose: Test the function for its error message
void popFromFront__naturally_empty() {
    bool runtime_error_thrown = false;
    std::string error_message = "";
    CharLinkedList list;

    try {
        list.popFromFront();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

//Name: popFromFront__naturally_one
//Purpose: Test the functions ability with a one element list.
void popFromFront__naturally_one() {
    CharLinkedList list('0');
    list.popFromFront();
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}

//Name: popFromFront__unnaturally_one
//Purpose: Tests the function with a one element and then error check.
void popFromFront__unnaturally_one() {
    CharLinkedList list;
    list.pushAtFront('#');
    list.popFromFront();
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
    bool runtime_error_thrown = false;
    std::string error_message = "";

    try {
        list.popFromFront();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

//Name: popFromFront__unnaturally_two
//Purpose: Checks the fucntion with two element list.
void popFromFront__unnaturally_two() {
    CharLinkedList list('0');
    list.pushAtFront('#');
    list.popFromFront();
    assert(list.toString() == "[CharLinkedList of size 1 <<0>>]");
}

//Name: popFromFront_large_test
//Purpose: Tests funciton with a large list.
void popFromFront_large_test() {
    CharLinkedList list('a');
    for (int i = 0; i < 400; i++) {
        list.pushAtBack('2');
    }
    for (int i = 0; i < 400; i++) {
        list.popFromFront();
    }
    assert(list.size() == 1);
}

//Name: popFromBack__naturally_empty
//Purpose: Tests for error message.
void popFromBack__naturally_empty() {
    bool runtime_error_thrown = false;
    std::string error_message = "";
    CharLinkedList list;

    try {
        list.popFromBack();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

//Name: popFromBack__naturally_one
//Purpose: Test function works as expected with one element list
void popFromBack__naturally_one() {
    CharLinkedList list('0');
    list.popFromBack();
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}

//Name: popFromBack__unnaturally_one
//Purpose: Tests function works with removal and them error output with empty.
void popFromBack__unnaturally_one() {
    CharLinkedList list;
    list.pushAtFront('#');
    list.popFromBack();
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
    bool runtime_error_thrown = false;
    std::string error_message = "";

    try {
        list.popFromBack();
    }
    catch (const std::runtime_error &e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }
    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

//Name: popFromBack__unnaturally_two
//Purpose: Tests function works with two element list
void popFromBack__unnaturally_two() {
    CharLinkedList list('0');
    list.pushAtFront('#');
    list.popFromBack();
    assert(list.toString() == "[CharLinkedList of size 1 <<#>>]");
}

//Name: popFromBack_large_test
//Purpose: Tests function works with large list
void popFromBack_large_test() {
    CharLinkedList list('a');
    for (int i = 0; i < 400; i++) {
        list.pushAtBack('2');
    }
    for (int i = 0; i < 400; i++) {
        list.popFromBack();
    }
    assert(list.size() == 1);
}

//Name: emptyArray_constructor
//Purpose: Tests array constructor works with empty list.
void emptyArray_constructor() {
    char arr[0];
    CharLinkedList list(arr, 0);
    assert(list.size() == 0);
}

//Name: elementArray_constructor
//Purpose: Test array constructor works
void elementArray_constructor() {
    char arr[1] = {'a'};
    CharLinkedList list(arr, 1);
    assert(list.size() == 1);
    assert(list.elementAt(0) == arr[0]);
}

//Name: largeElementArray_constructor
//Purpose: Tests array constructor works with large array
void largeElementArray_constructor() {
    char arr[12] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l'};
    CharLinkedList list(arr, 12);
    assert(list.size() == 12);
    for (int i = 0; i < 12; i++) {
        assert(list.elementAt(i) == arr[i]);
    }
}

//Name: emptyCopy_constructor
//Purpose: Tests copy constructor works with an empty other.
void emptyCopy_constructor() {
    CharLinkedList linked_list;
    CharLinkedList list(linked_list);
    assert(linked_list.size() == 0);
    assert(list.size() == 0);
}

//Name: one_elementCopy_constructor
//Purpose: Tests copy constructor works with an one element other.
void one_elementCopy_constructor() {
    CharLinkedList linked_list('c');
    CharLinkedList list(linked_list);
    assert(linked_list.size() == 1);
    assert(list.size() == 1);
}

//Name: largeCopy_constructor
//Purpose: Tests copy constructor works with a large other.
void largeCopy_constructor() {
    char arr[12] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l'};
    CharLinkedList linked_list(arr, 12);
    CharLinkedList list(linked_list);
    assert(linked_list.size() == 12);
    assert(list.size() == 12);
}

//copy operator

//Name: nonempty_emptyCopy_operator
//Purpose: Tests copy operator works with a non-empty to the left and empty to
// the right side of "="
void nonempty_emptyCopy_operator() {
    char arr[12] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l'};
    CharLinkedList list;
    CharLinkedList linked_list(arr, 12);
    linked_list = list;
    assert(linked_list.size() == 0);
    assert(list.size() == 0);
}

//Name: empty_nonemptyCopy_operator
//Purpose: Tests copy operator works with an empty to the left and non-empty to
// the right side of "="
void empty_nonemptyCopy_operator() {
    char arr[12] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l'};
    CharLinkedList list;
    CharLinkedList linked_list(arr, 12);
    list = linked_list;
    assert(list.size() == 12);
    assert(linked_list.size() == 12);
}

//Name: empty_emptyCopy_operator
//Purpose: Tests copy operator works with an empty to the left and empty to
// the right side of "="
void empty_emptyCopy_operator() {
    CharLinkedList list;
    CharLinkedList linked_list;
    list = linked_list;
    assert(list.size() == 0);
    assert(linked_list.size() == 0);
}

//Name: large_largeCopy_operator
//Purpose: Tests copy operator works with a large list to the left and large to
// the right side of "="
void large_largeCopy_operator() {
    char arra[11] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k'};
    char arr[10] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j'};
    CharLinkedList list(arr, 10);
    CharLinkedList linked_list(arra, 11);
    list = linked_list;
    assert(list.size() == 11);
    assert(linked_list.size() == 11);
}

//clear 

//Name: clearEmpty
//Purpose: Tests that clear works with an empty list.
void clearEmpty() {
    CharLinkedList linked_list;
    linked_list.clear();
    assert(linked_list.size() == 0);
}

//Name: clearOneElement
//Purpose: Tests clear work with one element list.
void clearOneElement() {
    CharLinkedList linked_list('9');
    linked_list.clear();
    assert(linked_list.size() == 0);
}

//Name: clearLarge
//Purpose: Tests clear works with a large list.
void clearLarge() {
    char arra[11] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k'};
    CharLinkedList linked_list(arra, 11);
    linked_list.clear();
    assert(linked_list.size() == 0);
}

//Name: toReverseString_naturally_empty
//Purpose: Tests that toReverseString works with an empty list.
void toReverseString_naturally_empty() {
    CharLinkedList list;
    assert(list.toReverseString() == "[CharLinkedList of size 0 <<>>]");
}

//Name: toReverseString_naturally_one
//Purpose: Tests that toReverseString works with an one element list.
void toReverseString_naturally_one() {
    CharLinkedList list('#');
    assert(list.toReverseString() == "[CharLinkedList of size 1 <<#>>]");
}

//Name: toReverseString_unnaturally_two_removed
//Purpose: Tests that toReverseString works with an altered element list.
void toReverseString_unnaturally_two_removed() {
    CharLinkedList list('a');
    assert(list.toReverseString() == "[CharLinkedList of size 1 <<a>>]");
    list.pushAtBack('2');
    assert(list.toReverseString() == "[CharLinkedList of size 2 <<2a>>]");
    list.popFromFront();
    assert(list.toReverseString() == "[CharLinkedList of size 1 <<2>>]");
    list.popFromFront();
    assert(list.toReverseString() == "[CharLinkedList of size 0 <<>>]");
}

//Name: largetoReverseString
//Purpose: Tests that toReverseString works with a large element list.
void largetoReverseString() {
    char arr[12] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l'};
    CharLinkedList list(arr, 12);
    assert(list.size() == 12);
    std::string contents = "[CharLinkedList of size 12 <<lkjihgfedcba>>]";
    assert(list.toReverseString() == contents);
}

//Name: insertAt_empty
//Purpose: Tests insertAt works with an empty list.
void insertAt_empty() {
    CharLinkedList list;
    list.insertAt('#',0);
    assert(list.size() == 1);
}

//Name: insertAt_nonempty
//Purpose: Tests interAt works with nonempty list, and that it inserts at the
// front, middle, and back without problems
void insertAt_nonempty() {
    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(arr, 5);
    list.insertAt('#',3);
    assert(list.toString() == "[CharLinkedList of size 6 <<abc#de>>]");
    list.insertAt('#',0);
    assert(list.toString() == "[CharLinkedList of size 7 <<#abc#de>>]");
    list.insertAt('#',7);
    assert(list.toString() == "[CharLinkedList of size 8 <<#abc#de#>>]");
}

//Name: insertAt_error
//Purpose: Tests the function for its error.
void insertAt_error() {
    CharLinkedList list;
    bool range_error_thrown = false;
    std::string error_message = "";

    try {
        list.insertAt('2',42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0]");
}

//Name: insertInOrder_empty
//Purpose: Tests insertInOrder works when list is empty
void insertInOrder_empty() {
    CharLinkedList list;
    list.insertInOrder('#');
    assert(list.size() == 1);
}

//Name: insertInOrder_nonempty
//Purpose: Tests insertInOrder works with a nonempty list.
void insertInOrder_nonempty() {
    char arr[5] = {'a', 'd', 'p', 'v', 'z'};
    CharLinkedList list(arr, 5);
    list.insertInOrder('b');
    assert(list.toString() == "[CharLinkedList of size 6 <<abdpvz>>]");
    list.insertInOrder('z');
    assert(list.toString() == "[CharLinkedList of size 7 <<abdpvzz>>]");
    list.insertInOrder('h');
    assert(list.toString() == "[CharLinkedList of size 8 <<abdhpvzz>>]");
    list.insertInOrder('!');
    assert(list.toString() == "[CharLinkedList of size 9 <<!abdhpvzz>>]");
}

//Name: removeAt_empty
//Purpose: Tests removeAt works when list is empty
void removeAt_empty() {
    CharLinkedList list;
    bool range_error_thrown = false;
    std::string error_message = "";

    try {
        list.removeAt(0);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (0) not in range [0..0]");
}

//Name: removeAt_out_of_range
//Purpose: Tests removeAt works when list is empty
void removeAt_out_of_range() {
    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(arr, 5);
    bool range_error_thrown = false;
    std::string error_message = "";

    try {
        list.removeAt(list.size() + 1);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (6) not in range [0..5]");
}

//Name: removeAt_nonempty
//Purpose: Tests removeAt works with a nonempty list, and that it can remove
// at the front, middle, and back.
void removeAt_nonempty() {
    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(arr, 5);
    list.removeAt(3);
    assert(list.toString() == "[CharLinkedList of size 4 <<abce>>]");
    list.removeAt(0);
    assert(list.toString() == "[CharLinkedList of size 3 <<bce>>]");
    list.removeAt(1);
    assert(list.toString() == "[CharLinkedList of size 2 <<be>>]");
}

//replaceAt
//Name: replaceAt_naturally_empty
//Purpose: Tests that replaceAt produce error with empty list.
void replaceAt_naturally_empty() {
    bool range_error_thrown = false;
    std::string error_message = "";
    CharLinkedList list;

    try {
        list.replaceAt('l',0);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (0) not in range [0..0)");
}

//Name: replaceAt_naturally_one_removed
//Purpose: Tests that replaceAt works, and produces error when altered to empty
void replaceAt_naturally_one_removed() {
    CharLinkedList list('a');
    list.replaceAt('3', 0);
    assert(list.elementAt(0) == '3');
    list.popFromFront();
    bool range_error_thrown = false;
    std::string error_message = "";

    try {
        list.replaceAt('m',4000);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (4000) not in range [0..0)");
}

//Name: replaceAt_unnaturally_two_removed
//Purpose: Tests that replaceAt can be used front, middle, back and that
// when altered to empty list produces error
void replaceAt_unnaturally_two_removed() {
    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(arr, 5);
    list.replaceAt('2', 0);
    assert(list.toString() == "[CharLinkedList of size 5 <<2bcde>>]");
    list.replaceAt('3', 4);
    assert(list.toString() == "[CharLinkedList of size 5 <<2bcd3>>]");
    list.replaceAt('q', 2);
    assert(list.toString() == "[CharLinkedList of size 5 <<2bqd3>>]");
    list.clear();
    bool range_error_thrown = false;
    std::string error_message = "";

    try {
        list.replaceAt('p',-1);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (-1) not in range [0..0)");
}

//Name: replaceAt_large_test
//Purpose: Tests that replaceAt works with large lists
void replaceAt_large_test() {
    CharLinkedList list('a');
    for (int i = 0; i < 400; i++) {
        list.pushAtBack('2');
    }
    list.replaceAt('e', 0);
    assert(list.elementAt(0) == 'e');
    list.replaceAt('8', 4);
    assert(list.elementAt(4) == '8');
    assert(list.elementAt(40) == '2');
    list.replaceAt('k', 399);
    assert(list.elementAt(399) == 'k');
}

//Name: replaceAt_outOfBounds
//Purpose: Tests replaceAt with out of bounds index
void replaceAt_outOfBounds() {
    CharLinkedList list('a');
    bool range_error_thrown = false;
    std::string error_message = "";

    try {
        list.replaceAt('a',1);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (1) not in range [0..1)");
}

//Name: replaceAt_outOfBounds_Large
//Purpose: Tests replaceAt with a larger out of bounds index
void replaceAt_outOfBounds_Large() {
    char arr[6] = {'a', 'b', 'c', 'd', 'e', 'f'};
    CharLinkedList list(arr, 6);
    bool range_error_thrown = false;
    std::string error_message = "";

    try {
        list.replaceAt('a',6);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (6) not in range [0..6)");
}

//concatenate

//Name: empty_emptyConcatenate
//Purpose: Tests concatenate works with empty list and empty other.
void empty_emptyConcatenate() {
    CharLinkedList list;
    CharLinkedList linked_list;
    list.concatenate(&linked_list);
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}

//Name: empty_nonemptyConcatenate
//Purpose: Tests concatenate works with empty list and non-empty other.
void empty_nonemptyConcatenate() {
    char arr[12] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l'};
    CharLinkedList list;
    CharLinkedList linked_list(arr, 12);
    list.concatenate(&linked_list);
    std::string contents = "[CharLinkedList of size 12 <<abcdefghijkl>>]";
    assert(list.toString() == contents);
}

//Name: nonempty_emptyConcatenate
//Purpose: Tests concatenate works with non-empty list and empty other.
void nonempty_emptyConcatenate() {
    char arr[12] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l'};
    CharLinkedList list;
    CharLinkedList linked_list(arr, 12);
    linked_list.concatenate(&list);
    std::string contents = "[CharLinkedList of size 12 <<abcdefghijkl>>]";
    assert(linked_list.toString() == contents);
}

//Name: nonempty_nonemptyConcatenate
//Purpose: Tests concatenate works with non-empty list and non-empty other.
void nonempty_nonemptyConcatenate() {
    char arr[12] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l'};
    CharLinkedList list(arr, 12);
    CharLinkedList linked_list(arr, 12);
    linked_list.concatenate(&list);
    std::string c = "[CharLinkedList of size 24 <<abcdefghijklabcdefghijkl>>]";
    assert(linked_list.toString() == c);
}
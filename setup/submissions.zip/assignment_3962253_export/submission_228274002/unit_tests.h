/*
 *  unit_tests.h
 *  Amelie Wickham
 *  02.01.24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  This file contains all of the tests that were 
    written to test the implemented ADT in the CharLinkedList.cpp 
    file. These tests were written to address the primary 
    function of the implemented member functions in 
    different circumstances as well as identify any areas 
    in which the function may have to address an edge case 
    and test its response to that.
 *
 */

#include "CharLinkedList.h"
#include <cassert>

/* constructor test I
 * tests to make sure there are no fatal memory leaks/errors 
 * in constructor
 */
void constructor_testI() {
    CharLinkedList test_list;
}

/*
 * constructor test II
 * tests to make sure there are no fatal memory leaks/errors 
 * in constructor II (char input)
 */
void constructor_testII() {
    char c = 'c';
    CharLinkedList test_list = CharLinkedList(c);
    assert (test_list.first() == 'c');
}

/*
 * constructor test III first last
 * Make sure no fatal errors/memory leaks in the third constructor
 *
 */
void constructor_testIII_FL() {
    int num = 3;
    char arr[] = {'a','b','c'};
    CharLinkedList test_list(arr, num);
    assert(test_list.size() == 3);
    assert(test_list.first() == 'a');
    assert(test_list.last() == 'c');
}

/*
 * constructor test III empty
 * Make sure no fatal errors/memory leaks in the third constructor
 * when empty array is inputted
 */
void constructor_testIII_Empty() {
    int num = 0;
    char arr[] = {};
    CharLinkedList test_list(arr, num);
    assert(test_list.size() == 0);
}


/*
 * copy constructor test I one full one empty
 * Make sure no fatal errors/memory leaks in the copy constructor
 */
void copyConstructor_testI() {
    char arr[] = {'a','b','c'};
    CharLinkedList list1(arr, 3);

    CharLinkedList list2 = list1;

    assert(list2.toString() ==  "[CharLinkedList of size 3 <<abc>>]");

}

/*
 * copy constructor test I empty lists
 * Make sure no fatal errors/memory leaks in the copy constructor
 */
void copyConstructor_testII() {
    CharLinkedList list1;

    CharLinkedList list2 = list1;

    assert(list2.toString() ==  "[CharLinkedList of size 0 <<>>]");
}

/*
 * copy constructor test I empty
 * Make sure no fatal errors/memory leaks in the copy constructor
 */
void copyConstructor_testIII() {
    char arr[] = {'a','b','c'};
    CharLinkedList list1(arr, 3);

    CharLinkedList list2 = list1;

    assert(list2.toString() ==  "[CharLinkedList of size 3 <<abc>>]");

}



// overloadOp test I
// tests two full lists
void overloadOp_testI() {
    char arr[] = {'a','b','c'};
    CharLinkedList list1(arr, 3);

    char array[] = {'x','y','z'};
    CharLinkedList list2(array, 3);
    
    assert(list2.toString() ==  "[CharLinkedList of size 3 <<xyz>>]");

    list2 = list1;
    assert(list2.toString() ==  "[CharLinkedList of size 3 <<abc>>]");
}

// concatenate test III
// tests that 2 empty lists can be copied 
// using this function
void overloadOp_testII() {
    CharLinkedList list1;
    CharLinkedList list2;
    list2 = list1;
    std:: cerr<< "completed assignment" << std::endl;
    assert(list2.toString() ==  "[CharLinkedList of size 0 <<>>]");
        std:: cerr << list2.toString();
}

// overloadOp test III
// tests one full list one empty
void overloadOp_testIII() {
    CharLinkedList list1;

    char array[] = {'x','y','z'};
    CharLinkedList list2(array, 3);

    list2 = list1;
    assert(list2.toString() ==  "[CharLinkedList of size 0 <<>>]");
}

// overloadOp test III
// tests one full list one empty
void overloadOp_testIV() {
    CharLinkedList list1;

    char array[] = {'x','y','z'};
    CharLinkedList list2(array, 3);

    list1 = list2;
    assert(list1.toString() ==  "[CharLinkedList of size 3 <<xyz>>]");
}


/* isEmpty test
 * tests isEmpty function on an empty list
 */
void isEmpty_true(){
    CharLinkedList test_list;
    assert(test_list.isEmpty());
}

/* isEmpty test
 * tests isEmpty function on a non-empty list
 */
void isEmpty_false(){
    int num = 3;
    char arr[] = {'a','b','c'};
    CharLinkedList test_list(arr, num);
    assert(not test_list.isEmpty());
}

/*
 * clear() test
 * tests to make sure clear() function properly clears three 
 * char LL
 */

void clear_reg(){
    int num = 3;
    char arr[] = {'a','b','c'};
    CharLinkedList test_list(arr, num);
    test_list.clear();
    assert(test_list.size() == 0);
}

/*
 * clear() test II
 * tests to make sure clear() function properly clears one 
 * char LL
 */
void clear_one(){
    int num = 1;
    char arr[] = {'a'};
    CharLinkedList test_list(arr, num);
    test_list.clear();
    assert(test_list.size() == 0);
}

/*
 * clear() test III
 * tests to make sure clear() function properly clears one 
 * char LL
 */
void clear_empty(){
    CharLinkedList test_list;
    test_list.clear();
    assert(test_list.size() == 0);
}

/*
 * size() test
 * tests the functionality of the size()
 */
void size_test(){
    int num = 3;
    char arr[] = {'a','b','c'};
    CharLinkedList test_list(arr, num);
    assert(test_list.size() == 3);
}

/*
 * first() test
 * tests the functionality of the first()
 */
void first_test(){
    int num = 3;
    char arr[] = {'a','b','c'};
    CharLinkedList test_list(arr, num);
    assert(test_list.first() == 'a');
}

/*
 * last() test
 * tests the functionality of the last()
 */
void last_test(){
    int num = 3;
    char arr[] = {'a','b','c'};
    CharLinkedList test_list(arr, num);
    assert(test_list.last() == 'c');
}

/*
 * elementAt()test I
 * tests elementAt on an empty list
 */
void elementAt_empty(){
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    // elementAt for any index
    test_list.elementAt(0);
    }
    catch (const std::runtime_error &e) {
    // if elementAtt is correctly implemented, a runtime_error 
    // will be thrown, and we will end up here
    runtime_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(runtime_error_thrown);
    assert(error_message == "cannot get element of"
                                 " empty LinkedList");

}

/*
 * elementAt()test II
 * tests elementAt for an out of range index
 */
void elementAt_OORup(){
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    int num = 3;
    char arr[] = {'a','b','c'};
    CharLinkedList test_list(arr, num);
    try {
    // elementAt for out-of-range index
    test_list.elementAt(42);
    }
    catch (const std::range_error &e) {
    // if elementAt is correctly implemented, a range_error will 
    // be thrown, and we will end up here
    range_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..3)");

}

/*
 * elementAt()test III
 * tests elementAt on an empty list
 */
void elementAt_OORdown(){
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    int num = 3;
    char arr[] = {'a','b','c'};
    CharLinkedList test_list(arr, num);
    try {
    // elementAt for out-of-range index
    test_list.elementAt(-1);
    }
    catch (const std::range_error &e) {
    // if elementAt is correctly implemented, a range_error 
    // will be thrown,
    // and we will end up here
    range_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (-1) not in range [0..3)");

}

/*
 * elementAt()test IV
 * tests elementAt on an empty list
 */
void elementAt_correctSmall(){

    // initialize LL
    int num = 3;
    char arr[] = {'a','b','c'};
    CharLinkedList test_list(arr, num);

    // out here, we make our assertions
    assert(test_list.elementAt(1) == 'b');

}

/*
 * elementAt()test V
 * tests elementAt on an long LL
 */
void elementAt_correctLong(){
    CharLinkedList test_list;
    // initialize long list
    for (int i = 0; i < 1000; i++){
        test_list.pushAtBack('a');
    }

    // out here, we make our assertions
    assert(test_list.elementAt(800) == 'a');
}

/*
 * popFromFront()test I
 * tests function on empty linked list
 */
void popFromFront_empty(){
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    // popFromFront for any index
    test_list.popFromFront();
    }
    catch (const std::runtime_error &e) {
    // if elementAtt is correctly implemented, a runtime_error 
    // will be thrown, and we will end up here
    runtime_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from"
                                 " empty LinkedList");

}

/*
 * popFromFront()test II
 * tests function on short linked list
 */
void popFromFront_short(){
    // initialize LL
    int num = 3;
    char arr[] = {'a','b','c'};
    CharLinkedList test_list(arr, num);

    //call function
    test_list.popFromFront();

    //assertions
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'c');
    assert(test_list.size() == 2);
}

/*
 * popFromFront()test I
 * tests function on empty linked list
 */
void popFromBack_empty(){
    bool runtime_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    // popFromBack for empty list
    test_list.popFromBack();
    }
    catch (const std::runtime_error &e) {
    // if elementAtt is correctly implemented, a runtime_error 
    // will be thrown, and we will end up here
    runtime_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from"
                                 " empty LinkedList");

}

/*
 * popFromFront()test II
 * tests function on short linked list
 */
void popFromBack_short(){
    // initialize LL
    int num = 3;
    char arr[] = {'a','b','c'};
    CharLinkedList test_list(arr, num);

    //call function
    test_list.popFromBack();

    // assertions
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    assert(test_list.size() == 2);
}

/*
 * removeAt test I
 * check to see if function returns correct element at given index
 */
void removeAt_test_I() {
    char arr[] = {'x','y','z'};
    CharLinkedList list(arr, 3);
    list.removeAt(0);
    assert(list.elementAt(0) =='y');
}

/*
 * removeAt test II
 * check to see if function returns correct element at given index
 */
void removeAt_test_II() {
    char arr[] = {'x','y','z'};
    CharLinkedList list(arr, 3);
    list.removeAt(1);
    assert(list.elementAt(1) =='z');
}

/*
 * removeAt test II
 * check to see if function returns correct element at given index
 */
void removeAt_test_III() {
    char arr[] = {'x','y','z'};
    CharLinkedList list(arr, 3);
    list.removeAt(2);
    assert(list.elementAt(1) =='y');
}

/*
 * removeAt empty test
 * tests removeAt on an empty list
 */
void removeAt_empty(){
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    // elementAt for out-of-range index
    test_list.removeAt(0);
    }
    catch (const std::range_error &e) {
    // if elementAt is correctly implemented, a range_error 
    // will be thrown,
    // and we will end up here
    range_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (0) not in range [0..0)");

}

/*
 * elementAt()test II
 * tests elementAt for an out of range index
 */
void removeAt_OORup(){
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    int num = 3;
    char arr[] = {'a','b','c'};
    CharLinkedList test_list(arr, num);
    try {
    // elementAt for out-of-range index
    test_list.removeAt(42);
    }
    catch (const std::range_error &e) {
    // if elementAt is correctly implemented, a range_error will 
    // be thrown, and we will end up here
    range_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..3)");

}

/*
 * elementAt()test III
 * tests elementAt on an empty list
 */
void removeAt_OORdown(){
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    int num = 3;
    char arr[] = {'a','b','c'};
    CharLinkedList test_list(arr, num);
    try {
    // elementAt for out-of-range index
    test_list.removeAt(-1);
    }
    catch (const std::range_error &e) {
    // if elementAt is correctly implemented, a range_error 
    // will be thrown,
    // and we will end up here
    range_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (-1) not in range [0..3)");

}

/*
 * replaceAt()test I
 * tests replaceAt on an empty LL
 */
void replaceAt_empty(){
     bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    // elementAt for out-of-range index
    test_list.replaceAt('c' , 0);
    }
    catch (const std::range_error &e) {
    // if elementAt is correctly implemented, a range_error 
    // will be thrown,
    // and we will end up here
    range_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (0) not in range [0..0)");

}

/*
 * replaceAt()test II
 * tests replaceAt with positive out of range value
 */
void replaceAt_OORup(){
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    int num = 3;
    char arr[] = {'a','b','c'};
    CharLinkedList test_list(arr, num);
    try {
    // elementAt for out-of-range index
    test_list.replaceAt('c' , 42);
    }
    catch (const std::range_error &e) {
    // if elementAt is correctly implemented, a range_error will 
    // be thrown, and we will end up here
    range_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..3)");

}

/*
 * replaceAt()test III
 * tests replaceAt with negative out of range value
 */
void replaceAt_OORdown(){
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    int num = 3;
    char arr[] = {'a','b','c'};
    CharLinkedList test_list(arr, num);
    try {
    // elementAt for out-of-range index
    test_list.replaceAt('c' , -1);
    }
    catch (const std::range_error &e) {
    // if elementAt is correctly implemented, a range_error 
    // will be thrown,
    // and we will end up here
    range_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (-1) not in range [0..3)");

}

/* replaceAt test IV
 * tests replaceAt on a one member list
 */
void replaceAt_one(){
    int num = 1;
    char arr[] = {'a'};
    CharLinkedList test_list(arr, num);
    
    //call function and make assertion
    test_list.replaceAt('c' , 0);
    assert(test_list.elementAt(0) == 'c');
}

/* replaceAt test V
 * tests replaceAt on a one member list
 */
void replaceAt_long(){
    CharLinkedList test_list;
    // initialize long list
    for (int i = 0; i < 1000; i++){
        test_list.pushAtBack('a');
    }
    //call function and make assertion
    test_list.replaceAt('c' , 900);
    assert(test_list.elementAt(900) == 'c');
    assert(test_list.elementAt(899) == 'a');
}

/* toString test I
 * tests toString on a longer list
 */
void toString_long(){
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    assert(test_list.toString() ==     
        "[CharLinkedList of size 8 <<abcdefgh>>]");
}

/*
 * toString II
 * test efficacy of toString function singleton;
 */
void toString_test_one(){
    int num = 1;
    char arr[] = {'a'};
    CharLinkedList test_list(arr, num);
    assert(test_list.toString() ==     
        "[CharLinkedList of size 1 <<a>>]");
}

/*
 * toString III
 * test efficacy of toString function empty;
 */
void toString_test_empty(){
    CharLinkedList test_list;
    assert(test_list.toString() ==     
        "[CharLinkedList of size 0 <<>>]");
}

/* toReverseString test I
 * tests toReverseString on a longer list
 */
void toReverseString_long(){
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    assert(test_list.toReverseString() ==     
        "[CharLinkedList of size 8 <<hgfedcba>>]");
}

/*
 * toReverseString II
 * test efficacy of toReverseString function singleton;
 */
void toReverseString_test_one(){
    int num = 1;
    char arr[] = {'a'};
    CharLinkedList test_list(arr, num);
    assert(test_list.toReverseString() ==     
        "[CharLinkedList of size 1 <<a>>]");
}

/*
 * toReverseString III
 * test efficacy of toReverseString function empty;
 */
void toReverseString_test_empty(){
    CharLinkedList test_list;
    assert(test_list.toReverseString() ==     
        "[CharLinkedList of size 0 <<>>]");
}

// concatenate test I
// tests that two full LLs can be concatenated using this function
void concatenate_testI() {
    char arr[] = {'a','b','c'};
    CharLinkedList list(arr, 3);

    char array[] = {'x','y','z'};
    CharLinkedList test_list = CharLinkedList(array, 3);
    list.concatenate(&test_list);

    assert(list.toString() ==  "[CharLinkedList of size 6 <<abcxyz>>]");

}

// concatenate test II
// tests that two full differently size arrays can be concatenated 
// using this function
void concatenate_testII() {
    char arr[] = {'a','b','c'};
    CharLinkedList list(arr, 3);

    char array[] = {'y','z'};
    CharLinkedList test_list = CharLinkedList(array, 2);
    list.concatenate(&test_list);

    assert(list.toString() ==  "[CharLinkedList of size 5 <<abcyz>>]");
}

// concatenate test III
// tests that one full one empty LLs can be concatenated 
// using this function
void concatenate_testIII() {
    char arr[] = {'a','b','c'};
    CharLinkedList list(arr, 3);

    CharLinkedList test_list;
    list.concatenate(&test_list);

    assert(list.toString() ==  "[CharLinkedList of size 3 <<abc>>]");
}

// concatenate test IV
// tests that two empty LLs can be concatenated 
// using this function
void concatenate_testIV() {
    CharLinkedList list;

    CharLinkedList test_list;
    list.concatenate(&test_list);

    assert(list.toString() ==  "[CharLinkedList of size 0 <<>>]");
}

// Tests correct insertion into an empty AL.
// Afterwards, size should be 1 and element at index 0
// should be the element we inserted.
void insertAt_empty_correct() { 

    CharLinkedList test_list;
    test_list.insertAt('a', 0);
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');

}

// Tests incorrect insertion into an empty AL.
// Attempts to call insertAt for index larger than 0.
// This should result in an std::range_error being raised.
void insertAt_empty_incorrect() {

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    // insertAt for out-of-range index
    test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
    // if insertAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    range_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0]");
    
}

// Tests correct insertAt for front of 1-element list.
void insertAt_front_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at front
    test_list.insertAt('b', 0);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'a');
    
}

// Tests correct insertAt for back of 1-element list.
void insertAt_back_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at back
    test_list.insertAt('b', 1);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    
}

// Tests calling insertAt for a large number of elements.
void insertAt_many_elements() {
    
    CharLinkedList test_list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.insertAt('a', i);
    }

    assert(test_list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
    
}

// Tests insertion into front of a larger list
void insertAt_front_large_list() {
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    test_list.insertAt('y', 0);

    assert(test_list.size() == 10);
    assert(test_list.elementAt(0) == 'y');
    assert(test_list.toString() ==     
        "[CharLinkedList of size 10 <<yabczdefgh>>]");

}

// Tests insertion into the back of a larger list
void insertAt_back_large_list() {

    char test_arr[10] = { 'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 10);  

    test_list.insertAt('x', 10);

    assert(test_list.size() == 11);
    assert(test_list.elementAt(10) == 'x');
    assert(test_list.toString() == 
    "[CharLinkedList of size 11 <<yabczdefghx>>]"); 

}

// Tests insertion into the middle of a larger list
void insertAt_middle_large_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.insertAt('z', 3);

    assert(test_list.size() == 9);
    assert(test_list.elementAt(3) == 'z');
    assert(test_list.toString() ==  
        "[CharLinkedList of size 9 <<abczdefgh>>]");

}

// Tests out-of-range insertion for a non-empty list.
void insertAt_nonempty_incorrect() {
   
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8]");
    
}

// insertInOrder testing
// tests the ability of the function for a first char insertion
void insertInOrder_correct_front(){
    char test_arr[8] = {'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i'};
    CharLinkedList test_list(test_arr, 8);

    test_list.insertInOrder('a');
    assert(test_list.size() == 9);
    assert(test_list.toString() ==  "[CharLinkedList of size 9 <<abcdefghi>>]");
}

// insertInOrder testing II
// tests the ability of the function for a middle char insertion
void insertInOrder_correct_middle(){
    char test_arr[8] = {'a', 'b', 'c', 'e', 'f', 'g', 'h', 'i'};
    CharLinkedList test_list(test_arr, 8);

    test_list.insertInOrder('d');
    assert(test_list.size() == 9);
    assert(test_list.toString() ==  "[CharLinkedList of size 9 <<abcdefghi>>]");
}

// insertInOrder testing III
// tests the ability of the function for a back char insertion
void insertInOrder_correct_end(){
    char test_arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(test_arr, 8);

    test_list.insertInOrder('z');
    assert(test_list.size() == 9);
    assert(test_list.toString() ==  "[CharLinkedList of size 9 <<abcdefghz>>]");
}

// insertInOrder testing IV
// tests the ability of the function for a back char insertion
void insertInOrder_correct_empty(){
    CharLinkedList test_list;

    test_list.insertInOrder('z');
    // assert(test_list.size() == 1);
    assert(test_list.toString() ==  "[CharLinkedList of size 1 <<z>>]");
}

// insertInOrder testing III
// tests the ability of the function for a back char insertion
void insertInOrder_correct_same(){
    char test_arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(test_arr, 8);

    test_list.insertInOrder('c');
    assert(test_list.size() == 9);
    assert(test_list.toString() ==  "[CharLinkedList of size 9 <<abccdefgh>>]");
}
/*
 *  CharLinkedList.cpp
 *  Amelie Wickham
 *  02.01.24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  This file contains the implementation of the Linked List 
 *  ADT described in the CharLinkedList.h file. These functions 
 *  allow for the functioning of CharLinkedList class as a 
 *  dynamic data type.
 *
 */

#include "CharLinkedList.h"
#include <sstream>
#include <iostream>

using namespace std;


/*
 * name:      LinkedList default constructor I
 * purpose:   initialize an empty CharLinkedList
 * arguments: none
 * returns:   none
 * */
CharLinkedList::CharLinkedList(){
    numItems = 0;
    front = nullptr;
    back = nullptr;
}

/*
 * name:      LinkedList constructor II
 * purpose:   initialize a CharLinkedList with one node
 * arguments: character
 * returns:   none
 */
CharLinkedList::CharLinkedList(char c){
    numItems = 1;

    // create new node
    front = newNode(c, nullptr, nullptr);
    back = front;
}

/*
 * name:      LinkedList constructor III
 * purpose:   initialize a CharLinkedList from a given array
 * arguments: array, size integer
 * returns:   none
 */
CharLinkedList::CharLinkedList(char arr[], int size){
    // initiate empty CharLinkedList
    numItems = 0;
    front = nullptr;
    back = nullptr;

    // check size, if empty return initiated empty linkedlist
    if (size == 0) return;  

    // otherwise use loop to set 
    else {
        // use pushAtBack as helper function
        for (int i = 0; i < size; i++){
            pushAtBack(arr[i]);
        }
    }
}

/*
 * name:      CharLinkedList constructor IV
 * purpose:   initialize a deep copy of a CharLinkedList
 * arguments: constant CharLinkedList
 * returns:   none
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other){
    // set pointers and variables to reflect an empty listt
    front = nullptr;
    back = nullptr;
    numItems = 0; 

    // temp variable to track through other listt
    Node* temp = other.front;

    // go through other list, push at back each element of list
    while (temp != nullptr) {
        pushAtBack(temp->data);
        temp = temp->next;
    }

}


/*
 * name:      ~CharLinkedList()
 * purpose:   recycle memory from CharLinkedList
 * arguments: none
 * returns:   none
 */
CharLinkedList::~CharLinkedList(){
    // use recycleRecursive helper function to recycle memory
    recycleRecursive(front);
}

/*
 * name:      Assignment opperator for class CharLinkedList
 * purpose:   recycles the storage associated with the instance
              on the left of the assignment and makes a deep copy 
              of the instance on the right hand side into
              the instance on the left hand side.
 * arguments: instance of the CharLinkedList
 * returns:   none
 */
CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other){
    // if lists are the same, return list
    if (this == &other) {
        return *this;
    }

    //recycle memory and set numItems to other numItems
    clear();


    // if list is not empty, push at back other information
    if (numItems > 0){
        for (int i = 0; i < numItems; i++){
            pushAtBack(other.elementAt(i));
        }
    }
    // return list
    return *this;

}

/*
 * name:      isEmpty()
 * purpose:   check numItems to determine whether or not list
 *            is empty
 * arguments: none
 * returns:   boolean value
 */
bool CharLinkedList:: isEmpty() const{
    // if numItems is zero, list is empty
    if (size() == 0){
        return true;
    }
    // if numItems is anything other than zero, 
    else return false;
}

/*
 * name:      clear()
 * purpose:   calls recycle function to clear the LL and resets basic
 *            info
 * arguments: none
 * returns:   none
 */
void CharLinkedList:: clear(){
    // use the recycleRecursive function to recycle memory
    recycleRecursive(front);

    // initiate new empty LinkedList
    numItems = 0;
    front = nullptr;
    back = nullptr;
}

/*
 * name:      size()
 * purpose:   access private variable numItems and reurn integer
 * arguments: none
 * returns:   integer
 */
int CharLinkedList::size() const{
    return numItems;
}

/*
 * name:      first()
 * purpose:   access char data in first node of LL
 * arguments: none
 * returns:   character
 */
char CharLinkedList::first() const{
    // check that LL isn't empty - if it is throw runtime error
    if (isEmpty()){
        throw std::runtime_error("cannot get first of"
                                 " empty LinkedList");
    }

    // otherwise return char data of front node
    else{
        return front->data;
    }
}

/*
 * name:      last()
 * purpose:   access char data in last node of LL
 * arguments: none
 * returns:   character
 */
char CharLinkedList::last() const{
    // check that LL isn't empty - if it is throw runtime error
    if (isEmpty()){
        throw std::runtime_error("cannot get last of"
                                 " empty LinkedList");
    }

    // otherwise return char data of back node
    else{
        return back->data;
    }
}

/*
 * name:      elementAt()
 * purpose:   use nodeFinder helper function to find a node at
 *            given index and then return char data from that node
 * arguments: index integer
 * returns:   character
 */
char CharLinkedList::elementAt(int index) const{
    // check that LL isn't empty - if it is throw runtime error
    if (isEmpty()){
        throw std::runtime_error("cannot get element of"
                                 " empty LinkedList");
    }
    // check for range error, throw message if applicable
    if (index >= size() or index < 0){
        throw std::range_error("index (" + std::to_string(index) 
                + ") not in range [0.." + std::to_string(size()) + ")");
    }
    // if index is in range, use nodeFinder() helper function to recursively
    // access node
    else{
        Node *temp = nodeFinder(index, front);
        return temp->data;
    }
}

/*
 * name:      toString
 * purpose:   print message with the string of the char list
 * arguments: none
 * returns:   string
 */
std::string CharLinkedList::toString() const{
    // declare string variables
    std::string word;
    std::string message;

    // compile elements into one string
    for (int i = 0; i < size(); i++){
        word += elementAt(i);
    }

    // form and return message with size and string
    message = "[CharLinkedList of size " + std::to_string(size());
    message += " <<" + word + ">>]";

    return message;
}

/*
 * name:      toReverseString
 * purpose:   print message with the string in reverse
 * arguments: none
 * returns:   string
 */
std::string CharLinkedList::toReverseString() const{
    // declare string variables
    std::string word;
    std::string message;

    // compile elements into one string backwards
    for (int i = (size() - 1); i >= 0; i--){
        word += elementAt(i);
    }

    // form and return message with size and reversed string
    message = "[CharLinkedList of size " + std::to_string(size());
    message += " <<" + word + ">>]";

    return message;
}

/*
 * name:      pushAtBack()
 * purpose:   create a new node at the back of the linked list
 * arguments: character
 * returns:   none
 */
void CharLinkedList::pushAtBack(char c){
    // if list is empty, create new node with char c
    if (isEmpty()){
        pushAtFront(c);
    }
    
    // base case - create new node a the back of list
    else {
        Node *prevBack = back;
        back = newNode(c, nullptr, prevBack);
        prevBack->next = back;
        numItems++;
    }
}

/*
 * name:      pushAtFront()
 * purpose:   create a new node at the front of the linked list
 * arguments: character
 * returns:   none
 */
void CharLinkedList:: pushAtFront(char c){
    // create new node
    front = newNode(c, front, nullptr);

    // check to see if list is empty
    if (size() == 0){
        back = front;
    }
    numItems++;
}

/*
 * name:      insertAt()
 * purpose:   add a node at a given index and adjust pointers
 *            accordingly
 * arguments: character and index
 * returns:   none
 */
void CharLinkedList:: insertAt(char c, int index){
    // // check for range error, throw message if applicable
    if (index < 0 or index > size()){
        throw std::range_error("index (" + std::to_string(index) 
                + ") not in range [0.." + std::to_string(size()) + "]");
        return;
    }
    // if index is zero, call pushAtFront function
    if (index == 0){
        pushAtFront(c);
    }

    // if index is equal to size, call pushAtBack function
    else if (index == (size())){
        pushAtBack(c);
    }

    // otherwise use nodeFinder helper function to determine pointers to
    // nodes at index and index - 1, adjust pointers and variables as needed 
    else {
        Node *curr = nodeFinder((index - 1), front);
        Node *next = curr->next;
        Node *insert = newNode(c, next, curr);
        curr->next = insert;
        next->prev = insert;
        numItems++;
    }
    return;

}

/* 
* name:       insertInOrder
 * purpose:   add a char to a linked list of chars in order
 * arguments: char
 * returns:   none
 */
void CharLinkedList::insertInOrder(char c){
    // if list is empty, push at front
    if (isEmpty()){
        pushAtFront(c);
    }
    // otherwise, check each element against given char
    else {
        for (int i = 0; i < size(); i++){
            // insert when it reaches a char greater than or 
            // equal to in ascii value
            if (c <= elementAt(i)){
                insertAt(c, i);
                return;
            }
            // reached end of list, push at back
            if (i == (size()-1)){
                pushAtBack(c);
                return;
            }
        }
    }
}

/*
 * name:      popFromFront()
 * purpose:   remove node at the front of the linked list
 * arguments: none
 * returns:   none
 */
void CharLinkedList:: popFromFront(){
     // if list is empty, throw runtime error
    if (isEmpty()){
        throw std::runtime_error("cannot pop from"
                                 " empty LinkedList");
        return;
    }
    // else use temp variable to point to front, adjust pointers 
    // then delete temp to recycle memory
    Node *temp = front;
    front = front->next;
    front->prev = nullptr;

    delete temp;

    // adjust numItems variable
    numItems--;
}

/*
 * name:      popFromBack()
 * purpose:   remove node at the front of the linked list
 * arguments: none
 * returns:   none
 */
void CharLinkedList:: popFromBack(){
    if (isEmpty()){
        throw std::runtime_error("cannot pop from"
                                 " empty LinkedList");
        return;
    }
    Node *temp = back;
    back = back->prev;
    back->next = nullptr;
    delete temp;
    numItems--;
}

/*
 * name:      removeAt()
 * purpose:   remove a node from a given index and adjust pointers
 *            accordingly
 * arguments: index
 * returns:   none
 */
void CharLinkedList:: removeAt(int index){
    // check for range error, throw message if applicable
    if (index >= size() or index < 0){
        throw std::range_error("index (" + std::to_string(index) 
                + ") not in range [0.." + std::to_string(size()) + ")");
    } 
    // check if front or back index is used
    else if (index == 0 and numItems != 0){
        popFromFront();
    }
    else if (index == (size()-1)){
        popFromBack();
    }
    // base case - calls recursive nodeFinder helper function, adjusts
    // pointers accordingly, deletes memory 
    else {
        Node *temp = nodeFinder(index, front);
        Node *previous = temp->prev;
        Node *nextnode = temp->next;
        previous->next = nextnode;
        nextnode->prev = previous;
        numItems--;
        delete temp;
    }
}

/*
 * name:      replaceAt()
 * purpose:   replace data in a node at given index with given data
 * arguments: character and index
 * returns:   none
 */
void CharLinkedList::replaceAt(char c, int index){
    // check for range error, throw message if applicable
    if (index >= size() or index < 0){
        throw std::range_error("index (" + std::to_string(index) 
                + ") not in range [0.." + std::to_string(size()) + ")");
    } 
    // base case - call nodeFinder helper function, then replace 
    // data at that index
    else{
        Node *element = nodeFinder(index, front);
        element->data = c;
    }
}

/*
 * name:      concatenate()
 * purpose:   combine two linked lists into one 
 * arguments: character and two node pointers, one to the next
 *            node and one to the previous node
 * returns:   node pointer
 */
void CharLinkedList::concatenate(CharLinkedList *other){
    // if list is empty, set front to other front
    if (isEmpty()) {
            front = other->front;     
    }

    // adjust pointers as neccesary 
    else {
        back->next = other->front;

        // if other list is not empty, adjust the back pointer
        if (not other->isEmpty()){
            other->front->prev = back;
            back = other->back;
        }
    }
    
    // Set the other front to nullptr to prevent memory leaks
    other->front = nullptr;
    numItems += other->size();
}

/*
 * name:      newNode()
 * purpose:   create a new node 
 * arguments: character and two node pointers, one to the next
 *            node and one to the previous node
 * returns:   node pointer
 */
CharLinkedList::Node *CharLinkedList::newNode(char newData, 
                                    Node *next, Node *prev){
    // create new node
    Node *newNode = new Node;

    // adjust pointers and data to the arguments
    newNode->data = newData;
    newNode->next = next;
    newNode->prev = prev;

    // return new node
    return newNode;
}

/*
 * name:      nodeFinder()
 * purpose:   use recursion to find a node at a given index
 * arguments: index and pointer to a node
 * returns:   pointer to a node
 */
CharLinkedList::Node *CharLinkedList::nodeFinder(int index, Node *curr) const{
    // base case - arrived at node
    if (index == 0){
        return curr;
    }

    // recursive case - continue recursion
    else{
        return nodeFinder(index - 1, curr->next);
    }
}

/*
 * name:      recycleRecursive()
 * purpose:   use recursion to recycle all memory used for LL
 * arguments: pointer to a node
 * returns:   none
 */
void CharLinkedList::recycleRecursive(Node *curr){
    
    // base case - last node
    if (curr == nullptr){
        delete curr;
        return;
    }

    // recursive case - LL is not empty, memory needs to be recycled 
    else {
        Node *temp = curr->next;
        delete curr;
        recycleRecursive(temp);
    }
}

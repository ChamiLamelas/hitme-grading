/*
 *  CharLinkedList.h
 *  Amelie Wickham
 *  9.21.23
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  This file serves as the abstract data type, 
    or ADT for the CharLinkedList class. It contains the 
    outlines of all public and private functions and variables 
    as well as the arguments each takes, but no specifics 
    about the actual implementation, or what is "under the 
    hood" of each function.
 *
 */

#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H
#include <string>


class CharLinkedList {
public:
    //constructors
    CharLinkedList();
    CharLinkedList(char c);
    CharLinkedList(char arr[], int size);
    CharLinkedList(const CharLinkedList &other);

    //destructors
    ~CharLinkedList();
    void clear();

    // editing functions
    CharLinkedList &operator=(const CharLinkedList &other);
    void replaceAt(char c, int index);
    void concatenate(CharLinkedList *other);

    // access functions
    bool isEmpty() const;
    int size() const;
    char first() const;
    char last() const;
    char elementAt(int index) const;
    std::string toString() const;
    std::string toReverseString() const;

    // insertion functions
    void pushAtBack(char c);
    void pushAtFront(char c); 
    void insertAt(char c, int index); 
    void insertInOrder(char c);

    // deletion functionr
    void popFromFront();
    void popFromBack();
    void removeAt(int index);

private:

    // node struct
    struct Node {
        char data;
        Node *prev;
        Node *next;
    };

    // variables
    int numItems = 0;

    //node pointers
    Node *front;
    Node *back;

    //private helper functions
    Node *newNode(char newData, Node *next, Node *prev);
    Node *nodeFinder(int index, Node *curr) const;
    void recycleRecursive(Node *curr);

};

#endif
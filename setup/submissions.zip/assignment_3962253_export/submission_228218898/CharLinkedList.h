/*
 *  CharLinkedList.h
 *  Edited By - Nithya Reddy Chinthakuntla
 *  Date created: 01/30/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  This is a header file defines class declaration for CharLinkedList.
 * 
 *  It has methods to manipulate the list such as insertion, deletion, and 
 *  concatenation.
 *  On client side, have to ensure proper usage of methods to prevent errors
 *  such as out-of-range indices may result in unexpected behavior
 *  and expect to throw error
 * 
 */

#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H
#include <string>
class CharLinkedList {
    public:

    /* 
     * Constructors usually initialize instances of the CharLinkedList class
     * with different initial states: empty, containing a single character,
     * or initialized with an array of characters.
    */

    // Default constructor
    CharLinkedList(); // Creates an empty CharLinkedList

    // Single character constructor
    CharLinkedList(char c); 
    //Initializes a CharLinkedList with a single character.

    // Array constructor
    CharLinkedList(char arr[], int size); 
    //Initializes a CharLinkedList with an array of characters and its size.

    // Copy constructor
    CharLinkedList(const CharLinkedList& other);
    //Creates a copy of another CharLinkedList.

    ~CharLinkedList(); //Destructor

    CharLinkedList& operator=(const CharLinkedList& other); //Operator Overload

    // Public member functions

    bool isEmpty() const;
    void clear();
    int size() const;
    char first() const;
    char last() const;
    char elementAt(int index) const;
    std::string toString() const;
    std::string toReverseString() const;
    void pushAtBack(char c);
    void pushAtFront(char c);
    void insertAt(char c, int index);
    void insertInOrder(char c);
    void popFromFront();
    void popFromBack();
    void removeAt(int index);
    void replaceAt(char c, int index);
    void concatenate(CharLinkedList *other);

    private:

        // Node structure for linked list elements
        struct Node {
            char data;
            Node *next;
            Node *prev;
            Node(char c) : data(c), next(nullptr), prev(nullptr) {}
        };

        Node *head; // Pointer to the first node
        Node *tail; // Pointer to the last node
        int numItems;  // Number of items in the linked list
};

#endif

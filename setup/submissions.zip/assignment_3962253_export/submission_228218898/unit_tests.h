/*
 *  unit_tests.h
 *  Edited By - Nithya Reddy Chinthakuntla
 *  Date created: 01/30/2024
 *  Unit tests for the CharLinkedList class.
 */

#include "CharLinkedList.h"
#include <cassert>

/********************************************************************\
*                       CHAR LINKED LIST TESTS                        *
\********************************************************************/

// Test isEmpty() on an empty list.
void test_isEmpty_empty() {
    CharLinkedList test_list;
    assert(test_list.isEmpty());  // The list should be empty.
}
// Test isEmpty() on a non-empty list.
void test_isEmpty_nonEmpty() {
   CharLinkedList test_list;
    test_list.pushAtBack('a');
    test_list.pushAtBack('b');
    test_list.pushAtBack('c');
    test_list.pushAtBack('d');
    test_list.pushAtBack('e');
    assert(not test_list.isEmpty());  // The list should not be empty.
}

//Test case clear() function
void test_clear(){
    CharLinkedList test_list1;
    test_list1.pushAtBack('c');
    test_list1.pushAtBack('a');
    test_list1.pushAtBack('t');
    assert(test_list1.toString() == "[CharLinkedList of size 3 <<cat>>]");  
    test_list1.clear();
    assert(test_list1.isEmpty());  // The list should be empty.
    assert(test_list1.size() == 0);
}
// Test clear() on a non-empty list.
void test_clear_nonEmpty() {
    CharLinkedList test_list;
    test_list.pushAtBack('a');
    test_list.pushAtBack('b');
    test_list.pushAtBack('c');
    test_list.pushAtBack('d');
    test_list.pushAtBack('e');

    test_list.clear();

    assert(test_list.isEmpty());  // The list should be empty.
    assert(test_list.size() == 0);  // The size should be 0.
}
 
 //To test size() function
 void test_size(){
    CharLinkedList charList;
    charList.insertAt('C',0);
    charList.insertAt('o',1);
    charList.insertAt('m',2);
    charList.insertAt('p',3);
    charList.insertAt(' ',4);
    charList.insertAt('1',5);
    charList.insertAt('5',6);
    assert(charList.size() == 7); 
    assert(charList.toString() == "[CharLinkedList of size 7 <<Comp 15>>]");
 }

// Test size() on an empty list.
void test_size_empty() {
    CharLinkedList test_list;
    assert(test_list.size() == 0);  // The size should be 0.
}
// Test size() on a non-empty list.
void test_size_nonEmpty() {
    CharLinkedList test_list;
    test_list.pushAtBack('a');
    test_list.pushAtBack('b');
    test_list.pushAtBack('c');
    test_list.pushAtBack('d');
    test_list.pushAtBack('e');
    assert(test_list.size() == 5);  // The size should be 5.
}

// Test first() on a non-empty list.
void test_first_nonEmpty() {
    CharLinkedList test_list;
    test_list.pushAtBack('a');
    test_list.pushAtBack('b');
    test_list.pushAtBack('c');
    test_list.pushAtBack('d');
    test_list.pushAtBack('e');
    assert(test_list.first() == 'a');  // The first element should be 'a'.
}
// Test first() on a empty list.
void test_first_empty(){
    CharLinkedList test_list;
    bool runtime_error_thrown = false;
    std::string error_message = "";
    try {
        test_list.first();
    } catch (const std::runtime_error& e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }
    // Asserts
    assert(runtime_error_thrown);
    assert(error_message == "cannot get first of empty LinkedList");
}

// Test last() on a non-empty list.
void test_last_nonEmpty() {
    CharLinkedList test_list;
    test_list.pushAtBack('a');
    test_list.pushAtBack('b');
    test_list.pushAtBack('c');
    test_list.pushAtBack('d');
    test_list.pushAtBack('e');
    assert(test_list.last() == 'e');  // The last element should be 'e'.
}

// Test last() on a empty list.
void test_last_empty(){
    CharLinkedList test_list;
    bool runtime_error_thrown = false;
    std::string error_message = "";
    try {
        test_list.last();
    } catch (const std::runtime_error& e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    // Asserts
    assert(runtime_error_thrown);
    assert(error_message == "cannot get last of empty LinkedList");

}

//Tests correct insertion into an empty AL.
//Afterwards, size should be 1 and element at index 0
//should be the element we inserted.
void insertAt_empty_correct() { 

    CharLinkedList test_list;
    test_list.insertAt('a', 0);
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');
}

// Tests incorrect insertion into an empty AL.
// Attempts to call insertAt for index larger than 0.
// This should result in an std::range_error being raised.
void insertAt_empty_incorrect() {

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    // insertAt for out-of-range index
    test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
    // if insertAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    range_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0]"); 
}

// Tests correct insertAt for front of 1-element list.
void insertAt_front_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at front
    test_list.insertAt('b', 0);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'a'); 
}

// Tests correct insertAt for back of 1-element list.
void insertAt_back_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at back
    test_list.insertAt('b', 1);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    
}

// Tests calling insertAt for a large number of elements.
// Not only does this test insertAt, it also checks that
// array expansion works correctly.
void insertAt_many_elements() {
    
    CharLinkedList test_list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.insertAt('a', i);
    }

    assert(test_list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }  
}

// Tests insertion into front of a larger list
void insertAt_front_large_list() {
    CharLinkedList test_list;
    test_list.pushAtFront('h');
    test_list.pushAtFront('g');
    test_list.pushAtFront('f');
    test_list.pushAtFront('e');
    test_list.pushAtFront('d');
    test_list.pushAtFront('c');
    test_list.pushAtFront('b');
    test_list.pushAtFront('a');  
    test_list.insertAt('z', 3);
    assert(test_list.size() == 9);
    assert(test_list.elementAt(3) == 'z');
    assert(test_list.toString() == "[CharLinkedList of size 9 <<abczdefgh>>]");

}

// Tests insertion into the back of a larger list
void insertAt_back_large_list() {
    CharLinkedList test_list;
    test_list.pushAtBack('y');
    test_list.pushAtBack('a');
    test_list.pushAtBack('b');
    test_list.pushAtBack('c');
    test_list.pushAtBack('d');
    test_list.pushAtBack('e');
    test_list.pushAtBack('f');
    test_list.pushAtBack('g');
    test_list.pushAtBack('h');   

    test_list.insertAt('x', 9);

    assert(test_list.size() == 10);
    assert(test_list.elementAt(9) == 'x');
    assert(test_list.toString() 
    == "[CharLinkedList of size 10 <<yabcdefghx>>]"); 

}

// Tests insertion into the middle of a larger list
void insertAt_middle_large_list() {
    CharLinkedList test_list;
    test_list.pushAtBack('a');
    test_list.pushAtBack('b');
    test_list.pushAtBack('c');
    test_list.pushAtBack('d');
    test_list.pushAtBack('e');
    test_list.pushAtBack('f');
    test_list.pushAtBack('g');
    test_list.pushAtBack('h');   

    test_list.insertAt('z', 3);

    assert(test_list.size() == 9);
    assert(test_list.elementAt(3) == 'z');
    assert(test_list.toString() =="[CharLinkedList of size 9 <<abczdefgh>>]");

}

// Tests out-of-range insertion for a non-empty list.
void insertAt_nonempty_incorrect() {
    CharLinkedList test_list;
    test_list.pushAtBack('a');
    test_list.pushAtBack('b');
    test_list.pushAtBack('c');
    test_list.pushAtBack('d');
    test_list.pushAtBack('e');
    test_list.pushAtBack('f');
    test_list.pushAtBack('g');
    test_list.pushAtBack('h'); 

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8]");
    
}

// Test elementAt() on a non-empty with valid index
void test_elementAt_validIndex() {
    CharLinkedList test_list;
    test_list.pushAtBack('a');
    test_list.pushAtBack('b');
    test_list.pushAtBack('c');
    test_list.pushAtBack('d');
    test_list.pushAtBack('e');
    assert(test_list.elementAt(2) == 'c');  
    // The element at index 2 should be 'c'.
}

// Test elementAt() with non-empty list but invalid index is given 
void test_elementAt_invalidIndex(){
    CharLinkedList test_list;
    test_list.pushAtBack('a');
    test_list.pushAtBack('b');
    test_list.pushAtBack('c');
    test_list.pushAtBack('d');
    test_list.pushAtBack('e');

    bool range_error_thrown = false;
    std::string error_message = "";

    try {
        test_list.elementAt(8);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (8) not in range [0..5)");     
}

// Test elementAt() on a empty list
void test_elementAt_empty(){
    CharLinkedList test_list;
    bool range_error_thrown = false;
    std::string error_message = "";

    try {
        test_list.elementAt(4);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (4) not in range [0..0)");     
}

// Test toString() on an empty list.
void test_toString_empty() {
    CharLinkedList test_list;
    assert(test_list.toString() == "[CharLinkedList of size 0 <<>>]"); 
}

// Test toString() on a non-empty list.
void test_toString_nonEmpty() {
    CharLinkedList test_list;
    test_list.pushAtBack('a');
    test_list.pushAtBack('b');
    test_list.pushAtBack('c');
    test_list.pushAtBack('d');
    test_list.pushAtBack('e');
    assert(test_list.toString() == "[CharLinkedList of size 5 <<abcde>>]");  
}

// Test toReverseString() on an empty list.
void test_toReverseString_empty() {
    CharLinkedList test_list;
    assert(test_list.toReverseString() == "[CharLinkedList of size 0 <<>>]");  
}

// Test toReverseString() on a non-empty list.
void test_toReverseString_nonEmpty() {
    CharLinkedList test_list;
    test_list.pushAtBack('a');
    test_list.pushAtBack('d');
    test_list.pushAtBack('e');
    assert(test_list.toReverseString() =="[CharLinkedList of size 3 <<eda>>]");
}

// Test pushAtFront() on an empty list.
void test_pushAtFront_empty() {
    CharLinkedList test_list;
    test_list.pushAtFront('z');
    assert(test_list.size() == 1);  // The size should be 1.
    assert(test_list.first() == 'z');  // The first element should be 'z'.
    assert(test_list.toString() == "[CharLinkedList of size 1 <<z>>]");  
}

// Test pushAtFront() on a non-empty list.
void test_pushAtFront_nonEmpty() {
    CharLinkedList test_list;
    test_list.pushAtBack('a');
    test_list.pushAtBack('b');
    test_list.pushAtBack('c');
    test_list.pushAtBack('d');
    test_list.pushAtBack('e');
    test_list.pushAtFront('z');
    assert(test_list.size() == 6);  // The size should be 6.
    assert(test_list.first() == 'z');  // The first element should be 'z'.
    assert(test_list.toString() == "[CharLinkedList of size 6 <<zabcde>>]");  
    // The string representation of the list.
}

// Test pushAtBack() on an empty list.
void test_pushAtBack_empty() {
    CharLinkedList test_list;
    test_list.pushAtBack('z');
    assert(test_list.size() == 1);  // The size should be 1.
    assert(test_list.last() == 'z');  // The last element should be 'z'.
    assert(test_list.toString() == "[CharLinkedList of size 1 <<z>>]"); 
     // The string representation of the list.
}

// Test pushAtBack() on a non-empty list.
void test_pushAtBack_nonEmpty() {
    CharLinkedList test_list;
    test_list.pushAtBack('a');
    test_list.pushAtBack('b');
    test_list.pushAtBack('c');
    test_list.pushAtBack('d');
    test_list.pushAtBack('e');
    test_list.pushAtBack('z');
    assert(test_list.size() == 6);  // The size should be 6.
    assert(test_list.last() == 'z');  // The last element should be 'z'.
    assert(test_list.toString() == "[CharLinkedList of size 6 <<abcdez>>]");  
    // The string representation of the list.
}

// Test insertInOrder() on an empty list.
void test_insertInOrder_empty() {
    CharLinkedList test_list;
    test_list.insertInOrder('c');
    assert(test_list.size() == 1);  // The size should be 1.
    assert(test_list.first() == 'c');  // The first element should be 'c'.
    assert(test_list.toString() == "[CharLinkedList of size 1 <<c>>]"); 
     // The string representation of the list.
}

// Test insertInOrder() on a non-empty list.
void test_insertInOrder_nonEmpty() {
    CharLinkedList test_list;
    test_list.pushAtBack('a');
    test_list.pushAtBack('b');
    test_list.pushAtBack('c');
    test_list.pushAtBack('d');
    test_list.pushAtBack('e');
    test_list.insertInOrder('B');
    assert(test_list.size() == 6);  // The size should be 6.
    assert(test_list.toString() == "[CharLinkedList of size 6 <<Babcde>>]");  
    // The string representation of the ordered list.
}

// Test popFromFront() on a non-empty list.
void test_popFromFront_nonEmpty() {
    CharLinkedList test_list;
    test_list.pushAtBack('a');
    test_list.pushAtBack('b');
    test_list.pushAtBack('c');
    test_list.pushAtBack('d');
    test_list.pushAtBack('e');
    test_list.popFromFront();
    assert(test_list.size() == 4);  // The size should be 4.
    assert(test_list.first() == 'b');  // The first element should be 'b'.
    assert(test_list.toString() == "[CharLinkedList of size 4 <<bcde>>]");  
}

// Test popFromFront() on a empty list
void test_popFromFront_empty(){
    CharLinkedList test_list;
    bool runtime_error_thrown = false;
    std::string error_message = "";
    try {
        test_list.popFromFront();
    } catch (const std::runtime_error& e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    // Asserts
    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

// Test popFromBack() on a non-empty list.
void test_popFromBack_nonEmpty() {
    CharLinkedList test_list;
    test_list.pushAtBack('a');
    test_list.pushAtBack('b');
    test_list.pushAtBack('c');
    test_list.pushAtBack('d');
    test_list.pushAtBack('e');
    test_list.popFromBack();
    assert(test_list.size() == 4);  // The size should be 4.
    assert(test_list.toString() == "[CharLinkedList of size 4 <<abcd>>]");  
}

// Test popFromBack() on a empty list
void test_popFromBack_empty(){
    CharLinkedList test_list;
    bool runtime_error_thrown = false;
    std::string error_message = "";
    try {
        test_list.popFromBack();
    } catch (const std::runtime_error& e) {
        runtime_error_thrown = true;
        error_message = e.what();
    }

    // Asserts
    assert(runtime_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

// Test removeAt() on a non-empty list.
void test_removeAt_nonEmpty() {
    CharLinkedList test_list;
    test_list.pushAtBack('a');
    test_list.pushAtBack('b');
    test_list.pushAtBack('c');
    test_list.pushAtBack('d');
    test_list.pushAtBack('e');
    test_list.removeAt(2);
    assert(test_list.size() == 4);  // The size should be 4.
    // The element at index 2 should be 'd'.
    assert(test_list.toString() == "[CharLinkedList of size 4 <<abde>>]");  
}

//Test replaceAt() when the lsit is empty
void test_removeAt_Empty(){
    bool range_error_thrown = false;
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    // insertAt for out-of-range index
        test_list.removeAt(10);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (10) not in range [0..0)"); 
}

//Test removet() when invalid index is given
void test_removeAt_invalid(){
    CharLinkedList test_list;
    test_list.pushAtBack('a');
    test_list.pushAtBack('b');
    test_list.pushAtBack('c');
    test_list.pushAtBack('d');
    test_list.pushAtBack('e');
  
    bool range_error_thrown = false;
    std::string error_message = "";

    try {
        test_list.removeAt(10);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (10) not in range [0..5)");     
}

// Test replaceAt() on a non-empty list.
void test_replaceAt_nonEmpty() {
    CharLinkedList test_list;
    test_list.pushAtBack('a');
    test_list.pushAtBack('b');
    test_list.pushAtBack('c');
    test_list.pushAtBack('d');
    test_list.pushAtBack('e');
    test_list.replaceAt('z', 2);
    assert(test_list.size() == 5);  // The size should be 5.
    assert(test_list.elementAt(2) == 'z');  
    // The element at index 2 should be 'z'.
    assert(test_list.toString() == "[CharLinkedList of size 5 <<abzde>>]"); 

//Test replaceAt() when invalid list is empty
}
void test_replaceAt_Empty(){
    bool range_error_thrown = false;
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    // insertAt for out-of-range index
        test_list.replaceAt('a', 10);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (10) not in range [0..0)"); 
}

//Test replaceAt() when invalid index is given
void test_replaceAt_incorrect(){
    CharLinkedList test_list;
    test_list.pushAtBack('a');
    test_list.pushAtBack('b');
    test_list.pushAtBack('c');
    test_list.pushAtBack('d');
    test_list.pushAtBack('e');
  
    bool range_error_thrown = false;
    std::string error_message = "";

    try {
        test_list.replaceAt('h',10);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }
    assert(range_error_thrown);
    assert(error_message == "index (10) not in range [0..5)");     
}

// Test concatenate() on two non-empty lists.
void test_concatenate_nonEmpty() {
    CharLinkedList test_list1;
    test_list1.pushAtBack('c');
    test_list1.pushAtBack('a');
    test_list1.pushAtBack('t');

    CharLinkedList test_list2;
    test_list2.pushAtBack('c');
    test_list2.pushAtBack('a');
    test_list2.pushAtBack('t');

    test_list1.concatenate(&test_list2);

    assert(test_list1.size() == 6);
    assert(test_list1.toString() == "[CharLinkedList of size 6 <<catcat>>]");
}

// Test case when test_list2 is empty while test_list1 is not empty
void test_concatenate_list2_Empty() {
    CharLinkedList test_list1;
    test_list1.pushAtBack('c');
    test_list1.pushAtBack('a');
    test_list1.pushAtBack('t');

    CharLinkedList test_list2;
    test_list1.concatenate(&test_list2);

    assert(test_list1.size() == 3);  // The size should be 3
    assert(test_list1.toString() == "[CharLinkedList of size 3 <<cat>>]");  
}

// Test case when test_list1 is empty while test_list2 is not empty
void test_concatenate_list1_Empty() {
    CharLinkedList test_list1;
    CharLinkedList test_list2;
    test_list2.pushAtBack('c');
    test_list2.pushAtBack('a');
    test_list2.pushAtBack('t');

    test_list1.concatenate(&test_list2);

    assert(test_list1.size() == 3);  // The size should be 3
    assert(test_list1.toString() == "[CharLinkedList of size 3 <<cat>>]");  
}

// Test case for self-concatenation
void test_concatenate_itself() {

    CharLinkedList test_list1;
    test_list1.pushAtBack('c');
    test_list1.pushAtBack('a');
    test_list1.pushAtBack('t');
    CharLinkedList test_list2;
    test_list1.concatenate(&test_list1);

    assert(test_list1.size() == 6);  // The size should be 6
    assert(test_list1.toString() == "[CharLinkedList of size 6 <<catcat>>]");  
}

// Test default constructor
void test_default_constructor() {
    CharLinkedList list;
    assert(list.isEmpty());
    assert(list.size() == 0);
}

// Test constructor with a single character
void test_single_char_constructor() {
    CharLinkedList test_list('a');
    assert(not test_list.isEmpty()); // Check if the list is not empty
    assert(test_list.size() == 1); // Check if the size is 1
    assert(test_list.first() == 'a'); // Check if the first element is 'a'
}

// Test constructor with an array of characters
void test_array_constructor() {
    char arr[] = {'a', 'b', 'c', 'd'};
    int size = sizeof(arr) / sizeof(arr[0]);
    CharLinkedList test_list(arr, size);
    assert(not test_list.isEmpty()); // Check if the list is not empty
    assert(test_list.size() == size); 
    // Check if the size matches the array size
    assert(test_list.toString() == "[CharLinkedList of size 4 <<abcd>>]"); 
    // Check if the elements are inserted correctly
}

// Testing the Big Three

// Test copy constructor
void test_copy_constructor() {
    CharLinkedList test_list;
    test_list.pushAtBack('a');
    test_list.pushAtBack('b');
    test_list.pushAtBack('c');

    CharLinkedList copy(test_list);
    assert(copy.size() == test_list.size());
    assert(copy.toString() == test_list.toString());
    // Check if contents match
}

void test_destructor() {
    {
        CharLinkedList test_list;
        test_list.pushAtBack('a');
        test_list.pushAtBack('b');
        test_list.pushAtBack('c');
        // Destructor is called when test_list goes out of scope
    }
    // the list should be deleted here
}

// Test Assignment Operator
void test_assignment_operator() {
    CharLinkedList test_list;
    test_list.pushAtBack('a');
    test_list.pushAtBack('b');
    test_list.pushAtBack('c');
    // Initialize an empty list
    CharLinkedList op_list;
    
    // Assign original_list to assigned_list using the assignment operator
    op_list = test_list;

    // Assertions
    assert(not op_list.isEmpty());  // Check if assigned_list is not empty
    assert(op_list.size() == test_list.size());  // Check if sizes match
    assert(op_list.toString() == test_list.toString());  
    // Check if contents match
}

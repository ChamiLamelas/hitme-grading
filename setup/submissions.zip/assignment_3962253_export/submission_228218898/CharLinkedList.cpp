/*
 *  CharLinkedList.cpp
 *  Edited By - Nithya Reddy Chinthakuntla
 *  Date created: 01/30/2024
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *  Function definitions for the CharLinkedList class
 */

#include "CharLinkedList.h"
#include <iostream>

/*
 * name:      CharLinkedList default constructor
 * purpose:   Initialize an empty CharLinkedList with head, tail, and numItems
 *            set to nullptr and 0
 * arguments: none
 * returns:   none
 * effects:   Initializes an empty CharLinkedList.
 */

CharLinkedList::CharLinkedList() {
    head = nullptr;
    tail = nullptr;
    numItems = 0;
}

/*
 * name:      CharLinkedList constructor with a single character
 * purpose:   Initialize a CharLinkedList with a single character
 * arguments: Initialize the CharLinkedList with c - character
 * returns:   none
 * effects:   Initializes the CharLinkedList with a single node containing
 *            the character c.
 */
CharLinkedList::CharLinkedList(char c) {
    head = new Node(c);
    tail  = head;
    numItems = 1;
}

/*
 * name:      CharLinkedList constructor with an array of characters
 * purpose:   Initialize a CharLinkedList with an array of characters
 * arguments: arr - array of characters, size - size of the array
 * returns:   none
 * effects:   Initializes the CharLinkedList with nodes containing characters
 *            from the array.
 */
CharLinkedList::CharLinkedList(char arr[], int size){
    head = nullptr;
    tail = nullptr;
    numItems = 0;
    for (int i = 0; i < size; ++i) {
            Node *newNode = new Node(arr[i]);
            if (isEmpty()) {
                head = newNode;
                tail = newNode;
            } 
            else {
                tail->next = newNode;
                newNode->prev = tail;
                tail = newNode;
            }
            numItems++;
        }
}

/*
 * name:      CharLinkedList copy constructor
 * purpose:   Initialize a CharLinkedList as a copy of another CharLinkedList
 * arguments: other - CharLinkedList to copy
 * returns:   none
 * effects:   Initializes the CharLinkedList as a copy of the provided
 *            CharLinkedList.
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other){
    head = nullptr;
    tail = nullptr;
    numItems = 0 ;
    Node *othercurr = other.head;
        while (othercurr != nullptr) {
            Node *newNode = new Node(othercurr->data);
            if (isEmpty()) {
                head = newNode;
                tail = newNode;
            } else {
                tail->next = newNode;
                newNode->prev = tail;
                tail = newNode;
            }
            othercurr = othercurr->next;
            numItems++;
        }

}

/*
 * name:      CharLinkedList destructor
 * purpose:   Destroy the CharLinkedList and free the memory
 * arguments: none
 * returns:   none
 * effects:   Deallocates the memory used by the CharLinkedList.
 */

CharLinkedList::~CharLinkedList() {
        Node *curr = head;
        while (curr != nullptr) {
            Node *nextNode = curr->next;
            delete curr;
            curr = nextNode;
        }
}

/*
 * name:      Assignment operator
 * purpose:   Assign the contents of one CharLinkedList to another
 * arguments: other - the CharLinkedList to copy
 * returns:   a reference to the modified CharLinkedList
 * effects:   Performs a deep copy of the provided CharLinkedList to the 
 *            curr instance.
 */

CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other) {
    if (this != &other) {  
        // Clear curr content and deallocate memory
        clear();

        // Copy elements from other list
        Node *othercurr = other.head;
        while (othercurr != nullptr) {
            Node *newNode = new Node(othercurr->data);
            if (isEmpty()) {
                head = newNode;
                tail = newNode;
            } else {
                tail->next = newNode;
                newNode->prev = tail;
                tail = newNode;
            }
            othercurr = othercurr->next;
            numItems++;
        }
    }

    return *this;  
}

/*
 * name:      isEmpty
 * purpose:   Check if the CharLinkedList is empty
 * arguments: none
 * returns:   true if the CharLinkedList is empty, or else return false 
 * effects:   none
 */

bool CharLinkedList::isEmpty() const{
        return numItems == 0;
}

/*
 * name:      clear
 * purpose:   Clear all elements in the CharLinkedList
 * arguments: none
 * returns:   none
 * effects:   Removes all nodes from CharLinkedList and deallocate memory.
 */

void CharLinkedList::clear(){
    Node *curr = head;
    while (curr != nullptr) {
        Node *nextNode = curr->next;
        delete curr;
        curr = nextNode;
    }
    head = nullptr;
    tail = nullptr;
    numItems = 0;
}

/*
 * name:      size
 * purpose:   Get the number of elements in the CharLinkedList
 * arguments: none
 * returns:   Number of elements in the CharLinkedList
 * effects:   none
 */
int CharLinkedList::size() const{
    return numItems;
}

/*
 * name:      first
 * purpose:   Get the first element in the CharLinkedList
 * arguments: none
 * returns:   First element in the CharLinkedList
 * effects:   Throws an exception if the CharLinkedList is empty.
 */

char CharLinkedList::first() const{
    if (isEmpty()) {
        throw std::runtime_error("cannot get first of empty LinkedList");
    }
    return head->data;

}

/*
 * name:      last
 * purpose:   Get the last element in the CharLinkedList
 * arguments: none
 * returns:   Last element in the CharLinkedList
 * effects:   Throws an exception if the CharLinkedList is empty.
 */

char CharLinkedList::last() const{
    if (isEmpty()){
        throw std::runtime_error("cannot get last of empty LinkedList");
    }
    return tail->data;
}

/*
 * name:      elementAt
 * purpose:   Get the element at a specified index in the CharLinkedList
 * arguments: index - the index of the element to retrieve
 * returns:   the element at the specified index
 * effects:   Throws an exception if the index is out of range.
 */

char CharLinkedList::elementAt(int index) const{
    if (index < 0 or index >= numItems) {
        throw std::range_error("index (" + std::to_string(index) 
        + ") not in range [0.." + std::to_string(numItems) + ")");
    }
    Node *curr = head;
    for (int i = 0; i < index; ++i) {
        curr = curr->next;
    }
    return curr->data;
}

/*
 * name:      toString
 * purpose:   Convert the CharLinkedList to a string representation
 * arguments: none
 * returns:   a string representation of the CharLinkedList
 * effects:   none
 */

std::string CharLinkedList::toString() const{
    std::string res = "[CharLinkedList of size " + std::to_string(numItems)
    + " <<";
    Node *curr = head;
    while (curr != nullptr) {
        res += curr->data;
        curr = curr->next;
    }
    res += ">>]";
    return res;
}

/*
 * name:      toReverseString
 * purpose:   Convert the CharLinkedList to a reversed string representation
 * arguments: none
 * returns:   a reversed string representation of the CharLinkedList
 * effects:   none
 */

std::string CharLinkedList::toReverseString() const {
    std::string res = "[CharLinkedList of size " 
    + std::to_string(numItems) + " <<";
    
    if(numItems == 0) {
        res += ">>]";
        return res; 
    }
    Node *curr = tail; 
    while (curr != nullptr){
        res += curr->data;
        curr = curr->prev;
    }   
    res += ">>]";
    return res;
}

/*
 * name:      pushAtBack
 * purpose:   Add a character to the back of the CharLinkedList
 * arguments: c - the character to add
 * returns:   none
 * effects:   Creates a new node containing the character c and adds it to
 *            the back of the list.
 */

void  CharLinkedList::pushAtBack(char c){
    Node *newNode = new Node(c);
    if (isEmpty()) {
        head = newNode;
        tail = newNode;
    } else {
        tail->next = newNode;
        newNode->prev = tail;
        tail = newNode;
    }
    numItems++;
}

/*
 * name:      pushAtFront
 * purpose:   Add a character to the front of the CharLinkedList
 * arguments: c - the character to add
 * returns:   none
 * effects:   Creates a new node containing the character c and adds it to the
 *            front of the list.
 */

void CharLinkedList::pushAtFront(char c){
    Node *newNode = new Node(c);
    if (isEmpty()) {
        head = newNode;
        tail = newNode;
    } else {
        newNode->next = head;
        head->prev = newNode;
        head = newNode;
    }
    numItems++;
}

/*
 * name:      insertAt
 * purpose:   Insert a character at a specified index in the CharLinkedList
 * arguments: c - the character to insert, index - the index at which to insert
 * returns:   none
 * effects:   Creates a new node containing the character c and inserts it at
 *            the specified index.
 */

void CharLinkedList::insertAt(char c, int index){
    if (index < 0 or index > numItems) {
        throw std::range_error("index (" + std::to_string(index) 
        + ") not in range [0.." + std::to_string(numItems) + "]");
    }
    if (index == 0) {
        pushAtFront(c);
    } else if (index == numItems) {
        pushAtBack(c);
    } else {
        Node *curr = head;
        for (int i = 0; i < index; ++i) {
            curr = curr->next;
        }
        Node *newNode = new Node(c);
        newNode->next = curr;
        newNode->prev = curr->prev;
        curr->prev->next = newNode;
        curr->prev = newNode;
        numItems++;
    }
}

/*
 * name:      insertInOrder
 * purpose:   Insert a character in order into the CharLinkedList
 * arguments: c - the character to insert
 * returns:   none
 * effects:   Creates a new node containing the character c and inserts it in
 *            order.
 */

void CharLinkedList::insertInOrder(char c){
    Node *newNode = new Node(c);

    if (isEmpty() or c <= head->data) {
        pushAtFront(c);
        delete newNode;
    } else if (c >= tail->data) {
        pushAtBack(c);
        delete newNode;
    } else {
        Node *curr = head;
        while (curr != nullptr and c > curr->data) {
            curr = curr->next;
        }
        newNode->next = curr;
        newNode->prev = curr->prev;
        curr->prev->next = newNode;
        curr->prev = newNode;

        numItems++;
    }
}

/*
 * name:      popFromFront
 * purpose:   Remove the character from the front of the CharLinkedList
 * arguments: none
 * returns:   none
 * effects:   Removes the node from the front of the list and frees up memory.
 */

void CharLinkedList::popFromFront() {
    if (isEmpty()) {
        throw std::runtime_error("cannot pop from empty LinkedList");
    }

    Node *prevHead = head;
    head = head->next;
    if (head != nullptr) {
        head->prev = nullptr;
    } else {
        tail = nullptr;
    }
    delete prevHead;
    numItems--;
}

/*
 * name:      popFromBack
 * purpose:   Remove the character from the back of the CharLinkedList
 * arguments: none
 * returns:   none
 * effects:   Removes the node from the back of the list and frees up memory.
 */

void CharLinkedList::popFromBack() {
    if (isEmpty()) {
        throw std::runtime_error("cannot pop from empty LinkedList");
    }

    Node *prevTail = tail;
    tail = tail->prev;
    if (tail != nullptr) {
        tail->next = nullptr;
    } else {
        head = nullptr;
    }
    delete prevTail;
    numItems--;
}

/*
 * name:      removeAt
 * purpose:   Remove the character at a specified index in the CharLinkedList
 * arguments: index - the index of the character to remove
 * returns:   none
 * effects:   Removes the node at the specified index and frees up memory.
 */

void CharLinkedList::removeAt(int index) {
    if (index < 0 or index > numItems) {
        throw std::range_error("index (" + std::to_string(index) 
        + ") not in range [0.." + std::to_string(numItems) + ")");
    }
    if (index == 0) {
        popFromFront();
    } else if (index == numItems - 1) {
        popFromBack();
    } else {
        Node *curr = head;
        for (int i = 0; i < index; ++i) {
            curr = curr->next;
        }
        curr->prev->next = curr->next;
        curr->next->prev = curr->prev;
        delete curr;
        numItems--;
    }
}

/*
 * name:      replaceAt
 * purpose:   Replace the character at a specified index in the CharLinkedList
 * arguments: c - the character to replace with, index - the index to replace
 * returns:   none
 * effects:   Replaces the character at the specified index.
 */

void CharLinkedList::replaceAt(char c, int index) {
    if (index < 0 or index > numItems) {
        throw std::range_error("index (" + std::to_string(index) 
        + ") not in range [0.." + std::to_string(numItems) + ")");
    }

    Node *curr = head;
    for (int i = 0; i < index; ++i) {
        curr = curr->next;
    }
    curr->data = c;
}

/*
 * name:      concatenate
 * purpose:   Concatenate the CharLinkedList with another CharLinkedList
 * arguments: other - a pointer to the CharLinkedList to concatenate with
 * returns:   none
 * effects:   Concatenates the CharLinkedList with the provided CharLinkedList.
 *            If the lists are the same or the curr list is empty, creates
 *            a temporary copy of the other list to avoid
 *            self-concatenation issues.
 */

void CharLinkedList::concatenate(CharLinkedList *other) {
    int newSize = numItems + other->numItems;

  // If this list is empty, or if this and other are the same object,
  // duplicate the data
    if (isEmpty() or this == other) {
        CharLinkedList temp(*other);  // Create a temporary copy of other list
        Node *tempCurr = temp.head;
        while (tempCurr != nullptr) {
            pushAtBack(tempCurr->data);
            tempCurr = tempCurr->next;
        }
    } else {
        // If this list is not empty
        Node *otherCurr = other->head;
        while (otherCurr != nullptr) {
            pushAtBack(otherCurr->data);
            otherCurr = otherCurr->next;
        }
    }
}

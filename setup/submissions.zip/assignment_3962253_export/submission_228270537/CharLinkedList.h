/*
 *  CharLinkedList.h
 *  YOUR NAME HERE
 *  DATE CREATED
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Purpose: Define the CharLinkedList class type that will be implemented in a
 *  separate file. CharLinkedList is a class that represents an ordered, 
 *  dynamic list of characters(including alphabets, numbers, and whitespace).
 *  Clients can create CharLinkedList that is emptry, stored one character, or 
 *  stores multiple characters. Then, Clients can add or remove characters
 *  from the list. Clients can also copy a list or concatenate two lists.
 */

#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H
#include <string>
#include <stdexcept> //for throwing an exception error message


class CharLinkedList {
    public:
        CharLinkedList();
        CharLinkedList(char c);
        CharLinkedList(char arr[], int size);
        CharLinkedList(const CharLinkedList &other);

        ~CharLinkedList();

        CharLinkedList &operator=(const CharLinkedList &other);

        bool isEmpty() const;
        void clear();
        int size() const;
        char first() const;
        char last() const;
        char elementAt(int index) const;
        std::string toString() const;
        std::string toReverseString() const;
        void pushAtBack(char c);
        void pushAtFront(char c);
        void insertAt(char c, int index);
        void insertInOrder(char c);
        void popFromFront();
        void popFromBack();
        void removeAt(int index);
        void replaceAt(char c, int index);
        void concatenate(CharLinkedList *other);

    private:
        struct Node {
            char      element;
            Node       *prev;
            Node       *next;

            //Node constructor. It initializes the values.
            Node(char c) {
                element = c;
                prev = nullptr;
                next = nullptr;
            }
        };

        Node *start; //a pointer that points to the first element
        Node *end; //a pointer that points to the last element
        int   SIZE;

        //helper functions
        void deleteNodes(struct Node *curr_node);
        char getElement(struct Node *curr_node, int index) const;
        void insertNodeinFront(struct Node *curr, struct Node *new_one);
        void replaceNode(struct Node *curr_node, struct Node *new_node,
                        int index);
};

#endif

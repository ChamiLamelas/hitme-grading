/*
 *  CharLinkedList.cpp
 *  Betty Park
 *  2/1/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Purpose: This file contains an implementation of the CharLinkedList class.
 *
 */

#include "CharLinkedList.h"

/*
 * CharLinkedList
 * purpose: Construct an empty CharLinkedList
 */
CharLinkedList::CharLinkedList() {
    start = nullptr;
    end = nullptr;
    SIZE = 0;
}

/*
 * CharLinkedList
 * purpose: Construct a CharLinkedList with size of 1, storing one character
 * arguments: A character to store in the list
 */
CharLinkedList::CharLinkedList(char c) {
    Node *new_node = new Node(c);

    start = new_node;
    end = new_node;
    SIZE = 1;
}

/*
 * CharLinkedList
 * purpose: Construct a CharLinkedList that stores the given characters with 
 *            the according size. 
 * arguments: An array of characters to store in the list, and its size
 */
CharLinkedList::CharLinkedList(char arr[], int size) {
    start = nullptr;
    end = nullptr;
    SIZE = 0;
    for (int i = 0; i < size; i++) {
        pushAtBack(arr[i]);
    }
}

/*
 * CharLinkedList (Copy constructor)
 * purpose: Construct a CharLinkedList by copying the given CharLinkedList
 * arguments: Address to the CharLinkedList to copy from
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other) {
    start = nullptr;
    end = nullptr;
    SIZE = 0;
    /* create a pointer to hold the elements of the other list */
    Node *original_node = other.start;
    for (int i = 0; i < other.size(); i++) {
        pushAtBack(original_node->element);
        /* move on to the next element of the other list */
        original_node = original_node->next;
    }
}

/*
 * name:      ~CharLinkedList (Destructor)
 * purpose:   Delete all heap-allocated data in the current linked list
 */
CharLinkedList::~CharLinkedList() {
    deleteNodes(start);
}

/*
 * name:      operator= 
 * purpose:   Delete the data in the CharLinkedList given on left of the 
 *            operator, and copies the CharLinkedList on the right into the
 *            left one.
 * arguments: Address to the CharLinkedList to copy from
 * returns:   Pointer to the CharLinkedList on the left with copied data
 */
CharLinkedList& CharLinkedList::operator=(const CharLinkedList &other) {
    if (this != &other) {
        /* delete the current list if it's already pointing to a heap-allocated
        list */
        if (SIZE > 0) {
            deleteNodes(start);
        }
        start = nullptr;
        end = nullptr;
        SIZE = 0;
        /* create a pointer to hold the elements of the other list */
        Node *original_node = other.start;
        for (int i = 0; i < other.size(); i++) {
            pushAtBack(original_node->element);
            /* move on to the next element of the other list */
            original_node = original_node->next;
        }
    }
    return *this;
}

/*
 * isEmpty
 * purpose: Check if the list is empty
 * return: Boolean value that is true if the class is empty, flase otherwise
 */
bool CharLinkedList::isEmpty() const {
    return (SIZE == 0 and start == nullptr);
}

/*
 * clear
 * purpose: Make the list to an empty list
 */
void CharLinkedList::clear() {
    deleteNodes(start);
    start = nullptr;
    end = nullptr;
    SIZE = 0;
}

/*
 * size
 * purpose: Return the size of the list
 * return: Integer value of the size of the list
 */
int CharLinkedList::size() const {
    return SIZE;
}

/*
 * first
 * purpose: Return the first element of the list
 * return: Char value of the first element
 * effects: Raises an error if the function is called for an empty list
 */
char CharLinkedList::first() const {
    if (isEmpty()) {
        throw std::runtime_error("cannot get first of empty LinkedList");
    }
    return start->element;
}

/*
 * last
 * purpose: Return the last element of the list
 * return: Char value of the last element
 * effects: Raises an error if the function is called for an empty list
 */
char CharLinkedList::last() const {
    if (isEmpty()) {
        throw std::runtime_error("cannot get last of empty LinkedList");
    }
    return end->element;
}

/*
 * elementAt
 * purpose: Return the element at the specified index
 * arguments: Integer value of the index
 * return: Char value of the element
 * effects: Raises an error if the index is out of the range of the list
 */
char CharLinkedList::elementAt(int index) const {
    if (index < 0 or index > SIZE - 1) {
        throw std::range_error("index (" + std::to_string(index) + 
        ") not in range [0.." + std::to_string(SIZE) + ")");
    } 
    return getElement(start, index);
}

/*
 * toString
 * purpose: Return a string that contains the characters in the list in order
 * return: A string that contains the characters in the list array and the
 *         size of the array 
 */
std::string CharLinkedList::toString() const {
    std::string word;
    std::string output;

    //start from the front
    Node *curr_node = start;
    //run a while loop until it reaches the end
    while (curr_node != nullptr) {
        word += curr_node->element;
        curr_node = curr_node->next;
    }

    output = "[CharLinkedList of size " + std::to_string(SIZE) + " <<" + word + 
    ">>]";
    return output;
}

/*
 * toReverseString
 * purpose: Return a string that contains the characters in the list in 
 *          reversed order
 * return: A string that contains the characters in the list array and the
 *         size of the array 
 */
std::string CharLinkedList::toReverseString() const {
    std::string word;
    std::string output;

    //start from the back
    Node *curr_node = end; 
    //run a while loop until it reaches the start
    while (curr_node != nullptr) {
        word += curr_node->element;
        curr_node = curr_node->prev;
    }

    output = "[CharLinkedList of size " + std::to_string(SIZE) + " <<" + word + 
    ">>]";
    return output;
}

/*
 * pushAtBack
 * purpose: Insert the given new element after the end of the existing elements 
 *          of the list
 * arguments: Char value to insert
 */
void CharLinkedList::pushAtBack(char c) {
    Node *new_node = new Node(c);
    //if it's an empty list, reassign the start and end pointers
    if (start == nullptr) {
        start = new_node;
        end = new_node;
    } else {
        //otherwise, reassign only the end pointer
        end->next = new_node;
        new_node->prev = end;
        end = new_node;
    }
    SIZE++;
}

/*
 * pushAtFront
 * purpose: Insert the given new element in front of the existing elements 
 *          of the list
 * arguments: Char value to insert
 */
void CharLinkedList::pushAtFront(char c) {
    Node *new_node = new Node(c);
    //if it's an empty list, reassign the start and end pointers
    if (start == nullptr) {
        start = new_node;
        end = new_node;
    } else {
        //otherwise, reassign only the start pointer
        start->prev = new_node;
        new_node->next = start;
        start = new_node;
    }
    SIZE++;
}

/*
 * insertAt
 * purpose: Insert new element at the specified index
 * arguments: Char value to insert and integer value of the index
 * effects: Raises an error if the index is out of range of the list
 */
void CharLinkedList::insertAt(char c, int index) {
    if (index < 0 or index > SIZE) {
        throw std::range_error("index (" + std::to_string(index) + 
        ") not in range [0.." + std::to_string(SIZE) + "]");
    } 

    if (index == 0) {
        pushAtFront(c);
    } else if (index == SIZE) {
        pushAtBack(c);
    } else {
        Node *new_node = new Node(c);
        Node *curr_node = start;

        //find the index
        for (int i = 0; i < index; i++) {
            curr_node = curr_node->next;
        }
        insertNodeinFront(curr_node, new_node);

        //increment size after inserting a node
        SIZE++;
    }
}

/*
 * insertInOrder
 * purpose: Insert new element into the list in ASCII order
 * arguments: Char value to insert
 */
void CharLinkedList::insertInOrder(char c) {
    int original_size = SIZE;
    Node *curr_node = start;

    for (int i = 0; i < original_size + 1; i++) {

        //find the index of correct order
        if (i < SIZE and curr_node->element >= c) {
            Node *new_node = new Node(c);
            insertNodeinFront(curr_node, new_node);
            SIZE++;

            //if the index was the 0, reassign the start node
            if (i == 0) start = new_node;

            //terminate the loop
            i = SIZE + 1;
        }
        //if it couldn't find a correct order within the list, add it to back
        //ohterwise, move on to the next node for the index-finding loop
        if (i == original_size) pushAtBack(c); 
        else curr_node = curr_node->next;
    } 
}

/*
 * popFromFront
 * purpose: Remove the first element of the list
 * effects: Raises an error if the function is called for an empty list
 */
void CharLinkedList::popFromFront() {
    if (isEmpty()) {
        throw std::runtime_error("cannot pop from empty LinkedList");
    }
    //if it's not a single element list,
    if (start->next != nullptr) {
        //create a pointer to hold the second element
        Node *next_node = start->next;
        next_node->prev = nullptr;
        delete start;

        start = next_node;
    } else {
        //if it's a single element list, just delete the one
        delete start;
        start = nullptr;
        end = nullptr;
    }
    SIZE--;
}

/*
 * popFromBack
 * purpose: Remove the last element of the list
 * effects: Raises an error if the function is called for an empty list
 */
void CharLinkedList::popFromBack() {
    if (isEmpty()) {
        throw std::runtime_error("cannot pop from empty LinkedList");
    }
    
    //if it's not a single element list,
    if (end->prev != nullptr) {
        //create a pointer to hold the second last element
        Node *prev_node = end->prev;
        prev_node->next = nullptr;
        delete end;

        //reassign the end node
        end = prev_node;
    } else {
        //if it's a signle element list, just delete the one
        delete end;
        end = nullptr;
        start = nullptr;
    }
    SIZE--;
}

/*
 * removeAt
 * purpose: Remove the element at the specified index
 * arguments: Integer value of the index
 * effects: Raises an error if the index is out of range of the list
 */
void CharLinkedList::removeAt(int index) {
    if (index < 0 or index > SIZE - 1) {
        throw std::range_error("index (" + std::to_string(index) + 
        ") not in range [0.." + std::to_string(SIZE) + ")");
    } 

    Node *curr_node = start;
    //find the index
    for (int i = 0; i < index; i++) {
        curr_node = curr_node->next;
    }
    //if the index is 0, remove the first element
    if (curr_node == start) {
        popFromFront();
    } else if (curr_node == end) {
        //if the index is SIZE - 1, remove the last element
        popFromBack();
    } else {
        //otherwise, reassign the links of the previous node and the next node
        Node *prev_node = curr_node->prev;
        Node *next_node = curr_node->next;
        prev_node->next = next_node;
        next_node->prev = prev_node;

        //then delete the node at the index
        delete curr_node;
        SIZE--;
    }
}

/*
 * replaceAt
 * purpose: Replace the element at the specified index with the new element
 * arguments: Char value to insert and integer value of the index
 * effects: Raises an error if the index is out of range of the list
 */
void CharLinkedList::replaceAt(char c, int index) {
    if (index < 0 or index > SIZE - 1) {
        throw std::range_error("index (" + std::to_string(index) + 
        ") not in range [0.." + std::to_string(SIZE) + ")");
    } 
  
    Node *new_node = new Node(c);
    replaceNode(start, new_node, index);

    //reassign start or end pointer if necessary
    if (index == 0) {
        start = new_node;
    } else if (index == SIZE - 1) {
        end = new_node;
    }
}

/*
 * concatenate
 * purpose: Add a copy of the list pointed to by the parameter value to the 
            end of the list the function was called from
 * arguments: Address to the CharLinkedList to copy from
 */
void CharLinkedList::concatenate(CharLinkedList *other) {
    Node *original_node = other->start;
    Node *curr_node = end;
    for (int i = 0; i < other->size(); i++) {
        //when the left list is empty, start from inserting the first element 
        if (isEmpty()) {
            pushAtBack(original_node->element);
            original_node = original_node->next;
            curr_node = end;
        } else {
            //make a copy of the original node
            Node *adding_node = new Node(original_node->element);
            //connect it with the last node of the left list
            curr_node->next = adding_node;
            adding_node->prev = curr_node;

            //move on to the next node for the loop
            curr_node = curr_node->next;
            original_node = original_node->next;

            //if it's the last node to copy from, mark it as the end node
            if (i == other->size() - 1) {
                end = curr_node;
            }
            //increment size as we add on copied nodes
            SIZE++;
        }
    }
}

/*
 * getElement
 * purpose: Get the element at the specified index in a recursive function
 * arguments: A pointer to the node that we will start the inspection from and
 *            the index number
 * return: A char value of the element
 */
char CharLinkedList::getElement(struct Node *curr_node, int index) const {
    /* Return the element in the current node when the index hit 0 */
    if (index == 0) {
        return curr_node->element;
    }
    /* Call the recursive function with index - 1, so we can find the 
    index-th element */
    return getElement(curr_node->next, index - 1);
}

/*
 * replaceNode
 * purpose: Replace the Node at the specified index with a new Node in a 
 *          recursive fuction
 * arguments: A pointer to the node that we will start the inspection from, the
 *            new Node to insert, and the index number
 */
void CharLinkedList::replaceNode(struct Node *curr_node, struct Node *new_node,
                                int index) {
    /* Operate function if index hit 0 */
    if (index == 0) {
        /* If current node has a next node, reassign the pointer values of the
        next node */
        if (curr_node->next != nullptr) {
            Node *next_node = curr_node->next;
            next_node->prev = new_node;
            new_node->next = next_node;
        }
        /* If current node has a previous node, reassign the pointer values of 
        the previous node */
        if (curr_node->prev != nullptr) {
            Node *prev_node = curr_node->prev;
            prev_node->next = new_node;
            new_node->prev = prev_node;
        }
        delete curr_node;
    } else {
        /* Call the recursive function with index - 1, so we can find the 
        index-th element */
        replaceNode(curr_node->next, new_node, index - 1);
    }
}

/*
 * deleteNodes
 * purpose: Delete the heap-allocated nodes in a recursive function 
 * arguments: A pointer to the node that we will start the function from
 */
void CharLinkedList::deleteNodes(struct Node *curr_node) {
    /* When it's the end node, return */
    if (curr_node == nullptr) {
        return;
    } 
    /* Call the recursive function with the pointer to the next node */
    deleteNodes(curr_node->next);
    delete curr_node;
}

/*
 * insertNodeinFront
 * purpose: Insert a new Node in front of the specified Node
 * arguments: A pointer to a Node and a pointer to a new Node to insert in 
 *            front of it
 */
void CharLinkedList::insertNodeinFront(struct Node *curr, struct Node *new_one) 
{
    //If the current node has a previous node, reassign the pointer values
    //of the previous node
    if (curr->prev != nullptr) {
        //Create a pointer to hold the previous node
        Node *prev_node = curr->prev;
        prev_node->next = new_one;
        new_one->prev = prev_node;
    } 
    new_one->next = curr;
    curr->prev = new_one;
}


/*
 *  unit_tests.h
 *  Betty Park
 *  2/1/24
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  Pupose: Unit tests for CharLinkedList.cpp functions are implemented here.
 *
 */

#include "CharLinkedList.h"
#include <cassert>

void dummy() {
    2+2;
}

/* <<Constructors>> */

void constructor_test() {
    //Empty constructor
    CharLinkedList emptyone;
    assert(emptyone.size() == 0);

    //One letter constructor
    CharLinkedList tester('a');
    assert(tester.first() == 'a');
    assert(tester.last() == 'a');

    //Array constructor
    char list[5] = {'a', 'p', 'p', 'l', 'e'};
    CharLinkedList tester2(list, 5);
    assert(tester2.first() == 'a');
    assert(tester2.last() == 'e');
}

/* <<isEmpty()>> */

void isempty_test() {
    CharLinkedList tester;
    assert(tester.isEmpty());

    CharLinkedList tester2('a');
    assert(not tester2.isEmpty());
}

/* <<clear()>> */

void clear_biglist() {
    char list[5] = {'a', 'p', 'p', 'l', 'e'};
    CharLinkedList tester(list, 5);
    tester.clear();
    assert(tester.isEmpty());
}

void clear_smallist() {
    CharLinkedList tester('a');
    tester.clear();
    assert(tester.isEmpty());
}

void clear_empty() {
    CharLinkedList emptyone;
    emptyone.clear();
    assert(emptyone.isEmpty());
}

/* <<first & last()>> */

void first_test() {
    CharLinkedList tester('a');
    char list[6] = {'b', 'a', 'n', 'a', 'n', 'a'};
    CharLinkedList tester2(list, 6);

    assert(tester.first() == 'a');
    assert(tester2.first() == 'b');
}

void first_empty_error() {
    CharLinkedList tester;

    bool rt_error_thrown = false;
    std::string error_message = "";
    try {
        tester.first();
    }
    catch (const std::runtime_error &e) {
    rt_error_thrown = true;
    error_message = e.what();
    }

    assert(rt_error_thrown);
    assert(error_message ==  "cannot get first of empty LinkedList");
}

void last_test() {
    CharLinkedList tester('a');

    assert(tester.last() == 'a');

    char list[3] = {'r', 'u', 'n'};
    CharLinkedList tester2(list, 3);
    assert(tester2.last() == 'n');
}

void last_empty_error() {
    CharLinkedList tester;

    bool rt_error_thrown = false;
    std::string error_message = "";
    try {
        tester.last();
    }
    catch (const std::runtime_error &e) {
    rt_error_thrown = true;
    error_message = e.what();
    }

    assert(rt_error_thrown);
    assert(error_message ==  "cannot get last of empty LinkedList");
}

/* <<elementat()>> */

void elementat_smalllist() {
    CharLinkedList tester('a');
    assert(tester.elementAt(0) == 'a');
}

void elementat_biglist() {
    char test_arr[5] = {'a', 'p', 'p', 'l', 'e'};
    CharLinkedList test_list(test_arr, 5);

    assert(test_list.elementAt(2) == 'p');
    assert(test_list.elementAt(3) == 'l');
}

void elementat_outofrange() {
    char test_arr[5] = {'a', 'p', 'p', 'l', 'e'};
    CharLinkedList test_list(test_arr, 5);

    bool range_error_thrown = false;
    std::string error_message = "";

    try {
    test_list.elementAt(5);
    }
    catch (const std::range_error &e) {
    range_error_thrown = true;
    error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message ==  "index (5) not in range [0..5)");
}

void elementat_emptylist() {
    CharLinkedList emptyarray;

    bool range_error_thrown = false;
    std::string error_message = "";

    try {
    emptyarray.elementAt(3);
    }
    catch (const std::range_error &e) {
    range_error_thrown = true;
    error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message ==  "index (3) not in range [0..0)");
}

/* <<toString & toReverseString()>> */

void strings_basic_test() {
    char test_arr[5] = {'a', 'p', 'p', 'l', 'e'};
    CharLinkedList test_list(test_arr, 5);
    assert(test_list.toString() ==     "[CharLinkedList of size 5 <<apple>>]");
    assert(test_list.toReverseString()=="[CharLinkedList of size 5 <<elppa>>]");
}

void strings_emptyarray() {
    CharLinkedList emptyone;

    assert(emptyone.toString() == "[CharLinkedList of size 0 <<>>]");
    assert(emptyone.toReverseString() == "[CharLinkedList of size 0 <<>>]");
}

/* <<pushAtBack() & pushAtFront()>> */

void pushatBack_and_Front_bigarray() {
    char list[5] = {'a', 'p', 'p', 'l', 'e'};
    CharLinkedList tester(list, 5);

    tester.pushAtFront('b');
    tester.pushAtFront('q');
    tester.pushAtBack('y');
    assert(tester.toString() == "[CharLinkedList of size 8 <<qbappley>>]");
}

void pushatBack_and_Front_emptyarray() {
    CharLinkedList emptyone;

    emptyone.pushAtBack('I');
    emptyone.pushAtFront('H');
    assert(emptyone.toString() == "[CharLinkedList of size 2 <<HI>>]");
}

/* <<insertAt()>> */

void insertat_biglist() {
    char list[5] = {'a', 'p', 'p', 'l', 'e'};
    CharLinkedList tester(list, 5);

    tester.insertAt('h', 1);
    tester.insertAt('i', 2);
    assert(tester.toString() == "[CharLinkedList of size 7 <<ahipple>>]");
}

void insertat_back() {
    char list[5] = {'a', 'p', 'p', 'l', 'e'};
    CharLinkedList tester(list, 5);

    tester.insertAt('y', 5);
    assert(tester.toString() == "[CharLinkedList of size 6 <<appley>>]");
}

void insertat_front() {
    char list[5] = {'a', 'p', 'p', 'l', 'e'};
    CharLinkedList tester(list, 5);

    tester.insertAt('y', 0);
    assert(tester.toString() == "[CharLinkedList of size 6 <<yapple>>]");
}

void insertat_empty_correct() { 

    CharLinkedList test_list;
    test_list.insertAt('a', 0);
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');

}

void insertAt_empty_incorrect() {

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
    // insertAt for out-of-range index
    test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
    // if insertAt is correctly implemented, a range_error will be thrown,
    // and we will end up here
    range_error_thrown = true;
    error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0]");
    
}

/* <<insertInOrder()>> */
void InOrder_biglist() {
    char test_arr[5] = {'a', 'p', 'p', 'l', 'e'};
    CharLinkedList test_list(test_arr, 5);

    test_list.insertInOrder('b');
    assert(test_list.toString() == "[CharLinkedList of size 6 <<abpple>>]");
    test_list.insertInOrder('f');
    assert(test_list.toString() == "[CharLinkedList of size 7 <<abfpple>>]");
    
    //inserting a letter that is last in order
    test_list.insertInOrder('q');
    assert(test_list.toString() == "[CharLinkedList of size 8 <<abfppleq>>]");
    //inserting a letter with the same ascii value
    test_list.insertInOrder('a');
    assert(test_list.toString() == "[CharLinkedList of size 9 <<aabfppleq>>]");
}

void InOrder_emptylist_noerror() {
    CharLinkedList emptyone;

    emptyone.insertInOrder('e');
    assert(emptyone.toString() == "[CharLinkedList of size 1 <<e>>]");
}

/* <<popFromFront() & popFromBack()>> */

void popBack_and_Front_small_list() {
    CharLinkedList tester1('a');
    CharLinkedList tester2('b');
    
    tester1.popFromBack();
    tester2.popFromFront();

    assert(tester1.isEmpty());
    assert(tester2.isEmpty());
}

void popBack_and_Front_biglist() {
    char test_arr[5] = {'a', 'p', 'p', 'l', 'e'};
    CharLinkedList test_list(test_arr, 5);

    test_list.popFromBack();
    assert(test_list.toString() ==     "[CharLinkedList of size 4 <<appl>>]");
    test_list.popFromFront();
    assert(test_list.toString() ==     "[CharLinkedList of size 3 <<ppl>>]");
}

void popBack_emptylist() {
    CharLinkedList emptyone;

    bool rt_error_thrown = false;
    std::string error_message = "";
    try {
    emptyone.popFromBack();
    }
    catch (const std::runtime_error &e) {
    rt_error_thrown = true;
    error_message = e.what();
    }

    assert(rt_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

void popFront_emptylist() {
    CharLinkedList emptyone;

    bool rt_error_thrown = false;
    std::string error_message = "";
    try {
    emptyone.popFromFront();
    }
    catch (const std::runtime_error &e) {
    rt_error_thrown = true;
    error_message = e.what();
    }

    assert(rt_error_thrown);
    assert(error_message == "cannot pop from empty LinkedList");
}

/* <<removeAt()>> */

void removeat_small_list() {
    CharLinkedList tester('a');
    tester.removeAt(0);
    assert(tester.isEmpty());
}

void removeat_biglist() {
    char test_arr[5] = {'a', 'p', 'p', 'l', 'e'};
    CharLinkedList test_list(test_arr, 5);

    test_list.removeAt(2);
    assert(test_list.toString() == "[CharLinkedList of size 4 <<aple>>]");
}

void removeat_outofrange() {
    char test_arr[5] = {'a', 'p', 'p', 'l', 'e'};
    CharLinkedList test_list(test_arr, 5);

    bool range_error_thrown = false;
    std::string error_message = "";

    try {
    test_list.removeAt(5);
    }
    catch (const std::range_error &e) {
    range_error_thrown = true;
    error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message ==  "index (5) not in range [0..5)");
}

void removeat_emptylist() {
    CharLinkedList emptylist;

    bool range_error_thrown = false;
    std::string error_message = "";

    try {
    emptylist.removeAt(3);
    }
    catch (const std::range_error &e) {
    range_error_thrown = true;
    error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message ==  "index (3) not in range [0..0)");
}

/* <<replaceAt()>> */

void replaceat_small_list() {
    CharLinkedList tester1('a');
    
    tester1.replaceAt('b', 0);
    assert(tester1.toString() == "[CharLinkedList of size 1 <<b>>]");
}

void replaceat_biglist() {
    char test_arr[5] = {'a', 'p', 'p', 'l', 'e'};
    CharLinkedList tester2(test_arr, 5);

    tester2.replaceAt('k', 3);
    assert(tester2.toString() == "[CharLinkedList of size 5 <<appke>>]");

    tester2.replaceAt('t', 4);
    assert(tester2.toString() == "[CharLinkedList of size 5 <<appkt>>]");

    tester2.replaceAt('u', 0);
    assert(tester2.toString() == "[CharLinkedList of size 5 <<uppkt>>]");

    assert(tester2.first() == 'u');
    assert(tester2.last() == 't');
}

/* <<Copy Constructor>> */

void copy_constructor_basic_test() {
    char test_arr[5] = {'a', 'p', 'p', 'l', 'e'};
    CharLinkedList test_list(test_arr, 5);
    CharLinkedList copy_list(test_list); 
    assert(test_list.toString() == "[CharLinkedList of size 5 <<apple>>]");
    assert(copy_list.toString() == "[CharLinkedList of size 5 <<apple>>]");
}

void copy_constructor_emptylist() {
    CharLinkedList test_list;
    CharLinkedList copy_list(test_list);

    assert(copy_list.isEmpty());
}

/* <<concatenate()>> */

void concatenate_basic_and_withempty() {
    char list[5] = {'a', 'p', 'p', 'l', 'e'};
    CharLinkedList tester(list, 5);

    char list2[5] = {'j','u','i','c','e'};
    CharLinkedList tester2(list2, 5);

    tester.concatenate(&tester2);
    assert(tester.toString() == "[CharLinkedList of size 10 <<applejuice>>]");
    assert(tester.first() == 'a');
    assert(tester.last() == 'e');

    CharLinkedList emptyone;

    emptyone.concatenate(&tester2);
    assert(emptyone.toString() == "[CharLinkedList of size 5 <<juice>>]");

    CharLinkedList copied(tester2);
    assert(copied.toString() == "[CharLinkedList of size 5 <<juice>>]");

    tester2 = tester;
    assert(tester2.toString() == "[CharLinkedList of size 10 <<applejuice>>]");
}

void concatenate_both_empty() {
    CharLinkedList tester;
    CharLinkedList tester2;
    tester.concatenate(&tester2);
    assert(tester.toString() == "[CharLinkedList of size 0 <<>>]");

    tester.concatenate(&tester);
    assert(tester.toString() == "[CharLinkedList of size 0 <<>>]");
}

/* <<=operator>> */

void operator_basic_test() {
    char test_arr[5] = {'a', 'p', 'p', 'l', 'e'};
    CharLinkedList test_list(test_arr, 5);
    char test_arr2[6] = {'c', 'h', 'e', 'r', 'r', 'y'};
    CharLinkedList test_list2(test_arr2, 6);

    test_list2 = test_list;
    assert(test_list.toString() ==     "[CharLinkedList of size 5 <<apple>>]");
    assert(test_list2.toString() ==   "[CharLinkedList of size 5 <<apple>>]");
}

void operator_emptyarray() {
    char test_arr[5] = {'a', 'p', 'p', 'l', 'e'};
    CharLinkedList test_list(test_arr, 5);

    CharLinkedList emptyone;

    test_list = emptyone;
    assert(test_list.isEmpty());
}
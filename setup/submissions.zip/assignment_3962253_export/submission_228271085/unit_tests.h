/**
 * unit_tests.h
 * Kyle Wigdor
 * Feb. 3, 2024
 *
 * CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 * Unit tests for the `CharLinkedList` class.
 *
 * These tests were taken from the `CharArrayList` homework assignment and
 * modified to instead test the `CharLinkedList` class. The original file
 * was written by Tyler Calabrese and modified by Milod Kazerounian.
 *
 */
#include "CharLinkedList.h";
#include <cassert>

void constructor_empty_test() {
    CharLinkedList list;
    assert(list.isEmpty());
    assert(list.size() == 0);
}

void constructor_char_test() {
    CharLinkedList list('a');
    assert(not list.isEmpty());
    assert(list.size() == 1);
    assert(list.first() == 'a');
    assert(list.last() == 'a');
}

void constructor_array_test() {
    char arr[7] = {'a', 'b', 'c', 'd', 'e', 'f', 'g'};
    CharLinkedList list(arr, 7);

    for (int i = 0; i < 7; i++) {
        assert(list.elementAt(i) == arr[i]);
    }

    assert(list.first() == 'a');
    assert(list.last() == 'g');
}

void constructor_array_one_test() {
    char arr[1] = {'a'};
    CharLinkedList list(arr, 1);

    assert(list.elementAt(0) == 'a');
    assert(list.first() == 'a');
    assert(list.last() == 'a');
}

void constructor_empty_array_test() {
    char arr[0];
    CharLinkedList list(arr, 0);

    assert(list.isEmpty());
}

void constructor_copy_test() {
    char arr[7] = {'a', 'b', 'c', 'd', 'e', 'f', 'g'};
    CharLinkedList list(arr, 7);

    CharLinkedList copy(list);

    assert(copy.size() == list.size());
    for (int i = 0; i < 7; i++) {
        assert(list.elementAt(i) == copy.elementAt(i));
    }
}

void constructor_copy_one_test() {
    CharLinkedList list('c');
    CharLinkedList copy(list);

    assert(copy.size() == list.size());
    assert(list.elementAt(0) == copy.elementAt(0));
    assert(list.first() == copy.first());
    assert(list.last() == copy.last());
}

void constructor_copy_empty_test() {
    CharLinkedList list;
    CharLinkedList copy(list);

    assert(copy.isEmpty());
}

void assignment_test() {
    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(arr, 5);

    CharLinkedList copy;

    // this should be the same as `copy`.
    CharLinkedList result = (copy = list);

    assert(copy.size() == list.size());
    for (int i = 0; i < 5; i++) {
        assert(list.elementAt(i) == copy.elementAt(i));
    }

    assert(result.size() == list.size());
    for (int i = 0; i < 5; i++) {
        assert(list.elementAt(i) == result.elementAt(i));
    }
}

// Make sure that if the variable that it is assigned to already has an
// allocated elements, that it is deallocated before the assignment.
void assignemnt_does_not_leak_test() {
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList list(arr, 3);
    CharLinkedList copy(arr, 3);

    copy = list;

    assert(copy.size() == list.size());
    for (int i = 0; i < 3; i++) {
        assert(list.elementAt(i) == copy.elementAt(i));
    }
}

void assignment_one_test() {
    CharLinkedList list('c');
    CharLinkedList copy;

    copy = list;

    assert(copy.size() == list.size());
    assert(list.elementAt(0) == copy.elementAt(0));
    assert(list.first() == copy.first());
    assert(list.last() == copy.last());
}

// ensure that assignment works even when both have `nullptr` for data.
void assignment_empty_test() {
    CharLinkedList list;
    CharLinkedList copy;

    copy = list;

    assert(copy.isEmpty());
}

void size_test() {
    for (int i = 0; i < 1000; i++) {
        char arr[i];
        CharLinkedList list(arr, i);

        assert(list.size() == i);
    }
}

void isEmpty_test() {
    for (int i = 0; i < 1000; i++) {
        char arr[i];
        CharLinkedList list(arr, i);

        assert(list.isEmpty() == (i == 0));
    }
}

void clear_test() {
    for (int i = 0; i < 1000; i++) {
        char arr[i];
        CharLinkedList list(arr, i);
        list.clear();

        assert(list.size() == 0);
        assert(list.isEmpty());
    }
}

void clear_one_test() {
    CharLinkedList list('c');
    list.clear();

    assert(list.isEmpty());
}

void clear_many_test() {
    char arr[7] = {'a', 'b', 'c', 'd', 'e', 'f', 'g'};
    CharLinkedList list(arr, 7);
    list.clear();

    assert(list.isEmpty());
}

// Test that the copy is not affected by the original list being cleared
void clear_copy_test() {
    char arr[7] = {'a', 'b', 'c', 'd', 'e', 'f', 'g'};
    CharLinkedList list(arr, 7);
    CharLinkedList copy(list);
    list.clear();

    assert(list.isEmpty());
    assert(copy.size() == 7);
    for (int i = 0; i < 7; i++) {
        assert(copy.elementAt(i) == arr[i]);
    }
}

void clear_empty_test() {
    CharLinkedList list;
    list.clear();

    assert(list.isEmpty());
}

void first_array_test() {
    char arr[7] = {'a', 'b', 'c', 'd', 'e', 'f', 'g'};
    CharLinkedList list2(arr, 7);
    assert(list2.first() == 'a');
}

void first_copy_test() {
    char arr[7] = {'a', 'b', 'c', 'd', 'e', 'f', 'g'};
    CharLinkedList list(arr, 7);
    CharLinkedList copy(list);

    assert(copy.first() == 'a');
}

void first_one_test() {
    CharLinkedList list('c');
    assert(list.first() == 'c');
}

void first_empty_test() {
    CharLinkedList list;

    std::string error_message = "";

    try {
        list.first();
    } catch (const std::runtime_error &e) {
        error_message = e.what();
    }

    assert(error_message == "cannot get first of empty LinkedList");
}

void last_test() {

    char arr[7] = {'a', 'b', 'c', 'd', 'e', 'f', 'g'};
    CharLinkedList list2(arr, 7);
    assert(list2.last() == 'g');
}

void last_copy_test() {
    char arr[7] = {'a', 'b', 'c', 'd', 'e', 'f', 'g'};
    CharLinkedList list(arr, 7);
    CharLinkedList copy(list);

    assert(copy.last() == 'g');
}

void last_one_test() {
    CharLinkedList list('c');
    assert(list.last() == 'c');
}

void last_empty_test() {
    CharLinkedList list;

    std::string error_message = "";

    try {
        list.last();
    } catch (const std::runtime_error &e) {
        error_message = e.what();
    }

    assert(error_message == "cannot get last of empty LinkedList");
}

void elementAt_test() {
    char arr[7] = {'a', 'b', 'c', 'd', 'e', 'f', 'g'};
    CharLinkedList list(arr, 7);

    for (int i = 0; i < 7; i++) {
        assert(list.elementAt(i) == arr[i]);
    }
}

void elementAt_one_test() {
    CharLinkedList list('c');
    assert(list.elementAt(0) == 'c');
}

// ensures `elementAt` out-of-bounds checks are correct.
void elementAt_oob_test() {
    char arr[3] = {'a', 'b', 'c'};
    CharLinkedList list(arr, 3);

    std::string error_message = "";

    try {
        list.elementAt(-1);
    } catch (const std::range_error &e) {
        error_message = e.what();
    }

    assert(error_message == "index (-1) not in range [0..3)");

    try {
        list.elementAt(4);
    } catch (const std::range_error &e) {
        error_message = e.what();
    }

    assert(error_message == "index (4) not in range [0..3)");
}

void elementAt_empty_test() {
    CharLinkedList list;
    std::string error_message = "";

    try {
        list.elementAt(0);
    } catch (const std::range_error &e) {
        error_message = e.what();
    }

    assert(error_message == "index (0) not in range [0..0)");
}

void toString_test() {
    char arr[7] = {'a', 'b', 'c', 'd', 'e', 'f', 'g'};
    CharLinkedList list(arr, 7);
    assert(list.toString() == "[CharLinkedList of size 7 <<abcdefg>>]");
}

void toString_one_test() {
    CharLinkedList list('c');
    assert(list.toString() == "[CharLinkedList of size 1 <<c>>]");
}

void toString_empty_list() {
    CharLinkedList list;
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}

void toReverseString_test() {
    char arr[7] = {'a', 'b', 'c', 'd', 'e', 'f', 'g'};
    CharLinkedList list(arr, 7);
    assert(list.toReverseString() == "[CharLinkedList of size 7 <<gfedcba>>]");
}

void toReverseString_one_test() {
    CharLinkedList list('c');
    assert(list.toReverseString() == "[CharLinkedList of size 1 <<c>>]");
}

void toReverseString_empty_list() {
    CharLinkedList list;
    assert(list.toReverseString() == "[CharLinkedList of size 0 <<>>]");
}

void pushAtBack_test() {
    CharLinkedList list;
    list.pushAtBack('a');
    assert(list.size() == 1);
    assert(list.elementAt(0) == 'a');

    list.pushAtBack('b');
    assert(list.size() == 2);
    assert(list.elementAt(0) == 'a');
    assert(list.elementAt(1) == 'b');

    list.pushAtBack('c');
    assert(list.size() == 3);
    assert(list.elementAt(0) == 'a');
    assert(list.elementAt(1) == 'b');
    assert(list.elementAt(2) == 'c');
}

void pushAtBack_one_test() {
    CharLinkedList list('a');
    list.pushAtBack('b');
    assert(list.size() == 2);
    assert(list.elementAt(0) == 'a');
    assert(list.elementAt(1) == 'b');
}

// an iterative `pushAtBack` test that will check that every possible array
// between lenth 0..=1000 is able to be indexed properly.
void pushAtBackIter_test() {
    CharLinkedList list;
    for (int i = 0; i < 1000; i++) {
        list.pushAtBack(static_cast<char>((i % 26) + 'a'));
        assert(list.size() == i + 1);
        for (int j = 0; j <= i; j++) {
            assert(list.elementAt(j) == static_cast<char>((j % 26) + 'a'));
        }
    }
}

void pushAtFront_test() {
    CharLinkedList list;
    list.pushAtFront('a');
    assert(list.size() == 1);
    assert(list.elementAt(0) == 'a');

    list.pushAtFront('b');
    assert(list.size() == 2);
    assert(list.elementAt(0) == 'b');
    assert(list.elementAt(1) == 'a');

    list.pushAtFront('c');
    assert(list.size() == 3);
    assert(list.elementAt(0) == 'c');
    assert(list.elementAt(1) == 'b');
    assert(list.elementAt(2) == 'a');
}

// an iterative `pushAtFront` test that will check that every possible array
// between lenth 0..=1000 is able to be indexed properly.
void pushAtFrontIter_test() {
    CharLinkedList list;
    for (int i = 0; i < 1000; i++) {
        list.pushAtFront(static_cast<char>((i % 26) + 'a'));
        assert(list.size() == i + 1);
        for (int j = 0; j <= i; j++) {
            assert(list.elementAt(j) == static_cast<char>((i - j) % 26 + 'a'));
        }
    }
}

void pushAtFront_one_test() {
    CharLinkedList list('a');
    list.pushAtFront('b');
    assert(list.size() == 2);
    assert(list.elementAt(0) == 'b');
    assert(list.elementAt(1) == 'a');
}

void insertAt_test() {
    CharLinkedList list;
    list.insertAt('a', 0);
    assert(list.size() == 1);
    assert(list.elementAt(0) == 'a');

    list.insertAt('b', 0);
    assert(list.size() == 2);
    assert(list.elementAt(0) == 'b');
    assert(list.elementAt(1) == 'a');

    list.insertAt('c', 1);
    assert(list.size() == 3);
    assert(list.elementAt(0) == 'b');
    assert(list.elementAt(1) == 'c');
    assert(list.elementAt(2) == 'a');

    list.insertAt('d', 1);
    assert(list.size() == 4);
    assert(list.elementAt(0) == 'b');
    assert(list.elementAt(1) == 'd');
    assert(list.elementAt(2) == 'c');
    assert(list.elementAt(3) == 'a');

    list.insertAt('e', 2);
    assert(list.size() == 5);
    assert(list.elementAt(0) == 'b');
    assert(list.elementAt(1) == 'd');
    assert(list.elementAt(2) == 'e');
    assert(list.elementAt(3) == 'c');
    assert(list.elementAt(4) == 'a');

    list.insertAt('f', 4);
    assert(list.size() == 6);
    assert(list.elementAt(0) == 'b');
    assert(list.elementAt(1) == 'd');
    assert(list.elementAt(2) == 'e');
    assert(list.elementAt(3) == 'c');
    assert(list.elementAt(4) == 'f');
    assert(list.elementAt(5) == 'a');
}

// check that `insertAt` has accurate bounds checks.
void insertAt_throws_test() {
    char chars[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(chars, 5);

    std::string error_message = "";

    try {
        list.insertAt('a', 6);
    } catch (const std::range_error &e) {
        error_message = e.what();
    }

    assert(error_message == "index (6) not in range [0..5]");

    try {
        list.insertAt('a', -1);
    } catch (const std::range_error &e) {
        error_message = e.what();
    }

    assert(error_message == "index (-1) not in range [0..5]");
}

void insertAt_throws_empty_test() {
    CharLinkedList list;

    std::string error_message = "";

    try {
        list.insertAt('a', -1);
    } catch (const std::range_error &e) {
        error_message = e.what();
    }

    assert(error_message == "index (-1) not in range [0..0]");

    try {
        list.insertAt('a', 1);
    } catch (const std::range_error &e) {
        error_message = e.what();
    }

    assert(error_message == "index (1) not in range [0..0]");
}

void insertInOrder_match_test() {
    CharLinkedList list;

    list.pushAtBack('a');
    list.pushAtBack('b');
    list.pushAtBack('d');
    list.pushAtBack('e');
    list.pushAtBack('f');

    list.insertInOrder('c');

    assert(list.toString() == "[CharLinkedList of size 6 <<abcdef>>]");
}

void insertInOrder_iter_test() {
    CharLinkedList list;

    // insert every other letter in alphabet.
    for (int i = 0; i < 26; i += 2) {
        list.insertInOrder(static_cast<char>(i + 'a'));
    }

    // insert the rest of the letters, in order.
    for (int i = 1; i < 26; i += 2) {
        list.insertInOrder(static_cast<char>(i + 'a'));
    }

    assert(list.toString() ==
           "[CharLinkedList of size 26 <<abcdefghijklmnopqrstuvwxyz>>]");
}

void insertInOrder_opposite_test() {
    CharLinkedList list;

    // insert every other letter in alphabet.
    // starting at `b`.
    for (int i = 1; i < 26; i += 2) {
        list.insertInOrder(static_cast<char>(i + 'a'));
    }

    // insert the rest of the letters, in order.
    for (int i = 0; i < 26; i += 2) {
        list.insertInOrder(static_cast<char>(i + 'a'));
    }

    assert(list.toString() ==
           "[CharLinkedList of size 26 <<abcdefghijklmnopqrstuvwxyz>>]");
}

// ensure we can `insertInOrder` to an empty list.
void insertInOrder_0_test() {
    CharLinkedList list;

    list.insertInOrder('c');
    list.insertInOrder('a');
    list.insertInOrder('b');

    assert(list.toString() == "[CharLinkedList of size 3 <<abc>>]");
}

// ensure we can `insertInOrder` to the left and to the right od the current
// elements.
void insertInOrder_extremity_test() {
    char arr[3] = {'b', 'e', 'h'};
    CharLinkedList list(arr, 3);

    list.insertInOrder('i');
    assert(list.toString() == "[CharLinkedList of size 4 <<behi>>]");

    list.insertInOrder('a');
    assert(list.toString() == "[CharLinkedList of size 5 <<abehi>>]");

    list.insertInOrder('j');
    assert(list.toString() == "[CharLinkedList of size 6 <<abehij>>]");

    list.insertInOrder('z');
    assert(list.toString() == "[CharLinkedList of size 7 <<abehijz>>]");
}

void popFromFront_test() {
    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(arr, 5);

    list.popFromFront();
    assert(list.toString() == "[CharLinkedList of size 4 <<bcde>>]");

    list.popFromFront();
    assert(list.toString() == "[CharLinkedList of size 3 <<cde>>]");

    list.popFromFront();
    assert(list.toString() == "[CharLinkedList of size 2 <<de>>]");

    list.popFromFront();
    assert(list.toString() == "[CharLinkedList of size 1 <<e>>]");

    list.popFromFront();
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");

    std::string error_message = "";

    try {
        list.popFromFront();
    } catch (const std::runtime_error &e) {
        error_message = e.what();
    }

    assert(error_message == "cannot pop from empty LinkedList");
}

void popFromBack_test() {
    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(arr, 5);

    list.popFromBack();
    assert(list.toString() == "[CharLinkedList of size 4 <<abcd>>]");

    list.popFromBack();
    assert(list.toString() == "[CharLinkedList of size 3 <<abc>>]");

    list.popFromBack();
    assert(list.toString() == "[CharLinkedList of size 2 <<ab>>]");

    list.popFromBack();
    assert(list.toString() == "[CharLinkedList of size 1 <<a>>]");

    list.popFromBack();
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");

    std::string error_message = "";

    try {
        list.popFromBack();
    } catch (const std::runtime_error &e) {
        error_message = e.what();
    }

    assert(error_message == "cannot pop from empty LinkedList");
}

void removeAt_test() {
    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(arr, 5);

    list.removeAt(0);
    assert(list.toString() == "[CharLinkedList of size 4 <<bcde>>]");

    list.removeAt(3);
    assert(list.toString() == "[CharLinkedList of size 3 <<bcd>>]");

    list.removeAt(1);
    assert(list.toString() == "[CharLinkedList of size 2 <<bd>>]");

    list.removeAt(1);
    assert(list.toString() == "[CharLinkedList of size 1 <<b>>]");

    list.removeAt(0);
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}

// test `removeAt` works at the edges of the list.
void removeAt_edges_test() {
    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(arr, 5);

    list.removeAt(4);
    assert(list.toString() == "[CharLinkedList of size 4 <<abcd>>]");

    list.removeAt(0);
    assert(list.toString() == "[CharLinkedList of size 3 <<bcd>>]");

    list.removeAt(2);
    assert(list.toString() == "[CharLinkedList of size 2 <<bc>>]");

    list.removeAt(1);
    assert(list.toString() == "[CharLinkedList of size 1 <<b>>]");

    list.removeAt(0);
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}

// test `removeAt` works at the nodes next to the edges of the list.
void removeAt_semiedges_test() {
    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(arr, 5);

    list.removeAt(3);
    assert(list.toString() == "[CharLinkedList of size 4 <<abce>>]");

    list.removeAt(1);
    assert(list.toString() == "[CharLinkedList of size 3 <<ace>>]");

    list.removeAt(1);
    assert(list.toString() == "[CharLinkedList of size 2 <<ae>>]");
}

// ensure `removeAt` has the correct bounds checks.
void removeAt_oob_fail_test() {
    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(arr, 5);

    std::string error_message = "";
    try {
        list.removeAt(6);
    } catch (const std::range_error &e) {
        error_message = e.what();
    }

    assert(error_message == "index (6) not in range [0..5)");

    try {
        list.removeAt(-1);
    } catch (const std::range_error &e) {
        error_message = e.what();
    }
    assert(error_message == "index (-1) not in range [0..5)");

    list.clear();
    try {
        list.removeAt(0);
    } catch (const std::range_error &e) {
        error_message = e.what();
    }
    assert(error_message == "index (0) not in range [0..0)");
}

void replaceAt_test() {
    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(arr, 5);

    list.replaceAt('z', 4);
    assert(list.toString() == "[CharLinkedList of size 5 <<abcdz>>]");

    list.replaceAt('y', 3);
    assert(list.toString() == "[CharLinkedList of size 5 <<abcyz>>]");

    list.replaceAt('x', 2);
    assert(list.toString() == "[CharLinkedList of size 5 <<abxyz>>]");

    list.replaceAt('w', 1);
    assert(list.toString() == "[CharLinkedList of size 5 <<awxyz>>]");

    list.replaceAt('v', 0);
    assert(list.toString() == "[CharLinkedList of size 5 <<vwxyz>>]");
}

void replaceAt_edges_test() {
    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(arr, 5);

    list.replaceAt('x', 4);
    assert(list.toString() == "[CharLinkedList of size 5 <<abcdx>>]");

    list.replaceAt('y', 0);
    assert(list.toString() == "[CharLinkedList of size 5 <<ybcdx>>]");
}

void replaceAt_one_test() {
    CharLinkedList list('a');
    list.replaceAt('b', 0);
    assert(list.toString() == "[CharLinkedList of size 1 <<b>>]");
}

// ensure `replaceAt` has the correct bounds checks.
void replaceAt_oob_test() {
    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(arr, 5);

    std::string error_message = "";

    try {
        list.replaceAt('a', 5);
    } catch (const std::range_error &e) {
        error_message = e.what();
    }

    assert(error_message == "index (5) not in range [0..5)");

    try {
        list.replaceAt('a', -1);
    } catch (const std::range_error &e) {
        error_message = e.what();
    }

    assert(error_message == "index (-1) not in range [0..5)");

    list.clear();

    try {
        list.replaceAt('a', 0);
    } catch (const std::range_error &e) {
        error_message = e.what();
    }

    assert(error_message == "index (0) not in range [0..0)");
}

void concatenate_test() {
    char arr1[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list1(arr1, 5);

    char arr2[5] = {'f', 'g', 'h', 'i', 'j'};
    CharLinkedList list2(arr2, 5);

    list1.concatenate(&list2);
    assert(list1.toString() == "[CharLinkedList of size 10 <<abcdefghij>>]");

    CharLinkedList list3;

    list1.concatenate(&list3);
    assert(list1.toString() == "[CharLinkedList of size 10 <<abcdefghij>>]");

    list3.concatenate(&list2);
    assert(list3.toString() == "[CharLinkedList of size 5 <<fghij>>]");

    list1.concatenate(&list3);
    assert(list1.toString() ==
           "[CharLinkedList of size 15 <<abcdefghijfghij>>]");
}

void concatenate_one_to_one_test() {
    CharLinkedList list1('a');
    CharLinkedList list2('b');

    list1.concatenate(&list2);
    assert(list1.toString() == "[CharLinkedList of size 2 <<ab>>]");
}

void concatenate_many_to_one_test() {
    CharLinkedList list1('a');
    char arr[5] = {'b', 'c', 'd', 'e', 'f'};
    CharLinkedList list2(arr, 5);

    list1.concatenate(&list2);
    assert(list1.toString() == "[CharLinkedList of size 6 <<abcdef>>]");
}

void concatenate_one_to_many_test() {
    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list1(arr, 5);
    CharLinkedList list2('f');

    list1.concatenate(&list2);
    assert(list1.toString() == "[CharLinkedList of size 6 <<abcdef>>]");
}

void concatenate_empty_to_one_test() {
    CharLinkedList list1('a');
    CharLinkedList list2;

    list1.concatenate(&list2);
    assert(list1.toString() == "[CharLinkedList of size 1 <<a>>]");
}

void concatenate_one_to_empty_test() {
    CharLinkedList list1;
    CharLinkedList list2('a');

    list1.concatenate(&list2);
    assert(list1.toString() == "[CharLinkedList of size 1 <<a>>]");
}

// ensure we can concatenate a list to itself without infinitely looping.
void concatenate_self_test() {
    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(arr, 5);

    list.concatenate(&list);
    assert(list.toString() == "[CharLinkedList of size 10 <<abcdeabcde>>]");
}

/* insertAt tests */

// Tests correct insertion into an empty AL.
// Afterwards, size should be 1 and element at index 0
// should be the element we inserted.
void insertAt_empty_correct() {

    CharLinkedList test_list;
    test_list.insertAt('a', 0);
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');
}

// Tests incorrect insertion into an empty AL.
// Attempts to call insertAt for index larger than 0.
// This should result in an std::range_error being raised.
void insertAt_empty_incorrect() {

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
        // insertAt for out-of-range index
        test_list.insertAt('a', 42);
    } catch (const std::range_error &e) {
        // if insertAt is correctly implemented, a range_error will be thrown,
        // and we will end up here
        range_error_thrown = true;
        error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0]");
}

// Tests correct insertAt for front of 1-element list.
void insertAt_front_singleton_list() {

    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at front
    test_list.insertAt('b', 0);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'a');
}

// Tests correct insertAt for back of 1-element list.
void insertAt_back_singleton_list() {

    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at back
    test_list.insertAt('b', 1);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
}

// Tests calling insertAt for a large number of elements.
// Not only does this test insertAt, it also checks that
// array expansion works correctly.
void insertAt_many_elements() {

    CharLinkedList test_list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.insertAt('a', i);
    }

    assert(test_list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
}

// Tests insertion into front of a larger list
void insertAt_front_large_list() {
    char test_arr[9] = {'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(test_arr, 9);

    test_list.insertAt('y', 0);

    assert(test_list.size() == 10);
    assert(test_list.elementAt(0) == 'y');
    assert(test_list.toString() ==
           "[CharLinkedList of size 10 <<yabczdefgh>>]");
}

// Tests insertion into the back of a larger list
void insertAt_back_large_list() {

    char test_arr[10] = {'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(test_arr, 10);

    test_list.insertAt('x', 10);

    assert(test_list.size() == 11);
    assert(test_list.elementAt(10) == 'x');
    assert(test_list.toString() ==
           "[CharLinkedList of size 11 <<yabczdefghx>>]");
}

// Tests insertion into the middle of a larger list
void insertAt_middle_large_list() {
    char test_arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(test_arr, 8);

    test_list.insertAt('z', 3);

    assert(test_list.size() == 9);
    assert(test_list.elementAt(3) == 'z');
    assert(test_list.toString() == "[CharLinkedList of size 9 <<abczdefgh>>]");
}

// Tests out-of-range insertion for a non-empty list.
void insertAt_nonempty_incorrect() {

    char test_arr[8] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'};
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.insertAt('a', 42);
    } catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8]");
}

void insertAt_after_removeAt_test() {
    char arr[5] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list(arr, 5);

    list.removeAt(2);
    list.insertAt('z', 2);

    assert(list.toString() == "[CharLinkedList of size 5 <<abzde>>]");

    list.removeAt(0);
    list.insertAt('y', 0);

    assert(list.toString() == "[CharLinkedList of size 5 <<ybzde>>]");

    list.removeAt(4);
    list.insertAt('x', 4);

    assert(list.toString() == "[CharLinkedList of size 5 <<ybzdx>>]");

    list.removeAt(1);
    list.insertAt('w', 1);

    assert(list.toString() == "[CharLinkedList of size 5 <<ywzdx>>]");

    list.removeAt(3);
    list.insertAt('v', 3);

    assert(list.toString() == "[CharLinkedList of size 5 <<ywzvx>>]");
}

/**
 * CharLinkedList.cpp
 * Kyle Wigdor
 * Feb. 3, 2024
 *
 * CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 * Implementation of `CharLinkedList` class.
 *
 */

#include "CharLinkedList.h"
#include <sstream>
#include <stdexcept>

/**
 * name: default constructor
 * purpose: initializes an empty list
 * arguments: this constructor takes no arguments
 * returns: this constructor returns nothing
 * effect: this constructor initializes an empty list
 */
CharLinkedList::CharLinkedList() {
    length = 0;
    front = nullptr;
    back = nullptr;
}

/**
 * name: single character constructor
 * purpose: initializes a list containing a single character
 * arguments: this constructor takes a single character `c`
 * returns: this constructor returns nothing at all
 * effect: this constructor initializes a list containing a single character
 */
CharLinkedList::CharLinkedList(char c) {
    length = 0;
    front = nullptr;
    back = nullptr;
    pushAtBack(c);
}

/**
 * name: array constructor
 * purpose: initializes a list containing the provided characters in `arr` up to
 * (but not including) index `size`
 * arguments: this constructor takes an array of characters `arr` and an integer
 * `size`
 * returns: this constructor returns nothing
 * effect: this constructor initializes a list containing the provided
 * characters in `arr` up to length `size`. If `size` is greater than the length
 * of `arr`, the behavior of this function is undefined.
 */
CharLinkedList::CharLinkedList(char arr[], int size) {
    length = 0;
    front = nullptr;
    back = nullptr;
    concatenateArray(arr, size);
}

/**
 * name: copy constructor
 * purpose: initializes a list containing the same characters as `other`
 * arguments: this constructor takes a reference to a `CharLinkedList` `other`
 * returns: this constructor returns nothing
 * effect: this constructor initializes a list containing the same characters as
 * `other`
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other) {
    length = 0;
    front = nullptr;
    back = nullptr;
    concatenateList(&other);
}

/**
 * name: destructor
 * purpose: destroys the list, freeing any allocated memory
 * arguments: this destructor takes no arguments
 * returns: this destructor returns nothing
 * effect: this destructor destroys the list, freeing any allocated memory
 */
CharLinkedList::~CharLinkedList() {
    clear();
}

/**
 * name: assignment operator
 * purpose: copies the contents of `other` into this `CharLinkedList`
 * arguments: this function takes a reference to a `CharLinkedList` `other`
 * returns: this function returns a reference to this `CharLinkedList`
 * effect: this function copies the contents of `other` into this
 `CharLinkedList`

*/
CharLinkedList &CharLinkedList::operator=(const CharLinkedList &other) {
    clear();
    concatenateList(&other);
    return *this;
}

/**
 * name: isEmpty
 * purpose: returns whether the list is empty or not
 * arguments: this function takes no arguments
 * returns: true if the list is empty, false otherwise
 * effect: this function has no effects
 */
bool CharLinkedList::isEmpty() const {
    return length == 0;
}

/**
 * name: clear
 * purpose: removes all characters from the list
 * arguments: this function takes no arguments
 * returns: this function returns nothing
 * effect: this function removes all characters from the list
 */
void CharLinkedList::clear() {
    removeNodeAndNext(front);
    length = 0;
    front = nullptr;
    back = nullptr;
}

/**
 * name: size
 * purpose: returns the number of characters in the list
 * arguments: this function takes no arguments
 * returns: this function returns the number of characters in the list
 * effect: this function has no effect
 */
int CharLinkedList::size() const {
    return length;
}

/**
 * name: first
 * purpose: returns the first character in the list
 * arguments: this function takes no arguments
 * returns: the first character in the list
 * effect: if the list is empty, this function throws a `std::runtime_error`.
 */
char CharLinkedList::first() const {
    if (length == 0) {
        throw std::runtime_error("cannot get first of empty LinkedList");
    }

    return elementAt(0);
}

/**
 * name: last
 * purpose: returns the last character in the list
 * arguments: this function takes no arguments
 * returns: the last character in the list
 * effect: if the list is empty, this function throws a `std::runtime_error`.
 */
char CharLinkedList::last() const {
    if (length == 0) {
        throw std::runtime_error("cannot get last of empty LinkedList");
    }

    return elementAt(length - 1);
}

/**
 * name: elementAt
 * purpose: returns the character at the provided index
 * arguments: this function takes an integer `index`
 * returns: the character at the provided index
 * effect: if the index is out of range, this function throws a
 * `std::range_error`.
 */
char CharLinkedList::elementAt(int index) const {
    if (index < 0 or index >= length) {
        throw std::range_error("index (" + std::to_string(index) +
                               ") not in range [0.." + std::to_string(length) +
                               ")");
    }

    return locate(index)->data;
}

/**
 * name: toString
 * purpose: returns a string representation of the list assuming the characters
 * are in forward order
 * arguments: this function takes no arguments
 * returns: a string representation of the list assuming the characters are in
 * forward order
 * effect: this function has no effect
 */
std::string CharLinkedList::toString() const {
    return formatString(asRawString());
}

/**
 * name: toReverseString
 * purpose: returns a string representation of the list assuming the characters
 * are in reverse order
 * arguments: this function takes no arguments
 * returns: a string representation of the list assuming the characters are in
 * reverse order
 * effect: this function has no effect
 */
std::string CharLinkedList::toReverseString() const {
    return formatString(asRawReverseString());
}

/**
 * name: pushAtBack
 * purpose: pushes the provided character to the back of this list
 * arguments: this function takes a character `c`
 * returns: this function returns nothing
 * effect: this function pushes the provided character to the back of this list
 */
void CharLinkedList::pushAtBack(char c) {
    insertAt(c, length);
}

/**
 * name: pushAtBack
 * purpose: pushes the provided character to the front of this list
 * arguments: this function takes a character `c`
 * returns: this function returns nothing
 * effect: this function pushes the provided character to the front of this list
 */
void CharLinkedList::pushAtFront(char c) {
    insertAt(c, 0);
}

/**
 * name: insertAt
 * purpose: inserts the provided character at the given index in this list
 * arguments: this function takes a character `c` and an integer `index`
 * returns: this function returns nothing
 * effect: this function inserts the provided character at the given index in
 * this list. If `index` is out of range, this function throws a
 * `std::range_error`.
 */
void CharLinkedList::insertAt(char c, int index) {
    if (index < 0 or index > length) {
        throw std::range_error("index (" + std::to_string(index) +
                               ") not in range [0.." + std::to_string(length) +
                               "]");
    }

    Node *next = locate(index);
    // `next` will be `nullptr` iff `index` is equal to `size()`, in which case
    // we insert at back by passing `nullptr` as the next node.
    insert(c, next);
}

/**
 * name: insertInOrder
 * purpose: inserts the provided character in order in this list, assuming the
 * list is already sorted in ascending order
 * arguments: this function takes a character `c`
 * returns: this function returns nothing
 * effect: this function inserts the provided character in order in this list,
 * assuming the list is already sorted in ascending order
 */
void CharLinkedList::insertInOrder(char c) {
    Node *at = front;

    // Find the last index where the character is less than `c`.
    while (at != nullptr and at->data < c) {
        at = at->next;
    }

    // `at` will be `nullptr` iff `c` is greater than all characters in the
    // list or if `front` is `nullptr` (so the list is empty). In either case,
    // we can insert at the back of the list (signified by `nullptr`).
    insert(c, at);
}

/**
 * name: popFromFront
 * purpose: removes the first character from the list
 * arguments: this function takes no arguments
 * returns: the function returns nothing
 * effect: the function removes the first character from the list. If the list
 * is empty, throws a `std::runtime_error`.
 */
void CharLinkedList::popFromFront() {
    if (length == 0) {
        throw std::runtime_error("cannot pop from empty LinkedList");
    }

    removeAt(0);
}

/**
 * name: popFromBack
 * purpose: removes the last character from the list
 * arguments: this function takes no arguments
 * returns: the function returns nothing
 * effect: the function removes the last character from the list. If the list
 * is empty, throws a `std::runtime_error`.
 */
void CharLinkedList::popFromBack() {
    if (length == 0) {
        throw std::runtime_error("cannot pop from empty LinkedList");
    }

    removeAt(length - 1);
}

/**
 * name: removeAt
 * purpose: removes the character at the given index
 * arguments: this function takes an integer `index`.
 * returns: the function returns nothing
 * effect: the function removes the character at the given index. If the given
 * index is not in the range `[0..size())`, throws a `std::range_error`.
 */
void CharLinkedList::removeAt(int index) {
    if (index < 0 or index >= length) {
        throw std::range_error("index (" + std::to_string(index) +
                               ") not in range [0.." + std::to_string(length) +
                               ")");
    }

    Node *node = locate(index);
    // `node` cannot be `nullptr` because the index is checked to be in range.
    remove(node);
}

/**
 * name: replaceAt
 * purpose: replaces the character at the given index with the provided
 * character
 * arguments: the function takes a new character `c` and an integer `index`.
 * returns: this function returns void
 * effect: this function replaces the chracter at the provided index with the
 * given character. If the index is not in the range `[0..size())`, throws a
 * `std::range_error`.
 */
void CharLinkedList::replaceAt(char c, int index) {
    if (index < 0 or index >= length) {
        throw std::range_error("index (" + std::to_string(index) +
                               ") not in range [0.." + std::to_string(length) +
                               ")");
    }

    locate(index)->data = c;
}

/**
 * name: concatenate
 * purpose: concatenates an array of characters to the end of this list
 * arguments: this function takes `other`, a pointer to the start of the array
 * and `size`, the length of characters to add to the list.
 * returns: this function does not return anything.
 * effect: concatenates the characters from the given array up to the given
 * size. If the length of `other` is less than size, then the behavior of this
 * function is undefined
 */
void CharLinkedList::concatenateArray(const char *other, int size) {
    for (int i = 0; i < size; i++) {
        pushAtBack(other[i]);
    }
}

/**
 * name: concatenate
 * purpose: concatenates the characters in `other` to the end of this list
 * arguments: this takes a const pointer to a `CharLinkedList`, `other`
 * returns: this function returns nothing
 * effect: this function concatenates the characters in `other` to the end of
 * this list. If `other` is `nullptr`, the behavior of this function is
 * undefined. Despite this function taking a non-const pointer, `other` is
 * unchanged.
 */
void CharLinkedList::concatenateList(const CharLinkedList *other) {
    // We define a `const` version of `concatenate` to reuse the concatenation
    // logic for initializing with a `const CharLinkedList&` (as is done in the
    // copy constructor and assignment operator).

    // We need to cache the length of `other` because we will be modifying it
    // iff `other == this`.
    int otherLength = other->length;

    for (int i = 0; i < otherLength; i++) {
        pushAtBack(other->elementAt(i));
    }
}

/**
 * name: concatenate
 * purpose: concatenates the characters in `other` to the end of this list
 * arguments: this takes a pointer to a `CharLinkedList` `other`
 * returns: this function returns nothing
 * effect: this function concatenates the characters in `other` to the end of
 * this list. If `other` is `nullptr`, the behavior of this function is
 * undefined. Despite this function taking a non-const pointer, `other` is
 * unchanged.
 */
void CharLinkedList::concatenate(CharLinkedList *other) {
    // We must explicitly cast to not infinitely recurse.
    concatenateList((const CharLinkedList *)other);
}

/**
 * name: node constructor
 * purpose: initializes a `Node` containing the given character and the provided
 * previous node and next node.
 * arguments: this function accepts a character `c`, a pointer to the intended
 * previous node `p`, and a pointer to the intended next node `n`.
 * returns: the constructor does not return.
 * effect: this constructor initializes a `Node` as described in the purpose
 * statement of this function contract
 */
CharLinkedList::Node::Node(char c, Node *p, Node *n) {
    data = c;
    prev = p;
    next = n;
}

/**
 * name: locate
 * purpose: locates the node located at the `index`-th node relative to `at`
 * arguments: this function accepts an integer `index` to locate and a pointer
 * to the basis node, `at`.
 * returns: the found node, else `nullptr`
 * effect: this function has no side effects.
 */
CharLinkedList::Node *CharLinkedList::locate(int index, Node *at) const {
    if (index > 0) {
        return locate(index - 1, at->next);
    } else if (index < 0) {
        return locate(index + 1, at->prev);
    } else {
        return at;
    }
}

/**
 * name: locate
 * purpose: locates the node located at the `index`-th node relative to `front`
 * arguments: this function accepts an integer `index` to locate
 * returns: this function returns the found node, else `nullptr` if not found.
 * effect: this function has no side effects.
 */
CharLinkedList::Node *CharLinkedList::locate(int index) const {
    if (index > length / 2) {
        return locate(index - length + 1, back);
    } else {
        return locate(index, front);
    }
}

/**
 * name: link
 * purpose: links the provided nodes together, updating the previous and next
 * nodes accordingly, as well as the `front` and `back` pointers if necessary.
 * arguments: this function accepts pointers to the previous and next nodes
 * `prev` and `next`, respectively, as well as pointers to the new previous
 * and next nodes, `newPrev` and `newNext`, respectively.
 * returns: this function returns nothing
 * effect: this function links the provided nodes
 * together, updating the previous and next nodes accordingly, as well as the
 * `front` and `back` pointers if necessary. If `prev` and `next` are not
 * adjacent nodes in the list, this function will cause a memory leak and
 * corrupt the list.
 */
void CharLinkedList::link(Node *prev, Node *newPrev, Node *newNext,
                          Node *next) {
    if (prev == nullptr) {
        front = newNext;
    } else {
        prev->next = newNext;
    }

    if (next == nullptr) {
        back = newPrev;
    } else {
        next->prev = newPrev;
    }
}

/**
 * name: remove
 * purpose: removes the provided node from the list
 * arguments: this function accepts a pointer to the node to remove, `node`
 * returns: this function returns void, absolutely nothing.
 * effect: this function removes the provided node from the list
 */
void CharLinkedList::remove(Node *node) {
    link(node->prev, node->prev, node->next, node->next);
    delete node;
    length--;
}

/**
 * name: insert
 * purpose: inserts a character between two nodes
 * arguments: this function accepts a character `c`, a pointer to the previous
 * node `prev`, and a pointer to the next node `next`.
 * returns: this function returns nothing.
 * effect: this function inserts the provided character between the given nodes.
 * Note that if the given previous node is not directly before the given next
 * node, this function will leak memory.
 */
void CharLinkedList::insert(char c, Node *prev, Node *next) {
    Node *node = new Node(c, prev, next);
    link(prev, node, node, next);
    length++;
}

/**
 * name: insert
 * purpose: inserts a character before the given node.
 * arguments: this function accepts a character `c`  and a pointer to the next
 * node `next`.
 * returns: this function returns absolutely nothing.
 * effect: this function inserts the provided character before the given node.
 */
void CharLinkedList::insert(char c, Node *next) {
    if (next == nullptr) {
        // If `next` is nullptr, insert at back.
        insert(c, back, nullptr);
    } else {
        insert(c, next->prev, next);
    }
}

/**
 * name: removeNodeAndNext
 * purpose: removes the given node and all subsequent nodes
 * arguments: this function accepts a pointer to the node `at`
 * returns: this function returns nothing
 * effect: this function removes the given node and all subsequent nodes from
 * the list
 */
void CharLinkedList::removeNodeAndNext(Node *at) {
    if (at == nullptr) {
        return;
    }

    Node *next = at->next;
    delete at;
    removeNodeAndNext(next);
}

/**
 * name: asRawString
 * purpose: converts the characters in this list to a `std::string` assuming the
 * characters are in forward order
 * returns: the characters in this list as a `std::string` assuming the
 * characters are in forward order.
 * effect: this function has no side effects.
 */
std::string CharLinkedList::asRawString() const {
    std::stringstream ss;

    for (Node *node = front; node != nullptr; node = node->next) {
        ss << node->data;
    }

    return ss.str();
}

/**
 * name: asRawString
 * purpose: converts the characters in this list to a `std::string` assuming the
 * characters are in forward order
 * returns: the characters in this list as a `std::string` assuming the
 * characters are in forward order.
 * effect: this function has no side effects.
 */
std::string CharLinkedList::asRawReverseString() const {
    std::stringstream ss;

    for (Node *node = back; node != nullptr; node = node->prev) {
        ss << node->data;
    }

    return ss.str();
}

/**
 * name: formatString
 * purpose: formats the provided `rawString` into a string representation of the
 * list.
 * arguments: this function accepts a `std::string` `rawString` to format.
 * returns: the formatted string representation of the list.
 * effect: this function has no side effects.
 */
std::string CharLinkedList::formatString(std::string rawString) const {
    std::stringstream ss;

    ss << "[CharLinkedList of size " << length << " <<" << rawString << ">>]";

    return ss.str();
}

/**
 * CharLinkedList.h
 * Kyle Wigdor
 * Feb. 3, 2024
 *
 * CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 * Defines `CharLinkedList`, an ordered list of characters supporting
 * arbitrary indexing, insertion, and removal at any index in the list.
 * Front/back insertion/removal/access are fast for this list, but random
 * operations will be slower.
 *
 */

#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H

#include <string>

class CharLinkedList {
public:
    CharLinkedList();
    CharLinkedList(char c);
    CharLinkedList(char arr[], int size);
    CharLinkedList(const CharLinkedList &other);

    ~CharLinkedList();

    CharLinkedList &operator=(const CharLinkedList &other);

    bool isEmpty() const;

    void clear();

    int size() const;

    char first() const;

    char last() const;

    char elementAt(int index) const;

    std::string toString() const;

    std::string toReverseString() const;

    void pushAtBack(char c);

    void pushAtFront(char c);

    void insertAt(char c, int index);

    void insertInOrder(char c);

    void popFromFront();

    void popFromBack();

    void removeAt(int index);

    void replaceAt(char c, int index);

    void concatenate(CharLinkedList *other);

    void sort();

    CharLinkedList *slice(int left, int right);

private:
    struct Node {
        char data;
        Node *prev;
        Node *next;

        Node(char c, Node *p, Node *n);
    };

    int length;
    Node *front;
    Node *back;

    Node *locate(int index, Node *at) const;
    Node *locate(int index) const;

    void concatenateArray(const char *other, int size);
    void concatenateList(const CharLinkedList *other);

    void link(Node *prev, Node *a, Node *b, Node *next);

    void remove(Node *node);

    void insert(char c, Node *prev, Node *next);
    void insert(char c, Node *next);

    void removeNodeAndNext(Node *at);

    std::string asRawString() const;

    std::string asRawReverseString() const;

    std::string formatString(std::string rawString) const;
};

#endif

/*
 *  unit_tests.h
 *  Kimberly Pothemont
 *  January 31st
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  The purpose of this file is to implement unit tests that I will use to 
 *  run my declared unit test cases.
 *
 */

#include "CharLinkedList.h"
#include <cassert>
#include <iostream>
#include <string>
#include <cstdlib> 
#include <ctime>   

using namespace std;

/**************************
 * LIST TESTING CONSTANTS *
 **************************/
// Idea taken from timer_main.cpp - Milod Kazerounian Professor
const int LARGE_LIST_SIZE = 10000;
const int LIST_AMOUNT = 1000;
const int ELEM_AMOUNT = 100;

/*   TAKEN FROM timer_main.cpp
 * name:      generateRandList
 * purpose:   generates a CharLinkedList of random elements
 * arguments: const int size of list to generate
 * returns:   pointer to the new heap-allocated CharArrayList
 * effects:   allocates CharArrayList on heap
 */
CharLinkedList *generateRandList(const int size)
{
    CharLinkedList *list = new CharLinkedList;

    for(int i = 0; i < size; i++) {
        // rand() will generate a random int. The mod operation will
        // put it in range [0, 255]. In C++, ints translate into chars
        // of the corresponding ASCII number.
        list->pushAtBack(rand() % 256);
    }

    return list;
}

/********************************************************************\
*                       CHAR LINKED LIST TESTS                        *
\********************************************************************/

/********************************************************************\
*                       CONSTRUCTOR TESTS                            *
\********************************************************************/

// Test for default constructor
void testDefaultConstructor() {
    CharLinkedList list;
    assert(list.size() == 0);
    assert(list.isEmpty());
}

// Test for single character constructor
void testSingleCharConstructor() {
    CharLinkedList list('a');
    assert(list.size() == 1);
    assert(list.first() == 'a');
    assert(list.last() == 'a');
}

// Test for array constructor with empty array
void testArrayConstructorEmpty() {
    char arr[1] = {}; // Empty array
    CharLinkedList list(arr, 0);
    assert(list.size() == 0);
    assert(list.isEmpty());
}

// Test for array constructor with non-empty array
void testArrayConstructorNonEmpty() {
    char arr[] = {'a', 'b', 'c'};
    CharLinkedList list(arr, 3);
    assert(list.size() == 3);
    assert(list.first() == 'a');
    assert(list.last() == 'c');

    char kimArr[5] = {'k','i','m','m','y'};
    CharLinkedList list2(kimArr, 5);
    assert(list2.size() == 5);
    assert(list2.first() == 'k');
    assert(list2.last() == 'y');

}

// Test for copy constructor
void testCopyConstructor() {
    char arr[5] = {'k','i','m','m','y'};
    CharLinkedList originalList(arr, 5);
    CharLinkedList copiedList(originalList);
    
    assert(copiedList.size() == originalList.size());
    assert(copiedList.first() == originalList.first());
    assert(copiedList.last() == originalList.last());

}

// Test for copy constructor with an empty list
void testCopyConstructorEmptyList() {
    CharLinkedList originalList;
    CharLinkedList copiedList(originalList);
    assert(copiedList.size() == 0);
    assert(copiedList.isEmpty());
}

// Test for ensuring deep copy
void testCopyConstructorDeepCopy() {
    char arr[] = {'x', 'y', 'z'};
    CharLinkedList originalList(arr, 3);
    CharLinkedList copiedList(originalList);
    // Modify original list after copying
    originalList.pushAtBack('a');
    // Ensure copied list is unchanged
    assert(copiedList.size() == 3); 
    assert(copiedList.last() == 'z'); 
    assert(originalList.size() == 4);
    assert(originalList.last() == 'a'); 
}

// Test for copying a large list
void testCopyLargeList() {
    srand((time(0))); 

    // Generate a large random list
    CharLinkedList *largeList = generateRandList(LARGE_LIST_SIZE);

    assert(largeList->size() == LARGE_LIST_SIZE); 

    // Copy the large list
    CharLinkedList copiedList(*largeList);

    // Test the integrity of the copied list
    assert(copiedList.size() == largeList->size());
    assert(copiedList.first() == largeList->first());
    assert(copiedList.last() == largeList->last());

    delete largeList;
}

/********************************************************************\
*                       DECONSTRUCTOR TESTS                          *
\********************************************************************/

// Test for ensuring a list is created and destroyed several times 
//   implicitly with the deconstructor. Using Valgrind 
void testRepeatedCreateDestroy() {
    for (int i = 0; i < LIST_AMOUNT; ++i) {
        CharLinkedList list;
        for (int j = 0; j < ELEM_AMOUNT; ++j) {
            list.pushAtBack('a'); 
        }
        // Destructor is called implicitly here at the end of each iteration
    }
    
}

//Test ensuring dynamic memory allocation still works with our deconstructor
void testDynamicAllocation() {
    for (int i = 0; i < LIST_AMOUNT; ++i) {
        CharLinkedList* list = new CharLinkedList;
        for (int j = 0; j < ELEM_AMOUNT; ++j) {
            list->pushAtBack('a'); 
        }
        delete list; // Destructor should clean up all internal allocations
    }
    // Again, check with Valgrind for leaks
}

/********************************************************************\
*                     ASSIGNMENT OPERATOR TESTS                      *
\********************************************************************/

//Test that self assignment doesn't alter the list or cause any issues
void testSelfAssignment() {
    char arr[5] = {'k','i','m','m','y'};
    CharLinkedList list(arr, 5);

    list = list; 

    assert(list.size() == 5);
    assert(list.first() == 'k');
    assert(list.last() == 'y');
}

//Test checks that assigning an empty list to a nonempty list correctly 
//empties the target list
void testEmptyToNonEmptyAssignment() {
    CharLinkedList sourceList; 
    CharLinkedList targetList;
    targetList.pushAtBack('x'); 

    targetList = sourceList; 

    assert(targetList.size() == 0);
}

//Test checks that assigning a non-empty list to another non-empty list copies 
//all elements correctly and clears the target list before the assignment.
void testNonEmptyToNonEmptyAssignment() {
    char arr[5] = {'k','i','m','m','y'};
    CharLinkedList sourceList(arr, 5);

    char arr2[3] = {'a','b','c'};
    CharLinkedList targetList(arr2, 5);

    targetList = sourceList; 

    assert(targetList.size() == 5);
    assert(targetList.first() == 'k');
    assert(targetList.last() == 'y');
    assert(targetList.toString() == "[CharLinkedList of size 5 <<kimmy>>]");
}

//Test checks that assigning a non-empty list to an empty list copies
//all elements correctly
void testAssignmentToEmptyList() {
    char arr[5] = {'k','i','m','m','y'};
    CharLinkedList sourceList(arr, 5);

    CharLinkedList targetList; 

    targetList = sourceList; 

    assert(targetList.size() == 5);
    assert(targetList.first() == 'k');
    assert(targetList.last() == 'y');
    assert(targetList.toString() == "[CharLinkedList of size 5 <<kimmy>>]");


}

/********************************************************************\
*                     GETTER FUNCTION TESTS                          *
\********************************************************************/

//Test for ensuring a newly constructed list is empty and verify if 
// that it returns true for a false ar
void testisEmptyOnBoth() {

    CharLinkedList list;
    assert(list.isEmpty());

    list.pushAtBack('k');
    assert(!(list.isEmpty()));
}



//Test to see if list is empty 
void testClearOnNonEmpty() {
    char arr[5] = {'k','i','m','m','y'};
    CharLinkedList list(arr, 5);

    //calling my clear
    list.clear();   

    //asserting this because if i clear everything, it has to be empty
    assert(list.isEmpty());
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}

//Test to see if the clear function works on an empty list already
void testClearOnEmpty(){
    CharLinkedList list;

    list.clear();

    assert(list.isEmpty());
    assert(list.toString() == "[CharLinkedList of size 0 <<>>]");
}

// Test for verifying the size function on both an empty and non-empty list
void testSizeOnBothConditions() {
    CharLinkedList list;
    assert(list.size() == 0); // Test on empty list

    list.pushAtBack('k');
    assert(list.size() == 1); // Test on non-empty list
}

// Test for veifying size on a regular linked list that isn't too large
void testSizeOnRegular(){
    char arr[5] = {'k','i','m','m','y'};
    CharLinkedList list(arr, 5);

    assert(list.size() == 5);
    assert(list.toString() == "[CharLinkedList of size 5 <<kimmy>>]");
}


// Test for verifying size on a large list
void testSizeOnLargeList() {
    CharLinkedList largeList;
    for(int i = 0; i < LARGE_LIST_SIZE; i++) {
        largeList.pushAtBack('a'); 
    }

    assert(largeList.size() == LARGE_LIST_SIZE);
}

// Test for verifying first and last elements on a large list
void testFirstLastOnLargeList() {
   CharLinkedList largeList;
    
    for(int i = 0; i < LARGE_LIST_SIZE - 1; i++) { 
        largeList.pushAtBack('a');
    }
    largeList.pushAtBack('b'); 

    assert(largeList.first() == 'a');
    assert(largeList.last() == 'b');
}

//Test first on regular sized list that's not too large
void testFirstOnNonEmpty(){

    char arr[5] = {'k','i','m','m','y'};
    CharLinkedList list(arr, 5);

    assert(list.first() == 'k');
}

// Test for verifying isEmpty on a large list before and after clear
void testIsEmptyBeforeAfterClearLargeList() {
    CharLinkedList largeList;
    for(int i = 0; i < LARGE_LIST_SIZE; i++) {
        largeList.pushAtBack('a');
    }

    assert(largeList.isEmpty()); 
    largeList.clear(); 
    assert(!(largeList.isEmpty())); 
}

/********************************************************************\
*                     elementAt TESTS                                *
\********************************************************************/

void elementAtTest(){

    char arr[5] = {'k','i','m','m','y'};
    CharLinkedList list(arr, 5);
    assert(list.elementAt(2) == 'm');

}

void RevString_EmptyTest(){
    CharLinkedList list; 
    list.toReverseString(); 
    assert(list.isEmpty());
    assert(list.toReverseString() == "[CharLinkedList of size 0 <<>>]");
}

void RevString_OneChar(){
    char arr[1] = {'k'};
    CharLinkedList list(arr, 1); 
    list.toReverseString(); 
    assert(list.toReverseString() == "[CharLinkedList of size 1 <<k>>]");
    cout << "This is the reversed list: " << list.toReverseString() << endl;

}

void RevString_MultiChar(){
    char arr[5] = {'k','i','m','m','y'};
    CharLinkedList list(arr, 5); 
    list.toReverseString(); 
    assert(list.toReverseString() == "[CharLinkedList of size 5 <<ymmik>>]");
    cout << "This is the reversed list: " << list.toReverseString() << endl;
} 

void PushAtFrontEmptyList() {
    CharLinkedList list;
    list.pushAtFront('k');
    assert(list.toString() == "[CharLinkedList of size 1 <<k>>]"); 
    cout << "testPushAtFrontEmptyList: Passed" << endl;
}

void PushAtFrontNonEmptyList() {
    char arr[3] = {'m', 'm', 'y'};

    CharLinkedList list(arr, 3);
    list.pushAtFront('i');
    assert(list.toString() == "[CharLinkedList of size 4 <<immy>>]"); 
}

void insertAt_test(){
    char arr[4] = {'k','m','m','y'};
    CharLinkedList list(arr, 4);

    cout << list.toString() << endl; 

    list.insertAt('z', 1);

    cout << list.toString() << endl; 
}

void insertInOrder_test(){
    char arr[4] = {'a','b','d','e'};
    CharLinkedList list(arr, 4);

    list.insertInOrder('c'); 
    cout << "CHECK ORDER: " << list.toString() << endl;

}

void popFromFront_test(){
    char arr[5] = {'k','i','m','m','y'};
    CharLinkedList list(arr, 5);

    list.popFromFront(); 
    cout << "AFTER: " << list.toString() << endl; 

    list.popFromFront(); 
    cout << "MORE: " << list.toString() << endl; 
}

void popFromBack_test(){

    cout << "TESTING popFromBack() \n";
    char arr[5] = {'k','i','m','m','y'};
    CharLinkedList list(arr, 5);

    list.popFromBack(); 
    cout << "AFTER: " << list.toString() << endl; 
    list.popFromBack();  
    cout << "MORE: " << list.toString() << endl; 
}

void removeAt_test() {
    cout << "Testing RemoveAt(): \n";
    char arr[5] = {'k', 'i', 'm', 'm', 'y'};
    CharLinkedList list(arr, 5);

    // Remove middle element and check
    list.removeAt(2);
    assert(list.toString() == "[CharLinkedList of size 4 <<kimy>>]");
    
    // Remove first element and check
    list.removeAt(0);
    assert(list.toString() == "[CharLinkedList of size 3 <<imy>>]");

    // Remove last element and check
    list.removeAt(2);
    assert(list.toString() == "[CharLinkedList of size 2 <<im>>]");

    // Trying to create an error
    bool caughtException = false;
    try {
        list.removeAt(5); 
    } catch (const std::range_error& e) {
        caughtException = true;
        string expectedMsg = "index (5) not in range [0..2)";
        assert(string(e.what()) == expectedMsg);
    }
    assert(caughtException);
    cout << " - Passed RemoveAt()\n";
}

void replaceAt_test() {
    cout << "Testing replaceAt(): \n";
    char arr[5] = {'k', 'i', 'm', 'm', 'y'};
    CharLinkedList list(arr, 5);

    // Replace middle element and check
    list.replaceAt('x', 2);
    assert(list.toString() == "[CharLinkedList of size 5 <<kixmy>>]");
    
    // Replace first element and check
    list.replaceAt('z', 0);
    assert(list.toString() == "[CharLinkedList of size 5 <<zixmy>>]");

    // Replace last element and check
    list.replaceAt('w', 4);
    assert(list.toString() == "[CharLinkedList of size 5 <<zixmw>>]");

    // Trying to replace an element at an index that is out of range
    bool caughtException = false;
    try {
        list.replaceAt('t', 5); 
    } catch (const std::range_error& e) {
        caughtException = true;
        string expectedMsg = "index (5) not in range [0..5)";
        assert(string(e.what()) == expectedMsg);
    }
    assert(caughtException);
    
    // Test replacing at negative index
    caughtException = false;
    try {
        list.replaceAt('n', -1);
    } catch (const std::range_error& e) {
        caughtException = true;
        string expectedMsg = "index (-1) not in range [0..5)";
        assert(string(e.what()) == expectedMsg);
    }
    assert(caughtException);
    
    cout << " - Passed replaceAt()\n";
}


void concatenate_test() {
    cout << "Testing concatenate(): \n";
    
    char arrKim[3] = {'k', 'i', 'm'};
    CharLinkedList listKim(arrKim, 3);

    char arrMy[2] = {'m', 'y'};
    CharLinkedList listMy(arrMy, 2);

    listKim.concatenate(&listMy);
    assert(listKim.toString() == "[CharLinkedList of size 5 <<kimmy>>]");

    CharLinkedList listEmpty;
    CharLinkedList listKimmy = listKim; 

    listEmpty.concatenate(&listKimmy);
    assert(listEmpty.toString() == "[CharLinkedList of size 5 <<kimmy>>]");

    CharLinkedList listEmpty2;
    listKimmy.concatenate(&listEmpty2);
    assert(listKimmy.toString() == "[CharLinkedList of size 5 <<kimmy>>]");


    CharLinkedList listKimmySelf(arrKim, 3); 
    listKimmySelf.concatenate(&listMy);
    listKimmySelf.concatenate(&listKimmySelf); 
    std::string expectedValue = "[CharLinkedList of size 10 <<kimmykimmy>>]";
    assert(listKimmySelf.toString() == expectedValue);
    cout << " - Passed concatenate()\n";
}

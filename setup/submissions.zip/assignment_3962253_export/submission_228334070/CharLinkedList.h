/*
 *  CharLinkedList.h
 *  Kimberly Pothemont
 *  January 31st
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Function Declarations for the CharLinkedList class
 * 
 *  This file is the interface of the CharLinkedList class. It contains
 *  functions declarations that are implemented in the CharLinkedList.cpp file. 
 *  
 *
 *  Function declarations for the CharLinkedList.cpp file
 *
 */

#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H

#include <string>

class CharLinkedList {
public: 
    //Constructors
    CharLinkedList();
    CharLinkedList(char c);
    CharLinkedList(char arr[], int length);
    CharLinkedList(const CharLinkedList &other);

    //Deconstructor
    ~CharLinkedList(); 

    //Assignment Operator
    CharLinkedList& operator=(const CharLinkedList &other);

    //Function Declarations
    void pushAtBack(char c);
    void pushAtFront(char c);
    bool isEmpty(); 
    void clear();
    int size() const; 
    char first() const;
    char last() const;
    char elementAt(int index) const;
    std::string toString() const;
    std::string toReverseString() const;
    void insertAt (char c, int index); 
    void insertInOrder(char c);
    void popFromFront();
    void popFromBack();
    void removeAt(int index);
    void replaceAt(char c, int index);
    void concatenate(CharLinkedList *other);


private: 
    struct CharNode{
        char letter; 
        CharNode *previous; 
        CharNode *next; 
    };

    //Nodes that point to front and back of list 
    CharNode *front; 
    CharNode *end; 
    int sizes; 

    //HELPER FUNCTIONS
    CharNode *makeNewNode(char c, CharNode *p, CharNode *n);
    char elemAtHelp(CharNode *node, int tgtIndex, int currIndex) const;
    CharNode *getNodeAtIndex(int index);
    CharNode *getNodeHelper(CharNode* node, int index) const;



};

#endif

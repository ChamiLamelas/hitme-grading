/*
 *  CharLinkedList.cpp
 *  Kimberly Pothemont
 *  January 31st
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  Function Definitions for the CharLinkedList class
 * 
 *  This file contains the implementation of the CharLinkedList 
 *  interface. The CharLinkedList is used to store characters using a 
 *  doubly-linked list. This file also includes functions that interact 
 *  with elements within the Linked list. 
 *
 */

#include "CharLinkedList.h"
#include <sstream>
#include <string>
#include <cassert>

#include <iostream>


using namespace std; 

/********************************************************************\
*                       CONSTRUCTORS                                 *
\********************************************************************/


/*
 * name:      CharLinkedList
 * purpose:   Initializes an empty LinkedList as first constructor
 * arguments: None
 * returns:   Nonex
 * effects:   Creates a Empty Linked list
 */
CharLinkedList::CharLinkedList() {
    front = nullptr;
    end = nullptr;
    sizes = 0;
}

/*
 * name:     CharLinkedList
 * purpose:   Creates linked list with given element as second constructor
 * arguments: Character
 * returns:   None
 * effects:   Creates a Linked list with one element
 */
CharLinkedList::CharLinkedList(char c) {
    CharNode *newLetterNode = makeNewNode(c, nullptr, nullptr);

    front = newLetterNode; 
    end = newLetterNode; 
    sizes = 1;
}

/* name: CharLinkedList
 * purpose: Create a list containing the characters in the array
 *          as a third constructor
 * arguments: Takes an array of characters and the integer length
 * returns: None
 * effect: Creates a list containing the characters in the array
 */
CharLinkedList::CharLinkedList(char arr[], int length) {
    
    sizes = 0;
    front = nullptr;
    end = nullptr;
    if (arr == nullptr) return;
    for (int i = 0; i < length; i++){
        pushAtBack(arr[i]);
    }
}

/*
 * name:      Copy constructor
 * purpose:   Updates the information of 'this' to be the same as that of
 *            'other', making a cope
 * arguments: Another charLinkedList object
 * returns:   None
 * effects:   Copies elements from one CharLinkedList to another
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other) {
    
    sizes = 0;
    front = nullptr;
    end   = nullptr;

    int loopCount = other.size();
    CharNode *temp = other.front;
    for (int i = 0; i < loopCount; i++){
        this->pushAtBack(temp->letter);
        temp = temp->next;
    }

}

/********************************************************************\
*                       DECONSTRUCTORS                               *
\********************************************************************/

/*
 * name:      CharArrayList  deconstructor
 * purpose:   Destroys all heap-allocated data 
 * arguments: None
 * returns:   None
 * effects:   Deletes everything
 */
CharLinkedList::~CharLinkedList() {
    CharNode *temp = end;

    while (temp != nullptr) {
        CharNode* toDelete = temp; 
        temp = temp->previous;
        delete toDelete; 
    }

    front = nullptr; 
    end = nullptr; 
}

/********************************************************************\
*                       ASSIGNMENT OPERATOR                         *
\********************************************************************/
/*
 * name:      operator=
 * purpose:   assigns one CharLinkedList to another, making a deep copy
 * arguments: const reference to another CharLinkedList
 * returns:   reference to the current instance of CharLinkedList
 * effects:   recycles storage of the current instance and copies all elements
 *            from the argument list
 */
CharLinkedList& CharLinkedList::operator=(const CharLinkedList &other){

    if (this == &other) {
        return *this;
    }

    clear(); 

    CharNode* curr = other.front; 
    while (curr != nullptr) {
        pushAtBack(curr->letter); 
        curr = curr->next; 
    }

    return *this;
}

/********************************************************************\
*                       HELPER FUNCTIONS                             *
\********************************************************************/

/*
 * name:      makeNewNode
 * purpose:   Makes and links new node
 * arguments: Character and two pointers: previous and next
 * returns:   Pointer
 * effects:   Makes and links new node to the LinkedList
 */
CharLinkedList::CharNode* 
CharLinkedList::makeNewNode(char c, CharNode *p, CharNode *n){
    CharNode *newLetterNode = new CharNode;
    newLetterNode->letter = c; 
    newLetterNode->previous = p;
    newLetterNode->next = n;  
    return newLetterNode; 
}


/*
 * name:      pushAtBack
 * purpose:   Pushes new node to the back of the linked list
 * arguments: Character, two pointers: previous and next
 * returns:   Pointer
 * effects:   Pushes node to the back of the LinkedList
 */
void CharLinkedList::pushAtBack(char c){
    CharNode* newLetterNode = makeNewNode(c, end, nullptr);

    if (end != nullptr) {
        end->next = newLetterNode;
    } else {
        front = newLetterNode;
    }
    end = newLetterNode;
    sizes++;
}

/*
 * name:      PushAtFront
 * purpose:   Pushes new node to the front of the linked list
 * arguments: Character
 * returns:   Nothing
 * effects:   Pushes node to the front of the LinkedList
 */
void CharLinkedList::pushAtFront(char c) {
    CharNode* newLetterNode = makeNewNode(c, nullptr, nullptr);
    
    if (front == nullptr) { 
        front = newLetterNode; 
        end = newLetterNode; 
    } else { 
        newLetterNode->next = front; 
        front->previous = newLetterNode; 
        front = newLetterNode; 
    }

    sizes++; 
}


/* name: toString
 * purpose: Turns the LinkedList into a string, and returns it
 * arguments: None
 * returns: A string representation of the Linked List
 * effect: Makes the CharLinkedList into a printable string
 */ 
std::string CharLinkedList::toString() const {
    std::stringstream ss;
    ss << "[CharLinkedList of size " << this->sizes << " <<"; 

    CharNode *temp = this->front; 
    while (temp != nullptr){
        ss << temp->letter; 
        temp = temp->next;
    }

    ss << ">>]";

    return ss.str();
}

/* name: toReverseString
 * purpose: Reverse the order of a string
 * arguments: None
 * returns: A string with the characters of the CharLinkedList in reverse
 * effect: Makes the CharLinkedList into a printable reverse string
 */ 
std::string CharLinkedList::toReverseString() const{
    std::stringstream ss;
    ss << "[CharLinkedList of size " << this->sizes << " <<"; 

    CharNode *temp = this->end; 

    while (temp != nullptr){
        ss << temp->letter; 
        temp = temp->previous;
    }

    ss << ">>]";

    return ss.str();
}

/* name: elemAt-Helper
 * purpose: Report the state of the list as a string
 * arguments: Current node, the target index, and the current index 
 * returns: A string with the state of the list
 * effects: Helper function to help with locating desired element at index, 
 *          returns range error if the element at the index is out of range
 */ 
char CharLinkedList::elemAtHelp(
    CharNode *node, int tgtIndex, int currIndex) const {
    
    if (node == nullptr) { 
        throw std::range_error("Reached end of list unexpectedly");
    }
    if (currIndex == tgtIndex) {
        return node->letter;
    }
    return elemAtHelp(node->next, tgtIndex, currIndex + 1);
}


/* name: getNodeHelper
* purpose: Recursively retrieves a node at a specified index in the 
*           CharLinkedList.
* arguments:A pointer to the current node being used in the recursion,
*            integer index that is 0-based 
* returns: Pointer to the node at the specified index 
*           within the list.
* effects: A Helper function to help get the next node in LinkedList
*/ 
CharLinkedList::CharNode*
CharLinkedList::getNodeHelper(CharNode* node, int index) const {
    if (index == 0) {
        return node;
    }
    return getNodeHelper(node->next, index - 1);
}

/********************************************************************\
*                       ADDITIONAL FUNCTIONS                     *
\********************************************************************/


/* name:isEmpty
 * purpose: Checking if our list is empty
 * arguments: None
 * returns: Returns a boolean value is Linked list is empty or not
 * effect: Checks if list is empty
 */ 

bool CharLinkedList::isEmpty(){
    return front == nullptr;
}

/* name: clear
 * purpose: Clears out list 
 * arguments: None
 * returns: None
 * effect: Create a temp pointer to loop through the list and delete 
 */ 
void CharLinkedList::clear() {

    CharNode *temp = front;

    while (temp != nullptr) {
        CharNode *next = temp->next;
        delete temp;
        temp = next;
    }
   
    //Reset everything
    front = nullptr;
    end = nullptr;
    sizes = 0; 
}

/* name: size
 * purpose: returns the number of characters in the list
 * arguments: None
 * returns: Returns an integer
 * effects: Returns the size
 */
int CharLinkedList::size() const{
    return sizes;
}


/* name: first
 * purpose: Returns the first element (char) in the list
 * arguments: None
 * returns: Returns a character
 * efffect: Returns the first element (char) in the list
 */
char CharLinkedList::first() const { 
   
    if (front != nullptr){
       return front->letter;
    }  else {
        throw std::runtime_error("cannot get first of empty LinkedList");
    }
}

/* name:last
 * purpose: Returns the last element (char) in the list
 * argument: None
 * returns: Character
 * effects: Returns the last element (char) in the list
 */ 
char CharLinkedList::last() const {
 
    if (end != nullptr){
       return end->letter;
    }  else {
        throw std::runtime_error("cannot get last of empty LinkedList");
    }

}

/* size:elementAt
 * purpose: Returns the the element (char) at a desired index in the list
 * argument: Index position
 * returns: Character
 * effect: Gets and retuns the element at a desired index position
 */ 
char CharLinkedList::elementAt(int index) const {
    
    if (index < 0 or index >= sizes) {
        throw std::range_error("index (" + std::to_string(index) 
        + ") not in range [0.." + std::to_string(sizes) + ")");
    }
    return elemAtHelp(front, index, 0);
}

/* name:insertAt
 * purpose: Inserts the new element at the specified index
 * argument: Takes an element (char) and an integer index 
 * returns: Character
 * effect: Insert character at a desired index position
 */
void CharLinkedList::insertAt(char c, int index){
    if (index < 0 or index > sizes) {
        throw std::range_error("index (" + std::to_string(index) 
        + ") not in range [0.." + std::to_string(sizes) + "]");
    }

    if (index == 0){
        pushAtFront(c);
        return;
    } else if (index == sizes){
        pushAtBack(c);
        return; 
    }

    CharNode *beforeNode = getNodeAtIndex(index - 1);
    CharNode *afterNode = beforeNode->next;
    CharNode *newLetterNode = makeNewNode(c, beforeNode, afterNode);

    //Updating pointers to now include the new letter node
    beforeNode->next = newLetterNode;
    if (afterNode != nullptr) { // If inserting before the last element
        afterNode->previous = newLetterNode;
    }
    sizes++; 
}

/* name: insertInOrder
 * purpose: Inserts the new element at the specified index by ASCII order
 * arguments: Takes in a character
 * returns: None
 * effect: Inserts the character in order 
 */ 
void CharLinkedList::insertInOrder(char c){

    if (front == nullptr or c <= front->letter) {
        pushAtFront(c);
        return;
    }

    if (c >= end->letter) {
        pushAtBack(c);
        return;
    }

    CharNode* temp = front;
    int index = 0;
    while (temp != nullptr and c > temp->letter) {
        temp = temp->next;
        index++;
    }
    insertAt(c, index);
}

/* name:popFromFront
 * purpose: Removes the new element at the specified index by ASCII order
 * parameters: No parameters 
 * returns: Nothing
 * effect: Removes the node containing the variable at the front
 */ 
void CharLinkedList::popFromFront(){
    
    if (front == nullptr){
        throw std::runtime_error("cannot pop from empty LinkedList"); 
    } else {

        CharNode *temp = front;
        front = front->next;

        if (front != nullptr) {
            front->previous = nullptr;
        } else {
            end = nullptr;  // Update tail when the list becomes empty
        }

        sizes--; 
        delete temp;
    }
}

/* name:popFromBack
 * purpose: Removes the new element at the specified index by ASCII order
 * parameters: No parameters 
 * returns: Nothing
 * effect: Removes the node containing the variable at the back
 */ 
void CharLinkedList::popFromBack(){

    if (end == nullptr){
        throw std::runtime_error("cannot pop from empty LinkedList"); 
    } else {

        CharNode *temp = end;
        end = end->previous;

        if (end != nullptr) {
            end->next = nullptr;
        } else {
            front = nullptr;  // Update front when the list becomes empty
        }

        sizes--; 
        delete temp;
    }
}

/* name: removeAt
 * purpose: Removes the new element at the specified index 
 * parameters: Index
 * returns: Nothing
 * effect: Removes the node containing the variable at the specified index
 */ 
void CharLinkedList::removeAt(int index) {

    if (index < 0 or index >= sizes) {
        throw std::range_error("index (" + std::to_string(index) 
        + ") not in range [0.." + std::to_string(sizes) + ")");
    }

    //If front, or back
    if (index == 0){
        popFromFront();
        return;
    } else if (index == sizes-1){
        popFromBack();
        return;
    }

    CharNode *delNode = getNodeAtIndex(index);
    CharNode *beforeNode = delNode->previous;
    CharNode *afterNode = delNode->next;

    beforeNode->next = afterNode;
    afterNode->previous = beforeNode;

    delete delNode;
    sizes--;
}

/* name: getNodeAtIndex
*  purpose: Get a node at a specified index
*  arguments: an integer index
*  returns: pointer to specified node at index of list
*  effect: Helper function to get a node at a specific index
*/ 
CharLinkedList::CharNode*
CharLinkedList::getNodeAtIndex(int index){
    if (index < 0 or index >= sizes) {
        throw std::range_error("index (" + std::to_string(index) 
        + ") not in range [0.." + std::to_string(sizes) + ")");
    }

    return getNodeHelper(front, index);

}

/* name replaceAt
*  purpose: Get a character at specified index 
*  arguments: A character c and an index
*  returns: None 
*  effect: Replaces the letter at the index position with given letter
*/
void CharLinkedList::replaceAt(char c, int index){
    if (index < 0 or index >= sizes) {
        throw std::range_error("index (" + std::to_string(index) 
        + ") not in range [0.." + std::to_string(sizes) + ")");
    }

    CharNode* nodeToReplace = getNodeAtIndex(index);
    nodeToReplace->letter = c;

}

/* name: concatenate
*  purpose: Adds another list onto another
*  arguments: A pointer to a linked list
*  returns: Nothing 
*  effect: Joins two lists together
*/
void CharLinkedList::concatenate(CharLinkedList *other){

    int loopCount = other->size();
    CharNode *temp = other->front;
    for (int i = 0; i < loopCount; i++){
        this->pushAtBack(temp->letter);
        temp = temp->next;
    }

}
/*
 *  unit_tests.h
 *  Diwei Chen
 *  Feb 4, 2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  The purpose of this file is to conduct unit test on each funcion in 
 *  implementation
 */

#include "CharLinkedList.h"
#include <iostream>
#include <cassert>
using namespace std;


void testConcatenate(){
    char arr2[] = {'a', 'b', 'c', 'd'};
    CharLinkedList list2(arr2, 4);
    char arr3[] = {'x', 'y', 'z'};
    CharLinkedList list3(arr3, 3);
    list2.concatenate(&list3);
    cout << list2.toString() << "\n";

    list2.concatenate(&list2);
    cout << list2.toString() << "\n";

    CharLinkedList listEmpty;
    list2.concatenate(&listEmpty);
    cout << list2.toString() << "\n";

}

//test assignment operator
void testAssignemntOpe(){
    char arr2[] = {'a', 'b', 'c', 'd'};
    CharLinkedList list2(arr2, 4);
    char arr3[] = {'a', 'b', 'c'};
    CharLinkedList list3(arr3, 3); 
    
    list2 = list2;
    cout << list2.toString() << "\n";
    list2 = list3;
    cout << list2.toString() << "\n";

    CharLinkedList listEmpty;
    list2 = listEmpty;
    cout << list2.toString() << "\n";

}

// test deepcopy constructor
void testDeepCopy(){
    char arr2[] = {'a', 'b', 'c', 'd'};
    CharLinkedList list2(arr2, 4);
    CharLinkedList listDeepCopy(list2);
    cout << list2.toString() << "\n";
    cout << listDeepCopy.toString() << "\n";

    listDeepCopy.popFromFront();
    cout << list2.toString() << "\n";
    cout << listDeepCopy.toString() << "\n";

}
void testRemoveAt(){
    CharLinkedList listEmpty;
    cout << listEmpty.toString() << "\n";
    try{
        listEmpty.removeAt(0);
        cout << listEmpty.toString() << "\n";
    }
    catch(range_error& e){
        cerr << e.what() << "\n";
    }
    try{
        listEmpty.removeAt(3);
        cout << listEmpty.toString() << "\n";
    }
    catch(range_error& e){
        cerr << e.what() << "\n";
    }
    
    char arr2[] = {'a', 'b', 'c', 'd'};
    CharLinkedList list2(arr2, 4);
    try{
        list2.removeAt(2);
        cout << list2.toString() << "\n";
    }
    catch(range_error& e){
        cerr << e.what() << "\n";
    }
    try{
        list2.removeAt(0);
        cout << list2.toString() << "\n";
    }
    catch(range_error& e){
        cerr << e.what() << "\n";
    }
    //now it is {'b', 'd'}
    try{
        list2.removeAt(1);
        cout << list2.toString() << "\n";
    }
    catch(range_error& e){
        cerr << e.what() << "\n";
    }
    try{
        list2.removeAt(0);
        cout << list2.toString() << "\n";
    }
    catch(range_error& e){
        cerr << e.what() << "\n";
    }
    try{
        list2.removeAt(2);
        cout << list2.toString() << "\n";
    }
    catch(range_error& e){
        cerr << e.what() << "\n";
    }
}

void testInsertInOrder(){
    CharLinkedList listEmpty;
    cout << listEmpty.toString() << "\n";
    listEmpty.insertInOrder('a');
    cout << listEmpty.toString() << "\n";
    listEmpty.insertInOrder('c');
    cout << listEmpty.toString() << "\n";
    listEmpty.insertInOrder('b');
    cout << listEmpty.toString() << "\n";
    listEmpty.insertInOrder('b');
    cout << listEmpty.toString() << "\n";
    listEmpty.insertInOrder('w');
    cout << listEmpty.toString() << "\n";

}

void testInsertAt(){
    CharLinkedList listEmpty;
    cout << listEmpty.toString() << "\n";
    try{
        listEmpty.insertAt('w', 0);
        cout << listEmpty.toString() << "\n";
    }
    catch(runtime_error& e){
        cerr << e.what() << "\n";
    }    

    char arr2[] = {'a', 'b', 'c', 'd'};
    CharLinkedList list2(arr2, 4);
    try{
        list2.insertAt('w', 2);
        cout << list2.toString() << "\n";
    }
    catch(runtime_error& e){
        cerr << e.what() << "\n";
    }
    char arr3[] = {'a', 'b', 'c', 'd'};
    CharLinkedList list3(arr3, 4);
    try{
        list3.insertAt('w', 4);
        cout << list3.toString() << "\n";
    }
    catch(runtime_error& e){
        cerr << e.what() << "\n";
    }
}
void testClear(){
    CharLinkedList listEmpty;
    cout << listEmpty.toString() << "\n";

    char arr2[] = {'a', 'b', 'c'};
    CharLinkedList list2(arr2, 3);
    cout << list2.toString() << "\n";
    list2.clear();
    cout << list2.toString() << "\n";

}

void testPopBack(){
    CharLinkedList listEmpty;
    try{
        listEmpty.popFromBack();
        cout << listEmpty.toString() << "\n";
    }
    catch(runtime_error& e){
        cerr << e.what() << "\n";
    }
    
    char arr2[] = {'a', 'b', 'c'};
    CharLinkedList list2(arr2, 3);
    cout << list2.toString() << "\n";
    try{
        list2.popFromBack();
        cout << list2.toString() << "\n";
    }
    catch(runtime_error& e){
        cerr << e.what() << "\n";
    }
    try{
        list2.popFromBack();
        cout << list2.toString() << "\n";
    }
    catch(runtime_error& e){
        cerr << e.what() << "\n";
    }
    try{
        list2.popFromBack();
        cout << list2.toString() << "\n";
    }
    catch(runtime_error& e){
        cerr << e.what() << "\n";
    }    
    try{
        list2.popFromBack();
        cout << list2.toString() << "\n";
    }
    catch(runtime_error& e){
        cerr << e.what() << "\n";
    }
}

void testPopFront(){
    CharLinkedList listEmpty;
    try{
        listEmpty.popFromFront();
        cout << listEmpty.toString() << "\n";
    }
    catch(runtime_error& e){
        cerr << e.what() << "\n";
    }
    
    char arr2[] = {'a', 'b', 'c'};
    CharLinkedList list2(arr2, 3);
    cout << list2.toString() << "\n";
    try{
        list2.popFromFront();
        cout << list2.toString() << "\n";
    }
    catch(runtime_error& e){
        cerr << e.what() << "\n";
    }
    try{
        list2.popFromFront();
        cout << list2.toString() << "\n";
    }
    catch(runtime_error& e){
        cerr << e.what() << "\n";
    }
    try{
        list2.popFromFront();
        cout << list2.toString() << "\n";
    }
    catch(runtime_error& e){
        cerr << e.what() << "\n";
    }    
    try{
        list2.popFromFront();
        cout << list2.toString() << "\n";
    }
    catch(runtime_error& e){
        cerr << e.what() << "\n";
    }
}

//test replaceAt
void testReplace(){
    CharLinkedList listEmpty;
    try{
        listEmpty.replaceAt('w', 0);
        cout << listEmpty.toString() << "\n";
    }
    catch(runtime_error& e){
        cerr << e.what() << "\n";
    }

    char arr2[] = {'a', 'b', 'c', 'd'};
    CharLinkedList list2(arr2, 4);
    try{
        list2.replaceAt('w', 0);
        cout << list2.toString() << "\n";
    }
    catch(runtime_error& e){
        cerr << e.what() << "\n";
    }
    try{
        list2.replaceAt('w', 3);
        cout << list2.toString() << "\n";
    }
    catch(runtime_error& e){
        cerr << e.what() << "\n";
    }
    try{
        list2.replaceAt('w', 4);
        cout << list2.toString() << "\n";
    }
    catch(runtime_error& e){
        cerr << e.what() << "\n";
    }
}

//test testElemAt
void testElemAt(){
    CharLinkedList listEmpty;
    try{
        cout << listEmpty.elementAt(0) << "\n";
    }
    catch(runtime_error& e){
        cerr << e.what() << "\n";
    }
    try{
        cout << listEmpty.elementAt(1) << "\n";
    }
    catch(runtime_error& e){
        cerr << e.what() << "\n";
    }

    char arr2[] = {'a', 'b', 'c', 'd'};
    CharLinkedList list2(arr2, 4);
    std::cout << list2.elementAt(0) << "\n";
    std::cout << list2.elementAt(3) << "\n";
    try{
        cout << list2.elementAt(3) << "\n";
    }
    catch(range_error& e){
        cerr << e.what() << "\n";
    }    
    try{
        cout << list2.elementAt(4) << "\n";
    }
    catch(range_error& e){
        cerr << e.what() << "\n";
    }

    CharLinkedList list5('k');
    std::cout << list5.elementAt(0) << "\n";
    try{
        cout << list5.elementAt(1) << "\n";
    }
    catch(range_error& e){
        cerr << e.what() << "\n";
    }    
    try{
        cout << list5.elementAt(-1) << "\n";
    }
    catch(range_error& e){
        cerr << e.what() << "\n";
    }
}

//test first and last function
void testFirstLast(){
    CharLinkedList listEmpty;
    try{
        cout << listEmpty.first() << "\n";
    }
    catch(runtime_error& e){
        cerr << e.what() << "\n";
    }
    try{
        cout << listEmpty.last() << "\n";
    }
    catch(runtime_error& e){
        cerr << e.what() << "\n";
    }

    char arr2[] = {'t', 'b', 'c', 'd'};
    CharLinkedList list2(arr2, 4);
    std::cout << list2.first() << "\n";
    std::cout << list2.last() << "\n";

    CharLinkedList list5('k');
    std::cout << list5.first() << "\n";
    std::cout << list5.last() << "\n";
}

//test to ReverseString and isEmpty
void testToRevString(){
    std::cout << "united test hooked up succeasfully!" << "\n";
    // CharLinkedList list0;

    char arr2[] = {'t', 'b', 'c', 'd'};
    CharLinkedList list4(arr2, 4);
    std::cout << list4.toReverseString() << "\n";
    CharLinkedList list5('k');
    std::cout << list5.toReverseString() << "\n";
    std::cout << CharLinkedList().toReverseString() << "\n";

    std::cout << list4.isEmpty() << "\n";
    std::cout << list5.isEmpty() << "\n";
    std::cout << CharLinkedList().isEmpty() << "\n";
}

// test default constructor
void testA(){
    CharLinkedList();
    std::cout << "united test hooked up succeasfully!" << "\n";
}

//test (char c), (char arr[], size), tostring
void testToString(){
    char arr[] = {'a', 'b', 'c', 'd'};
    CharLinkedList list1(arr, 4);
    std::cout << list1.toString() << "\n";
    CharLinkedList list2('w');
    std::cout << list2.toString() << "\n";
    std::cout << CharLinkedList().toString() << "\n";
}

//test push front and back
void testPushFront(){
    char arr[] = {'a', 'b', 'c', 'd'};
    CharLinkedList list1(arr, 4);
    // std::cout << "the size is " << list1.size() << "\n";
    std::cout << list1.toString() << "\n";
    list1.pushAtFront('y');
    list1.pushAtBack('p');
    std::cout << list1.toString() << "\n";

    CharLinkedList listEmpty;
    listEmpty.pushAtFront('k');
    std::cout << listEmpty.toString() << "\n";

    CharLinkedList listEmpty2;
    listEmpty2.pushAtBack('w');
    std::cout << listEmpty2.toString() << "\n";
}




/*
 *  CharLinkedList.cpp
 *  Diwei Chen
 *  Feb 4, 2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  implementation of linkedlist
 *
 */

#include "CharLinkedList.h"
#include <iostream>
using namespace std;

CharLinkedList::CharLinkedList()
{
    front = nullptr;
    back = nullptr;
}

// helper to make and place a new Node
CharLinkedList::Node *CharLinkedList::makeNewNode(char c, Node *prev, Node *next)
{
    Node *newNode = new Node;
    newNode->data = c;
    newNode->prev = prev;
    newNode->next = next;
    return newNode;
}

CharLinkedList::CharLinkedList(char c)
{
    front = makeNewNode(c, nullptr, nullptr);
    back = front;
}
CharLinkedList::CharLinkedList(char arr[], int size)
{
    front = nullptr;
    back = nullptr;
        // for each char, call push at back
    for (int i = 0; i < size; i++){
        pushAtBack(arr[i]);
    }
}
CharLinkedList::CharLinkedList(const CharLinkedList &other)
{
    front = nullptr;
    back = nullptr;
    if (other.front == nullptr){
        return;
    }
    else{
        for (int i = 0; i < other.size(); i++){
            pushAtBack(other.elementAt(i));
        }
    }
}
CharLinkedList::~CharLinkedList()
{
    //manually delete each node
    //This function must use a private recursive helper function.
    recycleRecursively(front);
}
// private helper
void CharLinkedList::recycleRecursively(Node *curr)
{
    if (curr == nullptr)
    {
        return;
    }
    else
    {
        Node *curr2 = curr->next;
        if (curr2 != nullptr){
            curr2->prev = curr->prev;
        }
        delete curr;
        recycleRecursively(curr2);
    }
}
CharLinkedList& CharLinkedList::operator=(const CharLinkedList &other)
{
    if (this == &other){
        return *this;
    }
    clear();
    for (int i = 0; i < other.size(); i++){
        pushAtBack(other.elementAt(i));
    }
    return *this;
} 
bool CharLinkedList::isEmpty() const
{
    if (size() == 0){
        return true;
    }
    else{
        return false;
    }
}
void CharLinkedList::clear()
{
    while(front != nullptr){
        popFromBack();
    }
}
int CharLinkedList::size() const
{
    int t = 0;
    Node *temp = front;
    if (temp == nullptr){
        return t;
    }
    t += 1;
    while (temp->next != nullptr){
        t += 1;
        temp = temp->next;
    }
    return t;
}
char CharLinkedList::first() const
{
    if (size() == 0){
        throw std::runtime_error("cannot get first of empty LinkedList");
    }
    // print front node data
    return front->data;
}
char CharLinkedList::last() const
{
    if (size() == 0){
        throw std::runtime_error("cannot get last of empty LinkedList");
    }
    // print front node data
    return back->data;
}
char CharLinkedList::elementAt(int index) const
{
    if (index > size() - 1 || index < 0 || size() == 0){
        throw std::range_error(
            "index (" + std::to_string(index) 
            + ") not in range [0.." + std::to_string(size()) +")");
    }
    //if in bound, do the loop
    return findElemRecursive(index, front);
}
char CharLinkedList::findElemRecursive(int index, Node *temp) const
{
    if (index == 0){
        return temp->data;
    }
    else{
        int step_left = index - 1;
        Node *new_temp = temp->next;
        return findElemRecursive(step_left, new_temp);
    }
}

std::string CharLinkedList::toString() const
{
    if(size() == 0){
        return "[CharLinkedList of size 0 <<>>]";
    }
    else{
        string s = "[CharLinkedList of size ";
        s += std::to_string(size());
        s += " <<";

        Node *temp = front;
        for (int i = 0; i < size(); i++){
            s = s + temp->data;
            temp = temp->next;
        }
        s += ">>]";
        return s;
    }
}
std::string CharLinkedList::toReverseString() const
{
    if(size() == 0){
        return "[CharLinkedList of size 0 <<>>]";
    }
    else{
        string s = "[CharLinkedList of size ";
        s += std::to_string(size());
        s += " <<";

        Node *temp = back;
        for (int i = 0; i < size(); i++){
            s = s + temp->data;
            temp = temp->prev;
        }
        s += ">>]";
        return s;
    }        
}
void CharLinkedList::pushAtBack(char c)
{
    
    if (back == nullptr){
        back = makeNewNode(c, nullptr, nullptr);
        front = back;
    }
    else{
        back->next = makeNewNode(c, back, nullptr);
        back = back->next;
    }
}
void CharLinkedList::pushAtFront(char c)
{
    if (back == nullptr){
        back = makeNewNode(c, nullptr, nullptr);
        front = back;
    }
    else{
        front->prev = makeNewNode(c, nullptr, front);
        front = front->prev;
    }
}
void CharLinkedList::insertAt(char c, int index)
{
    if (index > size() || index < 0){
        throw std::range_error(
            "index (" + std::to_string(index) 
            + ") not in range [0.." + std::to_string(size()) +"]");
    }
    if (index == 0){
        pushAtFront(c);
    }
    else if(index == size()){
        pushAtBack(c);
    }    
    else {
        Node *target = findReplaceRecursive(index, front);
        //add a new node and change the before and after
        Node *newNode = makeNewNode(c, target->prev, target);
        target->prev->next = newNode;
        target->prev = newNode;
    }
}
void CharLinkedList::insertInOrder(char c)
{
    if (front == nullptr){
        pushAtFront(c);
    }
    else{
        int counter = 0;
        Node *temp = front;
        while (c > temp->data){
            counter += 1;
            temp = temp->next;
            if (temp == nullptr)
                break;
        }
        insertAt(c, counter);
    }
}
void CharLinkedList::popFromFront()
{
    if (size() == 0){
        throw std::runtime_error("cannot pop from empty LinkedList");
    }
    Node *temp = front;
    front = front->next;
    delete temp;
    if (front == nullptr){
        back = nullptr;
        return;
    }
    else{
        front->prev = nullptr;
    }
}
void CharLinkedList::popFromBack()
{
    if (size() == 0){
        throw std::runtime_error("cannot pop from empty LinkedList");
    }
    Node *temp = back;
    back = back->prev;
    delete temp;
    if (back == nullptr){
        front = nullptr;
        return;
    }
    else{
        back->next = nullptr;
    }   
}
void CharLinkedList::removeAt(int index)
{
    if (index > size() - 1 || index < 0 || size() == 0){
        throw std::range_error(
            "index (" + std::to_string(index) 
            + ") not in range [0.." + std::to_string(size()) +")");
    }
    if (index == 0){
        popFromFront();
    }
    else if (index == size() - 1){
        
        popFromBack();
    }
    else{
    Node *target = findReplaceRecursive(index, front);
    target->prev->next = target->next;
    target->next->prev = target->prev;
    delete target;
    }
}
void CharLinkedList::replaceAt(char c, int index)
{
    if (index > size() - 1 || index < 0 || size() == 0){
        throw std::range_error(
            "index (" + std::to_string(index) 
            + ") not in range [0.." + std::to_string(size()) +")");
    }
    Node *target = findReplaceRecursive(index, front);
    target->data = c;
}

//a helper function to locate the index-th node
CharLinkedList::Node *CharLinkedList::findReplaceRecursive(int step, Node *temp) const
{
    if (step == 0){
        // cout << "here is elemAt char: " 
        // << temp->data << "\n";
        return temp;
    }
    else{
        int step_left = step - 1;
        // cout << "step left: " << step_left << "\n";
        Node *new_temp = temp->next;
        return findReplaceRecursive(step_left, new_temp);
    }
}
void CharLinkedList::concatenate(CharLinkedList *other)
{
    if (other->isEmpty()){
        return;
    }
    else if(this == other){
        int t = size();
        char arr[t];
        for (int i = 0; i < t; i++){
            arr[i] = elementAt(i);
        }
        for (int i = 0; i < t; i++){
            pushAtBack(arr[i]);
        }
    }
    else{
        for (int i = 0; i < other->size(); i++){
            // cout << other->elementAt(i) << "\n";
            pushAtBack(other->elementAt(i));
        }
    }
}


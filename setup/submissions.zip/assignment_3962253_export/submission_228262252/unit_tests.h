/*
 *  unit_tests.h
 *  Aahan Mehra
 *  2/1/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to linked up in Fur
 *
 *  This file contains unit tests for the CharArrayList class.
 *  The purpose of these tests is to thoroughly validate the functionality of 
 *  the CharLinkedList class and ensure that it behaves as expected under 
 *  various scenarios and edge cases. These tests cover constructors, 
 *  assignment operators, insertion, removal, replacement, concatenation, and 
 *  other Operations provided by the CharLinkedList class.
 *
 */

#include "CharLinkedList.h"
#include <cassert>

void default_constructor() {
    CharLinkedList test_list;
}

void char_single_character_constructor() {
    // Create a CharLinkedList with a single character 'a'
    CharLinkedList test_list('a');

    // Check if the size of the list is 1
    assert(test_list.size() == 1);

    // Check if the first element is 'a'
    assert(test_list.elementAt(0) == 'a');
}

void char_array_constructor() {
    // Create an array of characters
    char arr[] = {'a', 'b', 'c', 'd', 'e'};

    // Create a CharLinkedList from the array
    CharLinkedList test_list(arr, 5);

    // Check if the size of the list matches the size of the array
    assert(test_list.size() == 5);

    // Check if the elements in the list match the elements in the array
    for (int i = 0; i < 5; i++) {
        assert(test_list.elementAt(i) == arr[i]);
    }
}

void copy_constructor_empty_list() {
    CharLinkedList original;
    CharLinkedList copy(original);
    assert(copy.isEmpty());
    assert(copy.size() == 0);
}

void copy_constructor_single_element_list() {
    CharLinkedList original('a');
    CharLinkedList copy(original);
    assert(copy.size() == 1);
    assert(copy.elementAt(0) == 'a');
}

void copy_constructor_multi_element_list() {
    char arr[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList original(arr, 5);
    CharLinkedList copy(original);
    assert(copy.size() == 5);
    for (int i = 0; i < 5; i++) {
        assert(copy.elementAt(i) == original.elementAt(i));
    }
}

void assignment_operator() {
    char arr[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list1(arr, 5);
    CharLinkedList list2;
    list2 = list1; // Perform assignment
    
    // Check if sizes are equal
    assert(list1.size() == list2.size());

    // Check if elements are equal
    for (int i = 0; i < list1.size(); i++) {
        assert(list1.elementAt(i) == list2.elementAt(i));
    }
}

void isEmpty_empty_list() {
    CharLinkedList test_list;
    assert(test_list.isEmpty());
}

void isEmpty_non_empty_list() {
    CharLinkedList test_list('a');
    assert(not test_list.isEmpty());
}

void clear_list() {
    char arr[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList test_list(arr, 5);
    test_list.clear();
    assert(test_list.isEmpty());
}

void size_empty_list() {
    // Create an empty CharLinkedList
    CharLinkedList test_list;

    // Check if the size of the empty list is 0
    assert(test_list.size() == 0);
}

void size_nonempty_list() {
    // Create a non-empty CharLinkedList with 5 characters
    char arr[] = {'a', 'b', 'c', 'd', 'e'};

    // Create a CharLinkedList from the array
    CharLinkedList test_list(arr, 5);

    // Check if the size of the list is 5
    assert(test_list.size() == 5);
}

void first_empty_list() {
    CharLinkedList test_list;
    try {
        test_list.first();
        // If no exception is thrown, the test fails
        assert(false);
    } catch (const std::runtime_error &e) {
        assert(std::string(e.what()) == 
        "cannot get first of empty LinkedList");
    }
}

void first_non_empty_list() {
    CharLinkedList test_list('a');
    assert(test_list.first() == 'a');
}

void last_empty_list() {
    CharLinkedList test_list;
    try {
        test_list.last();
        // If no exception is thrown, the test fails
        assert(false);
    } catch (const std::runtime_error &e) {
        assert(std::string(e.what()) == 
        "cannot get last of empty LinkedList");
    }
}

void last_non_empty_list() {
    char arr[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList test_list(arr, 5);
    assert(test_list.last() == 'e');
}

void elementAt_valid_index() {
    char arr[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList test_list(arr, 5);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(2) == 'c');
    assert(test_list.elementAt(4) == 'e');
}

void elementAt_invalid_index() {
    char arr[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList test_list(arr, 5);
    bool exception_thrown = false;
    try {
        test_list.elementAt(5);
    } catch (const std::range_error& e) {
        // Verify that the correct exception message is thrown
        std::string expected_message = "index (5) not in range [0..5)";
        assert(e.what() == expected_message);
        exception_thrown = true;
    }
    assert(exception_thrown);
}

void elementAt_negative_index() {
    char arr[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList test_list(arr, 5);
    bool exception_thrown = false;
    try {
        test_list.elementAt(-1);
    } catch (const std::range_error& e) {
        // Verify that the correct exception message is thrown
        std::string expected_message = "index (-1) not in range [0..5)";
        assert(e.what() == expected_message);
        exception_thrown = true;
    }
    assert(exception_thrown);
}

void toString_empty_list() {
    CharLinkedList test_list;
    assert(test_list.toString() == "[CharLinkedList of size 0 <<>>]");
}

void toString_single_element_list() {
    CharLinkedList test_list('a');
    assert(test_list.toString() == "[CharLinkedList of size 1 <<a>>]");
}

void toString_nonempty_list() {
    char arr[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList test_list(arr, 5);
    assert(test_list.toString() == "[CharLinkedList of size 5 <<abcde>>]");
}

void toReverseString_empty_list() {
    CharLinkedList test_list;
    assert(test_list.toReverseString() == "[CharLinkedList of size 0 <<>>]");
}

void toReverseString_single_element_list() {
    CharLinkedList test_list('a');
    assert(test_list.toReverseString() == "[CharLinkedList of size 1 <<a>>]");
}

void toReverseString_multi_element_list() {
    char arr[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList test_list(arr, 5);
    assert(test_list.toReverseString() == 
    "[CharLinkedList of size 5 <<edcba>>]");
}


// Unit test for pushAtBack function with an empty list
void pushAtBack_empty_list() {
    CharLinkedList test_list;
    test_list.pushAtBack('a');
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');
}

// Unit test for pushAtBack function with a non-empty list
void pushAtBack_non_empty_list() {
    char arr[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList test_list(arr, 5);
    test_list.pushAtBack('f');
    assert(test_list.size() == 6);
    assert(test_list.elementAt(5) == 'f');
}

// Unit test for pushAtFront function with an empty list
void pushAtFront_empty_list() {
    CharLinkedList test_list;
    test_list.pushAtFront('a');
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');
}

// Unit test for pushAtFront function with a non-empty list
void pushAtFront_non_empty_list() {
    char arr[] = {'b', 'c', 'd', 'e', 'f'};
    CharLinkedList test_list(arr, 5);
    test_list.pushAtFront('a');
    assert(test_list.size() == 6);
    assert(test_list.elementAt(0) == 'a');
}

// Tests correct insertion into an empty AL.
// Afterwards, size should be 1 and element at index 0
// should be the element we inserted.
void insertAt_empty_correct() { 

    CharLinkedList test_list;
    test_list.insertAt('a', 0);
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');

}

// Tests incorrect insertion into an empty AL.
// Attempts to call insertAt for index larger than 0.
// This should result in an std::range_error being raised.
void insertAt_empty_incorrect() {

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    CharLinkedList test_list;
    try {
        // insertAt for out-of-range index
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        // if insertAt is correctly implemented, a range_error will be thrown,
        // and we will end up here
        range_error_thrown = true;
        error_message = e.what();
    }

    // out here, we make our assertions
    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..0]");
    
}

// Tests correct insertAt for front of 1-element list.
void insertAt_front_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at front
    test_list.insertAt('b', 0);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'b');
    assert(test_list.elementAt(1) == 'a');
    
}

// Tests correct insertAt for back of 1-element list.
void insertAt_back_singleton_list() {
    
    // initialize 1-element list
    CharLinkedList test_list('a');

    // insert at back
    test_list.insertAt('b', 1);

    assert(test_list.size() == 2);
    assert(test_list.elementAt(0) == 'a');
    assert(test_list.elementAt(1) == 'b');
    
}

// Tests calling insertAt for a large number of elements.
// Not only does this test insertAt, it also checks that
// array expansion works correctly.
void insertAt_many_elements() {
    
    CharLinkedList test_list;

    // insert 1000 elements
    for (int i = 0; i < 1000; i++) {
        // always insert at the back of the list
        test_list.insertAt('a', i);
    }

    assert(test_list.size() == 1000);

    for (int i = 0; i < 1000; i++) {
        assert(test_list.elementAt(i) == 'a');
    }
    
}

// Tests insertion into front of a larger list
void insertAt_front_large_list() {
    char test_arr[9] = { 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 9);

    test_list.insertAt('y', 0);

    assert(test_list.size() == 10);
    assert(test_list.elementAt(0) == 'y');
    assert(test_list.toString() == 
    "[CharLinkedList of size 10 <<yabczdefgh>>]");

}

// Tests insertion into the back of a larger list
void insertAt_back_large_list() {

    char test_arr[10] = { 'y', 'a', 'b', 'c', 'z', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 10);  

    test_list.insertAt('x', 10);

    assert(test_list.size() == 11);
    assert(test_list.elementAt(10) == 'x');
    assert(test_list.toString() == 
    "[CharLinkedList of size 11 <<yabczdefghx>>]"); 

}

// Tests insertion into the middle of a larger list
void insertAt_middle_large_list() {
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    test_list.insertAt('z', 3);

    assert(test_list.size() == 9);
    assert(test_list.elementAt(3) == 'z');
    assert(test_list.toString() == "[CharLinkedList of size 9 <<abczdefgh>>]");

}

// Tests out-of-range insertion for a non-empty list.
void insertAt_nonempty_incorrect() {
   
    char test_arr[8] = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h' };
    CharLinkedList test_list(test_arr, 8);

    // var to track whether range_error is thrown
    bool range_error_thrown = false;

    // var to track any error messages raised
    std::string error_message = "";

    try {
        test_list.insertAt('a', 42);
    }
    catch (const std::range_error &e) {
        range_error_thrown = true;
        error_message = e.what();
    }

    assert(range_error_thrown);
    assert(error_message == "index (42) not in range [0..8]");
}

// Test insertInOrder with an empty list
void insertInOrder_empty_list() {
    CharLinkedList test_list;
    test_list.insertInOrder('a');
    assert(test_list.size() == 1);
    assert(test_list.elementAt(0) == 'a');
}

// Test insertInOrder with a non-empty list
void insertInOrder_non_empty_list() {
    char arr[] = {'a', 'b', 'd', 'e', 'f'};
    CharLinkedList test_list(arr, 5);
    test_list.insertInOrder('c');
    assert(test_list.size() == 6);
    assert(test_list.toString() == "[CharLinkedList of size 6 <<abcdef>>]");
}

// Test popFromFront with non-empty list
void popFromFront_non_empty() {
    char arr[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList test_list(arr, 5);
    test_list.popFromFront();
    assert(test_list.size() == 4);
    assert(test_list.toString() == "[CharLinkedList of size 4 <<bcde>>]");
}

// Test popFromFront with empty list
void popFromFront_empty() {
    CharLinkedList test_list;
    try {
        test_list.popFromFront();
    } catch (const std::runtime_error& e) {
        assert(e.what() == std::string("cannot pop from empty LinkedList"));
    }
}

// Test popFromBack with non-empty list
void popFromBack_non_empty() {
    char arr[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList test_list(arr, 5);
    test_list.popFromBack();
    assert(test_list.size() == 4);
    assert(test_list.toString() == "[CharLinkedList of size 4 <<abcd>>]");
}

// Test popFromBack with empty list
void popFromBack_empty() {
    CharLinkedList test_list;
    try {
        test_list.popFromBack();
    } catch (const std::runtime_error& e) {
        assert(e.what() == std::string("cannot pop from empty LinkedList"));
    }
}

// Test removeAt with a valid index
void removeAt_valid_index() {
    char arr[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList test_list(arr, 5);
    test_list.removeAt(2);
    assert(test_list.size() == 4);
    assert(test_list.toString() == "[CharLinkedList of size 4 <<abde>>]");
}

// Test removeAt with index at the beginning of the list
void removeAt_beginning_index() {
    char arr[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList test_list(arr, 5);
    test_list.removeAt(0);
    assert(test_list.size() == 4);
    assert(test_list.toString() == "[CharLinkedList of size 4 <<bcde>>]");
}

// Test removeAt with index at the end of the list
void removeAt_end_index() {
    char arr[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList test_list(arr, 5);
    test_list.removeAt(4);
    assert(test_list.size() == 4);
    assert(test_list.toString() == "[CharLinkedList of size 4 <<abcd>>]");
}

// Test removeAt with index out of range (too small)
void removeAt_out_of_range_small_index() {
    char arr[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList test_list(arr, 5);
    try {
        test_list.removeAt(-1);
    } catch (const std::range_error& e) {
        assert(e.what() == std::string("index (-1) not in range [0..5)"));
    }
}

// Test removeAt with index out of range (too large)
void removeAt_out_of_range_large_index() {
    char arr[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList test_list(arr, 5);
    try {
        test_list.removeAt(5);
    } catch (const std::range_error& e) {
        assert(e.what() == std::string("index (5) not in range [0..5)"));
    }
}


// Tests replacing an element at the front of the list
void replaceAt_front() {
    char arr[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList test_list(arr, 5);

    test_list.replaceAt('f', 0);

    assert(test_list.toString() == "[CharLinkedList of size 5 <<fbcde>>]");
}

// Tests replacing an element in the middle of the list
void replaceAt_middle() {
    char arr[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList test_list(arr, 5);

    test_list.replaceAt('f', 2);

    assert(test_list.toString() == "[CharLinkedList of size 5 <<abfde>>]");
}

// Tests replacing an element at the end of the list
void replaceAt_back() {
    char arr[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList test_list(arr, 5);

    test_list.replaceAt('f', 4);

    assert(test_list.toString() == "[CharLinkedList of size 5 <<abcdf>>]");
}

// Test replacing an element in an empty list (should throw exception)
void replaceAt_empty() {
    CharLinkedList test_list;

    try {
        test_list.replaceAt('f', 0);
        // If the exception isn't thrown, the test failed
        assert(false);
    } catch (const std::range_error &e) {
        assert(std::string(e.what()) == "index (0) not in range [0..0]");
    }
}

// Test replacing an element at an out-of-range index (should throw exception)
void replaceAt_out_of_range() {
    char arr[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList test_list(arr, 5);

    try {
        test_list.replaceAt('f', 10);
        // If the exception isn't thrown, the test failed
        assert(false);
    } catch (const std::range_error &e) {
        assert(std::string(e.what()) == "index (10) not in range [0..5]");
    }
}

// Test concatenating two non-empty lists
void concatenate_non_empty() {
    char arr1[] = {'a', 'b', 'c'};
    CharLinkedList list1(arr1, 3);

    char arr2[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list2(arr2, 5);

    list1.concatenate(&list2);

    assert(list1.toString() == "[CharLinkedList of size 8 <<abcabcde>>]");
}

// Test concatenating an empty list with a non-empty list
void concatenate_empty_with_non_empty() {
    CharLinkedList list1;

    char arr2[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list2(arr2, 5);

    list1.concatenate(&list2);

    assert(list1.toString() == "[CharLinkedList of size 5 <<abcde>>]");
}

// Test concatenating a non-empty list with an empty list
void concatenate_non_empty_with_empty() {
    char arr1[] = {'a', 'b', 'c'};
    CharLinkedList list1(arr1, 3);

    CharLinkedList list2;

    list1.concatenate(&list2);

    assert(list1.toString() == "[CharLinkedList of size 3 <<abc>>]");
}

// Test concatenating an empty list with itself
void concatenate_empty_with_itself() {
    CharLinkedList list1;

    list1.concatenate(&list1);

    assert(list1.toString() == "[CharLinkedList of size 0 <<>>]");
}

// Test concatenating a non-empty list with itself
void concatenate_non_empty_with_itself() {
    char arr[] = {'a', 'b', 'c', 'd', 'e'};
    CharLinkedList list1(arr, 5);

    list1.concatenate(&list1);

    assert(list1.toString() == "[CharLinkedList of size 10 <<abcdeabcde>>]");
}

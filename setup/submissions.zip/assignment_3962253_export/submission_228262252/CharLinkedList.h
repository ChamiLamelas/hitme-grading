/*
 *  CharLinkedList.h
 *  Aahan Mehra
 *  02/01/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 * 
 *  This header file declares the CharLinkedList class, representing a linked 
    list of characters.
 *  Instances of CharLinkedList maintain an ordered sequence of characters, 
    allowing clients to add, remove, and manipulate character data dynamically.
 *  Abstract State:
 *  - Each instance represents a sequence of characters, preserving the 
    order of insertion.
 *  Interaction:
 *  - Primarily interacts with client code requiring dynamic management of 
    character sequences.
 *  Common Use Cases:
 *  - Text processing applications, data parsers, algorithms operating on 
    character sequences.
 */

#ifndef CHAR_LINKED_LIST_H
#define CHAR_LINKED_LIST_H

#include <stdexcept>
#include <string>

class CharLinkedList {
private:
    // Private nested struct to represent each node in the linked list
    struct Node {
        char data;
        Node* prev;
        Node* next;

        // Member function to initialize node
        void initialize(char c) {
            data = c;
            prev = nullptr;
            next = nullptr;
        }
    };

    // Private variables
    Node* head;
    Node* tail;
    int csize;

    // Private helper functions
    void recursiveDelete(Node* current);
    char recursiveElementAt(Node* current, int index) const;
    void copyNodesFrom(const CharLinkedList &other);
    void insertNodeAt(char c, Node* current);
    Node* getNodeAt(int index) const;
    void recursiveReplaceAt(Node* current, char c, int index);

public:
    // Constructors
    CharLinkedList();
    CharLinkedList(char c);
    CharLinkedList(char arr[], int size);
    CharLinkedList(const CharLinkedList &other);

    // Destructor
    ~CharLinkedList();

    // Assignment operator
    CharLinkedList& operator=(const CharLinkedList &other);

    // Public member functions
    bool isEmpty() const;
    void clear();
    int size() const;
    char first() const;
    char last() const;
    char elementAt(int index) const;
    std::string toString() const;
    std::string toReverseString() const;
    void pushAtBack(char c);
    void pushAtFront(char c);
    void insertAt(char c, int index);
    void insertInOrder(char c);
    void popFromFront();
    void popFromBack();
    void removeAt(int index);
    void replaceAt(char c, int index);
    void concatenate(CharLinkedList *other);
};

#endif

/*
 *  CharLinkedList.cpp
 *  Aahan Mehra
 *  02/01/2024
 *
 *  CS 15 HW 2 Cheshire ConCATenation - Time to get linked up in Fur
 *
 *  This file contains an implementation of the CharLinkedList class.
 */

#include "CharLinkedList.h"

/*
 * name:      CharLinkedList
 * purpose:   Constructs an empty CharLinkedList object
 * arguments: None
 * returns:   None
 * effects:   Initializes the head and tail pointers to nullptr and sets the 
              current size (csize) to 0.
 */
CharLinkedList::CharLinkedList() {
    head = nullptr;
    tail = nullptr;
    csize = 0;
}

/*
 * name:      CharLinkedList
 * purpose:   Constructs a CharLinkedList object with a single character 
              parameter
 * arguments: a char representing the initial character of the linked list
 * returns:   None
 * effects:   Creates a new node with the given character, sets it as the head 
              and tail of the list, and initializes the size of the list to 1.
 */
CharLinkedList::CharLinkedList(char c) {
    // Create a new node
    Node* newNode = new Node;
    // Initialize the new node
    newNode->initialize(c);
    // Update head and tail to point to the new node
    head = tail = newNode;
    // Update the size of the list
    csize = 1;
}

/*
 * name:      CharLinkedList
 * purpose:   Constructs a CharLinkedList object with an array of characters 
              and size parameter
 * arguments: a char array representing the characters to initialize the linked 
              list, an integer representing the size of the array
 * returns:   None
 * effects:   Initializes the size of the list to 0, then iterates over the 
              array of characters and pushes each character to the back of the 
              linked list.
 */
CharLinkedList::CharLinkedList(char arr[], int size) {
    csize = 0;
    // Iterate over the array of characters
    for (int i = 0; i < size; i++) {
        // Push each character to the back of the linked list
        pushAtBack(arr[i]);
    }
}

/*
 * name:      CharLinkedList (copy constructor)
 * purpose:   Constructs a copy of a CharLinkedList object
 * arguments: a constant reference to another CharLinkedList object
 * returns:   None
 * effects:   Initializes the head, tail, and size of the new list to 0, then 
              copies nodes from the other list.
 */
CharLinkedList::CharLinkedList(const CharLinkedList &other) {
    // Initialize head, tail, and size
    head = nullptr;
    tail = nullptr;
    csize = 0;

    // Copy nodes from the other list
    copyNodesFrom(other);
}

/*
 * name:      operator= (assignment operator)
 * purpose:   Assigns the content of one CharLinkedList object to another
 * arguments: a constant reference to another CharLinkedList object
 * returns:   A reference to the left-hand side CharLinkedList object after 
              assignment
 * effects:   Clears the current content of the left-hand side instance, then 
              copies nodes from the other list.
 */

CharLinkedList& CharLinkedList::operator=(const CharLinkedList &other) {
    // Check for self-assignment
    if (this == &other) {
        return *this;
    }

    // Clear the current content of the left-hand side instance
    clear();

    // Copy nodes from the other list
    copyNodesFrom(other);

    return *this;
}

/*
 * name:      ~CharLinkedList (destructor)
 * purpose:   Destructs a CharLinkedList object
 * arguments: None
 * returns:   None
 * effects:   Deletes all nodes in the linked list
 */
CharLinkedList::~CharLinkedList() {
    // Call the private recursive helper function to delete all nodes
    recursiveDelete(head);
}

/*
 * name:      recursiveDelete
 * purpose:   Deletes all nodes in the linked list recursively
 * arguments: a pointer to the current node in the linked list
 * returns:   None
 * effects:   Recursively deletes all nodes in the linked list
 */
void CharLinkedList::recursiveDelete(Node* current) {
    if (current == nullptr) {
        return; // Base case: reached the end of the list
    }
    // Recursively delete the next node
    recursiveDelete(current->next);
    // Delete the current node
    delete current;
}

/*
 * name:      recursiveElementAt
 * purpose:   Finds the element at the specified index in the linked list 
              recursively
 * arguments: a pointer to the current node in the linked list, an integer 
              index
 * returns:   The character element at the specified index
 * effects:   None
 */
char CharLinkedList::recursiveElementAt(Node* current, int index) const {
    // Base case: reached the node at the specified index
    if (index == 0) {
        return current->data;
    }
    // Recursive case: continue traversing the list
    return recursiveElementAt(current->next, index - 1);
}

/*
 * name:      copyNodesFrom
 * purpose:   Copies nodes from another CharLinkedList object
 * arguments: a constant reference to another CharLinkedList object
 * returns:   None
 * effects:   Creates new nodes in the linked list and copies data from the 
              other list
 */
void CharLinkedList::copyNodesFrom(const CharLinkedList &other) {
    Node* otherCurr = other.head;
    while (otherCurr != nullptr) {
        // Create a new node
        Node* newNode = new Node;
        newNode->data = otherCurr->data;
        newNode->prev = nullptr;
        newNode->next = nullptr;

        // If this is the first node being copied, set it as the head
        if (isEmpty()) {
            head = tail = newNode;
        } else {
            // Otherwise, link it to the previous node
            tail->next = newNode;
            newNode->prev = tail;
            tail = newNode;
        }

        // Move to the next node
        otherCurr = otherCurr->next;
        csize++;
    }
}

/*
 * name:      insertNodeAt
 * purpose:   Inserts a new node with a given character at a specified position 
              in the linked list
 * arguments: a character element, a pointer to the current node in the linked 
              list
 * returns:   None
 * effects:   Modifies the linked list by inserting a new node at the specified 
              position
 */
void CharLinkedList::insertNodeAt(char c, Node* current) {
    // Create a new node
    Node* newNode = new Node;
    // Initialize the new node with the given character
    newNode->initialize(c);

    // If the current node is not the tail, adjust pointers accordingly
    if (current != tail) {
        newNode->next = current->next;
        current->next->prev = newNode;
    } else {
        // If the current node is the tail, update  to point to the new node
        tail = newNode;
    }

    // Update pointers of the new node
    newNode->prev = current;
    current->next = newNode;

    // Increment the size of the list
    csize++;
}

/*
 * name:      getNodeAt
 * purpose:   Retrieves the node at the specified index in the linked list
 * arguments: an integer index representing the position of the node to 
              retrieve
 * returns:   A pointer to the node at the specified index
 * effects:   None
 */
CharLinkedList::Node* CharLinkedList::getNodeAt(int index) const {
    // Check if index is out of range
    if (index < 0 or index >= csize) {
        throw std::range_error("index (" + std::to_string(index) + 
                               ") not in range [0.." + std::to_string(csize) +
                               ")");
    }

    // Start from the head
    Node* current = head;
    // Traverse the list until reaching the desired index
    for (int i = 0; i < index; i++) {
        current = current->next;
    }
    return current;
}

/*
 * name:      isEmpty
 * purpose:   Checks if the linked list is empty
 * arguments: None
 * returns:   A boolean value indicating whether the linked list is empty 
              (true) or not (false)
 * effects:   None
 */
bool CharLinkedList::isEmpty() const {
    return csize == 0;
}

/*
 * name:      clear
 * purpose:   Clears the content of the linked list
 * arguments: None
 * returns:   None
 * effects:   Deletes all nodes in the linked list and resets head, tail, and 
              size to indicate an empty list
 */
void CharLinkedList::clear() {
    // Call the private recursive helper function to delete all nodes
    recursiveDelete(head);

    // Reset head, tail, and size to indicate an empty list
    head = nullptr;
    tail = nullptr;
    csize = 0;
}

/*
 * name:      recursiveReplaceAt
 * purpose:   Recursively replaces the element at the specified index with the 
              new element
 * arguments: A pointer to the current node being processed, a character 
              representing the new element to replace, and an integer index 
              representing the position of the element to replace
 * returns:   None
 * effects:   Modifies the data of the node at the specified index to the new 
              element. Throws a std::range_error exception if the index is out 
              of range.
 */
void CharLinkedList::recursiveReplaceAt(Node* current, char c, int index) {
    // Base case: reached the node at the specified index
    if (current == nullptr) {
        throw std::range_error("index (" + std::to_string(index) + 
                               ") not in range [0.." + std::to_string(csize) +
                               "]");
    }
    if (index == 0) {
        current->data = c;
        return;
    }
    // Recursive case: continue traversing the list
    recursiveReplaceAt(current->next, c, index - 1);
}


/*
 * name:      size
 * purpose:   Retrieves the size of the linked list
 * arguments: None
 * returns:   An integer representing the number of elements in the linked list
 * effects:   None
 */
int CharLinkedList::size() const {
    return csize;
}

/*
 * name:      first
 * purpose:   Retrieves the first element in the linked list
 * arguments: None
 * returns:   The first character element in the linked list
 * effects:   Throws a std::runtime_error exception if the linked list is
              empty.
 */
char CharLinkedList::first() const {
    if (isEmpty()) {
        throw std::runtime_error("cannot get first of empty LinkedList");
    }
    // Return the data of the head node
    return head->data;
}

/*
 * name:      last
 * purpose:   Retrieves the last element in the linked list
 * arguments: None
 * returns:   The last character element in the linked list
 * effects:   Throws a std::runtime_error exception if the linked list is 
              empty.
 */
char CharLinkedList::last() const {
    if (isEmpty()) {
        throw std::runtime_error("cannot get last of empty LinkedList");
    }
    // Return the data of the tail node
    return tail->data;
}

/*
 * name:      elementAt
 * purpose:   Retrieves the element at the specified index in the linked list
 * arguments: An integer index representing the position of the element to 
              retrieve
 * returns:   The character element at the specified index
 * effects:   Throws a std::range_error exception if the index is out of range.
 */
char CharLinkedList::elementAt(int index) const {
    // Check if index is out of range
    if (index < 0 or index >= csize) {
        throw std::range_error("index (" + std::to_string(index) + 
                               ") not in range [0.." + std::to_string(csize) +
                               ")");
    }

    // Call the recursive helper function to find element at the index
    return recursiveElementAt(head, index);
}

/*
 * name:      toString
 * purpose:   Converts the linked list to a string representation
 * arguments: None
 * returns:   A string representing the linked list, including its size and 
              elements
 * effects:   None
 */
std::string CharLinkedList::toString() const {
    // Initialize an empty string to store the result
    std::string result = "[CharLinkedList of size " + std::to_string(csize) + 
                         " <<";

    // Iterate through the list and append each element to the result string
    Node* current = head;
    while (current != nullptr) {
        result += current->data;
        current = current->next;
    }

    // Append the closing bracket
    result += ">>]";

    return result;
}

/*
 * name:      toReverseString
 * purpose:   Converts the linked list to a string representation in reverse 
              order
 * arguments: None
 * returns:   A string representing the linked list in reverse order, including 
              its size and elements
 * effects:   None
 */
std::string CharLinkedList::toReverseString() const {
    // Initialize an empty string to store the result
    std::string result = "[CharLinkedList of size " + std::to_string(csize) + 
                         " <<";

    // Start from the tail of the list and iterate backwards, appending each 
    // element to the result string
    Node* current = tail;
    while (current != nullptr) {
        result += current->data;
        current = current->prev;
    }

    // Append the closing bracket
    result += ">>]";

    return result;
}

/*
 * name:      pushAtBack
 * purpose:   Inserts a new node with the given character at the back of the 
              linked list
 * arguments: c - The character to be inserted at the back of the list
 * returns:   None
 * effects:   Modifies the linked list by adding a new node at the back
 */
void CharLinkedList::pushAtBack(char c) {
    // Create a new node
    Node* newNode = new Node;
    // Initialize the new node with the given character
    newNode->initialize(c);

    // If the list is empty, set both head and tail to point to the new node
    if (isEmpty()) {
        head = tail = newNode;
    } else {
        // Set the previous pointer of the new node
        newNode->prev = tail;
        // Otherwise, link the current tail node to the new node
        tail->next = newNode;
        // Update tail to point to the new node
        tail = newNode;
    }

    // Increment the size of the list
    csize++;
}

/*
 * name:      pushAtFront
 * purpose:   Inserts a new node with the given character at the front of the 
              linked list
 * arguments: c - The character to be inserted at the front of the list
 * returns:   None
 * effects:   Modifies the linked list by adding a new node at the front
 */

void CharLinkedList::pushAtFront(char c) {
    // Create a new node
    Node* newNode = new Node;
    // Initialize the new node with the given character
    newNode->initialize(c);

    // If the list is empty, set both head and tail to point to the new node
    if (isEmpty()) {
        head = tail = newNode;
    } else {
        // Set the next pointer of the new node
        newNode->next = head;
        // Set the previous pointer of the current head node
        head->prev = newNode;
        // Update head to point to the new node
        head = newNode;
    }

    // Increment the size of the list
    csize++;
}

/*
 * name:      insertAt
 * purpose:   Inserts a new node with the given character at the specified 
              index in the linked list
 * arguments: c - The character to be inserted
 *            index - The index at which to insert the new node
 * returns:   None
 * effects:   Modifies the linked list by adding a new node at the specified 
              index
 *            Throws std::range_error if the index is out of range
 */
void CharLinkedList::insertAt(char c, int index) {
    // Check if index is out of range
    if (index < 0 or index > csize) {
        throw std::range_error("index (" + std::to_string(index) + 
                               ") not in range [0.." + std::to_string(csize) +
                               "]");
    }

    // If index is 0, it's equivalent to pushing at the front
    if (index == 0 or isEmpty()) {
        pushAtFront(c);
    // If index is the size of the list, it's equivalent to pushing at the back
    } else if (index == csize) {
        pushAtBack(c);
    } else {
        // Get the node at the index
        Node* current = getNodeAt(index - 1);
        // Insert the new node at the specified index
        insertNodeAt(c, current);
    }
}

/*
 * name:      insertInOrder
 * purpose:   Inserts a new node with the given character into the linked list 
              in ascending order
 * arguments: c - The character to be inserted
 * returns:   None
 * effects:   Modifies the linked list by adding a new node in ascending order
 */
void CharLinkedList::insertInOrder(char c) {
    // If the list is empty or the new element is smaller than the first 
    // element, insert it at the front
    if (isEmpty() or c < head->data) {
        pushAtFront(c);
        return;
    }

    // Traverse the list to find the correct position to insert the new element
    Node* current = head;
    while (current->next != nullptr and current->next->data < c) {
        current = current->next;
    }

    // Insert the new element at the correct position
    insertNodeAt(c, current);
}

/*
 * name:      popFromFront
 * purpose:   Removes the first element from the linked list
 * arguments: None
 * returns:   None
 * effects:   Modifies the linked list by removing the first element
 */
void CharLinkedList::popFromFront() {
    // Throw error if list is empty
    if (isEmpty()) {
        throw std::runtime_error("cannot pop from empty LinkedList");
    }
    removeAt(0);
}

/*
 * name:      popFromBack
 * purpose:   Removes the last element from the linked list
 * arguments: None
 * returns:   None
 * effects:   Modifies the linked list by removing the last element
 */
void CharLinkedList::popFromBack() {
    // Throw error if list is empty
    if (isEmpty()) {
        throw std::runtime_error("cannot pop from empty LinkedList");
    }
    removeAt(size() - 1);
}

/*
 * name:      removeAt
 * purpose:   Removes the element at the specified index from the linked list
 * arguments: An integer index representing the position of the element to be 
              removed
 * returns:   None
 * effects:   Modifies the linked list by removing the element at the specified 
              index
 */
void CharLinkedList::removeAt(int index) {
    // Check if the index is out of range
    if (index < 0 or index >= csize) {
        throw std::range_error("index (" + std::to_string(index) + 
                               ") not in range [0.." + std::to_string(csize) +
                               ")");
    }

    // Get the node at the specified index
    Node* current = getNodeAt(index);

    // Update pointers to skip the current node
    if (current->prev != nullptr) {
        current->prev->next = current->next;
    } else {
        head = current->next; // Update head if the node is the head
    }
    if (current->next != nullptr) {
        current->next->prev = current->prev;
    } else {
        tail = current->prev; // Update tail if the node is the tail
    }

    // Delete the node
    delete current;

    // Decrement the size of the list
    csize--;
}

/*
 * name:      replaceAt
 * purpose:   Replaces the element at the specified index with the given 
              character
 * arguments: A character c representing the new element, and an integer index 
              representing the position of the element to be replaced
 * returns:   None
 * effects:   Modifies the linked list by replacing the element at the 
              specified index with the new character
 */
void CharLinkedList::replaceAt(char c, int index) {
    // Check if the index is out of range
    if (index < 0 or index >= csize) {
        throw std::range_error("index (" + std::to_string(index) + 
                               ") not in range [0.." + std::to_string(csize) +
                               "]");
    }

    // Call the recursive helper function to replace the element at the index
    recursiveReplaceAt(head, c, index);
}

/*
 * name:      concatenate
 * purpose:   Concatenates the elements of the given CharLinkedList to the end 
              of this CharLinkedList
 * arguments: A pointer to a CharLinkedList object representing the list to be 
              concatenated
 * returns:   None
 * effects:   Modifies this CharLinkedList by adding a copy of the elements 
              from the given CharLinkedList to the end
 */
void CharLinkedList::concatenate(CharLinkedList *other) {
    // If the other list is empty, there's nothing to concatenate
    if (other->isEmpty()) {
        return;
    }

    // Make a copy of the other list
    CharLinkedList copy(*other);

    // Iterate through the copied list and push each element to the back of 
    // this list
    Node* current = copy.head;
    while (current != nullptr) {
        pushAtBack(current->data);
        current = current->next;
    }
}